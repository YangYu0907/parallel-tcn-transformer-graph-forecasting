import json, os, hashlib, shutil
from pathlib import Path
from datetime import datetime, timezone

H = Path(__file__).resolve().parent
A = H.parent
B = A / '研究资料/CAISO_feature_fusion_rev12/asof_retraining_branch_20260913'
def read(p): return json.loads(Path(p).read_text(encoding='utf-8-sig'))
def save(p,obj):
    p=Path(p); q=p.with_suffix(p.suffix+'.tmp')
    q.write_text(json.dumps(obj,ensure_ascii=False,indent=2),encoding='utf-8');os.replace(q,p)
def sha(p): return hashlib.sha256(Path(p).read_bytes()).hexdigest()
report=read(H/'PRESERVATION_CHECK.json'); assert report['status']=='passed'
transfer=read(H/'LISTENER_TRANSFER.json'); assert transfer['status']=='passed'
assert transfer['dispatch_receipts_before']==transfer['dispatch_receipts_after'], 'New event appeared during handoff; inspect before ready'
at=datetime.now(timezone.utc).isoformat()
tid=transfer['new_thread_id']; pid=transfer['new_watcher_pid']
state=read(H/'CURRENT_STATE.json')
state.update({'transfer_state':'ready','destination_thread_id':tid,'destination_title':'10.11','listener':transfer,'preservation_report':report,'at_transfer':at})
save(H/'CURRENT_STATE.json',state)
handoff=read(B/'HANDOFF.json')
handoff['thread_transfer_20261011']={'at':at,'status':'ready','from_thread_id':transfer['old_thread_id'],'to_thread_id':tid,'handoff_directory':str(H),'overview':str(H/'10.11_接续总览.txt'),'current_state':str(H/'CURRENT_STATE.json'),'preservation_report':str(H/'PRESERVATION_CHECK.json'),'active_numerical_manager':None,'whole_research_complete':False,'previous_research_status':handoff.get('current_status'),'old_chat_starts_no_new_experiments':True}
handoff['event_listener_pid']=pid
handoff['event_listener_thread_id']=tid
handoff['event_listener_current_20261011']=transfer
handoff['current_manuscript_canonical']=str(A/'研究资料/manuscript_20261001_v7_diagrams')
handoff['latest_handoff_directory']=str(H)
handoff['last_handoff_at']=at
# Do not rewrite historical frozen protocols, historical pause records or historical PID fields.
save(B/'HANDOFF.json',handoff)
shutil.copy2(B/'HANDOFF.json',H/'HANDOFF_after_transfer.json')
extras=[]
for name in ('PATH_MAP.json','requirements_research_full.txt','requirements_research_snapshot.txt','先读我.txt'):
    p=A/name; dest=H/('原归档_'+name);shutil.copy2(p,dest)
    assert sha(p)==sha(dest);extras.append({'source':str(p),'copy':str(dest),'sha256':sha(p)})
save(H/'EXTRA_ARCHIVE_RECORDS.json',extras)
contract_files=['10.11_接续总览.txt','CURRENT_STATE.json','新对话启动说明.txt','保全与恢复说明.txt','PRESERVATION_CHECK.json','PROTECTED_18_CHECK.json','V7_SOURCE_BINDINGS_CHECK.json','DOCUMENT_CONTAINER_CHECK.json','EXPERIMENT_RESULT_INDEX.json','INVENTORY_SUMMARY.json','LISTENER_TRANSFER.json','HANDOFF_before_transfer.json','HANDOFF_after_transfer.json']
save(H/'HANDOFF_PACKAGE_CHECK.json',{'at':at,'status':'passed','files':[{'path':str(H/n),'sha256':sha(H/n)} for n in contract_files],'V7_originals_unchanged':report['protected18_before_and_after_passed'],'source_deletions':0,'experiment_runs_this_handoff':0,'new_thread_id':tid,'listener_pid':pid,'new_queue_events_during_transfer':transfer['dispatch_receipts_after']-transfer['dispatch_receipts_before']})
save(H/'TRANSFER_READY.json',{'status':'ready','at':at,'destination_thread_id':tid,'destination_title':'10.11','source_thread_id':transfer['old_thread_id'],'listener_pid':pid,'listener_creation_utc_ticks':transfer['new_watcher_creation_utc_ticks'],'preservation':'passed','active_numerical_manager':None,'overview':str(H/'10.11_接续总览.txt'),'current_state':str(H/'CURRENT_STATE.json'),'package_check':str(H/'HANDOFF_PACKAGE_CHECK.json'),'whole_research_completed':False,'training_handoff':'Only destination chat continues authorized research; source chat no new experimental mutations after ready.'})
print(json.dumps({'status':'ready','thread_id':tid,'listener_pid':pid,'preservation':report['status']},ensure_ascii=False))
