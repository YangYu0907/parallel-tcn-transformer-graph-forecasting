"""Read-only source inventory, byte hashes and bounded copies for the 10.11 handoff."""
import os, json, hashlib, shutil, stat, time, ast, re
from pathlib import Path
from collections import defaultdict
from datetime import datetime, timezone

A = Path(r'C:\Users\于阳\CAISO_V7_成功实验归档_20261002')
B = A / '研究资料/CAISO_feature_fusion_rev12/asof_retraining_branch_20260913'
R = B / 'reviewer_revision_v2_20261003'
Z = R / 'mechanism_weather_extension_20261007'
H = A / '交接_10.11'
M = A / '研究资料/manuscript_20261001_v7_diagrams'
H.mkdir(exist_ok=True)

def now(): return datetime.now(timezone.utc).isoformat()
def save(name, obj):
    p = H / name
    tmp = p.with_suffix(p.suffix + '.tmp')
    tmp.write_text(json.dumps(obj, ensure_ascii=False, indent=2), encoding='utf-8')
    os.replace(tmp, p)
def lp(p):
    p = str(p)
    return p if p.startswith('\\\\?\\') else '\\\\?\\' + os.path.abspath(p)
def sha(p):
    s = hashlib.sha256()
    with open(lp(p), 'rb') as f:
        while block := f.read(1024 * 1024): s.update(block)
    return s.hexdigest()
def read(p): return json.loads(Path(p).read_text(encoding='utf-8-sig'))

start = time.time()
stats = defaultdict(lambda: {'files': 0, 'bytes': 0})
files, junctions, scan_errors = [], [], []
cached_inventory = H / 'ALL_ARCHIVE_FILES.jsonl'
repair_roots = []
if cached_inventory.exists():
    files = [json.loads(line) for line in cached_inventory.open(encoding='utf-8')]
    old_inventory = read(H / 'INVENTORY_SUMMARY.json')
    junctions = old_inventory['junctions_not_followed']
    for err in old_inventory['errors']:
        match = re.search(r"('.*')$", err)
        if match:
            p = ast.literal_eval(match.group(1))
            if os.path.isfile(lp(p)):
                s = os.stat(lp(p)); files.append({'path': p, 'relative_path': str(Path(p).relative_to(A)), 'bytes': s.st_size, 'mtime_ns': s.st_mtime_ns})
            elif os.path.isdir(lp(p)): repair_roots.append(lp(p))
            else: scan_errors.append(err)
        else: scan_errors.append(err)
else: repair_roots = [lp(A)]
for scan_root in repair_roots:
 for root, dirs, names in os.walk(scan_root, followlinks=False, onerror=lambda e: scan_errors.append(str(e))):
    root = root.removeprefix('\\\\?\\')
    rd = Path(root)
    keep = []
    for dn in dirs:
        p = rd / dn
        if p == H: continue
        try:
            if os.lstat(lp(p)).st_file_attributes & stat.FILE_ATTRIBUTE_REPARSE_POINT:
                junctions.append({'path': str(p), 'target': os.path.realpath(p)})
            else: keep.append(dn)
        except OSError as e: scan_errors.append(str(e))
    dirs[:] = keep
    for name in names:
        p = rd / name
        try:
            s = os.stat(lp(p))
            row = {'path': str(p), 'relative_path': str(p.relative_to(A)), 'bytes': s.st_size, 'mtime_ns': s.st_mtime_ns}
            files.append(row)
        except OSError as e: scan_errors.append(str(e))
files = list({x['path']: x for x in files}.values())
for row in files:
    group = Path(row['relative_path']).parts[0]
    stats[group]['files'] += 1
    stats[group]['bytes'] += row['bytes']
with (H / 'ALL_ARCHIVE_FILES.jsonl').open('w', encoding='utf-8') as f:
    for row in files: f.write(json.dumps(row, ensure_ascii=False) + '\n')
save('INVENTORY_SUMMARY.json', {'at': now(), 'files': len(files), 'bytes': sum(x['bytes'] for x in files), 'groups': stats, 'junctions_not_followed': junctions, 'errors': scan_errors, 'scope': 'Entire existing archive except this handoff; every regular file indexed, not every file rehashed.'})
print(json.dumps({'stage': 'inventory', 'files': len(files), 'groups': stats, 'errors': scan_errors}, ensure_ascii=False), flush=True)

protected = read(Z / 'PROTECTED_FILES.json')
hashes, hash_errors = {}, []
def checked_sha(p):
    p = str(p)
    if p not in hashes:
        before = os.stat(lp(p))
        v = sha(p)
        after = os.stat(lp(p))
        if before.st_size != after.st_size or before.st_mtime_ns != after.st_mtime_ns:
            raise RuntimeError('File changed while hashing: ' + p)
        hashes[p] = v
    return hashes[p]
protected_rows = [{'path': p, 'expected': expected, 'actual': checked_sha(p), 'passed': checked_sha(p) == expected} for p, expected in protected.items()]
save('PROTECTED_18_CHECK.json', {'at': now(), 'passed': all(x['passed'] for x in protected_rows), 'files': protected_rows})
assert all(x['passed'] for x in protected_rows), 'Protected file mismatch; no source mutation performed'

core_dirs = [B / 'spike_specialist_v7_20260930', B / 'v7_confirmation_20260930']
text_ext = {'.py', '.ps1', '.txt', '.md', '.json', '.toml', '.yaml', '.yml', '.tex', '.bib', '.csv', '.log'}
model_ext = {'.joblib', '.pkl', '.pickle', '.pt', '.pth'}
hash_paths, copy_paths = set(protected), set(protected)
for row in files:
    p = Path(row['path']); size = row['bytes']; ext = p.suffix.lower()
    is_m = p.is_relative_to(M)
    is_r = p.is_relative_to(R)
    is_core = any(p.is_relative_to(d) for d in core_dirs)
    is_doc = any(q in p.parts for q in ('老师五项意见_当前总汇_20261004', '修补总复盘_20261004', '老师意见修订_20261003', '老师反馈分析_20261003'))
    bulk = any(x.lower() in {'work','raw','objects','__pycache__','pages','cache','download_receipts','raw_objects','tmp'} for x in p.parts)
    cache_array = ext == '.npy' or any(x.startswith('design') or x.startswith('encoded') for x in [p.name.lower()])
    is_b_text = p.is_relative_to(B) and ext in text_ext and size <= 8 * 1024**2 and not bulk
    is_r_evidence = is_r and not bulk and not cache_array
    if is_m or is_r_evidence or is_core or is_doc or is_b_text:
        hash_paths.add(str(p))
    # Copies: all manuscript assets, core evidence, all bounded text/code, recent models.
    # Large numerical caches and bulk weather data stay intact in their original location.
    if is_m or is_core or is_doc or (is_b_text and 'cycles' not in p.parts) or (is_r_evidence and ext in model_ext and size <= 64 * 1024**2):
        copy_paths.add(str(p))

binding_sources = [B / 'spike_specialist_v7_20260930/SOURCE_BINDINGS.json', B / 'spike_specialist_v7_20260930/DATA_ADMISSION.json', B / 'spike_specialist_v7_20260930/EXECUTION_SEAL.json', B / 'v7_confirmation_20260930/PROTOCOL.json', B / 'v7_confirmation_20260930/ALL_PREDICTIONS_COMMITTED.json']
bindings = []
def walk_bindings(obj, source):
    if isinstance(obj, dict):
        for key, val in obj.items():
            if isinstance(key, str) and len(key) > 3 and key[1:3] in (':\\', ':/') and isinstance(val, str) and len(val) == 64 and all(c in '0123456789abcdefABCDEF' for c in val):
                bindings.append({'manifest': str(source), 'path': key, 'expected': val.lower()})
            walk_bindings(val, source)
    elif isinstance(obj, list):
        for val in obj: walk_bindings(val, source)
for p in binding_sources: walk_bindings(read(p), p)
for row in bindings:
    try:
        row['actual'] = checked_sha(row['path'])
        row['passed'] = row['actual'] == row['expected']
    except Exception as e:
        row['passed'] = False; row['error'] = str(e)
save('V7_SOURCE_BINDINGS_CHECK.json', {'at': now(), 'checked': len(bindings), 'passed': all(x['passed'] for x in bindings), 'rows': bindings, 'scope': 'Absolute path-to-sha256 mappings in selected V7 manifests; other schema records retained for replay, not claimed revalidated.'})

planned_bytes = sum(os.stat(lp(p)).st_size for p in copy_paths)
save('COPY_PLAN.json', {'at': now(), 'files': len(copy_paths), 'bytes_before_deduplication': planned_bytes, 'hash_files': len(hash_paths), 'policy': 'Sources never moved or deleted. Content-addressed critical copies plus in-place full recent-tree hashes. Numerical arrays are never decoded.'})
print(json.dumps({'stage': 'plan', 'copy_files': len(copy_paths), 'copy_GiB': planned_bytes / 1024**3, 'hash_files': len(hash_paths), 'bindings': len(bindings)}, ensure_ascii=False), flush=True)
assert planned_bytes < 3 * 1024**3, 'Copy plan exceeds compact-snapshot cap; review without source mutation'
assert shutil.disk_usage(H).free - planned_bytes > 4 * 1024**3, 'Disk reserve'
objects = H / '保全快照/objects'; objects.mkdir(parents=True, exist_ok=True)
copy_rows, changed = [], []
manifest = H / 'VERIFIED_SOURCE_HASHES.jsonl'
with manifest.open('w', encoding='utf-8') as out:
    for i, p in enumerate(sorted(hash_paths | copy_paths)):
        try:
            digest = checked_sha(p)
            item = {'path': p, 'bytes': os.stat(lp(p)).st_size, 'sha256': digest}
            out.write(json.dumps(item, ensure_ascii=False) + '\n')
            if p in copy_paths:
                dest = objects / (digest + Path(p).suffix.lower())
                if not dest.exists(): shutil.copy2(lp(p), dest)
                actual = sha(dest)
                assert actual == digest, 'Snapshot mismatch'
                copy_rows.append({**item, 'snapshot': str(dest), 'verified': True})
        except Exception as e: hash_errors.append({'path': p, 'error': str(e)})
        if i % 500 == 0:
            save('PRESERVATION_PROGRESS.json', {'at': now(), 'processed': i + 1, 'total': len(hash_paths | copy_paths), 'copied': len(copy_rows), 'errors': hash_errors, 'elapsed_seconds': time.time() - start})
            print(json.dumps({'stage': 'hash_copy', 'processed': i + 1, 'total': len(hash_paths | copy_paths), 'errors': len(hash_errors)}), flush=True)
with (H / 'SNAPSHOT_INDEX.jsonl').open('w', encoding='utf-8') as out:
    for row in copy_rows: out.write(json.dumps(row, ensure_ascii=False) + '\n')
paper_dir = H / 'V7论文副本'; paper_dir.mkdir(exist_ok=True)
for p in [M / x for x in ('Energy_manuscript.docx', 'Energy_manuscript.pdf', 'Energy_supplementary.docx', 'Energy_supplementary.pdf')]:
    dest = paper_dir / p.name
    shutil.copy2(p, dest)
    assert sha(dest) == checked_sha(p)
after = [{'path': p, 'passed': sha(p) == expected} for p, expected in protected.items()]
report = {'at': now(), 'status': 'passed' if not scan_errors and not hash_errors and all(x['passed'] for x in after) and all(x['passed'] for x in bindings) else 'needs_review', 'indexed_files': len(files), 'indexed_bytes': sum(x['bytes'] for x in files), 'hash_verified_files': len(hash_paths | copy_paths) - len(hash_errors), 'snapshot_index_rows': len(copy_rows), 'snapshot_unique_files': len(list(objects.iterdir())), 'snapshot_unique_bytes': sum(p.stat().st_size for p in objects.iterdir()), 'protected18_before_and_after_passed': all(x['passed'] for x in after), 'V7_binding_rows_checked': len(bindings), 'V7_binding_failures': [x for x in bindings if not x['passed']], 'errors': scan_errors + hash_errors, 'source_deletions': 0, 'numerical_training_runs': 0, 'target_arrays_decoded': 0, 'recent_scope': str(R), 'recent_scope_all_regular_files_rehashed': False, 'scope_note': 'Complete archive path/size/mtime inventory including repaired Windows long paths. Rehash manuscript, V7 core, reviewer evidence/models/predictions/cycles and bounded evidence/code. Bulk network work/raw/objects/pages/cache/download_receipts and .npy design arrays are inventory-only; retained in place, existing source audits preserved. Compact byte-verified copies; larger original data/models stay in place. Same-disk preservation, not an off-device backup. Conda and remaining D-drive dependencies remain external.', 'elapsed_seconds': time.time() - start}
save('PRESERVATION_CHECK.json', report)
print(json.dumps(report, ensure_ascii=False), flush=True)
