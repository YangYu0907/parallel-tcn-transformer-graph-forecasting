import os, json, hashlib
from pathlib import Path
from datetime import datetime, timezone

A = Path(r'C:\Users\于阳\CAISO_V7_成功实验归档_20261002')
H = A / '交接_10.11'
B = A / '研究资料/CAISO_feature_fusion_rev12/asof_retraining_branch_20260913'
R = B / 'reviewer_revision_v2_20261003'
Z = R / 'mechanism_weather_extension_20261007'
W = Z / 'prefix_stability_1009'
E = W / 'tendency_1011'
M = A / '研究资料/manuscript_20261001_v7_diagrams'
def read(p): return json.loads(Path(p).read_text(encoding='utf-8-sig'))
def save(p, obj):
    p = Path(p); q = p.with_suffix(p.suffix + '.tmp')
    q.write_text(json.dumps(obj, ensure_ascii=False, indent=2), encoding='utf-8'); os.replace(q, p)
def sha(p): return hashlib.sha256(Path(p).read_bytes()).hexdigest()
at = datetime.now(timezone.utc).isoformat()
state = {
 'schema': 'caiso_thread_handoff_v1', 'at': at,
 'source_thread_id': '01a08bcc-5e32-79d1-9d89-fcf19c30f204', 'source_title': '0910', 'requested_destination_title': '10.11',
 'transfer_state': 'preparing', 'actual_transfer_authority': str(H / 'TRANSFER_READY.json'),
 'paths': {k:str(v) for k,v in {'archive':A,'branch':B,'reviewer_revision':R,'weather_extension':Z,'prefix_comparisons':W,'latest_experiment':E,'manuscript':M,'handoff':H}.items()},
 'current_research_status': 'weather_tendency_completed_no_stable_increment',
 'active_numerical_manager': None,
 'last_manager': {'pid':20996, 'creation_utc_ticks':639272829260225442, 'exit_monitor_pid':18132, 'status':'normally_exited_handled', 'exit_receipt':str(B / 'event_driven_automation/process_monitors/mechanism_exit_20996_639272829260225442.exit.json')},
 'user_pause': {'path':str(B.parent / 'RESEARCH_PAUSED.json'), 'last_record':read(B.parent / 'RESEARCH_PAUSED.json'), 'must_recheck_before_launch':True},
 'latest': {'result':str(E/'RESULT.json'),'result_sha256':sha(E/'RESULT.json'),'audit':str(E/'AUDIT.json'),'audit_sha256':sha(E/'AUDIT.json'),'decision':read(E/'DECISION.json'),'handled':read(E/'HANDLED.json')},
 'teacher_issues': [
  {'id':1,'issue':'动态图收益不稳定','status':'unresolved','next_evidence':'Exact matched local+dynamic versus local+static versus SELF/fixed/V7; strict prefix expert provenance required; reuse reviewed artifacts.'},
  {'id':2,'issue':'对比输入特征不一致','status':'core_price_only_comparison_completed_scope_limited','limit':'Do not relabel all16 historical baselines as same-input; new weather/DAM inputs need matched controls.'},
  {'id':3,'issue':'V7缺组件消融','status':'12_variants_completed','limit':'Retain unfavorable directions; new integrated systems require their own ablations.'},
  {'id':4,'issue':'突发尖峰提升不足','status':'unresolved','limit':'Latest probability recognition trial not promoted; no new point-price improvement established.'},
  {'id':5,'issue':'缺少概率区间','status':'implemented_development_evidence_frozen_candidate_independent_confirmation_pending'}],
 'preservation': {'report':str(H/'PRESERVATION_CHECK.json'),'all_archive_inventory':str(H/'ALL_ARCHIVE_FILES.jsonl'),'verified_hashes':str(H/'VERIFIED_SOURCE_HASHES.jsonl'),'copy_index':str(H/'SNAPSHOT_INDEX.jsonl'),'original_files_must_not_be_deleted':True,'V7_dependencies_include_older_experts':True},
 'next_actions': [
  'Read full handoff and recent decisions before acting; do not repeat latest completed four fits or failed GAM numerical repair.',
  'Inspect availability and bounded cost of truly new information: original-vintage nodal DAM values or exact same-valid-time forecast revisions; do not automatically launch another large extraction.',
  'Register finite same-calendar/same-input/same-budget comparison only after exact source and time admission. Test probabilistic value before KNN/amplitude/point correction.',
  'Keep graph attribution, fair-input coverage, new-chain ablations, source freeze and new independent temporal confirmation explicit; no fresh targets before gates.',
  'Continue autonomously within prior authority, but respect user pause, resource guard, no paid sources or outbound inquiry without explicit permission.' ],
 'closed_routes': [str(W/x) for x in ['retained_dam_1010','dam_pool_1010','gap_add_1010','smooth_risk_1011','smooth_solve_1011','tendency_1011']],
 'source_gaps': {'DAM':'Original numeric-value to as-issued publication binding unresolved; later-modified records excluded; complete calendar required.', 'weather':'Current cycles spaced3h, leads3/4/5 only. Past-state tendency is not same-valid-time revision; older lead6+ original objects and availability audit required.'},
 'guardrails': {'V7_unchanged':True,'core_elements':['TCN','Transformer','dynamic GNN','parallel temporal branches','adaptive feature-level attention'], 'read_new_test_targets':False,'manuscript_polishing':'deferred','preserve_all_outcomes':True,'promise_all_metrics_improve':False,'same_operator_audit_not_independent_person':True, 'launch_free_physical_GiB':5,'launch_free_commit_GiB':5,'runtime_headroom_GiB':4,'disk_reserve_GiB':4,'threads':1,'shared_numerical_lock':r'D:\Desktop\数据科学_论文\研究优化_20260818\logs\NEURAL_RUN.lock','python':r'D:\Documents\conda_envs\tcn_air\python.exe','no_wallclock_budget_from_eta':True},
 'event_policy': {'watcher':str(B/'event_driven_automation/watch.ps1'),'inbox':str(B/'event_driven_automation/inbox'),'schema':'caiso_research_event_v1','allowed_events':['audited_result_ready','major_milestone','unexpected_result','needs_analysis','blocking_failure','research_completed'],'unique_event_id':True,'only_real_new_evidence':True,'no_periodic_model_wakeups':True,'new_manager_requires_exit_monitor_pid_and_creation':True,'stop_listener_when_whole_research_complete':True,'keep_existing_dispatch_receipts':True},
 'last_duplicate_event': {'delivery_id':'f0210278a5625bacac363657dcf51e791132a12965319727125226d2578d878a','payload_event_id':'weather_information_needs_analysis_3eed1fce408579e9e52d8be403abf74493d2c5412250b2675b04ba56499aa673','already_handled':True,'rerun_or_renotify':False},
 'whole_research_completed':False
}
save(H/'CURRENT_STATE.json',state)
save(H/'TRANSFER_READY.json',{'status':'preparing','at':at,'reason':'Preservation and new chat event routing not finished. Do not launch numerical tasks until ready.'})
rows=[]
for line in (H/'ALL_ARCHIVE_FILES.jsonl').open(encoding='utf-8'):
    item=json.loads(line); p=Path(item['path'])
    if p.is_relative_to(B) and p.name.lower() in {'result.json','decision.json','postrun_review.json','completion.json'} and item['bytes'] < 16*1024**2:
        obj={}; error=None
        try: obj=read('\\\\?\\'+str(p))
        except Exception as e: error=str(e)
        if not isinstance(obj,dict): obj={'value_type':type(obj).__name__}
        rows.append({'path':str(p),'relative_to_branch':str(p.relative_to(B)),'bytes':item['bytes'],'status':obj.get('status',obj.get('event')),'at':obj.get('at'),'passed':obj.get('passed',obj.get('screen_passed')),'actual_scalar_fits':obj.get('actual_scalar_fits'),'is_fixture_or_diagnostic':any(x in p.parts for x in ('_qa','tests','audits')),'read_error':error})
save(H/'EXPERIMENT_RESULT_INDEX.json',{'at':at,'scope':'Result/decision/completion file index; row count is not experiment/training count. Preserve all original conclusions.', 'rows':rows})
print(json.dumps({'state_written':True,'result_index_rows':len(rows),'parse_errors':sum(bool(x['read_error']) for x in rows)},ensure_ascii=False))
