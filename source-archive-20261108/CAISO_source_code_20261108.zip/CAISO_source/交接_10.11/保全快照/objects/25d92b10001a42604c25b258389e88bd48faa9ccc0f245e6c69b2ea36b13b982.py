"""All three seeds, both arms, original predictions preserved and every direction retained."""
import json
import gate
METRICS=('mae','rmse','near_h1_4_mae','h12_mae')
def compare(aid,bid,a,b):
    return dict(candidate=aid,reference=bid,panels={pn:{m:dict(candidate=a[pn][m],reference=b[pn][m],
        reduction_percent=100*(1-a[pn][m]/b[pn][m])) for m in METRICS} for pn in ('June284','June3397','balanced278')})
def main():
    seal=gate.verify();rows={};audits={};comparisons=[];decisions=[]
    for case in seal['cases']:
        folder=gate.HERE/'runs'/case['id'];r=gate.read(folder/'completion.json');a=gate.read(folder/'audit.json')
        gate.need(a['status']=='passed' and a['completion_sha256']==gate.sha(folder/'completion.json'),'Incomplete audit')
        for p,d in a['output_bindings'].items():gate.need(gate.sha(gate.inside(p))==d,'Audited output changed')
        rows[case['id']]=r;audits[case['id']]=a
        parent=case['parent']['reference_panels']
        comparisons.append(compare(case['id'],case['parent']['id'],r['panels'],parent))
        protects=all(r['panels'][p][m]<=parent[p][m]+1e-9 for p in ('June284','June3397') for m in METRICS)
        improves=r['panels']['June3397']['mae']<parent['June3397']['mae']-1e-6
        decisions.append(dict(case=case['id'],selected_epoch=r['selected_epoch'],protects_all_eight_headlines=protects,
            improves_dense_mae=improves,bounded_advancement_pass=protects and improves,
            hourly_prediction_max_difference=a['hourly_prediction_max_difference']))
    for seed in (20260813,20260814,20260815):
        a=f'{seed}_OFFHOUR';b=f'{seed}_GLOBAL'
        comparisons.append(compare(a,b,rows[a]['panels'],rows[b]['panels']))
    advance={arm:all(x['bounded_advancement_pass'] for x in decisions if x['case'].endswith('_'+arm)) for arm in ('GLOBAL','OFFHOUR')}
    gate.write(gate.HERE/'summary.json',dict(status='six_offhour_adapter_runs_audited',at=gate.now(),comparisons=comparisons,
        decisions=decisions,arm_passes_all_three_seeds=advance,all_positive_negative_directions_preserved=True,
        selection_scope='Refinement selected on denseJune3397; no claim of independent confirmation or pure backbone architecture attribution.',
        limitations=['Fixed552parameter refinement; no heldout targets read','OFFHOUR cannot improve hourly errors by construction',
          'Same slots/updates with differing active gradient support','Dependent forecast cells; no significance inferred from individual cells',
          'DenseJune has been used repeatedly for development; independent chronological admission remains necessary'],
        heldout_targets_read=False,complete_research_experiment=False))
    print(json.dumps(dict(status='six_offhour_adapter_runs_audited',advancement=advance)))
if __name__=='__main__':main()
