"""Attribution of fixed, already inspected development predictions; no fitting."""
from pathlib import Path
from datetime import datetime,timezone
import sys
HERE=Path(__file__).resolve().parent;B=HERE.parent
sys.path.insert(0,str(B/'context_expert_v1_20260929'));import gate
ART=Path('C:/Users/于阳/CAISO_temporary_storage')/HERE.name
OLDART=ART.parent/'chronological_expert_pilot_v14_20260930'
def stamp(s):return int(datetime.fromisoformat(s.replace('Z','+00:00')).timestamp())
def main():
    with gate.exclusive('Read-only V17 fixed prediction attribution'):
        np,lim=gate.runtime(False);assert gate.read(HERE/'pilot/INDEPENDENT_REPLAY_AUDIT.json')['status']=='passed'
        with np.load(OLDART/'EXPERT_ERROR_LIBRARY.npz') as z:d={k:z[k] for k in z.files}
        selected=(d['issued']>=stamp('2024-09-01T00:00Z'))&(d['issued']<stamp('2025-01-01T00:00Z'))
        y=d['truth'];parent=d['SPECIALIST'];delta=d['FULL']-parent;error=parent-y
        oracle_g=np.zeros_like(parent);np.divide(y-parent,delta,out=oracle_g,where=delta!=0);oracle_g=np.clip(oracle_g,0,1)
        oracle=parent+oracle_g*delta;diagnoses={}
        for arm in ['old_features','renewable_features']:
            out=parent.copy();weight=np.zeros_like(parent);estimated=np.zeros(parent.shape+(2,))
            for fi in range(4):
                with np.load(ART/f'pilot/folds/{arm}_{fi}.npz') as z:ix=z['library_rows'];out[ix]=z['prediction'];weight[ix]=z['weight']
                for path in (ART/'pilot/chunks').glob(f'{arm}_{fi}_*.npz'):
                    with np.load(path) as z:estimated.reshape(-1,2)[z['rows']]=z['estimated_changes']
            correction=out-parent;actual_mae=abs(out-y)-abs(error);actual_sse=(out-y)**2-error**2
            cross=2*error*correction;square=correction**2
            assert np.allclose(actual_sse,cross+square,rtol=1e-10,atol=1e-7)
            report=[]
            for state in [3,4,5]:
                mask=(d['states']==state)&selected[:,None];changed=mask&(weight>0)
                day=np.broadcast_to(d['issued'][:,None]//86400,mask.shape)
                byday=[dict(day=datetime.fromtimestamp(int(a)*86400,timezone.utc).date().isoformat(),added_SSE=float(actual_sse[mask&(day==a)].sum())) for a in np.unique(day[mask])]
                byday.sort(key=lambda z:z['added_SSE'],reverse=True)
                report.append(dict(state=state,cells=int(mask.sum()),changed_cells=int(changed.sum()),
                    actual_added_absolute_error=float(actual_mae[mask].sum()),actual_added_squared_error=float(actual_sse[mask].sum()),
                    estimated_added_absolute_error=float(estimated[:,:,0][mask].sum()),estimated_added_squared_error=float(estimated[:,:,1][mask].sum()),
                    changed_cells_with_actual_error_increase=int((changed&(actual_mae>0)).sum()),
                    changed_cells_where_any_nonzero_reversion_is_wrong=int((changed&(oracle_g==0)).sum()),
                    positive_corrections=int((changed&(correction>0)).sum()),negative_corrections=int((changed&(correction<0)).sum()),
                    cross_term=float(cross[mask].sum()),magnitude_squared_term=float(square[mask].sum()),
                    hindsight_path_lower_bound_RMSE=float(np.sqrt(np.square(oracle-y)[mask].mean())),
                    parent_RMSE=float(np.sqrt(np.square(error)[mask].mean())),candidate_RMSE=float(np.sqrt(np.square(out-y)[mask].mean())),
                    dates_by_added_SSE=byday))
            diagnoses[arm]=report
        result=gate.read(HERE/'pilot/RESULT.json')
        gate.write(HERE/'pilot/FIXED_OUTPUT_DIAGNOSIS.json',dict(at=gate.now(),status='completed_read_only_attribution',
            scope=result['scope'],comparisons=diagnoses,result_sha256=gate.sha(HERE/'pilot/RESULT.json'),
            no_model_fit=True,no_model_or_threshold_changes=True,new_test_targets_read=False,
            hindsight_warning='True-target path projections are diagnostic lower bounds only; never used as routable predictions, a selector, or a reported model result',
            next_hypothesis='Conditional residual risk estimates are overconfident for recovery cases; verify out-of-time calibration before adding model capacity or modifying gates',
            literature={'title':'Probabilistic forecasts, calibration and sharpness','authors':'Gneiting, Balabdaoui and Raftery','journal':'JRSS SeriesB69(2),243-268','year':2007,'doi':'10.1111/j.1467-9868.2007.00587.x','url':'https://academic.oup.com/jrsssb/article/69/2/243/7109375','application':'Calibration must be evaluated out of sample; our conditional-loss diagnostic is a proposed application, not a proof of improvement'}))
        for arm,r in diagnoses.items():
            print(arm)
            for row in r:print({k:v for k,v in row.items() if k!='dates_by_added_SSE'})
if __name__=='__main__':main()
