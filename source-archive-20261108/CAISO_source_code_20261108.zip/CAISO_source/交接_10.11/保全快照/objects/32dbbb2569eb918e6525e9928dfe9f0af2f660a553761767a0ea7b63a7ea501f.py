"""Post-hoc attribution of the fixed V26 predictions; no optimizer or selection.

This does not reopen the failed finite trial or change its checkpoints.
"""
import common as c
import time

def main():
    p=c.verify();c.check(True);d=c.read(c.HERE/'DECISION.json');a=c.read(c.HERE/'AUDIT.json')
    assert a['status']=='passed' and a['decision_sha256']==c.sha(c.HERE/'DECISION.json')
    assert c.sha(c.HERE/'RESULT.json')==a['result_sha256']
    out=c.HERE/'attribution';assert not (out/'RESULT.json').exists(),'No duplicate attribution'
    case=c.read(c.HERE/'RESULT.json')['cases'][0]
    proto=dict(at=c.now(),status='registered_before_decomposition',scope='Post-hoc diagnosis of the closed one-seed V26 TRAIN/June development pilot',
        bindings={str(c.HERE/n):c.sha(c.HERE/n) for n in ('RESULT.json','DECISION.json','AUDIT.json','diagnose_completed.py')},
        procedure=['Exact prediction-change and squared-error decomposition by horizon,state,date for both saved arms and epochs.',
            'Measure horizon correction correlation and centered first covariance component share; not a cause by itself.',
            'Replay frozen selected TOKEN and SUMMARY on the full17102 TRAIN cache without fitting, alongside unchanged parent.',
            'Compute selected TOKEN normalized-Huber gradients for fixed horizon groups1-4,5-8,9-12 across the full TRAIN panel; no gradient surgery, update or hyperparameter selection.'],
        maximum_seconds=300,maximum_optimizer_steps=0,heldout_access=False,
        limits='Training replay is in-sample. S3/S4 June evidence covers only3dates each; correlated cells are not independent events. June already inspected; diagnosis cannot supply new independent confirmation.',
        literature=[dict(url='https://arxiv.org/abs/2001.06782',supports='Conflicting task gradients are a testable mechanism; no guarantee of improved generalization. Earlier V21 PCGrad failed its retention gate, so this is diagnostic, not a rerun.'),
                    dict(url='https://arxiv.org/abs/2211.14730',supports='Preserving temporal tokens motivates the completed probe; information preservation alone does not establish predictive usefulness.')])
    c.write(out/'PROTOCOL.json',proto)
    start=time.monotonic()
    def check():
        c.check()
        if time.monotonic()-start>300:raise TimeoutError('Finite attribution budget')
    with c.gate.exclusive('V26 fixed-prediction attribution and TRAIN gradient diagnosis'):
        np,torch,lim=c.gate.runtime(True)
        from model import Reader,decode,summary_memory
        import reductions as red
        def load(row):
            assert c.sha(row['prediction'])==row['prediction_sha256']
            with np.load(row['prediction']) as z:return {k:z[k].copy() for k in z.files}
        parent=load(case['arms']['TOKEN']['history'][0])
        truth=parent['truth'];before=parent['prediction'];codes=parent['codes'];times=parent['timestamps']
        def entry(err,delta):
            e=err.ravel();v=delta.ravel()
            if not len(e):return dict(cells=0)
            after=e+v;cross=float((2*e*v).mean());size=float((v*v).mean())
            mse=float((after*after-e*e).mean());assert np.isclose(mse,cross+size,atol=1e-9)
            return dict(cells=len(e),parent_mae=float(abs(e).mean()),mae=float(abs(after).mean()),
                parent_rmse=float(np.sqrt((e*e).mean())),rmse=float(np.sqrt((after*after).mean())),
                mae_gain=float((abs(e)-abs(after)).mean()),signed_error_before=float(e.mean()),signed_error_after=float(after.mean()),
                correction_mean=float(v.mean()),correction_mean_abs=float(abs(v).mean()),
                positive_correction_fraction=float((v>0).mean()),correction_opposes_error_fraction=float((v*e<0).mean()),
                improved_cell_fraction=float((abs(after)<abs(e)).mean()),mse_change=mse,mse_cross_term=cross,mse_correction_size=size)
        diagnostics=[]
        for arm,rec in case['arms'].items():
            for row in rec['history'][1:]:
                check();z=load(row);assert np.array_equal(z['truth'],truth) and np.array_equal(z['origins'],parent['origins'])
                delta=z['prediction']-before;err=before-truth
                matrix=delta.reshape(-1,12);cov=np.cov(matrix,rowvar=False)
                ev=np.linalg.eigvalsh(cov);corr=np.corrcoef(matrix,rowvar=False)
                state_rows=[dict(state=j,dates=int(len(np.unique(times[np.any(codes==j,axis=(1,2))]//86400))),
                            **entry(err[codes==j],delta[codes==j])) for j in range(6)]
                day_rows=[]
                for day in np.unique(times//86400):
                    mask=times//86400==day
                    day_rows.append(dict(utc_day=int(day),origins=int(mask.sum()),**entry(err[mask],delta[mask])))
                diagnostics.append(dict(arm=arm,epoch=row['epoch'],headline=entry(err,delta),
                    horizons=[dict(horizon=j+1,**entry(err[:,:,j],delta[:,:,j])) for j in range(12)],
                    states=state_rows,dates=day_rows,
                    correction_first_covariance_component_share=float(ev[-1]/ev.sum()),
                    mean_offdiagonal_horizon_correlation=float(corr[np.triu_indices(12,1)].mean()),
                    h1_h12_correlation=float(corr[0,11])))
        # Frozen TRAIN inference, with identical stored inputs and original target scaling.
        manifest=c.read(p['dataset_manifest'])
        limits=c.read(c.B/manifest['artifacts']['context_limits.json']['path'])['limits']
        scalers=c.read(c.B/manifest['artifacts']['scalers.json']['path'])
        center=np.array(scalers['price_center'])[0,:,0];scale=np.array(scalers['price_scale'])[0,:,0]
        th=np.array(c.read(c.B/manifest['artifacts']['state_thresholds.json']['path'])['thresholds'])
        old=c.old_cache(case['case'],'fit',np)
        memorypath=c.ART/case['case']['id']/'fit/memory.npy'
        assert c.sha(memorypath)==c.read(memorypath.parent/'receipt.json')['sha256']
        memory=np.load(memorypath,mmap_mode='r')
        base=c.base_model(case['case'],limits,torch);basefp=c.fingerprint(base)
        readers={}
        for arm,rec in case['arms'].items():
            cp=rec['selected'];assert c.sha(cp['checkpoint'])==cp['checkpoint_sha256']
            rd=Reader(case['case']['seed']);rd.load_state_dict(torch.load(cp['checkpoint'],map_location='cpu',weights_only=False)['reader'])
            readers[arm]=rd
        fingerprints={k:c.fingerprint(v) for k,v in readers.items()}
        n=len(old['y']);errors={k:np.empty((n,30,12)) for k in ('PARENT','TOKEN','SUMMARY')}
        group_grads=[np.zeros(2080) for _ in range(3)];cosines=[]
        def cosine(x,y):
            den=np.linalg.norm(x)*np.linalg.norm(y)
            return float(x@y/den) if den>1e-14 else None
        for off in range(0,n,64):
            if off%512==0:
                check();c.write(out/'progress.json',dict(at=c.now(),stage='frozen_TRAIN_replay_and_gradient',completed=off,total=n))
            ids=np.arange(off,min(off+64,n));f=c.features(old,ids,torch,np)
            m=torch.from_numpy(np.array(memory[ids],copy=True));y=torch.from_numpy(np.array(old['y'][ids],copy=True))
            with torch.no_grad():
                values=dict(PARENT=decode(base,f),SUMMARY=decode(base,f,readers['SUMMARY'],summary_memory(f)))
            token=decode(base,f,readers['TOKEN'],m);values['TOKEN']=token.detach()
            for k,v in values.items():errors[k][ids]=(v.numpy().astype(np.float64)-y.numpy().astype(np.float64))*scale[None,:,None]
            grads=[]
            for j in range(3):
                loss=torch.nn.functional.huber_loss(token[:,:,j*4:j*4+4],y[:,:,j*4:j*4+4],delta=.5)
                grad=torch.autograd.grad(loss,tuple(readers['TOKEN'].parameters()),retain_graph=j<2)
                flat=torch.cat([g.reshape(-1) for g in grad]).detach().numpy().astype(np.float64)
                assert np.isfinite(flat).all();group_grads[j]+=flat*len(ids)/n;grads.append(flat)
            cs=cosine(grads[0],grads[2])
            if cs is not None:cosines.append(cs)
        rawtruth=old['y'].astype(np.float64)*scale[None,:,None]+center[None,:,None]
        traincodes=red.codes(rawtruth,np.array(old['last']),center,scale,th)
        trainrows={}
        for k,e in errors.items():
            trainrows[k]=dict(mae=float(abs(e).mean()),rmse=float(np.sqrt((e*e).mean())),
                near_mae=float(abs(e[:,:,:4]).mean()),h12_mae=float(abs(e[:,:,11]).mean()),
                states=[dict(state=j,**red.core(e[traincodes==j])) for j in range(6)])
        check();assert c.fingerprint(base)==basefp
        assert all(c.fingerprint(v)==fingerprints[k] for k,v in readers.items())
        c.protected()
        result=dict(at=c.now(),status='completed_no_fits',protocol_sha256=c.sha(out/'PROTOCOL.json'),
            scope=proto['scope'],prediction_diagnostics=diagnostics,TRAIN_replay=trainrows,
            gradient_diagnosis=dict(objective='Normalized Huber delta0.5; entire17102TRAIN origins, selected TOKEN weights',
                aggregate_cosine=[[cosine(x,y) for y in group_grads] for x in group_grads],
                per_batch_near_far_negative_fraction=float(np.mean(np.array(cosines)<0)),
                per_batch_near_far_mean_cosine=float(np.mean(cosines)),
                interpretation='An optimization-conflict diagnostic at one fixed checkpoint. Negative gradients do not establish the cause of validation regressions or guarantee PCGrad would help.'),
            optimizer_steps=0,new_test_targets_read=False,V7_preserved=True,seconds=time.monotonic()-start)
        c.write(out/'RESULT.json',result)
        print('V26 attribution complete; no model updated.')
        print({k: {a:v[a] for a in ('mae','rmse','near_mae','h12_mae')} for k,v in trainrows.items()})
        print(result['gradient_diagnosis'])

if __name__=='__main__':main()
