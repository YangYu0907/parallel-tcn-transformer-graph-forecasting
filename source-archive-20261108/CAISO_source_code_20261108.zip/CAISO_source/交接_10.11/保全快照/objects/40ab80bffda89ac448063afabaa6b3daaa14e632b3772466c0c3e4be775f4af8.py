"""Full-direction scoring and predeclared protection screen."""
from pilot import *
def masks(d,base):
 yield 'overall',base
 yield 'near',base&(d['h']<4)
 yield 'low_volatility',base&d['low_volatility']
 for h in range(12):yield f'H{h+1}',base&(d['h']==h)
 for s in range(6):yield f'S{s}',base&(d['state']==s)
 for node in range(30):yield f'node{node}',base&(d['node']==node)
 for dr in ['low','high']:
  extreme=(d['truth']<d['threshold_lo']) if dr=='low' else (d['truth']>d['threshold_hi'])
  yield dr+'_endpoint',base&extreme
 # Observable at cutoff; separate from future-defined state labels.
 for s in np.unique(d['observable']):yield f'observed{s}',base&(d['observable']==s)
 for month in np.unique(d['days'].astype('datetime64[D]').astype('datetime64[M]')):
  yield str(month),base&(d['days'].astype('datetime64[D]').astype('datetime64[M]')==month)
def cell_losses(point,q,d):
 loss=distribution.loss_arrays(q,d);loss['ae']=abs(point-d['truth']);loss['se']=(point-d['truth'])**2
 return loss
def metric(loss,mask):
 out={k:float(v[mask].mean()) for k,v in loss.items() if k not in ['ae','se','high_probability','low_probability']}
 out['mae']=float(loss['ae'][mask].mean());out['rmse']=float(np.sqrt(loss['se'][mask].mean()))
 return out
def summarize(rows):
 out=[]
 for window in [0,1,2,3]:
  for arm in 'ABCD':
   for part in sorted({r['part'] for r in rows if r['window']==window}):
    rr=[r for r in rows if r['window']==window and r['arm']==arm and r['part']==part]
    if len(rr)!=3:continue
    assert len({r['cells'] for r in rr})==1
    metrics={k:float(np.mean([r[k] for r in rr])) for k in rr[0] if k not in ['window','seed','arm','part','cells','issue_dates']}
    out.append(dict(window=window,arm=arm,part=part,cells=rr[0]['cells'],issue_dates=rr[0]['issue_dates'],**metrics))
 return out
def bootstrap(data):
 tests=[];rng=np.random.default_rng(20261004)
 templates=[('D','A','mae'),('D','A','rmse'),('D','A','H12mae'),('D','B','mae'),('D','B','rmse'),('D','B','H12mae'),
   ('C','A','wis'),('C','A','high_brier'),('C','A','low_brier')]
 reference=data[('A',c.SEEDS[0])];group=np.column_stack([reference['window'],reference['days']//7])
 keys,gi=np.unique(group,axis=0,return_inverse=True);ng=len(keys)
 draws=[]
 for _ in range(2000):
  draw=np.concatenate([rng.choice(np.flatnonzero(keys[:,0]==w),size=int(sum(keys[:,0]==w)),replace=True) for w in [1,2,3]])
  draws.append(np.bincount(draw,minlength=ng))
 draws=np.array(draws)
 for candidate,control,endpoint in templates:
  lm='se' if endpoint=='rmse' else 'ae' if endpoint in ['mae','H12mae'] else endpoint
  mask=reference['h']==11 if endpoint=='H12mae' else np.ones(len(gi),bool)
  n=np.bincount(gi[mask],minlength=ng).astype(float);sums={}
  for arm in [candidate,control]:
   sums[arm]=np.stack([np.bincount(gi[mask],weights=data[(arm,s)][lm][mask],minlength=ng) for s in c.SEEDS])
  def stat(ss,weights):
   v=(ss@weights.T)/(n@weights.T)[None,:]
   return (np.sqrt(v) if endpoint=='rmse' else v).mean(0)
  delta=stat(sums[control],draws)-stat(sums[candidate],draws)
  observed=float((stat(sums[control],np.ones((1,ng)))-stat(sums[candidate],np.ones((1,ng))))[0])
  pv=min(1.,2*min((1+int(sum(delta<=0)))/2001,(1+int(sum(delta>=0)))/2001))
  tests.append(dict(candidate=candidate,control=control,endpoint=endpoint,benefit_difference=observed,
    interval95=np.quantile(delta,[.025,.975]).tolist(),p_unadjusted=pv,blocks=ng,issue_dates=len(np.unique(reference['days'])),
    bootstrap_replicates=2000,scope='Exploratory development, actual calendar7day buckets within window; repeated seeds not additional dates'))
 order=np.argsort([x['p_unadjusted'] for x in tests]);last=0
 for rank,i in enumerate(order):
  last=max(last,min(1.,(len(tests)-rank)*tests[i]['p_unadjusted']));tests[i]['p_holm']=last
 return tests
def main(tick=lambda **kw:guard()):
 verify();allrows=[];byseed={};qfiles={}
 for seed in c.SEEDS:
  tmp={a:[] for a in 'ABCD'}
  for window in [1,2,3]:
   for info,arms in [('old','AB'),('new','CD')]:
    tick(stage='scoring',seed=seed,window=window,info=info);d=prepare_data(seed,window,info);ev=d['evaluate']
    out=P/'fits'/f'w{window}_{seed}_{info}'
    ck=c.read(out/'COMPLETE.json');assert ck['protocol_sha256']==c.sha(P/'PROTOCOL.json')
    for arm in arms:
     path=out/f'{arm}.npz';assert c.sha(path)==ck['outputs'][str(path)];qfiles[str(path)]=c.sha(path)
     with np.load(path) as z:q=z['q'];point=z['point']
     loss=cell_losses(point,q,d)
     payload={k:v[ev] for k,v in loss.items()};payload.update({k:d[k][ev] for k in ['h','node','state','observable','low_volatility','days','origin','truth','threshold_lo','threshold_hi']})
     payload['point']=point[ev];payload['window']=np.full(ev.sum(),window)
     tmp[arm].append(payload)
     for part,m in masks(d,ev):
      if m.any():allrows.append(dict(window=window,seed=seed,arm=arm,part=part,cells=int(m.sum()),issue_dates=len(np.unique(d['days'][m])),**metric(loss,m)))
    del d;gc.collect()
  for arm in 'ABCD':
   dd={k:np.concatenate([x[k] for x in tmp[arm]]) for k in tmp[arm][0]};byseed[(arm,seed)]=dd
   for part,m in masks(dd,np.ones(len(dd['truth']),bool)):
    if m.any():allrows.append(dict(window=0,seed=seed,arm=arm,part=part,cells=int(m.sum()),issue_dates=len(np.unique(dd['days'][m])),**metric({k:v for k,v in dd.items() if k not in ['h','node','state','observable','low_volatility','days','origin','truth','threshold_lo','threshold_hi','point','window']},m)))
   save(P/'evaluated'/f'{arm}_{seed}.npz',**dd)
 summary=summarize(allrows);tests=bootstrap(byseed)
 def row(arm,part='overall',window=0):return next((r for r in summary if r['arm']==arm and r['part']==part and r['window']==window),None)
 checks=[]
 def ck(name,passed,detail=None):checks.append(dict(name=name,passed=bool(passed),detail=detail))
 a=row('A');b=row('B');d=row('D');cc=row('C')
 ck('D overallMAE improvesvsA',d['mae']<a['mae']);ck('D overallMAE improvesvsB',d['mae']<b['mae'])
 improvements=[byseed[('D',s)]['ae'].mean()<byseed[('A',s)]['ae'].mean() for s in c.SEEDS]
 ck('D at least2seeds improvevsA',sum(improvements)>=2,improvements)
 for window in [0,1,2,3]:
  for metricname in ['mae','rmse']:ck(f'D window{window} {metricname} retained',row('D',window=window)[metricname]<=row('A',window=window)[metricname]+1e-10)
 for part in ['near','low_volatility']+[f'H{i+1}' for i in range(12)]+[f'S{i}' for i in range(6)]:
  ar=row('A',part);dr=row('D',part)
  for key in ['mae','rmse']:ck(f'D {part} {key} retained',ar is not None and dr is not None and dr[key]<=ar[key]+1e-10)
  if part.startswith('S'):ck(f'{part} support>=5issue dates',ar is not None and ar['issue_dates']>=5,None if ar is None else ar['issue_dates'])
 prob=[]
 def pc(name,passed):prob.append(dict(name=name,passed=bool(passed)))
 pc('C WIS lower',cc['wis']<a['wis']);pc('C at least2seed WIS improve',sum(byseed[('C',s)]['wis'].mean()<byseed[('A',s)]['wis'].mean() for s in c.SEEDS)>=2)
 for level in [80,90]:pc(f'C {level}coverageerror retained',abs(cc[f'coverage{level}']-level/100)<=abs(a[f'coverage{level}']-level/100)+1e-10)
 for side in ['low','high']:
  for key in ['brier','logloss']:pc(f'C {side}_{key} retained',cc[f'{side}_{key}']<=a[f'{side}_{key}']+1e-10)
  rr=row('A',side+'_endpoint');pc(f'{side}eventdates>=5',rr is not None and rr['issue_dates']>=5)
 result=dict(at=c.now(),point_screen_passed=all(x['passed'] for x in checks),point_checks=checks,
   probability_screen_passed=all(x['passed'] for x in prob),probability_checks=prob,
   pooled_overall={a:row(a) for a in 'ABCD'},scope='Known CAISO development,428origins/28UTCissue dates/30nodes/12horizons/3seeds. Metrics mean of3seed metrics.',
   independent_confirmation=False,new_test_targets_read=False,V7_replaced=False,all_directions_preserved=True)
 write('ALL_RESULTS.json',allrows);write('SUMMARY.json',summary);write('STATISTICS.json',tests);write('RESULT.json',result)
 write('SCORING_BINDINGS.json',dict(inputs=qfiles,outputs={str(P/n):c.sha(P/n) for n in ['ALL_RESULTS.json','SUMMARY.json','STATISTICS.json','RESULT.json']}))
 lines=['新增灵活爬坡信息：四组匹配开发结果','同一428起点、28个UTC预测截止日期、30节点、12步；三种子指标均值。仅开发比较，V7未替换。']
 for arm in 'ABCD':
  z=row(arm);hh=row(arm,'H12');lines.append(f"{arm}: MAE={z['mae']:.6f}; RMSE={z['rmse']:.6f}; H12MAE={hh['mae']:.6f}; WIS={z['wis']:.6f}; 90%覆盖={z['coverage90']:.4%}; 宽度={z['width90']:.6f}")
 lines.extend(['点预测全部保护项通过：'+str(result['point_screen_passed']),'未通过：'+', '.join(x['name'] for x in checks if not x['passed']),
  '概率全部保护项通过：'+str(result['probability_screen_passed']),'未通过：'+', '.join(x['name'] for x in prob if not x['passed']),
  '公开来源是方向性通过组的灵活爬坡获配量；不等于CAISO物理备用裕度。历史可用性依赖完整出版/修订日志的报告级重建。',
  '本试验输出层不验证动态图优于STATIC/SELF；后续独立确认数据仍未准入。全部模型、原始方向、逐种子/状态/节点/步长结果保留。'])
 (P/'REPORT_CN.txt').write_text('\n'.join(lines),encoding='utf-8')
if __name__=='__main__':
 with c.numeric('Finite four-arm score'):main()
