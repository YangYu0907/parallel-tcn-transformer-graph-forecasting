"""Isolated conditional-distribution gate; never overwrites a forecasting backbone.

The forest-neighbour distribution follows the QRF idea (Meinshausen, 2006).
Date weighting, support checks and the two-loss path decision are our adaptation.
Estimated risk constraints are NOT guarantees about future realized errors.
No experiment, file reading or training runs at import time.
"""
from dataclasses import dataclass
import numpy as np


@dataclass(frozen=True)
class Settings:
    trees: int = 32
    depth: int = 4
    minimum_leaf_rows: int = 100
    minimum_dates: int = 10
    minimum_effective_dates: float = 5.0
    maximum_date_mass: float = 0.25
    seed: int = 20260813


def feature_matrix(context, duration, horizon, probabilities, v7, full, scale,
                   renewable=None):
    """One row per origin/node/horizon; only explicit ex-ante arguments.

    Context includes the already-frozen node and historical price descriptors.
    scale comes from TRAIN, not evaluation targets. Renewable columns have their
    own TRAIN-only normalizer and source-publication admission upstream.
    """
    context = np.asarray(context, dtype=float)
    arrays = [np.asarray(a, dtype=float).reshape(-1) for a in
              (duration, horizon, v7, full, scale)]
    duration, horizon, v7, full, scale = arrays
    n = len(v7)
    if context.ndim != 2 or any(len(a) != n for a in arrays) or len(context) != n:
        raise ValueError('Feature alignment')
    if np.any(scale <= 0) or np.any(duration < 0) or np.any((horizon < 1) | (horizon > 12)):
        raise ValueError('Invalid scale/duration/horizon')
    probs = np.asarray(probabilities, dtype=float)
    if probs.shape != (n, 3) or np.any(probs < 0) or not np.allclose(probs.sum(1), 1):
        raise ValueError('Expected three frozen regime probabilities')
    parts = [context, np.log1p(duration)[:, None], (horizon / 12)[:, None], probs,
             (v7 / scale)[:, None], (full / scale)[:, None], ((full-v7) / scale)[:, None]]
    if renewable is not None:
        renewable = np.asarray(renewable, dtype=float)
        if renewable.shape != (n, 5):
            raise ValueError('Exactly five registered renewable fields required')
        parts.append(renewable)
    x = np.column_stack(parts)
    if not np.isfinite(x).all():
        raise ValueError('Nonfinite causal feature')
    return x


def chronological_mask(issue, target_end, available, model_fit_end, cutoff,
                       purge_seconds=2*86400):
    """Each stored prediction must have been made by an earlier-only model.

    available includes the maximum label release time. This function is used
    for fitting admission only, never as a feature at prediction time.
    """
    issue, target_end, available, model_fit_end = np.broadcast_arrays(
        issue, target_end, available, model_fit_end)
    return ((model_fit_end < issue) & (target_end < cutoff-purge_seconds)
            & (available < cutoff) & (issue < target_end))


def distribution_decision(residual, weights, delta):
    """Choose z=g*delta toward FULL from V7; residual is y-V7 in TRAIN units.

    Minimize estimated squared risk on the path with estimated absolute risk
    no greater than at V7. Convexity gives a single feasible interval containing
    zero. Bisection solves its boundary; it is not a hyperparameter grid.
    """
    residual = np.asarray(residual, dtype=float)
    w = np.asarray(weights, dtype=float)
    if (residual.ndim != 1 or residual.shape != w.shape or not len(w)
            or np.any(w < 0) or not np.isfinite(residual).all()
            or not np.isfinite(w).all() or not np.isfinite(delta) or w.sum() <= 0):
        raise ValueError('Invalid conditional distribution')
    w = w / w.sum()
    if delta == 0:
        return 0.0, 0.0, 0.0
    mean = float(w @ residual)
    g = float(np.clip(mean / delta, 0, 1))
    base_mae = float(w @ abs(residual))

    def change(a):
        return float(w @ abs(residual-a*delta)) - base_mae

    if change(g) > 0:
        lo, hi = 0.0, g
        for _ in range(52):
            mid = (lo + hi) / 2
            if change(mid) <= 0:
                lo = mid
            else:
                hi = mid
        g = lo
    z = g * delta
    mae_change = change(g)
    mse_change = z*z - 2*z*mean
    # Floating point dust should not cause a correction when risks conflict.
    if abs(z) <= 1e-10 or mae_change > 1e-10 or mse_change >= -1e-12:
        return 0.0, 0.0, 0.0
    return g, mae_change, mse_change


class ConditionalRiskGate:
    def __init__(self, settings=Settings()):
        self.settings = settings

    def fit(self, x, residual, issue, target_end, available, model_fit_end,
            cutoff, *, confirmation_admitted=False, synthetic_only=False):
        if not confirmation_admitted and not synthetic_only:
            raise RuntimeError('No research fit before independent-source admission')
        from sklearn.ensemble import RandomForestRegressor
        x, residual = np.asarray(x, float), np.asarray(residual, float)
        if x.ndim != 2 or residual.shape != (len(x),) or not np.isfinite(x).all() or not np.isfinite(residual).all():
            raise ValueError('Training dimensions/values')
        eligible = chronological_mask(issue, target_end, available, model_fit_end, cutoff)
        if eligible.shape != residual.shape or not eligible.all():
            raise ValueError('In-sample backbone prediction, unripe label or purge violation')
        self.days = np.asarray(issue, dtype=np.int64) // 86400
        _, inv, counts = np.unique(self.days, return_inverse=True, return_counts=True)
        if len(counts) < self.settings.minimum_dates:
            raise ValueError('Insufficient distinct historical dates')
        self.base_weight = 1.0 / counts[inv]
        self.residual = residual.copy()
        self.forest = RandomForestRegressor(
            n_estimators=self.settings.trees, max_depth=self.settings.depth,
            min_samples_leaf=self.settings.minimum_leaf_rows, max_features=0.5,
            bootstrap=False, n_jobs=1, random_state=self.settings.seed)
        self.forest.fit(x, residual, sample_weight=self.base_weight)
        leaf = self.forest.apply(x)
        self.members = [{int(k): np.flatnonzero(leaf[:, j] == k)
                         for k in np.unique(leaf[:, j])} for j in range(leaf.shape[1])]
        self.synthetic_only = synthetic_only
        return self

    def distribution(self, row):
        leaf = self.forest.apply(np.asarray(row, float).reshape(1, -1))[0]
        weight = np.zeros(len(self.residual))
        for j, k in enumerate(leaf):
            ix = self.members[j][int(k)]
            local = self.base_weight[ix]
            weight[ix] += local / local.sum() / len(leaf)
        ix = np.flatnonzero(weight > 0)
        _, inv = np.unique(self.days[ix], return_inverse=True)
        date_mass = np.bincount(inv, weights=weight[ix])
        supported = (len(date_mass) >= self.settings.minimum_dates
                     and 1.0 / (date_mass @ date_mass) >= self.settings.minimum_effective_dates
                     and date_mass.max() <= self.settings.maximum_date_mass)
        return self.residual[ix], weight[ix], supported

    def predict(self, x, v7, full, scale, observed_extreme, protected_lowvol):
        x = np.asarray(x, dtype=float)
        v7, full, scale = [np.asarray(a, float) for a in (v7, full, scale)]
        extreme, lowvol = [np.asarray(a, bool) for a in (observed_extreme, protected_lowvol)]
        if (x.ndim != 2 or any(a.shape != (len(x),) for a in (v7, full, scale, extreme, lowvol))
                or not np.isfinite(x).all() or not np.isfinite(v7).all()
                or not np.isfinite(full).all() or not np.isfinite(scale).all() or np.any(scale <= 0)):
            raise ValueError('Prediction alignment/values')
        out = v7.copy()
        weights = np.zeros(len(v7))
        estimated_changes = np.zeros((len(v7), 2))
        for i in np.flatnonzero(extreme & ~lowvol & (v7 != full)):
            residual, w, supported = self.distribution(x[i])
            if not supported:
                continue
            g, da, ds = distribution_decision(residual, w, (full[i]-v7[i])/scale[i])
            if g:
                out[i] = v7[i] + g*(full[i]-v7[i])
                weights[i] = g
                estimated_changes[i] = da*scale[i], ds*scale[i]**2
        return out, weights, estimated_changes
