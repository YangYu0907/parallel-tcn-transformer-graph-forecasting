"""Once-frozen European chronological inference; never computes target errors."""
from pathlib import Path
import sys,os,time,uuid
sys.path.insert(0,str(Path(__file__).resolve().parents[1]))
import common as c
from guarded_io import EVAL,verify_freeze,PriceArchive,dates,verify_commit

def main():
    out=EVAL/'test_predictions';out.mkdir(exist_ok=True)
    with c.exclusive('European_frozen_test_inference'):
        f=verify_freeze();digest=c.sha(EVAL/'EUROPE_TEST_FREEZE.json')
        np,torch,limiter=c.runtime(True)
        from europe_model import build
        d=np.load(c.HERE/'data/train_valid.npz',allow_pickle=False)
        days=dates('2016-01-01','2016-12-31');reader=PriceArchive(f['source_receipts'])
        # Inputs are decoded only through their own historical cutoff, after freeze.
        histories=np.stack([reader.history(day,np) for day in days])
        x=((histories-d['mean'])/d['std']).astype(np.float32)
        c.write(out/'INPUT_ACCESS_RECEIPT.json',dict(at=c.now(),freeze_sha256=digest,accesses=reader.accesses,
          input_shape=list(x.shape),target_scores_computed=False,heldout_prices_decoded_as_history=True,
          note='Past test-day prices serve as inputs at later origins; no target error or model selection is performed.'))
        committed={}
        for case in f['neural_cases']+f['deterministic_cases']:
            name=case['id'];path=out/(name+'.npz');receipt=out/(name+'.json')
            c.guard()
            if receipt.exists():
                r=c.read(receipt);c.need(r['freeze_sha256']==digest and c.sha(path)==r['sha256'],'Resume prediction identity');committed[name]=r;continue
            c.need(not path.exists(),'Uncommitted prediction artifact: preserve and inspect before retry')
            started=time.perf_counter()
            if case['kind']=='neural':
                model=build(case['model'],case['seed']);ck=torch.load(case['checkpoint'],map_location='cpu',weights_only=False);model.load_state_dict(ck['model']);model.eval();parts=[]
                c.need(not model.training,'Model not in eval mode')
                before={k:v.detach().clone() for k,v in model.state_dict().items()}
                with torch.inference_mode():
                    for i in range(0,len(x),16):c.guard();parts.append(model(torch.from_numpy(x[i:i+16])).numpy())
                pred=np.concatenate(parts)*d['std']+d['mean']
                c.need(all(torch.equal(v,before[k]) for k,v in model.state_dict().items()),'Inference modified state')
                del model,ck,before,parts
            elif case['id']=='PreviousDay':pred=histories[:,-24:,:].copy()
            elif case['id']=='PreviousWeek':pred=histories[:,:24,:].copy()
            elif case['id']=='LASSO_AR':
                params=np.load(case['artifact'],allow_pickle=False)
                pred=(x.reshape(len(x),-1)@params['coef'].T+params['intercept']).reshape(len(x),24,3)*d['std']+d['mean']
            else:raise RuntimeError('Unregistered prediction case')
            c.need(pred.shape==(366,24,3) and np.isfinite(pred).all(),'Invalid frozen predictions')
            tmp=out/('t_'+uuid.uuid4().hex+'.tmp')
            with tmp.open('xb') as handle:np.savez_compressed(handle,prediction=pred,delivery_days=np.asarray(f['delivery_days']))
            os.replace(tmp,path)
            r=dict(id=name,path=str(path),sha256=c.sha(path),freeze_sha256=digest,at=c.now(),elapsed_seconds=time.perf_counter()-started,
              target_scores_computed=False,shape=list(pred.shape));c.write(receipt,r);committed[name]=r
            c.write(EVAL/'inference_status.json',dict(at=c.now(),completed=len(committed),total=30,last_case=name,pid=os.getpid(),target_scores_computed=False))
            print('Committed '+name,flush=True)
        commit=dict(status='all_predictions_committed_before_scoring',at=c.now(),freeze_sha256=digest,predictions=committed,
          target_scores_computed=False,heldout_prices_decoded_as_history=True,n_models=30)
        verify_commit(commit,f);c.write(EVAL/'ALL_PREDICTIONS_COMMITTED.json',commit)
        print('All 30 frozen prediction artifacts committed; scoring targets unopened by this worker.',flush=True)

if __name__=='__main__':main()
