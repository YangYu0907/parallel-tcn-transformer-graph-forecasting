"""Bounded, causal competence correction; old experiments remain immutable."""
from pathlib import Path
import sys, os, json, pickle, uuid, time, shutil
HERE=Path(__file__).resolve().parent
B=HERE.parent
T=B/'context_expert_v1_20260929'
V2=B/'adaptive_experts_v2_20260929'
ART=Path('C:/Users/于阳/CAISO_temporary_storage/adaptive_experts_v3_20260929')
sys.path.insert(1,str(T))
import gate
_start=None
_used=0.

def atomic(path,writer):
    path=Path(path)
    if not any(path.resolve().is_relative_to(root.resolve()) for root in (HERE,ART)):
        raise ValueError('Output outside isolated V3 roots')
    path.parent.mkdir(parents=True,exist_ok=True)
    if shutil.disk_usage(path.parent).free<32*1024**2:raise OSError('Output disk below 32MiB safety floor')
    tmp=path.with_name('.'+path.name+'.'+uuid.uuid4().hex+'.tmp')
    with tmp.open('xb') as f:writer(f);f.flush();os.fsync(f.fileno())
    os.replace(tmp,path)

def write(path,value):
    raw=json.dumps(value,ensure_ascii=False,indent=2,allow_nan=False).encode('utf-8')
    atomic(path,lambda f:f.write(raw))
def save(path,**arrays):
    import numpy as np
    atomic(path,lambda f:np.savez(f,**arrays))
def dump(path,value):atomic(path,lambda f:pickle.dump(value,f,protocol=5))
def load(path):
    with Path(path).open('rb') as f:return pickle.load(f)
def status(**kw):write(HERE/'queue/status.json',dict(at=gate.now(),pid=os.getpid(),**kw))

def tick(**kw):
    for d in (HERE,HERE/'queue'):
        for n in ('STOP_REQUESTED','STOP_REQUESTED.json'):
            if (d/n).exists():raise InterruptedError('User stop: '+str(d/n))
    gate.guard()
    if _start is not None:
        used=_used+time.monotonic()-_start
        write(HERE/'queue/budget.json',dict(used_seconds=used,maximum_seconds=3600,at=gate.now()))
        if used>=3600:raise TimeoutError('Fixed one-hour numerical development budget')
    if kw:status(event='step_process_started',**kw)

def start_budget():
    global _start,_used
    _used=gate.read(HERE/'queue/budget.json')['used_seconds'] if (HERE/'queue/budget.json').exists() else 0.
    _start=time.monotonic()

def verify():
    for path,digest in gate.read(HERE/'EXECUTION_SEAL.json')['bindings'].items():
        assert gate.sha(path)==digest,path
    assert gate.read(HERE/'QA.json')['status']=='passed'
    tick()

def paired_gain(pred,truth,scale):
    import numpy as np
    e=pred-truth[...,None]
    return np.stack([np.abs(e[...,0,None])-np.abs(e[...,1:]),
        (e[...,0,None]**2-e[...,1:]**2)/scale],-1)

class Calibration:
    """Date-grouped error correction. Margin is heuristic, not a coverage guarantee."""
    def __init__(self):self.days={};self.applied=set()
    def observe(self,key,issued,ready,now,regime,h,residual):
        import numpy as np
        assert ready<=now and issued<now
        if key in self.applied:raise ValueError('Duplicate feedback')
        self.applied.add(key)
        day=int(issued)//86400
        if day not in self.days:self.days[day]=(np.zeros((9,3,2)),np.zeros(9,np.int64))
        sums,counts=self.days[day]
        for r in range(3):
            mask=regime==r;group=r*3+h//4
            sums[group]+=residual[mask].sum(0);counts[group]+=int(mask.sum())
    def correction(self,now):
        import numpy as np
        mu=np.zeros((9,3,2));margin=np.zeros_like(mu);support=np.zeros(9,np.int64)
        for group in range(9):
            days=[d for d in sorted(self.days) if self.days[d][1][group]>0][-7:]
            support[group]=len(days)
            if len(days)<3:continue
            values=np.stack([self.days[d][0][group]/self.days[d][1][group] for d in days])
            ages=np.maximum(0,now/86400.-np.array(days)-1.)
            w=np.exp(-np.log(2)*ages/7.);w/=w.sum()
            mu[group]=(values*w[:,None,None]).sum(0)
            eff=1./np.square(w).sum()
            variance=(w[:,None,None]*(values-mu[group])**2).sum(0)/(1-np.square(w).sum())
            margin[group]=1.64*np.sqrt(variance/eff)
        return mu,margin,support

def weights(gain,regime,cal,temperature,allowed,now,dual=True):
    import numpy as np
    mu,margin,n=cal.correction(now)
    groups=regime[:,None]*3+np.arange(12)[None,:]//4
    lower=gain+mu[groups]-margin[groups]
    ratios=np.maximum(lower,0)/temperature[None,:,None,:]
    score=np.minimum(ratios[...,0],ratios[...,1]) if dual else ratios[...,0]
    support=allowed[:,None]&(n[groups]>=3)
    score=np.where(support[...,None],np.clip(score,0,1),0)
    w=np.concatenate([np.ones((30,12,1)),score],-1)
    w/=w.sum(-1,keepdims=True)
    return w,lower,support

def fit(path,X,y,seed):
    from sklearn.ensemble import HistGradientBoostingRegressor
    ident=dict(protocol=gate.sha(HERE/'PROTOCOL.json'),seed=int(seed),rows=len(y),cols=X.shape[1])
    if path.exists():
        obj=load(path);assert obj['identity']==ident;model=obj['model']
    else:model=HistGradientBoostingRegressor(loss='squared_error',learning_rate=.05,
        max_iter=10,max_leaf_nodes=7,min_samples_leaf=100,l2_regularization=1.,
        early_stopping=False,warm_start=True,random_state=int(seed))
    for it in range((getattr(model,'n_iter_',0)//10+1)*10,41,10):
        tick(stage='paired_gain_fit',case=path.stem,iteration=it,total=40)
        model.set_params(max_iter=it);model.fit(X,y);dump(path,dict(identity=ident,model=model))
    return model
