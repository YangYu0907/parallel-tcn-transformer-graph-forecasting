"""Bounded residual-distribution experiment. Only previously inspected development caches."""
from revision_common import *
import numpy as np, csv, pickle, gc
Q=np.array([.05,.1,.5,.9,.95]); ALPHAS=[.2,.1]
FIELDS=[0,8,9,10,11,12,13,14,15,16,19,20,21,22,23,24,25,26,27,28]
SCALER=B/'dataset/compiled_train_june/build_16b2377c02a74effb6983991b6bed066/scalers.json'
E=B/'energy_confirmation_v1_20260926'
_start=None;_used=0
def tick(**kw):
 global _start,_used
 guard()
 if _start is not None:
  used=_used+time.monotonic()-_start
  write(ROOT/'PROBABILITY_BUDGET.json',dict(used_seconds=used,maximum_seconds=3600,at=now()))
  if used>=3600:raise TimeoutError('Fixed one-hour numerical budget exhausted; no automatic extension')
 if kw:progress(**kw)
def dump(path,obj):
 path=Path(path);path.parent.mkdir(parents=True,exist_ok=True)
 tmp=path.with_suffix('.tmp')
 with tmp.open('wb') as f:pickle.dump(obj,f,protocol=5)
 os.replace(tmp,path)
def dates(cut):return np.asarray(cut).astype('datetime64[s]').astype('datetime64[D]')
def ca_features(last,point,experts,center,scale):
 n,l,h=point.shape
 node=np.tile(np.repeat(np.eye(l,dtype=np.float32),h,axis=0),(n,1))
 hist=np.repeat(last[:,:,FIELDS].reshape(-1,len(FIELDS)),h,axis=0)
 p=(point-center[None,:,None])/scale[None,:,None]
 spread=(experts.max(-1)-experts.min(-1))/scale[None,:,None]
 sd=experts.std(-1)/scale[None,:,None]
 full=(experts[...,0]-center[None,:,None])/scale[None,:,None]
 return np.column_stack([hist,p.ravel(),full.ravel(),spread.ravel(),sd.ravel(),np.tile((np.arange(h)+1)/h,n*l),node]).astype(np.float32)
def eu_features(raw,origins,point,center,scale,timestamps):
 n,l,h=point.shape;rows=[]
 for idx in origins:
  x=(raw[idx-168:idx]-center)/scale
  # Lag features and statistics use only already-available delivery-day prices.
  rows.append(np.column_stack([x[-1],x[-24],x[-48],x[-168],x[-24:].mean(0),x.mean(0),x[-24:].std(0),x.std(0)]))
 hist=np.repeat(np.stack(rows).reshape(-1,8),h,axis=0)
 target_days=timestamps[origins].astype('datetime64[D]').astype(int)
 dow=(target_days+3)%7
 calendar=np.repeat(np.column_stack([np.sin(2*np.pi*dow/7),np.cos(2*np.pi*dow/7)]),l*h,axis=0)
 node=np.tile(np.repeat(np.eye(l,dtype=np.float32),h,axis=0),(n,1))
 return np.column_stack([hist,((point-center[None,:,None])/scale[None,:,None]).ravel(),np.tile((np.arange(h)+1)/h,n*l),calendar,node]).astype(np.float32)
def source_paths():
 paths=[SCALER,B/'adaptive_experts_v4_20260929/FOLDS.json',T/'adaptive_experts_v4_20260929/panel.npz',E/'data/train_valid.npz']
 for s in SEEDS:
  paths.extend([T/'adaptive_experts_v4_20260929/experts'/f'{s}.npz',T/'spike_specialist_v7_20260930/audited'/f'{s}.npz',T/'spike_specialist_v7_20260930/predictions'/f'{s}.npz',E/'runs'/f'FULL_{s}_0.001/validation_predictions.npz'])
 return paths
def register_details():
 assert not (ROOT/'probability_models').exists(),'Registration must precede any model fit'
 write(ROOT/'PROBABILITY_IMPLEMENTATION_ADDENDUM.json',dict(at=now(),parent_protocol_sha=sha(ROOT/'PROTOCOL.json'),changes=[
  'Add HIST_CAL: historical residual quantiles receive the same held-calibration procedure as CQR_CAL. Compare the candidate with both HIST and HIST_CAL, avoiding a calibration-budget advantage.',
  'Sort five conditional quantiles before interval scoring. Apply nonnegative interval expansion separately at80/90%; enforce90% endpoints enclosing80% endpoints. Median unchanged by interval calibration.',
  'Warm-start checkpoints every20 of fixed60 boosting iterations; unchanged hyperparameters. No performance-driven tuning.',
  'CAISO field indices fixed before fit, with training scaler and location one-hot. Europe history-only lag/statistic features.'],
  ca_feature_fields=FIELDS,point_values='Exact copies of retained V7 for CAISO and FULL for Europe; distribution median is a separate output',
  primary_comparison='CQR_CAL versus HIST_CAL; also retain HIST and CQR_RAW',
  promotion='No replacement or independent-confirmation claim from this development study',
  quantile_postprocess='sort; then interval expansion; then90%-encloses80% projection'))
 write(ROOT/'PROBABILITY_SOURCE_BINDINGS.json',{str(p):sha(p) for p in source_paths()})
def load_data(task,seed):
 if task=='CAISO':
  with np.load(T/'adaptive_experts_v4_20260929/panel.npz') as z:
   panel={k:z[k] for k in ['origins','cutoff','last','observable_regime','available','metadata_feedback_available','raw_last']}
  with np.load(T/'spike_specialist_v7_20260930/predictions'/f'{seed}.npz') as z:ids=z['eval_indices']
  with np.load(T/'spike_specialist_v7_20260930/audited'/f'{seed}.npz') as z:
   y=z['truth'];p=z['CONTEXT'];st=z['states'];orig=z['origins']
  with np.load(T/'adaptive_experts_v4_20260929/experts'/f'{seed}.npz') as z:
   assert np.array_equal(z['origins'],panel['origins']);ex=z['experts'][ids]
  assert np.array_equal(panel['origins'][ids],orig)
  assert np.array_equal(panel['available'],panel['metadata_feedback_available'])
  sc=read(SCALER);center=np.array(sc['price_center'])[0,:,0];scale=np.array(sc['price_scale'])[0,:,0]
  assert np.max(abs(panel['last'][...,0]*scale+center-panel['raw_last']))<.001
  X=ca_features(panel['last'][ids],p,ex,center,scale)
  folds=read(B/'adaptive_experts_v4_20260929/FOLDS.json');role=np.full(len(ids),-1)
  for k,f in enumerate(folds):role[np.isin(ids,f['evaluation'])]=k
  assert set(role)=={0,1,2}
  cut=panel['cutoff'][ids];avail=panel['available'][ids]
  masks=[np.broadcast_to((role==k)[:,None,None],y.shape).copy() for k in range(3)]
  for k in [0,1]:masks[k]&=avail[:,None,:]<cut[role==k+1].min()
  for k in [0,1]:assert avail[np.any(masks[k],axis=1)].max()<cut[role==k+1].min()
  obs=np.broadcast_to(panel['observable_regime'][ids,:,None],y.shape)
  feature_names=[f'last_{j}' for j in FIELDS]+['frozen_point','FULL','expert_range','expert_std','horizon']+[f'node_{j}' for j in range(30)]
 else:
  with np.load(E/'data/train_valid.npz') as z:
   raw=z['raw'];orig=z['valid'];center=z['mean'];scale=z['std'];timestamps=z['timestamps'];threshold=z['state_thresholds']
  with np.load(E/'runs'/f'FULL_{seed}_0.001/validation_predictions.npz') as z:
   assert np.array_equal(orig,z['origins']);p=z['prediction'].transpose(0,2,1)
  y=np.stack([raw[i:i+24] for i in orig]).transpose(0,2,1)
  X=eu_features(raw,orig,p,center,scale,timestamps)
  day=timestamps[orig].astype('datetime64[D]');role=np.where(day<np.datetime64('2015-07-01'),0,np.where(day<np.datetime64('2015-10-01'),1,2))
  masks=[np.broadcast_to((role==k)[:,None,None],y.shape).copy() for k in range(3)]
  for k in [0,1]:masks[k][np.flatnonzero(role==k)[-1]]=False
  cut=(day.astype('datetime64[s]').astype(np.int64)-86400+11*3600)
  st=np.where(y<threshold[0][None,:,None],0,np.where(y>threshold[1][None,:,None],2,1))
  last=raw[orig-1];obs=np.where(last<threshold[0],0,np.where(last>threshold[1],2,1));obs=np.broadcast_to(obs[:,:,None],y.shape)
  feature_names=['lag1','lag24','lag48','lag168','mean24','mean168','std24','std168','frozen_point','horizon','dow_sin','dow_cos']+[f'market_{j}' for j in range(3)]
 assert X.shape[0]==y.size and X.shape[1]==len(feature_names) and np.isfinite(X).all()
 assert all(m.any() for m in masks) and not np.any(masks[0]&masks[1]) and not np.any(masks[1]&masks[2])
 residual=(y-p)/scale[None,:,None]
 return dict(X=X,y=y,point=p,residual=residual,scale=scale,origin=orig,cutoff=cut,role=role,masks=masks,state=st,observable=obs,features=feature_names)
def hist_quantiles(r,mask):
 l,h=r.shape[1:];a=np.empty((l,h,5))
 for i in range(l):
  for j in range(h):a[i,j]=np.quantile(r[mask[:,i,j],i,j],Q)
 return np.broadcast_to(a,(len(r),l,h,5)).copy()
def calibrate(q,r,mask):
 out=q.copy();values=np.empty((q.shape[2],2));counts=np.zeros_like(values,dtype=int)
 for c,(alpha,lo,hi) in enumerate([(.2,1,3),(.1,0,4)]):
  for h in range(q.shape[2]):
   scores=np.maximum(q[:,:,h,lo]-r[:,:,h],r[:,:,h]-q[:,:,h,hi])[mask[:,:,h]]
   n=len(scores);assert n>0;k=min(n,max(1,int(np.ceil((n+1)*(1-alpha)))))
   v=max(0.,float(np.partition(scores,k-1)[k-1]));values[h,c]=v;counts[h,c]=n
   out[:,:,h,lo]-=v;out[:,:,h,hi]+=v
 out[...,0]=np.minimum(out[...,0],out[...,1]);out[...,4]=np.maximum(out[...,4],out[...,3])
 return out,values,counts
def metric_arrays(y,q):
 e=y[...,None]-q;pin=np.maximum(Q*e,(Q-1)*e)
 result={'pinball':pin.mean(-1)};wis=.5*abs(y-q[...,2])
 for level,alpha,lo,hi in [(80,.2,1,3),(90,.1,0,4)]:
  width=q[...,hi]-q[...,lo];score=width+2/alpha*np.maximum(q[...,lo]-y,0)+2/alpha*np.maximum(y-q[...,hi],0)
  result[f'coverage{level}']=((y>=q[...,lo])&(y<=q[...,hi])).astype(float)
  result[f'width{level}']=width;result[f'interval_score{level}']=score;wis+=alpha/2*score
 result['wis']=wis/2.5
 return result
def train_raw(task,seed,d):
 from sklearn.ensemble import HistGradientBoostingRegressor
 masks=d['masks'];Xfit=d['X'][masks[0].ravel()];yfit=d['residual'][masks[0]]
 a=np.empty((*d['y'].shape,5))
 for j,q in enumerate(Q):
  path=ROOT/'probability_models'/task/f'{seed}_{q}.pkl'
  if path.exists():
   with path.open('rb') as f:model=pickle.load(f)
  else:model=HistGradientBoostingRegressor(loss='quantile',quantile=float(q),max_iter=20,max_leaf_nodes=7,min_samples_leaf=100,learning_rate=.05,l2_regularization=1,early_stopping=False,warm_start=True,random_state=seed)
  done=getattr(model,'n_iter_',0)
  for end in [20,40,60]:
   if done>=end:continue
   tick(stage='quantile_training',task=task,seed=seed,quantile=float(q),target_iterations=end)
   model.set_params(max_iter=end);model.fit(Xfit,yfit);dump(path,model);done=end
   tick(stage='quantile_checkpoint',task=task,seed=seed,quantile=float(q),iterations=end)
  a[...,j]=model.predict(d['X']).reshape(d['y'].shape)
  del model;gc.collect()
 return np.sort(a,axis=-1)
def save_and_score(task,seed,d,rawq):
 hist=hist_quantiles(d['residual'],d['masks'][0]);hq,hv,hc=calibrate(hist,d['residual'],d['masks'][1]);cq,cv,cc=calibrate(rawq,d['residual'],d['masks'][1])
 arms={'HIST':hist,'HIST_CAL':hq,'CQR_RAW':rawq,'CQR_CAL':cq};ev=d['role']==2;rows=[];point=d['point'][ev];y=d['y'][ev]
 payload=dict(truth=y,point=point,origin=d['origin'][ev],cutoff=d['cutoff'][ev],states=d['state'][ev],observable=d['observable'][ev],quantile_levels=Q)
 for name,q in arms.items():
  qq=point[...,None]+q[ev]*d['scale'][None,:,None,None]
  assert np.all(np.diff(qq,axis=-1)>=-1e-12) and np.isfinite(qq).all()
  payload[name]=qq;ma=metric_arrays(y,qq)
  partitions=[('overall','all',np.ones(y.shape,bool))]
  for i in range(y.shape[1]):partitions.append(('location',str(i),np.broadcast_to((np.arange(y.shape[1])==i)[None,:,None],y.shape)))
  for h in range(y.shape[2]):partitions.append(('horizon',str(h+1),np.broadcast_to((np.arange(y.shape[2])==h)[None,None,:],y.shape)))
  for k in np.unique(d['state'][ev]):partitions.append(('realized_state',str(k),d['state'][ev]==k))
  for k in np.unique(d['observable'][ev]):partitions.append(('observable_regime',str(k),d['observable'][ev]==k))
  for sign,mask in [('negative',y<0),('nonnegative',y>=0)]:partitions.append(('actual_price_sign',sign,mask))
  for kind,value,m in partitions:
   if m.any():rows.append(dict(task=task,seed=seed,model=name,partition=kind,value=value,cells=int(m.sum()),dates=int(len(np.unique(dates(d['cutoff'][ev])[m.any((1,2))]))),**{k:float(v[m].mean()) for k,v in ma.items()}))
 npz_save(ROOT/'probability_predictions'/task/f'{seed}.npz',**payload)
 npz_save(ROOT/'probability_calibration'/task/f'{seed}.npz',HIST_expansion=hv,HIST_counts=hc,CQR_expansion=cv,CQR_counts=cc,scale=d['scale'])
 write(ROOT/'probability_splits'/task/f'{seed}.json',dict(at=now(),features=d['features'],partitions=[dict(role=['fit','calibration','forward_development'][k],origins=int(np.any(m,(1,2)).sum()),cells=int(m.sum()),dates=int(len(np.unique(dates(d['cutoff'])[np.any(m,(1,2))]))),first_issue=int(d['cutoff'][np.any(m,(1,2))].min()),last_issue=int(d['cutoff'][np.any(m,(1,2))].max())) for k,m in enumerate(d['masks'])],point_preserved_exact=bool(np.array_equal(point,d['point'][ev])),scope='Previously inspected development; not independent confirmation'))
 write(ROOT/'probability_scores'/task/f'{seed}.json',rows)
 return rows
def aggregate():
 rows=[]
 for task in ['CAISO','Europe']:
  for seed in SEEDS:rows+=read(ROOT/'probability_scores'/task/f'{seed}.json')
 with (ROOT/'PROBABILITY_RESULTS.csv').open('w',encoding='utf-8-sig',newline='') as f:
  w=csv.DictWriter(f,fieldnames=list(rows[0]));w.writeheader();w.writerows(rows)
 summary={}
 for task in ['CAISO','Europe']:
  rr=[r for r in rows if r['task']==task and r['partition']=='overall'];s={}
  for model in ['HIST','HIST_CAL','CQR_RAW','CQR_CAL']:
   s[model]={key:float(np.mean([r[key] for r in rr if r['model']==model])) for key in ['wis','pinball','coverage80','width80','coverage90','width90']}
  improvements=[1-next(r['wis'] for r in rr if r['seed']==seed and r['model']=='CQR_CAL')/next(r['wis'] for r in rr if r['seed']==seed and r['model']=='HIST_CAL') for seed in SEEDS]
  summary[task]=dict(scores=s,matched_calibration_WIS_improvement_pct=100*(1-s['CQR_CAL']['wis']/s['HIST_CAL']['wis']),seed_improvements=improvements,screen_pass=bool(s['CQR_CAL']['wis']<s['HIST_CAL']['wis'] and sum(x>0 for x in improvements)>=2),point_preserved=True)
 write(ROOT/'PROBABILITY_RESULT.json',dict(at=now(),summary=summary,scope='Development only; CAISO194 origins, Europe2015Q4. All states and directions retained.',independent_confirmation=False,automatic_replacement=False,budget=read(ROOT/'PROBABILITY_BUDGET.json')))
def main():
 global _start,_used
 with numeric('reviewer revision fixed residual quantile development'):
  verify_protected();assert read(ROOT/'PROBABILITY_QA.json')['status']=='passed'
  for p,h in read(ROOT/'PROBABILITY_SOURCE_BINDINGS.json').items():assert sha(p)==h,p
  _used=read(ROOT/'PROBABILITY_BUDGET.json')['used_seconds'] if (ROOT/'PROBABILITY_BUDGET.json').exists() else 0;_start=time.monotonic()
  for task in ['CAISO','Europe']:
   for seed in SEEDS:
    if (ROOT/'probability_scores'/task/f'{seed}.json').exists():continue
    tick(stage='loading_development',task=task,seed=seed);d=load_data(task,seed)
    rawq=train_raw(task,seed,d);save_and_score(task,seed,d,rawq);del d,rawq;gc.collect();tick(stage='seed_completed',task=task,seed=seed)
  aggregate();verify_protected();tick(stage='probability_complete',new_test_targets_read=False)
if __name__=='__main__':
 try:main()
 except Exception as e:
  progress(stage='probability_blocked',error=repr(e),resume_from_checkpoints=True);raise
