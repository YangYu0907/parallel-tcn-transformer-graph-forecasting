"""Separate SAX value replay plus independent publication CSV replay; same operator."""
import zipfile,csv,io,xml.sax
from datetime import datetime,timedelta
from zoneinfo import ZoneInfo
from decimal import Decimal
from common import *
def stamp(x):return datetime.fromisoformat(x).timestamp()
class Reader(xml.sax.ContentHandler):
 def __init__(self,nodes):
  super().__init__();self.nodes=set(nodes);self.row=None;self.header={};self.report={};self.bucket=None;self.text=[];self.values={};self.count=0
 def startElement(self,name,attrs):
  name=name.split(':')[-1];self.text=[]
  if name in ['MessageHeader','REPORT_HEADER','REPORT_DATA']:self.bucket=name;self.row={}
 def characters(self,value):self.text.append(value)
 def endElement(self,name):
  name=name.split(':')[-1];value=''.join(self.text).strip()
  if self.bucket and name not in ['MessageHeader','REPORT_HEADER','REPORT_DATA']:self.row[name]=value
  if name=='MessageHeader':self.header=self.row;self.bucket=None
  elif name=='REPORT_HEADER':self.report=self.row;self.bucket=None
  elif name=='REPORT_DATA':
   r=self.row;self.count+=1
   if r.get('RESOURCE_NAME') in self.nodes:
    assert r['DATA_ITEM']=='LMP_CONG_PRC'
    key=(r['RESOURCE_NAME'],stamp(r['INTERVAL_START_GMT']),stamp(r['INTERVAL_END_GMT']))
    assert key not in self.values;v=Decimal(r['VALUE']);assert v.is_finite();self.values[key]=v
   if self.count%50000==0:guard()
   self.bucket=None
  self.text=[]
def source_run(tick):
 p=read(D/'PROTOCOL.json');pubs=[]
 for job in p['publication_jobs']:
  rx=read(D/'rx'/(job['id']+'.json'));assert sha(rx['original_zip'])==rx['sha256']
  with zipfile.ZipFile(rx['original_zip']) as arc:
   for member in arc.namelist():
    if member.lower().endswith('.csv'):
     with arc.open(member) as f:pubs.extend(r for r in csv.DictReader(io.TextIOWrapper(f,encoding='utf-8-sig')) if r.get('REPORT_NAME')=='PRC_LMP' and r.get('MARKET_RUN_ID')=='DAM')
 keys=lambda rows:{json.dumps(r,sort_keys=True) for r in rows}
 assert keys(pubs)==keys(read(D/'PUB_LEDGER.json'));pubs=list({json.dumps(r,sort_keys=True):r for r in pubs}.values())
 nodes=read(B/'dataset/compiled_train_june/manifest.json')['nodes'];passed=admitted=equalities=0
 for job in p['day_jobs']:
  source=D/'days'/(job['id']+'.json');r=read(source);rx=read(D/'rx'/(job['id']+'.json'))
  assert r['source_sha256']==rx['sha256']==sha(r['source_path'])
  checkpoint=E/'sa'/(job['id']+'.json')
  if checkpoint.exists():
   a=read(checkpoint);assert a['record_sha256']==sha(source) and a['source_sha256']==r['source_sha256'];passed+=1;admitted+=int(a['admitted']);equalities+=a['value_equalities'];continue
  with zipfile.ZipFile(r['source_path']) as arc:
   member=next(n for n in arc.namelist() if '_DAM_MCC_' in n and n.endswith('.xml'))
   # Header-only SAX stops at first data record for excluded files.
   class HeaderDone(Exception):pass
   class HeaderReader(Reader):
    def startElement(self,name,attrs):
     if name.split(':')[-1]=='REPORT_DATA':raise HeaderDone()
     super().startElement(name,attrs)
   h=HeaderReader(nodes)
   with arc.open(member) as f:
    try:xml.sax.parse(f,h)
    except HeaderDone:pass
   assert h.header['Source']=='OASIS' and h.report['MKT_TYPE']=='DAM' and h.report['REPORT']=='PRC_LMP'
   generated=stamp(h.header['TimeDate']);local=datetime.fromisoformat(job['date']).replace(tzinfo=ZoneInfo('America/Los_Angeles'));start=local.timestamp();end=(local+timedelta(days=1)).timestamp()
   witnesses=[q for q in pubs if q.get('OPR_DT')==job['date'] and q.get('STATUS')=='Push Completed' and stamp(q['INTERVAL_START_GMT'])==start and stamp(q['INTERVAL_END_GMT'])==end and abs(stamp(q['PUBLICATION_DATE_GMT'])-generated)<=900]
   assert generated==r['generation_utc'] and start==r['start_utc'] and end==r['end_utc'] and keys(witnesses)==keys(r['publication_witnesses'])
   eligible=generated<start and bool(witnesses) and max([generated]+[stamp(q['PUBLICATION_DATE_GMT']) for q in witnesses])<start
   assert eligible==r['admitted']
   num=0
   if eligible:
    h=Reader(nodes)
    with arc.open(member) as f:xml.sax.parse(f,h)
    expected={(node,t,t+3600) for node in nodes for t in range(int(start),int(end),3600)}
    saved={(q['node'],q['start'],q['end']):Decimal(q['MCC']) for q in r['rows']}
    assert len(saved)==len(r['rows']) and set(h.values)==expected and h.values==saved
    assert r['available_by']==max([generated]+[stamp(q['PUBLICATION_DATE_GMT']) for q in witnesses])
    assert h.header==r['header'];num=len(saved)
  write(checkpoint,dict(at=now(),passed=True,admitted=eligible,record_sha256=sha(source),source_sha256=r['source_sha256'],value_equalities=num))
  passed+=1;admitted+=int(eligible);equalities+=num;tick(stage='separate_source_replay',completed=passed,total=len(p['day_jobs']),admitted=admitted)
 assert passed==706 and admitted==337
 out=dict(at=now(),passed=True,dates=passed,admitted_days=admitted,excluded_days=passed-admitted,exact_decimal_equalities=equalities,publication_csv_replayed=26,
  independent_person_review=False,audit_type='Separate SAX parser and source rule implementation; same operator',
  admission_scope='Retrospective publisher-cached XML reconstruction with near-time publication corroboration. Not independent historical user capture or immutable-version proof.',
  whole_archive_admitted=False,protocol_sha256=sha(E/'PROTOCOL.json'))
 write(E/'SOURCE_AUDIT.json',out)
 return out

