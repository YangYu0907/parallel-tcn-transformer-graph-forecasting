"""Second-stage seal requires meaningful candidate/control QA."""
from pathlib import Path
import gate as g
TRAINING_SEAL=g.HERE/'TRAINING_SEAL.json'
def verify_training():
    g.verify();seal=g.read(TRAINING_SEAL)
    g.need(seal['status']=='sealed_finite_training','Training not sealed')
    for path,digest in seal['bindings'].items():g.need(g.sha(path)==digest,'Bound artifact changed: '+path)
    g.need(g.read(g.HERE/'QA.json')['status']=='passed','QA missing')
    return seal
def seal():
    g.verify();g.need(not TRAINING_SEAL.exists(),'Already sealed')
    qa=g.read(g.HERE/'QA.json');g.need(qa['status']=='passed' and len(qa['control_reuse'])==6,'QA failed')
    files=list(g.HERE.glob('*.py'))+list(g.HERE.glob('*.ps1'))+[g.SEAL,g.HERE/'PROTOCOL.json',g.HERE/'QA.json']
    old=g.ROOT/'residual_attention_v1_20260928'
    files += [old/name for name in ('EXECUTION_SEAL.json','PROTOCOL.json','AUDIT.json','common.py','train.py','selection.py')]
    for ref in g.read(g.HERE/'PROTOCOL.json')['reused_controls']:
        folder=Path(ref['directory']);r=g.read(folder/'completion.json')
        files += [folder/'completion.json',folder/'audit.json',folder/'run_start.json']
        for row in r['epochs']:files += [Path(row['evaluation']),Path(row['checkpoint']['path'])]
    g.write(TRAINING_SEAL,dict(status='sealed_finite_training',at=g.now(),bindings={str(p):g.sha(p) for p in files},new_fits=3,reused_controls=6,test_access_permitted=False))
    print('Training sealed')
if __name__=='__main__':seal()
