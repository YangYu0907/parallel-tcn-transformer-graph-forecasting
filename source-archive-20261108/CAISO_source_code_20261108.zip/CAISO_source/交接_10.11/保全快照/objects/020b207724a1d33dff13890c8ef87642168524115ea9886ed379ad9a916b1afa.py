from base import *
from features import apply_correction
from combine import data,intervals,probability_scores
import numpy as np
def main():
    verify()
    with numeric('matched recovery systems and probability comparisons'):
        tick=timer('evaluate');stages={};alloutputs={};rows=[];details=[];risks=[]
        from sklearn.metrics import brier_score_loss,log_loss,average_precision_score
        for fold in [1,2]:
            tick(fold=fold);d=data(fold);stages[fold]=d
            with np.load(HERE/f'fold{fold}/PREDICTIONS.npz') as z:heads={k:z[k] for k in z.files}
            assert np.array_equal(heads['origins'],d['origins'])
            source=OLD/('CALIBRATION_REPLAY.npz' if fold==1 else 'REPLAY.npz')
            with np.load(source) as z:parents={f'BASE_{s}':z[f'COMPLETE_{s}'] for s in SEEDS}
            outputs=dict(parents);outputs['FULL']=d['full']
            for seed in SEEDS:
                original=parents[f'BASE_{seed}']
                for arm in ['HEAD_ONLY','TRANSITION']:
                    p,w=apply_correction(original,heads['recovery'],heads['probability'],heads['eligible'],arm)
                    name=f'{arm}_{seed}';outputs[name]=p
                    q=parent.qualification(p,original,d['truth'],d['states'],d['days'])
                    fs=parent.state_metrics(d['full'],d['truth'],d['states'],d['days'])
                    addressed=all(q['states'][k][m]<=fs[k][m]+1e-6 for k in [3,4] for m in ['mae','rmse'])
                    details.append(dict(fold=fold,model=name,preservation_vs_BASE=q,repair_S3_S4_vs_FULL=addressed,
                        eligible_cells=int(heads['eligible'].sum()),changed_cells=int(np.count_nonzero(p-original))))
                    assert np.array_equal(p[d['states']<3],original[d['states']<3])
            alloutputs[fold]=outputs
            for name,p in outputs.items():
                rows.append(dict(fold=fold,stage='calibration' if fold==1 else 'historical_forward',model=name,
                    **parent.metrics(p,d['truth']),states=parent.state_metrics(p,d['truth'],d['states'],d['days'])))
            stats=read(OLD/f'fold{fold}_stats.json')['neural'];c=np.asarray(stats['center'])[None,:,None];q=np.asarray(stats['thresholds'])[1][None,:,None]
            target=abs(d['truth'][:,:,7:]-c)<=q;mask=np.broadcast_to(heads['eligible'][:,:,None],target.shape)
            yy=target[mask];pr=heads['probability'][mask]
            risks.append(dict(fold=fold,cells=len(yy),recovery_fraction=float(yy.mean()),mean_probability=float(pr.mean()),
                brier=float(brier_score_loss(yy,pr)),logloss=float(log_loss(yy,pr,labels=[False,True])),
                pr_auc=float(average_precision_score(yy,pr)),independent_events_not_cells=True))
            save(HERE/f'REPLAY_fold{fold}.npz',truth=d['truth'],states=d['states'],days=d['days'],origins=d['origins'],**outputs)
        prob=[];boundsout={}
        for name in alloutputs[2]:
            bounds,params=intervals(stages[1],stages[2],alloutputs[1][name],alloutputs[2][name],'CQR')
            prob.append(dict(model=name,method='CQR',**probability_scores(bounds,alloutputs[2][name],stages[2]['truth']),calibration=params))
            boundsout[name]=bounds
        save(HERE/'PROBABILITY_REPLAY.npz',truth=stages[2]['truth'],**boundsout)
        rawpass=all(x['preservation_vs_BASE']['passed'] and x['repair_S3_S4_vs_FULL'] for x in details if x['model'].startswith('TRANSITION'))
        controlpass=all(np.mean([x[m] for x in rows if x['fold']==f and x['model'].startswith('TRANSITION')])<
            np.mean([x[m] for x in rows if x['fold']==f and x['model'].startswith('HEAD_ONLY')])
            for f in [1,2] for m in ['mae','rmse','h12_mae'])
        write(HERE/'RESULT.json',dict(at=now(),status='finite_recovery_comparison_pending_arithmetic_audit',rows=rows,
            details=details,recovery_probability=risks,probability=prob,screen_passed=rawpass and controlpass,
            versus_HEAD_ONLY_passed=controlpass,scope='Historical development only; one frozen backbone seed, three old router initializations; no new independent test.',
            V7_replaced=False,new_test_targets_read=False,full_research_complete=False,
            preserved='Exact BASE_COMPLETE H1-H7 and every current-nonextreme output; cannot infer all other states improve.',
            replays={n:sha(HERE/n) for n in ['REPLAY_fold1.npz','REPLAY_fold2.npz','PROBABILITY_REPLAY.npz']}))
        verify();tick(status='complete')
if __name__=='__main__':main()

