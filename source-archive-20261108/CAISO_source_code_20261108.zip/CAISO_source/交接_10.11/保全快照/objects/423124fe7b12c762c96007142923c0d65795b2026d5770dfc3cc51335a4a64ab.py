from core import *

def main():
    assert not (HERE/'PROTOCOL.json').exists(),'Immutable registration already exists'
    qa=read(HERE/'QA.json');assert qa['status']=='passed'
    for name,h in qa['scripts'].items():assert sha(HERE/name)==h
    adm=read(HERE/'ADMISSION.json');assert adm['status']=='admitted_historical_development_only'
    assert all(x['dates']>=5 for b in adm['blocks'] for x in b['state_support'])
    m,paths=sources();src=list(HERE.glob('*.py'))+list(HERE.glob('fold*_origins.npz'))+list(HERE.glob('fold*_stats.json'))
    src += [HERE/'QA.json',HERE/'ADMISSION.json',MANIFEST,MANIFEST.parent/'audit.json',R/'common.py',R/'fair_inputs.py',R/'PROTECTED_FILES.json']
    src += list(paths.values())
    # Reuse reviewed source implementations, never old fitted full-period statistics.
    for path,h in read(R/'FAIR_INPUT_SEAL.json')['sources'].items():
        p=Path(path)
        if p.suffix=='.py':assert sha(p)==h;src.append(p)
    src += [R/'FAIR_INPUT_SEAL.json']
    verify_protected()
    write(HERE/'PROTOCOL.json',dict(at=now(),status='registered_before_all_expert_and_router_fits',
        authorization='Latest user explicitly requests a larger coherent improvement and says continue. Earlier narrower candidate budgets do not define this new finite experiment.',
        objective='Resolve short-calendar meta-learning and separate signed spike occurrence, magnitude, horizon routing and probabilistic calibration in one matched pipeline.',
        bindings={str(p):sha(p) for p in dict.fromkeys(src)},
        source_scope='Admitted TRAIN period only, already used in research. Retrospective source subset, not unobserved confirmation.',
        blocks=adm['blocks'],block_roles=['meta_fit','calibration','forward_development'],purge_days=2,
        backbones=dict(models=['FULL_price_only','iTransformer_price_only'],seed=SEEDS[0],
            fits=6,epochs=12,samples_per_epoch=4032,batch=4,selection='Fixed epoch12; no forward validation used to select epochs.',
            starts='Fresh initialization for each chronological prefix; fresh prefix scalers/context limits; identical sampled origins and learning rate schedule across the paired models.',
            missing_features='All nonprice slots zero from initialization through inference; same 288-step,30-node price information in all models.'),
        specialist=dict(fits_per_fold=9,heads=['three-class signed endpoint risk','three conditional mean regressors','quantiles .05 .1 .5 .9 .95'],
            training='First80% prefix dates, two-day purge, last20% temperature calibration; hourly qualified origins, one label-independent rotating horizon per node-origin.',
            estimator='HistGradientBoosting;80iterations,7leaves,minleaf50,lr.05,l2=1; no grid; same natural class frequency; thresholds fitted in tree training prefix only.',
            information='Same price window, node identity and requested horizon. Derived cross-location price summaries allowed for every model information contract. No future state labels in routing.',
            admission='Every signed class requires100rows and5dates; failure stops the finite queue, not a reason to relabel absent events.'),
        router=dict(variants=['COMPLETE','NO_SPIKE','NO_RISK'],seeds=SEEDS,fits=9,
            architecture='40 inputs,32 hidden GELU,expert softmax; effective FULL weight .5+.5*p_FULL; other weights .5*p_k. H1-H7 bitwise FULL; no output concatenation.',
            loss='Mean |USDerror/sbar| + .1*(USDerror/sbar)^2; sbar meta-fit mean node scale; AdamW lr.001 wd.001; gradientclip1;20fixedepochs,batch2048.',
            preprocessing='Meta-fit median/IQR,clip6; observable history outside meta-fit range returns FULL; NO_RISK zeroes last three probability inputs.',
            controls=['FULL','iTransformer','SPIKE','FIXED25','FIXED50','FIXED_THREE','NO_SPIKE','NO_RISK'],
            caution='Three router initializations share one backbone seed; do not call this three independent backbone replications.'),
        uncertainty=dict(intervals=[.8,.9],method='Price-quantile widths recentered on each fixed point forecast, empirical CQR-style horizon calibration. Point outputs remain exactly unchanged.',
            controls=['horizon-wise absolute-residual empirical intervals','conditional quantile intervals'],
            metrics=['WIS','coverage','width','interval score','signed-endpoint Brier','log loss','PR-AUC'],
            guarantees='No exchangeability-based guarantee asserted for dependent chronological prices; assess realized calibration and tail-state support.'),
        safeguards=dict(launch_GiB=5,runtime_GiB=4,threads=1,maximum_numerical_seconds=43200,
            primary='MAE; RMSE,all horizons and S0-S5 MAE/RMSE must not regress, each state >=5dates in calibration and forward evaluation.',
            continuation='COMPLETE must pass all preservation checks in every router seed and beat fixed controls in aggregate; otherwise unqualified. Missing support is not a pass.',
            protected='V7 and18hash-bound source/paper/evidence files remain immutable. H1-H7 preservation refers to matched newly trained FULL; no claim of new V7 performance without V7-matched confirmation.',
            deployment='Even a passed development screen requires new admitted independent confirmation plus backbone seed replication; no automatic replacement.',
            inference='No Q3/H1/Europe2016/Europe2017 target access. No follow-on hyperparameter search.'),
        statistics='Eight predeclared COMPLETE-versus-control MAE contrasts. Mean losses over router seeds; paired7-calendar-day-bin bootstrap2000replicates,actualgaps;Holm;exploratory.',
        literature=[
            dict(title='FFORMA, International Journal of Forecasting (2020)',url='https://robjhyndman.com/papers/fforma.pdf',scope='Feature-based combination and separately generated forecast losses; actual mixture loss and bounded router here are a new implementation, not a replication or guarantee.'),
            dict(title='Christensen, Hurn, Lindsay, Forecasting spikes in electricity prices, IJF (2012)',url='https://www.sciencedirect.com/science/article/pii/S0169207011000550',scope='Separate spike-occurrence risk as a forecasting task; publisher abstract inspected; working-paper full text retrieval timed out. Does not prescribe our tree mixture.'),
            dict(title='Romano, Patterson, Candes, Conformalized Quantile Regression, NeurIPS (2019)',url='https://arxiv.org/abs/1905.03222',scope='Conditional-width interval calibration; dependent sequence needs empirical evaluation, original finite-sample theorem not asserted here.'),
            dict(title='Gneiting, JASA (2011)',url='https://arxiv.org/abs/0912.0902',scope='Different point functionals and scores; no simultaneous MAE/RMSE guarantee.'),
            dict(title='Lago et al., Applied Energy (2021)',url='https://arxiv.org/abs/2008.08004',scope='Fair input and chronological comparison.'),
            dict(title='Cawley and Talbot, JMLR (2010)',url='https://jmlr.org/papers/v11/cawley10a.html',scope='Bounded candidate design and no repeated tuning on the same confirmation period.')],
        new_test_targets_read=False,V7_replaced=False,periodic_model_wakeups=False,whole_research_complete=False))
    # Resolve the delayed previous notification, without emitting another event.
    old=R/'direct_gate_20261003';close=read(old/'CLOSURE.json')
    for name,key in [('RESULT.json','original_result_sha256'),('AUDIT.json','original_audit_sha256'),('REPAIRED_RESULT.json','repaired_result_sha256'),('REPAIR_AUDIT.json','repair_audit_sha256')]:assert sha(old/name)==close[key]
    write(old/'EVENT_DELIVERY_ACK.json',dict(at=now(),user_event_id='8076ccdef66b023023c0f0556199e4d2bd25a41f894c986318ed4ea58acf7b72',
        emitter_event_id=close['event_id'],status='duplicate_delivery_already_analyzed_including_solver_repair',training_restarted=False))

if __name__=='__main__':main()
