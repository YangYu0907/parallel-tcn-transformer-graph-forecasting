﻿$ErrorActionPreference = 'Stop'
$trial = $PSScriptRoot
$branch = Split-Path -Parent (Split-Path -Parent $trial)
$py = 'D:\Documents\conda_envs\tcn_air\python.exe'
$managerFile = Join-Path $trial 'network_manager_20261007.py'
$statePath = Join-Path $trial 'STATUS.json'
$env:PYTHONIOENCODING = 'utf-8'
if (!(Test-Path -LiteralPath (Join-Path $trial 'PROTOCOL.json')) -or !(Test-Path -LiteralPath (Join-Path $trial 'QA.json'))) { throw 'Protocol and QA must exist before any manager launch' }
& $py -c "import sys;sys.path.insert(0,sys.argv[1]);import support as s;import network_manager_20261007 as r;s.verify();r.validate_recovery();print(s.guard(True))" $trial
if ($LASTEXITCODE -ne 0) { throw 'Registration, source binding or resource check failed; no manager launched' }
if (Test-Path -LiteralPath (Join-Path $trial 'MANAGER.lock')) { throw 'Existing manager lock; verify before launching' }
if (Test-Path -LiteralPath 'D:\Desktop\数据科学_论文\研究优化_20260818\logs\NEURAL_RUN.lock') { throw 'Shared numerical lock occupied' }
$live = @(Get-CimInstance Win32_Process | Where-Object { $_.Name -match '^python' -and $_.CommandLine -and $_.CommandLine.Contains($trial) })
if ($live.Count) { throw 'Another trial Python process exists' }
if (Test-Path -LiteralPath (Join-Path $trial 'START_READY.json')) {
    $old = Get-Content -LiteralPath (Join-Path $trial 'START_READY.json') -Raw | ConvertFrom-Json
    if ($old.manager_pid -ne 4436 -or $old.manager_start_utc_ticks -ne 639269649928778910) { throw 'Unexpected old launch identity' }
    Move-Item -LiteralPath (Join-Path $trial 'START_READY.json') -Destination (Join-Path $trial 'network_recovery_records_20261007\START_READY.retired.json')
}
$process = Start-Process -FilePath $py -ArgumentList @('-u', ('"' + $managerFile + '"')) -WindowStyle Hidden -PassThru -WorkingDirectory $trial -RedirectStandardOutput (Join-Path $trial 'network_20261007.stdout.log') -RedirectStandardError (Join-Path $trial 'network_20261007.stderr.log')
$ticks = $process.StartTime.ToUniversalTime().Ticks
$exitScript = Join-Path $branch 'event_driven_automation\watch_manager_exit.ps1'
$exitArgs = @('-NoProfile','-ExecutionPolicy','Bypass','-File',('"' + $exitScript + '"'),'-ManagerProcessId',$process.Id,'-ManagerStartUtcTicks',$ticks,'-ManagerScript',('"' + $managerFile + '"'),'-StatusPath',('"' + $statePath + '"'))
$monitor = Start-Process -FilePath 'powershell.exe' -ArgumentList $exitArgs -WindowStyle Hidden -PassThru -RedirectStandardOutput (Join-Path $trial 'network_20261007_exit.stdout.log') -RedirectStandardError (Join-Path $trial 'network_20261007_exit.stderr.log')
$receipt = Join-Path $branch ('event_driven_automation\process_monitors\mechanism_exit_' + $process.Id + '_' + $ticks + '.status.json')
$timer = [Diagnostics.Stopwatch]::StartNew()
while (!(Test-Path -LiteralPath $receipt) -and $timer.Elapsed.TotalSeconds -lt 15) { Start-Sleep -Milliseconds 200 }
if (!(Test-Path -LiteralPath $receipt)) { throw 'Exit monitor receipt absent; manager will safely time out without starting work' }
$ready = @{at=[DateTime]::UtcNow.ToString('o');manager_pid=$process.Id;manager_start_utc_ticks=$ticks;exit_monitor_pid=$monitor.Id;receipt=$receipt;periodic_model_wakeups=$false;resumption_date="2026-10-07"}
$tmp = Join-Path $trial 'START_READY.tmp'
$ready | ConvertTo-Json -Depth 5 | Set-Content -LiteralPath $tmp -Encoding UTF8
Move-Item -LiteralPath $tmp -Destination (Join-Path $trial 'START_READY.json')
$ready | ConvertTo-Json -Depth 5 | Set-Content -LiteralPath (Join-Path $trial 'LAUNCH.json') -Encoding UTF8
$ready | ConvertTo-Json -Depth 5
