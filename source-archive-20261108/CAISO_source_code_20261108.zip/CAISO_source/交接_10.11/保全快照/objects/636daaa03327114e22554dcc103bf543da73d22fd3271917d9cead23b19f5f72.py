"""Offline transport and cache-boundary checks; no HTTP requests or model fits."""
from pathlib import Path
import sys, hashlib, json
W=Path(__file__).resolve().parent
sys.path.insert(0,str(W))
import manager as m
nt=m.nt;s=m.s

def main():
    checks=[];fixture=W/'work'/'qa_fixture';fixture.mkdir(parents=True,exist_ok=True)
    file=fixture/'fragment.grib2';file.write_bytes(b'fixture')
    headers=Path(str(file)+'.headers')
    headers.write_text('HTTP/1.1 206 Partial Content\nETag: "abc"\nLast-Modified: Thu, 01 Jan 1970 00:00:00 GMT\nContent-Length: 7\nContent-Range: bytes 3-9/20\n',encoding='utf-8')
    x=dict(path=file,size=7,range=[3,9],source=dict(etag='"abc"',last_modified_seconds=0,bytes=20))
    assert nt.complete_part(x);checks.append('Complete exact range accepted')
    for field,value in [('etag','"wrong"'),('last_modified_seconds',1),('bytes',21)]:
        bad=dict(x,source=dict(x['source'],**{field:value}))
        try:nt.complete_part(bad)
        except AssertionError:pass
        else:raise AssertionError('Corrupt source metadata accepted '+field)
    checks.append('ETag, version time, and total object size mismatch rejected')
    file.write_bytes(b'fixtur');assert not nt.complete_part(x);file.write_bytes(b'fixture')
    checks.append('Incomplete fragment requires bounded retry')
    oldwrite=nt.write;writes=[];nt.write=lambda name,data:writes.append((name,data))
    try:
        nt.COUNTS.update(reserved_bytes=0,reserved_requests=0);nt.RAW_RESERVATIONS.clear()
        q=dict(maximum_bytes=20,maximum_requests=3,maximum_retained_raw_bytes=7)
        nt.reserve([x],q);nt.reserve([x],q)
        assert nt.COUNTS['reserved_bytes']==14 and sum(nt.RAW_RESERVATIONS.values())==7
        assert len(writes)==2;checks.append('Retry charges traffic twice but reserves same raw file once')
        snapshot=(dict(nt.COUNTS),dict(nt.RAW_RESERVATIONS),len(writes))
        try:nt.reserve([x],q)
        except AssertionError:pass
        else:raise AssertionError('Download quota not enforced')
        assert snapshot==(dict(nt.COUNTS),dict(nt.RAW_RESERVATIONS),len(writes))
        checks.append('Quota violation rejected before counter commit or I/O')
        bad=dict(x,path=W/'outside.grib2')
        try:nt.reserve([bad],dict(q,maximum_bytes=100))
        except AssertionError:pass
        else:raise AssertionError('Out-of-work target accepted')
        checks.append('Out-of-work transport target rejected')
    finally:nt.write=oldwrite
    receipt=dict(local=str(file.relative_to(s.N)),sha256=s.sha(file))
    download=dict(receipts=[dict(receipt)])
    assert m.prepare_release(download,True)==[] and download['receipts'][0]['local']
    checks.append('Pilot source payload retained')
    release=m.prepare_release(dict(receipts=[dict(receipt)]),False)
    assert len(release)==1
    marker=fixture/'keep.txt';marker.write_text('Retain unrelated files',encoding='utf-8')
    cycle=s.N/'cycles'/'-1.json'
    assert not cycle.exists();cycle.write_text('{"scope":"synthetic QA only"}',encoding='utf-8')
    try:
        m.release_payloads(-1,release,s.sha(cycle))
        assert not file.exists() and marker.exists() and headers.exists()
        checks.append('Exact verified payload deletion leaves headers and unrelated files intact')
    finally:
        assert cycle.resolve().is_relative_to((s.N/'cycles').resolve())
        cycle.unlink()
    nt.COUNTS.update(reserved_bytes=0,reserved_requests=0);nt.RAW_RESERVATIONS.clear()
    s.verify()
    checks.append('All scientific parent bindings and18protected files unchanged')
    m.write('QA.json',dict(at=s.now(),passed=True,checks=checks,network_requests=0,model_fits=0,new_test_targets_read=False))
    print(json.dumps(dict(passed=True,checks=len(checks),network_requests=0,model_fits=0)))

if __name__=='__main__':main()
