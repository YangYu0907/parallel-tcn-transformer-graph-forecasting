import common as c
import os,subprocess,traceback
def emit(event,path):
    key='v21_conflict_'+event+'_'+c.sha(path)
    c.write(c.ROOT/'event_driven_automation/inbox'/(key+'.json'),dict(schema='caiso_research_event_v1',event_id=key,event=event,evidence_path=str(path),at=c.now(),periodic=False))
    return key
def main():
    try:
        c.verify()
        for script in ('run.py','audit.py'):
            c.check(True);c.write(c.HERE/'status.json',dict(at=c.now(),pid=os.getpid(),event='step_process_started',script=script))
            p=subprocess.run(['D:/Documents/conda_envs/tcn_air/python.exe','-u',str(c.HERE/script)],cwd=str(c.HERE))
            if p.returncode:raise RuntimeError(script+' exit='+str(p.returncode))
        d=c.read(c.HERE/'DECISION.json');key=emit('audited_result_ready' if d['passed'] else 'unexpected_result',c.HERE/'AUDIT.json')
        c.write(c.HERE/'status.json',dict(at=c.now(),pid=os.getpid(),event='finite_mechanism_queue_completed',event_id=key,status='audited_complete',passed=d['passed']))
    except BaseException as exc:
        stopped=isinstance(exc,InterruptedError)
        try:c.check()
        except InterruptedError:stopped=True
        except Exception:pass
        path=c.HERE/'FAILURE.json';c.write(path,dict(at=c.now(),error=str(exc),traceback=traceback.format_exc(),V7_preserved=True))
        key=None if stopped else emit('blocking_failure',path)
        c.write(c.HERE/'status.json',dict(at=c.now(),pid=os.getpid(),event='user_stop_before_launch' if stopped else 'step_stopped_or_failed',classification='user_stop' if stopped else 'failure',event_id=key))
        raise
if __name__=='__main__':main()
