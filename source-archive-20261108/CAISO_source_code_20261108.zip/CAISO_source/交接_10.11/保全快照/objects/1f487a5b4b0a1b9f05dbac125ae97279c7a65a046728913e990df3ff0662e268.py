"""Bounded archival history I/O and the existing 29-feature transformation.

This module grants no test release. The production adapter provided here is
June-only. ZIP decompression may traverse skipped bytes, but only explicitly
permitted payload slices are returned for numeric conversion. Future targets
and the gaps between long-lag windows are never converted to numeric arrays.
"""
from dataclasses import dataclass
import ast
import hashlib
import math
from pathlib import Path
import struct
import zipfile


@dataclass(frozen=True)
class HistoryContract:
    origin: int

    def __post_init__(self):
        if type(self.origin) is not int or self.origin < 4320:
            raise ValueError('Origin cannot support the registered fourteen-day lag')

    @property
    def price_ranges(self):
        o = self.origin
        return ((o-4320, o-4032), (o-2304, o-2016), (o-864, o))

    @property
    def forecast_ranges(self):
        return ((self.origin-288, self.origin),)

    def allows(self, start, stop, kind):
        if type(start) is not int or type(stop) is not int or start >= stop:
            return False
        if kind not in ('price', 'forecast'):
            return False
        ranges = self.price_ranges if kind == 'price' else self.forecast_ranges
        return any(a <= start < stop <= b for a, b in ranges)


def file_sha(path):
    with Path(path).open('rb') as handle:
        return hashlib.file_digest(handle, 'sha256').hexdigest()


def exact_read(handle, n):
    data = handle.read(n)
    if len(data) != n:
        raise EOFError('Truncated bounded member')
    return data


class BoundedMember:
    """Read a scalar-dtype C-order NPY member with explicit per-origin ranges."""
    def __init__(self, archive, member, dtype, tail):
        if dtype not in ('<f4', '<i8', '|b1'):
            raise ValueError('Unsupported dtype; object arrays are forbidden')
        self.archive = Path(archive)
        self.member = member + '.npy'
        self.dtype, self.tail = dtype, tuple(tail)
        self.itemsize = {'<f4': 4, '<i8': 8, '|b1': 1}[dtype]
        self.row_bytes = math.prod(tail) * self.itemsize
        self.zip = zipfile.ZipFile(self.archive)
        self.stream = None
        try:
            if self.zip.namelist().count(self.member) != 1:
                raise ValueError('Missing or duplicate NPY member')
            self.stream = self.zip.open(self.member)
            if exact_read(self.stream, 6) != b'\x93NUMPY':
                raise ValueError('Invalid NPY magic')
            version = tuple(exact_read(self.stream, 2))
            if version not in ((1, 0), (2, 0)):
                raise ValueError('Unsupported NPY version')
            width = 2 if version == (1, 0) else 4
            size = int.from_bytes(exact_read(self.stream, width), 'little')
            if not 0 < size <= 65536:
                raise ValueError('Oversized NPY header')
            header = ast.literal_eval(exact_read(self.stream, size).decode('latin1'))
            shape = header.get('shape')
            if (header.get('descr') != dtype or header.get('fortran_order') is not False
                    or not isinstance(shape, tuple) or not shape
                    or any(type(x) is not int or x <= 0 for x in shape)
                    or shape[1:] != self.tail):
                raise ValueError('Member shape/order/dtype changed')
            self.shape = shape
            self.payload_offset = self.stream.tell()
            if self.zip.getinfo(self.member).file_size != self.payload_offset + shape[0]*self.row_bytes:
                raise ValueError('NPY member byte extent disagrees with header')
            self.receipts = []
            self.cache = []
        except BaseException:
            self.close()
            raise

    def read(self, start, stop, contract, kind):
        if not contract.allows(start, stop, kind) or stop > self.shape[0]:
            raise PermissionError('Requested rows escape the declared history dependencies')
        data = None
        for a,b,payload in self.cache:
            if a <= start < stop <= b:
                data = payload[(start-a)*self.row_bytes:(stop-a)*self.row_bytes]
                break
        if data is None:
            offset = self.payload_offset + start*self.row_bytes
            if self.stream.seek(offset) != offset:
                raise IOError('ZIP logical seek failed')
            data = exact_read(self.stream, (stop-start)*self.row_bytes)
        self.receipts.append(dict(origin=contract.origin, member=self.member, kind=kind,
            start=start, stop_exclusive=stop, payload_bytes=len(data), payload_sha256=hashlib.sha256(data).hexdigest(),
            target_rows_returned=False))
        return data

    def prepare_byte_cache(self, contracts, kind):
        """Cache the union of permitted history bytes, without numeric parsing.

        Every later read still checks its own origin. A later origin's cached
        history grants no earlier origin permission to consume those bytes.
        """
        if kind not in ('price','forecast'):
            raise ValueError('Unknown history source')
        intervals=[]
        for c in contracts:
            intervals.extend(c.price_ranges if kind=='price' else c.forecast_ranges)
        merged=[]
        for a,b in sorted(intervals):
            if a < 0 or b > self.shape[0]:
                raise ValueError('History exceeds archive')
            if merged and a <= merged[-1][1]:
                merged[-1][1]=max(merged[-1][1],b)
            else:merged.append([a,b])
        total=sum(b-a for a,b in merged)*self.row_bytes
        if total > 64*1024**2:
            raise MemoryError('Bounded history byte-cache exceeds 64 MiB')
        cache=[]
        for a,b in merged:
            offset=self.payload_offset+a*self.row_bytes
            if self.stream.seek(offset) != offset:raise IOError('ZIP logical seek failed')
            cache.append((a,b,exact_read(self.stream,(b-a)*self.row_bytes)))
        self.cache=cache

    def close(self):
        if self.stream is not None:
            self.stream.close()
        self.zip.close()


def build_features(recent, lag7, lag14, forecasts, missing, publications, seconds,
                   cutoff, scalers, tac, age_caps):
    """Same fitted transforms as compile_dataset; bounded float64 rolling sums.

    The rolling sum has a different accumulator origin from the compiled
    whole-prefix implementation. June replay must measure its floating-point
    difference before any H1 adapter can be admitted; equality is not presumed.
    """
    import numpy as np
    from compile_math import calendar, rolling_std, NAMES
    if (recent.shape != (864, 30, 4) or lag7.shape != (288, 30, 4)
            or lag14.shape != (288, 30, 4) or forecasts.shape != (288, 2)
            or missing.shape != (288, 2) or publications.shape != (288, 2)
            or seconds.shape != (288,) or len(tac) != 30):
        raise ValueError('History dimensions changed')
    if (not all(np.isfinite(a).all() for a in (recent, lag7, lag14, forecasts))
            or missing.any() or np.any(publications <= 0) or np.any(publications > cutoff)
            or seconds[-1] != cutoff or not np.all(np.diff(seconds) == 300)):
        raise ValueError('Nonfinite, unavailable, or misaligned history')
    caps = np.asarray(age_caps, np.float64)
    if caps.shape != (2,) or not np.isfinite(caps).all() or np.any(caps <= 0):
        raise ValueError('Invalid publication-age caps')
    pc = np.asarray(scalers['price_center'], np.float32)[0]
    ps = np.asarray(scalers['price_scale'], np.float32)[0]
    ec = np.asarray(scalers['external_center'], np.float32)[0]
    es = np.asarray(scalers['external_scale'], np.float32)[0]
    h = recent[576:]
    x = np.zeros((288, 30, 29), np.float32)
    x[:, :, :4] = (h-pc)/ps
    x[:, :, 8:15] = calendar(seconds)[:, None, :]
    x[:, :, 15:17] = ((forecasts-ec)/es)[:, None, :]
    x[:, :, 17:19] = missing[:, None, :]
    x[:, :, 19:21] = np.clip((cutoff-publications)/60/caps, 0, 1).astype(np.float32)[:, None, :]
    derived = np.empty((288, 30, 8), np.float32)
    derived[:, :, 0] = h[:, :, 0]-recent[564:852, :, 0]
    for node in range(30):
        derived[:, node, 1] = rolling_std(recent[:, node, 0], 36)[576:]
    tac = np.asarray(tac)
    for area in np.unique(tac):
        ids = np.flatnonzero(tac == area)
        values = h[:, ids, 2]
        derived[:, ids, 2] = values-np.median(values, axis=1)[:, None]
    derived[:, :, 3] = (forecasts[:, 1]-forecasts[:, 0])[:, None]
    derived[:, :, 4] = recent[288:576, :, 0]
    derived[:, :, 5] = recent[:288, :, 0]
    derived[:, :, 6] = lag7[:, :, 0]
    derived[:, :, 7] = lag14[:, :, 0]
    for field in range(8):
        state = scalers['derived'][NAMES[21+field]]
        norm = (derived[:, :, field]-np.asarray(state['center'], np.float32))/np.asarray(state['scale'], np.float32)
        x[:, :, 21+field] = np.nan_to_num(norm, nan=0, posinf=0, neginf=0)
    if not np.isfinite(x).all():
        raise ValueError('Nonfinite derived model input')
    return x


class JuneArchiveReader:
    """Development replay only. No H1 argument, release override, or target API."""
    def __init__(self, config, allowed_origins, expected_archive_hashes):
        self.allowed = frozenset(int(x) for x in allowed_origins)
        if not self.allowed or min(self.allowed) < 210528 or max(self.allowed)+12 > 219168:
            raise PermissionError('Only registered June2025 development origins allowed')
        self.readers = {}
        try:
            for key in ('price_archive', 'external_archive'):
                path = str(Path(config[key]).resolve())
                if path not in expected_archive_hashes or file_sha(path) != expected_archive_hashes[path]:
                    raise ValueError('Archive identity is missing or changed: '+key)
            for name, key, member, dtype, tail in (
                ('prices','price_archive','values','<f4',(30,4)),
                ('forecasts','external_archive','values','<f4',(4,)),
                ('missing','external_archive','missing','|b1',(4,))):
                self.readers[name] = BoundedMember(config[key], member, dtype, tail)
            contracts=[HistoryContract(o) for o in sorted(self.allowed)]
            for name,reader in self.readers.items():
                reader.prepare_byte_cache(contracts,'price' if name=='prices' else 'forecast')
        except BaseException:
            self.close()
            raise

    def history(self, origin, publications, seconds, scalers, tac, caps):
        import numpy as np
        if type(origin) is not int or origin not in self.allowed:
            raise PermissionError('Unregistered or held-out origin')
        c = HistoryContract(origin)
        price = [np.frombuffer(self.readers['prices'].read(a,b,c,'price'), '<f4').reshape(b-a,30,4)
                 for a,b in c.price_ranges]
        a,b = c.forecast_ranges[0]
        # The other two archived forecast columns are not converted or supplied
        # to this model. Row bytes contain them but numeric views select only 0:2.
        def first_two(name, dtype):
            payload = self.readers[name].read(a,b,c,'forecast')
            size = np.dtype(dtype).itemsize
            return np.ndarray((288,2), dtype=dtype, buffer=payload, strides=(4*size,size)).copy()
        return build_features(price[2],price[1],price[0],first_two('forecasts','<f4'),
            first_two('missing','|b1'),publications,seconds,int(seconds[-1]),scalers,tac,caps)

    def receipts(self):
        return [r for reader in self.readers.values() for r in reader.receipts]

    def close(self):
        for reader in self.readers.values():
            reader.close()
