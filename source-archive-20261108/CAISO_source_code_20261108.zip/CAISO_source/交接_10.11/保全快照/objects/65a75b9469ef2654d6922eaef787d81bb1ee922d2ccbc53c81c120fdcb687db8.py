"""Read-only event-support accounting before any V24 model fit."""
from pathlib import Path
import sys, json, os, hashlib
HERE=Path(__file__).resolve().parent
B=HERE.parent
sys.path.insert(0,str(B/'probability_contract_v23_20261001'))
import common as c

def save(path,obj):
    raw=json.dumps(obj,ensure_ascii=False,indent=2,allow_nan=False).encode('utf-8')
    tmp=path.with_suffix('.tmp')
    with tmp.open('wb') as f:f.write(raw);f.flush();os.fsync(f.fileno())
    os.replace(tmp,path)

def main():
    p=c.verify()
    with c.gate.exclusive('V24 event-support diagnosis; no model fitting'):
        np,lim=c.gate.runtime(False)
        with np.load(p['library'],allow_pickle=False) as z:d={k:z[k] for k in z.files}
        def account(ix):
            days,counts=np.unique(d['issued'][ix]//86400,return_counts=True)
            known=d['duration'][ix]<288;onset=d['issued'][ix]-(d['duration'][ix]-1)*300
            episodes=np.column_stack([d['node'][ix][known],onset[known]])
            unique,ecounts=np.unique(episodes,axis=0,return_counts=True)
            y=d['states'][ix]
            return dict(pairs=len(ix),distinct_issue_times=len(np.unique(d['issued'][ix])),nodes=len(np.unique(d['node'][ix])),utc_dates=len(days),calendar_weeks=len(np.unique(days//7)),
              date_weight_concentration_equivalent_count=float(counts.sum()**2/np.square(counts).sum()),largest_date_share=float(counts.max()/counts.sum()),
              observed_node_episodes=len(unique),right_history_censored_pairs=int((~known).sum()),largest_known_episode_pairs=int(ecounts.max()) if len(ecounts) else 0,
              states=[dict(state=k,cells=int((y==k).sum()),dates=len(np.unique(np.broadcast_to((d['issued'][ix]//86400)[:,None],y.shape)[y==k]))) for k in (3,4,5)])
        folds=[]
        for a,b in p['folds']:
            fit,cal,test,cut=c.split(d,c.stamp(a),c.stamp(b),np)
            folds.append(dict(month=a[:7],calibration_start=cut,**{k:account(np.flatnonzero(v)) for k,v in dict(fit=fit,cal=cal,test=test).items()}))
        out=dict(at=c.now(),status='event_support_accounted_before_V24_fit',source=p['library'],source_sha256=c.sha(p['library']),all_library=account(np.arange(len(d['issued']))),folds=folds,
          interpretation='Date-weight concentration equivalent count is descriptive Kish concentration, not effective independent sample size. Node episodes can share market shocks. Uncensored historical episode onset=issue-(duration-1)*300. No claim of independent episodes.',
          sufficiency='Enough labels for bounded exploratory matched-capacity comparison; insufficient basis to promise transferable gains or all-state superiority. No expansion of training/test dates or admission rules.',
          protected_files_verified=c.preserved(),model_fits=0,new_test_targets_read=False)
        save(HERE/'SUPPORT.json',out)
        print(json.dumps(out,ensure_ascii=False))

if __name__=='__main__':main()
