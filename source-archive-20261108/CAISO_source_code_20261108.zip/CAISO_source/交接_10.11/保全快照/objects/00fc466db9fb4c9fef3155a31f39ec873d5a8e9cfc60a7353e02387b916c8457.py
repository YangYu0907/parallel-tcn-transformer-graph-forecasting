import json
from pathlib import Path
import wait_resources as w

def main():
    seq=iter([MemoryError('below existing5GiBguard'),{'physical':5.1,'commit':7.0},{'physical':5.4,'commit':7.0}])
    calls=[]
    def check():
        value=next(seq)
        if isinstance(value,BaseException):raise value
        return value
    result=w.wait_ready(check,sleep=lambda n:calls.append(n))
    assert result['physical']==5.4 and calls==[10,10]
    for error in [InterruptedError('user pause'),OSError('disk guard'),AssertionError('source mismatch')]:
        def fail():raise error
        try:w.wait_ready(fail,sleep=lambda n:None)
        except type(error):pass
        else:raise AssertionError('Safety stop swallowed')
    proof={'passed':True,'checks':['Existing5GiBguard and additional5.25GiBmargin before launch','Pause/disk/source stops propagate'],'network_requests':0,'model_fits':0}
    (Path(__file__).parent/'WAIT_QA.json').write_text(json.dumps(proof,indent=2),encoding='utf-8')
    print(json.dumps(proof))

if __name__=='__main__':main()
