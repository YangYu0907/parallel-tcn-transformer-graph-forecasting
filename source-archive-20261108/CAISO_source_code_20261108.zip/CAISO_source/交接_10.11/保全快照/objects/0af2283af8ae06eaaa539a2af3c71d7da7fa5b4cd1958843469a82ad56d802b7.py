"""Fixed-output attribution; no fitting, candidate selection, or new test access."""
from pathlib import Path
from datetime import datetime, timezone
import sys, json, hashlib, time, os
H=Path(__file__).resolve().parent
B=H.parent
T=Path('C:/Users/于阳/CAISO_temporary_storage')
sys.path.insert(0,str(B/'context_expert_v1_20260929'))
import gate
SEEDS=[20260813,20260814,20260815]
def read(p): return json.loads(p.read_text(encoding='utf-8-sig'))
def sha(p):
    h=hashlib.sha256()
    with p.open('rb') as f:
        for block in iter(lambda:f.read(1024*1024),b''):h.update(block)
    return h.hexdigest()
def write(name,v): gate.write(H/name,v)
def register():
    assert not (H/'PROTOCOL.json').exists()
    v18=read(B/'mechanism_repair_v18_20260930/CAISO_MATCHED_RESULTS.json')
    files=[Path(__file__),B/'context_expert_v1_20260929/gate.py',B/'adaptive_experts_v4_20260929/FOLDS.json',B/'adaptive_experts_v4_20260929/FEEDBACK_ADMISSION.json',T/'adaptive_experts_v4_20260929/panel.npz',B/'mechanism_repair_v18_20260930/CAISO_MATCHED_RESULTS.json',B/'mechanism_repair_v18_20260930/AUDIT.json',B/'chronological_expert_pilot_v14_20260930/AUDIT.json',B/'chronological_expert_pilot_v14_20260930/FINAL_FREEZE.json',T/'chronological_expert_pilot_v14_20260930/EXPERT_ERROR_LIBRARY.npz']
    for row in v18['rows']:
        p=T/'mechanism_repair_v18_20260930/CAISO/predictions'/f"{row['seed']}_{row['anchor']}.npz"
        assert sha(p)==row['prediction_sha256']; files.append(p)
    protected=[B/'spike_specialist_v7_20260930/RESULT.json',B/'spike_specialist_v7_20260930/AUDIT.json',B/'v7_confirmation_20260930/RESULT.json',B/'v7_confirmation_20260930/AUDIT.json']
    for s in SEEDS: protected.append(T/'spike_specialist_v7_20260930/predictions'/f'{s}.npz')
    paper=Path('F:/CAISO_论文/manuscript_20260930_v7_integrated')
    protected.extend(paper/n for n in ['Energy_manuscript.docx','Energy_manuscript.pdf','Energy_supplementary.docx','Energy_supplementary.pdf','DELIVERY_MANIFEST.json'])
    write('PROTOCOL.json',dict(at=datetime.now(timezone.utc).isoformat(),status='registered_before_new_diagnostic',scope='Previously inspected698H1 development origins,three seeds,three corrected anchors. Separate2024chronological-prefix active-history error library2082pairs,one seed. Panels are never pooled.',
        authorization='User requests bounded improvements while retaining all prior positive directions; manuscript edits explicitly deferred.',
        fits=0,new_test_targets_read=False,manuscript_edits=False,budget_seconds=600,
        groups=['all','near1_4','middle5_8','far9_12','H12','state0_5','observed_active','observed_inactive','lowvol','chronological_fold'],
        attribution='For delta=corrected-anchor and e=anchor-truth, partition nochange,wrong-direction,helpful-without-crossing,helpful-crossing,harmful-overshoot,tied-crossing. Verify addedSSE=2e*delta+delta^2. Truth-dependent labels are diagnostic only, never router inputs.',
        gate='No additional fitted model until fresh independent data admission. No diagnosis/tuning using September outcomes. Same5GiBlaunch4GiBruntime,single numericalworker.',
        bindings={str(p):sha(p) for p in files},protected={str(p):sha(p) for p in protected},
        theory=[{'url':'https://arxiv.org/abs/0912.0902','basis':'Separate absolute and squared losses; evaluate both targets.'},{'url':'https://arxiv.org/abs/2205.04216','basis':'Conditional weighting must justify estimation cost relative to simple combinations.'},{'url':'https://jmlr.org/papers/v11/cawley10a.html','basis':'Do not select on repeatedly inspected test outcomes.'}]))
    print('Registered fixed-output diagnostic',flush=True)

def summarize(b,c,y,mask):
    b=b[mask].astype(float);c=c[mask].astype(float);y=y[mask].astype(float)
    e=b-y;d=c-b;z=c-y;changed=d!=0
    masks={
      'unchanged':~changed,
      'wrong_direction':changed&(e*d>=0),
      'helpful_without_crossing':changed&(e*d<0)&(abs(d)<=abs(e)),
      'helpful_crossing':changed&(e*d<0)&(abs(d)>abs(e))&(abs(z)<abs(e)),
      'harmful_overshoot':changed&(e*d<0)&(abs(z)>abs(e)),
      'tied_crossing':changed&(e*d<0)&(abs(d)>abs(e))&(abs(z)==abs(e))}
    assert np.all(sum(m.astype(int) for m in masks.values())==1)
    n=len(e)
    added_ae=abs(z)-abs(e);added_se=z*z-e*e
    pieces={k:dict(cells=int(m.sum()),added_AE=float(added_ae[m].sum()),added_SSE=float(added_se[m].sum())) for k,m in masks.items()}
    cross=float((2*e*d).sum());amplitude=float((d*d).sum());sse=float(added_se.sum())
    assert abs(cross+amplitude-sse)<1e-6*max(1,abs(sse))
    return dict(cells=n,changed_cells=int(changed.sum()),raw_MAE=float(abs(e).mean()) if n else None,corrected_MAE=float(abs(z).mean()) if n else None,
      raw_RMSE=float(np.sqrt(np.mean(e*e))) if n else None,corrected_RMSE=float(np.sqrt(np.mean(z*z))) if n else None,
      mean_raw_error=float(e.mean()) if n else None,mean_corrected_error=float(z.mean()) if n else None,
      added_AE=float(added_ae.sum()),added_SSE=sse,cross_term=cross,magnitude_term=amplitude,
      harmful_cells=int((added_ae>0).sum()),helpful_cells=int((added_ae<0).sum()),partition=pieces)

def main():
    global np
    p=read(H/'PROTOCOL.json');t0=time.monotonic()
    for path,h in (p['bindings']|p['protected']).items():assert sha(Path(path))==h,path
    with gate.exclusive('V20 finite fixed-output direction/amplitude diagnosis'):
        np,lim=gate.runtime(False)
        # Directly test the decomposition's mutually exclusive algebraic cases.
        q=summarize(np.array([1.,1.,1.,1.,1.,1.]),np.array([1.,2.,.5,-.5,-2.,-1.]),np.zeros(6),np.ones(6,dtype=bool))
        assert [v['cells'] for v in q['partition'].values()]==[1,1,1,1,1,1]
        write('status.json',dict(status='diagnosing',pid=os.getpid()))
        panelpath=T/'adaptive_experts_v4_20260929/panel.npz'
        assert sha(panelpath)==read(B/'adaptive_experts_v4_20260929/FEEDBACK_ADMISSION.json')['panel_sha256']
        with np.load(panelpath) as z:data={k:z[k] for k in ['truth','states','origins','days','observable_regime','low_volatility']}
        rows=[];v18=read(B/'mechanism_repair_v18_20260930/CAISO_MATCHED_RESULTS.json')
        folds=read(B/'adaptive_experts_v4_20260929/FOLDS.json')
        for record in v18['rows']:
            gate.guard();assert time.monotonic()-t0<600
            seed=record['seed'];anchor=record['anchor'];fp=T/'mechanism_repair_v18_20260930/CAISO/predictions'/f'{seed}_{anchor}.npz'
            with np.load(fp) as z:b=z['anchor'];c=z['prediction'];ids=z['indices'];assert np.array_equal(z['origins'],data['origins'][ids])
            y=data['truth'][ids];states=data['states'][ids];h=np.broadcast_to(np.arange(12)[None,None,:],y.shape)
            active=np.broadcast_to((data['observable_regime'][ids]==2)[...,None],y.shape)
            low=np.broadcast_to(data['low_volatility'][ids][...,None],y.shape)
            groups={'all':np.ones(y.shape,bool),'near1_4':h<4,'middle5_8':(h>=4)&(h<8),'far9_12':h>=8,'H12':h==11,'observed_active':active,'observed_inactive':~active,'lowvol':low}
            groups.update({f'state{s}':states==s for s in range(6)})
            groups.update({f'fold{f["id"]}':np.broadcast_to(np.isin(ids,f['evaluation'])[:,None,None],y.shape) for f in folds})
            vals={g:summarize(b,c,y,m) for g,m in groups.items()}
            assert abs(vals['all']['corrected_MAE']-record['corrected']['mae'])<1e-10
            days=[]
            for day in np.unique(data['days'][ids]):
                m=(data['days'][ids]==day);e=b[m]-y[m];z=c[m]-y[m]
                days.append(dict(day=int(day),cells=int(e.size),added_AE=float((abs(z)-abs(e)).sum()),added_SSE=float((z*z-e*e).sum())))
            rows.append(dict(seed=seed,anchor=anchor,groups=vals,days=days))
        # Earlier prefix-fitted specialist: only active-history pairs, not the complete panel.
        gate.guard()
        with np.load(T/'chronological_expert_pilot_v14_20260930/EXPERT_ERROR_LIBRARY.npz') as z:
            b=z['FULL'];c=z['SPECIALIST'];y=z['truth'];s=z['states'];issued=z['issued']
        h=np.broadcast_to(np.arange(12)[None,:],y.shape)
        groups={'all_active_pairs':np.ones(y.shape,bool),'near1_4':h<4,'far9_12':h>=8,'H12':h==11}
        groups.update({f'state{k}':s==k for k in range(6)})
        prefix={g:summarize(b,c,y,m) for g,m in groups.items()}
        for path,h in p['protected'].items():assert sha(Path(path))==h,path
        result=dict(at=datetime.now(timezone.utc).isoformat(),status='fixed_output_diagnosis_complete_pending_audit',protocol_sha256=sha(H/'PROTOCOL.json'),rows=rows,
          prefix_active_library=prefix,prefix_origin_node_pairs=len(b),prefix_dates=len(np.unique(issued//86400)),new_fits=0,new_test_targets_read=False,manuscript_changed=False,protected_hashes_unchanged=True,elapsed_seconds=time.monotonic()-t0)
        write('RESULT.json',result);write('status.json',dict(status='awaiting_separate_audit',pid=None))
        print(json.dumps({'status':'diagnosed','cases':len(rows),'prefix_pairs':len(b),'seconds':result['elapsed_seconds']}),flush=True)
if __name__=='__main__':
    if '--register' in sys.argv:register()
    else:
        try:main()
        except BaseException as e:
            write('STOP.json',dict(at=datetime.now(timezone.utc).isoformat(),error=repr(e),preserved=True));raise
