import pathlib,sys,time
gate=pathlib.Path(sys.argv[1])
end=time.monotonic()+40
while not gate.exists() and time.monotonic()<end: time.sleep(0.05)
