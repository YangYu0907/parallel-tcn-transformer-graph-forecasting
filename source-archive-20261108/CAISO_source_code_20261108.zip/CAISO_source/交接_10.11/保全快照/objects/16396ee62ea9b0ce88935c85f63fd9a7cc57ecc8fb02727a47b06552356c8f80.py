"""Metadata-only admission probe. Never downloads price targets or weather fields."""
import support as s
from urllib.request import urlopen,Request
from urllib.parse import urlencode
import xml.etree.ElementTree as ET
from datetime import datetime,timezone
from email.utils import parsedate_to_datetime
import hashlib,time
def main():
 s.write('SOURCE_PROTOCOL.json',dict(at=s.now(),code_sha256=s.sha(__file__),
  action='Read existing source decisions; inspect original forecast object metadata only',
  sample_dates=['20230601','20250601','20260101'],sample_cycle='00',lead_hour=1,
  sampling_rule='Fixed archive start/development month/subsequent development year boundary; no price/error selection',
  maximum_download_bytes=1000000,maximum_seconds=180,
  caveat='Sample metadata is not whole-panel admission or proof of incremental forecasting value',
  sources=['https://registry.opendata.aws/noaa-hrrr-pds/','https://www.nco.ncep.noaa.gov/pmb/products/hrrr/']))
 start=time.monotonic();records=[];downloaded=0
 root='https://noaa-hrrr-bdp-pds.s3.amazonaws.com/'
 for day in ['20230601','20250601','20260101']:
  try:
   assert time.monotonic()-start<180
   prefix=f'hrrr.{day}/conus/hrrr.t00z.wrfsfcf01.grib2'
   url=root+'?'+urlencode({'list-type':'2','prefix':prefix,'max-keys':'3'})
   with urlopen(Request(url,headers={'User-Agent':'CAISO-research-source-audit/1.0'}),timeout=20) as response:
    raw=response.read(150000);downloaded+=len(raw);assert downloaded<=1000000
   xml=ET.fromstring(raw);ns={'s':'http://s3.amazonaws.com/doc/2006-03-01/'}
   items=[{tag:el.find('s:'+tag,ns).text for tag in ['Key','LastModified','ETag','Size']} for el in xml.findall('s:Contents',ns)]
   assert items,'No archive listing for frozen date'
   objects=[]
   for item in items:
    if not item['Key'].endswith('.grib2'):continue
    with urlopen(Request(root+item['Key'],method='HEAD'),timeout=20) as response:headers=dict(response.headers.items())
    h={k.lower():v for k,v in headers.items()};modified=parsedate_to_datetime(h['last-modified']).astimezone(timezone.utc)
    cycle=datetime.strptime(day,'%Y%m%d').replace(tzinfo=timezone.utc)
    item.update(head_headers=headers,cycle_utc=cycle.isoformat(),last_modified_utc=modified.isoformat(),
     delivery_lag_minutes=(modified-cycle).total_seconds()/60,
     forecast_lead_hours=1,head_matches_listing_etag=h.get('etag')==item['ETag'],
     archived_bytes_downloaded=False,version_to_original_publication_fully_proven=False)
    assert item['head_matches_listing_etag']
    objects.append(item)
   records.append(dict(date=day,status='metadata_found',listing_url=url,listing_sha256=hashlib.sha256(raw).hexdigest(),objects=objects))
  except Exception as exc:records.append(dict(date=day,status='not_verified',error=repr(exc)))
  s.write('SOURCE_PROBE_PROGRESS.json',dict(at=s.now(),records=records,download_bytes=downloaded))
 prior=s.R/'routing_entry_v1_20261004/SOURCE_FOLLOWUP.json'
 flex=s.R/'next_research_design_20261004/source_resolution_02'
 fd=s.read(flex/'ADMISSION_RESULT.json');fc=s.read(flex/'FEATURE_CONTRACT.json')
 r=dict(at=s.now(),status='forward_curve_admission_not_complete',weather_metadata_probe=records,
  weather_admitted=False,weather_remaining=['Whole-panel exact forecast-cycle and lead availability coverage',
   'Bind downloaded bytes to object identity and original availability evidence',
   'Freeze node/weather mapping, missing policy, eligible lead and extraction recipe before outcome analysis',
   'Matched-information incremental utility evaluation'],
  RTD_DAM=dict(admitted_for_new_forward_curves=False,existing_followup=str(prior),followup_sha256=s.sha(prior),
   finding='Existing RTD/DAM values lack direct vintage/publisher-value linkage for full future curves; interval times are not publication times.'),
  flexible_ramp=dict(prior_status=fd['status'],scope=fd['scope'],contract=str(flex/'FEATURE_CONTRACT.json'),contract_sha256=s.sha(flex/'FEATURE_CONTRACT.json'),
   meaning=fc['physical_quantity'],new_forward_curve=False,already_tested_in_four_arm_development=True,
   avoid_repeat='Historical clearing awards cannot be relabelled future reserve margin or new forecast acceleration.'),
  download_bytes=downloaded,sealed_targets_read=False,new_fits=0)
 s.write('SOURCE_RESULT.json',r)
 print(__import__('json').dumps(dict(status=r['status'],samples=[dict(date=x['date'],status=x['status'],objects=x.get('objects',[])) for x in records],download_bytes=downloaded),ensure_ascii=False),flush=True)
if __name__=='__main__':main()
