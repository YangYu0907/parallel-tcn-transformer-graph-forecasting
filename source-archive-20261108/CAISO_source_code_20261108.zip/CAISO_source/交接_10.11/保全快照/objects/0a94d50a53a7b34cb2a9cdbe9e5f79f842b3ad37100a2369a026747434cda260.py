from common import *
import csv,hashlib
A4=ART.parent/'adaptive_experts_v4_20260929';A5=ART.parent/'adaptive_experts_v5_20260929';V4=B/'adaptive_experts_v4_20260929'
np=None
def materialize_train(cache,publications,seconds,origin,caps):
    from compile_math import age_at_origin
    history=np.array(cache[origin-288:origin],copy=True)
    history[:,:,19:21]=age_at_origin(publications,seconds,origin,caps)[:,None,:]
    return history
def new_features(history,nodes,sc,th):
    """One issue-time history[288,30,29]; no target argument exists."""
    assert history.shape==(288,30,29) and np.isfinite(history).all()
    q=np.array(th['thresholds'])[1];scale=np.array(sc['price_scale'])[0,:,0];z=history[:,:,0]*scale[None,:]/q[None,:]
    ext=abs(z)>1;cols=[];duration=[]
    for n in nodes:
        e=ext[:,n];run=int(np.cumprod(e[::-1]).sum());assert run>0,'Specialist requires an observed extreme history';duration.append(run)
        start=288-run;segment=z[start:,n];peak=int(np.argmax(abs(segment)));last=z[-1,n];peakvalue=segment[peak]
        cols.append([run/288,np.log1p(run),float(run==288),float(e.mean()),int(np.sum(e[1:]&~e[:-1]))/288,abs(peakvalue),float(run-1-peak)/288,(abs(peakvalue)-abs(last)),last-peakvalue])
    price=np.asarray(cols,float);extras=[]
    for size in (6,12,36,72,288):
        x=z[-size:,nodes];extras.extend([x[-1]-x[0],x.std(0),abs(x).mean(0)])
    price=np.column_stack([price,*extras])
    # Normalize all four component trajectories using unchanged TRAIN scalers.
    ctx=[]
    for ch in (1,2,3,15,16,23,24):
        x=history[:,nodes,ch]
        ctx.append(x[-1])
        for size in (12,72,288):ctx.extend([x[-1]-x[-size],x[-size:].mean(0),x[-size:].std(0)])
    for ch in (4,5,6,7,17,18,19,20):ctx.append(history[-1,nodes,ch])
    market=np.column_stack([np.median(z,axis=1),np.std(z,axis=1),ext.mean(1)])
    for k in range(3):
        for value in (market[-1,k],market[-1,k]-market[-12,k],market[-1,k]-market[-72,k],market[-72:,k].mean()):ctx.append(np.full(len(nodes),value))
    context=np.column_stack(ctx);assert np.isfinite(context).all()
    return price.astype(np.float32),context.astype(np.float32),np.array(duration)

def main():
    global np
    with gate.exclusive('V7 historical feature admission before training'):
        np,lim=gate.runtime(False);verify();start_budget()
        for p,h in gate.read(HERE/'SOURCE_BINDINGS.json')['bindings'].items():assert gate.sha(p)==h,p
        for p,h in gate.read(V4/'TRAIN_SOURCE_AUDIT.json')['bindings'].items():assert gate.sha(p)==h,p
        m=gate.read(B/'phase_sampling_support_v3_20260923/dataset/ADDITIVE/manifest.json');paths={k:gate.resolve(v['path']) for k,v in m['artifacts'].items()};sc=gate.read(paths['scalers.json']);th=gate.read(paths['state_thresholds.json'])
        with np.load(A5/'TRAIN_prepared.npz') as z:old={k:z[k] for k in z.files}
        feature=np.load(paths['features.npy'],mmap_mode='r');publications=np.load(paths['forecast_publications_seconds.npy'],mmap_mode='r');seconds=np.load(paths['timestamps_seconds.npy'],mmap_mode='r');caps=np.asarray(m['age_caps_minutes'])
        for name in ('forecast_publications_seconds.npy','timestamps_seconds.npy'):assert gate.sha(paths[name])==m['artifacts'][name]['sha256']
        N=len(old['origins']);px=np.empty((N,24),np.float32);cx=np.empty((N,90),np.float32);ages=np.zeros(N,int)
        for count,o in enumerate(np.unique(old['origins'])):
            ids=np.flatnonzero(old['origins']==o);hist=materialize_train(feature,publications,seconds,int(o),caps)
            p,c,d=new_features(hist,old['nodes'][ids],sc,th);px[ids]=p;cx[ids]=c;ages[ids]=d
            if count%400==0:tick(stage='TRAIN_historical_features',done=count)
        save(ART/'TRAIN_features.npz',price=np.column_stack([old['X'],px]),context=np.column_stack([old['X'],px,cx]),duration=ages,**{k:old[k] for k in ('origins','nodes','classes','fit','cal')})
        # Source admission reads historical covariates only, prior to specialist fitting.
        f=gate.read(H1/'FINAL_TEST_FREEZE.json');parent=gate.read(gate.resolve(f['input_freeze']))
        with np.load(gate.resolve(f['publication_routing'])) as z:meta={k:z[k] for k in z.files}
        meta['epoch']=int(meta['epoch']);sys.path.insert(0,str(B/'h1_feature_admission_v1_20260927'));from history import CandidateHistoryReader
        receipts={int(x['origin']):x['input_sha256'] for x in gate.read(gate.resolve(f['feature_receipts']))}
        with Path(parent['config']['node_panel']).open(encoding='utf-8-sig',newline='') as fd:tac=[r['TAC_AREA_ID'] for r in csv.DictReader(fd)]
        with np.load(A4/'panel.npz') as z:origins=z['origins'];oreg=z['observable_regime']
        with np.load(A5/'H1_features.npz') as z:oldx=z['X'];ho=z['origin_index'];hn=z['node']
        hp=np.empty((len(ho),24),np.float32);hc=np.empty((len(ho),90),np.float32);ha=np.zeros(len(ho),int);hashes=[]
        reader=CandidateHistoryReader(parent,meta)
        try:
            for j in np.unique(ho):
                ix=np.flatnonzero(ho==j);o=int(origins[j]);hist=reader.history(o,sc,tac,parent['age_caps']);h=hashlib.sha256(hist.tobytes()).hexdigest();assert h==receipts[o]
                p,c,d=new_features(hist,hn[ix],sc,th);hp[ix]=p;hc[ix]=c;ha[ix]=d;hashes.append(dict(origin=o,sha256=h));tick(stage='H1_historical_admission',origin=o)
        finally:reader.close()
        save(ART/'H1_features.npz',price=np.column_stack([oldx,hp]),context=np.column_stack([oldx,hp,hc]),duration=ha,origin_index=ho,node=hn)
        columns={name:int(np.sum(np.ptp(value,axis=0)>1e-9)) for name,value in [('TRAIN_context',cx[old['fit']]),('H1_context',hc)]};assert min(columns.values())>0
        firstexit=np.argmax(old['classes']<2,axis=1);hasexit=(old['classes']<2).any(1);firstexit=np.where(hasexit,firstexit,12)
        admission=dict(at=gate.now(),status='passed_before_training',H1_actual_input_hashes=hashes,H1_qualifying_node_origins=len(ho),TRAIN_qualifying_node_origins=N,TRAIN_fit=int(old['fit'].sum()),TRAIN_calibration=int(old['cal'].sum()),feature_variation=columns,
            TRAIN_window_censored=int(np.sum(ages==288)),H1_window_censored=int(np.sum(ha==288)),TRAIN_first_exit_within12=int(hasexit.sum()),TRAIN_no_exit_within12=int((~hasexit).sum()),covariate_contract='Existing admitted versions only. No new forecasts claimed available; source+version limits inherited.',new_independent_targets_read=False,
            artifacts={str(p):gate.sha(p) for p in (ART/'TRAIN_features.npz',ART/'H1_features.npz')})
        write(HERE/'DATA_ADMISSION.json',admission);tick(stage='feature_admission_complete');print(json.dumps({k:v for k,v in admission.items() if k!='H1_actual_input_hashes'}))
if __name__=='__main__':main()
