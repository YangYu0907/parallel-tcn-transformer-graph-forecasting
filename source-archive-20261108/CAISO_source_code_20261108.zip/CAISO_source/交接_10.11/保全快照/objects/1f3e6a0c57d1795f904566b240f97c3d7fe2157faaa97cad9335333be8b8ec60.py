from common import *
import psutil,ctypes,threading,shutil
def main():
    old=read(E/'LAUNCH.json');assert not psutil.pid_exists(old['manager_pid']);assert not(E/'MANAGER.lock').exists();assert not s.base.LOCK.exists()
    for n in ['PROTOCOL.json','LAUNCH.json','START_READY.json','STATUS.json','PROGRESS.json','FAILURE.json','stdout.log','stderr.log','exit.stdout.log','exit.stderr.log']:
        p=E/n
        if p.exists():shutil.copy2(p,E/('a1_'+n))
    test=E/'IO_TEST.json';write(test,dict(old=True));k=ctypes.windll.kernel32
    k.CreateFileW.restype=ctypes.c_void_p
    handle=k.CreateFileW(str(test),0x80000000,1,None,3,0,None);assert handle not in (0,None,ctypes.c_void_p(-1).value)
    def release():k.CloseHandle(ctypes.c_void_p(handle))
    timer=threading.Timer(.25,release);timer.start();start=time.monotonic();write(test,dict(new=True));timer.join();assert read(test)==dict(new=True)
    p=read(E/'PROTOCOL.json');p['bindings'][str(E/'common.py')]=sha(E/'common.py')
    fix=dict(at=now(),cause='Windows reader temporarily denies delete-sharing for PROGRESS.json; atomic replace needed finite retries.',change='Retry PermissionError at100ms up to20; no other OSError masked; model/data/penalty/scope unchanged.',test_passed=True,observed_retry_seconds=time.monotonic()-start,completed_fits_before_failure=0,calibration_or_evaluation_read=False,failed_pid=old['manager_pid'],failure_event_id=read(E/'STATUS.json').get('event_id'),original_protocol_sha256=sha(E/'a1_PROTOCOL.json'))
    write(E/'REPAIR.json',fix);p['implementation_repair']=fix;write(E/'PROTOCOL.json',p)
    (E/'START_READY.json').unlink();print(json.dumps(fix,ensure_ascii=False))
if __name__=='__main__':main()
