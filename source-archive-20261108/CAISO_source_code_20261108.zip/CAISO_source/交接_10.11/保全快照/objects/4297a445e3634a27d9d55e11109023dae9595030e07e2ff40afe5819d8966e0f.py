import support as s
import numpy as np
from experiment import features,labels,cif
import weather_source as w

def main():
 n=3;data=dict(last=np.zeros((n,30,29)),raw_last=np.ones((n,30))*40,cutoff=np.array([14100,17700,21300]))
 weather=dict(values=np.zeros((n,3,3,3)),cycles=np.array([0,3600,7200]));weather['values'][:,0]=np.array([280,281,283])[None,None,:];weather['values'][:,1]=3;weather['values'][:,2]=4
 for arm,dim in [('EXISTING',60),('WEATHER',78),('WEATHER_INTERACTION',90)]:
  x=features(data,weather,np.arange(n),arm,np.ones(30)*40,25);assert x.shape==(1080,dim) and np.isfinite(x).all()
  if arm!='EXISTING':
   # At 4h lead TMP=281K, speed=5m/s; at last horizon interpolation stays inside lead5.
   assert np.allclose(x[0,60:63],7.85) and np.allclose(x[0,63:66],5)
 y=np.zeros((2,30,12));y[0,:,4]=3;y[1,:,0]=-3
 tau,k,normal,risk,event=labels(y,np.zeros((2,30)),np.zeros(30),np.ones(30),np.ones(30)*2)
 assert np.all(tau[0]==4) and np.all(k[0]==1) and np.all(k[1]==2) and risk[0,0].sum()==5 and risk[1,0].sum()==1
 h=np.tile([.8,.15,.05],(2,30,12,1));p=cif(h);assert np.allclose(p[:,:,-1].sum(-1),1-.8**12)
 # Changing future outcome fixtures cannot change either of the input matrices.
 before=features(data,weather,np.arange(n),'WEATHER_INTERACTION',np.ones(30)*40,25);y[:]=1e6
 assert np.array_equal(before,features(data,weather,np.arange(n),'WEATHER_INTERACTION',np.ones(30)*40,25))
 # Independent official documentation locates Salt Lake City in HRRR chunk4.3.
 x,y=w.project(40.7608,-111.8910);ix=round((x+2697520.1425219304)/3000);iy=round((y+1587306.1525566636)/3000);assert (iy//150,ix//150)==(4,3)
 result=dict(at=s.now(),feature_dimensions=True,temperature_K_to_C=True,wind_magnitude=True,hourly_forecast_interpolation=True,first_entry_risk_censoring=True,cumulative_probability_mass=True,no_future_target_input=True,documented_projection_fixture=True,passed=True)
 s.write('QA.json',result);print(result)
if __name__=='__main__':main()
