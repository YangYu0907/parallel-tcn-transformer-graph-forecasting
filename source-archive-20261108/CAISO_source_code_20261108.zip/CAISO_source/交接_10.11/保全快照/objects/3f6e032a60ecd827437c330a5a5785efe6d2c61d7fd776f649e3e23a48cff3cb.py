"""One finite serial training+audit chain; terminal event only, no timer."""
import os,subprocess,traceback
import gcommon as c


def emit(kind,evidence):
    key='v21_graph_'+kind+'_'+c.sha(evidence)
    c.write(c.ROOT/'event_driven_automation/inbox'/(key+'.json'),dict(schema='caiso_research_event_v1',event_id=key,event=kind,evidence_path=str(evidence),at=c.now(),periodic=False))
    return key


def main():
    c.verify()
    try:
        for script in ('train.py','audit.py'):
            c.check()
            c.write(c.HERE/'status.json',dict(at=c.now(),pid=os.getpid(),event='step_process_started',script=script))
            p=subprocess.run(['D:/Documents/conda_envs/tcn_air/python.exe','-u',str(c.HERE/script)],cwd=str(c.HERE))
            if p.returncode:raise RuntimeError(script+' exit='+str(p.returncode))
        decision=c.read(c.HERE/'DECISION.json');evidence=c.HERE/'AUDIT.json'
        key=emit('audited_result_ready' if decision['passed'] else 'unexpected_result',evidence)
        c.write(c.HERE/'status.json',dict(at=c.now(),pid=os.getpid(),event='finite_mechanism_queue_completed',event_id=key,status='audited_complete',passed=decision['passed'],V7_preserved=True))
    except Exception as exc:
        failure=c.HERE/'FAILURE.json';c.write(failure,dict(at=c.now(),error=str(exc),traceback=traceback.format_exc(),V7_preserved=True))
        stopped=isinstance(exc,InterruptedError)
        key=None if stopped else emit('blocking_failure',failure)
        c.write(c.HERE/'status.json',dict(at=c.now(),pid=os.getpid(),event='user_stop_before_launch' if stopped else 'step_stopped_or_failed',classification='user_stop' if stopped else 'failure',event_id=key))
        raise

if __name__=='__main__':main()
