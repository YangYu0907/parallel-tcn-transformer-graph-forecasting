"""Post-hoc diagnosis of frozen forecasts; never changes predictions or thresholds."""
from common import *
import numpy as np
from scipy.special import expit, logit
from sklearn.metrics import average_precision_score

def score(y,q):
 y=y==1;q=np.clip(q,1e-12,1-1e-12);n=len(y)
 return dict(brier=float(np.mean((q-y)**2)),logloss=float(np.mean(np.where(y,-np.log(q),-np.log1p(-q)))),
  pos_brier=float(np.sum((1-q[y])**2)/n),neg_brier=float(np.sum(q[~y]**2)/n),
  prevalence=float(y.mean()),mean_probability=float(q.mean()),AP=float(average_precision_score(y,q)))
def main():
 p=verify();r=read(E/'RESULT.json');a=read(E/'AUDIT.json')
 event=read(B/'event_driven_automation/inbox/wi_3364c71ce24583cdf9cdb261.json')
 assert event['evidence_sha256']==sha(E/'RESULT.json')
 assert r['audit_sha256']==sha(E/'AUDIT.json') and a['predictions_sha256']==sha(E/'PREDICTIONS.npz')
 assert a['protocol_sha256']==sha(E/'PROTOCOL.json')
 assert a['source_audit_sha256']==sha(W/'dam_up_1010/SOURCE_AUDIT.json')
 ex=read(B/'event_driven_automation/process_monitors/mechanism_exit_18148_639271816875025112.exit.json')
 assert ex['terminal_handled'] and ex['manager_pid']==18148 and ex['manager_start_utc_ticks']==639271816875025112
 cells={};changes={};equ=0
 with s.base.numeric('Frozen DAM diagnosis: no new fitting and no target access'):
  with np.load(E/'INDICES.npz') as ix: ar={k:ix[k] for k in ix.files}
  for f in p['folds']:
   name=f['name'];fold_data={}
   for arm in p['arms']:
    guard()
    cell=E/name/arm;mark=read(cell/'COMPLETE.json')
    for path,h in mark['bindings'].items():assert sha(path)==h;equ+=1
    with np.load(cell/'PREDICTIONS.npz') as z:d={k:z[k] for k in z.files}
    q=d['evaluation'];cy=d['cal_y'];y=d['y'];on=d['alarm'];truth=y==1
    raw=expit(logit(np.clip(q,1e-12,1-1e-12))*r['results'][name][arm]['temperature'])
    c_raw=d['calibration_raw'][:,1]
    raw_thr=np.sort(c_raw[cy!=1])[int(np.ceil(.99*(np.sum(cy!=1)-1)))]
    invariant=bool(np.array_equal(raw>raw_thr,on))
    # Inverse mapping may differ at exact ties by roundoff: record but do not tune.
    fit_rate=float(np.mean(ar['y'][ar[name+'_fit']]==1))
    days=d['time']//86400;event_days=np.unique(days[truth]);hit_days=np.unique(days[truth&on])
    cells[name+'/'+arm]=dict(eval=score(y,q),cal=score(cy,d['calibration']),raw_eval_diagnostic=score(y,raw),
      training_prior_baseline=score(y,np.full(len(y),fit_rate)),fit_rate=fit_rate,
      raw_alarm_matches=invariant,raw_alarm_disagreements=int(np.count_nonzero((raw>raw_thr)!=on)),
      event_UTC_days=len(event_days),hit_UTC_days=len(hit_days),
      high_confidence_negative_cells=int(np.sum((q>=.5)&~truth)),
      high_confidence_positive_cells=int(np.sum((q>=.5)&truth)),
      high_confidence_negative_brier=float(np.sum(q[(q>=.5)&~truth]**2)/len(y)))
    fold_data[arm]=d
   for ctrl in ['HISTORY','COARSE']:
    v=fold_data[ctrl];c=fold_data[ctrl+'_DAM']
    assert all(np.array_equal(v[k],c[k]) for k in ['y','time','node'])
    pos=v['y']==1;on0=v['alarm'];on1=c['alarm'];n=len(pos)
    delta=(c['evaluation']-pos)**2-(v['evaluation']-pos)**2
    changes[name+'/'+ctrl]=dict(delta_brier=float(delta.mean()),positive_contribution=float(delta[pos].sum()/n),negative_contribution=float(delta[~pos].sum()/n),
      retained_TP=int(np.sum(pos&on0&on1)),lost_TP=int(np.sum(pos&on0&~on1)),new_TP=int(np.sum(pos&~on0&on1)),
      removed_FP=int(np.sum(~pos&on0&~on1)),new_FP=int(np.sum(~pos&~on0&on1)),
      net_TP=int(np.sum(pos&on1)-np.sum(pos&on0)),net_FP=int(np.sum(~pos&on1)-np.sum(~pos&on0)))
    assert abs(changes[name+'/'+ctrl]['positive_contribution']+changes[name+'/'+ctrl]['negative_contribution']-delta.mean())<1e-14
  verify()
 out=dict(at=now(),scope='Post-hoc exposed-development diagnosis; no model fit, no threshold/month selection, no new price targets',
  cells=cells,alarm_changes=changes,checksum_equalities=equ,protected_files_unchanged=18,event_evidence_matches=True,
  manager_exit_verified=True,new_model_fits=0,independent_person_review=False,
  audit_scope='same operator; separate checks and loss decomposition',V7_replaced=False)
 write(E/'DIAGNOSIS.json',out)
 print(json.dumps(out,ensure_ascii=False))
if __name__=='__main__':main()

