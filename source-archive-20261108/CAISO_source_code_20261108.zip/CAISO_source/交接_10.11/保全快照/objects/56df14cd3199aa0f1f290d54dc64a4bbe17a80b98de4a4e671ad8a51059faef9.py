from common import *
def main():
    with gate.exclusive('V7 posthoc diagnosis of frozen specialist; no new fits'):
        np,lim=gate.runtime(False);verify();audit=gate.read(HERE/'AUDIT.json');assert audit['status']=='passed' and audit['result_sha256']==gate.sha(HERE/'RESULT.json')
        A4=ART.parent/'adaptive_experts_v4_20260929'
        with np.load(A4/'panel.npz') as z:allorig=z['origins']
        with np.load(ART/'H1_features.npz') as z:ho=z['origin_index'];hn=z['node'];duration=z['duration']
        age=np.zeros((len(allorig),30),int);age[ho,hn]=duration
        folds=gate.read(B/'adaptive_experts_v4_20260929/FOLDS.json');ids=np.concatenate([f['evaluation'] for f in folds]);ages=np.broadcast_to(age[ids,:,None],(len(ids),30,12));rows=[];age_rows=[]
        for seed in SEEDS:
            with np.load(ART/'audited'/f'{seed}.npz') as z:
                y=z['truth'];st=z['states'];full=z['FULL']
                for arm in ('DURATION','CONTEXT_HULL','CONTEXT','CONTEXT_FIXED'):
                    pred=z[arm];d=pred-full;e=full-y;active=abs(d)>1e-9
                    for s in (3,4,5):
                        mask=st==s;rows.append(dict(seed=seed,arm=arm,state=s,cells=int(mask.sum()),active=int((mask&active).sum()),wrong_direction=int((mask&active&(d*e>0)).sum()),cross_target=int((mask&active&((pred-y)*e<0)).sum()),MAE_difference=float((abs(pred-y)-abs(e))[mask].mean()),MSE_difference=float(((pred-y)**2-e**2)[mask].mean())))
                    for name,mask in [('up_to_1h',(ages>0)&(ages<=12)),('1_to_3h',(ages>12)&(ages<=36)),('over_3h',ages>36)]:
                        if not mask.any():continue
                        age_rows.append(dict(seed=seed,arm=arm,observed_duration=name,cells=int(mask.sum()),MAE=float(abs(pred-y)[mask].mean()),FULL_MAE=float(abs(e)[mask].mean()),state_counts=[int((mask&(st==s)).sum()) for s in (3,4,5)]))
        write(HERE/'ATTRIBUTION_NUMERICAL.json',dict(at=gate.now(),status='posthoc_frozen_prediction_diagnosis',state_direction=rows,observed_duration_groups=age_rows,unit='dependent origin-node-horizon cells; not independent events',candidate_changed=False,new_test_targets_read=False))
        print('V7 attribution complete; predictions unchanged')
if __name__=='__main__':main()
