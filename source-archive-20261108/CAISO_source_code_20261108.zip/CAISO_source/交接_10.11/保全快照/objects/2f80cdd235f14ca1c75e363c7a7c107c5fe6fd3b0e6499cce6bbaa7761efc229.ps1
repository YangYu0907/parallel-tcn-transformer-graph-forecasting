param()
$ErrorActionPreference='Stop'
function Get-Sha256([string]$Path) {
    $algorithm=[Security.Cryptography.SHA256]::Create()
    $stream=[IO.File]::OpenRead($Path)
    try { return [BitConverter]::ToString($algorithm.ComputeHash($stream)).Replace('-','').ToLowerInvariant() }
    finally { $stream.Dispose(); $algorithm.Dispose() }
}
$branch=Split-Path -Parent $PSScriptRoot
$managerPath=Join-Path $PSScriptRoot 'source\manager.py'
$eventDir=Join-Path $branch 'event_driven_automation'
$bridgePath=Join-Path $PSScriptRoot 'watch_manager_exit.ps1'
$review=Get-Content -LiteralPath (Join-Path $PSScriptRoot 'MANAGER_REVIEW.json') -Raw -Encoding UTF8 | ConvertFrom-Json
$sealHash=Get-Sha256 (Join-Path $PSScriptRoot 'EXECUTION_SEAL.json')
$bridgeHash=Get-Sha256 $bridgePath
if ($review.status -ne 'passed' -or $review.independent -ne $true -or $review.execution_seal_sha256 -ne $sealHash -or $review.bridge_source_sha256 -ne $bridgeHash -or $review.bridge_actual_QA_passed -ne $true) { throw 'Independent manager/bridge review missing or stale' }
$pause=Get-Content -LiteralPath (Join-Path (Split-Path -Parent $branch) 'RESEARCH_PAUSED.json') -Raw -Encoding UTF8 | ConvertFrom-Json
if ($pause.status -ne 'resumed_by_user' -or $pause.stop_preparation_and_training) { throw 'Research paused' }
if (Test-Path -LiteralPath (Join-Path $PSScriptRoot 'queue\QUEUE.lock')) { throw 'Sampling manager already owns queue lock' }
$all=@(Get-CimInstance Win32_Process)
$duplicate=@($all | Where-Object { $_.Name -eq 'python.exe' -and $_.CommandLine -and $_.CommandLine.Contains($managerPath) })
if ($duplicate.Count -ne 0) { throw 'Sampling manager already running' }
$watchState=Get-Content -LiteralPath (Join-Path $eventDir 'status.json') -Raw -Encoding UTF8 | ConvertFrom-Json
$watch=@($all | Where-Object { $_.ProcessId -eq $watchState.pid -and $_.CommandLine -and $_.CommandLine.Contains((Join-Path $eventDir 'watch.ps1')) })
if ($watch.Count -ne 1) { throw 'Shared OS event listener is not alive' }
$tag=[guid]::NewGuid().ToString('N').Substring(0,12)
$launchDir=Join-Path $PSScriptRoot ('launch_'+$tag)
New-Item -ItemType Directory -Path $launchDir | Out-Null
$python='D:\Documents\conda_envs\tcn_air\python.exe'
& $python $managerPath check
if ($LASTEXITCODE -ne 0) { throw 'Metadata queue admission failed' }
& $python (Join-Path $PSScriptRoot 'launch_gate.py')
if ($LASTEXITCODE -ne 0) { throw 'Completed predecessor or resource admission failed' }
$manager=Start-Process -FilePath $python -ArgumentList @(('"'+$managerPath+'"'),'run') -WorkingDirectory $branch -WindowStyle Hidden -RedirectStandardOutput (Join-Path $launchDir 'manager.stdout.log') -RedirectStandardError (Join-Path $launchDir 'manager.stderr.log') -PassThru
$ticks=$manager.StartTime.ToUniversalTime().Ticks
$statusPath=Join-Path $PSScriptRoot 'queue\status.json'
$bridgeArgs=@('-NoProfile','-ExecutionPolicy','Bypass','-File',('"'+$bridgePath+'"'),'-ManagerProcessId',[string]$manager.Id,'-ManagerStartUtcTicks',[string]$ticks,'-ManagerScript',('"'+$managerPath+'"'),'-StatusPath',('"'+$statusPath+'"'))
$bridge=Start-Process -FilePath 'C:\Windows\System32\WindowsPowerShell\v1.0\powershell.exe' -ArgumentList $bridgeArgs -WorkingDirectory $branch -WindowStyle Hidden -RedirectStandardOutput (Join-Path $launchDir 'bridge.stdout.log') -RedirectStandardError (Join-Path $launchDir 'bridge.stderr.log') -PassThru
$record=[ordered]@{status='sampling_manager_and_OS_exit_bridge_launched_after_admitted_completion';at=[DateTime]::UtcNow.ToString('o');manager_pid=$manager.Id;manager_start_utc_ticks=$ticks;bridge_pid=$bridge.Id;shared_event_watcher_pid=$watchState.pid;prior96completion_verified=$true;manager_script=$managerPath;bridge_script=$bridgePath;directory=$launchDir;periodic_model_wakeup=$false;numerical_training_started_by_this_launch=$false;execution_seal_sha256=$sealHash;bridge_sha256=$bridgeHash}
$record | ConvertTo-Json -Depth 6 | Set-Content -LiteralPath (Join-Path $launchDir 'launch.json') -Encoding UTF8
$record | ConvertTo-Json -Depth 6