"""Separate loop-form arithmetic validation; no claims of external review."""
from diagnose import *

def main():
    verify();previous.checked(True);count=0
    with old.numeric('Separate component arithmetic audit; no training'):
        raw,times,admitted,m=sources();result=old.read(HERE/'RESULT.json')
        for panel in result['full_forward_panels']:
            fold=panel['fold']
            with np.load(R/f'two_regime_completion_20261004/REPLAY_fold{fold}.npz') as z:
                o=z['origins'];states=z['states'];days=z['days']
                for row in panel['rows']:
                    chunks=[];e=[];dates=[];obs=[];on=[];tn=[];last=[];future=[];ramps=[]
                    for h in (range(12) if row['horizons']=='H1-H12' else range(7,12)):
                        ii,nn=np.where(states[:,:,h]==row['state'])
                        x=np.asarray(raw[o[ii]+h,nn],float);a=np.asarray(raw[o[ii]-1,nn],float);lag=np.asarray(raw[o[ii]-13,nn],float)
                        chunks.append(x-a);dates.extend(days[ii]);obs.extend(ii);on.extend(zip(o[ii],nn));tn.extend(zip(o[ii]+h,nn));last.append(a);future.append(x);ramps.append(a-lag)
                        e.append(np.stack([z[f'BASE_{seed}'][ii,nn,h]-x[:,0] for seed in old.SEEDS]))
                    d=np.concatenate(chunks);assert len(d)==row['cells'];count+=1
                    if not len(d):continue
                    dc=abs(d[:,1:]);share=dc.sum(0)/dc.sum();align=np.array([sum(d[:,j]*d[:,0])/sum(d[:,0]**2) for j in [1,2,3]])
                    for field,value in [('abs_change_share',share),('signed_squared_change_alignment',align),('mean_abs_component_change',dc.mean(0)),('current_component_abs_mean',abs(np.concatenate(last)[:,1:]).mean(0)),('target_component_abs_mean',abs(np.concatenate(future)[:,1:]).mean(0)),('history_60min_component_abs_change',abs(np.concatenate(ramps)[:,1:]).mean(0))]:
                        assert np.allclose(row[field],value,rtol=1e-10,atol=1e-8),(fold,field);count+=1
                    assert row['dates']==len(set(dates)) and row['origins']==len(set(obs)) and row['origin_node_pairs']==len(set(on)) and row['target_node_pairs']==len(set(tn));count+=1
                    errors=np.concatenate(e,axis=1)
                    assert abs(row['base_MAE']-abs(errors).mean())<1e-9 and abs(row['base_RMSE_mean_router']-np.sqrt((errors**2).mean(1)).mean())<1e-9;count+=1
            for horizons in ['H1-H12','H8-H12']:
                assert sum(r['cells'] for r in panel['rows'] if r['horizons']==horizons)==len(o)*30*(12 if horizons=='H1-H12' else 5);count+=1
        for panel in result['load_probe_groups']:
            fold=panel['fold'];source=old.read(R/f'load_gate_probe_20261004/probe{fold}/RESULT.json')
            n=sum(g['cells'] for g in panel['groups']);difference=sum(g.get('total_brier_difference',0) for g in panel['groups'])/n
            expected=source['scores']['PRICE_LOAD']['brier']-source['scores']['PRICE']['brier']
            assert abs(difference-expected)<1e-12;count+=1
        assert old.parent.verify_protected()==18;count+=1
    old.write(HERE/'AUDIT.json',dict(at=old.now(),status='separate_component_accounting_replay_passed',checks=count,
        result_sha256=old.sha(HERE/'RESULT.json'),protected_files=18,models_fitted=0,new_test_targets_read=False,
        external_human_review=False,scope='Loop-form full-panel arithmetic and load-probe Brier-difference accounting, not causal validation'))
    print('Component audit passed',count)

if __name__=='__main__':main()
