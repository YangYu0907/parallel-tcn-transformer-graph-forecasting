"""Four bounded publication-ledger probes. No prices or forecast MW values."""
from pathlib import Path
from datetime import datetime,timezone
from urllib.request import Request,urlopen
from urllib.parse import urlencode
from collections import Counter,defaultdict
import sys,time,csv,io,json,zipfile,os
HERE=Path(__file__).resolve().parent;B=HERE.parent
sys.path.insert(0,str(B/'context_expert_v1_20260929'));import gate
ART=Path('C:/Users/于阳/CAISO_temporary_storage')/HERE.name

def main():
 gate.boundary();ART.mkdir(parents=True,exist_ok=True)
 jobs=[dict(label=label,market=market,start=a,end=b) for label,a,b in [('TRAIN','20240601T00:00-0000','20240608T00:00-0000'),('UNUSED_CANDIDATE','20260901T00:00-0000','20260908T00:00-0000')] for market in ['DAM','RTM']]
 p=dict(at=gate.now(),status='registered_before_metadata_requests',script_sha256=gate.sha(__file__),jobs=jobs,maximum_requests=4,request_gap_seconds=8,request_timeout_seconds=40,automatic_retry=False,
  purposes=['Identify exact public stress/supply/renewable report names and publication/version fields','Check presence in fixed early2024andSeptember2026week; does not admit a testperiod'],
  forbids=['price or forecastMWqueries','target numeric decoding','model training','oldperiodrelabeling'],scope_note='TRAIN label means historical development metadata only;June2024 is validation in V14. September2026 is an unused candidate requiring full future access audit.')
 gate.need(not (HERE/'PROTOCOL.json').exists(),'Do not duplicate a completed/probed request set')
 gate.write(HERE/'PROTOCOL.json',p)
 with gate.exclusive('V16 four metadata-only source feasibility probes'):
  results=[];last=-1e20
  for job in jobs:
   wait=8-(time.monotonic()-last)
   if wait>0:time.sleep(wait)
   gate.guard();last=time.monotonic();ident=job['label']+'_'+job['market']
   args=dict(queryname='ATL_PUB',market_run_id=job['market'],oasis_section='ALL',status='ALL',atlpubversion='ALL',version=1,startdatetime=job['start'],enddatetime=job['end'],resultformat=6)
   url='https://oasis.caiso.com/oasisapi/SingleZip?'+urlencode(args)
   row=dict(id=ident,job=job,url=url,at=gate.now())
   try:
    with urlopen(Request(url,headers={'User-Agent':'CAISO-academic-source-feasibility/1.0'}),timeout=40) as r:
     body=r.read(12_000_001);headers={k:r.headers[k] for k in ['Date','Content-Type','Last-Modified'] if r.headers[k]}
    gate.need(len(body)<=12_000_000,'Metadata body size guard')
    f=ART/(ident+'.zip');tmp=f.with_suffix('.tmp');tmp.write_bytes(body);os.replace(tmp,f)
    counts=Counter();versions=defaultdict(Counter);records=[];fields=set()
    with zipfile.ZipFile(io.BytesIO(body)) as z:
     for name in z.namelist():
      gate.need(name.lower().endswith('.csv'),'NonCSV response: '+z.read(name)[:300].decode('utf8','replace'))
      gate.need(z.getinfo(name).file_size<60_000_000,'Expansion guard')
      with z.open(name) as member:
       reader=csv.DictReader(io.TextIOWrapper(member,encoding='utf-8-sig',newline=''));fields.update(reader.fieldnames or [])
       gate.need({'REPORT_NAME','PUBLICATION_DATE_GMT','INTERVAL_START_GMT','INTERVAL_END_GMT','ATLPUBVERSION'}.issubset(fields),'Metadata schema')
       for rec in reader:
        if rec.get('STATUS')!='Push Completed' or rec.get('OASIS_REC_STAT')!='V':continue
        report=rec['REPORT_NAME'];counts[report]+=1;versions[report][rec['ATLPUBVERSION']]+=1
        records.append({k:rec.get(k) for k in ['REPORT_NAME','PUBLICATION_DATE_GMT','INTERVAL_START_GMT','INTERVAL_END_GMT','ATLPUBVERSION','PUBLICATION_ID','STATUS','OASIS_REC_STAT']})
    fp=ART/(ident+'.records.json');fp.write_text(json.dumps(records,ensure_ascii=False),encoding='utf-8')
    row.update(status='metadata_received',headers=headers,body=str(f),body_sha256=gate.sha(f),ledger=str(fp),ledger_sha256=gate.sha(fp),fields=sorted(fields),report_counts=dict(counts),versions={k:dict(v) for k,v in versions.items()})
   except Exception as exc:row.update(status='probe_failed',error=repr(exc))
   gate.write(HERE/(ident+'.json'),row);results.append(row);print(json.dumps(dict(id=ident,status=row['status'],reports=row.get('report_counts',{}))),flush=True)
  gate.write(HERE/'RESULT.json',dict(at=gate.now(),status='finite_source_probe_complete',probes=results,new_sources_admitted=False,new_confirmation_admitted=False,new_test_targets_read=False,training_started=False,needs='Map report economic meaning and exact historical source versions before numerical data use'))
if __name__=='__main__':main()
