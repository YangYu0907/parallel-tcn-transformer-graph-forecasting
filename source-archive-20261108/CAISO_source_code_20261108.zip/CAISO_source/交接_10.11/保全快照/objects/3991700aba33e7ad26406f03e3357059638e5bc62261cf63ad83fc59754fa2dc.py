"""Sparsify cross-neighbour allocation while preserving the learned self mass."""
import types
import torch


def sparsemax(z):
    z=z-z.max(-1,keepdim=True).values
    sorted_z,_=z.sort(dim=-1,descending=True)
    k=torch.arange(1,z.shape[-1]+1,device=z.device,dtype=z.dtype)
    sums=sorted_z.cumsum(-1)
    support=1+k*sorted_z>sums
    size=support.sum(-1,keepdim=True)
    tau=(sums.gather(-1,size-1)-1)/size
    return torch.clamp(z-tau,min=0)


def sparse_cross(adj):
    """All self weights are copied. Sparsemax selects among other markets only."""
    n=adj.shape[-1]
    rows=[]
    for i in range(n):
        others=[j for j in range(n) if j!=i]
        cross=adj[:,i,others]
        # log probabilities differ from original attention logits only by a
        # row constant; sparsemax is translation-invariant.
        allocation=sparsemax(torch.log(cross.clamp_min(1e-12)))
        cross_mass=cross.sum(-1,keepdim=True)
        positions={j:k for k,j in enumerate(others)}
        rows.append(torch.stack([adj[:,i,i] if j==i else allocation[:,positions[j]]*cross_mass[:,0] for j in range(n)],-1))
    return torch.stack(rows,1)


def attach(model):
    original=model.graph.dynamic_adjacency
    def revised(self,projected):
        adjacency,context=original(projected)
        return sparse_cross(adjacency),context
    model.graph.dynamic_adjacency=types.MethodType(revised,model.graph)
    return model


def synthetic_qa():
    a=torch.tensor([[[.2,.6,.2],[.4,.2,.4],[.7,.2,.1]]],dtype=torch.float64,requires_grad=True)
    b=sparse_cross(a)
    assert torch.allclose(b.sum(-1),a.sum(-1))
    assert torch.equal(b.diagonal(dim1=-2,dim2=-1),a.diagonal(dim1=-2,dim2=-1))
    assert (b>=0).all() and (b==0).any()
    assert torch.autograd.gradcheck(sparse_cross,(a,),eps=1e-6,atol=1e-4)
    assert torch.allclose(sparsemax(torch.tensor([[2.,1.],[0.,0.]])),torch.tensor([[1.,0.],[.5,.5]]))
    return 5
