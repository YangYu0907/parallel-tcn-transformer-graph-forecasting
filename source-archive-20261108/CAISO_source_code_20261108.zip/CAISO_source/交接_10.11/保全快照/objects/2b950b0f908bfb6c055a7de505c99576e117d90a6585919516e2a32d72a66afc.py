import fcommon as c
from datetime import datetime
def main():
    original=c.HERE/'diagnosis_io_repair_original'
    old=c.read(original/'DIAGNOSIS_SEAL.json')
    changed=[]
    for p,h in old['bindings'].items():
        if c.sha(p)!=h:changed.append(p)
    assert changed==[str(c.HERE/'diagnosis.py')]
    assert c.sha(original/'diagnosis.py')==old['bindings'][str(c.HERE/'diagnosis.py')]
    start=datetime.fromisoformat(c.read(original/'DIAGNOSIS_LAUNCH.json')['at'].replace('Z','+00:00'))
    stop=datetime.fromisoformat(c.read(original/'DIAGNOSIS_FAILURE.json')['at'])
    old['bindings'][str(c.HERE/'diagnosis.py')]=c.sha(c.HERE/'diagnosis.py')
    old.update(at=c.now(),amendment='Metadata writer retry for transient Windows sharing violation; all scientific computations, inputs and model settings unchanged.')
    c.write(c.HERE/'DIAGNOSIS_IO_REPAIR.json',dict(at=c.now(),status='repaired_before_rerun',previous_seconds_charged=(stop-start).total_seconds(),
        original_seal_sha256=c.sha(original/'DIAGNOSIS_SEAL.json'),original_script_sha256=c.sha(original/'diagnosis.py'),new_script_sha256=c.sha(c.HERE/'diagnosis.py'),
        reason='Windows PermissionError at progress-file atomic os.replace while status was being read. Numerical result files and checkpoints unaffected.',
        change='Finite retry of progress JSON replacement only; carry previous elapsed seconds into original1800s cap.',model_training_restarted=False,new_test_targets_read=False))
    c.write(c.HERE/'DIAGNOSIS_SEAL.json',old)
    print('I/O-only repair sealed; original evidence preserved.')
if __name__=='__main__':main()
