import common as c
import os, subprocess, traceback

def emit(kind,path):
    key='v26_temporal_memory_'+kind+'_'+c.sha(path)
    c.gate.write(c.B/'event_driven_automation/inbox'/(key+'.json'),dict(schema='caiso_research_event_v1',
         event_id=key,event=kind,evidence_path=str(path),at=c.now(),periodic=False))
    return key

def handoff(status,active,evidence):
    h=c.read(c.B/'HANDOFF.json')
    h.update(at=c.now(),status=status,research_training_active=active,numeric_diagnostic_active=active,
             complete_research_experiment=False,
             next_action='V26 single-worker temporal-memory matched development pilot; preserve V7. Follow status and audited gate before any integration.',
             temporal_memory_v26=dict(directory=str(c.HERE),manager_pid=os.getpid(),active=active,evidence=evidence))
    c.gate.write(c.B/'HANDOFF.json',h)

def main():
    try:
        c.verify();assert not (c.HERE/'AUDIT.json').exists(),'Already completed'
        handoff('V26_temporal_memory_running_V7_retained',True,str(c.HERE/'status.json'))
        for script in ('run.py','audit.py'):
            if script=='run.py' and (c.HERE/'RESULT.json').exists():continue
            c.check(True)
            c.write(c.HERE/'status.json',dict(at=c.now(),pid=os.getpid(),event='step_process_started',script=script))
            proc=subprocess.run(['D:/Documents/conda_envs/tcn_air/python.exe','-u',str(c.HERE/script)],cwd=str(c.HERE))
            if proc.returncode:raise RuntimeError(script+' exit='+str(proc.returncode)+'; inspect checkpoint before resumption')
        d=c.read(c.HERE/'DECISION.json');a=c.read(c.HERE/'AUDIT.json')
        assert a['status']=='passed' and a['decision_sha256']==c.sha(c.HERE/'DECISION.json')
        key=emit('audited_result_ready' if d['passed'] else 'unexpected_result',c.HERE/'AUDIT.json')
        c.write(c.HERE/'status.json',dict(at=c.now(),pid=os.getpid(),event='finite_mechanism_queue_completed',status='audited_complete',event_id=key,screen_passed=d['passed']))
        handoff('V26_temporal_memory_audited_V7_retained',False,str(c.HERE/'DECISION.json'))
    except BaseException as exc:
        stopped=isinstance(exc,InterruptedError)
        try:c.gate.boundary()
        except InterruptedError:stopped=True
        if any((c.HERE/n).exists() for n in ('STOP_REQUESTED','STOP_REQUESTED.json')):stopped=True
        path=c.HERE/'FAILURE.json';c.write(path,dict(at=c.now(),error=str(exc),traceback=traceback.format_exc(),V7_preserved=True))
        key=None if stopped else emit('blocking_failure',path)
        c.write(c.HERE/'status.json',dict(at=c.now(),pid=os.getpid(),event='user_stop_before_launch' if stopped else 'step_stopped_or_failed',
                                       classification='user_stop' if stopped else 'failure',event_id=key))
        handoff('V26_paused_or_blocked_V7_retained',False,str(path));raise

if __name__=='__main__':main()
