"""Fixed-sample original GRIB decoding and archive parity; no price targets."""
from pathlib import Path
from datetime import datetime, timezone
import sys, time, json, traceback

P = Path(__file__).resolve().parent
R = P.parent
B = R.parent
A = B.parents[2]
H = R / 'historical_weather_admission_20261005'
W = R / 'weather_information_20261004'
sys.path.insert(0, str(A / '老师意见修订_20261003'))
import revision_common as base
base.ROOT = P
sys.path[:0] = [str(P / 'vendor'), str(W / 'vendor'), str(W)]
import numpy as np
import eccodes as ec
import weather_source as ws
ws.N = P / 'zarr_parity'


def main():
    protocol = base.read(P / 'PROTOCOL.json')
    assert base.sha(H / 'GRIB_BYTE_PROOF.json') == protocol['source_proof_sha256']
    proof = base.read(H / 'GRIB_BYTE_PROOF.json')
    assert len(proof['rows']) == 36
    start = time.monotonic()
    rows, geometry, size = [], None, 0
    assert not (P / 'RESULT.json').exists(), 'Completed proof must not be rerun'
    with base.numeric('fixed 36-message GRIB value parity; zero model fits'):
        base.verify_protected()
        for date in protocol['dates']:
            base.guard()
            assert time.monotonic() - start < protocol['max_seconds']
            cycle = int(datetime.fromisoformat(date + 'T12:00:00+00:00').timestamp())
            archive = ws.read_cycle(cycle, cycle + 3 * 3600 + 55 * 60)
            base.write(P / ('zarr_' + date + '.json'), archive)
            for receipt in proof['rows']:
                if receipt['date'] != date:
                    continue
                base.guard()
                assert time.monotonic() - start < protocol['max_seconds']
                path = Path(receipt['local'])
                assert base.sha(path) == receipt['message_sha256']
                with path.open('rb') as f:
                    handle = ec.codes_grib_new_from_file(f)
                    try:
                        assert handle is not None
                        assert ec.codes_get(handle, 'dataDate') == int(date.replace('-', ''))
                        assert ec.codes_get(handle, 'dataTime') == 1200
                        assert ec.codes_get(handle, 'forecastTime') == receipt['lead']
                        assert ec.codes_get(handle, 'gridDefinitionTemplateNumber') == 30
                        nx, ny = int(ec.codes_get(handle, 'Nx')), int(ec.codes_get(handle, 'Ny'))
                        if geometry is None:
                            geometry = []
                            for name, lat, lon in protocol['points']:
                                nearest = ec.codes_grib_find_nearest(handle, lat, lon, npoints=1)[0]
                                idx = int(nearest['index'])
                                geometry.append(dict(name=name, index=idx, x=idx % nx, y=idx // nx,
                                                     latitude=float(nearest['lat']), longitude=float(nearest['lon']),
                                                     distance_km=float(nearest['distance'])))
                        for g, zg in zip(geometry, archive['geometry']):
                            assert (g['x'], g['y']) == (zg['x'], zg['y']), (g, zg)
                        values = ec.codes_get_values(handle)
                        assert values.size == nx * ny
                        raw = np.asarray([values[g['index']] for g in geometry])
                        del values
                        variable = receipt['variable']
                        vi = ['TMP', 'UGRD', 'VGRD'].index(variable)
                        li = protocol['leads'].index(receipt['lead'])
                        level = '2m_above_ground' if vi == 0 else '10m_above_ground'
                        root = datetime.fromtimestamp(cycle, timezone.utc).strftime('sfc/%Y%m%d/%Y%m%d_%Hz_fcst.zarr/')
                        md_bytes, _ = ws.get(root + level + '/' + variable + '/.zmetadata')
                        md = json.loads(md_bytes)['metadata']
                        dtype = np.dtype(md[level + '/' + variable + '/.zarray']['dtype'])
                        expected = raw.astype(dtype).astype(np.float64)
                        observed = np.asarray(archive['values'])[vi, :, li]
                        # Archive encoding rounding is tested explicitly, not hidden by broad tolerance.
                        rounding = float(np.max(np.abs(observed - expected)))
                        assert np.allclose(observed, expected, rtol=0, atol=1e-5), (receipt['local'], raw.tolist(), observed.tolist(), dtype.str)
                        units = str(ec.codes_get(handle, 'units'))
                        row = dict(date=date, variable=variable, lead=receipt['lead'], original_sha256=receipt['message_sha256'],
                                   original_available=receipt['headers']['Last-Modified'], grib_units=units,
                                   archive_dtype=dtype.str, grib_values=raw.tolist(), archive_values=observed.tolist(),
                                   max_rounding_adjusted_difference=rounding,
                                   max_raw_difference=float(np.max(np.abs(observed - raw))),
                                   original_bytes=receipt['bytes'], nx=nx, ny=ny,
                                   ecCodes_version=ec.codes_get_api_version(), archive_timely=archive['admitted'])
                        rows.append(row)
                    finally:
                        if handle is not None:
                            ec.codes_release(handle)
            size = sum(f.stat().st_size for f in (P / 'zarr_parity' / 'objects').glob('*.bin'))
            assert size <= protocol['max_download_bytes']
            base.write(P / 'PROGRESS.json', dict(at=base.now(), completed_messages=len(rows), downloaded_bytes=size,
                                               elapsed_seconds=time.monotonic() - start, model_fits=0))
            print(json.dumps(dict(date=date, checked_messages=len(rows), downloaded_bytes=size), ensure_ascii=False), flush=True)
        with np.load(H / 'SHORT_CONTEXT_METADATA_POPULATION.npz', allow_pickle=False) as pop:
            cut = pop['cutoff'][pop['eligible']]
            cycles = (cut // 3600 - 3) * 3600
            cycle_count = int(np.unique(cycles).size)
            origin_count = int(cut.size)
        elapsed = time.monotonic() - start
        result = dict(at=base.now(), status='fixed_sample_source_value_proof_completed', passed=True,
                      decoded_messages=len(rows), verified_values=len(rows) * 3, geometry=geometry,
                      grid_projection='Lambert conformal, raw archived wind components; no nodal physical mapping claimed',
                      rows=rows, downloaded_archive_bytes=size, seconds=elapsed,
                      input_population_origins=origin_count, unique_forecast_cycles=cycle_count,
                      approximate_full_grib_bytes=cycle_count * proof['downloaded_bytes'] / 4,
                      approximate_full_zarr_bytes=cycle_count * size / 4,
                      estimates_are_only_four_cycle_extrapolations=True,
                      full_origin_source_admission=False, new_price_targets_read=False, model_fits=0, V7_replaced=False,
                      protected_files_unchanged=base.verify_protected(),
                      qualification='Late Zarr objects are decoder cross-checks, not admitted as forecast-time inputs. All actual origins still require original source/version availability validation.')
        base.write(P / 'RESULT.json', result)
        base.write(P / 'STATUS.json', dict(at=base.now(), status='completed', model_fits=0, numerical_worker_active=False))
        print(json.dumps({k: v for k, v in result.items() if k not in ['rows', 'geometry']}, ensure_ascii=False), flush=True)


if __name__ == '__main__':
    try:
        main()
    except Exception as exc:
        base.write(P / 'FAILURE.json', dict(at=base.now(), error=repr(exc), traceback=traceback.format_exc(), model_fits=0))
        raise
