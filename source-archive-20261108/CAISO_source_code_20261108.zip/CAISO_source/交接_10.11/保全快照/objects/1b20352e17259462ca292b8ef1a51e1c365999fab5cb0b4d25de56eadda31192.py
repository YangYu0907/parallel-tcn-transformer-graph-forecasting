"""Six finite frozen-FULL adapter runs; GLOBAL versus OFFHOUR with denseJune selection."""
import argparse,copy,gc,hashlib,json,random,sys,uuid
import gate
np=None;torch=None
def fp(model):
    h=hashlib.sha256()
    for key,value in sorted(model.state_dict().items()):
        h.update(key.encode());h.update(value.detach().cpu().contiguous().numpy().tobytes())
    return h.hexdigest()
def opt_for(model):
    return torch.optim.AdamW(model.adapter.parameters(),lr=.001,weight_decay=.0001,betas=(.9,.999),eps=1e-8)
def rng_get(rng):
    return dict(torch=torch.get_rng_state().clone(),numpy_global=np.random.get_state(),numpy_generator=copy.deepcopy(rng.bit_generator.state),python=random.getstate())
def rng_set(state,rng):
    torch.set_rng_state(state['torch']);np.random.set_state(state['numpy_global']);rng.bit_generator.state=state['numpy_generator'];random.setstate(state['python'])
def checkpoint(run,identity,student,opt,rng,state,name=None):
    p=run/'checkpoints'/(name or ('c_'+uuid.uuid4().hex+'.pt'))
    saved=dict(identity=identity,state_dict=copy.deepcopy(student.state_dict()),optimizer=copy.deepcopy(opt.state_dict()),
        rng=rng_get(rng),progress=copy.deepcopy(state),model_training=student.training,scope='frozen_full_adapter_only')
    gate.atomic(p,lambda f:torch.save(saved,f))
    receipt=dict(path=gate.rel(p),sha256=gate.sha(p),identity=identity,steps=state['steps'],
        epoch=state['epoch'],phase=state['phase'],at=gate.now())
    gate.write(p.with_suffix('.receipt.json'),receipt);gate.write(run/'latest.json',receipt,True)
    return receipt
def recover(run,identity):
    rs=[]
    for p in (run/'checkpoints').glob('*.receipt.json'):
        r=gate.read(p);target=gate.inside(r['path'])
        gate.need(target.is_relative_to(run/'checkpoints') and target.with_suffix('.receipt.json')==p,'Receipt location mismatch')
        gate.need(r['identity']==identity and gate.sha(target)==r['sha256'],'Checkpoint identity/hash mismatch')
        rs.append(r)
    if (run/'latest.json').exists():gate.need(gate.read(run/'latest.json') in rs,'Pointer has no committed receipt')
    if not rs:return None
    receipt=max(rs,key=lambda x:(x['steps'],x['epoch'],x['phase']=='epoch_complete',x['at']))
    saved=torch.load(gate.inside(receipt['path']),map_location='cpu',weights_only=False)
    gate.need(saved['identity']==identity and saved['progress']['steps']==receipt['steps'],'Payload/receipt mismatch')
    return saved
def evaluate(model,data,part,order):
    import reductions as r
    origins=data.origins[part];n=len(origins)
    pred=np.empty((n,30,12),np.float64);truth=np.empty_like(pred);codes=np.empty(pred.shape,np.uint8)
    q=np.array(gate.read(data.paths['state_thresholds.json'])['thresholds'],np.float64)
    model.eval();fingerprint=fp(model);rng=torch.get_rng_state().clone()
    with torch.inference_mode():
        for start in range(0,len(order),4):
            gate.guard();ids=order[start:start+4];x,y=data.batch(part,ids)
            hourly=torch.from_numpy(((data.times[origins[ids]]//300)%12==0).copy())
            gate.need(np.array_equal(hourly.numpy(),origins[ids]%12==0),'Timestamp/index phase mismatch')
            p=model(torch.from_numpy(x),hourly)['prediction'].cpu().numpy().astype(np.float64)
            pred[ids]=p*data.scale[None,:,None]+data.center[None,:,None]
            truth[ids]=y.astype(np.float64)*data.scale[None,:,None]+data.center[None,:,None]
            codes[ids]=r.codes(truth[ids],x[:,-1,:,0],data.center,data.scale,q)
    gate.need(fp(model)==fingerprint and torch.equal(rng,torch.get_rng_state()),'Evaluation changed model/RNG')
    gate.need(np.isfinite(pred).all() and np.isfinite(truth).all(),'Nonfinite prediction')
    return dict(origins=origins.copy(),prediction=pred,truth=truth,codes=codes)
def save_eval(run,name,arrays):
    p=run/'evaluation'/(name+'_'+uuid.uuid4().hex+'.npz')
    gate.atomic(p,lambda f:np.savez(f,**arrays))
    return dict(path=gate.rel(p),sha256=gate.sha(p))
def run(case_id,resume):
    global np,torch
    seal=gate.verify();case=next(c for c in seal['cases'] if c['id']==case_id)
    folder=gate.HERE/'runs'/case_id
    identity=dict(case=case,seal_sha256=gate.sha(gate.SEAL),protocol_sha256=gate.sha(gate.HERE/'PROTOCOL.json'))
    if folder.exists():gate.need(resume,'Existing pilot requires explicit resume')
    elif resume:raise RuntimeError('Cannot resume absent pilot')
    with gate.exclusive('adapter_'+case_id):
        np,torch,limiter=gate.runtime()
        identity['runtime']=dict(python=sys.version,torch=torch.__version__,numpy=np.__version__,threads=1)
        sys.path.append(str(gate.COMMON))
        import reductions as r
        from compiled_data import CompiledData
        from models.factory import build_backbone
        from math_ops import step
        from adapter import AdaptedFULL
        data=CompiledData(seal['dataset_manifest'])
        diag=np.load(gate.inside(seal['train_diagnostic']),allow_pickle=False)
        gate.need(diag.shape==(288,) and np.isin(diag,data.origins['train_all']).all() and (diag+12<=210528).all(),'TRAIN diagnostic invalid')
        data.origins['diagnostic']=diag
        limits=gate.read(data.paths['context_limits.json'])['limits']
        def parent_model(parent,trainable):
            path=gate.inside(parent['selected_checkpoint'])
            gate.need(gate.sha(path)==seal['bindings'][gate.rel(path)],'Parent checkpoint changed')
            saved=torch.load(path,map_location='cpu',weights_only=False)
            gate.need(saved['identity']==parent['identity'] and saved['scope']=='backbone_only','Parent scope/identity mismatch')
            m=build_backbone('FULL',case['seed'],limits);m.load_state_dict(saved['state_dict'],strict=True);m.eval()
            if not trainable:m.requires_grad_(False)
            return m
        base=parent_model(case['parent'],False)
        student=AdaptedFULL(base,case['seed'],case['arm'])
        base_fp=fp(base);initial_fp=fp(student)
        gate.need(sum(p.numel() for p in student.parameters() if p.requires_grad)==552,'Adapter parameter budget')
        torch.manual_seed(case['seed']+800000);np.random.seed(case['seed']);random.seed(case['seed'])
        rng=np.random.default_rng(case['seed']+800000)
        opt=opt_for(student)
        start=dict(identity=identity,student_initial_fingerprint=initial_fp,base_fingerprint=base_fp,
            active_parameters=sum(p.numel() for p in student.parameters() if p.requires_grad),
            initializer=case['parent']['selected_checkpoint'],adapter_initial_fingerprint=fp(student.adapter))
        if (folder/'run_start.json').exists():gate.need(gate.read(folder/'run_start.json')==start,'Initialization changed')
        else:gate.write(folder/'run_start.json',start)
        state=dict(phase='initializing',epoch=0,steps=0,offset=0,order=None,epochs=[],supervised_sum=0.,gradient_sum=0.)
        saved=recover(folder,identity) if resume else None
        if saved:
            student.load_state_dict(saved['state_dict'],strict=True);opt.load_state_dict(saved['optimizer'])
            rng_set(saved['rng'],rng);student.train(saved['model_training']);state=saved['progress'];del saved
            gate.need(0<=state['epoch']<=2 and 0<=state['steps']<=2016 and state['phase'] in ('initializing','train','epoch_complete'),'Invalid resume cursor')
            if state['phase']=='train':
                gate.need(state['offset']%4==0 and 0<=state['offset']<=4032 and np.array_equal(np.sort(state['order']),np.arange(4032)),'Resume order/cursor invalid')
            elif state['phase']=='epoch_complete':
                gate.need(state['steps']==state['epoch']*1008,'Completed-epoch step mismatch')
            for group in opt.param_groups:
                gate.need(group['lr']==.001 and group['weight_decay']==.0001 and group['betas']==(.9,.999) and group['eps']==1e-8,'Optimizer changed')
        dense0=data.origins['june_dense'];reg0=data.origins['june']
        panel0,_=r.panels(dense0,reg0)
        selection_order=np.r_[panel0['June284'],np.flatnonzero(~np.isin(np.arange(len(dense0)),panel0['June284']))]
        def completed_epoch(epoch):
            arrays=evaluate(student,data,'june_dense',selection_order)
            evalref=save_eval(folder,'epoch'+str(epoch)+'_dense_selection',arrays)
            if epoch==0:
                ref=gate.read(gate.inside(case['parent']['dense_receipt']))
                gate.need(gate.sha(gate.inside(ref['artifact']))==ref['artifact_sha256'],'Frozen parent dense reference changed')
                with np.load(gate.inside(ref['artifact']),allow_pickle=False) as z:original=z['prediction']
                gate.need(np.array_equal(arrays['prediction'],original),'Warm-start dense prediction differs')
            filename='e'+str(epoch)+'_'+uuid.uuid4().hex+'.pt'
            metrics=r.headline(arrays['prediction']-arrays['truth'])
            state['epochs'].append(dict(epoch=epoch,selection_metrics=metrics,evaluation=evalref,
                checkpoint=gate.rel(folder/'checkpoints'/filename),steps=state['steps'],
                train_supervised_mean=None if epoch==0 else state['supervised_sum']/4032))
            state.update(phase='epoch_complete',offset=0,order=None)
            checkpoint(folder,identity,student,opt,rng,state,filename)
            print(json.dumps(dict(event='epoch_complete',case=case_id,epoch=epoch,metrics=metrics)),flush=True)
        try:
            if state['phase']=='initializing':completed_epoch(0)
            while state['phase']=='train' or state['epoch']<2:
                gate.guard()
                if state['phase']=='epoch_complete':
                    epoch=state['epoch']+1;data.set_epoch(4+epoch)
                    gate.need(len(data.origins['train'])==4032,'Sampling budget changed')
                    state.update(phase='train',epoch=epoch,offset=0,order=rng.permutation(4032),supervised_sum=0.,gradient_sum=0.)
                    checkpoint(folder,identity,student,opt,rng,state)
                epoch=state['epoch'];data.set_epoch(4+epoch);student.train();gate.need(not student.base.training,'Frozen backbone mode')
                gate.need(state['steps']==(epoch-1)*1008+state['offset']//4,'Resume cursor/step mismatch')
                while state['offset']<4032:
                    gate.boundary()
                    start_idx=state['offset'];ids=state['order'][start_idx:start_idx+4]
                    origins=data.origins['train'][ids]
                    gate.need((origins>=288).all() and (origins+12<=210528).all(),'TRAIN target cutoff')
                    x,y=data.batch('train',ids)
                    hourly=torch.from_numpy(((data.times[origins]//300)%12==0).copy())
                    gate.need(np.array_equal(hourly.numpy(),origins%12==0),'TRAIN phase mismatch')
                    sv,gn=step(student,opt,torch.from_numpy(x),torch.from_numpy(y),hourly)
                    state['steps']+=1;state['offset']+=len(ids)
                    state['supervised_sum']+=sv*len(ids);state['gradient_sum']+=gn*len(ids)
                    if state['steps']%32==0 or state['offset']==4032:
                        gate.need(fp(student.base)==base_fp,'Frozen base changed during update')
                        checkpoint(folder,identity,student,opt,rng,state);gate.guard()
                        print(json.dumps(dict(event='adapter_progress',case=case_id,steps=state['steps'],epoch=epoch,at=gate.now())),flush=True)
                completed_epoch(epoch)
            gate.need(state['steps']==2016 and [x['epoch'] for x in state['epochs']]==[0,1,2],'Finite pilot budget incomplete')
            gate.need(fp(student.base)==base_fp and all(p.grad is None for p in student.base.parameters()),'Frozen base changed')
            best=state['epochs'][0]
            for row in state['epochs'][1:]:
                if row['selection_metrics']['mae']<best['selection_metrics']['mae']-1e-6:best=row
            def restore_epoch(row):
                path=gate.inside(row['checkpoint']);receipt=gate.read(path.with_suffix('.receipt.json'))
                gate.need(gate.sha(path)==receipt['sha256'],'Frozen epoch changed')
                saved=torch.load(path,map_location='cpu',weights_only=False)
                student.load_state_dict(saved['state_dict'],strict=True);student.eval();del saved;gc.collect()
            restore_epoch(best)
            dense=data.origins['june_dense'];registered=data.origins['june']
            panel_ids,blocks=r.panels(dense,registered)
            gate.need((len(dense),len(registered),len(blocks))==(3397,284,278),'Common panels changed')
            regpos=panel_ids['June284'];order=np.r_[regpos,np.flatnonzero(~np.isin(np.arange(len(dense)),regpos))]
            dense_arrays=evaluate(student,data,'june_dense',order)
            dense_ref=save_eval(folder,'selected_dense',dense_arrays)
            with np.load(gate.inside(best['evaluation']['path']),allow_pickle=False) as z:
                gate.need(np.array_equal(dense_arrays['prediction'],z['prediction']),'Selected dense regression')
            error=dense_arrays['prediction']-dense_arrays['truth']
            panels={name:r.breakdown(error[ix],dense_arrays['codes'][ix],dense[ix]) for name,ix in panel_ids.items()}
            curves=[]
            for row in state['epochs']:
                restore_epoch(row)
                arr=evaluate(student,data,'diagnostic',np.arange(288))
                reference=save_eval(folder,'epoch'+str(row['epoch'])+'_train',arr)
                curves.append(dict(epoch=row['epoch'],evaluation=reference,metrics=r.breakdown(arr['prediction']-arr['truth'],arr['codes'],diag)))
            gate.verify()
            result=dict(status='adapter_run_completed_pending_numeric_audit',at=gate.now(),identity=identity,
                epochs=state['epochs'],selected_epoch=best['epoch'],selected_checkpoint=best['checkpoint'],
                optimizer_steps=2016,initial_fingerprint=initial_fp,base_fingerprint=base_fp,base_unchanged=True,adapter_trainable_parameters=552,
                dense_evaluation=dense_ref,panels=panels,train_curves=curves,heldout_targets_read=False,
                all_core_elements_preserved=True,complete_research_experiment=False)
            gate.write(folder/'completion.json',result)
            print(json.dumps(dict(event='adapter_completed',case=case_id,selected_epoch=best['epoch'])),flush=True)
            return 0
        except (InterruptedError,MemoryError) as exc:
            # If post-training evaluation loaded another frozen epoch, preserve the last training checkpoint instead.
            if state['steps']<2016 or state['phase']!='epoch_complete':
                receipt=checkpoint(folder,identity,student,opt,rng,state)
            else:receipt=gate.read(folder/'latest.json')
            gate.write(folder/'stops'/('stop_'+uuid.uuid4().hex+'.json'),dict(reason=repr(exc),at=gate.now(),checkpoint=receipt))
            return 3
def main():
    p=argparse.ArgumentParser();p.add_argument('--case',required=True);p.add_argument('--resume',action='store_true')
    a=p.parse_args();return run(a.case,a.resume)
if __name__=='__main__':raise SystemExit(main())

