﻿param(
    [int]$ManagerProcessId,
    [long]$ManagerStartUtcTicks,
    [string]$ManagerScript,
    [string]$StatusPath,
    [switch]$SelfTest
)
$ErrorActionPreference = 'Stop'
$root = Split-Path -Parent $PSScriptRoot
$automation = Join-Path $root 'event_driven_automation'
$inbox = Join-Path $automation 'inbox'
function Save-Json($path, $value) {
    $temp = $path + '.' + [guid]::NewGuid().ToString('N') + '.tmp'
    $value | ConvertTo-Json -Depth 12 | Set-Content -LiteralPath $temp -Encoding UTF8
    Move-Item -LiteralPath $temp -Destination $path -Force
}
function Test-UserPaused {
    foreach ($stopFolder in @($root, $PSScriptRoot, (Split-Path -Parent $statusFullPath))) {
        foreach ($stopName in @('STOP_REQUESTED','STOP_REQUESTED.json')) {
            if (Test-Path -LiteralPath (Join-Path $stopFolder $stopName)) { return $true }
        }
    }
    $pausePath = Join-Path (Split-Path -Parent $root) 'RESEARCH_PAUSED.json'
    if (Test-Path -LiteralPath $pausePath) {
        $pause = Get-Content -LiteralPath $pausePath -Raw -Encoding UTF8 | ConvertFrom-Json
        return ($pause.status -ne 'resumed_by_user' -or $pause.stop_preparation_and_training -eq $true)
    }
    return $false
}
function Terminal-Handled($row, [bool]$explicitEventExists) {
    if ($row.classification -eq 'user_stop' -or $row.event -in @('user_stop_at_stage_boundary','user_stop_before_launch','user_stop')) { return $true }
    if ($row.event -in @('finite_mechanism_queue_completed','step_stopped_or_failed','finite_sampling_queue_completed','sampling_blocking_failure') -and $explicitEventExists) { return $true }
    return $false
}
if ($SelfTest) {
    $checks = @(
      (Terminal-Handled ([pscustomobject]@{event='finite_sampling_queue_completed'}) $true),
      (-not (Terminal-Handled ([pscustomobject]@{event='finite_sampling_queue_completed'}) $false)),
      (Terminal-Handled ([pscustomobject]@{event='sampling_blocking_failure'}) $true),
      (-not (Terminal-Handled ([pscustomobject]@{event='sampling_blocking_failure'}) $false)),
      (Terminal-Handled ([pscustomobject]@{event='finite_mechanism_queue_completed'}) $true),
      (-not (Terminal-Handled ([pscustomobject]@{event='finite_mechanism_queue_completed'}) $false)),
      (Terminal-Handled ([pscustomobject]@{event='step_stopped_or_failed'}) $true),
      (-not (Terminal-Handled ([pscustomobject]@{event='step_stopped_or_failed'}) $false)),
      (Terminal-Handled ([pscustomobject]@{event='user_stop_before_launch'}) $false),
      (Terminal-Handled ([pscustomobject]@{classification='user_stop'}) $false),
      (-not (Terminal-Handled ([pscustomobject]@{event='step_process_started'}) $true))
    )
    if ($checks -contains $false) { throw 'Terminal handling QA failed' }
    [ordered]@{status='passed';checks=$checks.Count;training_started=$false;model_calls=0;timer=$false} | ConvertTo-Json
    exit 0
}
if ($ManagerProcessId -le 0 -or $ManagerStartUtcTicks -le 0 -or -not $ManagerScript -or -not $StatusPath) { throw 'Explicit process identity and paths required' }
$managerFullPath = [IO.Path]::GetFullPath($ManagerScript)
$statusFullPath = [IO.Path]::GetFullPath($StatusPath)
$branchPrefix = [IO.Path]::GetFullPath($root).TrimEnd('\') + '\'
if (-not $managerFullPath.StartsWith($branchPrefix,[StringComparison]::OrdinalIgnoreCase) -or -not $statusFullPath.StartsWith($branchPrefix,[StringComparison]::OrdinalIgnoreCase)) { throw 'Bridge paths must belong to this branch' }
$key = 'submission_exit_' + $ManagerProcessId + '_' + $ManagerStartUtcTicks
$monitorDir = Join-Path $automation 'process_monitors'
New-Item -ItemType Directory -Path $monitorDir -Force | Out-Null
$mutex = [Threading.Mutex]::new($false, ('Local\CAISO_' + $key))
if (-not $mutex.WaitOne(0)) { throw 'Exit bridge already attached' }
$subscription = $null
$process = $null
try {
    $process = Get-Process -Id $ManagerProcessId -ErrorAction SilentlyContinue
    if ($process) {
        if ($process.StartTime.ToUniversalTime().Ticks -ne $ManagerStartUtcTicks) { throw 'Manager PID was reused' }
        $info = Get-CimInstance Win32_Process -Filter ('ProcessId = ' + $ManagerProcessId)
        if ($info -and -not $info.CommandLine.Contains($managerFullPath)) { throw 'Manager command mismatch' }
        $process.EnableRaisingEvents = $true
        $subscription = Register-ObjectEvent -InputObject $process -EventName Exited -SourceIdentifier ('CAISO.' + $key)
    }
    Save-Json (Join-Path $monitorDir ($key + '.status.json')) ([ordered]@{
       status='watching_process_exit';watcher_pid=$PID;manager_pid=$ManagerProcessId;manager_start_utc_ticks=$ManagerStartUtcTicks
       manager_script=$managerFullPath;manager_status=$statusFullPath;at=[DateTime]::UtcNow.ToString('o');timer=$false;periodic_model_calls=$false
    })
    if ($process -and -not $process.HasExited) {
        $event = Wait-Event -SourceIdentifier ('CAISO.' + $key)
        Remove-Event -EventIdentifier $event.EventIdentifier -ErrorAction SilentlyContinue
    }
    $row = $null
    if (Test-Path -LiteralPath $statusFullPath) { $row = Get-Content -LiteralPath $statusFullPath -Raw -Encoding UTF8 | ConvertFrom-Json }
    $statusTimeMatches = $false
    if ($row -and $row.at) {
        $statusTimeMatches = ([DateTimeOffset]::Parse([string]$row.at).UtcTicks -ge $ManagerStartUtcTicks)
    }
    $matchingStatus = $row -and [int]$row.pid -eq $ManagerProcessId -and $statusTimeMatches
    $explicitPath = $null
    if ($matchingStatus -and $row.event -eq 'finite_mechanism_queue_completed' -and $row.completion_sha256) {
        $explicitPath = Join-Path $inbox ('mechanisms_complete_' + $row.completion_sha256 + '.json')
    } elseif ($matchingStatus -and $row.event_id) {
        $explicitPath = Join-Path $inbox ([string]$row.event_id + '.json')
    }
    $handled = $matchingStatus -and (Terminal-Handled $row ([bool]($explicitPath -and (Test-Path -LiteralPath $explicitPath))))
    $paused = Test-UserPaused
    $evidencePath = Join-Path $monitorDir ($key + '.exit.json')
    Save-Json $evidencePath ([ordered]@{
      status='manager_exit_observed';at=[DateTime]::UtcNow.ToString('o');watcher_pid=$PID;manager_pid=$ManagerProcessId
      manager_start_utc_ticks=$ManagerStartUtcTicks;terminal_handled=$handled;user_paused=$paused;last_status=$row;source_status=$statusFullPath
    })
    if (-not $handled -and -not $paused) {
        $eventPath = Join-Path $inbox ($key + '.json')
        if (-not (Test-Path -LiteralPath $eventPath)) {
            Save-Json $eventPath ([ordered]@{
              schema='caiso_research_event_v1';event_id=$key;event='blocking_failure';evidence_path=$evidencePath
              at=[DateTime]::UtcNow.ToString('o');reason='manager_exit_without_delivered_terminal_event';manager_pid=$ManagerProcessId
              instruction='Verify manager and surviving child process plus saved checkpoints before recovery; no automatic restart.'
            })
        }
    }
} catch {
    $bridgeError = $_.Exception.Message
    $paused = $false
    $pauseCheckError = $null
    try { $paused = Test-UserPaused } catch { $pauseCheckError = $_.Exception.Message }
    $failurePath = Join-Path $monitorDir ($key + '.bridge_failure.json')
    Save-Json $failurePath ([ordered]@{status='exit_bridge_failed';error=$bridgeError;user_paused=$paused;pause_check_error=$pauseCheckError;at=[DateTime]::UtcNow.ToString('o');watcher_pid=$PID;manager_pid=$ManagerProcessId})
    $failureEventPath = Join-Path $inbox ($key + '_bridge_failure.json')
    if (-not $paused -and -not (Test-Path -LiteralPath $failureEventPath)) {
        Save-Json $failureEventPath ([ordered]@{schema='caiso_research_event_v1';event_id=($key + '_bridge_failure');event='blocking_failure';evidence_path=$failurePath;at=[DateTime]::UtcNow.ToString('o');reason='OS_process_exit_monitor_failed'})
    }
    throw
} finally {
    if ($subscription) { Unregister-Event -SubscriptionId $subscription.SubscriptionId -ErrorAction SilentlyContinue }
    if ($process) { $process.Dispose() }
    $mutex.ReleaseMutex(); $mutex.Dispose()
}