"""Register one development experiment before its first fit."""
import gate

def main():
    gate.boundary()
    gate.need(not (gate.HERE/'PROTOCOL.json').exists(), 'Protocol already exists')
    manifest = gate.ROOT/'phase_sampling_support_v3_20260923/dataset/ADDITIVE/manifest.json'
    audit = manifest.with_name('audit.json')
    a = gate.read(audit)
    gate.need(a['status']=='passed' and a['dataset_manifest_sha256']==gate.sha(manifest), 'Dataset audit')
    cases = []
    for seed in (20260813,20260814,20260815):
        for model in ('FULL','DLinear'):
            folder=gate.ROOT/'budget_extension_v1_20260925/runs'/f'{seed}_{model}'
            a=gate.read(folder/'audit.json')
            gate.need(a['status']=='passed','Parent audit failed')
            checkpoints=list((folder/'checkpoints').glob('e12_*.pt'))
            gate.need(len(checkpoints)==1,'Terminal checkpoint ambiguity')
            cp=checkpoints[0];receipt=gate.read(cp.with_suffix('.receipt.json'))
            gate.need(receipt['epoch']==12 and receipt['phase']=='epoch_complete' and gate.sha(cp)==receipt['sha256'],'Parent terminal receipt')
            done=gate.read(folder/'completion.json')
            epoch=next(e for e in done['epochs'] if e['epoch']==12)
            reference=gate.resolve(epoch['evaluation']['path'])
            gate.need(gate.sha(reference)==epoch['evaluation']['sha256'],'Epoch12 replay reference')
            cases.append(dict(seed=seed,model=model,checkpoint=str(cp),checkpoint_sha256=gate.sha(cp),
                audit=str(folder/'audit.json'),audit_sha256=gate.sha(folder/'audit.json'),
                reference=str(reference),reference_sha256=gate.sha(reference),
                selected_reference=str(gate.resolve(done['dense_evaluation']['path'])),
                selected_reference_sha256=done['dense_evaluation']['sha256']))
    p=dict(version='context_expert_development_v1',at=gate.now(),
        authorization='User: 你试试看吧; preserve existing advantages and improve deficiencies with situation-aware models.',
        scope='Exploratory June development only. Prior June inspection is disclosed. No new independent-test claim.',
        source_gate_revision='This separately authorized low-cost development pilot may run before future test admission; the prior common-unit-loss trial remains closed.',
        dataset_manifest=str(manifest),dataset_manifest_sha256=gate.sha(manifest),cases=cases,
        preserved=['dynamic_GNN','parallel_TCN_Transformer','adaptive_feature_attention','original_prediction_head'],
        experts=['FULL_epoch12','DLinear_epoch12','Persistence'],expert_training_updates=0,
        candidate='context-conditioned soft convex prediction mixture; original internal feature fusion unchanged',
        arms=['STATIC_MIX','HORIZON_MIX','CONTEXT_MIX'],
        deterministic_controls=['FULL','DLinear','Persistence','EQUAL_EXPERT','FULL_SELECTED'],
        seeds=[20260813,20260814,20260815],hidden_units=16,features=13,
        optimizer=dict(name='Adam',lr=.001,weight_decay=.0001,batch_size=4096,epochs=20),
        loss='Mean absolute error in original USD/MWh; same objective for all three combination learners',
        initialization='All combination logits initially [4,0,0], favouring unchanged FULL. No output hard switching.',
        normalization='Only preceding fold-training rows; frozen during later evaluation.',
        folds=dict(date_basis='UTC forecast cutoff dates',train_date_counts=[7,11,15],next_evaluation_dates=4,
                   purge='All train label endpoints strictly before earliest evaluation cutoff'),
        selection='Fixed terminal20epochs, no early stopping, no hyperparameter search, all27fits retained',
        promotion=dict(minimum_MAE_gain_vs_matched_FULL_percent=1.,min_improving_seeds=2,min_improving_folds=2,
            no_regression=['rmse','near_mae','h12_mae','low_volatility_mae'],
            existing_selected_FULL_protection=['mae','rmse','near_mae','h12_mae','low_volatility_mae'],
            all_six_states_MAE_RMSE_must_not_worsen_vs_matched_FULL=True,
            context_MAE_must_beat=['STATIC_MIX','HORIZON_MIX'],
            all_states_nodes_horizons_retained=True,
            scarce_state_conclusions='Descriptive only; no all-state superiority when event support is insufficient',
            independent_confirmation_and_matched_component_controls_still_required=True),
        maximum_active_development_seconds=7200,post_trial_actions='No automatic architecture extension. Audit, report decision, preserve all results.',
        resources=dict(launch_physical_and_commit_GiB=5,runtime_physical_and_commit_GiB=4,numerical_workers=1,threads=1),
        new_test_targets_read=False,paper_results_replaced=False,
        literature=[
          dict(title='Mixture-of-Linear-Experts for Long-term Time Series Forecasting',venue='AISTATS 2024',url='https://proceedings.mlr.press/v238/ni24a.html',use='Lightweight expert specialization and learned routing; no assumption its reported gains transfer.'),
          dict(title='Regime-aware conditional neural processes with multi-criteria decision support for operational electricity price forecasting',venue='Energy Economics 157 (2026) 109233',url='https://doi.org/10.1016/j.eneco.2026.109233',author_version='https://arxiv.org/abs/2508.00040',use='Conditional electricity-price experts; current inputs determine inference weights.'),
          dict(title='Forecasting day-ahead electricity prices: best practices and an open-access benchmark',url='https://arxiv.org/abs/2008.08004',use='Matched comparisons and chronological evaluation.')])
    gate.write(gate.HERE/'PROTOCOL.json',p)
    gate.write(gate.HERE/'HANDOFF.before_trial.json',gate.read(gate.ROOT/'HANDOFF.json'))
    print('Protocol registered; no fitting performed.')

def seal():
    p=gate.read(gate.HERE/'PROTOCOL.json');bindings={}
    def bind(path,expected=None):
        path=gate.resolve(path);value=gate.sha(path)
        gate.need(expected is None or value==expected,'Binding mismatch: '+str(path))
        bindings[str(path)]=value
    for f in gate.HERE.glob('*.py'): bind(f)
    for f in gate.HERE.glob('*.ps1'): bind(f)
    bind(gate.HERE/'PROTOCOL.json');bind(gate.HERE/'QA.json')
    bind(p['dataset_manifest'],p['dataset_manifest_sha256'])
    bind(gate.resolve(p['dataset_manifest']).with_name('audit.json'))
    m=gate.read(p['dataset_manifest'])
    for v in m['artifacts'].values():bind(v['path'],v['sha256'])
    for c in p['cases']:
        for field in ('checkpoint','audit','reference','selected_reference'):bind(c[field],c[field+'_sha256'])
    for path in (gate.ROOT/'source').rglob('*.py'):bind(path)
    for rel in ('matched_external_v1_20260924/model_adapter.py','external/preparation_20260913/source/official_models.py'):
        bind(gate.ROOT/rel)
    vendor=gate.ROOT.parent/'external_baselines_20260913/vendor'
    bind(vendor/'manifest.json')
    for path in vendor.rglob('*.py'):bind(path)
    gate.write(gate.HERE/'SEAL.json',dict(at=gate.now(),bindings=bindings,status='sealed_before_real_fit'))
    print('Sealed',len(bindings),'dependencies')

if __name__=='__main__':
    import sys
    seal() if len(sys.argv)>1 and sys.argv[1]=='seal' else main()
