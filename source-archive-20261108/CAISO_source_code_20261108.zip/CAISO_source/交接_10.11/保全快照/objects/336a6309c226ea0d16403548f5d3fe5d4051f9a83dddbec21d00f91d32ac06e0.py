"""All twelve budget comparisons and fixed-panel seed means."""
import statistics,json
import gate
M=('mae','rmse','near_h1_4_mae','h12_mae')
def compare(a,b):
 return {pn:{m:dict(candidate=a[pn][m],reference=b[pn][m],reduction_percent=100*(1-a[pn][m]/b[pn][m])) for m in M} for pn in ('June284','June3397','balanced278')}
def main():
 s=gate.verify();rows={};changes=[];curves=[]
 for c in s['cases']:
  folder=gate.HERE/'runs'/c['id'];r=gate.read(folder/'completion.json');au=gate.read(folder/'audit.json')
  gate.need(au['status']=='passed' and au['completion_sha256']==gate.sha(folder/'completion.json'),'Audit missing')
  for p,d in au['output_bindings'].items():gate.need(gate.sha(gate.inside(p))==d,'Audited output changed')
  rows[(c['seed'],c['variant'])]=r
  changes.append(dict(case=c['id'],prefix_selected_epoch=c['parent']['selected_epoch'],extended_selected_epoch=r['selected_epoch'],
   selected_at_budget_ceiling=r['selected_epoch']==12,panels=compare(r['panels'],c['parent_panels'])))
  curves.append(dict(case=c['id'],june284=[dict(epoch=e['epoch'],mae=e['june']['mae'],train_huber=e['train_huber_mean']) for e in r['epochs']],
   fixed_train_prefix=c['parent_train_curve'],fixed_train_extension=[dict(epoch=x['epoch'],metrics=x['metrics']) for x in r['train_curves_new']]))
 means={v:{pn:{m:statistics.mean(rows[(seed,v)]['panels'][pn][m] for seed in (20260813,20260814,20260815)) for m in M}
  for pn in ('June284','June3397','balanced278')} for v in gate.VARIANTS}
 comparisons=[dict(seed=seed,candidate='FULL',reference=v,panels=compare(rows[(seed,'FULL')]['panels'],rows[(seed,v)]['panels']))
  for seed in (20260813,20260814,20260815) for v in ('TCN','DLinear','iTransformer-H')]
 gate.write(gate.HERE/'summary.json',dict(status='twelve_budget_extensions_audited',at=gate.now(),changes_from_six_epochs=changes,
  means=means,comparisons=comparisons,learning_curves=curves,
  scope='Fixed12096updates, originalcosine6epochs then6floorLRcontinuation; not a convergence guarantee or independent heldout evaluation.',
  all_positive_negative_directions_preserved=True,adapter_family_closed=True,
  next='Review trainingadequacy, matchedFiLM/QUERY, finalfreeze and dataG3-G8 before independentchronologicaltargets.',
  heldout_targets_read=False,complete_research_experiment=False))
 print(json.dumps(dict(status='twelve_budget_extensions_audited',cases=12)))
if __name__=='__main__':main()
