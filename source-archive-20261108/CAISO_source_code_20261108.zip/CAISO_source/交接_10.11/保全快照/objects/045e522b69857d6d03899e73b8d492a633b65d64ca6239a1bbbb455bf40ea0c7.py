"""Frequency-adapted LASSO ARX; no path or test-data reader."""
def design(features,publications,times,caps,origins,node):
    import numpy as np
    o=np.asarray(origins,np.int64)
    if features.ndim!=3 or features.shape[1:]!=(30,29) or o.ndim!=1 or not len(o) or o.min()<288 or o.max()>=len(features):raise ValueError('Design shape/origin')
    if node not in range(30):raise ValueError('Node')
    history=np.asarray(features[o[:,None]-np.arange(288,0,-1)[None,:],node,0],np.float64)
    last=np.asarray(features[o-1,node,1:],np.float64).copy()
    pub=publications[o-1];cut=times[o-1,None]
    if np.any(pub<=0) or np.any(pub>cut):raise ValueError('Unavailable forecast publication')
    last[:,18:20]=np.clip((cut-pub)/60/np.asarray(caps),0,1).astype(np.float32)
    other=np.asarray(features[o-1,:,0],np.float64)[:,[i for i in range(30) if i!=node]]
    x=np.concatenate((history,last,other),axis=1)
    if x.shape!=(len(o),345) or not np.isfinite(x).all():raise ValueError('Nonfinite/design width')
    return x

def fit_path(x,y,ratios,guard=lambda:None):
    import numpy as np
    from sklearn.linear_model import lasso_path
    import warnings
    from sklearn.exceptions import ConvergenceWarning
    mean=x.mean(0);sd=x.std(0);sd[sd<1e-12]=1
    z=np.asfortranarray((x-mean)/sd);ym=y.mean(0);yc=np.asarray(y-ym,np.float64)
    gram=np.ascontiguousarray(z.T@z);n=len(z);k=len(ratios);h=y.shape[1]
    weights=np.zeros((h,z.shape[1],k));alphas=np.zeros((h,k));dual=np.zeros((h,k));iters=np.zeros((h,k),np.int64)
    retries=[]
    for j in range(h):
        guard();xy=z.T@yc[:,j];amax=float(np.max(np.abs(xy))/n)
        if amax<=1e-15:continue
        aa=amax*np.asarray(ratios,np.float64);limit=1e-5*np.mean(yc[:,j]**2)
        for maxit in (10000,30000,100000):
            with warnings.catch_warnings(record=True) as warn:
                warnings.simplefilter('always',ConvergenceWarning)
                a,w,g,it=lasso_path(z,yc[:,j],alphas=aa,precompute=gram,Xy=xy,copy_X=False,tol=1e-5,max_iter=maxit,selection='cyclic',return_n_iter=True)
            converged=np.isfinite(w).all() and np.isfinite(g).all() and np.all(g<=limit+1e-12) and not any(issubclass(q.category,ConvergenceWarning) for q in warn)
            if converged:break
            retries.append(dict(horizon=j+1,max_iter=maxit,dual_gap=np.asarray(g).tolist()))
        if not converged:raise RuntimeError('Nonconverged LASSO horizon '+str(j+1))
        if not np.allclose(a,aa,atol=0,rtol=1e-12):raise RuntimeError('Alpha order changed')
        weights[j]=w;alphas[j]=a;dual[j]=g;iters[j]=it
    return dict(weights=weights,mean=mean,sd=sd,target_mean=ym,alphas=alphas,dual_gaps=dual,iterations=iters),retries

def predict(x,fit):
    import numpy as np
    z=(x-fit['mean'])/fit['sd']
    return np.einsum('nd,hdk->nhk',z,fit['weights'],optimize=True)+fit['target_mean'][None,:,None]
