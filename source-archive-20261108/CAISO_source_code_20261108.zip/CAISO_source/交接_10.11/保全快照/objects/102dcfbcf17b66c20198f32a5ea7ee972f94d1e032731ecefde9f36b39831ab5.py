"""Record deep diagnosis; never promote diagnostic substitutions."""
from diagnose import P,B,gate,write
from statistics import mean

r=gate.read(P/'RESULT.json');c=gate.read(P/'CLOCK_PHASE_DIAGNOSIS.json');d=gate.read(P/'DECISION_TRACE.json')
a=gate.read(P/'AUDIT.json');da=gate.read(P/'DECISION_AUDIT.json');p=gate.read(P/'PROTOCOL.json')
assert a['status']==da['status']=='passed'
assert a['result_sha256']==gate.sha(P/'RESULT.json') and a['clock_result_sha256']==gate.sha(P/'CLOCK_PHASE_DIAGNOSIS.json')
assert da['result_sha256']==gate.sha(P/'DECISION_TRACE.json')
for path,digest in p['protected'].items():assert gate.sha(path)==digest,path
assert not (P/'DEEP_REVIEW.json').exists()
def risk(part,mode):
    return next(z for z in r['risk_set_scores'] if z['panel']==part and z['task']=='hazard' and z['mode']==mode and z['horizon'] is None)
def composed(part,mode):
    return next(z['score'] for z in r['composed_scores'] if z['panel']==part and z['mode']==mode and z['horizon_band']=='ALL')
price_summary=[]
for state in [3,4,5]:
    price_summary.append(dict(state=state,**{mode:{metric:mean(z[metric] for z in r['fixed_temperature_substitution_price_diagnostics'] if z['state']==state and z['mode']==mode) for metric in ['MAE','RMSE']} for mode in ['RAW','HAZARD_TEMP_ONLY','POSTEXIT_TEMP_ONLY','SAVED']}))
review=dict(at=gate.now(),status='deep_diagnosis_complete_no_new_model',
    scope='Frozen V7 pipeline and already inspected development. No training, parameter fitting, candidate selection, new test access or manuscript-result replacement.',
    causal_account=[
      {'finding':'A demonstrable calibration-objective mismatch, beyond a theoretical concern',
       'calibration_hazard_raw':risk('CAL','raw'),'calibration_hazard_saved_temperature':risk('CAL','saved_temperature'),
       'composed_calibration_raw':composed('CAL','RAW'),'composed_calibration_saved':composed('CAL','SAVED'),
       'composed_development_raw':composed('DEV','RAW'),'composed_development_saved':composed('DEV','SAVED'),
       'interpretation':'Saved temperature reduces the declared outcome-weighted calibration NLL while worsening natural hazard NLL and the composed state score. Local optimization and the downstream probability objective differ.',
       'boundary':'This does not prove recalibrating alone will improve all price errors.'},
      {'finding':'Case discrimination, not just aggregate probability level, remains a bottleneck',
       'first_step_hazard_AUC':{part:next(z['AUC'] for z in r['hazard_ranking_by_horizon'] if z['panel']==part and z['horizon']==1) for part in ['FIT','CAL','DEV']},
       'development_first_step':next(z for z in c['rows'] if z['panel']=='DEV' and z['scope']=='H1'),
       'interpretation':'Aggregate first-step exit probability 0.5073 is close to observed 0.4970, yet severe local mistakes remain. Training versus held-out rankings differ descriptively. A single positive temperature is monotone and cannot improve binary hazard AUC; this was checked at each evaluable horizon.',
       'boundary':'In-sample versus later-population AUC differences do not uniquely prove overfitting; population change and event dependence remain possible contributors.'},
      {'finding':'The output rule converts uncertain mixtures into large deterministic changes',
       'largest_examples':d['largest_single_S3_harm_cells'],
       'interpretation':'Both direction checks use functionals of the same estimated distribution. Their agreement is not two independent confidence measurements. Fixed 0.75 shrinkage then transmits distribution error into prices.',
       'boundary':'With a correct conditional distribution, same-direction movement toward its mean and median can be sensible in expected loss; it does not guarantee improvement on each realization.'},
      {'finding':'A coarse uncertainty fallback conflicts with retained persistent-spike benefits',
       'fixed_probability_band':[.25,.75],
       'S3_positive_added_SSE_share': [z['S3_positive_added_SSE_middle_band_fraction'] for z in d['summaries']],
       'S5_positive_SSE_benefit_share':[z['S5_positive_SSE_benefit_middle_band_fraction'] for z in d['summaries']],
       'interpretation':'The same broad uncertainty region contains 95.81-97.62% of harmful S3 added SSE and 81.72-82.31% of helpful S5 SSE reductions. Rejecting all such corrections would also discard many beneficial ones. These shares concern positive contributions, not net RMSE or a simulated alternative model.'},
      {'finding':'Chronology of the dominant error is now explicit',
       'dominant_origin':r['top_S3_harm_origins'][0],
       'first_step_positive_S3_harm_share':[z['S3_positive_added_SSE_first_horizon_fraction'] for z in d['summaries']],
       'time_feature_check':c['time_features'],
       'interpretation':'The dominant origin was still at a recent observed peak before abrupt next-step reversion. The full history does include minute precision. Every DEV first target is on the hour; first-horizon and hour-boundary effects are confounded on this panel.',
       'boundary':'Official 5/15-minute market cadence motivates examining time strata; it does not establish a dispatch cause for this archived event. No missing minute field or market causation is asserted.'},
      {'finding':'One small but definite logical-support inconsistency',
       'structural_checks':d['structural_label_check'],
       'first_step_impossible_reentry_mean_probability':d['summaries'][0]['first_horizon_impossible_reentry_probability_mean'],
       'first_step_impossible_reentry_max_probability':d['summaries'][0]['first_horizon_impossible_reentry_probability_max'],
       'interpretation':'Under the discrete first-exit definition, first-step exit excludes an extreme destination at that same step. The pooled post-exit classifier nevertheless assigns it nonzero mass. This is a support constraint to repair in an isolated version.',
       'boundary':'Mean added extreme-state mass is about 0.70 percentage points, max 2.56 points. It cannot explain the main failure alone; no production forecast was changed.'}
    ],
    diagnostic_temperature_price_summary=price_summary,
    temperature_summary_warning='Retrospective frozen-output diagnostics only. RAW is not selected or promoted. Removing temperature improves S5 but worsens S3/S4 on this inspected panel.',
    explanations_now_unsupported=[
      'More independent seeds would automatically fix gate uncertainty: saved gate probabilities are identical across the current seeds.',
      'All problems are caused by missing minute information: daily time sine/cosine already encode minutes.',
      'All harmful cases are marginal out-of-range inputs: harmful pairs have fewer marginal-range exceedances than helpful pairs.',
      'A global hazard level adjustment or broad uncertainty cutoff can preserve all existing gains.',
      'The 0.70-point impossible re-entry mass accounts for the severe S3 high forecasts.'
    ],
    bounded_next_design_without_execution={
      'model_addition_not_yet_justified':True,
      'step_1':'Audit and explicitly specify the natural row-level hazard/state likelihood and structural-zero constraint. Separate TRAIN fitting from chronologically distinct calibration.',
      'step_2':'Before fitting a new router, establish repeatable first-step recovery discrimination across earlier-only dates and known clock/duration strata. Compare against simple TRAIN-only rates, account for dates, and retain failures.',
      'step_3':'Only if discrimination evidence exists, predefine one matched intervention and assess price consequences against V7 on all retained metrics. A reduction of probability score alone is insufficient.',
      'separate_onset':'S2 onset remains outside the current specialist activation domain. An exit-model fix cannot be represented as an onset fix.',
      'separate_graph_fusion':'Dynamic graph and CONCAT comparison issues remain separate; no unique cause or successful repair is inferred from this spike diagnosis.',
      'new_final_test':'Any new candidate still requires a fresh admitted final panel and freeze. Earlier viewed final panels cannot supply fresh confirmation.',
      'no_training_queued':True
    },
    literature=[
      {'title':'Making and Evaluating Point Forecasts','author':'Tilmann Gneiting','journal':'JASA','year':2011,'url':'https://arxiv.org/html/0912.0902v2','use':'Weighted scoring and appropriate point functionals; not a proof of CAISO improvement.'},
      {'title':'On Calibration of Modern Neural Networks','authors':'Guo, Pleiss, Sun, Weinberger','venue':'ICML/PMLR 70','year':2017,'url':'https://proceedings.mlr.press/v70/guo17a.html','use':'Temperature calibration method. Published empirical scope is neural image/document models; binary monotonicity here follows directly from sigmoid(logit(p)/T) and was independently replayed.'},
      {'title':'Products and services','author':'California ISO','url':'https://www.caiso.com/market-operations/products-services','use':'Official real-time market cadence only; no claim about the cause of the specific 2026-03-20 archived event.'}
    ],
    evidence={str(P/n):gate.sha(P/n) for n in ['RESULT.json','CLOCK_PHASE_DIAGNOSIS.json','DECISION_TRACE.json','AUDIT.json','DECISION_AUDIT.json','PROTOCOL.json','PHASE_PROTOCOL.json','DECISION_TRACE_PROTOCOL.json']},
    fits=0,new_test_targets_read=False,protected_files_verified=len(p['protected']),
    complete_research_experiment=False,same_operator_audit=True,external_human_review=False)
write('DEEP_REVIEW.json',review)
h=gate.read(B/'HANDOFF.json');write('HANDOFF_before_deep_review.json',h)
h['status']='diagnosis_first_no_new_model_queued';h['research_training_active']=False;h['complete_research_experiment']=False
h['next_action']='Deep diagnosis complete: probability-objective mismatch, weak temporal discrimination and decision amplification are separated. No new model queued. Design one earlier-only matched discriminator before any new fit; retain V7 and manuscript.'
h['deep_mechanism_trace_20261001']=dict(at=gate.now(),path=str(P/'DEEP_REVIEW.json'),sha256=gate.sha(P/'DEEP_REVIEW.json'),fits=0,protected_files_verified=len(p['protected']),training_queued=False)
gate.write(B/'HANDOFF.json',h)
print({'status':'deep_review_recorded','retrospective_price_diagnostics':price_summary,'main_audit_checks':a['check_count'],'decision_audit_checks':da['check_count'],'fits':0})
