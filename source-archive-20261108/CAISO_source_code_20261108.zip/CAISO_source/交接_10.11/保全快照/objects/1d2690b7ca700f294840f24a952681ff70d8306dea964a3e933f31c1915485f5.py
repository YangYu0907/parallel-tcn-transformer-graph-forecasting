"""Download bounded public documentation, preserving receipts; no model/data fits."""
from pathlib import Path
from datetime import datetime, timezone
import json, hashlib, os, re, requests
P = Path(__file__).resolve().parent
sources = {
    'correction_note.pdf': 'https://www.caiso.com/documents/readiness-notes-new-price-correction-summary-report-in-oasis.pdf',
    'dame_summary.pdf': 'https://www.caiso.com/documents/businesspracticesummary-day-ahead-market-enhancement.pdf',
    'dame_launch.pdf': 'https://www.caiso.com/documents/presentation-release-activation-review-dame-and-edam-apr-23-2026.pdf',
    'api_2017.pdf': 'https://www.caiso.com/documents/oasis-interfacespecification_v5_1_1clean_fall2017release.pdf',
    'bulk_index.html': 'https://oasis-bulk.caiso.com/',
}
receipts = []
for name, url in sources.items():
    dest = P / name
    rec = dict(name=name,url=url,retrieved_at=datetime.now(timezone.utc).isoformat())
    try:
        if dest.exists():
            data = dest.read_bytes(); rec['reused'] = True
        else:
            with requests.get(url, timeout=(10,25), stream=True) as r:
                r.raise_for_status(); chunks=[]; size=0
                for block in r.iter_content(65536):
                    size += len(block)
                    if size > 8000000: raise ValueError('documentation size cap')
                    chunks.append(block)
                data=b''.join(chunks)
                rec.update(http_status=r.status_code,final_url=r.url,
                           response_last_modified=r.headers.get('Last-Modified'))
            if name.endswith('.pdf') and not data.startswith(b'%PDF'): raise ValueError('not PDF')
            tmp=dest.with_name('.s'+os.urandom(4).hex()); tmp.write_bytes(data); os.replace(tmp,dest)
        rec.update(bytes=len(data),sha256=hashlib.sha256(data).hexdigest(),path=str(dest),status='received')
        if name.endswith('.html'):
            rec['public_links'] = re.findall(r'(?:href|src)=["\']([^"\']+)["\']',data.decode('utf-8',errors='replace'))[:100]
    except Exception as e: rec.update(status='failed',error=str(e))
    receipts.append(rec)
    print(json.dumps({k:rec[k] for k in ['name','status','bytes','error'] if k in rec},ensure_ascii=False),flush=True)
tmp=P/('.s'+os.urandom(4).hex()); tmp.write_text(json.dumps(receipts,ensure_ascii=False,indent=2),encoding='utf-8'); os.replace(tmp,P/'DOCUMENT_RECEIPTS.json')
