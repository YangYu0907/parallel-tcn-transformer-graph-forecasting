"""Pure metadata sampling functions. No file I/O, array library, prices or RNG."""
from collections import deque
from hashlib import sha256
from math import ceil

VERSION = 'additive_capacity_matching_v1'
SALT = 'phase_sampling_additive_v2_20260920'

class InfeasiblePlan(ValueError):
    def __init__(self, certificate):
        self.certificate = certificate
        super().__init__('Phase quotas cannot be satisfied within admitted original hours')

def edge_key(epoch, row, origin, phase):
    return sha256(f'{SALT}|{epoch}|{row}|{origin}|{phase}'.encode()).digest()

def phase_quotas(n, epoch):
    if n <= 0 or epoch not in range(1, 7):
        raise ValueError('Positive row count and one of six registered epochs required')
    q = {d: n // 11 for d in range(1, 12)}
    for j in range(n % 11):
        q[1 + ((epoch - 1) * (n % 11) + j) % 11] += 1
    return q

def build_epoch_plan(anchors, admitted_origins, timestamps_seconds, train_stop,
                     epoch, history=288, horizon=12):
    anchors = tuple(anchors)
    admitted = set(admitted_origins)
    if not anchors or len(set(anchors)) != len(anchors):
        raise ValueError('Each epoch needs unique original hourly anchors')
    if history != 288 or horizon != 12:
        raise ValueError('History and forecast horizons are frozen')
    quotas = phase_quotas(len(anchors), epoch)
    candidates = []
    for row, origin in enumerate(anchors):
        if (not isinstance(origin, int) or isinstance(origin, bool) or origin % 12
                or origin < history or origin + horizon > train_stop
                or origin not in admitted):
            raise ValueError('Original anchor fails the registered TRAIN boundary')
        base_time = int(timestamps_seconds[origin])
        if base_time % 3600 or base_time - int(timestamps_seconds[origin - 1]) != 300:
            raise ValueError('Original anchor is not a consecutive five-minute hourly point')
        legal = []
        for phase in range(1, 12):
            added = origin + phase
            if added not in admitted or added + horizon > train_stop:
                continue
            stamp = int(timestamps_seconds[added])
            if (stamp != base_time + phase * 300 or stamp // 3600 != base_time // 3600
                    or stamp - int(timestamps_seconds[added - 1]) != 300):
                continue
            if int(timestamps_seconds[added + horizon - 1]) != stamp + (horizon - 1) * 300:
                continue
            legal.append(phase)
        candidates.append(sorted(legal, key=lambda d: edge_key(epoch, row, origin, d)))
    assigned = {}
    members = {d: set() for d in quotas}
    reroutes = 0
    for start in range(len(anchors)):
        rows = deque([start]); seen_rows = {start}; parent_phase = {}; free_phase = None
        while rows and free_phase is None:
            row = rows.popleft()
            for phase in candidates[row]:
                if phase in parent_phase:
                    continue
                parent_phase[phase] = row
                if len(members[phase]) < quotas[phase]:
                    free_phase = phase
                    break
                for other in sorted(members[phase]):
                    if other not in seen_rows:
                        seen_rows.add(other); rows.append(other)
        if free_phase is None:
            raise InfeasiblePlan({'epoch': epoch, 'required': len(anchors),
                'matched': len(assigned), 'failed_row': start, 'quotas': quotas,
                'candidate_counts_by_phase': {d: sum(d in c for c in candidates) for d in quotas},
                'reachable_rows': sorted(seen_rows), 'reachable_phases': sorted(parent_phase),
                'anchor_drop_allowed': False, 'quota_relaxation_allowed': False})
        phase = free_phase
        while True:
            row = parent_phase[phase]
            previous = assigned.get(row)
            if previous is not None:
                members[previous].remove(row); reroutes += 1
            assigned[row] = phase; members[phase].add(row)
            if previous is None:
                break
            phase = previous
    additions = [o + assigned[j] for j, o in enumerate(anchors)]
    additive = [v for pair in zip(anchors, additions) for v in pair]
    repeated = [v for o in anchors for v in (o, o)]
    assert len(set(additive)) == 2 * len(anchors)
    assert {d: len(members[d]) for d in quotas} == quotas
    assert additive[::2] == list(anchors) == repeated[::2] == repeated[1::2]
    return {'version': VERSION, 'epoch': epoch, 'original_anchors': list(anchors),
            'added_origins': additions, 'ADDITIVE': additive, 'REPEAT': repeated,
            'nonhourly_phase_counts': quotas, 'augmenting_reroutes': reroutes,
            'optimizer_updates': ceil(len(additive) / 4)}

def build_sampling_plan(six_epoch_anchors, admitted_origins, timestamps_seconds, train_stop,
                        expected_origins_per_epoch=2016):
    rows = list(six_epoch_anchors)
    if len(rows) != 6 or any(len(x) != expected_origins_per_epoch for x in rows):
        raise ValueError('Six separate original epoch lists with declared row count required')
    admitted = set(admitted_origins)
    epochs = [build_epoch_plan(x, admitted, timestamps_seconds, train_stop, i + 1)
              for i, x in enumerate(rows)]
    return {'version': VERSION, 'epochs': epochs,
            'original_unique_origins': len(set(v for x in rows for v in x)),
            'additive_unique_origins': len(set(v for e in epochs for v in e['ADDITIVE'])),
            'sample_presentations_each_policy': sum(len(e['ADDITIVE']) for e in epochs),
            'updates_each_policy': sum(e['optimizer_updates'] for e in epochs),
            'statistically_independent_samples_estimated': False}
