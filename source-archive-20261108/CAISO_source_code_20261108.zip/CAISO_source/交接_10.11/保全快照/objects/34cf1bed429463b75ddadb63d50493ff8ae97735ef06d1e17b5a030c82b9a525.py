"""Post-result attribution, restricted to already inspected 2015 validation."""
import gcommon as c

def main():
    c.verify()
    with c.gate.exclusive('V21 graph post-result diagnostic, no fitting'):
        np,torch,lim=c.gate.runtime(True)
        from model import sparse_cross
        audit=c.read(c.HERE/'AUDIT.json')
        assert audit['status']=='passed'
        assert c.sha(c.HERE/'RESULT.json')==audit['result_sha256']
        assert c.sha(c.HERE/'DECISION.json')==audit['decision_sha256']
        rows=[];support=[]
        for path in sorted((c.HERE/'runs').glob('*/result.json')):
            r=c.read(path)
            assert c.sha(r['prediction'])==r['prediction_sha256']
            assert c.sha(r['checkpoint'])==r['checkpoint_sha256']
            rows.append(dict(case=r['case']['id'],epoch=r['selected_epoch'],mae=[x['mae'] for x in r['history']]))
        for seed in (20260813,20260814,20260815):
            p=c.ROUND/'structure_arrays'/f'Europe_VALID_{seed}_FULL.npz'
            with np.load(p,allow_pickle=False) as z:
                adj=z['adjacency']
            s=sparse_cross(torch.from_numpy(adj)).numpy()
            n=adj.shape[-1];off=~np.eye(n,dtype=bool)
            diag=np.diagonal(adj,axis1=-2,axis2=-1)
            assert np.array_equal(diag,np.diagonal(s,axis1=-2,axis2=-1))
            support.append(dict(seed=seed,zero_cross_edges_percent=float(100*(s[:,off]==0).mean()),
                mean_row_l1_change=float(np.abs(s-adj).sum(-1).mean()),self_mass_exactly_preserved=True))
        assert len(rows)==15 and all(x['epoch']==0 for x in rows)
        result=dict(at=c.now(),status='completed',scope='Post-hoc description of original 2015 Europe validation; no new test or fitting',
            verified_result_sha256=audit['result_sha256'],verified_predictions_and_checkpoints=15,
            histories=rows,support=support,
            facts=['All 15 matched cases selected epoch0; neither two-epoch continuation improved validation MAE.',
                   'All three FULL sparse epoch0 models already have higher MAE than their unmodified parent.',
                   'Thus the selected regression is directly present at the adjacency intervention, not caused by selecting a trained checkpoint.',
                   'Sparsification redistributes retained cross-node mass; self mass remains unchanged.'],
            hypotheses=['Hard zeroing may remove useful complementary cross-market signal, or the pretrained downstream mapping may be poorly adapted to shifted neighbor allocation. This design cannot distinguish those explanations.',
                        'Two-epoch continuation with restarted AdamW is not evidence that every sparse graph or longer training must fail.'],
            decision='Close this fixed G candidate without an edge threshold/epoch search. Preserve all results and V7. Proceed to separately registered F hypothesis.',
            V7_preserved=True,new_test_targets_read=False)
        c.write(c.HERE/'DIAGNOSIS.json',result)
        print({'cases':len(rows),'selected_epoch0':15,'support':support})

if __name__=='__main__':main()
