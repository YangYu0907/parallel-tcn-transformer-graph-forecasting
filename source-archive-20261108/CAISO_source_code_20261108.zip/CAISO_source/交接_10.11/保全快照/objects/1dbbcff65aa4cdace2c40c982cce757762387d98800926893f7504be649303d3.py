"""One metadata-defined short-context hazard population, not a model/threshold search."""
import support as s
import numpy as np,json
from datetime import datetime,timezone
def sec(t):return int(datetime.fromisoformat(t+'T00:00:00+00:00').timestamp())
def main():
    p=s.read(s.N/'SHORT_CONTEXT_PROTOCOL.json');assert s.sha(__file__)==p['code_sha256']
    if (s.N/'SHORT_CONTEXT_FEASIBILITY.json').exists():print('Existing census retained');return
    with s.base.numeric('Actual-dependency first-entry source/support census, no training'):
        for path,h in p['bindings'].items():assert s.sha(path)==h,path
        with np.load(p['publications'],allow_pickle=False) as z:
            ts=z['timestamps_seconds'][:210528];last=z['price_last_publication_seconds'][:210528];firstpub=z['price_first_publication_seconds'][:210528];valid=z['price_event_bound'][:210528]
        o=np.arange(4320,210528-11,dtype=np.int64);cutoff=ts[o-1]
        histmax=np.maximum.reduce([last[o-h] for h in range(1,37)])
        histvalid=np.logical_and.reduce([valid[o-h] for h in range(1,37)])
        max_target=np.maximum.reduce([last[o+h] for h in range(12)])
        min_first=np.minimum.reduce([firstpub[o+h] for h in range(12)])
        targetvalid=np.logical_and.reduce([valid[o+h] for h in range(12)])
        a,b=map(sec,p['split_dates']);freezes=np.array([a-172800,b-172800,sec('2025-06-01')-300])
        role=np.where(cutoff<a,0,np.where(cutoff<b,1,2))
        purged=((role==0)&(ts[o+11]>=freezes[0]))|((role==1)&(ts[o+11]>=freezes[1]))
        eligible=histvalid&(histmax<=cutoff)&targetvalid&(min_first>cutoff)&(max_target<=freezes[role])&~purged
        # Population is locked entirely by input dependencies/publication metadata before outcome census.
        s.save('SHORT_CONTEXT_METADATA_POPULATION.npz',origin=o,cutoff=cutoff,role=role,eligible=eligible,historical_publication_max=histmax,label_publication_max=max_target)
        old=np.load(s.N/'PUBLICATION_CORRECTED_ORIGINS.npz');oldset=old['origins'][old['eligible']];intersection=np.isin(o,oldset)
        meta=dict(at=s.now(),prospective_context_steps=36,all_candidates=len(o),qualified=int(eligible.sum()),in_previous_population=int((eligible&intersection).sum()),added_from_same_TRAIN=int((eligible&~intersection).sum()),no_outcome_filter=True,population_sha256=s.sha(s.N/'SHORT_CONTEXT_METADATA_POPULATION.npz'))
        s.write('SHORT_CONTEXT_METADATA_ADMISSION.json',meta)
        threshold=s.read(s.N/'PUBLICATION_CORRECTED_THRESHOLDS.json');cen=np.array(threshold['center']);th=np.array(threshold['thresholds'])
        prices=np.load(p['raw_prices'],mmap_mode='r');counts={};events={};review=0
        for start in range(0,len(o),256):
            s.guard();oo=o[start:start+256];rr=role[start:start+256];ok=eligible[start:start+256];tt=cutoff[start:start+256]
            x=np.asarray(prices[oo-1,:,0],float);f=np.asarray(prices[oo[:,None]+np.arange(12),:,0],float).transpose(0,2,1)
            normal=(abs(x-cen)<=th[0])&np.isfinite(x)&np.isfinite(f).all(2)
            delta=f-cen[None,:,None];hits=abs(delta)>th[1][None,:,None];where=hits.argmax(2);hit=hits.any(2)
            cls=np.where(hit,np.where(np.take_along_axis(delta,where[:,:,None],axis=2)[:,:,0]>0,1,2),0)
            for which,mask in [('ALL_SHORT',ok),('COMMON_OLD',ok&intersection[start:start+256]),('ADDITIONAL',ok&~intersection[start:start+256])]:
                for role_id in range(3):
                    key=f'{which}/{role_id}';v=normal&(mask&(rr==role_id))[:,None]
                    r=counts.setdefault(key,dict(origins=0,pairs=0));r['origins']+=int(v.any(1).sum());r['pairs']+=int(v.sum())
                    for c in [1,2]:
                        j,node=np.where(v&(cls==c));events.setdefault((key,c),[]).extend((tt[j]+300*(where[j,node]+1)).tolist())
            # Direct publication replay, deterministic origins without event selection.
            for j in range(len(oo)):
                if (start+j)%1499:continue
                org=int(oo[j]);i=start+j
                check=all(bool(valid[k]) and int(last[k])<=int(cutoff[i]) for k in range(org-36,org)) and all(bool(valid[k]) and int(last[k])<=int(freezes[role[i]]) and int(firstpub[k])>int(cutoff[i]) for k in range(org,org+12)) and not purged[i]
                assert check==bool(eligible[i]);review+=1
        rows=[]
        for key,c in counts.items():
            arm,role_id=key.split('/');row=dict(population=arm,role=int(role_id),**c)
            for cls,name in [(1,'up'),(2,'down')]:
                values=events.get((key,cls),[]);times=np.unique(values)
                row[name]=dict(pairs=len(values),UTC_event_dates=len(np.unique(times//86400)),event_clusters_1h=int(1+np.sum(np.diff(times)>3600)) if len(times) else 0)
            rows.append(row)
        support=all(r[name][metric]>=p['minimum_event_dates'][str(r['role'])] for r in rows if r['population']=='ALL_SHORT' for name in ['up','down'] for metric in ['UTC_event_dates','event_clusters_1h'])
        for path,h in s.read(s.N/'PROTECTED_FILES.json').items():assert s.sha(path)==h
        report=dict(at=s.now(),metadata=meta,rows=rows,event_support_passed=support,metadata_scalar_replays=review,model_fits=0,V7_replaced=False,new_test_targets_read=False,
            scope='TRAIN-only feasibility of a NEW standalone3h hazard input contract. Original FULL/V7 and existing evaluation populations unchanged. These additional origins are not approved for models requiring24h/14d price history or RTD/DAM data.',
            next='Even if support passes, no weather acquisition or model fit until exact source coverage, class calibration and fair feature contract are registered; no claim of improvement from event counts.')
        s.write('SHORT_CONTEXT_FEASIBILITY.json',report);print(json.dumps(report,ensure_ascii=False))
if __name__=='__main__':main()
