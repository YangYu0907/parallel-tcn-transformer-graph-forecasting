"""Register chronology amendment and run only synthetic fitting QA before market fit."""
from pilot import *
import ast

def main():
    assert not (HERE/'PROTOCOL.json').exists()
    sources=[HERE/n for n in ['pilot.py','audit.py','manager.py','register.py']]
    for s in sources:compile(s.read_text(encoding='utf-8'),str(s),'exec')
    assert not any(isinstance(n,ast.Call) and isinstance(n.func,ast.Attribute) and n.func.attr in ['backward','step'] for n in ast.walk(ast.parse((HERE/'pilot.py').read_text(encoding='utf-8'))))
    with numeric('synthetic gate QA and timestamp-only partition eligibility'):
        import numpy as np
        rng=np.random.default_rng(7301);x=rng.normal(size=(100,10));g=rng.normal(size=(100,2))
        model=fit_risk(x[:50],g[:50,0],g[:50,1]);days=np.repeat(np.arange(5),5)
        margin=calibrate(model,x[50:75],g[50:75,0],g[50:75,1],days)
        before=route(model,margin,x[75:])[0]
        altered=g.copy();altered[75:]+=1e8
        model2=fit_risk(x[:50],altered[:50,0],altered[:50,1]);m2=calibrate(model2,x[50:75],altered[50:75,0],altered[50:75,1],days)
        assert model==model2 and margin==m2 and np.array_equal(before,route(model2,m2,x[75:])[0])
        assert np.all((before>=0)&(before<=.25)) and route(model,margin,np.full((1,10),1e20))[0][0]==0
        manifest=read(B/'phase_sampling_support_v3_20260923/dataset/ADDITIVE/manifest.json')
        def path(name):
            row=manifest['artifacts'][name];p=Path(row['path']);p=p if p.is_absolute() else B/p
            assert sha(p)==row['sha256'];return p
        times=np.load(path('timestamps_seconds.npy'));orig=np.load(path('june_origins.npy'));days=np.unique(times[orig-1]//86400)
        assert len(days)==19 and times[manifest['train_target_stop_exclusive']-1]<times[orig-1].min()
        qa=dict(at=now(),status='passed',future_label_perturbation_invariant=True,bounded_weight=True,out_of_support_fallback=True,
                history_and_model_fit_before_June=True,observed_dates=len(days),original_V7_protected=verify_protected())
        write(HERE/'QA.json',qa)
    cps={name:str(ROOT/'fair_runs'/f'20260813_{name}'/'epoch12.pt') for name in ['FULL_price_only','iTransformer_price_only']}
    refs=[ROOT/'fair_runs'/f'20260813_{name}'/'epoch12_june.npz' for name in cps]
    sources+=list(map(Path,cps.values()))+refs+[ROOT/'fair_inputs.py',ROOT/'common.py',HERE/'QA.json']
    write(HERE/'PROTOCOL.json',dict(at=now(),status='registered_before_new_market_fit',authorization='User asks to try efficiently, preserve V7',
        amendment='Current best.pt selected on whole June cannot support month-internal forward gate validation. Reuse fixed epoch12 saved weights for BOTH experts and ALL controls; original selected models untouched. Fixed epoch is training-budget endpoint, not selected for performance. Prior June inspection remains disclosed.',
        scope='Previously inspected June3397 only; one seed diagnostic; not independent confirmation and not V7 replacement',
        seed=20260813,backbone_fits=0,gate_fits=1,automatic_seed_expansion=False,budget_seconds=900,
        launch_GiB=5,runtime_GiB=4,threads=1,checkpoints=cps,bindings={str(s):sha(s) for s in sources},parent_seal_sha256=sha(ROOT/'FAIR_INPUT_SEAL.json'),
        split='First10 observedUTCdates fit; next4calibrate; last5forward development. Purge labels not fully realized before next block. Preserve calendar gaps.',
        candidate='H1-H7 identical fixed-epoch FULL; H8-H12 FULL+alpha*(iTransformer-FULL), alpha in[0,.25]',
        controls=['same_epoch_FULL','same_epoch_iTransformer','fixed25_H8','fixed50_H8'],
        gate='One two-output ridge, mean objective lambda1 unpenalized intercept; 10inputs fitmedian/IQR, clip6. Learn absolute/squared error benefit of fixed25 action. Calibration bias allowance max(0,mean_day_error+2*day_sd/sqrt(days)); heuristic, not risk guarantee. Min positive relative benefit of both heads, support min/max of fit inputs, otherwise exactzero. No threshold/weight/architecture search.',
        features=['lag1_ramp','lag12_ramp','std36','last_minus_mean288','last_minus_crossnode_median','expert_delta','abs_expert_delta','full_minus_last','other_minus_last','horizon_over12'],
        protection='V7 hashes unchanged; near5-35min bitwise unchanged from fixedepoch parent. All directions retained. State support >=5dates and allMAE/RMSE nonworse required for screen; known limited June events mean no automatic promotion or expansion even on aggregate gain.',
        no_new_test_targets=True,literature=['https://robjhyndman.com/papers/fforma.pdf','https://arxiv.org/html/1912.09363v3','https://www.sciencedirect.com/science/article/pii/S0169207016000327']))
    print(json.dumps(dict(status='registered',QA=qa,seed=20260813,backbone_fits=0,gate_fits=1)))

if __name__=='__main__':main()
