import json
import gate
def main():
    repair=gate.read(gate.HERE/'SUMMARY_REPAIR_LOCK.json')
    for name,digest in repair['bindings'].items():gate.need(gate.sha(gate.inside(name))==digest,'Repair input changed: '+name)
    s=gate.verify();r=gate.read(gate.HERE/'result.json');a=gate.read(gate.HERE/'numeric_audit.json')
    gate.need(a['status']=='passed' and a['result_sha256']==gate.sha(gate.HERE/'result.json'),'Unbound audit')
    rows={x['id']:x for x in r['results']};metrics=('mae','rmse','near_h1_4_mae','h12_mae');comparisons=[]
    for seed in (20260813,20260814):
        full=rows[f'CONTROL_FULL_{seed}']
        for model in ('TCN','EQUAL','CONCAT','GLOBAL','GTF','STATIC','SELF','DLinear','iTransformer-X'):
            other=rows[(f'CONTROL_{model}_' if model not in ('DLinear','iTransformer-X') else model+'_')+str(seed)]
            for panel in ('June284','June3397','balanced278'):
                if panel not in other['panels']:continue
                f=full['panels'][panel];o=other['panels'][panel]
                comparisons.append(dict(seed=seed,full_id=full['id'],comparator=other['id'],panel=panel,
                    full={k:f[k] for k in metrics},other={k:o[k] for k in metrics},
                    reduction_percent={k:100*(o[k]-f[k])/o[k] for k in metrics},
                    improved_node_mae=sum(x['mae']<y['mae'] for x,y in zip(f['by_node'],o['by_node'])),
                    improved_horizon_mae=sum(x['mae']<y['mae'] for x,y in zip(f['by_horizon'],o['by_horizon']))))
    gate.write(gate.HERE/'summary.json',dict(status='twenty_frozen_models_evaluated_and_audited',at=gate.now(),
        result_sha256=gate.sha(gate.HERE/'result.json'),audit_sha256=gate.sha(gate.HERE/'numeric_audit.json'),
        comparisons=comparisons,all_comparison_directions_retained=True,limitations=r['limitations'],
        scope='Completed original CONTROL-stage mechanism and external comparisons; newer sampling/retention are separate backbone-stage experiments.',
        heldout_targets_read=False,complete_research_experiment=False))
    print(json.dumps(dict(status='summary_completed',comparisons=len(comparisons))))
if __name__=='__main__':main()
