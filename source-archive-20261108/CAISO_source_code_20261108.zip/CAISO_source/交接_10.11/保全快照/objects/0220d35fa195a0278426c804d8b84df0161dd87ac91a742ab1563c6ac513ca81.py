"""G0: no-fit lineage, exact original replay and causal fixed-parent counterfactual."""
from pathlib import Path
import sys,json,os,time,importlib.util,types,csv,ast
G=Path(__file__).resolve().parent;B=G.parents[2];R=B/'reviewer_revision_v2_20261003'
A=B.parents[2];T=A/'运行依赖/CAISO_temporary_storage'
sys.path.insert(0,str(R))
import common as core
def write(name,obj):core.write(G/name,obj)
def load_np(path,keys=None):
 with np.load(path) as z:return {k:z[k] for k in (keys or z.files)}
def module(name,path):
 spec=importlib.util.spec_from_file_location(name,path);m=importlib.util.module_from_spec(spec);spec.loader.exec_module(m);return m
def metrics(y,p,mask=None):
 y=np.asarray(y,dtype=float);p=np.asarray(p,dtype=float)
 if mask is None:mask=np.ones(y.shape,dtype=bool)
 a=p-y;v=a[mask]
 if not len(v):return dict(cells=0)
 return dict(cells=len(v),mae=float(abs(v).mean()),rmse=float(np.sqrt((v*v).mean())),bias=float(v.mean()))
def main():
 global np
 start=time.monotonic();checks=[];lineage=[];rows=[];source={};receipts=[]
 def bind(path,expected=None):
  h=core.sha(path);source[str(path)]=h
  if expected is not None:assert h==expected,str(path);checks.append('hash:'+str(path))
  return h
 def check(value,label):
  assert value,label;checks.append(label)
 def tick(**kw):
  core.guard()
  if time.monotonic()-start>5400:raise TimeoutError('G0 budget')
  write('G0_PROGRESS.json',dict(at=core.now(),**kw))
 with core.numeric('G0 lineage and fixed-parent no-fit replay'):
  import numpy as np
  assert core.verify_protected()==18
  v4=B/'adaptive_experts_v4_20260929';v7=B/'spike_specialist_v7_20260930'
  m=module('g0_v4_common',v4/'common.py');ns=dict(m.__dict__);ns['__name__']='g0_v4_worker'
  code=(v4/'worker.py').read_text(encoding='utf-8-sig').replace('from common import *','')
  exec(compile(code,str(v4/'worker.py'),'exec'),ns)
  ns['np']=np;ns['tick']=tick
  folds=core.read(v4/'FOLDS.json');ids=np.concatenate([f['evaluation'] for f in folds])
  bind(v4/'FOLDS.json')
  panelpath=T/'adaptive_experts_v4_20260929/panel.npz'
  bind(panelpath,core.read(v4/'FEEDBACK_ADMISSION.json')['panel_sha256'])
  data=load_np(panelpath)
  check(np.array_equal(data['available'],data['metadata_feedback_available']),'availability_matches_audited_publication')
  check(np.all(np.diff(data['cutoff'])>0),'origins_strictly_chronological')
  inv=core.read(B/'h1_final_evaluation_v1_20260927/ALL_PREDICTIONS_COMMITTED.json')
  frozen=core.read(B/'h1_final_evaluation_v1_20260927/FINAL_TEST_FREEZE.json')
  bind(B/'h1_final_evaluation_v1_20260927/FINAL_TEST_FREEZE.json',inv['freeze_sha256'])
  for f in folds:
   tr=np.array(f['train']);fit=np.array(f['fit']);cal=np.array(f['calibration']);ev=np.array(f['evaluation'])
   check(data['available'][tr].max()<=data['cutoff'][ev[0]],f'fold{f["id"]}:all_fit_cal_labels_matured')
   check(np.intersect1d(tr,ev).size==0,f'fold{f["id"]}:no_overlap')
   receipts.append(dict(fold=f['id'],fit_origins=len(fit),cal_origins=len(cal),eval_origins=len(ev),
         first_utc=str(np.array(data['cutoff'][ev[0]]).astype('datetime64[s]')),
         last_utc=str(np.array(data['cutoff'][ev[-1]]).astype('datetime64[s]')),
         max_train_label_available=int(data['available'][tr].max()),eval_first_cutoff=int(data['cutoff'][ev[0]])))
  for seed in core.SEEDS:
   tick(stage='seed',seed=seed)
   ex_path=T/f'adaptive_experts_v4_20260929/experts/{seed}.npz';bind(ex_path)
   ex=load_np(ex_path,['origins','experts']);check(np.array_equal(ex['origins'],data['origins']),'expert_origins');experts=ex['experts']
   fixed=[]
   for variant,k in [('FULL',0),('DLinear',1)]:
    cid=f'{seed}_{variant}';case=next(c for c in frozen['cases'] if c['id']==cid)
    ck=B/str(case['checkpoint']).replace('\\','/').split('asof_retraining_branch_20260913/',1)[1]
    bind(ck,case['checkpoint_sha256'])
    pp=B/f'h1_final_evaluation_v1_20260927/predictions/{cid}/predictions.npz';bind(pp,inv['cases'][cid]['prediction_sha256'])
    p=load_np(pp,['origins','prediction'])
    check(np.array_equal(p['prediction'],experts[...,k]),cid+':expert_exact_original')
    fixed.append(dict(model=variant,checkpoint=str(ck),checkpoint_sha256=core.sha(ck)))
   p7=T/f'spike_specialist_v7_20260930/predictions/{seed}.npz'
   bind(p7,core.read(v7/f'receipts/{seed}.json')['sha256'])
   audit7=T/f'spike_specialist_v7_20260930/audited/{seed}.npz';bind(audit7)
   z7=load_np(audit7,['CONTEXT','truth','origins']);p7o=load_np(p7,['CONTEXT','eval_indices'])
   check(np.array_equal(z7['CONTEXT'],p7o['CONTEXT']),'V7_audited_equals_committed')
   check(np.array_equal(p7o['eval_indices'],ids),'V7_eval_ids_equal')
   check(np.array_equal(z7['truth'],data['truth'][ids]),'V7_targets_exact_known_development')
   specialist=[]
   for task in ['hazard','postexit']:
    mp=T/f'spike_specialist_v7_20260930/models/{seed}_CONTEXT_{task}.pkl'
    specialist.append(dict(path=str(mp),sha256=bind(mp)))
   base1=None;newparts=[];learned=[]
   for f in folds:
    fid=f['id'];ev=np.array(f['evaluation']);tr=np.array(f['train']);cal=np.array(f['calibration'])
    fp=T/f'adaptive_experts_v4_20260929/folds/{seed}_fold{fid}.npz'
    bind(fp,core.read(v4/f'receipts/{seed}_fold{fid}.json')['sha256'])
    z=load_np(fp)
    check(np.array_equal(z['eval_indices'],ev),'fold_ids')
    if base1 is None:base1={k:z[k] for k in ['conditional','functions','prior','temperature']}
    # Original and counterfactual use identical fold support and release schedule.
    args=(data,experts,tr,ev,cal)
    kw=dict(unsupported=z['unsupported'],pooled_allowed=z['pooled_allowed'])
    orig=ns['simulate'](*args,conditional=z['conditional'],functions=z['functions'],prior=z['prior'],temp=z['temperature'],**kw)
    err=float(np.max(abs(orig[0]['NEW5']-z['NEW5'])))
    check(err<1e-7,f'original_replay_{seed}_{fid}')
    cf=ns['simulate'](*args,conditional=base1['conditional'],functions=base1['functions'],prior=base1['prior'],temp=base1['temperature'],**kw)
    check(np.array_equal(orig[2],cf[2]),'matched_feedback_schedule')
    check(np.all(cf[2][:,2]<=cf[2][:,3]),'counterfactual_feedback_matured')
    ix=np.searchsorted(ids,ev);vp=z7['CONTEXT'][ix];obs=data['observable_regime'][ev]
    mask=np.broadcast_to((obs!=2)[...,None],vp.shape)
    check(np.array_equal(vp[mask],z['NEW5'][mask]),'nonextreme_V7_exact_V4')
    cp=vp.copy();cp[mask]=cf[0]['NEW5'][mask]
    check(np.array_equal(cp[~mask],vp[~mask]),'extreme_specialist_unchanged')
    if fid==1:check(np.max(abs(cp-vp))<1e-7,'first_fold_counterfactual_identity')
    newparts.append(cp)
    y=data['truth'][ev]
    out=dict(seed=seed,fold=fid,original_replay_max_abs=err,origins=len(ev),
       original=metrics(y,vp),fixed_parent=metrics(y,cp),FULL=metrics(y,experts[ev,...,0]),
       original_nonextreme=metrics(y,vp,mask),fixed_parent_nonextreme=metrics(y,cp,mask),
       original_h12=metrics(y[:,:,-1],vp[:,:,-1]),fixed_parent_h12=metrics(y[:,:,-1],cp[:,:,-1]),
       cells_changed=int(np.count_nonzero(abs(cp-vp)>1e-7)),
       full_to_v7_mean_correction=float((vp-experts[ev,...,0]).mean()),
       states={str(s):dict(original=metrics(y,vp,data['states'][ev]==s),
                          fixed_parent=metrics(y,cp,data['states'][ev]==s)) for s in range(6)})
    rows.append(out)
    models=[]
    for typ,n in [('loss',5),('functional',2)]:
     for k in range(n):
      mp=T/f'adaptive_experts_v4_20260929/models/{seed}_fold{fid}_{typ}{k}.pkl';models.append(dict(path=str(mp),sha256=bind(mp)))
    learned.append(dict(fold=fid,models=models))
    tick(stage='replay_complete',seed=seed,fold=fid)
    print(json.dumps(dict(seed=seed,fold=fid,original_mae=out['original']['mae'],fixed_parent_mae=out['fixed_parent']['mae'],replay_error=err)),flush=True)
   path=G/f'counterfactual/{seed}.npz';core.npz_save(path,origins=data['origins'][ids],prediction=np.concatenate(newparts))
   lineage.append(dict(seed=seed,fixed_backbones=fixed,TRAIN_fixed_specialist=specialist,
          rolling_parent=learned,counterfactual=str(path),counterfactual_sha256=bind(path)))
  mean=[]
  for fid in [1,2,3]:
   rs=[v for v in rows if v['fold']==fid]
   mean.append(dict(fold=fid,**{k:{j:float(np.mean([v[k][j] for v in rs])) for j in ['mae','rmse','bias']} for k in ['original','fixed_parent','FULL','original_nonextreme','fixed_parent_nonextreme','original_h12','fixed_parent_h12']}))
  check(core.verify_protected()==18,'protected_18_unchanged')
  write('G0_RESULT.json',dict(at=core.now(),status='no_fit_lineage_and_counterfactual_complete',checks=len(checks),check_names=checks,
       scope='Known 698-origin development only; not new independent evidence and not promoted',
       folds=receipts,lineage=lineage,rows=rows,mean_seed_by_fold=mean,
       fixed='Original backbone/scaler and V7 TRAIN-only extreme specialist',
       changing='V4 learned conditional-loss and residual-functional models refit on each prefix for inherited nonextreme path; released feedback calibration remains causal',
       counterfactual='Fix learned functions/loss/prior/temp at first legal fold, retain each evaluation fold support and feedback schedule, preserve V7 extreme forecasts exactly. Isolates learned-parent replacement given same fold policy, not every aspect of rolling adaptation.',
       new_fits=0,new_test_targets_read=False,V7_replaced=False,seconds=time.monotonic()-start,bindings=source))
 print('G0 complete',flush=True)
if __name__=='__main__':main()

