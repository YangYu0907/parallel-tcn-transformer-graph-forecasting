"""Two predeclared causal historical-price baselines, no fitting or test reader."""
import gate
from lear_runner import save_npz, metrics

def main():
    gate.verify(numeric=True)
    with gate.exclusive('CAISO_naive_June'):
        np,cap=gate.runtime()
        from compile_math import group_codes,close
        d=gate.data();target=np.load(d.paths['target_scaled.npy'],mmap_mode='r')
        thresholds=np.asarray(gate.read(d.paths['state_thresholds.json'])['thresholds'])
        results={}
        for part in ('june','june_dense'):
            gate.guard();o=d.origins[part]
            yy=np.asarray(target[o[:,None]+np.arange(12)],np.float64).transpose(0,2,1)*d.scale[None,:,None]+d.center[None,:,None]
            last=np.asarray(target[o-1],np.float64)*d.scale+d.center
            pred={'PERSISTENCE':np.repeat(last[:,:,None],12,axis=2),
                  'DAILY_SEASONAL':np.asarray(target[o[:,None]+np.arange(12)-288],np.float64).transpose(0,2,1)*d.scale[None,:,None]+d.center[None,:,None]}
            states=group_codes(yy,last,d.center,thresholds)
            for name,pp in pred.items():
                path=gate.HERE/'naive'/name/(part+'_outputs.npz')
                if path.exists():
                    with np.load(path,allow_pickle=False) as z:
                        gate.need(all(np.array_equal(z[k],v) for k,v in dict(origins=o,prediction=pp,truth=yy,states=states).items()),'Existing naive artifact changed')
                else:save_npz(path,origins=o,timestamps=d.times[o],prediction=pp,truth=yy,states=states)
                results.setdefault(name,{})[part]=dict(path=str(path),sha256=gate.sha(path),metrics=metrics(pp,yy,states))
        close(target)
        gate.write(gate.HERE/'naive/completion.json',dict(status='completed',at=gate.now(),results=results,sources=gate.sources(),heldout_targets_read=False))
        print('Two causal naive baselines complete',flush=True)

if __name__=='__main__':main()
