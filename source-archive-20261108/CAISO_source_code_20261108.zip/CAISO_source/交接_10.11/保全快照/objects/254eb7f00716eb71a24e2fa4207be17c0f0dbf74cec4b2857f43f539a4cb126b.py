"""Separate scoring, frozen-output checks and direct-history routing audit."""
from common import *
import json

def main():
    with gate.exclusive('adaptive_v2_independent_arithmetic_audit'):
        np,lim=gate.runtime(False)
        for path,digest in gate.read(HERE/'EXECUTION_SEAL.json')['bindings'].items():
            assert gate.sha(path)==digest,path
        p=gate.read(HERE/'PROTOCOL.json');done=gate.read(HERE/'FIT_COMPLETE.json')
        assert done['protocol_sha256']==gate.sha(HERE/'PROTOCOL.json')
        for q,s in done['prediction_hashes'].items():assert gate.sha(q)==s
        with np.load(HERE/'feedback.npz') as z:cut=z['cutoff'];ready=z['available']
        reports=[];checks=[];daily=[];counts={}
        for seed in p['seeds']:
            with np.load(HERE/'cache'/f'{seed}_experts.npz') as z:experts=z['experts'];truth=z['truth'];origins=z['origins']
            pieces=[]
            for f in (1,2,3):
                path=HERE/'folds'/f'{seed}_fold{f}.npz'
                with np.load(path) as z:d={k:z[k] for k in z.files}
                tr=d['train_indices'];ev=d['eval_indices'];trace=d['releases']
                assert np.array_equal(d['FULL'],experts[ev,:,:,0])
                assert np.array_equal(d['GB_DELTA'],experts[ev,:,:,3])
                assert np.array_equal(d['STATIC_ADD'],.5*(experts[ev,:,:,0]+experts[ev,:,:,3]))
                assert np.array_equal(d['truth'],truth[ev])
                assert np.all(ready[tr]<=cut[ev[0]])
                assert len(set(map(tuple,trace[:,:2])))==len(trace)
                assert np.all(trace[:,2]<=trace[:,3]) and np.all(cut[trace[:,0]]<trace[:,3])
                prior_calc=np.abs(experts[tr]-truth[tr,:,:,None]).mean((0,1))
                assert np.allclose(d['prior'],np.broadcast_to(prior_calc[None],d['prior'].shape))
                # Independent direct-history summation at fixed first/middle/last samples.
                for pos in sorted(set([0,len(ev)//2,len(ev)-1])):
                    j=ev[pos];now=cut[j];hist=[]
                    allowed=np.concatenate([tr,ev[ev<j]])
                    for half in (21600.,604800.):
                        risks=np.empty((30,12,4))
                        for h in range(12):
                            ids=allowed[ready[allowed,h]<=now]
                            w=np.exp(-np.log(2)*(now-cut[ids])/half)
                            loss=np.abs(experts[ids,:,h,:]-truth[ids,:,h,None])
                            risks[:,h,:]=((loss*w[:,None,None]).sum(0)+prior_calc[h])/(1+w.sum())
                        hist.append(risks)
                    scores=.5*np.maximum(d['conditional'][pos],0)+.25*hist[0]+.25*hist[1]
                    for name,k in [('JOINT3',3),('JOINT4',4)]:
                        log=-scores[:,:,:k]/d['temperature'][None,:,None]
                        log-=log.max(-1,keepdims=True);w=np.exp(log);w/=w.sum(-1,keepdims=True)
                        anchor=.25+.5*d['unsupported'][pos,:,None]
                        w*=1-anchor[:,:,None];w[:,:,0]+=anchor
                        assert np.allclose(w,d[name+'_weights'][pos],rtol=2e-6,atol=2e-7)
                for name,k in [('JOINT3',3),('JOINT4',4)]:
                    w=d[name+'_weights']
                    assert np.allclose(w.sum(-1),1,atol=2e-7) and (w>=0).all()
                    replay=(w.astype(np.float64)*experts[ev,:,:,:k]).sum(-1)
                    assert np.allclose(replay,d[name],rtol=2e-6,atol=1e-4)
                pieces.append(d);checks.append(f'{seed}_fold{f}:frozen_outputs_causal_trace_direct_history_weight_reconstruction')
                guard()
            merged={k:np.concatenate([d[k] for d in pieces]) for k in ['origins','truth']+p['arms']}
            with np.load(T/'audited_arrays'/f'{seed}.npz') as z:
                assert np.array_equal(z['origins'],merged['origins']) and np.array_equal(z['truth'],merged['truth'])
                codes=z['codes'];low=z['low_volatility']
            indices=np.searchsorted(origins,merged['origins'])
            dates=cut[indices].astype('datetime64[s]').astype('datetime64[D]')
            for state in range(6):
                mask=codes==state
                counts[f'S{state}']=dict(cells=int(mask.sum()),UTC_dates=int(np.unique(dates[mask.any((1,2))]).size))
            def stat(e):
                return dict(count=int(e.size),mae=float(np.abs(e).sum()/e.size) if e.size else None,
                    rmse=float(np.sqrt(np.square(e).sum()/e.size)) if e.size else None)
            for name in p['arms']:
                e=merged[name]-merged['truth'];v=stat(e)
                v.update(near_mae=stat(e[:,:,:4])['mae'],h12_mae=stat(e[:,:,11])['mae'],
                    low_volatility_mae=stat(e[low])['mae'],
                    states=[stat(e[codes==s]) for s in range(6)],
                    horizons=[stat(e[:,:,h]) for h in range(12)],nodes=[stat(e[:,n,:]) for n in range(30)])
                reports.append(dict(seed=seed,model=name,**v))
                for day in np.unique(dates):
                    x=e[dates==day];daily.append(dict(seed=seed,model=name,date=str(day),count=int(x.size),
                        sum_absolute_error=float(np.abs(x).sum()),sum_squared_error=float(np.square(x).sum())))
            guard()
        keys=['mae','rmse','near_mae','h12_mae','low_volatility_mae']
        means={name:{k:float(np.mean([r[k] for r in reports if r['model']==name])) for k in keys} for name in p['arms']}
        states={name:[{k:float(np.mean([r['states'][s][k] for r in reports if r['model']==name])) for k in ('mae','rmse')} for s in range(6)] for name in p['arms']}
        comparisons={base:{k:100*(1-means['JOINT4'][k]/means[base][k]) for k in keys} for base in ['FULL','FULL_SELECTED','JOINT3','STATIC_ADD','HORIZON_MIX']}
        tests=dict(mean_MAE_gain_at_least_half_percent=comparisons['FULL']['mae']>=.5,
            two_seeds_improve=sum(r['mae']<next(b['mae'] for b in reports if b['model']=='FULL' and b['seed']==r['seed']) for r in reports if r['model']=='JOINT4')>=2,
            secondary_metrics_protected=all(means['JOINT4'][k]<=means['FULL'][k]+1e-10 for k in keys[1:]),
            all_six_states_protected=all(states['JOINT4'][s][k]<=states['FULL'][s][k]+1e-10 for s in range(6) for k in ('mae','rmse')),
            original_selected_protected=all(means['JOINT4'][k]<=means['FULL_SELECTED'][k]+1e-10 for k in keys)
                and all(states['JOINT4'][s][k]<=states['FULL_SELECTED'][s][k]+1e-10 for s in range(6) for k in ('mae','rmse')))
        result=dict(at=gate.now(),status='exploratory_development_complete',means=means,per_seed=reports,
            states=states,state_counts_per_seed=counts,JOINT4_improvements_percent=comparisons,acceptance_checks=tests,
            candidate_passed=all(tests.values()),independent_confirmation=False,new_test_targets_read=False,
            scope='June2646 origins12 UTC cutoff dates30nodes12horizons; repeated development inspection',
            inference='No statistical significance or universal superiority claim from this development screening',
            manuscript_results_replaced=False)
        gate.write(HERE/'RESULT.json',result);gate.write(HERE/'DAILY_ERRORS.json',daily)
        gate.write(HERE/'AUDIT.json',dict(at=gate.now(),status='passed',checks=checks,
            audit_scope='Separate numerical reconstruction and all-case scoring; not external peer review',
            result_sha256=gate.sha(HERE/'RESULT.json'),fit_complete_sha256=gate.sha(HERE/'FIT_COMPLETE.json'),
            script_sha256=gate.sha(__file__),protocol_sha256=gate.sha(HERE/'PROTOCOL.json')))
        gate.write(HERE/'DECISION.json',dict(at=gate.now(),status='development_passed_pending_full_source_admission_and_confirmation' if all(tests.values()) else 'fixed_candidate_failed_development_not_promoted',
            candidate='JOINT4',acceptance_checks=tests,all_results_preserved=True,
            automatic_extra_training=False,automatic_test_opening=False,new_test_targets_read=False,
            next_action='Complete September source admission and freeze if passed; otherwise close this configuration and retain original FULL',
            result=str(HERE/'RESULT.json'),audit=str(HERE/'AUDIT.json')))
        print(json.dumps(dict(means=means,checks=tests,states=states['JOINT4'])),flush=True)

if __name__=='__main__':main()
