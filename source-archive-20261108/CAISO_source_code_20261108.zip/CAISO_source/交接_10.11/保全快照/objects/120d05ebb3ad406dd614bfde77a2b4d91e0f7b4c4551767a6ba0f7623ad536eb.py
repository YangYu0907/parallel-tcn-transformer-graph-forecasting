"""Separate fixed-panel scoring of post-hoc matched controls. No model selection."""
from run import *
import math,csv
def main():
 assert not (H/'RESULT.json').exists(),'Already scored; no repeat'
 p=read(H/'PROTOCOL.json');verify(p);c=read(H/'PREDICTIONS_COMMITTED.json');assert c['protocol_sha256']==gate.sha(H/'PROTOCOL.json')
 with gate.exclusive('V19 separate post-hoc matched-control scoring;zero fits'):
  np,lim=gate.runtime(False)
  for path,h in c['files'].items():assert gate.sha(path)==h,path
  with np.load(T/O.name/'targets.npz') as z:y=z['truth'].astype(float);states=z['states'];low=z['low_volatility'];origins=z['origins']
  assert np.array_equal(origins,p['origins']) and y.shape==(186,30,12)
  dates=(origins-300).astype('datetime64[s]').astype('datetime64[D]');days=np.unique(dates);assert len(days)==12
  old={x['seed']:x for x in read(O/'ALL_CASE_METRICS.json') if x['model']=='V7_FROZEN'}
  rows=[];daily={};checks=0
  def metric(e):return dict(count=int(e.size),mae=float(abs(e).mean()) if e.size else None,rmse=float(np.sqrt(np.square(e).mean())) if e.size else None)
  for anchor in p['anchors']:
   for seed in p['seeds']:
    gate.guard()
    with np.load(A/anchor/'predictions'/f'{seed}_all.npz') as z:pred=z['V7_FROZEN'];assert np.array_equal(z['origins'],origins)
    e=pred-y;m=metric(e)
    aa=math.fsum(float(abs(e[i,n]).sum()) for i in range(186) for n in range(30))/e.size
    ss=math.sqrt(math.fsum(float(np.square(e[i,n]).sum()) for i in range(186) for n in range(30))/e.size)
    assert abs(aa-m['mae'])<1e-10 and abs(ss-m['rmse'])<1e-10;checks+=2
    row=dict(anchor=anchor,seed=seed,**m,near_mae=metric(e[:,:,:4])['mae'],h12_mae=metric(e[:,:,-1])['mae'],low_volatility_mae=metric(e[np.broadcast_to(low[:,:,None],e.shape)])['mae'],states=[dict(state=k,**metric(e[states==k])) for k in range(6)],nodes=[metric(e[:,k]) for k in range(30)],horizons=[metric(e[:,:,k]) for k in range(12)])
    if anchor=='FULL':
     for k in ['mae','rmse','near_mae','h12_mae','low_volatility_mae']:assert abs(row[k]-old[seed][k])<1e-12;checks+=1
     assert row['states']==old[seed]['states'] and row['nodes']==old[seed]['nodes'] and row['horizons']==old[seed]['horizons'];checks+=3
    rows.append(row);daily[(anchor,seed)]=np.array([[abs(e[dates==d]).sum(),np.square(e[dates==d]).sum(),e[dates==d].size] for d in days])
  keys=['mae','rmse','near_mae','h12_mae','low_volatility_mae'];means={a:{k:float(np.mean([r[k] for r in rows if r['anchor']==a])) for k in keys} for a in p['anchors']}
  ds={a:np.mean([daily[a,s] for s in p['seeds']],0) for a in p['anchors']};rng=np.random.default_rng(p['statistics']['bootstrap_seed']);draws=[]
  for _ in range(p['statistics']['bootstrap_replicates']):
   ids=[int(rng.integers(len(days)))]
   for j in range(1,len(days)):
    prev=ids[-1];nxt=prev+1
    if rng.random()<.5 or nxt>=len(days) or int((days[nxt]-days[prev]).astype(int))!=1:nxt=int(rng.integers(len(days)))
    ids.append(nxt)
   draws.append(ids)
  draws=np.array(draws);comparisons=[]
  for a in p['statistics']['family']:
   x=ds[a];f=ds['FULL'];diff=x[:,0]-f[:,0];obs=diff.sum()/x[:,2].sum();centered=diff-obs*x[:,2]
   boot=100*(x[draws,0].sum(1)-f[draws,0].sum(1))/x[draws,0].sum(1);null=centered[draws].sum(1)/x[draws,2].sum(1)
   pv=float((1+np.sum(abs(null)>=abs(obs)))/(len(draws)+1))
   comparisons.append(dict(control=a,absolute_MAE_gain=float(obs),MAE_gain_percent=100*obs/means[a]['mae'],CI95_percent=np.quantile(boot,[.025,.975]).tolist(),p=pv,seed_MAE_wins=sum(next(r['mae'] for r in rows if r['anchor']=='FULL' and r['seed']==s)<next(r['mae'] for r in rows if r['anchor']==a and r['seed']==s) for s in p['seeds'])))
  order=np.argsort([z['p'] for z in comparisons]);running=0
  for i,j in enumerate(order):running=max(running,min(1,(len(order)-i)*comparisons[j]['p']));comparisons[j]['holm_p']=float(running)
  result=dict(at=gate.now(),status='posthoc_matched_deployment_scored',scope=p['scope'],mean_seed_metrics=means,comparisons=comparisons,all_cases=rows,origins=186,dates=list(map(str,days)),nodes=30,horizons=12,V7_exact_replay=c['V7_exact_replay'],all_prior_V7_metrics_identical=True,new_fits=0,new_training_updates=0,no_test_based_tuning=True,independent_new_test=False)
  verify(p);write(H/'RESULT.json',result)
  write(H/'AUDIT.json',dict(at=gate.now(),status='passed',separate_scoring_process_same_operator=True,result_sha256=gate.sha(H/'RESULT.json'),protocol_sha256=gate.sha(H/'PROTOCOL.json'),metric_checks=checks,prediction_hashes_verified=True,entire_common_panel=True,V7_predictions_and_every_profile_identical=True,new_test=False))
  write(H/'queue/status.json',dict(at=gate.now(),status='complete_audited_posthoc_controls',pid=None))
  print(json.dumps({'means':means,'comparisons':comparisons,'V7_unchanged':True},ensure_ascii=False),flush=True)
if __name__=='__main__':
 try:main()
 except BaseException as e:write(H/'queue/STOP.json',dict(at=gate.now(),error=repr(e),traceback=traceback.format_exc(),artifacts_preserved=True));raise
