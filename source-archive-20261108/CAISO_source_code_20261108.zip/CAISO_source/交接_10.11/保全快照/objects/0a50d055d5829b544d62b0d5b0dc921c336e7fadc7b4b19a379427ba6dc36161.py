from pathlib import Path
import subprocess,sys,json,hashlib,datetime
V=Path("C:\\Users\\于阳\\CAISO_feature_fusion_rev12\\asof_retraining_branch_20260913\\phase_sampling_support_v3_20260923")
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def execute(label,args,report=None):
 folder=V/'audits';out=folder/(label+'.stdout.log');err=folder/(label+'.stderr.log')
 with out.open('xb') as o,err.open('xb') as e:
  r=subprocess.run([sys.executable]+[str(a) for a in args],cwd=V.parent,stdout=o,stderr=e)
 d={'status':'completed' if r.returncode==0 else 'failed','exit_code':r.returncode,'command':[sys.executable]+list(map(str,args)),'stdout':str(out),'stderr':str(err),'at':datetime.datetime.now(datetime.timezone.utc).isoformat()}
 if report and report.exists():d['report_sha256']=sha(report)
 p=folder/(label+'.execution.json')
 with p.open('x',encoding='utf-8') as f:json.dump(d,f,indent=2)
 print(json.dumps({'label':label,'exit_code':r.returncode,'stderr':err.read_text(encoding='utf-8',errors='replace')[-1600:]}),flush=True)
 if r.returncode:raise SystemExit(r.returncode)
 return p
execute('compiler_final',[V/'source/independent_compiler_qa.py'],V/'independent_compiler_qa_results.json')
p=execute('runner_source_final',[V/'source/runner_source_qa.py'],V/'runner_synthetic_qa.json')
execute('runner_independent_final',[V/'audits/independent_runner_static.py','--source-execution-receipt',p,'--output',V/'audits/runner_independent_final.json'],V/'audits/runner_independent_final.json')
