"""Metadata admission and exact eight-model regression gate; stdlib only."""
from pathlib import Path
import copy
import hashlib
import json

QUEUE_LOCK_SHA='1a5335ff40f0d9082bcf9218d27839357da3207be5b6b4ad8d4214add8136db6'
QUEUE_PLAN_SHA='ea1b9da71a25b9624feb1328105aa250dee9257a8300b68e90cb4702e26b754b'
PRIOR_RESULT_SHA='3595a92dbd5c74bd81e9620a5ef6a4053c93ec5c167f6a40f57f71c32bb2581b'
PRIOR_AUDIT_SHA='326920db577cba6a1674426ba57f7daaef205ebe66a000ced0c4eac89dbfcc41'
PRIOR_LOCK_SHA='47d8f3a5b636182dce41e52ec823164f851662e7dc5e6270449e7594ac866013'
SEEDS=(20260813,20260814)
PRIMARY_IDS={f'CONTROL_{v}_{s}' for s in SEEDS for v in ('FULL','TCN','EQUAL','CONCAT')}
EXTERNAL_IDS={f'{v}_{s}' for s in SEEDS for v in ('DLinear','iTransformer-X')}
PRIOR_IDS={f'CONTROL_{v}_{s}' for s in SEEDS for v in ('FULL','TCN')}|EXTERNAL_IDS
PANEL_IDS=PRIMARY_IDS|EXTERNAL_IDS
ROW_FIELDS=('seed','model','kind','metrics','origins','nodes','horizons','forecast_cells','units',
            'source_indices','join','truth_matches_canonical','checkpoint_sha256',
            'selection_sha256','audit_sha256','prediction_sha256','source_selection_population')


def require(ok,message):
    if not bool(ok):raise RuntimeError(message)


def sha(path):
    h=hashlib.sha256()
    with Path(path).open('rb') as f:
        for block in iter(lambda:f.read(1024*1024),b''):h.update(block)
    return h.hexdigest()


def check_completion(completion,steps,lock_sha):
    require(completion.get('status')=='registered_internal_and_external_TRAIN_June_stages_independently_audited','Original queue has not completed')
    require(completion.get('post_backbone_lock_sha256')==lock_sha,'Queue completion lock mismatch')
    require(completion.get('Q3_evaluated') is False and completion.get('H1_evaluated') is False,'Queue target scope')
    ids=[s['id'] for s in steps]
    require(len(ids)==118 and len(set(ids))==118,'Original fixed118 step plan required')
    require(set(completion['step_receipts'])=={v+'.json' for v in ids},'All118 committed receipts required')


def bind_queue(bind,root):
    root=Path(root);folder=root/'post_backbone_queue_io_v2'
    # Deliberately fail before inspecting any target or model array if incomplete.
    completion=bind.json(folder/'completion.json')
    lock=bind.json(root/'POST_BACKBONE_LOCK_io_v2.json',QUEUE_LOCK_SHA)
    plan=bind.json(root/'POST_BACKBONE_PLAN_io_v2.json',QUEUE_PLAN_SHA)
    require(lock['status']=='sealed_finite_post_backbone_queue' and lock['plan_sha256']==QUEUE_PLAN_SHA,'Original queue source/plan seal')
    check_completion(completion,plan['steps'],QUEUE_LOCK_SHA)
    require(not (folder/'QUEUE.lock').exists(),'Queue manager has not released its own lock')
    state=bind.json(folder/'status.json')
    require(state.get('event')=='finite_post_backbone_completed' and state.get('completion_sha256')==sha(folder/'completion.json'),'Queue terminal completion event')
    for rel,digest in lock['sources'].items():bind.file(root/rel,digest)
    require(lock['required_predecessor_sha256']==plan['predecessor_queue_sha256'],'Queue predecessor lock')
    bind.file(root/plan['predecessor_queue'],lock['required_predecessor_sha256'])
    review=bind.json(root/'audits/post_backbone_independent_review_io_v2.json')
    require(review['status']=='passed' and review['post_backbone_lock_sha256']==QUEUE_LOCK_SHA,'Independent queue source review')
    for step in plan['steps']:
        receipt=bind.json(folder/'steps'/(step['id']+'.json'),completion['step_receipts'][step['id']+'.json'])
        require(receipt['post_backbone_lock_sha256']==QUEUE_LOCK_SHA and receipt['step']==step,'Step receipt/locked plan mismatch: '+step['id'])
        require(receipt['status'] in ('completed','accepted_existing_success_marker'),'Incomplete step: '+step['id'])
        if receipt['status']=='completed':require(receipt.get('exit_code')==0,'Nonzero actual step exit')
        marker=receipt['marker'];path=bind.file(marker['path'],marker['sha256'])
        expected=Path(step['success_marker']);expected=(root/expected if not expected.is_absolute() else expected).resolve()
        require(path==expected,'Wrong success marker for step')
        row=bind.json(path)
        require(row.get('status')==step['expected_status']==marker['status'],'Step success status differs')
        require(row.get('Q3_targets_read',False) is False and row.get('test_2026_targets_read',False) is False,'Forbidden target-access marker')
    for seed in SEEDS:
        for variant in ('FULL','TCN','EQUAL','CONCAT'):
            run=root/'stages/query'/f'{seed}_{variant}'/'runs/CONTROL'
            audit=bind.json(run/'control_audit.json');selected=bind.json(run/'selection.json')
            require(audit['status']=='passed' and audit['selection_sha256']==sha(run/'selection.json'),'Missing current final CONTROL audit')
            require(audit['identity']==selected['identity'] and selected['identity']['seed']==seed and selected['identity']['variant']==variant,'Control audit identity')
    return dict(completion=str((folder/'completion.json').relative_to(root)),completion_sha256=sha(folder/'completion.json'),
                source_lock='POST_BACKBONE_LOCK_io_v2.json',source_lock_sha256=QUEUE_LOCK_SHA,
                plan='POST_BACKBONE_PLAN_io_v2.json',plan_sha256=QUEUE_PLAN_SHA,required_tasks=118)


def bind_prior(bind,root):
    root=Path(root);folder=root/'validation_registered_20260919'
    result=bind.json(folder/'result.json',PRIOR_RESULT_SHA)
    audit=bind.json(folder/'independent_numeric_audit_20260920_v2.json',PRIOR_AUDIT_SHA)
    lock=bind.json(folder/'VALIDATION_LOCK.json',PRIOR_LOCK_SHA)
    execution=bind.json(folder/'run_execution_1b859862cbb5.json',audit['original_execution_sha256'])
    audit_execution=bind.json(folder/'independent_numeric_audit_execution_4762a940d8cb.json')
    require(audit['status']=='passed_independent_registered_June284_numeric_audit' and audit['case_count']==8 and audit['all_four_metrics_and_12_horizons_verified'] is True,'Original eight numerical audit')
    require(audit['result_sha256']==PRIOR_RESULT_SHA and audit['validation_lock_sha256']==PRIOR_LOCK_SHA,'Original numerical audit binding')
    require(execution['exit_code']==0 and execution['result_sha256']==PRIOR_RESULT_SHA and execution['validation_lock_sha256']==PRIOR_LOCK_SHA,'Original actual summary exit')
    require(audit_execution['exit_code']==0 and audit_execution['report_sha256']==PRIOR_AUDIT_SHA and audit_execution['global_lock_exists_after_exit'] is False,'Original actual audit exit')
    require(audit['Q3_targets_read'] is False and audit['H1_targets_read'] is False and audit['Torch_imported'] is False,'Original audit scope')
    require(result['status']=='passed_registered_June284_summary' and result['model_selection_performed'] is False,'Original frozen result')
    require(len(result['results'])==8 and {r['id'] for r in result['results']}==PRIOR_IDS,'Original fixed eight cases')
    bind.file(folder/'registered_summary.py',execution['source_sha256'])
    bind.file(folder/'independent_numeric_audit_20260920_v2.py',audit['independent_auditor_source_sha256'])
    for rel,digest in lock['sources'].items():bind.file(root/rel,digest)
    return dict(result=str((folder/'result.json').relative_to(root)),result_sha256=PRIOR_RESULT_SHA,
                validation_lock=str((folder/'VALIDATION_LOCK.json').relative_to(root)),validation_lock_sha256=PRIOR_LOCK_SHA,
                numeric_audit=str((folder/'independent_numeric_audit_20260920_v2.json').relative_to(root)),numeric_audit_sha256=PRIOR_AUDIT_SHA,
                execution=str((folder/'run_execution_1b859862cbb5.json').relative_to(root)),execution_sha256=sha(folder/'run_execution_1b859862cbb5.json'),
                numeric_audit_execution=str((folder/'independent_numeric_audit_execution_4762a940d8cb.json').relative_to(root)),
                numeric_audit_execution_sha256=sha(folder/'independent_numeric_audit_execution_4762a940d8cb.json'))


def check_prior_eight(candidate,prior):
    for key in ('registered_origins','node_order','canonical_truth_float64_sha256'):
        require(candidate[key]==prior[key],'Common population/truth differs from original eight: '+key)
    rows=candidate['results'];old=prior['results']
    require(len(rows)==12 and {r['id'] for r in rows}==PANEL_IDS,'Complete unique12 case panel required')
    require(len(old)==8 and {r['id'] for r in old}==PRIOR_IDS,'Original eight case identity')
    lookup={r['id']:r for r in rows}
    for row in old:
        actual=lookup[row['id']]
        for key in ROW_FIELDS:require(actual[key]==row[key],'Original eight differs exactly: '+row['id']+'/'+key)
    return dict(status='exactly_reproduced',cases=sorted(PRIOR_IDS),four_metrics_and_all12_horizons_exact=True,
                mappings_checkpoint_prediction_and_selection_hashes_exact=True)


def synthetic_gate_qa():
    steps=[{'id':f'step{i:03d}'} for i in range(118)]
    complete=dict(status='registered_internal_and_external_TRAIN_June_stages_independently_audited',post_backbone_lock_sha256='locked',
                  Q3_evaluated=False,H1_evaluated=False,step_receipts={s['id']+'.json':'digest' for s in steps})
    check_completion(complete,steps,'locked')
    bad=copy.deepcopy(complete);bad['step_receipts'].pop('step117.json')
    wrong=copy.deepcopy(complete);wrong['post_backbone_lock_sha256']='changed'
    forbidden=copy.deepcopy(complete);forbidden['H1_evaluated']=True
    for item in (bad,wrong,forbidden):
        try:check_completion(item,steps,'locked')
        except RuntimeError:pass
        else:raise RuntimeError('Invalid synthetic queue completion accepted')
    def row(ident):
        x={k:'synthetic' for k in ROW_FIELDS};x['id']=ident
        x['metrics']=dict(mae=1.,rmse=2.,near_h1_4_mae=3.,h12_mae=4.,mae_by_horizon=[1.]*12)
        return x
    prior=dict(registered_origins=[3,9],node_order=['synthetic'],canonical_truth_float64_sha256='synthetic',results=[row(i) for i in sorted(PRIOR_IDS)])
    candidate=copy.deepcopy(prior);candidate['results']=[row(i) for i in sorted(PANEL_IDS)]
    check_prior_eight(candidate,prior)
    for key in ('metrics','source_indices','prediction_sha256'):
        changed=copy.deepcopy(candidate);target=next(r for r in changed['results'] if r['id'] in PRIOR_IDS);target[key]='changed'
        try:check_prior_eight(changed,prior)
        except RuntimeError:pass
        else:raise RuntimeError('Original eight regression accepted')
    changed=copy.deepcopy(candidate);changed['results'][-1]=copy.deepcopy(changed['results'][0])
    try:check_prior_eight(changed,prior)
    except RuntimeError:pass
    else:raise RuntimeError('Duplicate/missing panel case accepted')
    return ['queue118_schema','missing_receipt_rejected','queue_lock_change_rejected','heldout_scope_rejected',
            'original_eight_exact_pass','changed_metrics_rejected','changed_mapping_rejected','changed_prediction_rejected','duplicate_panel_rejected']
