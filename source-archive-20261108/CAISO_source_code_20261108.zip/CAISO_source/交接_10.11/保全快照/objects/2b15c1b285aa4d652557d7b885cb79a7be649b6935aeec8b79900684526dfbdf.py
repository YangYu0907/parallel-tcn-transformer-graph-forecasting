import math,torch
from torch.nn import functional as F

def inactive_name(mode,name):
    if mode=='GTF':return name.startswith(('tcn.','attention.'))
    if mode in ('EQUAL','CONCAT'):return name.startswith('attention.')
    if mode=='GLOBAL':return name.startswith('attention.') and name!='attention.branch_bias'
    if mode=='SELF':return name.startswith(('graph.query.','graph.key.'))
    return False

def explicit_features(model,x):
    """Independent arithmetic path, including graph adjacency and feature fusion."""
    mode=getattr(model,'fusion_mode',model.variant)
    g=model.graph
    projected=F.linear(x,g.input_projection.weight,g.input_projection.bias)
    batch,steps,nodes,width=projected.shape
    seq=projected.permute(0,2,1,3).reshape(batch*nodes,steps,width)
    _,state=g.context_gru(seq)
    context=state[-1].reshape(batch,nodes,width)+g.node_embedding.unsqueeze(0)
    identity=torch.eye(nodes,dtype=torch.bool,device=x.device)
    if mode=='SELF':
        adjacency=identity.to(x.dtype).unsqueeze(0).expand(batch,-1,-1)
    else:
        ctx=g.node_embedding if mode=='STATIC' else context
        query=F.linear(ctx,g.query.weight)
        key=F.linear(ctx,g.key.weight)
        scores=query@key.transpose(-1,-2)/math.sqrt(width)
        val,idx=scores.masked_fill(identity,-torch.inf).topk(g.top_k,dim=-1)
        sparse=torch.full_like(scores,-torch.inf).scatter(-1,idx,val).masked_fill(identity,0.)
        adjacency=sparse.softmax(-1)
        if adjacency.ndim==2: adjacency=adjacency.unsqueeze(0).expand(batch,-1,-1)
    message=torch.einsum('bij,btjd->btid',adjacency,F.linear(projected,g.message.weight))
    encoded=F.layer_norm(projected+F.linear(F.gelu(message),g.output.weight,g.output.bias),
        g.norm.normalized_shape,g.norm.weight,g.norm.bias,g.norm.eps)
    tcn=torch.zeros_like(context) if mode=='GTF' else model.tcn(encoded)
    if mode=='TCN':
        fused=tcn.unsqueeze(2).expand(-1,-1,12,-1)
        raw=torch.stack((x[:,-1,:,0],x[:,-1,:,0]-x[:,-12:,:,0].mean(1)),-1)
        observed=torch.clamp(raw,min=-model.context_limits,max=model.context_limits)
        features=fused+model.price_context(observed).unsqueeze(2)
        return features,None,adjacency,fused
    seq=encoded.permute(0,2,3,1).reshape(batch*nodes,width,steps)
    tokens=F.avg_pool1d(F.avg_pool1d(seq,12,6,ceil_mode=True),6,6,ceil_mode=True).transpose(1,2)
    distant=model.transformer(tokens).reshape(batch,nodes,width)
    if mode=='GTF':
        weights=x.new_zeros((batch,nodes,12,2));weights[...,1]=1
    elif mode in ('EQUAL','CONCAT'):
        weights=x.new_full((batch,nodes,12,2),.5)
    elif mode=='GLOBAL':
        weights=model.attention.branch_bias.softmax(-1).view(1,1,1,2).expand(batch,nodes,12,2)
    else:
        query=F.linear(context,model.attention.query.weight).unsqueeze(2)+model.attention.horizon_embedding
        keys=F.linear(torch.stack((tcn,distant),2),model.attention.key.weight)
        logits=torch.einsum('bnhd,bnkd->bnhk',query,keys)/math.sqrt(width)
        weights=(logits+model.attention.branch_bias).softmax(-1)
    fused=weights[...,:1]*tcn.unsqueeze(2)+weights[...,1:]*distant.unsqueeze(2)
    if mode=='CONCAT':
        p=model.concat_projection[0]
        fused=F.gelu(F.linear(torch.cat((tcn,distant),-1),p.weight,p.bias)).unsqueeze(2).expand(-1,-1,12,-1)
    raw=torch.stack((x[:,-1,:,0],x[:,-1,:,0]-x[:,-12:,:,0].mean(1)),-1)
    observed=torch.clamp(raw,min=-model.context_limits,max=model.context_limits)
    features=fused+model.price_context(observed).unsqueeze(2)
    return features,weights,adjacency,fused

def explicit_forward(model,x):
    features,weights,adjacency,fused=explicit_features(model,x)
    return model.head(features),fused,adjacency
