"""Separate scoring path: reload saved predictions, verify routing, then score."""
import math
import numpy as np
import support as s

ROUTES=['PURE_DYNAMIC_SELF','PURE_STATIC_SELF','V7_DYNAMIC_SELF','V7_STATIC_SELF','V7_SELF_ONLY']
HEAD=['mae','rmse','near_mae','h12_mae','low_volatility_mae']
def basic(e):
 e=np.asarray(e,dtype=np.float64).ravel()
 if not len(e):return None
 return dict(n=len(e),mae=math.fsum(np.abs(e))/len(e),rmse=math.sqrt(math.fsum(e*e)/len(e)))
def score(pred,y,states,low):
 e=np.asarray(pred,np.float64)-np.asarray(y,np.float64);r=basic(e)
 r.update(near_mae=basic(e[:,:,:4])['mae'],h12_mae=basic(e[:,:,-1])['mae'],low_volatility_mae=basic(e[np.broadcast_to(low[:,:,None],e.shape)])['mae'])
 r['states']={str(k):basic(e[states==k]) for k in range(6)}
 r['nodes']=[basic(e[:,i]) for i in range(30)]
 r['horizons']=[basic(e[:,:,h]) for h in range(12)]
 return r
def average(items):
 if items[0] is None:return None
 if isinstance(items[0],dict):return {k:average([r[k] for r in items]) for k in items[0]}
 if isinstance(items[0],list):return [average([r[j] for r in items]) for j in range(len(items[0]))]
 return float(np.mean(items))
def bootstrap(difference,days,seed):
 # Origin cells are never resampled as independent observations.
 block=(days-days.min())//2;ids=np.unique(block)
 sums=np.array([difference[:,block==i].sum() for i in ids]);counts=np.array([difference[:,block==i].size for i in ids])
 rng=np.random.default_rng(seed);draw=rng.integers(len(ids),size=(1999,len(ids)))
 boot=sums[draw].sum(1)/counts[draw].sum(1)
 pv=min(1.,2*min((1+np.count_nonzero(boot<=0))/2000,(1+np.count_nonzero(boot>=0))/2000))
 return dict(mean_mae_gain=float(difference.mean()),ci95=np.quantile(boot,[.025,.975]).tolist(),p_unadjusted=pv,occupied_calendar_blocks=len(ids),calendar_block_ids=ids.tolist(),resamples=1999)
def holm(rows):
 order=sorted(range(len(rows)),key=lambda j:rows[j]['p_unadjusted']);running=0.
 for rank,j in enumerate(order):
  running=max(running,min(1.,(len(rows)-rank)*rows[j]['p_unadjusted']));rows[j]['p_holm']=running

def main(tick):
 protocol=s.verify();seeds=[];checks=[]
 def check(name,ok):
  checks.append(dict(check=name,passed=bool(ok)))
  if not ok:raise AssertionError(name)
 routes_enabled=[]
 for si,case in enumerate(protocol['cases']):
  tick(stage='audit_reload',seed=case['seed'])
  p=s.N/f'seed{si}.npz';check('receipt_hash_'+str(si),s.sha(p)==s.read(s.N/f'seed{si}.receipt.json')['sha256'])
  with np.load(p,allow_pickle=False) as z:d={k:z[k] for k in z.files}
  with np.load(case['V7'],allow_pickle=False) as z:check('frozen_V7_exact_'+str(si),np.array_equal(d['V7'],z['CONTEXT']) and np.array_equal(d['origins'],z['origins']))
  mask=d['learned_mask'];check('panel_counts_'+str(si),len(mask)==698 and mask.sum()==453)
  names=[k for k,v in d.items() if v.shape==(698,30,12) and k not in ['truth','states'] and not k.startswith('ACTION_')]
  for k in names:check('finite_'+str(si)+'_'+k,np.isfinite(d[k]).all())
  for route in ROUTES:
   anchor=d['SELF'] if route.startswith('PURE') else d['V7'];sel=d['ACTION_'+route]
   check('warmup_exact_'+str(si)+'_'+route,np.array_equal(d[route][~mask],anchor[~mask]))
   if route=='PURE_DYNAMIC_SELF':acts=[d['FULL']]
   elif route=='PURE_STATIC_SELF':acts=[d['STATIC']]
   elif route=='V7_DYNAMIC_SELF':acts=[anchor+.75*(d['FULL']-anchor),anchor+.75*(d['SELF']-anchor)]
   elif route=='V7_STATIC_SELF':acts=[anchor+.75*(d['STATIC']-anchor),anchor+.75*(d['SELF']-anchor)]
   else:acts=[anchor+.75*(d['SELF']-anchor)]
   expected=anchor.copy()
   for code,act in enumerate(acts,1):expected[sel==code]=act[sel==code]
   check('routing_exact_'+str(si)+'_'+route,sel.max()<=len(acts) and np.array_equal(d[route],expected))
  for fi in [1,2]:
   log=s.read(s.N/f'fold_s{si}_{fi}.json')
   check('fit_calibration_time_'+str(si)+'_'+str(fi),log['fit_last_available']<log['calibration_first_cutoff'])
   check('calibration_evaluation_time_'+str(si)+'_'+str(fi),log['calibration_last_available']<log['evaluation_first_cutoff'])
   for route,r in log['routes'].items():
    check('enable_from_calibration_'+str(si)+'_'+str(fi)+'_'+route,r['enabled']==all(r['checks'].values()))
    routes_enabled.append(dict(seed=case['seed'],fold=fi+1,route=route,**r))
  seeds.append(d)
 d=seeds[0]
 for si,ds in enumerate(seeds[1:],1):
  for k in ['truth','states','low','origins','cutoff','days','learned_mask']:check('common_panel_'+str(si)+'_'+k,np.array_equal(d[k],ds[k]))
 panels={};per_seed={};interventions={}
 for panel,mask in [('full698',np.ones(698,bool)),('learned453',d['learned_mask'])]:
  all_scores=[]
  for si,ds in enumerate(seeds):
   tick(stage='independent_score',panel=panel,seed=protocol['cases'][si]['seed'])
   all_scores.append({k:score(ds[k][mask],ds['truth'][mask],ds['states'][mask],ds['low'][mask]) for k in names})
  per_seed[panel]=all_scores;panels[panel]={k:average([r[k] for r in all_scores]) for k in names}
  interventions[panel]={}
  for route in ROUTES+['RAW_'+k for k in ROUTES]:
   stat=[]
   for ds in seeds:
    anchor=ds['SELF'] if route.replace('RAW_','').startswith('PURE') else ds['V7']
    e0=anchor[mask].astype(float)-ds['truth'][mask];e1=ds[route][mask].astype(float)-ds['truth'][mask];changed=ds[route][mask]!=anchor[mask]
    stat.append(dict(changed_fraction=float(changed.mean()),harmful_mae_fraction_among_changed=float((abs(e1[changed])>abs(e0[changed])).mean()) if changed.any() else None,
      mean_mae_gain_on_changed=float((abs(e0[changed])-abs(e1[changed])).mean()) if changed.any() else None,
      total_squared_error_gain=float((e0*e0-e1*e1).sum())))
   interventions[panel][route]=stat
 # Independent implementation sanity comparison against the fitting-side metric function.
 import experiment
 original=experiment.headline(d['V7'],d['truth'],d['low']);independent=per_seed['full698'][0]['V7']
 for k in HEAD:check('scoring_agreement_'+k,abs(original[k]-independent[k])<1e-10)
 acceptance={};table=panels['full698'];base=table['V7'];cand=table['V7_DYNAMIC_SELF']
 acceptance['strict_mae_improvement']=cand['mae']<base['mae']-1e-12
 acceptance['two_of_three_seed_mae_improvements']=sum(r['V7_DYNAMIC_SELF']['mae']<r['V7']['mae']-1e-12 for r in per_seed['full698'])>=2
 for k in HEAD[1:]:acceptance[k+'_nonworse']=cand[k]<=base[k]+1e-12
 state_support={}
 for state in range(6):
  sk=str(state);sm=d['states']==state;dates=int(len(np.unique(d['days'][sm.any((1,2))])))
  supported=bool(sm.sum()>0 and dates>=3);state_support[sk]=dict(cells=int(sm.sum()),UTC_dates=dates,supported=supported)
  acceptance['S'+sk+'_supported']=supported
  for k in ['mae','rmse']:acceptance['S'+sk+'_'+k+'_nonworse']=bool(supported and cand['states'][sk][k]<=base['states'][sk][k]+1e-12)
 stats={};pairs=[('V7_DYNAMIC_SELF','V7'),('V7_STATIC_SELF','V7'),('V7_DYNAMIC_SELF','V7_STATIC_SELF'),('PURE_DYNAMIC_SELF','PURE_STATIC_SELF')]
 for panel,mask in [('full698',np.ones(698,bool)),('learned453',d['learned_mask'])]:
  stat=[]
  for j,(candidate,baseline) in enumerate(pairs):
   diff=np.stack([abs(ds[baseline][mask].astype(float)-ds['truth'][mask])-abs(ds[candidate][mask].astype(float)-ds['truth'][mask]) for ds in seeds])
   stat.append(dict(candidate=candidate,baseline=baseline,**bootstrap(diff,d['days'][mask],20261004+j)))
  holm(stat);stats[panel]=stat
 check('protected_artifacts_unchanged',s.verify()==protocol)
 result=dict(at=s.now(),status='completed_known_development_experiment',actual_scalar_fits=60,backbone_training_updates=0,
   seeds=[r['seed'] for r in protocol['cases']],screen_passed=all(acceptance.values()),acceptance=acceptance,
   full_panel=dict(origins=698,UTC_dates=len(np.unique(d['days'])),nodes=30,horizons=12),learned_origins=453,
   panels=panels,per_seed=per_seed,state_support=state_support,interventions=interventions,calibration_decisions=routes_enabled,statistics=stats,
   units='USD/MWh; three-seed mean of per-seed metrics; all states, nodes, horizons retained',
   interpretation='Repeatedly inspected H1 development only. Bootstrap is exploratory, not a new independent confirmation. No automatic promotion or additional search.',
   V7_replaced=False,new_test_targets_read=False,first_entry_forward_source_problem_resolved=False)
 s.write('RESULT.json',result)
 s.write('AUDIT.json',dict(at=s.now(),passed=True,independent_scoring_implementation=True,independent_human_reviewer=False,checks=checks,
   result_sha256=s.sha(s.N/'RESULT.json'),protocol_sha256=s.sha(s.N/'PROTOCOL.json'),protected_artifacts=len(s.read(s.N/'PROTECTED_FILES.json')),
   prediction_hashes={str(s.N/f'seed{i}.npz'):s.sha(s.N/f'seed{i}.npz') for i in range(3)}))
 lines=['输出收益门控：本轮实际训练结果','60个标量收益回归器，3个种子×2个时间窗口×5个动作×2个损失；不是60次主干重训。','共同开发面板：698起点、42个UTC日期、30节点、12步；前245起点不干预，后453起点评估新门控。','V7和已归档论文保持不变；无新测试目标读取。','']
 for panel in ['full698','learned453']:
  lines.extend([panel,'模型 | MAE | RMSE | 近端MAE | H12 MAE | 低波动MAE'])
  for k in names:
   r=panels[panel][k];lines.append(k+' | '+' | '.join(f'{r[h]:.6f}' for h in HEAD))
  lines.append('')
 lines+=['主候选完整门槛通过：'+str(result['screen_passed']),'未通过项：'+', '.join(k for k,v in acceptance.items() if not v),'','各状态：V7 -> 主候选（MAE / RMSE）']
 for sk in map(str,range(6)):
  r0=base['states'][sk];r1=cand['states'][sk]
  lines.append('S'+sk+': '+str(r0)+' -> '+str(r1))
 lines+=['','原始未筛选门控及所有匹配对照完整保存在RESULT.json。','此处为已反复使用的开发数据，不作为新独立确认；前瞻版本台账缺口仍存在。']
 (s.N/'本轮实际训练结果.txt').write_text('\n'.join(lines),encoding='utf-8')
 return result

if __name__=='__main__':
 raise SystemExit('Run under the registered single-worker manager')
