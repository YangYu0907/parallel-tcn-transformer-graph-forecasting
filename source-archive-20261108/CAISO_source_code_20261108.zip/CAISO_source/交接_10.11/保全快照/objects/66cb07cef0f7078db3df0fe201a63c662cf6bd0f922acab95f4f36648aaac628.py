"""Preserve the failed V26 screen and record verified attribution and next decision."""
import json
import os
import uuid
import common as c


def main():
    event_number = '576d0497bbb57efc2407845763326aff207f80295fa6a91c96ddeab8c5d62a9d'
    event_file = c.B / 'event_driven_automation/inbox/v26_temporal_memory_unexpected_result_85ffe960a7475f3eabb7e20b2a891f360fad4dc221003466eb3ab2392fbd1ba9.json'
    c.verify()
    d = c.read(c.HERE / 'DECISION.json')
    a = c.read(c.HERE / 'AUDIT.json')
    r = c.read(c.HERE / 'attribution/RESULT.json')
    check = c.read(c.HERE / 'attribution/REVIEW.json')
    assert not d['passed'] and a['status'] == check['status'] == 'passed'
    assert a['result_sha256'] == c.sha(c.HERE / 'RESULT.json')
    assert a['decision_sha256'] == c.sha(c.HERE / 'DECISION.json')
    assert check['attribution_result_sha256'] == c.sha(c.HERE / 'attribution/RESULT.json')
    assert not (c.HERE / 'EVENT_HANDLING.json').exists(), 'Event already handled'
    row = next(x for x in r['prediction_diagnostics'] if x['arm'] == 'TOKEN' and x['epoch'] == 2)
    state3, state4 = row['states'][3:5]
    case = c.read(c.HERE / 'RESULT.json')['cases'][0]
    token = case['arms']['TOKEN']['selected']['metrics']['June3397']
    parent = case['arms']['TOKEN']['history'][0]['metrics']['June3397']
    summary = case['arms']['SUMMARY']['selected']['metrics']['June3397']
    metrics = []
    for key in ('mae', 'rmse', 'near_h1_4_mae', 'h12_mae'):
        metrics.append(dict(metric=key, parent=parent[key], summary=summary[key], token=token[key],
                            error_reduction_percent=100*(parent[key]-token[key])/parent[key]))
    protected = c.protected()
    review = dict(
        at=c.now(), event_number=event_number, status='closed_screen_attribution_completed_V7_unchanged',
        scope=dict(panel='June3397 development', origins=3397, utc_dates=19, nodes=30, horizons=12,
                   seed=20260813, completed_seeds=1, planned_seeds_not_run=2, units='USD/MWh'),
        headline=metrics, state_regressions=[
            dict(state=s['state'], cells=s['cells'], utc_dates=s['dates'], parent_mae=s['parent_mae'], token_mae=s['mae'],
                 mae_increase_percent=100*(s['mae']/s['parent_mae']-1), parent_rmse=s['parent_rmse'], token_rmse=s['rmse'])
            for s in (state3, state4)],
        inference=d['inference'],
        observations=[
            'TOKEN improves overall MAE/RMSE and near MAE, but misses the fixed 0.5% MAE screen and worsens H12 MAE. S3/S4 also regress.',
            'At epoch2, horizon1-6 MAE gains are positive and horizon7-12 negative. This observed division is diagnostic, not a deployable cutoff selected from June.',
            'S3 parent signed errors are all positive in this panel; 89.57% of TOKEN corrections raise the prediction further.',
            'S4 already regresses in the TRAIN resubstitution replay; a purely unseen-month-shift explanation is insufficient.',
            'Near/far TRAIN gradient cosine is only weakly negative in aggregate; most batches are not opposed. The previously unsuccessful PCGrad route is not reopened.'
        ],
        numerical_attribution=dict(
            horizon_correction_mean_correlation=row['mean_offdiagonal_horizon_correlation'],
            correction_first_covariance_component_share=row['correction_first_covariance_component_share'],
            S3_positive_correction_fraction=state3['positive_correction_fraction'],
            S3_MSE_change=state3['mse_change'], S3_error_correction_cross_term=state3['mse_cross_term'],
            S3_correction_square_term=state3['mse_correction_size'],
            S3_cross_term_share=state3['mse_cross_term']/state3['mse_change'],
            gradient_diagnosis=r['gradient_diagnosis']),
        hypotheses=[
            'Access to temporal tokens may supply a small useful signal, but the shared residual readout learns similar corrections across horizons.',
            'The current objective and representation may not adequately distinguish persistence from recovery when a positive correction is useful for one target and harmful for another.',
            'High correlation is not proof of the causal bottleneck. Rare-state support and repeated development selection remain alternative explanations.'
        ],
        decision=[
            'Close V26 with its original screen; do not add epochs, seeds, tune cutoffs or revise its pass threshold.',
            'Do not replace V7 or manuscript main results. The parent here is one frozen FULL seed, not the three-seed V7 system.',
            'Prepare one explicitly separate horizon-conditioned-readout comparison before considering larger expert systems; do not label this proposed remedy validated.',
            'Any later replacement still requires matched fusion/graph controls, V7 integration and a newly admitted independent test.'
        ],
        limits=[
            'One selected seed on already inspected development data, not independent confirmation.',
            'S3/S4 each span three UTC dates; cells and overlapping horizons are dependent.',
            'State labels use target outcomes and may only be diagnostic or TRAIN supervision, never prediction-time routing inputs.',
            'TRAIN replay is in-sample. Gradient diagnosis is local to one selected checkpoint.',
            'Original model audit: separate script and process, same operator. Attribution review independently checks prediction arithmetic, not an external human review.'
        ],
        audit=dict(original_checks=a['checks'], attribution_prediction_checks=check['checks'],
                   files_unchanged=protected, independent_TRAIN_replay=False),
        new_test_targets_read=False, V7_preserved=True, training_running=False,
        complete_research_experiment=False)
    c.write(c.HERE / 'OUTCOME_REVIEW.json', review)
    next_step = dict(
        at=c.now(), status='designed_not_started_not_a_pass', fits_started=0,
        scope='Distinct exploratory follow-up, not continuation or reopening of V26',
        basis=str(c.HERE / 'OUTCOME_REVIEW.json'),
        question='Does explicit horizon conditioning of the residual value/output transform improve correction direction, beyond horizon-conditioned attention weights alone?',
        candidate='Retain frozen FULL and the V26 temporal memory/readout. Add one small feature-wise affine modulation of the attended16-dimensional value, conditioned on the original fused feature plus the frozen horizon embedding. Zero-initialized modulation and zero residual output reproduce the original parent at initialization. All original core modules remain.',
        control='Same trainable layers, parameter count, initialization, memory, query attention, samples, optimizer and two-pass budget; supply the mean horizon embedding only to the added modulation. The existing query and original fusion remain horizon-aware in both arms. This isolates direct horizon conditioning of the added value transform; it is not a general test of all horizon information.',
        implementation_boundary='Do not use June-derived horizon6 cutoff or target-derived state labels as gate features. No warm start from June-selected V26 weights. Start both readers from identical initializations on the same frozen original FULL parent.',
        potential_benefit='Allow different residual directions/magnitudes at different lead times instead of predominantly shared upward or downward adjustments.',
        costs_and_risks='Adds a small learned transform and two paired fits; increased capacity may overfit sparse transitions and need not fix state recognition. V7 remains unchanged throughout.',
        finite_budget=dict(first_seed=20260813, maximum_pilot_fits=2, epochs_per_fit=2, maximum_pilot_seconds=1800,
                           parameter_or_threshold_search=False),
        before_launch=[
            'Write exact equations, parameter count, immutable code/data hashes, paired sample-order and optimizer settings before any fit.',
            'Check zero-output equivalence, horizon broadcast, frozen parent, finite gradients, independent manual formula, causal input invariance and equal parameter count.',
            'Recheck no active numerical process/lock, pause state, at least5GiB available/commit and update manager-exit monitoring.'
        ],
        screen='Same June3397 primary; candidate MAE >=0.5% lower than the original parent and lower than matched control; RMSE, near/H12 MAE and all nonempty S0-S5 MAE/RMSE no worse than the parent. Missing support is not a pass. Keep all horizons, nodes, days and secondary panels. If any condition fails, close without another local search.',
        validation='One seed can only qualify expansion. If the pilot passes, register remaining two seeds and then fully matched controls/integration; no promotion or significant-advantage claim from this pilot.',
        literature=[
            dict(url='https://arxiv.org/abs/1912.09363', title='Temporal Fusion Transformers for Interpretable Multi-horizon Time Series Forecasting',
                 inspected='Author abstract', supports='Multi-horizon representations and feature/gating mechanisms; the exact proposed residual modulation is a new test, not a published guarantee.'),
            dict(url='https://arxiv.org/abs/2001.06782', title='Gradient Surgery for Multi-Task Learning',
                 inspected='Author abstract and prior local implementation', supports='Gradient interference is testable. Current evidence and failed V21 retention do not warrant a blind repeat.'),
            dict(url='https://jmlr.org/papers/v11/cawley10a.html', title='On Over-fitting in Model Selection and Subsequent Selection Bias in Performance Evaluation',
                 inspected='Journal abstract', supports='Repeated development selection can overfit; a new independent confirmation is required to update claims.')
        ],
        blocked_from_final_test_until='Fresh source admission AND final model/input/panel/statistics freeze; no reuse of inspected September/Europe2016 outcomes for selection.',
        core_modules_retained=True, V7_preserved=True, periodic_wakeups=False)
    c.write(c.HERE / 'NEXT_STEP.json', next_step)
    c.write(c.HERE / 'EVENT_HANDLING.json', dict(
        at=c.now(), event_id=c.read(event_file)['event_id'], event_number=event_number,
        event_file=str(event_file), event_sha256=c.sha(event_file),
        status='processed_direct_turn_report', new_numeric_training_started=False,
        original_manager_pid=21752, manager_exited=True,
        watcher_pid=2344, watcher_retained=True,
        evidence={str(c.HERE / name): c.sha(c.HERE / name) for name in
                  ('RESULT.json', 'DECISION.json', 'AUDIT.json', 'attribution/RESULT.json', 'attribution/REVIEW.json', 'OUTCOME_REVIEW.json', 'NEXT_STEP.json')},
        notification='Report this event directly once; do not re-enqueue the same evidence.',
        audit_reviewer_initial_failure='Auxiliary checker initially unpacked NumPy-only runtime as three outputs; corrected before computation. First attempt performed no fits, checkpoint changes or result writes.',
        protected_files_verified=protected, new_test_targets_read=False))
    path = c.B / 'HANDOFF.json'
    before = path.read_bytes()
    backup = c.HERE / 'HANDOFF_before_event_close.json'
    c.atomic(backup, lambda f: f.write(before))
    handoff = json.loads(before.decode('utf-8-sig'))
    handoff['status'] = 'V26_screen_closed_attribution_verified_V7_retained'
    handoff['research_training_active'] = False
    handoff['numeric_diagnostic_active'] = False
    handoff['complete_research_experiment'] = False
    handoff['next_action'] = 'V26 is closed; no extra seeds/epochs. Attribution and NEXT_STEP are recorded. Next bounded candidate requires implementation/QA and a new seal before launch. Fresh independent confirmation still requires source admission; V7 remains the retained paper version.'
    handoff['temporal_memory_v26'].update(active=False, outcome=str(c.HERE / 'OUTCOME_REVIEW.json'),
        attribution_review=str(c.HERE / 'attribution/REVIEW.json'), next_step=str(c.HERE / 'NEXT_STEP.json'),
        event_handling=str(c.HERE / 'EVENT_HANDLING.json'))
    assert path.read_bytes() == before, 'Concurrent handoff modification'
    tmp = path.with_name('.HANDOFF.' + uuid.uuid4().hex + '.tmp')
    with tmp.open('xb') as f:
        f.write(json.dumps(handoff, ensure_ascii=False, indent=2, allow_nan=False).encode('utf8'))
        f.flush()
        os.fsync(f.fileno())
    os.replace(tmp, path)
    print(json.dumps(dict(status=handoff['status'], headline=metrics, protected_files=protected), ensure_ascii=False))


if __name__ == '__main__':
    main()
