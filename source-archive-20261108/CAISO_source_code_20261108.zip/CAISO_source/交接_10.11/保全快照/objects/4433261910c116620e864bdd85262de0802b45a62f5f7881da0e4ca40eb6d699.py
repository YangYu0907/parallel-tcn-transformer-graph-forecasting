"""Read-only descriptive attribution; no fitting or candidate modifications."""
from pilot import *

def main():
    policy_check()
    with numeric('posthoc descriptive gate attribution, no new fit'):
        import numpy as np
        f=read(HERE/'GATE_FROZEN.json');a=read(HERE/'RESULT.json');audit=read(HERE/'AUDIT.json')
        assert audit['result_sha256']==sha(HERE/'RESULT.json')
        with np.load(HERE/'REPLAY.npz') as z:d={k:z[k] for k in z.files}
        pred=estimate(f['model'],d['X']);margin=np.array(f['margin']);alpha=d['alpha'].ravel()
        roles=np.repeat(d['role'],150);ev=d['role']==2;evalrows=roles==2
        block=[]
        for k in range(3):
            m=roles==k
            block.append(dict(role=k,origins=int((d['role']==k).sum()),
                actual_fixed25_tail_mae_benefit=float(d['scaled_gain_mae'][m].mean()*f['scale']),
                estimated_tail_mae_benefit=float(pred[m,0].mean()*f['scale']),
                actual_fixed25_tail_mse_benefit=float(d['scaled_gain_mse'][m].mean()*f['scale']**2),
                estimated_tail_mse_benefit=float(pred[m,1].mean()*f['scale']**2),
                activation=float((alpha[m]>0).mean()),mean_weight=float(alpha[m].mean())))
        activation=[]
        for s in range(6):
            mask=d['states'][ev][:,:,7:]==s
            row=dict(state=s,tail_cells=int(mask.sum()),active=int((d['alpha'][ev][mask]>0).sum()),
                     mean_weight=float(d['alpha'][ev][mask].mean()) if mask.any() else None)
            for key in ['full','fixed25','fixed50','candidate']:
                m=d['states'][ev]==s;e=(d[key][ev]-d['truth'][ev])[m]
                row[key]=dict(mae=float(abs(e).mean()),rmse=float(np.sqrt(np.mean(e**2)))) if len(e) else None
            activation.append(row)
        daily=[]
        for day in np.unique(d['dates'][ev]):
            m=ev&(d['dates']==day)
            daily.append(dict(date=str(np.datetime64(int(day),'D')),origins=int(m.sum()),
                rows=[dict(model=key,**metrics(d[key][m],d['truth'][m])) for key in ['full','other','fixed25','fixed50','candidate']]))
        gate_m=pred[:,0]>margin[0];gate_s=pred[:,1]>margin[1]
        blocked=evalrows&(alpha==0);active=evalrows&(alpha>0)
        detail=dict(mae_head_pass_fraction=float(gate_m[evalrows].mean()),mse_head_pass_fraction=float(gate_s[evalrows].mean()),
            both_pass_fraction=float((gate_m&gate_s)[evalrows].mean()),
            fixed25_actual_mean_mae_benefit_on_blocked=float(d['scaled_gain_mae'][blocked].mean()*f['scale']),
            fixed25_actual_mean_mae_benefit_on_active=float(d['scaled_gain_mae'][active].mean()*f['scale']),
            scope='Post-hoc description only; forward labels are used for attribution, never as routing inputs or new parameter selection')
        parent=a['rows'][0];candidate=a['rows'][-1]
        gains={k:100*(parent[k]-candidate[k])/parent[k] for k in ['mae','rmse','near_mae','h12_mae']}
        result=dict(at=now(),status='closed_no_promotion',registered_pilot_sha256=sha(HERE/'PROTOCOL.json'),
            result_sha256=sha(HERE/'RESULT.json'),audit_sha256=sha(HERE/'AUDIT.json'),
            gate_sha256=sha(HERE/'GATE_FROZEN.json'),posthoc_script_sha256=sha(Path(__file__)),
            improvements_percent=gains,block_diagnostics=block,state_activation=activation,daily=daily,gate_passes=detail,
            new_fits=0,decision='The conditional gate does not beat the predeclared simple controls. Retain diagnostic result and V7; no gate-grid, seed expansion, or promotion based on this panel.',
            protected_files_verified=verify_protected(),new_test_targets_read=False)
        write(HERE/'DIAGNOSIS.json',result)
        print(json.dumps(dict(improvements=gains,blocks=block,states=activation,gate_passes=detail)))

if __name__=='__main__':main()
