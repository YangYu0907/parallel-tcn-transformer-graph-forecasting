from common import *
def main():
    with gate.exclusive('V7 synthetic hazard and causal-feature QA'):
        np,lim=gate.runtime(False);import worker as w;import prepare as p;w.np=p.np=np
        classes=np.array([[2,2,0,1,2,2,2,2,2,2,2,2],[2]*12,[0]*12])
        risk,event,post=w.targets(classes);assert risk[0].sum()==3 and event[0,2] and post[0].sum()==10
        assert risk[1].all() and not event[1].any() and not post[1].any();assert event[2,0] and post[2].all()
        hazard=np.full((2,12),.2);after=np.zeros((2,12,3));after[:,:,0]=1
        probs,s=w.survival_probabilities(hazard,after);assert np.allclose(s,.8**np.arange(1,13));assert np.allclose(probs[:,:,2],s);assert np.allclose(probs.sum(-1),1)
        after[:,:,0]=.5;after[:,:,2]=.5;probs,s=w.survival_probabilities(hazard,after);assert np.allclose(probs[:,:,2],.5+.5*s)
        hist=np.zeros((288,30,29),np.float32);hist[-3:,0,0]=[3,4,3];hist[-288:,1,0]=3
        sc={'price_scale':np.ones((1,30,4)).tolist()};th={'thresholds':[np.ones(30).tolist(),(np.ones(30)*2).tolist()]}
        price,context,ages=p.new_features(hist,np.array([0,1]),sc,th);assert ages.tolist()==[3,288];assert price.shape==(2,24) and context.shape==(2,90);assert price[1,2]==1
        future=np.full((12,30,29),1000.,np.float32);combined=np.concatenate([hist,future]);a=p.new_features(combined[:288],np.array([0,1]),sc,th);combined[288:]=-1e6;b=p.new_features(combined[:288],np.array([0,1]),sc,th)
        assert all(np.array_equal(x,y) for x,y in zip(a,b))
        full=np.ones((2,30,12));pred,weights=w.specialist(full,full+4,full+2);assert np.allclose(pred,full+1.5);assert weights[...,0].min()==.25
        pred,weights=w.specialist(full,full+1,full-1);assert np.array_equal(pred,full) and (weights[...,0]==1).all()
        # Predictive routing must not depend on future truth or scoring state.
        data=dict(origins=np.arange(2),observable_regime=np.zeros((2,30),int),raw_last=np.full((2,30),3.),truth=np.zeros((2,30,12)),states=np.zeros((2,30,12),int));data['observable_regime'][:,0]=2
        expert=np.repeat(full[...,None],5,-1);expert[...,1]=3;expert[...,2]=-2
        probs={k:np.broadcast_to([.6,.2,.2],(2,30,12,3)).copy() for k in ('DURATION','CONTEXT')};mus=np.zeros((2,30,12,3));qs=np.tile(np.linspace(-.1,.1,31),(3,1));th['center']=np.zeros(30).tolist()
        r=w.forecast(data,[0,1],expert,full,full,probs,mus,qs,np.array([.4,.2,.4]),th);data['truth'][:]=9999;data['states'][:]=5
        r2=w.forecast(data,[0,1],expert,full,full,probs,mus,qs,np.array([.4,.2,.4]),th)
        for arm in ARMS:assert np.array_equal(r[arm],r2[arm]);assert np.array_equal(r[arm][:,1:],full[:,1:])
        write(HERE/'QA.json',dict(at=gate.now(),status='passed',checks=['first-exit risk sets and right censoring','analytic survival and post-exit re-entry','observed duration and historical window censor flag','future-input mutation invariant','probability simplex','FULL anchor and opposite-functionals fallback','full routing independent of future targets/states','nonextreme exact preservation'],real_market_targets_read=False))
        files=[HERE/n for n in ('common.py','prepare.py','worker.py','audit.py','manager.py','qa.py','PROTOCOL.json','SOURCE_BINDINGS.json','QA.json')]
        write(HERE/'EXECUTION_SEAL.json',dict(at=gate.now(),bindings={str(p):gate.sha(p) for p in files}));print('V7 meaningful QA passed; code sealed')
if __name__=='__main__':main()
