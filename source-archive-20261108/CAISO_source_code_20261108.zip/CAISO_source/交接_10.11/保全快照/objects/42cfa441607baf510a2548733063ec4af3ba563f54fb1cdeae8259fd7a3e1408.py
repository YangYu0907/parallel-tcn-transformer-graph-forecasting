"""Shared I/O and deterministic training helpers; only admitted TRAIN/June."""
import copy
import hashlib
import random
import sys
import gate as g
np=torch=None


def init():
    global np,torch
    np,torch,limiter=g.runtime()
    sys.path.append(str(g.ROOT/'common_sampling_evaluation_20260923'))
    return limiter


def data():
    from compiled_data import CompiledData
    d=CompiledData(str(g.MANIFEST))
    g.need(len(d.origins['june_dense'])==3397 and len(d.origins['june'])==284,'Changed panel count')
    g.need((d.origins['june_dense']>=210528).all() and (d.origins['june_dense']+12<=219168).all(),'Outside June')
    return d


def parent(seed,variant):
    base='CONCAT' if variant=='CONCAT_CONT' else 'FULL'
    return next(p for p in g.read(g.HERE/'PROTOCOL.json')['parents'] if p['seed']==seed and p['variant']==base)


def model(seed,variant,limits):
    from models.factory import build_backbone
    from model import ResidualFusion
    m=ResidualFusion(seed,limits) if variant=='RESIDUAL' else build_backbone('CONCAT' if variant=='CONCAT_CONT' else 'FULL',seed,limits)
    p=parent(seed,variant);g.need(g.sha(p['checkpoint'])==p['sha256'],'Parent changed')
    saved=torch.load(p['checkpoint'],map_location='cpu',weights_only=False)
    state=saved['state_dict'];del saved
    if variant=='RESIDUAL':
        state=dict(state);state['residual_scale']=torch.zeros(())
    m.load_state_dict(state,strict=True)
    return m


def optimizer(m):
    return torch.optim.AdamW(m.parameters(),lr=.0001,weight_decay=.0001,betas=(.9,.999),eps=1e-8)


def update(m,opt,x,y):
    opt.zero_grad(set_to_none=True)
    loss=torch.nn.functional.huber_loss(m(x)['prediction'],y,delta=.5)
    g.need(torch.isfinite(loss),'Nonfinite loss');loss.backward()
    g.need(all(p.grad is not None and torch.isfinite(p.grad).all() for p in m.parameters() if p.requires_grad),'Invalid gradient')
    norm=torch.nn.utils.clip_grad_norm_(m.parameters(),1.)
    g.need(torch.isfinite(norm),'Invalid gradient norm');opt.step()
    return float(loss.detach())


def seed_rng(seed):
    torch.manual_seed(seed+400000);np.random.seed(seed+400000);random.seed(seed+400000)
    return np.random.default_rng(seed+400000)


def rng_get(rng):
    return dict(torch=torch.get_rng_state().clone(),generator=copy.deepcopy(rng.bit_generator.state),numpy=np.random.get_state(),python=random.getstate())


def rng_set(v,rng):
    torch.set_rng_state(v['torch']);rng.bit_generator.state=copy.deepcopy(v['generator']);np.random.set_state(v['numpy']);random.setstate(v['python'])


def panel(d):
    return dict(role='development',name='June3397',origins_sha256=hashlib.sha256(d.origins['june_dense'].astype('<i8').tobytes()).hexdigest(),cells=3397*30*12)


def arrays(path,values):g.atomic(path,lambda f:np.savez(f,**values))


def evaluate(m,d):
    import reductions as red
    origins=d.origins['june_dense'];panels,_=red.panels(origins,d.origins['june'])
    order=np.r_[panels['June284'],np.flatnonzero(~np.isin(np.arange(len(origins)),panels['June284']))]
    pred=np.empty((len(origins),30,12),np.float64);truth=np.empty_like(pred);codes=np.empty(pred.shape,np.uint8)
    q=np.asarray(g.read(d.paths['state_thresholds.json'])['thresholds'])
    before={k:v.clone() for k,v in m.state_dict().items()};rng=torch.get_rng_state().clone();training=m.training;m.eval()
    with torch.no_grad():
        for start in range(0,len(order),4):
            g.guard();ix=order[start:start+4];x,y=d.batch('june_dense',ix)
            pred[ix]=m(torch.from_numpy(x))['prediction'].numpy().astype(np.float64)*d.scale[None,:,None]+d.center[None,:,None]
            truth[ix]=y.astype(np.float64)*d.scale[None,:,None]+d.center[None,:,None]
            codes[ix]=red.codes(truth[ix],x[:,-1,:,0],d.center,d.scale,q)
    g.need(torch.equal(rng,torch.get_rng_state()),'Evaluation consumed RNG')
    g.need(all(torch.equal(v,before[k]) for k,v in m.state_dict().items()),'Evaluation mutated model')
    g.need(np.isfinite(pred).all() and np.isfinite(truth).all(),'Nonfinite evaluation');m.train(training)
    metrics={name:red.breakdown((pred-truth)[ix],codes[ix],origins[ix]) for name,ix in panels.items()}
    return dict(origins=origins.copy(),prediction=pred,truth=truth,codes=codes),metrics
