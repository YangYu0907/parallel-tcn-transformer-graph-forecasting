import json, hashlib, os, ast, time
from pathlib import Path
from datetime import datetime
import manager as m
P=m.P;Z=m.Z;S=P/'resume'
S.mkdir(exist_ok=True)
def sha(p):return hashlib.sha256(Path(p).read_bytes()).hexdigest()
def read(p):return json.loads(Path(p).read_text(encoding='utf-8-sig'))
def write(n,o):m.write('resume/'+n,o)
parent,original=m.verify()
indices={};original_hashes={};checks=[]
for c in original['choices']:
    file=Z/'cycles'/f'{c["cycle"]}.json';old=read(file)
    assert old['choice']==c
    original_hashes[str(file)]=sha(file)
    for rec in old['receipts']:
        if not rec['key'].endswith('.idx'):continue
        file=(Z/rec['local']).resolve()
        assert file.is_relative_to(Z.resolve())
        data=file.read_bytes();meta=rec['source']
        assert hashlib.sha256(data).hexdigest()==rec['sha256']
        assert len(data)==meta['bytes'] and hashlib.md5(data).hexdigest()==meta['etag'].strip('"')
        assert meta['last_modified_seconds']<=c['minimum_qualified_cutoff']
        indices[rec['key']]=dict(path=str(file),sha256=rec['sha256'],source=meta)
assert len(indices)==96
write('INDEX_REPLAY.json',dict(at=m.s.now(),indices=indices,original_cycles=original_hashes,
    reason='Reuse previously admitted byte-identical original indexes to address cross-mirror HTTP412; no weakening of payload identity or source-time checks'))
checks.append('All96 original index SHA256, MD5, size and historical-cutoff checks passed')
prior=read(P/'PROGRESS.json');rows=prior['rows']
assert len(rows)==9
retained=0;released=0
for row in rows:
    file=P/'cycles'/f'{row["cycle"]}.json';actual=read(file);old=read(Z/'cycles'/f'{row["cycle"]}.json')
    assert sha(file)==row['mirror_record_sha256']
    for key in ['center_values','patch_means','geometry']:assert actual[key]==old[key]
    reference={(x['key'],tuple(x.get('range',[]))):x['sha256'] for x in old['receipts']}
    release=read(P/'released'/f'{row["cycle"]}.json')
    assert release['record_sha256']==sha(file)
    releases={str(Path(x['path']).resolve()):x['sha256'] for x in release['verified_files']}
    for receipt in actual['receipts']:
        assert receipt['sha256']==reference[(receipt['key'],tuple(receipt.get('range',[])))]
        if receipt.get('local'):
            assert sha(Z/receipt['local'])==receipt['sha256'];retained+=1
        else:
            path=str((Z/receipt['temporary_source_fragment']).resolve())
            assert releases[path]==receipt['sha256'];released+=1
checks.append('All9 completed mirror records replayed independently against original source values and receipts')
import resume_manager as rm
rm.INDEX.update(indices)
key=next(iter(indices));expected=indices[key]['source']
data,_=rm.validated_index(key,expected)
for change in [dict(bytes=expected['bytes']+1),dict(etag='"'+'0'*32+'"')]:
    try:rm.validated_index(key,dict(expected,**change))
    except AssertionError:pass
    else:raise AssertionError('Index identity rejection broken')
checks.append('Wrong index size and checksum rejected; no network-based index fallback introduced')
ast.parse((P/'resume_manager.py').read_text(encoding='utf-8'))
q=dict(original);q['bindings']=dict(original['bindings'])
q.update(at=m.s.now(),status='registered_cache_repair_before_resume',prior_rows=rows,
    prior_active_seconds=(datetime.fromisoformat(read(P/'FAILURE.json')['at'])-datetime.fromisoformat(read(P/'LAUNCH.json')['at'].replace('Z','+00:00'))).total_seconds(),
    inherited_counters=read(P/'FAILURE.json')['network'],
    repair='Reuse all96 original index receipts; completed9 cycles and valid partial payloads retained',
    stop='All32 exact checks and unchanged cost gate required; stop early if elapsed alone makes gate mathematically impossible',
    manual_engineering_pause_in_throughput=False,original_wallclock_deadlines_unchanged=True)
assert time.time()<q['deadline_unix']
launcher=(P/'launch.ps1').read_text(encoding='utf-8-sig')
launcher=launcher.replace("$statePath=Join-Path $trial 'STATUS.json'","$stateRoot=Join-Path $trial 'resume'\n$statePath=Join-Path $stateRoot 'STATUS.json'")
launcher=launcher.replace("'manager.py'","'resume_manager.py'").replace("import manager as m","import resume_manager as m")
for name in ['START_READY.json','START_READY.tmp','LAUNCH.json','stdout.log','stderr.log','exit.stdout.log','exit.stderr.log']:
    launcher=launcher.replace("Join-Path $trial '"+name+"'","Join-Path $stateRoot '"+name+"'")
(P/'launch_resume.ps1').write_text(launcher,encoding='utf-8')
checks.append('Fixed32sample, 4IOthreads, unchanged original deadlines and quotas; prior active transfer time and counters carried forward')
qa=dict(at=m.s.now(),passed=True,checks=checks,verified_indices=96,verified_completed_mirror_cycles=9,
    retained_receipts_verified=retained,released_receipts_verified=released,network_requests=0,model_fits=0,
    scope='Separate hash/value replay plus offline rejection tests, not independent-person review or model-accuracy audit')
write('QA.json',qa)
for file in [P/'resume_manager.py',P/'launch_resume.ps1',S/'QA.json',S/'INDEX_REPLAY.json',P/'FAILURE.json',P/'PROGRESS.json',P/'PROTOCOL.json']:
    q['bindings'][str(file)]=sha(file)
write('PROTOCOL.json',q)
rm.verify()
print(json.dumps(dict(passed=True,verified_indices=96,completed_mirror_cycles=9,prior_active_seconds=q['prior_active_seconds'],
    deadline_remaining_seconds=q['deadline_unix']-time.time(),additional_source_cycles=0,model_fits=0),ensure_ascii=False))

