"""Stdlib-only adversarial checks of the independent additive schedule auditor."""
from copy import deepcopy
from hashlib import sha256
from pathlib import Path
import argparse
import ast
import json
import sys

HERE = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(HERE / 'source'))
import audit_schedule as audit


def invented_plan():
    # Construct directly from the quota definition; do not invoke the scheduler.
    count, stop = 25, 9000
    times = [300 * o for o in range(stop)]
    eligible = list(range(288, stop - 11))
    originals, epochs = [], []
    for epoch in range(1, 7):
        anchors = [360 + (epoch - 1) * 360 + j * 12 for j in range(count)]
        phases = []
        extras = {(epoch - 1) * 3 % 11, ((epoch - 1) * 3 + 1) % 11,
                  ((epoch - 1) * 3 + 2) % 11}
        quotas = {str(p): 2 + int(p - 1 in extras) for p in range(1, 12)}
        for p in range(1, 12):
            phases.extend([p] * quotas[str(p)])
        added = [o + p for o, p in zip(anchors, phases)]
        epochs.append(dict(epoch=epoch, original_anchors=anchors, added_origins=added,
            ADDITIVE=[x for pair in zip(anchors, added) for x in pair],
            REPEAT=[x for o in anchors for x in (o, o)], nonhourly_phase_counts=quotas,
            optimizer_updates=13, augmenting_reroutes=0))
        originals.append(anchors)
    plan = dict(epochs=epochs, original_unique_origins=len({o for a in originals for o in a}),
        additive_unique_origins=len({o for e in epochs for o in e['ADDITIVE']}),
        sample_presentations_each_policy=300, updates_each_policy=78,
        statistically_independent_samples_estimated=False)
    return plan, originals, eligible, times, stop, count


def run():
    checks = []
    fixture = invented_plan()
    result = audit.validate_plan(*fixture)
    assert len(result) == 6 and sum(x['optimizer_updates'] for x in result) == 78
    checks.append('valid six distinct epoch lists with rotating extra quotas accepted')

    def reject(name, mutator):
        changed = list(deepcopy(fixture))
        mutator(changed)
        try:
            audit.validate_plan(*changed)
        except (ValueError, IndexError):
            checks.append(name)
            return
        raise AssertionError('Corruption was accepted: ' + name)

    reject('missing epoch rejected', lambda f: f[0]['epochs'].pop())
    reject('changed original row order rejected', lambda f: f[0]['epochs'][0]['original_anchors'].reverse())
    reject('dropped hourly anchor in even slots rejected', lambda f: f[0]['epochs'][0]['ADDITIVE'].__setitem__(0, 361))
    reject('incorrect REPEAT odd slot rejected', lambda f: f[0]['epochs'][0]['REPEAT'].__setitem__(1, 372))
    reject('addition not admitted rejected', lambda f: f[2].remove(f[0]['epochs'][0]['added_origins'][0]))
    reject('ADDITIVE duplicate rejected', lambda f: f[0]['epochs'][0]['ADDITIVE'].__setitem__(3, f[0]['epochs'][0]['ADDITIVE'][1]))
    reject('reported quota tampering rejected', lambda f: f[0]['epochs'][1]['nonhourly_phase_counts'].__setitem__('1', 999))
    reject('optimizer budget tampering rejected', lambda f: f[0]['epochs'][0].__setitem__('optimizer_updates', 12))
    reject('presentations counted as unique rejected', lambda f: f[0].__setitem__('sample_presentations_each_policy', 150))
    reject('false independent-sample claim rejected', lambda f: f[0].__setitem__('statistically_independent_samples_estimated', True))
    reject('timestamp cadence corruption inside history rejected', lambda f: f[3].__setitem__(350, f[3][350] + 1))
    reject('timestamp clock offset invalidating hourly anchors rejected', lambda f: f.__setitem__(3, [t + 300 for t in f[3]]))
    reject('duplicate eligible membership rejected', lambda f: f[2].append(f[2][0]))
    reject('eligible target crossing TRAIN boundary rejected', lambda f: f[2].append(f[4] - 5))
    reject('boolean origin rejected', lambda f: f[0]['epochs'][0]['added_origins'].__setitem__(0, True))

    def wrong_epoch_rotation(f):
        row = f[0]['epochs'][1]
        phase_list = [p for p in range(1, 12) for _ in range(2 + int(p in (1, 2, 3)))]
        added = [o + p for o, p in zip(f[1][1], phase_list)]
        row['added_origins'] = added
        row['ADDITIVE'] = [x for pair in zip(f[1][1], added) for x in pair]
        row['nonhourly_phase_counts'] = {str(p): phase_list.count(p) for p in range(1, 12)}
    reject('nonrotating quota assignment rejected independently of reported counts', wrong_epoch_rotation)

    rule = json.loads((HERE / 'DIAGNOSTIC_PANEL_RULE.json').read_text(encoding='utf-8-sig'))
    panel = audit.diagnostic_reference(fixture[2], fixture[3], rule)
    assert len(panel) == len(set(panel)) == 288
    assert all(sum((fixture[3][o] % 3600) // 300 == p for o in panel) == 24 for p in range(12))
    assert panel == audit.diagnostic_reference(list(reversed(fixture[2])), fixture[3], rule)
    checks.append('fixed diagnostic panel has 24 per clock phase and is independent of input order')
    bad_rule = dict(rule, salt='unregistered')
    try:
        audit.diagnostic_reference(fixture[2], fixture[3], bad_rule)
    except ValueError:
        checks.append('changed diagnostic salt rejected')
    else:
        raise AssertionError('Changed salt accepted')

    parent = dict(status='old', training_allowed=False, cutoff='timestamps_ns[o-1]',
                  Q3_target_values_read=False, artifacts={
                      'features.npy': {'path': 'parent/features.npy', 'sha256': 'abc'},
                      'epoch1_origins.npy': {'path': 'parent/epoch1.npy', 'sha256': 'old'}})
    extension = dict(policy='ADDITIVE', protocol_sha256='protocol')
    child = deepcopy(parent)
    child.update(status='sampling_extension_pending_independent_origin_audit', sampling_extension=extension)
    child['artifacts']['epoch1_origins.npy'] = {'path': 'new/epoch1.npy', 'sha256': 'new'}
    audit.validate_manifest_copy(parent, child, extension)
    checks.append('only registered sampling artifact changes accepted')
    for field in ('cutoff', 'Q3_target_values_read', 'features'):
        bad = deepcopy(child)
        if field == 'features':
            bad['artifacts']['features.npy']['sha256'] = 'changed'
        elif field == 'cutoff':
            bad[field] = 'timestamps_ns[o]'
        else:
            bad[field] = True
        try:
            audit.validate_manifest_copy(parent, bad, extension)
        except ValueError:
            checks.append('inherited ' + field + ' modification rejected')
        else:
            raise AssertionError('Inherited change accepted: ' + field)

    source = (HERE / 'source/audit_schedule.py').read_text(encoding='utf-8-sig')
    tree = ast.parse(source)
    imported = {node.module for node in ast.walk(tree) if isinstance(node, ast.ImportFrom)}
    assert 'schedule' not in imported
    assert 'build_sampling_plan' not in source and 'build_epoch_plan' not in source
    assert 'torch' not in sys.modules and 'numpy' not in sys.modules
    checks.append('synthetic execution imported neither constructor nor numerical runtime')
    return dict(status='passed_synthetic_only', cases=len(checks), checks=checks,
        audit_source_sha256=sha256((HERE / 'source/audit_schedule.py').read_bytes()).hexdigest(),
        qa_source_sha256=sha256(Path(__file__).read_bytes()).hexdigest(),
        real_arrays_read=False, heldout_targets_read=False, numerical_lock_acquired=False,
        real_schedule_audited=False)


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument('--output')
    args = parser.parse_args()
    result = run()
    if args.output:
        path = Path(args.output).resolve()
        if not path.is_relative_to(HERE):
            raise ValueError('Synthetic output outside isolated extension')
        raw = json.dumps(result, indent=2)
        if path.exists():
            if json.loads(path.read_text(encoding='utf-8-sig')) != result:
                raise RuntimeError('Immutable synthetic output differs')
        else:
            path.write_text(raw, encoding='utf-8')
    print(json.dumps(result))


if __name__ == '__main__':
    main()
