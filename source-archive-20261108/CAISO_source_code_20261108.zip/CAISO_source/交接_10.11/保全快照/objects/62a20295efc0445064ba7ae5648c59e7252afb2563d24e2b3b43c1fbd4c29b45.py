from common import *
import time,traceback,psutil
def main():
 start=time.monotonic();lock=E/'MANAGER.lock'
 with lock.open('x') as f:json.dump(dict(pid=os.getpid(),created=psutil.Process().create_time()),f)
 def status(**kw):write(E/'STATUS.json',dict(at=now(),pid=os.getpid(),**kw))
 def tick(**kw):
  write(E/'PROGRESS.json',dict(at=now(),pid=os.getpid(),elapsed_seconds=time.monotonic()-start,rss_MiB=psutil.Process().memory_info().rss/2**20,resources=guard(),**kw))
 try:
  p=verify();guard(True);status(event='awaiting_exit_monitor_binding')
  while not (E/'START_READY.json').exists():
   if time.monotonic()-start>55:raise TimeoutError('Exit monitor receipt missing')
   time.sleep(.2)
  ready=read(E/'START_READY.json');assert ready['manager_pid']==os.getpid()
  assert abs((ready['manager_start_utc_ticks']-621355968000000000)/1e7-psutil.Process().create_time())<.01
  receipt=read(ready['receipt']);assert receipt['manager_pid']==os.getpid() and receipt['watcher_pid']==ready['exit_monitor_pid'] and psutil.pid_exists(ready['exit_monitor_pid'])
  status(event='step_process_started',stage='training_retention_identification',planned_fits=4)
  with s.base.numeric('Four matched binary fits restore original TRAIN only, CAL/EVAL identical'):
   verify();assert read(E/'SUPPORT.json')['up_passed']
   import runner
   runner.run(p,tick)
   import audit
   audit.run(p,tick)
  verify()
  eid=s.emit('needs_analysis',E/'RESULT.json')
  status(event='finite_mechanism_queue_completed',event_id=eid,whole_research_completed=False,new_model_fits=4)
 except InterruptedError as exc:status(event='user_stop_at_stage_boundary',classification='user_stop',error=str(exc))
 except BaseException as exc:
  write(E/'FAILURE.json',dict(at=now(),error=repr(exc),traceback=traceback.format_exc(),automatic_continuation=True))
  eid=s.emit('blocking_failure',E/'FAILURE.json');status(event='step_stopped_or_failed',event_id=eid,error=repr(exc))
 finally:
  if lock.exists() and read(lock)['pid']==os.getpid():lock.unlink()
if __name__=='__main__':main()

