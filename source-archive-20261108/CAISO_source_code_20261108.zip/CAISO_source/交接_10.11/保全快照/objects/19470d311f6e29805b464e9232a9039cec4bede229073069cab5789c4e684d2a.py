"""One finite feature-admission audit. Real completion/failure events only; no timer."""
import os
from pathlib import Path
import subprocess
import sys
import uuid
HERE=Path(__file__).resolve().parent
sys.path.insert(0,str(HERE.parent/'energy_confirmation_v1_20260926'))
import common as c
Q=HERE/'queue'

def status(event,**kw):
    body=dict(event=event,at=c.now(),pid=os.getpid(),**kw)
    p=Q/'events'/(uuid.uuid4().hex+'.json');c.write(p,body);c.write(Q/'status.json',body);return p

def notify(kind,path):
    key='h1_feature_admission_'+kind+'_'+c.sha(path)
    target=c.BRANCH/'event_driven_automation/inbox'/(key+'.json')
    if not target.exists():c.write(target,dict(schema='caiso_research_event_v1',event_id=key,event=kind,
        evidence_path=str(path),complete_research_experiment=False,
        instruction='Feature-only admission audit. Review per-origin and publication receipts and final release gates; no automatic H1 target access. No scheduled model wakeups.'))
    return key

def main():
    import psutil
    Q.mkdir(parents=True,exist_ok=True)
    owner=dict(pid=os.getpid(),created=psutil.Process().create_time(),token=uuid.uuid4().hex)
    lock=Q/'QUEUE.lock'
    with lock.open('x',encoding='utf-8') as f:
        import json
        json.dump(owner,f);f.flush();os.fsync(f.fileno())
    child=None
    try:
        c.guard(True);c.need(not c.SHARED_LOCK.exists(),'Numeric worker already active')
        c.need(not (HERE/'FEATURE_ADMISSION_RESULT.json').exists(),'Prior result exists; review before rerun')
        for p,d in c.read(HERE/'FEATURE_AUDIT_FREEZE.json')['bindings'].items():c.need(c.sha(p)==d,'Freeze changed: '+p)
        out=Q/('worker_'+owner['token']+'.stdout.log');err=Q/('worker_'+owner['token']+'.stderr.log')
        with out.open('xb') as fo,err.open('xb') as fe:
            child=subprocess.Popen([sys.executable,'-X','utf8',str(HERE/'run.py')],cwd=HERE,
                stdout=fo,stderr=fe,creationflags=getattr(subprocess,'CREATE_NO_WINDOW',0))
            status('step_process_started',child_pid=child.pid,stdout=str(out),stderr=str(err))
            code=child.wait()
        c.need(code==0,'Feature audit exit '+str(code)+': '+str(err))
        result=HERE/'FEATURE_ADMISSION_RESULT.json'
        c.need(c.read(result)['status']=='passed_H1_source_cutoff_and_fixed_features','Feature audit did not pass')
        completion=Q/'completion.json'
        c.write(completion,dict(status='feature_admission_complete_pending_release_review',at=c.now(),exit_code=code,
            result=str(result),result_sha256=c.sha(result),freeze_sha256=c.sha(HERE/'FEATURE_AUDIT_FREEZE.json'),
            H1_scores_computed=False,complete_research_experiment=False))
        eid=notify('major_milestone',completion)
        status('finite_sampling_queue_completed',event_id=eid,completion_sha256=c.sha(completion))
    except Exception as exc:
        paused=False
        try:c.boundary()
        except InterruptedError:paused=True
        paused=paused or any((HERE/n).exists() for n in ('STOP_REQUESTED','STOP_REQUESTED.json'))
        p=status('user_stop' if paused else 'step_stopped_or_failed',reason=repr(exc))
        if not paused:
            eid=notify('blocking_failure',p);status('step_stopped_or_failed',reason=repr(exc),event_id=eid)
        return 3 if paused else 2
    finally:
        if child is not None and child.poll() is None:child.wait()
        c.need(c.read(lock)==owner,'Manager lock owner changed')
        c.write(Q/'lock_releases'/(owner['token']+'.json'),dict(owner=owner,at=c.now()));lock.unlink()
    return 0

if __name__=='__main__':raise SystemExit(main())
