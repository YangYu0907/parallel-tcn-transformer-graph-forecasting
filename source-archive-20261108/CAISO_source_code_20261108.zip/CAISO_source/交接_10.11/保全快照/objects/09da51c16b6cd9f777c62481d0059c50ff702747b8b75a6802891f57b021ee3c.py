"""Read-only audit of newly completed concurrent batches and measured speed."""
from pathlib import Path
import json,hashlib
from datetime import datetime,timezone
W=Path(__file__).resolve().parent;N=W.parent
def read(p):return json.loads(p.read_text(encoding='utf-8-sig'))
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
q=read(W/'PROTOCOL.json');cp=read(W/'CHECKPOINT.json')
before=read(W/'RESUME_MANIFEST.json')['cycle_hashes']
added=[c for c in cp['cycle_hashes'] if str(N/'cycles'/f'{c}.json') not in before]
assert len(set(added))==len(added)
checks=0
for cycle in added:
    p=N/'cycles'/f'{cycle}.json';record=read(p);assert sha(p)==cp['cycle_hashes'][cycle]
    assert record['choice']['cycle']==int(cycle) and record['source_available_by']<=record['choice']['minimum_qualified_cutoff']
    assert len(record['rows'])==24 and len({(r['vi'],r['lead']) for r in record['rows']})==24
    for receipt in record['receipts']:
        assert receipt['source']['last_modified_seconds']<=record['choice']['minimum_qualified_cutoff']
        if receipt.get('temporary_source_fragment'):
            original=N/receipt['temporary_source_fragment'];release=read(original.parent.parent.parent/'released_payloads'/p.name)
            assert release['cycle_sha256']==cp['cycle_hashes'][cycle]
            assert any(r['sha256']==receipt['sha256'] and r['bytes']==receipt['bytes'] for r in release['files'])
        elif receipt.get('local'):assert sha(N/receipt['local'])==receipt['sha256']
        checks+=1
progress=read(W/'PROGRESS.json');decision=read(W/'FLOW_DECISION.json') if (W/'FLOW_DECISION.json').exists() else None
result=dict(at=datetime.now(timezone.utc).isoformat(),passed=True,new_unique_cycles=len(added),
 receipt_checks=checks,completed_cycles=progress['completed_cycles'],progress=progress,flow_decision=decision,
 final_speedup_not_guaranteed=True,source_identity_checks_unchanged=True,model_fits=0,
 audit_scope='Separate saved checkpoint/time/receipt inspection by same agent; not forecast accuracy or independent-person review')
(W/'CONCURRENCY_REVIEW.json').write_text(json.dumps(result,ensure_ascii=False,indent=2),encoding='utf-8')
print(json.dumps(result,ensure_ascii=False))

