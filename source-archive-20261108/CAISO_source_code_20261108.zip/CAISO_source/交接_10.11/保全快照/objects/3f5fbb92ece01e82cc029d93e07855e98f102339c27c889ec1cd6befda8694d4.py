"""Separate metric recomputation and source-binding audit; not a second human review."""
from pathlib import Path
import sys,json,math
G=Path(__file__).resolve().parent;R=G.parents[1];B=R.parent;A=B.parents[2];T=A/'运行依赖/CAISO_temporary_storage'
sys.path.insert(0,str(R))
import common as c
def main():
 checks=[]
 def chk(v,n):
  if not v:raise AssertionError(n)
  checks.append(n)
 with c.numeric('Independent G0 saved-prediction metric recomputation'):
  import numpy as np
  r=c.read(G/'G0_RESULT.json');folds=c.read(B/'adaptive_experts_v4_20260929/FOLDS.json')
  for p,h in r['bindings'].items():chk(c.sha(p)==h,'hash:'+p)
  byfold={}
  for seed in c.SEEDS:
   with np.load(T/f'spike_specialist_v7_20260930/audited/{seed}.npz') as z:y=z['truth'].astype('float64');old=z['CONTEXT'].astype('float64');origins=z['origins']
   with np.load(G/f'counterfactual/{seed}.npz') as z:
    pred=z['prediction'].astype('float64');chk(np.array_equal(origins,z['origins']),'origins:'+str(seed))
   offset=0
   for f in folds:
    n=len(f['evaluation']);sl=slice(offset,offset+n);offset+=n
    row=next(x for x in r['rows'] if x['seed']==seed and x['fold']==f['id'])
    for key,p in [('original',old),('fixed_parent',pred)]:
     d=(p[sl]-y[sl]).ravel()
     # Chunked scalar accumulation separate from production means.
     count=d.size;absum=math.fsum(float(np.sum(np.abs(a))) for a in np.array_split(d,37))
     sqsum=math.fsum(float(np.dot(a,a)) for a in np.array_split(d,37))
     sm=math.fsum(float(np.sum(a)) for a in np.array_split(d,37))
     vals=dict(mae=absum/count,rmse=math.sqrt(sqsum/count),bias=sm/count)
     for k,v in vals.items():chk(abs(v-row[key][k])<1e-9,f'{seed}:fold{f["id"]}:{key}:{k}')
     byfold.setdefault(f['id'],{}).setdefault(key,[]).append(vals)
    if f['id']==1:chk(np.max(np.abs(pred[sl]-old[sl]))<1e-7,'firstfoldidentity:'+str(seed))
   chk(offset==698,'698origins:'+str(seed))
  for row in r['mean_seed_by_fold']:
   for key in ['original','fixed_parent']:
    for k in ['mae','rmse','bias']:
     chk(abs(sum(v[k] for v in byfold[row['fold']][key])/3-row[key][k])<1e-9,f'mean:{row["fold"]}:{key}:{k}')
  chk(c.verify_protected()==18,'protected18')
  c.write(G/'G0_AUDIT.json',dict(at=c.now(),status='passed',checks=len(checks),check_names=checks,
      implementation=str(Path(__file__).resolve()),implementation_sha256=c.sha(__file__),
      result_sha256=c.sha(G/'G0_RESULT.json'),separate_formula_and_saved_prediction_recompute=True,
      independent_human_review=False,new_fits=0,new_test_targets=False,protected_files=18))
 print(json.dumps(dict(status='passed',checks=len(checks))),flush=True)
if __name__=='__main__':main()

