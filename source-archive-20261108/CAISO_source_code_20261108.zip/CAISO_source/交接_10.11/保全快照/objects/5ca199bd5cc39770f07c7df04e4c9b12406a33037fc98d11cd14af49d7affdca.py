from common import *
import gc
np=None
def learner(path,X,y,weights,seed):
    from sklearn.ensemble import HistGradientBoostingClassifier
    identity=dict(protocol=gate.sha(HERE/'PROTOCOL.json'),seed=seed,rows=len(y),columns=X.shape[1])
    if path.exists():
        obj=load(path);assert obj['identity']==identity;model=obj['model']
    else:model=HistGradientBoostingClassifier(max_iter=10,max_leaf_nodes=15,min_samples_leaf=50,learning_rate=.05,l2_regularization=1.,early_stopping=False,warm_start=True,random_state=seed)
    for it in range((getattr(model,'n_iter_',0)//10+1)*10,81,10):
        tick(stage='TRAIN_prequential_fit',case=path.stem,iteration=it,total=80);model.set_params(max_iter=it);model.fit(X,y,sample_weight=weights);dump(path,dict(identity=identity,model=model))
    return model
def model_probability(hazard,postexit,X):
    import mathcore as mc
    h=hazard.predict_proba(X)[:,1].reshape(-1,12);p=postexit.predict_proba(X).reshape(-1,12,3)
    return mc.survival(h,p)
def inference_inputs():
    with np.load(A4/'panel.npz') as z:data={k:z[k] for k in ('origins','observable_regime','raw_last')}
    with np.load(A7/'H1_features.npz') as z:he={k:z[k] for k in z.files}
    m=gate.read(B/'phase_sampling_support_v3_20260923/dataset/ADDITIVE/manifest.json');th=gate.read(gate.resolve(m['artifacts']['state_thresholds.json']['path']))
    ids=np.concatenate([f['evaluation'] for f in gate.read(B/'adaptive_experts_v4_20260929/FOLDS.json')])
    return data,he,th,ids
def apply(seed,model,rawh,data,he,th,ids):
    import mathcore as mc
    q=np.array(th['thresholds']);center=np.array(th['center']);shape=(len(ids),30,12)
    with np.load(A7/'predictions'/f'{seed}.npz') as z:old=z['CONTEXT'];base=z['BASE'];oldp=z['CONTEXT_probabilities'];assert np.array_equal(z['eval_indices'],ids)
    with np.load(A4/'experts'/f'{seed}.npz') as z:full=z['experts'][ids,...,0]
    with np.load(A5/'models'/f'{seed}_distributions.npz') as z:mu=z['mus'][ids];quantiles=z['quantiles'];prior=z['prior']
    cal=mc.calibrate(rawh,he['duration'],he['price'][:,44],model);dense=np.broadcast_to(prior,(len(data['origins']),30,12,3)).copy();dense[he['origin_index'],he['node']]=cal;newp=dense[ids]
    mask=np.broadcast_to((data['observable_regime'][ids]==2)[:,:,None],shape);ratio=np.broadcast_to(q[0][None,:,None]/q[1][None,:,None],shape)[mask]
    scale=np.broadcast_to(q[1][None,:,None],shape)[mask];cent=np.broadcast_to(center[None,:,None],shape)[mask]
    sign=np.broadcast_to(np.sign(data['raw_last'][ids]-center)[:,:,None],shape)[mask];fn=(full[mask]-cent)/scale
    result=dict(origins=data['origins'][ids],eval_indices=ids,FULL=full,V7=old,calibrated_probability=newp,original_probability=oldp,prior=prior)
    for arm in ARMS[1:]:
        prob=oldp if arm=='GUARD_ONLY' else newp;atoms,weights=mc.distribution(mu[mask],quantiles,prob[mask],ratio,sign)
        predicted,alpha,d=mc.forecast(fn,atoms,weights,arm!='CAL_ONLY');out=base.copy();out[mask]=predicted*scale+cent
        af=np.zeros(shape);df=np.zeros(shape);af[mask]=alpha;df[mask]=d*scale
        result.update({arm:out,arm+'_alpha':af,arm+'_direction':df})
    return result
def main():
    global np
    with gate.exclusive('V8 TRAIN chronological calibration and conditional risk control'):
        np,lim=gate.runtime(False);verify();start_budget();import mathcore as mc
        ad=gate.read(HERE/'DATA_ADMISSION.json');assert ad['status']=='passed_before_fit'
        for p,h in gate.read(HERE/'SOURCE_BINDINGS.json')['bindings'].items():assert gate.sha(p)==h,p
        with np.load(A7/'TRAIN_features.npz') as z:tr={k:z[k] for k in z.files}
        risk,event,post=mc.targets(tr['classes']);cal=tr['cal'];ycal=tr['classes'][cal].ravel();fitlogs=[]
        data,he,th,ids=inference_inputs();Xh=mc.expand(he['context'],he['duration']);Xcal=mc.expand(tr['context'][cal],tr['duration'][cal]);folds=gate.read(HERE/'FOLDS.json')
        for seed in SEEDS:
            oo=[];pp=[]
            for f in folds:
                fi=np.array(f['fit_indices']);vi=np.array(f['validation_indices']);outpath=ART/'oof'/f'{seed}_{f["id"]}.npz';receipt=HERE/'receipts'/f'{seed}_oof{f["id"]}.json'
                if receipt.exists():
                    assert gate.sha(outpath)==gate.read(receipt)['sha256']
                    with np.load(outpath) as z:p=z['probability'];assert np.array_equal(z['indices'],vi)
                else:
                    X=mc.expand(tr['context'][fi],tr['duration'][fi]);V=mc.expand(tr['context'][vi],tr['duration'][vi]);models={}
                    for task in ('hazard','postexit'):
                        rm=(risk if task=='hazard' else post)[fi];m=rm.ravel();y=(event if task=='hazard' else tr['classes'])[fi].ravel()[m].astype(int)
                        weights=np.repeat(1/np.maximum(rm.sum(1),1),12)[m]
                        assert np.unique(y).tolist()==([0,1] if task=='hazard' else [0,1,2])
                        models[task]=learner(ART/'models'/f'{seed}_fold{f["id"]}_{task}.pkl',X[m],y,weights,seed)
                    p=model_probability(models['hazard'],models['postexit'],V);save(outpath,indices=vi,probability=p)
                    write(receipt,dict(at=gate.now(),sha256=gate.sha(outpath),fold=f['id'],seed=seed));del X,V,models;gc.collect()
                oo.append(vi);pp.append(p)
            oi=np.concatenate(oo);op=np.concatenate(pp);assert len(np.unique(oi))==len(oi)
            X,scaler=mc.design(op,tr['duration'][oi],tr['price'][oi,44]);y=tr['classes'][oi].ravel();ref=np.zeros((X.shape[1],3));ref[:3]=np.eye(3)
            from scipy.optimize import minimize,minimize_scalar
            opt=minimize(mc.calibration_loss_grad,ref.ravel(),args=(X,y,ref),jac=True,method='L-BFGS-B',options={'maxiter':300,'ftol':1e-12,'gtol':1e-6})
            assert opt.success or np.max(abs(opt.jac))<1e-5, str(opt.message)
            W=opt.x.reshape(ref.shape);hazard=load(A7/'models'/f'{seed}_CONTEXT_hazard.pkl')['model'];postexit=load(A7/'models'/f'{seed}_CONTEXT_postexit.pkl')['model']
            rawcal=model_probability(hazard,postexit,Xcal);rawh=model_probability(hazard,postexit,Xh)
            xc,_=mc.design(rawcal,tr['duration'][cal],tr['price'][cal,44],scaler);qc=mc.softmax(xc@W)
            with np.load(A5/'models'/f'{seed}_distributions.npz') as z:prior=z['prior']
            one=np.eye(3)[ycal]
            def loss(a):
                q=a*qc+(1-a)*prior
                return float(-np.log(np.maximum(q[np.arange(len(ycal)),ycal],1e-12)).mean()+.5*np.square(q-one).sum(1).mean())
            opt2=minimize_scalar(loss,bounds=(0,1),method='bounded');alpha=min([0.,float(opt2.x),1.],key=lambda a:(loss(a),a))
            model=dict(seed=seed,W=W.tolist(),scaler=scaler,shrink=alpha,prior=prior.tolist(),fit_indices_sha256=gate.sha(HERE/'FOLDS.json'),oof_pairs=len(oi),calibration_pairs=int(cal.sum()),calibration_loss=loss(alpha),prior_loss=loss(0.),optimizer_success=bool(opt.success),protocol_sha256=gate.sha(HERE/'PROTOCOL.json'))
            write(HERE/'calibrators'/f'{seed}.json',model);save(ART/'calibration'/f'{seed}.npz',oof_indices=oi,oof_probability=op,raw_calibration_probability=rawcal,raw_h1_probability=rawh)
            result=apply(seed,model,rawh,data,he,th,ids);path=ART/'predictions'/f'{seed}.npz';save(path,**result)
            write(HERE/'receipts'/f'{seed}.json',dict(at=gate.now(),sha256=gate.sha(path),seed=seed));fitlogs.append(dict(seed=seed,shrink=alpha,oof_pairs=len(oi),calibration_loss=loss(alpha),prior_loss=loss(0.)))
            tick(stage='seed_complete',seed=seed);print(json.dumps(fitlogs[-1]),flush=True)
        write(HERE/'FIT_COMPLETE.json',dict(at=gate.now(),status='finite_three_seed_fits_complete',rows=fitlogs,new_test_targets_read=False,artifacts={str(p):gate.sha(p) for p in (ART/'predictions').glob('*.npz')}));tick(stage='fits_complete')
if __name__=='__main__':main()
