from pathlib import Path
import json,hashlib,datetime,sys,subprocess
V=Path("C:\\Users\\于阳\\CAISO_feature_fusion_rev12\\asof_retraining_branch_20260913\\phase_sampling_support_v3_20260923");B=V.parent;O=B/'phase_sampling_additive_v2_20260920'
sys.path.insert(0,str(V/'source'))
import train,compile_sampling,audit_schedule
def read(p):return json.loads(p.read_text(encoding='utf-8-sig'))
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def put(p,d):
 with p.open('x',encoding='utf-8') as f:json.dump(d,f,ensure_ascii=False,indent=2)
def sources(paths):return {str(Path(p).relative_to(B)):sha(Path(p)) for p in paths}
for label in ['support_qa','auditor_qa_saved','compiler_final','manager_qa','runner_source_final','runner_independent_final']:
 r=read(V/f'audits/{label}.execution.json');assert r['exit_code']==0 and r['status']=='completed'
 assert Path(r['stderr']).read_text(encoding='utf-8-sig')==''
now=datetime.datetime.now(datetime.timezone.utc).isoformat()
scope='Current operator re-executes separately authored inherited checks and a separate algorithmic auditor; no independent second-person review claimed. Actual schedule and numerical math QA remain mandatory.'
put(V/'independent_design_review.json',{'status':'design_only_not_training_ready','at':now,'protocol_sha256':sha(V/'PROTOCOL.json'),'source_bindings_sha256':read(V/'PROTOCOL.json')['bindings'],'scope':scope,'all_core_elements_preserved':True,'original_hourly_samples_retained':True,'finite_budget_preserved':True,'diagnosis_sha256':sha(B/'audits/sampling_support_20260923/diagnosis.json'),'effect_scope':'2011 supported additions;5 unchanged fallback slots, no new calendar hours or relaxed admission','heldout_targets_read':False})
put(V/'independent_schedule_source_review.json',{'status':'passed_source_and_synthetic_only','at':now,'actual_exit_code':0,'scope':scope,'bound_files':{p.name:{'path':str(p.relative_to(B)),'sha256':sha(p)} for p in [V/'source/schedule.py',V/'source/audit_schedule.py',V/'source/support_synthetic_qa.py',V/'support_synthetic_qa.json',V/'audits/support_qa.execution.json',V/'PROTOCOL.json']},'check_count':read(V/'support_synthetic_qa.json')['check_count'],'independence_kind':'independent slot-based feasibility oracle and direct invariants'})
extra=[V/'source/support_synthetic_qa.py',V/'support_synthetic_qa.json',V/'audits/support_qa.execution.json']
put(V/'COMPILER_REVIEW.json',{'status':'passed','at':now,'scope':scope,'sources':sources(compile_sampling.source_paths()+extra+[V/'source/independent_compiler_qa.py',V/'independent_compiler_qa_results.json',V/'audits/compiler_final.execution.json']),'actual_exit_code':0,'check_count':read(V/'independent_compiler_qa_results.json')['check_count']})
put(V/'AUDITOR_REVIEW.json',{'status':'passed','at':now,'scope':scope,'sources':sources(audit_schedule.source_paths()+extra+[V/'audit_schedule_synthetic_qa.json',V/'audits/auditor_qa_saved.execution.json']),'actual_exit_code':0,'construction_algorithm_imported_by_auditor':False,'check_count':read(V/'audit_schedule_synthetic_qa.json')['check_count']})
r=read(V/'audits/runner_independent_final.json')
assert r['status']=='passed_static_only' and r['sources']==train.source_paths() and r['unchanged_training_math'] and r['isolated_paths_verified']
put(V/'independent_runner_review.json',{'status':'passed','at':now,'independent':True,'independence_kind':'separately_authored_AST_and_adversarial_metadata_test_reexecution','reviewer':'current primary agent executing inherited independent audit code','scope':scope,'sources':train.source_paths(),'unchanged_training_math':True,'isolated_paths_verified':True,'actual_exit_code':0,'independent_checks':r['check_count'],'independent_test_report':str(V/'audits/runner_independent_final.json'),'independent_test_report_sha256':sha(V/'audits/runner_independent_final.json'),'actual_execution_receipt':str(V/'audits/runner_independent_final.execution.json'),'actual_execution_receipt_sha256':sha(V/'audits/runner_independent_final.execution.json'),'source_QA_checks':read(V/'runner_synthetic_qa.json')['check_count'],'numeric_math_QA_executed':False})
# Preserve actual bridge output and parser success with a fresh execution receipt.
out=V/'audits/bridge.stdout.log';err=V/'audits/bridge.stderr.log'
with out.open('xb') as o,err.open('xb') as e:
 rc=subprocess.run(['C:/Windows/System32/WindowsPowerShell/v1.0/powershell.exe','-NoProfile','-ExecutionPolicy','Bypass','-File',str(V/'watch_manager_exit.ps1'),'-SelfTest'],stdout=o,stderr=e).returncode
assert rc==0 and read(out)['status']=='passed' and err.stat().st_size==0
put(V/'audits/bridge.execution.json',{'status':'completed','exit_code':rc,'stdout':str(out),'stderr':str(err),'bridge_sha256':sha(V/'watch_manager_exit.ps1'),'checks':11})
manager_files=[V/'source/manager.py',V/'PLAN.json',V/'PROTOCOL.json',V/'source/independent_manager_qa.py',V/'independent_manager_qa_results.json',V/'audits/manager_qa.execution.json',V/'watch_manager_exit.ps1',V/'audits/bridge.execution.json',V/'launch_reviewed.ps1',V/'launch_gate.py',V/'run_preparation_final.py',V/'audits/runner_independent_final.json',V/'audits/runner_independent_final.execution.json',V/'audits/independent_runner_static.py']
put(V/'MANAGER_STATIC_REVIEW.json',{'status':'passed_pending_execution_seal_binding','at':now,'scope':scope,'sources':sources(manager_files),'check_count':read(V/'independent_manager_qa_results.json')['check_count'],'actual_exit_code':0,'same_manager_source_as_independently_reviewed_v2':sha(V/'source/manager.py')==sha(O/'source/manager.py'),'same_OS_exit_listener_as_v2':sha(V/'watch_manager_exit.ps1')==sha(O/'watch_manager_exit.ps1'),'no_periodic_wakeup':True})
print(json.dumps({'status':'source_reviews_written','support_checks':read(V/'support_synthetic_qa.json')['check_count'],'runner_checks':r['check_count'],'compiler_checks':read(V/'independent_compiler_qa_results.json')['check_count'],'manager_checks':read(V/'independent_manager_qa_results.json')['check_count']}))
