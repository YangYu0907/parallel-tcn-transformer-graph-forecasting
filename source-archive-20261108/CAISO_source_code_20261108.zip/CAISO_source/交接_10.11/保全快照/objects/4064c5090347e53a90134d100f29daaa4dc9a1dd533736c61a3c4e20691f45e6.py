"""Independently audit completed external TRAIN/June trajectories without Torch.

Read only new TRAIN/June target/scaler/origin artifacts and saved predictions.
Recompute all epoch metrics, exact phase/cosine budgets, patience, selected
checkpoint receipts and frozen-June equality. No fitting or Q3/H1 reader.
"""
from pathlib import Path
import argparse
import json
import math
import os
import sys
for key in ('OMP_NUM_THREADS','MKL_NUM_THREADS','OPENBLAS_NUM_THREADS','NUMEXPR_NUM_THREADS'):os.environ[key]='1'
ROOT=Path(__file__).resolve().parents[1]
sys.path.insert(0,str(ROOT/'source'))
import external_train as r
from external_runtime_review import preparation,verify


def branch_path(value):
    p=Path(value);p=(r.BRANCH/p if not p.is_absolute() else p).resolve()
    verify(p.is_relative_to(r.BRANCH),'dataset path escapes new branch')
    return p


def audit(model,seed):
    preparation();identity=r.admission(model,seed);run=r.run_path(model,seed)
    completion_path=run/'completion.json';completion=r.read(completion_path)
    selection=r.read(run/'selected.json');frozen=r.read(run/'frozen_june/result.json')
    verify(completion['status']=='training_completed_pending_independent_audit' and completion['identity']==identity,
           'completed training identity')
    verify(selection['status']=='selected_on_registered_June284' and selection['identity']==identity and
           selection['completion_sha256']==r.sha(completion_path),'selection identity')
    verify(frozen['status']=='frozen_June_predictions_verified' and frozen['selected_sha256']==r.sha(run/'selected.json') and
           frozen['optimizer_steps']==0,'frozen inference completion')
    for report in (completion,frozen):
        verify(report['Q3_targets_read'] is False and report['test_2026_targets_read'] is False,'forbidden evaluation scope')
    with r.exclusive('independent_external_saved_result_audit_'+model+'_'+str(seed)):
        import numpy as np
        from threadpoolctl import threadpool_limits,threadpool_info
        limiter=threadpool_limits(1)
        verify(all(row['num_threads']<=1 for row in threadpool_info()),'NumPy thread limit')
        manifest_path=branch_path(identity['dataset_manifest']);manifest=r.read(manifest_path)
        verify(r.sha(manifest_path)==identity['dataset_manifest_sha256'] and manifest['prefix_stop']==219168 and
               manifest['Q3_target_values_read'] is False and manifest['test_2026_targets_read'] is False,'bounded TRAIN/June manifest')
        dataset_audit=manifest_path.parent/'audit.json'
        verify(r.sha(dataset_audit)==identity['dataset_audit_sha256'] and r.read(dataset_audit)['status']=='passed','independent new dataset audit')
        def artifact(name):
            row=manifest['artifacts'][name];path=branch_path(row['path'])
            verify(r.sha(path)==row['sha256'],'new dataset artifact changed: '+name)
            return path
        origins=np.load(artifact('registered_june_origins.npy'),allow_pickle=False)
        verify(origins.shape==(284,) and (np.diff(origins)>0).all() and
               (origins>=manifest['train_target_stop_exclusive']).all() and
               (origins+12<=manifest['june_target_stop_exclusive']).all(),'registered June target bounds')
        target=np.load(artifact('target_scaled.npy'),mmap_mode='r',allow_pickle=False)
        try:truth=np.stack([np.asarray(target[o:o+12].T,np.float64) for o in origins])
        finally:target._mmap.close()
        scalers=r.read(artifact('scalers.json'))
        center=np.asarray(scalers['price_center'],np.float64)[0,:,0];scale=np.asarray(scalers['price_scale'],np.float64)[0,:,0]
        truth=truth*scale[None,:,None]+center[None,:,None]
        verify(truth.shape==(284,30,12) and np.isfinite(truth).all(),'reconstructed USD truth')
        phase_counts=[]
        for phase in range(1,7):
            rows=np.load(artifact(f'epoch{phase}_origins.npy'),allow_pickle=False)
            verify(rows.ndim==1 and len(rows)==2016 and (rows+12<=manifest['train_target_stop_exclusive']).all(),'bound TRAIN phase origins')
            phase_counts.append(len(rows))
        records=completion['epochs'];verify(11<=len(records)<=30 and completion['completed_epochs']==len(records),'registered finite stopping range')
        best=None;bad=0;steps=0;checked=[]
        for epoch,row in enumerate(records,1):
            reason=r.stop_reason(run)
            if reason:raise RuntimeError(reason)
            verify(row['epoch']==epoch and row['phase_epoch']==(epoch-1)%6+1,'continuous epoch and cyclic phase')
            count=phase_counts[(epoch-1)%6];steps+=math.ceil(count/4)
            expected_lr=.0001+.5*(.001-.0001)*(1+math.cos(math.pi*(epoch-1)/29))
            verify(row['train_origins']==count and row['optimizer_steps']==steps and math.isclose(row['lr'],expected_lr,rel_tol=0,abs_tol=1e-15),
                   'new phase budget and 30-epoch cosine')
            verify(math.isfinite(row['train_huber_mean']) and row['train_huber_mean']>=0 and
                   math.isfinite(row['gradient_norm_mean']) and row['gradient_norm_mean']>=0,'finite epoch loss and norm')
            path=r.inside(row['prediction']);verify(path.is_relative_to(run/'validation') and r.sha(path)==row['prediction_sha256'],'epoch prediction ownership/hash')
            prediction=np.load(path,allow_pickle=False)
            verify(prediction.dtype==np.float64 and prediction.shape==truth.shape and np.isfinite(prediction).all(),'complete USD predictions')
            error=prediction-truth
            metrics=dict(mae=float(abs(error).mean(dtype=np.float64)),rmse=float(np.sqrt(np.square(error).mean(dtype=np.float64))),
                near_h1_4_mae=float(abs(error[:,:,:4]).mean(dtype=np.float64)),h12_mae=float(abs(error[:,:,11]).mean(dtype=np.float64)))
            differences={key:abs(value-row['june'][key]) for key,value in metrics.items()}
            verify(max(differences.values())<1e-9 and row['june']['origins']==284 and
                   row['june']['forecast_cells']==102240 and row['june']['units']=='USD/MWh','independently recomputed epoch metrics')
            checkpoint=r.inside(row['checkpoint']);verify(checkpoint.is_relative_to(run/'checkpoints'),'checkpoint ownership')
            receipt=r.read(checkpoint.with_suffix('.receipt.json'))
            verify(receipt['status']=='committed' and receipt['identity']==identity and receipt['epoch']==epoch and
                   receipt['phase']=='epoch_complete' and receipt['steps']==steps and r.inside(receipt['path'])==checkpoint and
                   r.sha(checkpoint)==receipt['sha256'],'complete epoch checkpoint receipt')
            improved=best is None or row['june']['mae']<best['june']['mae']-1e-6
            if improved:best=row
            if epoch>6:bad=0 if improved else bad+1
            verify(not(epoch>6 and bad>=5 and epoch<len(records)),'no training beyond patience')
            checked.append(dict(epoch=epoch,phase_epoch=row['phase_epoch'],optimizer_steps=steps,recomputed_june=metrics,
                maximum_metric_difference=max(differences.values()),checkpoint_sha256=receipt['sha256'],prediction_sha256=row['prediction_sha256']))
        early=bool(len(records)>6 and bad>=5);capped=len(records)==30
        verify(early or capped,'completion before registered stopping rule')
        verify(completion['optimizer_steps']==steps<=15120 and completion['maximum_updates']==identity['maximum_updates']==15120,
               'final optimizer budget')
        verify(completion['stop_reason']==('patience5_after6' if early else 'registered_epoch30_cap'),'stopping reason')
        last=[row['june']['mae'] for row in records[-5:]];monotone=all(b<a-1e-6 for a,b in zip(last,last[1:]))
        verify(completion['budget_limited']==bool(capped and (best['epoch']>=28 or monotone)) and
               completion['last5_strict_mae_improvement']==monotone and completion['convergence_proven'] is False,'honest budget-limited flag')
        verify(completion['selected_epoch']==selection['selected_epoch']==best['epoch'] and completion['selected_june']==selection['june']==best['june'],
               'earliest-tie best registered June selection')
        checkpoint=r.inside(best['checkpoint']);digest=r.sha(checkpoint)
        verify(Path(completion['selected_checkpoint']).resolve()==checkpoint==Path(selection['checkpoint']).resolve() and
               completion['selected_checkpoint_sha256']==selection['checkpoint_sha256']==digest,'selected new checkpoint')
        fp=run/'frozen_june/prediction.npy';fo=run/'frozen_june/origins.npy'
        verify(r.sha(fp)==frozen['prediction_sha256'] and r.sha(fo)==frozen['origins_sha256'],'frozen export hashes')
        verify(np.array_equal(np.load(fo,allow_pickle=False),origins) and
               np.array_equal(np.load(fp,allow_pickle=False),np.load(r.inside(best['prediction']),allow_pickle=False)) and
               frozen['metrics']==best['june'],'frozen entire June predictions equal the selected epoch')
        verify('torch' not in sys.modules,'saved-result audit must not import Torch')
        verify(r.admission(model,seed)==identity,'final source and dataset admission still current')
        result=dict(status='passed',model=model,seed=seed,completion_sha256=r.sha(completion_path),selection_sha256=r.sha(run/'selected.json'),
            frozen_june_result_sha256=r.sha(run/'frozen_june/result.json'),dataset_manifest_sha256=r.sha(manifest_path),
            dataset_audit_sha256=r.sha(dataset_audit),selected_epoch=best['epoch'],selected_checkpoint_sha256=digest,
            optimizer_steps=steps,epochs=checked,stop_reason=completion['stop_reason'],budget_limited=completion['budget_limited'],
            all_epoch_metrics_verified=True,selection_verified=True,checkpoint_receipts_verified=True,frozen_predictions_exact=True,
            auditor_source_sha256=r.sha(Path(__file__)),audit_source_lock_sha256=r.sha(ROOT/'audit_source/AUDIT_SOURCE_LOCK.json'),
            scope='external saved TRAIN/June results; original scaled-target USD reconstruction',
            Torch_imported=False,model_executed_by_this_audit=False,training_updates_by_this_audit=0,Q3_targets_read=False,H1_targets_read=False,test_2026_targets_read=False)
        destination=run/'independent_result_audit.json'
        if destination.exists():verify(r.read(destination)==result,'immutable result audit differs')
        else:r.write(destination,result)
        return result


if __name__=='__main__':
    parser=argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--model',choices=('DLinear','iTransformer-X'),required=True)
    parser.add_argument('--seed',type=int,choices=(20260813,20260814),required=True)
    args=parser.parse_args()
    print(json.dumps(audit(args.model,args.seed),ensure_ascii=True))
