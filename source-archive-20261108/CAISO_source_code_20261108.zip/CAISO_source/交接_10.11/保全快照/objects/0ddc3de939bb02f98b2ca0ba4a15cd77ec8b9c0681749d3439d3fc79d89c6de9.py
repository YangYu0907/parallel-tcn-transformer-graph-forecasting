"""Serial inference for four frozen selected ADDITIVE controls and24 fixed TRAIN epoch panels."""
from pathlib import Path
import gc, hashlib, json, sys, uuid
import gate,runner
runner.install()
def fingerprint(model):
    h=hashlib.sha256()
    for k,v in sorted(model.state_dict().items()):
        h.update(k.encode());h.update(v.detach().cpu().contiguous().numpy().tobytes())
    return h.hexdigest()
def main():
    seal=gate.verify_evaluation()
    with gate.exclusive('common_sampling_frozen_inference'):
        np,torch,limiter=gate.runtime(True)
        import reductions as r
        from compiled_data import CompiledData
        from models.factory import build_backbone
        data=CompiledData(seal['dataset_manifest'])
        dense=data.origins['june_dense'];registered=data.origins['june']
        panel_ids,blocks=r.panels(dense,registered)
        gate.need(len(dense)==3397 and len(registered)==284 and len(blocks)==278,'Panel counts changed')
        gate.need((dense>=210528).all() and (dense+12<=219168).all(),'June target bounds')
        gate.need(np.all(np.diff(data.times)==300),'Index phases need uninterrupted five-minute grid')
        diag=np.load(gate.inside(seal['train_diagnostic']),allow_pickle=False)
        gate.need(diag.shape==(288,) and np.all(np.diff(diag)>0) and np.isin(diag,data.origins['train_all']).all(),'Invalid fixed TRAIN panel')
        gate.need((diag>=288).all() and (diag+12<=210528).all(),'TRAIN panel escaped')
        data.origins['diagnostic']=diag
        q=gate.read(data.paths['state_thresholds.json'])
        gate.need(q['quantiles']==[.9,.99] and np.array_equal(q['center'],data.center),'Frozen state definitions mismatch')
        thresholds=np.array(q['thresholds'],np.float64)
        limits=gate.read(data.paths['context_limits.json'])['limits']
        regpos=panel_ids['June284']
        order=np.r_[regpos,np.flatnonzero(~np.isin(np.arange(len(dense)),regpos))]
        references={}
        results=[]
        def infer(model,part,order):
            origins=data.origins[part]
            prediction=np.empty((len(origins),30,12),np.float64)
            truth=np.empty_like(prediction);state=np.empty(prediction.shape,np.uint8)
            frozen=fingerprint(model);rng=torch.get_rng_state().clone()
            with torch.inference_mode():
                for start in range(0,len(order),4):
                    gate.guard()
                    ids=order[start:start+4]
                    x,y=data.batch(part,ids)
                    p=model(torch.from_numpy(x))['prediction'].cpu().numpy().astype(np.float64)
                    p=p*data.scale[None,:,None]+data.center[None,:,None]
                    t=y.astype(np.float64)*data.scale[None,:,None]+data.center[None,:,None]
                    gate.need(np.isfinite(p).all() and np.isfinite(t).all(),'Nonfinite evaluation')
                    prediction[ids]=p;truth[ids]=t
                    state[ids]=r.codes(t,x[:,-1,:,0],data.center,data.scale,thresholds)
            gate.need(fingerprint(model)==frozen and torch.equal(torch.get_rng_state(),rng),'Frozen model or RNG changed in inference')
            return dict(origins=origins.copy(),prediction=prediction,truth=truth,codes=state)
        def load_model(case,checkpoint):
            gate.guard()
            ck=gate.inside(checkpoint)
            gate.need(gate.sha(ck)==seal['bindings'][gate.rel(ck)],'Checkpoint changed')
            saved=torch.load(ck,map_location='cpu',weights_only=False)
            gate.need(saved['identity']==case['identity'] and saved['scope']=='backbone_only','Checkpoint identity mismatch')
            model=build_backbone(case['variant'],case['seed'],limits)
            model.load_state_dict(saved['state_dict'],strict=True)
            model.eval() # Preserve selected-validation parameter flags; no gradient recording below.
            del saved;gc.collect()
            return model
        def load_or_run(case,label,checkpoint,part,order):
            folder=gate.HERE/'cases'/case['id']
            receipt=folder/(label+'.json')
            if receipt.exists():
                rec=gate.read(receipt)
                gate.need(rec['seal_sha256']==gate.sha(gate.EVAL_SEAL) and rec['checkpoint']==checkpoint,'Stale evaluation receipt')
                gate.need(gate.sha(gate.inside(rec['artifact']))==rec['artifact_sha256'],'Existing inference changed')
                with np.load(gate.inside(rec['artifact']),allow_pickle=False) as z:arrays={k:z[k] for k in z.files}
            else:
                model=load_model(case,checkpoint)
                arrays=infer(model,part,order)
                del model;gc.collect()
                artifact=folder/(label+'_'+uuid.uuid4().hex+'.npz')
                gate.atomic(artifact,lambda f:np.savez(f,**arrays))
                rec=dict(status='frozen_inference_completed',at=gate.now(),seal_sha256=gate.sha(gate.EVAL_SEAL),
                    case=case['id'],checkpoint=checkpoint,artifact=gate.rel(artifact),artifact_sha256=gate.sha(artifact),
                    model_weights_changed=False,optimizer_updates=0,heldout_targets_read=False)
                gate.write(receipt,rec)
            if part not in references:
                references[part]=(arrays['origins'].copy(),arrays['truth'].copy(),arrays['codes'].copy())
            for observed,expected in zip((arrays['origins'],arrays['truth'],arrays['codes']),references[part]):
                gate.need(np.array_equal(observed,expected),'Common panel alignment differs')
            return rec,arrays
        for i,case in enumerate(seal['cases']):
            gate.guard()
            gate.write(gate.HERE/'progress.json',dict(at=gate.now(),case=case['id'],case_index=i+1,case_count=len(seal['cases']),stage='dense'),True)
            rec,arrays=load_or_run(case,'dense',case['selected_checkpoint'],'june_dense',order)
            prior=np.load(gate.inside(case['selected_prediction']),allow_pickle=False)
            diff=float(np.max(np.abs(arrays['prediction'][regpos]-prior)))
            gate.need(diff<=1e-9,'Registered prediction reproduction mismatch: '+case['id']+' '+str(diff))
            error=arrays['prediction']-arrays['truth']
            summaries={name:r.breakdown(error[ids],arrays['codes'][ids],dense[ids]) for name,ids in panel_ids.items()}
            for key in ('mae','rmse','near_h1_4_mae','h12_mae'):
                gate.need(abs(summaries['June284'][key]-case['reference_metrics'][key])<=1e-9,'Registered headline changed')
            curve=[]
            for epoch in case['epochs']:
                gate.write(gate.HERE/'progress.json',dict(at=gate.now(),case=case['id'],case_index=i+1,case_count=len(seal['cases']),stage='TRAIN_diagnostic',epoch=epoch['epoch']),True)
                rr,aa=load_or_run(case,'train_epoch'+str(epoch['epoch']),epoch['checkpoint'],'diagnostic',np.arange(len(diag)))
                curve.append(dict(epoch=epoch['epoch'],checkpoint=epoch['checkpoint'],receipt=gate.rel(gate.HERE/'cases'/case['id']/('train_epoch'+str(epoch['epoch'])+'.json')),
                    train=r.breakdown(aa['prediction']-aa['truth'],aa['codes'],diag),original_june=epoch['original_june']))
            results.append(dict(id=case['id'],policy=case['policy'],variant=case['variant'],seed=case['seed'],
                selected_epoch=case['selected_epoch'],registered_max_prediction_difference=diff,panels=summaries,train_curve=curve,dense_receipt=gate.rel(gate.HERE/'cases'/case['id']/'dense.json')))
            print(json.dumps(dict(event='common_case_completed',case=case['id'],dense_mae=summaries['June3397']['mae'])),flush=True)
        gate.verify_evaluation()
        output=dict(status='common_inference_completed_pending_numeric_audit',at=gate.now(),seal_sha256=gate.sha(gate.EVAL_SEAL),
            results=results,panel_sizes={k:len(v) for k,v in panel_ids.items()},complete_blocks=blocks.tolist(),
            node_names=data.manifest['nodes'],units='USD/MWh',model_selection_changed=False,optimizer_updates=0,
            heldout_targets_read=False,complete_research_experiment=False)
        path=gate.HERE/'result.json'
        if path.exists():
            old=gate.read(path);old.pop('at',None);new=dict(output);new.pop('at',None)
            gate.need(old==new,'Immutable final inference differs')
        else:gate.write(path,output)
        print(json.dumps(dict(status=output['status'],result_sha256=gate.sha(path),case_count=len(seal['cases']))),flush=True)
if __name__=='__main__':main()

