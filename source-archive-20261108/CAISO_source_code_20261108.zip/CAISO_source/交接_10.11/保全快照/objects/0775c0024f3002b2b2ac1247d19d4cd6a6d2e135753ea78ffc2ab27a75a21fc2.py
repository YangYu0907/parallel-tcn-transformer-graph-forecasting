"""Seal storage engineering before any real model fit; parent protocol retained."""
from pathlib import Path
import sys,ast,json
W=Path(__file__).resolve().parent;sys.path.insert(0,str(W.parent))
import support as s
assert not (W/'PROTOCOL.json').exists()
for name in ['source_review.py','disk_hgb.py','qa_disk.py','manager.py','fit_compare.py']:
    ast.parse((W/name).read_text(encoding='utf-8'))
launch=(W.parent/'p2_1009/launch.ps1').read_text(encoding='utf-8-sig')
launch=launch.replace("& $py (Join-Path $trial 'preflight.py')",'& $py -c "import sys;sys.path.insert(0,sys.argv[1]);import manager;manager.verify();print(manager.guard(True))" $trial')
(W/'launch.ps1').write_text(launch,encoding='utf-8-sig')
assert s.read(W/'ENGINEERING_QA.json')['passed']
files=[W/name for name in ['source_review.py','disk_hgb.py','qa_disk.py','manager.py','fit_compare.py','launch.ps1','ENGINEERING_QA.json']]
files += [s.N/name for name in ['PROTOCOL.json','SOURCE_COMPLETE.json','USER_TIME_POLICY_20261008.json']]
files += [Path(s.base.__file__)]
q=dict(at=s.now(),status='registered_before_real_fitting',parent_protocol_sha256=s.sha(s.N/'PROTOCOL.json'),scope='Execute original four fixed arms on original complete5286cycle population; engineering-only disk matrices and exact binning',arms=['HISTORY','COARSE','SPATIAL','MECHANISM'],max_model_fits=4,trees_per_model=80,natural_prevalence=True,source_cycles=5286,guard_launch_GiB=5,guard_runtime_GiB=4,disk_reserve_GiB=4,numerical_processes=1,numerical_threads=1,time_budget=None,time_limit_stop_enabled=False,scientific_protocol_unchanged=True,storage_changes=['float32 feature values and original categorical order preserved','column-wise original sklearn thresholds and bins','disk-backed matrices avoid simultaneous full copies','completed arms and tree checkpoints can resume without duplicate fits'],QA='Exact synthetic stock-sklearn thresholds, nodes and probabilities; no new real-data experiment',source_admission='SOURCE_REVIEW.json must pass complete separate replay before start',source_runtime='Complete downloaded source files immutable; no network I/O',V7_replaced=False,new_test_targets_read=False,periodic_model_wakeups=False,bindings={str(x):s.sha(x) for x in files})
(W/'PROTOCOL.json').write_text(json.dumps(q,ensure_ascii=False,indent=2),encoding='utf-8')
print(json.dumps(dict(protocol_sha256=s.sha(W/'PROTOCOL.json'),bindings=len(q['bindings']),model_fits=0)))
