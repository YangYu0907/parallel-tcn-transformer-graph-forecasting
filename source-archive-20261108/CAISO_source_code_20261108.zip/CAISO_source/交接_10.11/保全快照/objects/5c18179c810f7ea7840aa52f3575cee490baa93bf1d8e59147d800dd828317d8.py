"""Bounded deterministic replay; scalar rescore independently from training code."""
import support as s
import time,gc,json
def score(p,y):
 import numpy as np
 d=np.asarray(p,dtype=np.float64)-np.asarray(y,dtype=np.float64)
 return dict(mae=float(np.abs(d).mean()),rmse=float(np.sqrt(np.square(d).mean())),
  near_h1_4_mae=float(np.abs(d[:,:,:4]).mean()),h12_mae=float(np.abs(d[:,:,-1]).mean()))
def main():
 p=s.verify(); s.guard(True); start=time.monotonic()
 with s.base.numeric('output_gate_expert_replay'):
  import numpy as np,torch
  torch.set_num_threads(1);torch.set_num_interop_threads(1);torch.use_deterministic_algorithms(True)
  from compiled_data import CompiledData
  from models.factory import build_backbone
  data=CompiledData(p['dataset_manifest']);limits=s.read(data.paths['context_limits.json'])['limits']
  origins=data.origins['june'];assert len(origins)==284
  ids=np.r_[np.arange(4),np.arange(len(origins)//2,len(origins)//2+4),np.arange(len(origins)-4,len(origins))]
  times=np.load(data.paths['timestamps_ns.npy'],mmap_mode='r',allow_pickle=False)
  trainingrows=np.load(data.paths['training_scaler_rows.npy'],allow_pickle=False)
  labels=np.load(data.paths['training_label_rows.npy'],allow_pickle=False)
  assert int(max(trainingrows.max(),labels.max()))<210528
  chronology=dict(train_target_last=str(np.datetime64(int(times[210527]),'ns')),
    june_first_target=str(np.datetime64(int(times[int(origins[0])]),'ns')),
    june_last_target=str(np.datetime64(int(times[int(origins[-1])+11]),'ns')),
    maximum_scaler_row=int(trainingrows.max()),maximum_fit_label_row=int(labels.max()),
    fixed_weights_chronological_at_value_fit_level=True,
    development_architecture_and_budget_previously_exposed_to_June=True,
    strict_independent_oof_gate_cache_admitted=False,
    reason='Fixed terminal weights avoid validation-based checkpoint choice; retrospective development choices and prefix V7/calibration provenance still require separate checks.')
  records=[]; cache={};truth=registered=None
  for row in p['cases']:
   s.guard();assert time.monotonic()-start<p['numerical_plan']['max_seconds'],'Bounded audit time exceeded'
   obj=torch.load(row['checkpoint'],map_location='cpu',weights_only=False)
   assert obj['progress']['epoch']==12 and obj['progress']['steps']==12096 and obj['progress']['phase']=='epoch_complete'
   assert obj['scheduler']['rule']=='epochs7to12_fixed_terminal_lr'
   model=build_backbone(row['variant'],row['seed'],limits);model.load_state_dict(obj['state_dict'],strict=True);model.eval()
   # Preserve historical requires_grad flags; changing them changes optimized CPU dispatch.
   with np.load(row['evaluation'],allow_pickle=False) as z:
    pred=z['prediction'];y=z['truth'];o=z['origins']
   assert np.array_equal(o,origins) and np.isfinite(pred).all()
   if truth is None:truth=y.copy();registered=o.copy()
   else:assert np.array_equal(truth,y) and np.array_equal(registered,o)
   maximum=0.;target_diff=0.
   with torch.no_grad():
    for st in range(0,len(ids),4):
     s.guard();idx=ids[st:st+4];x,t=data.batch('june',idx)
     out=model(torch.from_numpy(x))['prediction'].numpy().astype(np.float64)*data.scale[None,:,None]+data.center[None,:,None]
     direct=t.astype(np.float64)*data.scale[None,:,None]+data.center[None,:,None]
     maximum=max(maximum,float(np.max(np.abs(out-pred[idx]))));target_diff=max(target_diff,float(np.max(np.abs(direct-y[idx]))))
   assert maximum<=1e-8,(row['seed'],row['variant'],maximum)
   assert target_diff==0
   rec=dict(seed=row['seed'],variant=row['variant'],replay_max_difference=maximum,direct_target_max_difference=target_diff,
    metrics=score(pred,y),checkpoint=row['checkpoint'],checkpoint_sha256=s.sha(row['checkpoint']))
   records.append(rec);cache[(row['seed'],row['variant'])]=pred.copy()
   s.write('PROGRESS.json',dict(at=s.now(),completed=len(records),total=9,latest=rec))
   print(json.dumps(dict(event='replay_passed',seed=row['seed'],variant=row['variant'],max_difference=maximum)),flush=True)
   del obj,model;gc.collect()
  combinations=[]
  for seed in [20260813,20260814,20260815]:
   local=cache[(seed,'SELF')]
   for graph in ['FULL','STATIC']:
    gp=cache[(seed,graph)];mixed=.5*gp+.5*local
    # Hindsight is an upper bound on action selection, NOT a deployable predictor.
    de=np.abs(gp-truth)-np.abs(local-truth)
    combinations.append(dict(seed=seed,graph=graph,fixed_half_metrics=score(mixed,truth),
     graph_better_cell_fraction=float((de<0).mean()),local_better_cell_fraction=float((de>0).mean()),
     hindsight_cell_min_MAE=float(np.minimum(np.abs(gp-truth),np.abs(local-truth)).mean()),
     hindsight_is_noncausal_and_not_candidate=True))
  s.write('REPLAY_RESULT.json',dict(status='passed',at=s.now(),scope='Known June284 cached diagnostic, not June3397 selection or independent confirmation',
   origins=284,nodes=30,horizons=12,seed_count=3,chronology=chronology,models=records,fixed_combinations=combinations,
   numerical_fits=0,heldout_targets_read=False,V7_predictions_changed=False,protected_verified=s.protected(),elapsed_seconds=time.monotonic()-start))
 print('All expert replays and scalar rescoring completed',flush=True)
if __name__=='__main__':
 try:main()
 except Exception as e:
  s.write('REPLAY_FAILURE.json',dict(at=s.now(),error=repr(e),no_auto_restart=True));raise
