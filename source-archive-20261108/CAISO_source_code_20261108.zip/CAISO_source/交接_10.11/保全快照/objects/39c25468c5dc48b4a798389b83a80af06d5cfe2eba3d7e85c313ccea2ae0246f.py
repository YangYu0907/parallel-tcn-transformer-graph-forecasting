"""AFF-inspired joint local/global content correction; historical inputs only.

Dai et al. WACV2021 provide the feature-fusion idea, not electricity-price
evidence. Node pooling, LayerNorm, horizon conditioning and zero initialization
are declared adaptations. Outputs are weighted features before a shared head.
"""
import math
import torch
from torch import nn
from torch.nn import functional as F
from models.clip_model import ClipFusion
from models.model_feature_fusion_rev12 import FeatureFusionModel


class JointContent(nn.Module):
    def __init__(self):
        super().__init__()
        self.local = nn.Sequential(nn.Linear(32, 8), nn.LayerNorm(8), nn.ReLU(), nn.Linear(8, 32))
        self.global_context = nn.Sequential(nn.Linear(32, 8), nn.LayerNorm(8), nn.ReLU(), nn.Linear(8, 32))
        for net in (self.local, self.global_context):
            nn.init.zeros_(net[-1].weight)
            nn.init.zeros_(net[-1].bias)

    def forward(self, u):
        return self.local(u) + self.global_context(u.mean(dim=1, keepdim=True))


class JointFusion(ClipFusion):
    def __init__(self, seed, context_limits):
        super().__init__('FULL', seed, context_limits)
        with torch.random.fork_rng(devices=[]):
            torch.manual_seed(seed + 500000)
            self.joint_content = JointContent()

    def fusion(self, tcn, transformer, context):
        a = self.attention
        query = a.query(context).unsqueeze(2) + a.horizon_embedding
        keys = a.key(torch.stack((tcn, transformer), dim=2))
        logits = torch.einsum('bnhd,bnkd->bnhk', query, keys) / math.sqrt(32)
        logits = logits + a.branch_bias
        base = logits.softmax(dim=-1)
        u = (tcn + transformer).unsqueeze(2) * .5 + a.horizon_embedding
        delta = self.joint_content(u)
        correction = torch.stack((.5 * delta, -.5 * delta), dim=3)
        reference = logits.unsqueeze(-1).expand_as(correction)
        # Algebraically softmax(reference+correction). This form preserves the
        # exact original scalar computation when correction is zero.
        shift = (reference + correction).softmax(dim=3) - reference.softmax(dim=3)
        weights = base.unsqueeze(-1) + shift
        return weights, delta

    def forward(self, x):
        if x.ndim != 4 or x.shape[1:] != (288, 30, 29):
            raise ValueError('Expected registered historical schema')
        encoded, adjacency, context = self.graph(x)
        tcn = self.tcn(encoded)
        batch, _, nodes, hidden = encoded.shape
        low = FeatureFusionModel.low_frequency_history(encoded)
        sequence = low.permute(0, 2, 3, 1).reshape(batch * nodes, hidden, -1)
        tokens = F.avg_pool1d(sequence, 6, 6, ceil_mode=True).transpose(1, 2)
        transformer = self.transformer(tokens).reshape(batch, nodes, hidden)
        weights, delta = self.fusion(tcn, transformer, context)
        fused = weights[..., 0, :] * tcn.unsqueeze(2) + weights[..., 1, :] * transformer.unsqueeze(2)
        observed = self.observed_context(x)
        features = fused + self.price_context(observed).unsqueeze(2)
        return dict(prediction=self.head(features), branch_weights=weights,
                    fusion_correction=delta, fused_features=fused,
                    dynamic_adjacency=adjacency, transformer_features=transformer,
                    observed_context=observed, head_features=features)
