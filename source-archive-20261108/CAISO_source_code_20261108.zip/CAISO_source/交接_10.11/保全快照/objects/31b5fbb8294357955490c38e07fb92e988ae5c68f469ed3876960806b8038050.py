from pathlib import Path
from datetime import datetime,timezone
import json,sys,uuid,shutil,psutil
a=Path(__file__).resolve().parent
b=a.parents[1]
v=b/'phase_sampling_additive_v2_20260920'
sys.path.insert(0,str(b/'source'))
import backbone_train as io,compile_gate
at=datetime.now(timezone.utc).isoformat()
launch=io.read(a/'launch_e5a650278648/launch.json')
ms=io.read(b/'mechanism_controls_20260920/queue/status.json')
ss=io.read(v/'queue/status.json')
ck=io.read(b/'runs/backbone/20260814_GLOBAL/latest.json')
assert ms['pid']==18996 and ms['child_pid']==2960 and '--resume' in ms['command']
assert ss['pid']==17648 and ss['prior_pid']==18996 and ss['event']=='waiting_for_prior_manager_exit'
assert ck['steps']>1008 and io.sha(io.inside(ck['path']))==ck['sha256']
owner=io.read(io.GLOBAL_LOCK); assert owner['pid']==2960
for pid in (18996,2960,17648,8284,2368,18392):assert psutil.pid_exists(pid)
for name,pid in [('mechanism_exit_18996_639255551053289730',8284),('sampling_exit_17648_639255551053705401',2368)]:
 row=io.read(b/'event_driven_automation/process_monitors'/f'{name}.status.json')
 assert row['watcher_pid']==pid and row['status']=='watching_process_exit'
record=dict(status='controlled_resume_verified_progressing',at=at,
 root_cause='Original 4GiB runtime resource guard stopped safely; not a performance conclusion',
 original_event_id=launch['resource_event'],dependent_event_id=launch['dependent_event'],
 incoming_event_id='6b43ee96cc7ad0a4f98b299d80d08b68faa38db71b2907ea0fe74346b3b2126b',
 independent_review_sha256=io.sha(a/'independent_review.json'),
 independent_launcher_review_sha256=io.sha(a/'independent_launcher_review.json'),
 prior_steps=1008,current_checkpoint={k:ck[k] for k in ('path','sha256','steps','epoch','phase','committed_at')},
 actual_postlaunch_verification_tool_chunk='dadeba',
 mechanism_manager_pid=18996,worker_pid=2960,sampling_manager_pid=17648,
 mechanism_bridge_pid=8284,sampling_bridge_pid=2368,shared_listener_pid=18392,
 numerical_lock_owner=owner,resources=compile_gate.resources(),
 launch_guard_GiB=5,runtime_guard_GiB=4,resource_guards_unchanged=True,
 training_sources_unchanged=True,one_controlled_resume_executed=True,
 no_heldout_targets_read=True,new_sampling_numeric_work_started=False,
 dependent_event_handled_together=True,do_not_restart_for_dependent_event=True,
 periodic_model_wakeup=False,complete_research_experiment=False)
io.write(a/'resolution.json',record)
hp=b/'HANDOFF.json'
shutil.copyfile(hp,a/'HANDOFF.before_recovery.json')
h=io.read(hp)
h.update(status='mechanism_resource_stop_recovered_sampling_OS_continuation_rearmed',
 at=at,queue_pid=18996,observed_queue_state=ms,
 latest_resource_recovery='audits/resource_recovery_20260921/resolution.json',
 latest_resource_recovery_events=[launch['resource_event'],launch['dependent_event']],
 complete_research_experiment=False,paper_drafting_paused=True)
h['mechanism_continuation'].update(status='running_after_one_reviewed_resource_resume',
 manager_pid=18996,active_worker_pid=2960,current_step=ms['step'],current_case='20260814_GLOBAL',
 launch_record='audits/resource_recovery_20260921/launch_e5a650278648/launch.json',
 current_checkpoint=record['current_checkpoint'],completed_steps=12)
h['next_isolated_sampling_experiment'].update(status='rearmed_waiting_recovered_predecessor_OS_exit',
 manager_pid=17648,exit_bridge_pid=2368,training_started=False,training_ready=False,
 launch_record='audits/resource_recovery_20260921/launch_e5a650278648/launch.json',
 postlaunch_verified='audits/resource_recovery_20260921/resolution.json',
 handled_dependent_event_id=launch['dependent_event'])
e=h['event_automation']
e.update(exit_bridge_pid=8284,manager_start_utc_ticks=639255551053289730,
 binding='event_driven_automation/process_monitors/mechanism_exit_18996_639255551053289730.status.json',
 additional_exit_bridges=[dict(manager_pid=17648,bridge_pid=2368,
 script='phase_sampling_additive_v2_20260920/watch_manager_exit.ps1',
 status='event_driven_automation/process_monitors/sampling_exit_17648_639255551053705401.status.json')])
h['event_driven_automation'].update(manager_pid=18996,watcher_pid=18392,
 status='watching_recovered_mechanism_and_sampling_continuation',periodic_model_wakeup=False)
h['next_actions']=[s.replace('17012','18996').replace('19844','17648') for s in h['next_actions']]
h['next_actions'].insert(0,'Resource event and dependent sampling-stop event were handled together in resource_recovery_20260921/resolution.json. Do not replay recovery if either old event is delivered again; verify current live PIDs/status and remain quiet unless a new failure occurs.')
io.write(hp,h,replace=True)
print(json.dumps(dict(status=record['status'],checkpoint_steps=ck['steps'],checkpoint_epoch=ck['epoch'],
 resolution=str(a/'resolution.json'),handoff_sha256=io.sha(hp))))
