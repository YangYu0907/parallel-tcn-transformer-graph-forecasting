from common import *
import common

def assemble(origins,dm,events,ts,pub,valid,raw,cache,center,q99,sc,math,labels=False):
 import recurrence
 xx=[];oo=[];nn=[];yy=[]
 for start in range(0,len(origins),256):
  batch=origins[start:start+256];rr=recurrence.features(ts[batch-1],events,ts,pub,valid)
  for j,o in enumerate(batch):
   use=abs(raw[o-1,:,0]-center)<=q99
   short=math.features(raw[o-72:o],cache[o-1],sc);assert short.shape==(30,90)
   xx.append(np.column_stack([short,rr[j]])[use]);oo.extend([int(o)]*int(use.sum()));nn.extend(np.flatnonzero(use))
   if labels:yy.extend((abs(raw[o:o+12,:,0]-center)>q99).any(0)[use])
  progress(stage='onset_features',origins_done=min(start+256,len(origins)),origins_total=len(origins),labels_loaded=labels)
 x=np.concatenate(xx);assert x.shape[1]==103 and np.isfinite(x).all()
 out=dict(X=x,origin=np.array(oo),node=np.array(nn))
 if labels:out['y']=np.array(yy,dtype=np.uint8)
 return out

def probability(model,x,t=1):
 from scipy.special import expit,logit
 p=model.predict_proba(x)[:,1];return expit(logit(np.clip(p,1e-9,1-1e-9))/t)

def scoring(p,y,days,threshold,prior):
 from sklearn.metrics import average_precision_score
 pred=p>threshold;pos=y==1;neg=~pos;tp=int((pred&pos).sum());fp=int((pred&neg).sum());brier=float(((p-y)**2).mean())
 return dict(cells=len(y),positive_cells=int(pos.sum()),positive_dates=len(np.unique(days[pos])),dates=len(np.unique(days)),prevalence=float(y.mean()),
  auprc=float(average_precision_score(y,p)),brier=brier,brier_skill_vs_train_frequency=1-brier/float(((y-prior)**2).mean()),
  nll=float(-(y*np.log(np.clip(p,1e-12,1))+(1-y)*np.log(np.clip(1-p,1e-12,1))).mean()),
  threshold=float(threshold),tp=tp,fp=fp,recall=tp/int(pos.sum()) if pos.sum() else None,fpr=fp/int(neg.sum()),precision=tp/(tp+fp) if tp+fp else None,
  predicted_dates=len(np.unique(days[pred])),detected_dates=len(np.unique(days[pred&pos])),false_positive_dates=len(np.unique(days[pred&neg])))

def main():
 global np
 with gate.exclusive('V15 fixed short-history versus released-recurrence onset diagnostic'):
  np,lim=initialize();p=verify();import recurrence
  tests=recurrence.qa();dm=gate.read(V14/'DATA.json');root=Path(dm['directory']);stop=dm['prefix_stop']
  ts=np.load(dm['timestamps'],mmap_mode='r')[:stop];raw=np.load(dm['raw_prices'],mmap_mode='r')[:stop];cache=np.load(root/'features.npy',mmap_mode='r')
  with np.load(dm['publication_ledger']) as z:pub=z['price_last_publication_seconds'][:stop];valid=z['source_row_valid'][:stop].astype(bool)
  th=gate.read(root/'state_thresholds.json');center=np.array(th['center']);q99=np.array(th['thresholds'])[1];sc=gate.read(root/'scalers.json')
  math=gate.load('onset_short_math',B/'spike_transition_v12_20260930/modelmath.py')
  events=recurrence.catalog(raw[:,:,0],ts,pub,valid,center,q99)
  train=np.load(root/'train.npy');train=train[ts[train]%3600==0];val=np.load(root/'valid_select.npy');ev=np.load(root/'evaluation.npy')
  splits={};datasets={}
  for name,origins in [('train',train),('validation',val)]:
   datasets[name]=assemble(origins,dm,events,ts,pub,valid,raw,cache,center,q99,sc,math,True)
   save(ART/f'onset/{name}.npz',**datasets[name]);y=datasets[name]['y'];days=ts[datasets[name]['origin']-1]//86400
   assert y.sum()>=20 and len(np.unique(days[y==1]))>=3,'Insufficient natural-frequency events'
   # All labels used to fit/calibrate existed before the frozen July boundary.
   ready=pub[datasets[name]['origin'][:,None]+np.arange(12)];assert ready.max()<stamp('2024-07-01')
   splits[name]=dict(origins=len(origins),pairs=len(y),events=int(y.sum()),event_dates=len(np.unique(days[y==1])),max_label_publication=int(ready.max()))
  from sklearn.ensemble import HistGradientBoostingClassifier
  from scipy.optimize import minimize_scalar
  models={};frozen={};prior=float(datasets['train']['y'].mean())
  for name,nf in [('SHORT90',90),('RECURRENCE103',103)]:
   m=HistGradientBoostingClassifier(max_iter=10,learning_rate=.05,max_leaf_nodes=15,min_samples_leaf=50,l2_regularization=1.,early_stopping=False,warm_start=True,random_state=20260813)
   for it in range(10,81,10):
    m.set_params(max_iter=it);m.fit(datasets['train']['X'][:,:nf],datasets['train']['y']);dump(ART/f'onset/{name}.pkl',m);progress(stage='onset_fit',model=name,iterations=it)
   y=datasets['validation']['y'];x=datasets['validation']['X'][:,:nf]
   def nll(t):
    pp=probability(m,x,t);return float(-(y*np.log(np.clip(pp,1e-12,1))+(1-y)*np.log(np.clip(1-pp,1e-12,1))).mean())
   sol=minimize_scalar(nll,bounds=(.5,2),method='bounded');assert sol.success;t=float(sol.x);vp=probability(m,x,t);threshold=float(vp[y==0].max())
   models[name]=(m,nf,t,threshold);frozen[name]=dict(features=nf,temperature=t,threshold=threshold,training_prior=prior,validation=scoring(vp,y,ts[datasets['validation']['origin']-1]//86400,threshold,prior),model=str(ART/f'onset/{name}.pkl'))
  # Seal predictions before loading any evaluation target slices.
  write(HERE/'ONSET_MODEL_FREEZE.json',dict(at=gate.now(),protocol_sha256=gate.sha(HERE/'PROTOCOL.json'),models=frozen,scope=p['scope'],test_targets_read=False,
   bindings={str(f):gate.sha(f) for f in (ART/'onset').glob('*')},splits=splits,qa=tests))
  del datasets
  data=assemble(ev,dm,events,ts,pub,valid,raw,cache,center,q99,sc,math,False);save(ART/'onset/evaluation_inputs.npz',**data)
  probs={}
  for name,(m,nf,t,threshold) in models.items():
   probs[name]=np.concatenate([probability(m,data['X'][i:i+8192,:nf],t) for i in range(0,len(data['X']),8192)])
  save(ART/'onset/evaluation_probabilities.npz',**probs,origin=data['origin'],node=data['node'])
  write(HERE/'ONSET_PREDICTION_FREEZE.json',dict(at=gate.now(),model_freeze_sha256=gate.sha(HERE/'ONSET_MODEL_FREEZE.json'),bindings={str(ART/f'onset/{n}.npz'):gate.sha(ART/f'onset/{n}.npz') for n in ['evaluation_inputs','evaluation_probabilities']},evaluation_targets_read=False))
  y=np.zeros(len(data['origin']),np.uint8)
  for i in range(0,len(y),8192):
   oo=data['origin'][i:i+8192];nn=data['node'][i:i+8192];y[i:i+8192]=(abs(raw[oo[:,None]+np.arange(12),nn[:,None],0]-center[nn,None])>q99[nn,None]).any(1)
  days=ts[data['origin']-1]//86400
  result={name:scoring(pp,y,days,models[name][3],prior) for name,pp in probs.items()}
  bymonth=[]
  for left,right in [('2024-07-01','2024-08-01'),('2024-08-01','2024-09-01'),('2024-09-01','2024-10-01'),('2024-10-01','2024-11-01'),('2024-11-01','2024-12-01'),('2024-12-01','2025-01-01')]:
   use=(ts[data['origin']-1]>=stamp(left))&(ts[data['origin']-1]<stamp(right));bymonth.append(dict(month=left[:7],scores={n:scoring(pp[use],y[use],days[use],models[n][3],prior) for n,pp in probs.items()}))
  r=result['RECURRENCE103'];passed=r['auprc']>result['SHORT90']['auprc'] and r['brier_skill_vs_train_frequency']>0 and r['recall']>0 and r['fpr']<=.001
  save(ART/'onset/evaluation_labels.npz',y=y,days=days)
  write(HERE/'ONSET_RESULT.json',dict(at=gate.now(),status='complete_pending_audit',scores=result,by_month=bymonth,diagnostic_pass=bool(passed),splits=splits,all_point_predictions_unchanged=True,scope=p['scope'],coverage_summary=dict(mean=data['X'][:,-3:].mean(0).tolist(),minimum=data['X'][:,-3:].min(0).tolist()),
    event_definition='Any of12futuresteps exceedsTRAINq99 given currentnode nonextreme; not a per-step price forecast',independent_confirmation=False))
  charge();print(json.dumps(dict(onset_scores=result,diagnostic_pass=bool(passed))))
if __name__=='__main__':main()
