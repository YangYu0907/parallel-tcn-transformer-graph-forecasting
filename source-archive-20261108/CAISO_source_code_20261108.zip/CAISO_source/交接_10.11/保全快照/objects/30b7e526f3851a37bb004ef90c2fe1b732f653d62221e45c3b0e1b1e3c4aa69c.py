"""TRAIN-fitted probability calibration and prediction-only convex risk control."""
import numpy as np
def expand(X,duration):
    return np.column_stack([np.repeat(X,12,axis=0),np.tile((np.arange(12)+1)/12,len(X)),(np.repeat(duration,12)+np.tile(np.arange(12)+1,len(X)))/288]).astype(np.float32)
def targets(classes):
    first=np.where((classes<2).any(1),np.argmax(classes<2,axis=1),12);h=np.arange(12)[None,:]
    return h<=first[:,None],h==first[:,None],h>=first[:,None]
def survival(hazard,post):
    s=np.cumprod(1-hazard,1);p=(1-s[...,None])*post;p[:,:,2]+=s
    return p
def softmax(z):
    z=z-z.max(-1,keepdims=True);p=np.exp(z);return p/p.sum(-1,keepdims=True)
def design(p,duration,drawdown,scaler=None):
    n=len(duration);raw=np.column_stack([np.tile((np.arange(12)+1)/12,n),np.repeat(np.log1p(duration),12),np.repeat(drawdown,12)])
    if scaler is None:scaler=dict(mean=raw.mean(0).tolist(),std=np.maximum(raw.std(0),1e-3).tolist())
    extras=(raw-np.array(scaler['mean']))/np.array(scaler['std'])
    return np.column_stack([np.log(np.maximum(p.reshape(-1,3),1e-9)),extras,np.ones(len(raw))]),scaler
def calibration_loss_grad(flat,X,y,reference):
    W=flat.reshape(X.shape[1],3);q=softmax(X@W);one=np.eye(3)[y];diff=q-one
    loss=float(-np.log(np.maximum(q[np.arange(len(y)),y],1e-300)).mean()+.5*np.square(diff).sum(1).mean()+.005*np.square(W-reference).sum())
    gz=diff+q*(diff-(diff*q).sum(1,keepdims=True));grad=X.T@gz/len(y)+.01*(W-reference)
    return loss,grad.ravel()
def calibrate(p,duration,drawdown,model):
    X,_=design(p,duration,drawdown,model['scaler']);q=softmax(X@np.array(model['W']))
    q=model['shrink']*q+(1-model['shrink'])*np.array(model['prior'])
    return q.reshape(-1,12,3)
def distribution(mu,quantiles,prob,ratio,sign):
    atoms=mu[...,None]+quantiles[None,:,:]
    atoms[:,0]=np.clip(atoms[:,0],-ratio[:,None],ratio[:,None])
    for k in (1,2):
        s=np.where(atoms[:,k]>=0,1.,-1.);s=np.where(abs(atoms[:,k])<1e-12,sign[:,None],s)
        atoms[:,k]=s*np.clip(abs(atoms[:,k]),ratio[:,None] if k==1 else 1.,1. if k==1 else np.inf)
    weights=np.broadcast_to(prob[...,None]/quantiles.shape[1],atoms.shape).reshape(len(mu),-1)
    return atoms.reshape(len(mu),-1),weights
def functionals(atoms,weights):
    mean=(atoms*weights).sum(1);ix=np.argsort(atoms,axis=1);a=np.take_along_axis(atoms,ix,1);w=np.take_along_axis(weights,ix,1)
    median=a[np.arange(len(a)),np.argmax(np.cumsum(w,1)>=.5,1)]
    return mean,median
def direction(full,atoms,weights):
    mean,median=functionals(atoms,weights);u=mean-full;v=median-full
    return np.where(u*v>0,np.sign(u)*np.minimum(abs(u),abs(v)),0.)
def risk_alpha(full,d,atoms,weights):
    """Minimize E[e(a)^2]+E[(e(a)^2-e(0)^2)+], with expected MAE constraint.

    No true target/state is an input. Coefficient1 and alpha<=.75 are fixed.
    This is a decision-theoretic prototype, not a finite-sample guarantee.
    """
    e0=full[:,None]-atoms
    def derivative(a):
        e=e0+a[:,None]*d[:,None];gain=np.square(e)-np.square(e0)
        return (weights*2*d[:,None]*e*(1+(gain>0))).sum(1)
    # The right derivative at zero includes positive-part directional derivatives.
    v=2*d[:,None]*e0;right=(weights*(v+np.maximum(v,0))).sum(1)
    lo=np.zeros(len(full));hi=np.full(len(full),.75)
    for _ in range(36):
        mid=(lo+hi)/2;g=derivative(mid);lo=np.where(g<0,mid,lo);hi=np.where(g>=0,mid,hi)
    alpha=np.where(right<0,(lo+hi)/2,0.)
    base=(weights*abs(e0)).sum(1);lo=np.zeros(len(full));hi=alpha.copy()
    for _ in range(36):
        mid=(lo+hi)/2;mae=(weights*abs(e0+mid[:,None]*d[:,None])).sum(1)
        lo=np.where(mae<=base+1e-12,mid,lo);hi=np.where(mae>base+1e-12,mid,hi)
    return np.where(d!=0,lo,0.)
def forecast(full,atoms,weights,guard):
    d=direction(full,atoms,weights);a=risk_alpha(full,d,atoms,weights) if guard else np.where(d!=0,.75,0.)
    return full+a*d,a,d
