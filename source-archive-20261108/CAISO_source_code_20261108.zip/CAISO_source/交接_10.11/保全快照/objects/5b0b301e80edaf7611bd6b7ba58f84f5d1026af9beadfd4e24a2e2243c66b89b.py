import common as c


def main():
    assert not (c.HERE/'SEAL.json').exists(), 'Already registered'
    c.gate.boundary(); c.protected()
    prior=c.B/'temporal_memory_v26_20261001'
    old=c.read(prior/'PROTOCOL.json'); case=old['cases'][0]
    assert case['seed']==20260813 and c.sha(case['parent'])==case['parent_sha256']
    assert c.read(prior/'AUDIT.json')['status']=='passed'
    assert c.read(prior/'attribution/REVIEW.json')['status']=='passed'
    p=dict(at=c.now(),status='registered_before_fit',id='V27-horizon-conditioned-value',cases=[case],
        authorization='User: 继续, following the V26 report and explicitly proposed next bounded matched experiment.',
        scope='Exploratory TRAIN/June3397 development, one seed. Not independent confirmation or V7 replacement.',
        hypothesis='Explicit lead-time conditioning of the value transform may reduce the nearly collinear corrections seen in V26. V26 correlation and state regressions motivate this test but do not establish a cause.',
        candidate='HORIZON: frozen original FULL plus temporal-memory readout, with horizon-conditioned feature-wise affine modulation of its attended values.',
        control='MEAN: same parameters, initialization, memory, optimizer and samples. Only the added modulation receives the mean frozen horizon embedding instead of the specific embedding. The query, original fusion and head remain horizon-aware in both arms.',
        equations=[
            'f_h = w_T,h * T + w_Z,h * Z; q_h = Wq LN(f_h + e_h)',
            'k_j = Wk (LN(m_j) + pos_j); v_j = Wv LN(m_j); a_hj = softmax(q_h dot k_j / 4); u_h = sum_j a_hj v_j',
            'z_h = LN(f_h + e_h) for HORIZON, LN(f_h + mean_h(e_h)) for MEAN',
            '[gamma_h,beta_h] = Wm z_h + bm; u_mod,h = (1 + tanh(gamma_h)) * u_h + beta_h',
            'f_new,h = f_h + Wo u_mod,h + bo; prediction_h = original_head(f_new,h + original_price_context)'],
        parameters=dict(query=512,key=512,value=512,output=544,modulation=1056,total_per_arm=3136),
        initialization='Same seed+2700000 in both arms; output and modulation weights/biases zero, query/key/value PyTorch defaults. No V26 trained reader weights reused. Parent checkpoint frozen/eval.',
        freeze='All original dynamic GNN, TCN, Transformer, parallel branches, feature fusion attention, price context and prediction head are unchanged. Learned weighted fusion remains; no concatenation substitutes for FULL.',
        dataset_manifest=old['dataset_manifest'],
        training='All17102 unique origins from the six existing TRAIN phase arrays; two complete passes. Both arms share seed+2700000+epoch sample permutations. No June targets in training.',
        validation='June3397 primary; June284 and balanced278 secondary. Epoch0,1,2 selected by primary MAE, earliest within1e-6. All nodes/horizons/states retained.',
        lr=.001,weight_decay=.0001,batch_size=64,epochs=2,loss='normalized Huber delta0.5',grad_clip=1.,
        screen='HORIZON primary MAE at least0.5% lower than PARENT and lower than MEAN by1e-6; RMSE,near/H12 MAE and all nonempty S0-S5 MAE/RMSE no worse than PARENT. Missing state evidence cannot pass. Failure closes this experiment; no local hyperparameter or horizon-cutoff search.',
        inference='Descriptive paired real-calendar7day-block bootstrap2000 and Holm for two MAE comparisons. Prior development selection and few dates prohibit a fresh confirmation claim.',
        maximum_reader_fits=2,maximum_seconds=1800,
        after_pass='Register the remaining two seeds before matched full controls and V7 integration; this pilot never replaces V7 or supplies a paper-wide mechanism claim.',
        cache_reuse='Reuse only frozen original FULL activations from audited V26, with parent/order/source/receipt checks and sampled raw-input replay. No selected V26 weights reused.',
        forbidden=['June-derived horizon6 cutoff','target-derived state as prediction input','tuning on September or Europe2016','new held-out target access','more epochs or hyperparameter search'],
        resources=dict(single_numeric_worker=True,threads=1,launch_GiB=5,runtime_GiB=4,numeric='C temporary authorized',metadata='F project'),
        literature=[
            dict(url='https://arxiv.org/abs/1709.07871',title='FiLM: Visual Reasoning with a General Conditioning Layer',inspected='Author abstract; AAAI2018',supports='Feature-wise affine conditioning. Evidence is visual reasoning, not electricity prices; this bounded variant must establish its own effect.'),
            dict(url='https://arxiv.org/abs/1912.09363',title='Temporal Fusion Transformers for Interpretable Multi-horizon Time Series Forecasting',inspected='Author abstract',supports='Multi-horizon representations, feature selection and gating motivation. This is not a TFT replication.'),
            dict(url='https://jmlr.org/papers/v11/cawley10a.html',supports='Repeated model selection can overfit development evidence; new independent confirmation remains necessary.')],
        new_test_targets_read=False,V7_preserved=True)
    c.write(c.HERE/'PROTOCOL.json',p)
    manifest=c.Path(p['dataset_manifest'])
    paths=list(c.HERE.glob('*.py'))+list(c.HERE.glob('*.ps1'))+[c.HERE/'PROTOCOL.json',manifest,manifest.parent/'audit.json',
        prior/'SEAL.json',prior/'AUDIT.json',prior/'OUTCOME_REVIEW.json',prior/'NEXT_STEP.json',prior/'attribution/RESULT.json',prior/'attribution/REVIEW.json',
        c.OLD/'PROTOCOL.json',c.OLD/'SEAL.json',c.B/'TASK_PARALLEL_DEVELOPMENT_REVISION_20261001.json',
        c.B/'source/compiled_data.py',c.B/'source/compile_math.py',c.B/'matched_panel_v1_20260924/reductions.py',
        c.B/'context_expert_v1_20260929/gate.py',c.B/'source/compile_gate.py',c.Path(case['parent'])]
    paths+=list((c.B/'source/models').glob('*.py'))
    for part in ('fit','june_dense'):
        paths += [c.OLDART/case['id']/'cache'/part/'receipt.json',c.MEMROOT/case['id']/part/'receipt.json']
    c.write(c.HERE/'SEAL.json',dict(at=c.now(),bindings={str(x):c.sha(x) for x in paths}))
    c.write(c.HERE/'status.json',dict(at=c.now(),status='registered',training_started=False))
    print('V27 registered:3136 parameters/arm,one seed,two paired fits,two passes,30-minute cap.')


if __name__=='__main__':main()
