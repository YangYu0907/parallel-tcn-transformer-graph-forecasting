"""Single numerical worker, three finite continuations and separate audit, OS events only."""
import json
import os
import subprocess
import sys
import uuid
import gate as g
from execution import verify_training
Q=g.HERE/'queue'


def emit(event,**kw):
    value=dict(event=event,at=g.now(),pid=os.getpid(),**kw)
    p=Q/'events'/(uuid.uuid4().hex+'.json');g.write(p,value);g.write(Q/'status.json',value);return p


def main():
    verify_training();g.guard(True);g.need(g.read(g.HERE/'QA.json')['status']=='passed','QA missing')
    g.need(not (Q/'completion.json').exists(),'Queue already complete')
    import psutil
    owner=dict(pid=os.getpid(),created=psutil.Process().create_time(),token=uuid.uuid4().hex)
    Q.mkdir(exist_ok=True);lock=Q/'QUEUE.lock'
    with lock.open('x',encoding='utf-8') as f:json.dump(owner,f)
    child=None
    try:
        jobs=[]
        for seed in [20260813,20260814,20260815]:
            for variant in ['PRIOR']:
                jobs.append((f'{seed}_{variant}', ['train.py','--seed',str(seed),'--variant',variant],g.HERE/'runs'/f'{seed}_{variant}'/'completion.json','completed_pending_numeric_audit'))
        jobs.append(('audit',['audit.py'],g.HERE/'RESULT.json','finite_graph_prior_trial_audited'))
        for step,args,marker,status in jobs:
            verify_training();g.boundary();receipt=Q/'steps'/(step+'.json')
            if receipt.exists():
                r=g.read(receipt);g.need(r['exit_code']==0 and r['marker_sha256']==g.sha(marker),'Completed step changed');continue
            g.need(not marker.exists(),'Marker without exit receipt requires review')
            g.guard(True);g.need(not g.LOCK.exists(),'Another numerical process active')
            logs=Q/'logs';logs.mkdir(exist_ok=True)
            out=logs/(step+'_'+owner['token']+'.stdout.log');err=out.with_name(out.name.replace('stdout','stderr'))
            with out.open('xb') as fo,err.open('xb') as fe:
                child=subprocess.Popen([sys.executable,str(g.HERE/args[0]),*args[1:]],cwd=g.HERE,stdout=fo,stderr=fe,creationflags=getattr(subprocess,'CREATE_NO_WINDOW',0))
                emit('step_process_started',step=step,child_pid=child.pid,stdout=str(out),stderr=str(err));code=child.wait()
            g.boundary()
            g.need(code==0,f'{step} exited {code}; inspect {err}')
            g.need(g.read(marker)['status']==status,'Unexpected completion')
            g.write(receipt,dict(at=g.now(),exit_code=code,marker=str(marker),marker_sha256=g.sha(marker),seal_sha256=g.sha(g.SEAL)))
        completion=Q/'completion.json';result=g.read(g.HERE/'RESULT.json')
        g.write(completion,dict(status='finite_graph_prior_trial_complete',at=g.now(),result=str(g.HERE/'RESULT.json'),
            result_sha256=g.sha(g.HERE/'RESULT.json'),audit_sha256=g.sha(g.HERE/'AUDIT.json'),
            new_test_targets_read=False,complete_research_experiment=False))
        kind='audited_result_ready' if result['exploratory_promotion_gate_passed'] else 'unexpected_result'
        eid=g.notify(kind,completion);emit('finite_sampling_queue_completed',event_id=eid,completion_sha256=g.sha(completion))
        return 0
    except Exception as exc:
        paused=isinstance(exc,InterruptedError)
        path=emit('user_stop' if paused else 'step_stopped_or_failed',reason=repr(exc),child_pid=child.pid if child else None)
        if not paused:
            eid=g.notify('blocking_failure',path);emit('step_stopped_or_failed',event_id=eid,reason=repr(exc),evidence_path=str(path))
        return 3 if paused else 2
    finally:
        if child and child.poll() is None:child.wait()
        g.need(g.read(lock)==owner,'Queue ownership mismatch');lock.unlink()


if __name__=='__main__':raise SystemExit(main())
