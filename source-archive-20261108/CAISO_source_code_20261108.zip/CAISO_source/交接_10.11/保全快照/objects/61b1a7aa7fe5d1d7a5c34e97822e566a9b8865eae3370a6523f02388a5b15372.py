"""Finite descriptive outcome audit. No training, inference, or test target access."""
import gate as g

OUT=g.HERE/'outcome_review'
EVENT='c64b2ba3752e877ecc8000097bbfe915ea3288691e56efccc7602290e47a2465'

def main():
    g.verify();g.need(not (OUT/'REVIEW.json').exists(),'Review already complete')
    result=g.read(g.HERE/'RESULT.json');completion=g.read(g.HERE/'queue/completion.json')
    g.need(g.sha(g.HERE/'RESULT.json')==completion['result_sha256'],'Result changed')
    g.need(g.sha(g.HERE/'AUDIT.json')==completion['audit_sha256'],'Audit changed')
    g.write(OUT/'REGISTRATION.json',dict(at=g.now(),event_id=EVENT,source_sha256=g.sha(__file__),
        result_sha256=g.sha(g.HERE/'RESULT.json'),purpose='Describe fixed aligned selections on all development origins',
        groups=['all12horizons','horizons1to4','horizons5to12','hourly_and_offhour','all30nodes','all6states'],
        interpretation='Post-selection descriptive diagnosis, not independent significance or causal attribution',
        training_allowed=False,test_targets_allowed=False))
    with g.exclusive('selection_alignment_outcome_review'):
        np,torch,limiter=g.runtime()
        with np.load(g.HERE/'PANEL.npz',allow_pickle=False) as z:
            truth=z['truth'];scale=z['scale'];center=z['center'];origins=z['origins'];codes=z['codes'];hourly=z['hourly']
        absolute={};squared={};seed_rows=[]
        for c in result['cases']:
            g.guard();row=next(r for r in c['all_epochs'] if r['epoch']==c['aligned_epoch'])
            g.need(g.sha(row['forecast'])==row['forecast_sha256'],'Forecast changed')
            with np.load(row['forecast'],allow_pickle=False) as z:
                pred=z['prediction'] if row['format']=='raw' else z['prediction_scaled'].astype(np.float64)*scale[None,:,None]+center[None,:,None]
            err=pred-truth;ae=np.abs(err)
            g.need(abs(float(ae.mean())-c['aligned_dense']['mae'])<1e-10,'Aligned MAE mismatch')
            key=c['variant'];absolute[key]=absolute.get(key,0)+ae/3;squared[key]=squared.get(key,0)+np.square(err)/3
            seed_rows.append(dict(seed=c['seed'],variant=key,epoch=c['aligned_epoch'],
                near_mae=float(ae[:,:,:4].mean()),far_mae=float(ae[:,:,4:].mean()),by_horizon=ae.mean((0,1)).tolist()))
        change={}
        for model,means in result['means'].items():
            change[model]={scope:{m:100*(means['original_'+scope][m]-means['aligned_'+scope][m])/means['original_'+scope][m] for m in means['original_'+scope]} for scope in ('dense','hourly')}
        contrasts=[]
        for other in ('CONCAT','CHANNEL'):
            a=absolute['FULL'];b=absolute[other];delta=a-b
            all_delta=float(delta.mean());near_delta=float(delta[:,:,:4].mean());far_delta=float(delta[:,:,4:].mean())
            g.need(abs(all_delta-(near_delta/3+far_delta*2/3))<1e-12,'Horizon decomposition mismatch')
            contrasts.append(dict(comparator=other,FULL_minus_comparator_mae=all_delta,
                near=dict(FULL=float(a[:,:,:4].mean()),comparator=float(b[:,:,:4].mean()),delta=near_delta),
                far=dict(FULL=float(a[:,:,4:].mean()),comparator=float(b[:,:,4:].mean()),delta=far_delta),
                net_gap_share_h5to12_percent=(100*far_delta*2/3/all_delta if all_delta else None),
                net_gap_interpretation='Signed aggregate difference; this is not a fraction of all errors or a causal decomposition.',
                by_horizon_delta=delta.mean((0,1)).tolist(),by_node_delta=delta.mean((0,2)).tolist(),
                by_phase=[dict(phase=i,origins=int((origins%12==i).sum()),delta=float(delta[origins%12==i].mean())) for i in range(12)],
                by_state=[dict(state=i,cells=int((codes==i).sum()),delta=float(delta[codes==i].mean())) for i in range(6)]))
        checkpoint_trends=[]
        for c in result['cases']:
            rows=c['all_epochs'];last=[r for r in rows if r['epoch']>=10]
            checkpoint_trends.append(dict(case=c['case'],last3=[dict(epoch=r['epoch'],mae=r['mae']) for r in last],
                minimum_at_budget_end=c['aligned_epoch']==12,
                interpretation='A boundary minimum does not establish undertraining or authorize extending the budget.'))
        g.write(OUT/'REVIEW.json',dict(status='passed_descriptive_outcome_review',at=g.now(),event_id=EVENT,
            original_to_aligned_change_percent=change,comparisons=contrasts,seed_profiles=seed_rows,checkpoint_trends=checkpoint_trends,
            audit_scope='Hash-bound outputs and separately recomputed horizon decomposition by same operator',
            new_test_targets_read=False,optimizer_updates=0,
            conclusions=['Selection-population mismatch explains a small part of the development gap, not its full extent.',
                         'Per-channel replacement still does not improve on aligned scalar FULL.',
                         'Remaining FULL-CONCAT gap requires a separate causal hypothesis; localization alone is not proof of the cause.',
                         'Original hourly-selected tests remain frozen. This all-origin exploratory repair is not a retrospective replacement for their specified task.']))
        print(__import__('json').dumps(dict(status='passed',changes=change,contrasts=[{k:v for k,v in r.items() if k in ('comparator','near','far','net_gap_share_h5to12_percent')} for r in contrasts]),ensure_ascii=False))

if __name__=='__main__':main()
