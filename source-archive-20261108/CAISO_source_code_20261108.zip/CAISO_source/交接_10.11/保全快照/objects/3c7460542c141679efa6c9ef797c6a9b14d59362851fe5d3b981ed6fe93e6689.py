from pathlib import Path
import sys, json, os, hashlib, math
HERE=Path(__file__).resolve().parent; B=HERE.parent
sys.path.insert(0,str(B/'context_expert_v1_20260929'))
import gate
A=Path('C:/Users/于阳/CAISO_temporary_storage')
A4=A/'adaptive_experts_v4_20260929'; A5=A/'adaptive_experts_v5_20260929'
A7=A/'spike_specialist_v7_20260930'; A8=A/'recovery_guard_v8_20260930'
SEEDS=[20260813,20260814,20260815]
np=None

def read_np(path, keys=None):
    with np.load(path,allow_pickle=False) as f:
        return {k:f[k] for k in (f.files if keys is None else keys)}

def mix(atoms,p):
    weights=np.broadcast_to(p[:,:,None]/atoms.shape[-1],atoms.shape).reshape(len(p),-1)
    vals=atoms.reshape(len(p),-1); order=np.argsort(vals,axis=1)
    vs=np.take_along_axis(vals,order,axis=1); ws=np.take_along_axis(weights,order,axis=1)
    return (vals*weights).sum(1),vs[np.arange(len(vals)),np.argmax(ws.cumsum(1)>=.5,axis=1)]

def anchor(full,mean,median):
    u=mean-full;v=median-full
    return full+.75*np.where(u*v>0,np.sign(u)*np.minimum(abs(u),abs(v)),0.)

def scalar_mix(a,p,full):
    pairs=sorted((float(a[k,j]),float(p[k])/a.shape[1]) for k in range(3) for j in range(a.shape[1]))
    mean=math.fsum(v*w for v,w in pairs); cumulative=0.;median=pairs[-1][0]
    for value,weight in pairs:
        cumulative+=weight
        if cumulative>=.5:median=value;break
    if (mean-full)*(median-full)>0:
        closest=mean if abs(mean-full)<=abs(median-full) else median
        return .25*full+.75*closest
    return full

def err(pred,y):
    d=pred-y
    return dict(cells=int(y.size),mae=float(abs(d).mean()),rmse=float(np.sqrt((d*d).mean())),bias=float(d.mean()),sse=float((d*d).sum()))

def metrics(pred,y,states):
    return dict(overall=err(pred,y),near=err(pred[:,:,:3],y[:,:,:3]),H12=err(pred[:,:,-1],y[:,:,-1]),
                states={str(s):err(pred[states==s],y[states==s]) for s in range(6)})

def prob_metrics(p,c):
    from sklearn.metrics import roc_auc_score, average_precision_score
    p=p.reshape(-1,3);c=c.ravel();one=np.eye(3)[c]
    result=dict(cells=len(c),fractions=np.bincount(c,minlength=3).__truediv__(len(c)).tolist(),
                mean_probability=p.mean(0).tolist(),brier=float(((p-one)**2).sum(1).mean()),
                nll=float(-np.log(np.maximum(p[np.arange(len(c)),c],1e-12)).mean()),classes={})
    for k in range(3):
        y=c==k;bins=[]
        for lo in np.arange(0.,1.,.1):
            sel=(p[:,k]>=lo)&(p[:,k]<(lo+.1) if lo<.85 else p[:,k]<=1)
            if sel.any():bins.append(dict(lower=float(lo),cells=int(sel.sum()),forecast=float(p[sel,k].mean()),observed=float(y[sel].mean())))
        result['classes'][str(k)]=dict(auc=float(roc_auc_score(y,p[:,k])) if len(np.unique(y))==2 else None,
            average_precision=float(average_precision_score(y,p[:,k])) if y.any() else None,calibration_bins=bins)
    return result

def main():
    global np
    with gate.exclusive('Frozen spike component attribution; zero training; no new test targets'):
        np,lim=gate.runtime(False)
        paths=[HERE/'PROTOCOL.json',HERE/'diagnose.py',B/'spike_specialist_v7_20260930/DATA_ADMISSION.json',
               B/'spike_specialist_v7_20260930/AUDIT.json',B/'episode_spike_v9_20260930/AUDIT.json',
               B/'recovery_guard_v8_20260930/FOLDS.json',A4/'panel.npz',A7/'TRAIN_features.npz',A7/'H1_features.npz']
        for seed in SEEDS:
            paths += [A7/f'predictions/{seed}.npz',A5/f'models/{seed}_distributions.npz',A4/f'experts/{seed}.npz']
            paths += [A8/f'oof/{seed}_{f}.npz' for f in (1,2,3)]
        bindings={str(p):gate.sha(p) for p in paths}
        # Existing admission bindings include feature caches. Fail if they changed.
        for p,h in gate.read(B/'spike_specialist_v7_20260930/DATA_ADMISSION.json')['artifacts'].items():
            assert gate.sha(p)==h,p
        for seed in SEEDS:
            assert gate.sha(A7/f'predictions/{seed}.npz')==gate.read(B/f'spike_specialist_v7_20260930/receipts/{seed}.json')['sha256']
        gate.write(HERE/'INPUT_SEAL.json',dict(at=gate.now(),bindings=bindings))
        panel=read_np(A4/'panel.npz');tr=read_np(A7/'TRAIN_features.npz',['classes','fit','cal','origins'])
        manifest=gate.read(B/'phase_sampling_support_v3_20260923/dataset/ADDITIVE/manifest.json')
        threshold_path=gate.resolve(manifest['artifacts']['state_thresholds.json']['path'])
        th=gate.read(threshold_path);q=np.asarray(th['thresholds']);center=np.asarray(th['center'])
        bindings[str(threshold_path)]=gate.sha(threshold_path)
        rows=[];attrib=[];probability=[];local=[];capacity=[];qa=[];mean_delta=None;mean_positive=None
        for seed in SEEDS:
            gate.guard();z=read_np(A7/f'predictions/{seed}.npz',['CONTEXT','CONTEXT_probabilities','CONTEXT_mean','CONTEXT_median','eval_indices'])
            ids=z['eval_indices'];base=z['CONTEXT'];y=panel['truth'][ids];states=panel['states'][ids]
            day=panel['days'][ids];mask=np.broadcast_to((panel['observable_regime'][ids]==2)[:,:,None],y.shape)
            assert np.array_equal(mask,states>=3)
            expert=read_np(A4/f'experts/{seed}.npz',['experts'])['experts'][ids];full=expert[:,:,:,0]
            d=read_np(A5/f'models/{seed}_distributions.npz',['mus','quantiles']);mu=d['mus'][ids][mask]
            quant=d['quantiles'];p=z['CONTEXT_probabilities'][mask];c=(states[mask]-3).astype(int)
            scale=np.broadcast_to(q[1][None,:,None],y.shape)[mask];cent=np.broadcast_to(center[None,:,None],y.shape)[mask]
            ratio=np.broadcast_to((q[0]/q[1])[None,:,None],y.shape)[mask]
            sign=np.broadcast_to(np.sign(panel['raw_last'][ids]-center)[:,:,None],y.shape)[mask]
            atoms=mu[:,:,None]+quant[None,:,:];atoms[:,0]=np.clip(atoms[:,0],-ratio[:,None],ratio[:,None])
            for k in (1,2):
                s=np.where(atoms[:,k]>=0,1.,-1.);s=np.where(abs(atoms[:,k])<1e-12,sign[:,None],s)
                atoms[:,k]=s*np.clip(abs(atoms[:,k]),ratio[:,None] if k==1 else 1.,1. if k==1 else np.inf)
            # Convert atoms once. These values are USD/MWh, matching all reported metrics.
            atoms=atoms*scale[:,None,None]+cent[:,None,None]
            ptrue=np.eye(3)[c];aperfect=atoms.copy();ym=y[mask];fm=full[mask]
            aperfect[np.arange(len(c)),c]=ym[:,None]
            arms={'FULL':full,'V7':base};ma={}
            for name,aa,pp in [('REPLAY',atoms,p),('CLASS_ORACLE',atoms,ptrue),('TRUE_COMPONENT_ORACLE',aperfect,p),('BOTH_ORACLES',aperfect,ptrue)]:
                m,med=mix(aa,pp);forecast=anchor(fm,m,med)
                replay=np.array([scalar_mix(aa[j],pp[j],float(fm[j])) for j in range(len(c))])
                discrepancy=float(abs(replay-forecast).max());assert discrepancy<1e-8,(name,discrepancy)
                ma[name]=(m,med); pred=base.copy();pred[mask]=forecast
                assert np.array_equal(pred[~mask],base[~mask]);arms[name]=pred
                qa.append(dict(seed=seed,intervention=name,cells=len(c),scalar_max_abs_difference=discrepancy))
            replay_difference=float(abs(arms['REPLAY']-base).max());assert replay_difference<1e-8,replay_difference
            assert np.allclose(arms['BOTH_ORACLES'][mask],.25*full[mask]+.75*y[mask],rtol=0,atol=1e-8)
            m,med=ma['REPLAY'];lo=.25*full[mask]+.75*np.minimum.reduce([full[mask],m,med]);hi=.25*full[mask]+.75*np.maximum.reduce([full[mask],m,med])
            hull=base.copy();hull[mask]=np.clip(y[mask],lo,hi);arms['ANCHOR_HULL_ORACLE']=hull
            extlo=.25*full[mask]+.75*expert[mask].min(-1);exthi=.25*full[mask]+.75*expert[mask].max(-1)
            for name,pred in arms.items():
                if name!='REPLAY':rows.append(dict(seed=seed,arm=name,**metrics(pred,y,states)))
            for s in (3,4,5):
                ix=states==s;sl=c==s-3
                losses={a:float(((arms[a][ix]-y[ix])**2).sum()) for a in ('V7','CLASS_ORACLE','TRUE_COMPONENT_ORACLE','BOTH_ORACLES')}
                probgain=.5*(losses['V7']-losses['CLASS_ORACLE']+losses['TRUE_COMPONENT_ORACLE']-losses['BOTH_ORACLES'])
                ampgain=.5*(losses['V7']-losses['TRUE_COMPONENT_ORACLE']+losses['CLASS_ORACLE']-losses['BOTH_ORACLES'])
                assert abs(probgain+ampgain-(losses['V7']-losses['BOTH_ORACLES']))<1e-5
                attrib.append(dict(seed=seed,state=s,losses=losses,probability_oracle_sse_contribution=probgain,
                    amplitude_oracle_sse_contribution=ampgain,interaction=losses['V7']-losses['CLASS_ORACLE']-losses['TRUE_COMPONENT_ORACLE']+losses['BOTH_ORACLES'],
                    class_known_conditional_mean=err(ma['CLASS_ORACLE'][0][sl],y[mask][sl]),
                    class_known_conditional_median=err(ma['CLASS_ORACLE'][1][sl],y[mask][sl])))
                capacity.append(dict(seed=seed,state=s,cells=int(sl.sum()),V7_error=err(base[ix],y[ix]),
                    anchor_hull_oracle_error=err(hull[ix],y[ix]),
                    fraction_truth_inside_existing_specialist_range=float(((y[mask][sl]>=lo[sl])&(y[mask][sl]<=hi[sl])).mean()),
                    fraction_truth_inside_existing_five_experts_range=float(((y[mask][sl]>=extlo[sl])&(y[mask][sl]<=exthi[sl])).mean()),
                    mean_true_destination_probability=float(p[sl,s-3].mean()),
                    mean_extreme_destination_probability=float(p[sl,2].mean())))
            diff=(base-y)**2-(full-y)**2;pos=np.maximum(diff,0)
            mean_delta=diff/3 if mean_delta is None else mean_delta+diff/3
            mean_positive=pos/3 if mean_positive is None else mean_positive+pos/3
            for s in range(6):
                sel=states==s
                for h in range(12):
                    ix=sel[:,:,h]
                    if ix.any():local.append(dict(seed=seed,state=s,horizon=h+1,full=err(full[:,:,h][ix],y[:,:,h][ix]),V7=err(base[:,:,h][ix],y[:,:,h][ix])))
            probability.append(dict(seed=seed,scope='inspected_H1_current_extreme',**prob_metrics(p,c)))
            for fold in (1,2,3):
                oof=read_np(A8/f'oof/{seed}_{fold}.npz'); ix=oof['indices'];op=oof['probability']
                probability.append(dict(seed=seed,scope='TRAIN_OOF_fold_'+str(fold),**prob_metrics(op,tr['classes'][ix])))
            print(json.dumps(dict(seed=seed,replayed=True,oracle_diagnosis_complete=True)),flush=True)
        grouped=[]
        for name,coordinate in [('UTC_date',np.broadcast_to(day[:,None,None],y.shape)),('node_index',np.broadcast_to(np.arange(30)[None,:,None],y.shape))]:
            for s in range(6):
                state_mask=states==s;total_positive=float(mean_positive[state_mask].sum())
                for val in np.unique(coordinate[state_mask]):
                    sel=state_mask&(coordinate==val)
                    grouped.append(dict(group=name,value=int(val),state=s,cells=int(sel.sum()),net_delta_sse=float(mean_delta[sel].sum()),
                        positive_added_sse=float(mean_positive[sel].sum()),share_of_state_positive_added_sse=float(mean_positive[sel].sum()/max(total_positive,1e-12))))
        summary=[]
        for arm in sorted(set(r['arm'] for r in rows)):
            rr=[r for r in rows if r['arm']==arm]
            summary.append(dict(arm=arm,overall={k:float(np.mean([r['overall'][k] for r in rr])) for k in ('mae','rmse','bias')},
                states={str(s):{k:float(np.mean([r['states'][str(s)][k] for r in rr])) for k in ('mae','rmse','bias')} for s in range(6)}))
        limitations=['All oracle interventions use known outcomes and are impossible forecasting procedures; no performance claim or promotion is allowed.',
            'H1 is repeatedly inspected development evidence, not a new confirmation test.',
            'Attribution is sensitivity of the frozen implementation, not identifiable causal contributions or proof of a unique root cause.',
            'Dates, nodes and overlapping horizons are dependent; three backbone chains do not create independent meta-training data.',
            'Existing OOF caches are expanding-TRAIN diagnostic artifacts; OOF and H1 probability preprocessing/sample composition differ, so their raw scores are not a calibrated head-to-head performance comparison.',
            'Low separability of current fitted models would not prove an information-theoretic limit.']
        out=dict(at=gate.now(),status='completed_zero_fits',scope=dict(origins=len(ids),dates=len(np.unique(day)),nodes=30,horizons=12,seeds=SEEDS,current_extreme_cells=int(mask.sum())),
                 summary=summary,per_seed=rows,oracle_sensitivity=attrib,capacity=capacity,probability_diagnostics=probability,
                 all_date_node_localizations=grouped,all_state_horizon_localizations=local,limitations=limitations,
                 new_test_targets_read=False,training_updates=0,bindings=bindings)
        gate.write(HERE/'RESULT.json',out)
        gate.write(HERE/'AUDIT.json',dict(at=gate.now(),status='passed_numerical_crosscheck_same_operator',result_sha256=gate.sha(HERE/'RESULT.json'),
            checks=['V7 replay all three seeds','scalar independent implementation for every current-extreme cell and all four interventions',
                    'both-oracle analytical identity','exact unchanged non-extreme slice','all source bindings checked and recorded'],rows=qa,
            external_independent_review=False,new_test_targets_read=False))
        print(json.dumps(dict(summary=summary,top_S3_dates=sorted([r for r in grouped if r['group']=='UTC_date' and r['state']==3],key=lambda r:r['positive_added_sse'],reverse=True)),ensure_ascii=False),flush=True)

if __name__=='__main__':
    try:main()
    except Exception as e:
        gate.write(HERE/'FAILURE.json',dict(at=gate.now(),exception=type(e).__name__,message=str(e),training_started=False))
        raise
