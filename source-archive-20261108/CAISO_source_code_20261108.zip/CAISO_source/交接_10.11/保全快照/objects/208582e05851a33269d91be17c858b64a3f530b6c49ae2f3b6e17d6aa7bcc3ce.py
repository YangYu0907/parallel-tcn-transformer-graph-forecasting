"""Exploratory June-only phase diagnosis of eight frozen primary models; no tuning."""
from pathlib import Path
import hashlib, importlib.util, json, os, sys, uuid
from datetime import datetime, timezone
HERE=Path(__file__).resolve().parent
ROOT=HERE.parent
def sha(p):
    h=hashlib.sha256()
    with p.open("rb") as f:
        for block in iter(lambda:f.read(65536),b""):h.update(block)
    return h.hexdigest()
def read(p):return json.loads(p.read_text(encoding="utf-8-sig"))
def require(v,m):
    if not v:raise RuntimeError(m)
def write_new(p,v):
    with p.open("x",encoding="utf-8") as f:json.dump(v,f,ensure_ascii=False,indent=2,allow_nan=False)
def main():
    protocol=read(HERE/"protocol.json")
    require(protocol["source_sha256"]==sha(Path(__file__)),"Diagnostic source changed")
    require(not (HERE/"result.json").exists(),"Immutable result exists")
    for rel,digest in protocol["bindings"].items():require(sha(ROOT/rel)==digest,"Binding changed: "+rel)
    helper_path=ROOT/"validation_registered_20260919/independent_numeric_audit_20260920_v2.py"
    spec=importlib.util.spec_from_file_location("verified_resource_helper",helper_path)
    helper=importlib.util.module_from_spec(spec);spec.loader.exec_module(helper)
    helper.boundary();helper.resource_guard()
    require(not any((HERE/n).exists() for n in ("STOP_REQUESTED","STOP_REQUESTED.json")),"Diagnostic stopped")
    import psutil
    process=psutil.Process()
    owner=dict(token=uuid.uuid4().hex,pid=os.getpid(),created=process.create_time(),action="June_phase_diagnostic")
    with helper.LOCK.open("x",encoding="utf-8") as f:json.dump(owner,f)
    try:
        for key in helper.THREAD_VARS:os.environ[key]="1"
        process.cpu_affinity([min(process.cpu_affinity())])
        import numpy as np
        def metrics(e):
            require(e.ndim==3 and e.shape[1:]==(30,12) and len(e)>0 and np.isfinite(e).all(),"Error panel invalid")
            return dict(mae=float(np.abs(e).mean()),rmse=float(np.sqrt(np.square(e).mean())),
                        near_h1_4_mae=float(np.abs(e[:,:,:4]).mean()),h12_mae=float(np.abs(e[:,:,11]).mean()),
                        mae_by_horizon=np.abs(e).mean(axis=(0,1)).tolist())
        toy=np.ones((12,30,12),dtype=np.float64)*2
        require(metrics(toy)["mae"]==metrics(toy)["rmse"]==2.0,"Known-answer metric check")
        seal=read(ROOT/"validation_controls_20260920/VALIDATION_LOCK.json")
        result=read(ROOT/"validation_controls_20260920/result.json")
        for rel,digest in seal["sources"].items():require(sha(ROOT/rel)==digest,"Frozen source changed")
        manifest=read(ROOT/seal["dataset_manifest"])
        coverage={}
        extra_bindings={}
        time_row=manifest["artifacts"]["timestamps_seconds.npy"]
        require(sha(ROOT/time_row["path"])==time_row["sha256"],"Timestamp binding changed")
        times=np.load(ROOT/time_row["path"],allow_pickle=False)
        require(times.shape==(219168,),"Timestamp prefix differs")
        extra_bindings[time_row["path"]]=time_row["sha256"]
        origin_names=["registered_train_origins.npy","train_origins.npy","unique_phase_origins.npy"]
        origin_names += [f"epoch{epoch}_origins.npy" for epoch in range(1,7)]
        for name in origin_names:
            item=manifest["artifacts"][name]
            require(sha(ROOT/item["path"])==item["sha256"],"Training origin binding changed")
            values=np.load(ROOT/item["path"],allow_pickle=False)
            require(values.ndim==1 and (values+12<=210528).all(),"Origins outside TRAIN")
            extra_bindings[item["path"]]=item["sha256"]
            coverage[name]=dict(count=len(values),residues={str(p):int((values%12==p).sum()) for p in range(12)},
                target_start_minutes=sorted(set(map(int,(times[values]//60)%60))))
        registered=np.array(result["registered_origins"],dtype=np.int64)
        cases=[x for x in seal["cases"] if x["kind"]=="primary"]
        require(len(cases)==8,"Fixed eight primary cases required")
        refs={x["id"]:x for x in result["results"]}
        master_origins=None;master_truth=None;rows=[]
        for case in cases:
            helper.boundary();helper.resource_guard()
            origins=np.load(ROOT/case["origins"],allow_pickle=False)
            truth=np.load(ROOT/case["truth"],allow_pickle=False)
            prediction=np.load(ROOT/case["prediction"],allow_pickle=False)
            require(len(origins)==3397 and len(set(map(int,origins)))==3397,"Dense origins invalid")
            require(truth.shape==prediction.shape==(3397,30,12),"Dense shape invalid")
            if master_origins is None:master_origins=origins.copy();master_truth=truth.copy()
            require(np.array_equal(origins,master_origins) and np.array_equal(truth,master_truth),"Shared dense panel differs")
            error=prediction-truth
            lookup={int(x):i for i,x in enumerate(origins)}
            indices=[lookup[int(x)] for x in registered]
            reg=metrics(error[indices])
            for key in ("mae","rmse","near_h1_4_mae","h12_mae"):
                require(abs(reg[key]-refs[case["id"]]["metrics"][key])<1e-10,"Registered reproduction mismatch")
            phases=origins%12
            blocks=origins//12
            counts={int(b):set(map(int,phases[blocks==b])) for b in np.unique(blocks)}
            complete=np.array([b for b,v in counts.items() if v==set(range(12))],dtype=np.int64)
            require(len(complete)>0,"No complete blocks")
            complete_mask=np.isin(blocks,complete)
            partitions=[]
            for phase in range(12):
                mask=phases==phase
                balanced=mask&complete_mask
                require(mask.any() and balanced.any(),"Empty phase")
                partitions.append(dict(origin_index_mod12=phase,origins=int(mask.sum()),
                    metrics=metrics(error[mask]),balanced_origins=int(balanced.sum()),
                    complete_block_metrics=metrics(error[balanced])))
            dense=metrics(error)
            recomposed=sum(x["origins"]*x["metrics"]["mae"] for x in partitions)/len(origins)
            require(abs(recomposed-dense["mae"])<1e-10,"Phase recomposition mismatch")
            rows.append(dict(id=case["id"],dense_metrics=dense,registered_metrics=reg,
                             complete_12_origin_blocks=len(complete),phases=partitions))
        for rel,digest in seal["sources"].items():require(sha(ROOT/rel)==digest,"Input changed during diagnostic")
        for rel,digest in extra_bindings.items():require(sha(ROOT/rel)==digest,"Training-origin input changed")
        require("torch" not in sys.modules,"Unexpected Torch import")
        output=dict(status="exploratory_June_phase_diagnosis",at=datetime.now(timezone.utc).isoformat(),
                    protocol_sha256=sha(HERE/"protocol.json"),source_sha256=sha(Path(__file__)),
                    rows=rows,training_origin_coverage=coverage,extra_source_bindings=extra_bindings,phase_target_start_minutes={str(p):sorted(set(map(int,(times[master_origins[master_origins%12==p]]//60)%60))) for p in range(12)},registered_phase_counts={str(p):int((registered%12==p).sum()) for p in range(12)},
                    note="Index phases are descriptive, not asserted clock minutes; complete blocks hold calendar sampling approximately matched. All twelve phases retained.",
                    training_started=False,model_selection_performed=False,Q3_targets_read=False,H1_targets_read=False)
        write_new(HERE/"result.json",output)
        print(json.dumps({"status":output["status"],"models":8,"result_sha256":sha(HERE/"result.json")}))
    finally:
        require(read(helper.LOCK)==owner,"Numerical lock owner changed")
        helper.LOCK.unlink()
if __name__=="__main__":main()