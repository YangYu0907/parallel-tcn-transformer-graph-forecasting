from pathlib import Path
import sys,hashlib
from datetime import datetime,timezone
import numpy as np
import source_support as s
R=s.N.parent;Y=R/'forecast_compact_extraction_20261005';I=R/'forecast_source_inventory_20261005'
P=R/'forecast_value_proof_20261005'
sys.path.insert(0,str(P/'vendor'))
import eccodes as ec
FIELDS=[('TMP','2 m above ground',0,0,103,2),('DPT','2 m above ground',0,6,103,2),
        ('UGRD','10 m above ground',2,2,103,10),('VGRD','10 m above ground',2,3,103,10),
        ('UGRD','80 m above ground',2,2,103,80),('VGRD','80 m above ground',2,3,103,80),
        ('DSWRF','surface',4,7,1,None),('TCDC','entire atmosphere',6,1,10,None)]


def retained_index(key,expected):
    stamp=key.split('/')[0].split('.')[1]+'_'+key.split('/')[2][6:9]
    lead=key.split('wrfsfcf')[1][:2]
    path=Y/'raw'/stamp/('F'+lead+'.idx')
    if path.exists():
        data=path.read_bytes()
        if len(data)==expected['bytes'] and hashlib.md5(data).hexdigest()==expected['etag'].strip('"'):return data,str(path)
    return None,None

def grid_hash(blob):
    assert blob[:4]==b'GRIB' and blob[-4:]==b'7777' and int.from_bytes(blob[8:16],'big')==len(blob)
    pos=16
    while pos<len(blob)-4:
        size=int.from_bytes(blob[pos:pos+4],'big');assert size>=5
        if blob[pos+4]==3:return hashlib.sha256(blob[pos:pos+size]).hexdigest()
        pos+=size
    raise AssertionError('Missing grid section')

def geometry(handle,p):
    out=[]
    for name,lat,lon in p['anchors']:
        near=min(ec.codes_grib_find_nearest(handle,lat,lon%360),key=lambda x:x['distance'])
        index=int(near['index']);x=index%1799;y=index//1799
        patch=[(y+dy)*1799+x+dx for dy in [-1,0,1] for dx in [-1,0,1]]
        assert 0<x<1798 and 0<y<1058 and near['distance']<3
        out.append(dict(name=name,index=index,indices=patch,latitude=near['lat'],longitude=near['lon'],distance_km=near['distance']))
    old=s.read(P/'RESULT.json')['geometry']
    assert [x['index'] for x in out[:3]]==[x['index'] for x in old]
    return out

def decode(download,p,geo=None):
    choice=download['choice'];values=np.zeros((8,len(p['anchors']),3));means=values.copy();rows=[]
    reference=datetime.fromtimestamp(choice['cycle'],timezone.utc)
    assert len(download['messages'])==24
    for item in download['messages']:
        s.guard();vi=item['vi'];lead=item['lead'];field=FIELDS[vi]
        path=Path(item['file'])
        with path.open('rb') as stream:
            stream.seek(item['offset']);blob=stream.read(item['right']-item['left']+1)
        assert len(blob)==item['right']-item['left']+1
        assert grid_hash(blob)==p['grid_sha256']
        h=ec.codes_new_from_message(blob)
        try:
            assert ec.codes_get(h,'dataDate')==int(reference.strftime('%Y%m%d'))
            assert ec.codes_get(h,'dataTime')==reference.hour*100
            assert ec.codes_get(h,'stepType')=='instant' and ec.codes_get(h,'forecastTime')==lead
            assert ec.codes_get(h,'discipline')==0
            assert ec.codes_get(h,'parameterCategory')==field[2]
            number=ec.codes_get(h,'parameterNumber')
            assert number==field[3] or (vi==6 and number==192 and ec.codes_get(h,'centre')=='kwbc')
            assert ec.codes_get_long(h,'typeOfFirstFixedSurface')==field[4]
            if field[5] is not None:assert ec.codes_get(h,'level')==field[5]
            assert ec.codes_get(h,'units')==(['K','K']+['m s**-1']*4+['W m**-2','%'])[vi]
            assert (ec.codes_get(h,'Nx'),ec.codes_get(h,'Ny'))==(1799,1059)
            if geo is None:geo=geometry(h,p)
            patch=np.asarray(ec.codes_get_double_elements(h,'values',[idx for g in geo for idx in g['indices']])).reshape(len(geo),9);vals=patch[:,4].copy()
            assert np.isfinite(patch).all()
            if vi<2:assert np.all((patch>170)&(patch<345))
            elif vi<6:assert np.max(np.abs(patch))<150
            elif vi==6:assert patch.min()>=-1 and patch.max()<2000
            else:assert patch.min()>=-.1 and patch.max()<=100.1
            # A separate indexed-access API replays every retained pilot value.
            if download.get('audit_values'):
                replay=np.array(ec.codes_get_double_elements(h,'values',[g['index'] for g in geo]))
                assert np.array_equal(replay,vals)
            values[vi,:,lead-3]=vals;means[vi,:,lead-3]=patch.mean(1)
            rows.append(dict(vi=vi,lead=lead,key=item['key'],range=[item['left'],item['right']],sha256=hashlib.sha256(blob).hexdigest(),units=ec.codes_get(h,'units')))
        finally:
            ec.codes_release(h)
            del blob
    available=max(x['source']['last_modified_seconds'] for x in download['receipts'])
    record=dict(at=s.now(),choice=choice,center_values=values.tolist(),patch_means=means.tolist(),geometry=geo,rows=rows,receipts=download['receipts'],source_available_by=available,value_replay_passed=bool(download.get('audit_values')),scope='Fixed regional proxies; no turbine-output, nodal net-load, causal or electrical-topology equivalence asserted')
    return record,geo
