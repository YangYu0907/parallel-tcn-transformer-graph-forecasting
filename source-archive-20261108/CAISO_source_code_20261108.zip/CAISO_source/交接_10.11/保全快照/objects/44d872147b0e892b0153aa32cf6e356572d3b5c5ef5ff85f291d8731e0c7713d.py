"""Explicit-seed copy of the original QUERY residual before the single head.

This module performs no data access or training.  Inputs are the selected
FiLM's feature vectors and its TRAIN-fitted mean/std buffers; do not refit
those buffers on the transformed features.  CONTROL continues this same
adapter instead of adding another adapter or another prediction head.
"""
import copy

import torch
from torch import nn


class NodeResidual(nn.Module):
    def __init__(self, mean, std, seed=20260814):
        super().__init__()
        if seed not in (20260813, 20260814, 20260815):
            raise ValueError('Unregistered replication/reference seed')
        self.register_buffer('mean', torch.as_tensor(mean, dtype=torch.float32).clone())
        self.register_buffer('std', torch.as_tensor(std, dtype=torch.float32).clone())
        if self.mean.shape != (32,) or self.std.shape != (32,):
            raise ValueError('Expected selected FiLM normalizer with width 32')
        if not torch.isfinite(self.mean).all() or not torch.isfinite(self.std).all() or (self.std <= 0).any():
            raise ValueError('Invalid selected FiLM normalizer')
        # Preserve original constructor order and RNG scope exactly.
        with torch.random.fork_rng(devices=[]):
            torch.manual_seed(seed + 910000)
            self.query = nn.Linear(32, 16)
            self.age = nn.Linear(2, 16, bias=False)
            self.horizon = nn.Parameter(torch.randn(12, 16) * .02)
            self.var = nn.Parameter(torch.randn(6, 16) * .02)
            self.embed = nn.Linear(25, 16)
            self.key = nn.Linear(16, 16, bias=False)
            self.value = nn.Linear(16, 16, bias=False)
            self.out = nn.Linear(16, 32)
            nn.init.zeros_(self.out.weight)
            nn.init.zeros_(self.out.bias)

    def forward(self, z, mask, age, cov, return_attention=False):
        if z.shape != (len(z), 30, 12, 32) or mask.shape != (len(z), 30):
            raise ValueError('Expected original 30-node, 12-step feature schema')
        if age.shape != (len(z), 30, 2) or cov.shape != (len(z), 12, 6, 25):
            raise ValueError('Expected original age and exogenous feature schema')
        q = self.query((z - self.mean) / self.std) + self.age(age).unsqueeze(2) + self.horizon[None, None]
        token = torch.tanh(self.embed(cov) + self.var[None, None])
        k, v = self.key(token), self.value(token)
        weights = torch.softmax(torch.einsum('bnhd,bhvd->bnhv', q, k) / 4., dim=-1)
        value = torch.einsum('bnhv,bhvd->bnhd', weights, v)
        delta = self.out(q + value)
        changed = z + mask[:, :, None, None].to(z.dtype) * delta
        return (changed, weights) if return_attention else changed


class Readout(nn.Module):
    def __init__(self, head, mean, std, seed=20260814):
        super().__init__()
        self.head = copy.deepcopy(head).eval().requires_grad_(False)
        self.adapter = NodeResidual(mean, std, seed)

    def forward(self, z, mask, age, cov):
        return self.head(self.adapter(z, mask, age, cov))
