"""All-selected-origin exact replay of evaluation flag repair, no optimizer."""
import gc,json
import gate,runner
runner.install()
def main():
    old=gate.verify_parents();reports=[]
    with gate.exclusive('parameter_flag_recovery_all_registered_QA'):
        np,torch,limiter=gate.runtime(True)
        from compiled_data import CompiledData
        from model_adapter import build_model
        from evaluate import fingerprint
        data=CompiledData(old['dataset_manifest'])
        for c in old['cases']:
            gate.guard();ck=gate.inside(c['selected_checkpoint'])
            gate.need(gate.sha(ck)==old['bindings'][gate.rel(ck)],'Selected checkpoint changed')
            saved=torch.load(ck,map_location='cpu',weights_only=False)
            model=build_model(c['variant'],c['seed']);model.load_state_dict(saved['state_dict'],strict=True);model.eval()
            gate.need(all(p.requires_grad for p in model.parameters()),'Original validation parameter flags')
            before=fingerprint(model);rng=torch.get_rng_state().clone()
            prior=np.load(gate.inside(c['selected_prediction']),allow_pickle=False)
            pred=np.empty_like(prior)
            with torch.inference_mode():
                for start in range(0,284,4):
                    gate.guard();x,_=data.batch('june',slice(start,start+4),with_target=False)
                    out=model(torch.from_numpy(x))['prediction'].numpy().astype(np.float64)
                    pred[start:start+4]=out*data.scale[None,:,None]+data.center[None,:,None]
            diff=float(abs(pred-prior).max())
            gate.need(diff==0,'Exact saved-validation replay failed '+c['id'])
            gate.need(fingerprint(model)==before and torch.equal(rng,torch.get_rng_state()),'Model/RNG changed')
            gate.need(all(p.grad is None for p in model.parameters()),'Inference populated gradients')
            x,_=data.batch('june',slice(0,4),with_target=False)
            model.requires_grad_(False)
            with torch.inference_mode():
                old_out=model(torch.from_numpy(x))['prediction'].numpy().astype(np.float64)*data.scale[None,:,None]+data.center[None,:,None]
            old_diff=float(abs(old_out-prior[:4]).max())
            if c['variant']=='DLinear':gate.need(old_diff>1e-9,'Original failure not reproduced')
            reports.append(dict(case=c['id'],origins=284,cells=102240,repaired_max_difference=diff,
                old_flag_first4_max_difference=old_diff,parameters_RNG_gradients_unchanged=True,checkpoint_sha256=gate.sha(ck)))
            del model,saved;gc.collect()
            print(json.dumps(reports[-1]),flush=True)
        gate.verify_parents()
        gate.write(gate.HERE/'recovery_qa.json',dict(status='passed',at=gate.now(),cases=reports,sources=gate.sources(),
            total_exact_replayed_cells=6*102240,requires_grad_fix_only=True,comparison_tolerance_unchanged=True,
            no_backward_or_optimizer=True,heldout_targets_read=False))
if __name__=='__main__':main()
