from support import *
import torch,math
from torch import nn
from torch.nn import functional as F

def cdf_torch(q,z):
    levels=q.new_tensor(Q);ix=((q<=z[:,None]).sum(1)-1).clamp(0,len(Q)-2)
    a=q.gather(1,ix[:,None]).squeeze(1);b=q.gather(1,(ix+1)[:,None]).squeeze(1)
    p=levels[ix]+(levels[ix+1]-levels[ix])*(z-a)/(b-a).clamp_min(1e-10)
    ls=((q[:,1]-q[:,0])/math.log(Q[1]/Q[0])).clamp_min(1e-8)
    rs=((q[:,-1]-q[:,-2])/math.log((1-Q[-2])/(1-Q[-1]))).clamp_min(1e-8)
    p=torch.where(z<q[:,0],Q[0]*torch.exp(((z-q[:,0])/ls).clamp_max(0)),p)
    p=torch.where(z>q[:,-1],1-(1-Q[-1])*torch.exp(((q[:,-1]-z)/rs).clamp_max(0)),p)
    return p.clamp(0,1)

class JointQuantiles(nn.Module):
    def __init__(self,n,gaps,cap):
        super().__init__();self.net=nn.Sequential(nn.Linear(n,32),nn.SiLU(),nn.Linear(32,32),nn.SiLU(),nn.Linear(32,13))
        nn.init.zeros_(self.net[-1].weight);nn.init.zeros_(self.net[-1].bias)
        self.register_buffer('gaps',torch.as_tensor(gaps,dtype=torch.float32));self.register_buffer('cap',torch.as_tensor(cap,dtype=torch.float32))
    def forward(self,x,h,allow,fix=False):
        v=self.net(x);c=self.cap[h]*torch.tanh(v[:,0])*allow
        if fix:c=c*0
        increments=self.gaps[h]*torch.exp(math.log(4.)*torch.tanh(v[:,1:]))
        left=c[:,None]-torch.flip(torch.cumsum(torch.flip(increments[:,:6],dims=[1]),dim=1),dims=[1])
        right=c[:,None]+torch.cumsum(increments[:,6:],dim=1)
        return torch.cat([left,c[:,None],right],dim=1)

def objective(q,y,low,high,arm):
    tau=q.new_tensor(Q);e=y[:,None]-q
    loss=torch.maximum(tau*e,(tau-1)*e).mean()+abs(y-q[:,MID]).mean()
    if arm!='NO_RISK':
        p0=cdf_torch(q,low);p1=1-cdf_torch(q,high)
        loss=loss+((p0-(y<low).to(y.dtype))**2+(p1-(y>high).to(y.dtype))**2).mean()
    return loss
