import json
from pathlib import Path
import struct
import unittest
from source_math import *

class SourceBoundaryTests(unittest.TestCase):
    def row(self, **kw):
        x=dict(INTERVALSTARTTIME_GMT='2026-01-01T00:00:00Z',NODE_ID='n',XML_DATA_ITEM='LMP_PRC',MW='12.25');x.update(kw);return x
    def test_disallowed_future_never_converts_invalid_price(self):
        self.assertIsNone(permitted_value(self.row(MW='must-not-decode'),'price','n',{0}))
    def test_exact_cutoff_excludes_first_target(self):
        i=index('2026-01-01T00:00:00Z')
        self.assertIsNone(permitted_value(self.row(),'price','n',set(range(i-288,i))))
    def test_node_substitution_rejected(self):
        with self.assertRaises(ValueError):permitted_value(self.row(),'price','other',{272160})
    def test_nonfinite_history_rejected(self):
        for s in ('nan','inf','-inf'):
            with self.assertRaises(ValueError):permitted_value(self.row(MW=s),'price','n',{272160})
    def test_component_order_and_roundtrip(self):
        key,b=permitted_value(self.row(XML_DATA_ITEM='LMP_LOSS_PRC'),'price','n',{272160})
        self.assertEqual((272160,3),key);self.assertEqual(12.25,struct.unpack('<f',b)[0])
    def test_timezone_and_grid_required(self):
        for s in ('2026-01-01T00:00:01Z','2026-01-01T00:00:00'):
            with self.assertRaises(ValueError):index(s)
    def test_gap_rejected_not_bridged(self):
        a=ByteLookup([(1,2,b'abcd'),(4,5,b'efgh')],4)
        self.assertEqual(b'abcd',a.cell(1,0));self.assertEqual(b'efgh',a.cell(4,0))
        for i in (0,2,3,5):
            with self.assertRaises(PermissionError):a.cell(i,0)
    def test_calendar_union_keeps_gap(self):
        self.assertEqual([[1,4],[6,8]],merged([(1,3),(2,4),(6,8)]))
    def test_forecast_filter_before_numeric_decode(self):
        r=self.row(MW='invalid',TAC_AREA_NAME='other',MARKET_RUN_ID='RTM',EXECUTION_TYPE='RTD')
        self.assertIsNone(permitted_value(r,'rtd','',{272160}))

if __name__=='__main__':
    result=unittest.TextTestRunner().run(unittest.defaultTestLoader.loadTestsFromTestCase(SourceBoundaryTests))
    import hashlib
    folder=Path(__file__).parent
    (folder/'QA.json').write_text(json.dumps(dict(status='passed' if result.wasSuccessful() else 'failed',
        tests=result.testsRun,failures=len(result.failures),errors=len(result.errors),market_values_read=False,
        sources={str(folder/f):hashlib.sha256((folder/f).read_bytes()).hexdigest() for f in ('source_math.py','test_source_math.py')}),indent=2),encoding='utf-8')
    raise SystemExit(0 if result.wasSuccessful() else 1)
