from common import *
import copy
def main():
 assert not (E/'PROTOCOL.json').exists(),'Registration immutable'
 guard(True)
 # Dependencies from prior preregistered calendar/label construction, plus full source receipt ledger.
 old=read(D/'PROTOCOL.json');prior=read(W/'PROTOCOL.json')
 for path,h in old['bindings'].items():assert sha(path)==h,path
 for path,h in prior['bindings'].items():assert sha(path)==h,path
 for path,h in read(Z/'PROTECTED_FILES.json').items():assert sha(path)==h,path
 with s.base.numeric('Register distinct binary UP source-information trial, no scientific model fitting'):
  from qa import run
  qa=run()
  from prepare import prepare
  support=prepare()
 p=copy.deepcopy(old['model_plan']);p.update(at=now(),status='registered_before_any_scientific_binary_fit',
  scope='Exploratory UP first-entry classification on already exposed development targets, source-admissible common population. Not independent confirmation or solution of downward spikes.',
  original_bilateral_closed=str(E/'BILATERAL_CLOSED.json'),
  change_reason='All706 sources collected; original sign-specific support fails DOWN training (6/10 dates versus20), while UP passes (32/55). Distinct UP-only binary feasibility study; no model-score-driven selection, thresholds/calendar/source rules unchanged.',
  binary_target='y==1 denotes first extreme event upward; all y==0 or2 are natural negative examples, retained without weights or resampling; not probability of any later UP after first DOWN',
  features=dict(HISTORY=29,HISTORY_DAM=38,COARSE=56,COARSE_DAM=65),
  calibration='Own chronological CAL only: binary positive temperature [.5,2] minimizes 2-class NLL; negative99th percentile alarm with strict >; frozen before EVAL. No class reweighting.',
  support_rule='UP must pass20 event UTC dates and gap>3600sec clusters in FIT,5 each CAL/EVAL for each fixed fold. DOWN support explicitly fails original bilateral design and is not waived for it.',
  evaluation='Four paired UP tests: DAM vs respective parent xBrier/logloss;2000paired3day-block bootstrap. Holm8 with four unrun DOWN p=1. AP,precision,recall,FPR,TP,FP allfolds/months; false-UP alarms on DOWN rows. Exploratory across prior development selection.',
  information_gate='For each DAM arm, UP Brier and logloss both improve in each fold; precision/recall nonworse,FPR<=.02; both paired proper tests Holm8<.05. Still requires independent confirmation and OOF benefit integration. No price MAE/RMSE benefit implied.',
  source_rules=old['source_rules'],source_scope='Retrospective publisher-cache reconstruction; not immutable-version proof or contemporaneous user capture. Replay audit required before fit.',
  resources=old['resources'],automatic_continuation=True,periodic_model_wakeups=False,new_test_targets_read=False,
  point_price_integration=False,mandatory_backbone_elements_preserved=True,whole_research_completed=False,
  independent_person_review=False,literature_basis=[dict(url='https://jmlr.org/papers/v11/cawley10a.html',principle='Repeated model selection can overfit finite evaluation samples; scoped trial remains exploratory, final untouched confirmation required')])
 paths=list(E.glob('*.py'))+[E/'launch.ps1',E/'QA.json',E/'SUPPORT.json',E/'BILATERAL_CLOSED.json',E/'dam.npy',E/'INDICES.npz',D/'PROTOCOL.json',D/'PUB_LEDGER.json',D/'resume_1/RESULT.json',B/'dataset/compiled_train_june/manifest.json',Z/'features.py',Z/'support.py',Z/'fit4_1009/disk_hgb.py',Path(s.base.__file__),Z/'PROTECTED_FILES.json']
 # Bind prior audited labels/features without recursively invoking old runners.
 bindings=dict(prior['bindings']);bindings.update({str(v):sha(v) for v in paths})
 for job in old['day_jobs']:
  for v in [D/'days'/(job['id']+'.json'),D/'rx'/(job['id']+'.json')]:bindings[str(v)]=sha(v)
 for job in old['publication_jobs']:
  v=D/'rx'/(job['id']+'.json');bindings[str(v)]=sha(v)
 p['bindings']=bindings
 write(E/'PROTOCOL.json',p)
 print(json.dumps(dict(registered=True,QA=qa,support=support,max_scientific_fits=8),ensure_ascii=False))
if __name__=='__main__':main()

