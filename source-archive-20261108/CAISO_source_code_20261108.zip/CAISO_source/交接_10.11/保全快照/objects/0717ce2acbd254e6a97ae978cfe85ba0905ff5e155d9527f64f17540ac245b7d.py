"""Independent all-origin check of fresh six-stream TRAIN/June QUERY inputs.

Reads forecasts and metadata only. No Torch, model weights, price targets, Q3
targets, or H1 targets. Execute after the compiler in an exclusive numeric slot.
"""
from pathlib import Path
from datetime import datetime, timezone
import hashlib
import json
import os
import sys
import uuid

for name in ('OMP_NUM_THREADS', 'MKL_NUM_THREADS', 'OPENBLAS_NUM_THREADS'):
    os.environ[name] = '1'
ROOT = Path(__file__).resolve().parents[1]


def sha(path):
    h = hashlib.sha256()
    with Path(path).open('rb') as stream:
        for chunk in iter(lambda: stream.read(1048576), b''):
            h.update(chunk)
    return h.hexdigest()


def read(path):
    return json.loads(Path(path).read_text(encoding='utf-8-sig'))


def inside(value):
    path = (ROOT / value).resolve()
    if not path.is_relative_to(ROOT):
        raise ValueError('Path escapes the as-of branch')
    return path


def _audit():
    folder = ROOT / 'stages/query/data'
    manifest_path = folder / 'manifest.json'
    manifest = read(manifest_path)
    protocol_path = ROOT / 'QUERY_DATA_PROTOCOL.json'
    protocol = read(protocol_path)
    assert manifest['protocol_sha256'] == sha(protocol_path)
    assert manifest['source_sha256'] == protocol['code_sha256'] == sha(ROOT/'source/query_data.py')
    for path, digest in protocol['metadata_bindings'].items():
        assert sha(path) == digest
    core_path = Path(protocol['dataset_manifest'])
    core = read(core_path)
    core_audit = read(core_path.parent/'audit.json')
    assert core_audit['status'] == 'passed'
    assert core_audit['dataset_manifest_sha256'] == manifest['dataset_manifest_sha256'] == sha(core_path)
    assert core['prefix_stop'] == 219168
    source_audit = read(protocol['source_audit'])
    assert source_audit['status'] == 'passed' and source_audit['query_raw_cache_verified'] is True
    assert manifest['source_audit_sha256'] == sha(protocol['source_audit'])
    assert manifest['hourly_prefix'] == 18264 and manifest['fit_hours'] == 9086
    assert manifest['exact_o_minus_1_publication_gate'] is True
    assert manifest['raw_unfitted_archive_cache_only'] is True
    assert manifest['old_normalizer_reused'] is False
    assert manifest['no_price_targets_read'] is True and manifest['no_Q3_or_2026_targets_read'] is True
    assert manifest['training_started'] is False
    for name, digest in manifest['artifacts'].items():
        path = (folder/name).resolve()
        assert path.is_relative_to(folder.resolve()) and sha(path) == digest

    import compile_gate as gate
    gate.bound_process()
    import numpy as np
    import query_data
    producer_path = Path(protocol['eligibility_manifest'])
    producer = read(producer_path)
    producer_dir = producer_path.parent

    def producer_file(name):
        path = producer_dir/name
        assert sha(path) == producer['artifacts'][name]
        return path

    def core_array(name):
        row = core['artifacts'][name]
        path = inside(row['path'])
        assert sha(path) == row['sha256']
        return np.load(path, allow_pickle=False)

    train_origins = core_array('train_origins.npy')
    june_origins = core_array('june_origins.npy')
    times = core_array('timestamps_seconds.npy')
    assert len(train_origins) == 72316 and len(june_origins) == 3397
    assert len(times) == 219168 and np.all(np.diff(times) == 300)
    fit = np.load(folder/'fit_hours.npy', allow_pickle=False)
    producer_fit = np.load(producer_file('query_normalizer_hours.npy'), allow_pickle=False)
    assert fit.dtype == np.int64 and np.array_equal(fit, producer_fit)
    assert len(fit) == 9086 and np.all(np.diff(fit) > 0) and fit[-1] < 17544

    # Derive the fitting union from the qualified training origins independently.
    required_hours = np.zeros(18264, dtype=bool)
    for start in range(0, len(train_origins), 512):
        origins = train_origins[start:start+512]
        history = ((origins-1)//12)[:, None] - np.arange(23, -1, -1)[None, :]
        future = (origins[:, None]+np.arange(12)[None, :])//12
        required_hours[history.reshape(-1)] = True
        required_hours[future.reshape(-1)] = True
    assert np.array_equal(np.flatnonzero(required_hours), fit)

    raw_path = Path(protocol['raw_hourly_forecast'])
    assert sha(raw_path) == protocol['raw_hourly_sha256']
    archive = np.load(raw_path, mmap_mode='r', allow_pickle=False)
    assert archive.shape == (20472, 6) and archive.dtype == np.float64
    raw = np.load(folder/'raw_hourly.npy', allow_pickle=False)
    assert raw.shape == (18264, 6) and raw.dtype == np.float64 and np.isfinite(raw).all()
    assert np.array_equal(raw, archive[:18264])
    archive._mmap.close()
    center = np.median(raw[fit], axis=0)
    q25, q75 = np.quantile(raw[fit], [.25, .75], axis=0)
    scale = np.maximum(q75-q25, 1.)
    normalizer = read(folder/'normalizer.json')
    assert np.array_equal(center, np.asarray(normalizer['center'], np.float64))
    assert np.array_equal(scale, np.asarray(normalizer['scale'], np.float64))
    assert normalizer['fit_hours'] == 9086 and normalizer['fit_stop_exclusive'] == 17544
    assert normalizer['fit_hours_sha256'] == sha(producer_file('query_normalizer_hours.npy'))
    assert normalizer['old_learned_state_reused'] is False
    normalized = np.load(folder/'normalized_hourly.npy', allow_pickle=False)
    independently_normalized = ((raw-center)/scale).astype(np.float32)
    assert normalized.dtype == np.float32 and np.array_equal(normalized, independently_normalized)

    publications = np.load(folder/'publication_hours_seconds.npy', allow_pickle=False)
    with np.load(producer_file('publication_arrays.npz'), allow_pickle=False) as source:
        load = source['dam_load_last_publication_seconds'][:219168].reshape(18264, 12)
        renewable = source['dam_renewable_last_publication_seconds'][:219168].reshape(18264, 12)
        assert np.all(load == load[:, :1]) and np.all(renewable == renewable[:, :1])
        independently_published = np.empty((18264, 6), dtype=np.int64)
        independently_published[:, 0] = load[:, 0]
        independently_published[:, 1:] = renewable[:, :1]
    assert np.array_equal(publications, independently_published)

    checked = {}
    for part, all_origins in (('train', train_origins), ('june', june_origins)):
        max_publication_minus_cutoff = -float('inf')
        for start in range(0, len(all_origins), 64):
            origins = all_origins[start:start+64]
            history = ((origins-1)//12)[:, None] - np.arange(23, -1, -1)[None, :]
            future = (origins[:, None]+np.arange(12)[None, :])//12
            cutoff = times[origins-1]
            for indices in (history, future):
                values = independently_published[indices]
                assert np.all(values > 0) and np.all(values <= cutoff[:, None, None])
                max_publication_minus_cutoff = max(max_publication_minus_cutoff, int(np.max(values-cutoff[:, None, None])))
            expected = np.empty((len(origins), 12, 6, 25), np.float32)
            expected[..., :24] = independently_normalized[history].transpose(0, 2, 1)[:, None]
            expected[..., 24] = independently_normalized[future]
            actual = query_data.materialize(origins, normalized, publications, times)
            assert np.array_equal(expected, actual)
        checked[part] = {'origins': len(all_origins), 'all_covariates_exact': True,
                         'max_publication_minus_issue_seconds': max_publication_minus_cutoff}
    assert manifest['all_qualified_train_origins_checked'] == checked['train']['origins']
    assert manifest['all_qualified_june_origins_checked'] == checked['june']['origins']

    # A one-second future release and an absent timestamp must be rejected.
    origin = int(train_origins[0])
    hour = (origin-1)//12
    rejected = []
    for name, invalid in (('one_second_after_issue', int(times[origin-1])+1), ('missing_publication', 0)):
        bad = publications.copy()
        bad[hour, 0] = invalid
        try:
            query_data.materialize(np.array([origin], np.int64), normalized, bad, times)
        except ValueError:
            rejected.append(name)
        else:
            raise AssertionError('An invalid publication was accepted: '+name)
    assert 'torch' not in sys.modules
    report = {
        'status': 'passed', 'at': datetime.now(timezone.utc).isoformat(),
        'query_manifest_sha256': sha(manifest_path), 'auditor_source_sha256': sha(__file__),
        'dataset_manifest_sha256': sha(core_path), 'dataset_audit_sha256': sha(core_path.parent/'audit.json'),
        'source_publication_binding_audit_sha256': sha(protocol['source_audit']),
        'fit_hours_independently_reconstructed': 9086, 'TRAIN_only_normalizers_recomputed': True,
        'complete_raw_prefix_and_normalized_arrays_exact': True,
        'six_stream_publication_arrays_exact': True, 'all_qualified_origin_checks': checked,
        'rejected_adversarial_publications': rejected,
        'torch_imported': False, 'price_targets_read': False, 'Q3_targets_read': False,
        'test_2026_targets_read': False, 'training_started': False,
        'resources': gate.check_working_set(256),
    }
    destination = folder/'audit.json'
    if destination.exists():
        previous = read(destination)
        for key in ('at', 'resources'):
            report[key] = previous[key]
        assert previous == report, 'Preserve existing audit; investigate changed evidence.'
    else:
        gate.write_new(destination, report)
    return report


def main():
    import psutil
    import compile_gate as gate
    capacity = gate.resources()
    if min(capacity['available_physical_GiB'], capacity['available_commit_GiB']) < 1:
        raise MemoryError('One GiB headroom required for the <=256 MiB QUERY audit')
    lock = Path('D:/Desktop/数据科学_论文/研究优化_20260818/logs/NEURAL_RUN.lock')
    owner = {'token': uuid.uuid4().hex, 'pid': os.getpid(), 'created': psutil.Process().create_time(),
             'action': 'independent_new_QUERY_data_audit', 'directory': str(ROOT)}
    with lock.open('x', encoding='utf-8') as stream:
        json.dump(owner, stream)
    try:
        report = _audit()
    finally:
        assert read(lock) == owner, 'Global lock changed; do not release another owner.'
        gate.write_new(ROOT/'audits/lock_releases'/(owner['token']+'.json'),
                       {'owner': owner, 'released_at': datetime.now(timezone.utc).isoformat()})
        lock.unlink()
    print(json.dumps(report, ensure_ascii=True))


if __name__ == '__main__':
    main()
