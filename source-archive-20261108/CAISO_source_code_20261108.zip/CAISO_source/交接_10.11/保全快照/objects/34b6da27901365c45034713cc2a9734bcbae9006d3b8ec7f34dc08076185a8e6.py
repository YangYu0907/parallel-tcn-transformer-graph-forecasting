"""Focused source resolution: validate revision-filter semantics, no target access."""
from pathlib import Path
import sys,os,json,time,io,zipfile,csv,hashlib
from urllib.request import urlopen,Request
from urllib.parse import urlencode
from datetime import datetime,timezone
H=Path(__file__).resolve().parent;R=H.parents[1];G=H.parent/'gates_execution_01'
sys.path.insert(0,str(R));import common as c
def long_path_write(path,value):
 import uuid
 path=Path(path).resolve();assert path.is_relative_to(R.resolve())
 path.parent.mkdir(parents=True,exist_ok=True)
 tmp=path.with_name('.'+path.name+'.'+uuid.uuid4().hex+'.tmp')
 prefix='\\\\?\\' if os.name=='nt' else ''
 with open(prefix+str(tmp),'w',encoding='utf-8') as f:json.dump(value,f,ensure_ascii=False,indent=2,allow_nan=False)
 os.replace(prefix+str(tmp),prefix+str(path))
c.write=long_path_write
def rows(path):
 with zipfile.ZipFile(path) as z:
  for n in z.namelist():
   if n.lower().endswith('.csv'):
    with z.open(n) as f:yield from csv.DictReader(io.TextIOWrapper(f,encoding='utf-8-sig'))
   else:raise ValueError(z.read(n).decode('utf-8','replace')[:2000])
def fetch(name,params):
 p=H/'sources'/f'{name}.json'
 if p.exists():return c.read(p)
 c.guard();time.sleep(8)
 url='https://oasis.caiso.com/oasisapi/SingleZip?'+urlencode(params)
 with urlopen(Request(url,headers={'User-Agent':'CAISO-academic-source-audit/1.0'}),timeout=40) as resp:body=resp.read(15000001)
 assert len(body)<=15000000
 path=H/'sources'/f'{name}.zip';path.parent.mkdir(parents=True,exist_ok=True);path.write_bytes(body)
 rec=dict(at=c.now(),params=params,url=url,body=str(path),sha256=c.sha(path),size=len(body))
 try:
  rr=list(rows(path));rec.update(status='csv',rows=len(rr),versions=sorted(set(x.get('ATLPUBVERSION','') for x in rr)))
 except Exception as ex:rec.update(status='non_csv',error=str(ex))
 c.write(p,rec);return rec
def main():
 c.write(H/'PROTOCOL.json',dict(at=c.now(),request='User explicitly asks to continue resolving the source barrier',
  scope='Validate revision filter against cached complete ALL-market ledger, then use complete later revision history before retrospective input admission. No training or new target access.',
  source_budget_seconds=7200,initial_new_requests=1,protected_files=c.verify_protected(),
  original_decision_sha256=c.sha(G/'GATE_DECISION.json'),
  publication_semantics_reference='https://bpmcm.caiso.com/BPM%20Document%20Library/Market%20Instruments/BPM_for_Market%20Instruments_V89_Redline.pdf'))
 p=dict(queryname='ATL_PUB',market_run_id='ALL',oasis_section='ALL',status='ALL',atlpubversion='Revised',version=1,
        startdatetime='20260123T00:00-0000',enddatetime='20260126T00:00-0000',resultformat=6)
 r=fetch('REVISION_FILTER_QA',p)
 if r['status']=='csv':
  source=c.read(G/'sources/JAN26_ATL_PUB_ALL.json');assert c.sha(source['body'])==source['sha256']
  old={x['PUBLICATION_ID'] for x in rows(source['body']) if x['ATLPUBVERSION']=='Revised'}
  new={x['PUBLICATION_ID'] for x in rows(r['body'])}
  r.update(expected_revised=len(old),observed=len(new),exact_filter_match=old==new,unrelated_ids=len(new-old),missing_ids=len(old-new))
 c.write(H/'FILTER_AUDIT.json',r)
 print(json.dumps(r,ensure_ascii=False),flush=True)
if __name__=='__main__':main()
