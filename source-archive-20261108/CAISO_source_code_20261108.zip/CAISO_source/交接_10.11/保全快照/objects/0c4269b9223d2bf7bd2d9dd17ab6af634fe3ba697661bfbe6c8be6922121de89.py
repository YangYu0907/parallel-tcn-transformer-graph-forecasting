"""Separate scoring implementation; never fits or chooses models."""
from revision_common import *
import numpy as np,csv
def independent_scores(y,q):
 levels=[.05,.1,.5,.9,.95];pl=[]
 for j,t in enumerate(levels):
  diff=y-q[...,j];pl.append(np.where(diff>=0,t*diff,(t-1)*diff))
 result={'pinball':np.stack(pl).mean(0)};weighted=.5*np.abs(y-q[...,2])
 for cov,lo,hi in [(80,1,3),(90,0,4)]:
  a=1-cov/100;lower=q[...,lo];upper=q[...,hi];inside=(lower<=y)&(y<=upper)
  score=upper-lower
  score=score.copy();below=y<lower;above=y>upper
  score[below]+=(2/a)*(lower[below]-y[below]);score[above]+=(2/a)*(y[above]-upper[above])
  result.update({f'coverage{cov}':inside.astype(float),f'width{cov}':upper-lower,f'interval_score{cov}':score});weighted+=a/2*score
 result['wis']=weighted/2.5
 return result
def main():
 with numeric('independent probability scoring audit'):
  records=[];largest=0.;count=0
  for task in ['CAISO','Europe']:
   for seed in SEEDS:
    guard();path=ROOT/'probability_predictions'/task/f'{seed}.npz'
    with np.load(path) as z:d={k:z[k] for k in z.files}
    rows=read(ROOT/'probability_scores'/task/f'{seed}.json');y=d['truth'];dates=d['cutoff']//86400
    if task=='CAISO':
     original=T/'spike_specialist_v7_20260930/audited'/f'{seed}.npz'
     with np.load(original) as z:
      lookup={int(o):i for i,o in enumerate(z['origins'])};ii=[lookup[int(o)] for o in d['origin']]
      assert np.array_equal(d['point'],z['CONTEXT'][ii]);assert np.array_equal(y,z['truth'][ii])
    else:
     original=B/'energy_confirmation_v1_20260926/runs'/f'FULL_{seed}_0.001/validation_predictions.npz'
     with np.load(original) as z:
      lookup={int(o):i for i,o in enumerate(z['origins'])};ii=[lookup[int(o)] for o in d['origin']]
      assert np.array_equal(d['point'],z['prediction'][ii].transpose(0,2,1))
    cache={name:independent_scores(y,d[name]) for name in ['HIST','HIST_CAL','CQR_RAW','CQR_CAL']}
    for name in cache:
     assert np.isfinite(d[name]).all() and np.all(np.diff(d[name],axis=-1)>=0)
     assert np.allclose(cache[name]['wis'],2*cache[name]['pinball'],rtol=1e-12,atol=1e-12)
    for row in rows:
     kind=row['partition'];value=row['value'];n,l,h=y.shape
     if kind=='overall':mask=np.ones_like(y,bool)
     elif kind=='location':mask=np.broadcast_to((np.arange(l)==int(value))[None,:,None],y.shape)
     elif kind=='horizon':mask=np.broadcast_to((np.arange(h)+1==int(value))[None,None,:],y.shape)
     elif kind=='realized_state':mask=d['states']==int(value)
     elif kind=='observable_regime':mask=d['observable']==int(value)
     elif kind=='actual_price_sign':mask=(y<0) if value=='negative' else (y>=0)
     else:raise AssertionError(kind)
     assert mask.sum()==row['cells'] and len(np.unique(dates[mask.any((1,2))]))==row['dates']
     for metric,value in cache[row['model']].items():
      gap=abs(float(value[mask].mean())-row[metric]);largest=max(gap,largest);assert gap<1e-9,(task,seed,row,metric,gap)
     count+=1
    records.append(dict(task=task,seed=seed,exact_point_preservation=True,origins=len(y),dates=len(np.unique(dates)),prediction_file=str(path),sha256=sha(path)))
  for p,h in read(ROOT/'PROBABILITY_SOURCE_BINDINGS.json').items():assert sha(p)==h,p
  write(ROOT/'PROBABILITY_INDEPENDENT_AUDIT.json',dict(at=now(),status='passed',audit_kind='separate local scoring implementation; not external human review',rows_recomputed=count,max_metric_gap=largest,records=records,protected_files=verify_protected(),future_information_QA=read(ROOT/'PROBABILITY_QA.json')['status'],independent_test=False))
  print(json.dumps(dict(status='passed',rows=count,max_gap=largest)))
if __name__=='__main__':main()
