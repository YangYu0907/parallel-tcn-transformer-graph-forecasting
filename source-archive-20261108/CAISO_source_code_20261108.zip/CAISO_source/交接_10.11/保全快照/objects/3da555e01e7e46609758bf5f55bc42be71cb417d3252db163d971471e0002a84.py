"""Finite frozen-input audit and predictions. Never form new test target arrays."""
from pathlib import Path
import hashlib,os,sys,time,uuid
HERE=Path(__file__).resolve().parent
sys.path.insert(0,str(HERE.parent/'context_expert_v1_20260929'))
import gate
OUT=HERE/'evaluation'

def pulse():
    gate.guard()
    for folder in (HERE,OUT,OUT/'queue'):
        for name in ('STOP_REQUESTED','STOP_REQUESTED.json'):
            if (folder/name).exists():raise InterruptedError('User stop')
def status(**v):gate.write(OUT/'queue/status.json',dict(at=gate.now(),pid=os.getpid(),**v))
def event(kind,evidence):
    eid='guarded_period_inputs_'+kind+'_'+gate.sha(evidence)
    gate.write(gate.ROOT/'event_driven_automation/inbox'/(eid+'.json'),dict(schema='caiso_research_event_v1',event_id=eid,event=kind,
        evidence_path=str(evidence),at=gate.now(),new_test_targets_read=False,trial=str(HERE)))
    return eid
def handoff(stage,active):
    h=gate.read(gate.ROOT/'HANDOFF.json');h.update(at=gate.now(),status=stage,current_stage=stage,training_active=False,
        current_process=os.getpid() if active else None,current_plan_complete=False,complete_research_experiment=False)
    h.setdefault('guarded_confirmation',{}).update(stage=stage,input_audit_and_inference_active=active,
        final_deployment_gate_fitted=True,final_gate_refit_active=False,final_gate_freeze=str(HERE/'final_gates/AUDIT_FREEZE.json'),
        evaluation_protocol=str(OUT/'PROTOCOL.json'),evaluation_status=str(OUT/'queue/status.json'),test_targets_read=False,independent_period_admitted=False)
    gate.write(gate.ROOT/'HANDOFF.json',h)

def verify(p):
    for path,d in p['bindings'].items():gate.need(gate.sha(path)==d,'Frozen forecast pipeline changed: '+path)

def run():
    gate.boundary();p=gate.read(OUT/'PROTOCOL.json');verify(p)
    lock=OUT/'queue/manager.lock';lock.parent.mkdir(parents=True,exist_ok=True)
    with lock.open('x',encoding='utf-8') as f:f.write(str(os.getpid()))
    try:
        with gate.exclusive('guarded_period_frozen_inputs_and_forecasts_only'):
            handoff('guarded_period_input_and_inference_audit_running',True)
            np,torch,lim=gate.runtime();begun=time.monotonic()
            origins=np.array(p['origins_utc_seconds'],np.int64);feature_path=OUT/'features.npy'
            admission=OUT/'INPUT_ADMISSION.json'
            if admission.exists():
                a=gate.read(admission);gate.need(a['protocol_sha256']==gate.sha(OUT/'PROTOCOL.json') and gate.sha(feature_path)==a['features_sha256'],'Saved input audit changed')
            else:
                from period_history import History,independent_numeric_check,build_features
                reader=History(p,pulse);causal=reader.check_future_invariance();items=[]
                temp=OUT/('features.partial.'+uuid.uuid4().hex+'.npy')
                features=np.lib.format.open_memmap(temp,mode='w+',dtype=np.float32,shape=(len(origins),288,30,29))
                try:
                    for i,o in enumerate(origins):
                        pulse();parts=reader.parts(int(o));x=build_features(**parts,scalers=reader.scalers,tac=reader.tac,age_caps=reader.caps)
                        delta,ratio=independent_numeric_check(x,parts,reader.scalers,reader.tac,reader.caps)
                        features[i]=x
                        items.append(dict(origin_utc_seconds=int(o),status='passed',input_sha256=hashlib.sha256(x.tobytes()).hexdigest(),
                                          independent_volatility_max_abs=delta,volatility_tolerance_fraction=ratio))
                        if i%16==0:status(event='checking_actual_inputs',completed=i+1,total=len(origins))
                    features.flush()
                finally:features._mmap.close()
                gate.need(not feature_path.exists(),'Do not overwrite existing features');os.replace(temp,feature_path)
                gate.write(OUT/'input_receipts.json',items);gate.write(OUT/'input_source_reads.json',reader.source_receipts)
                a=dict(at=gate.now(),status='all_frozen_source_inputs_passed_separate_equation_checks',origins=len(items),nodes=30,features=29,
                       history=288,protocol_sha256=gate.sha(OUT/'PROTOCOL.json'),features_sha256=gate.sha(feature_path),
                       input_receipts_sha256=gate.sha(OUT/'input_receipts.json'),source_read_receipts_sha256=gate.sha(OUT/'input_source_reads.json'),
                       causal_invariance=causal,test_target_arrays_read=False,target_statistics_computed=False,
                       input_contract_unchanged=True,training_updates=0,scoring_release=False)
                gate.write(admission,a);del reader
            status(event='frozen_expert_inference_and_June_replay',origins=len(origins))
            features=np.load(feature_path,mmap_mode='r')
            from period_inference import run as inference
            try:inference(dict(p,actual_features_sha256=gate.sha(feature_path)),features,origins,np,torch,pulse)
            finally:features._mmap.close()
            verify(p)
            complete=OUT/'queue/completion.json'
            gate.write(complete,dict(at=gate.now(),status='111_frozen_inputs_and_all_forecasts_ready_pending_independent_release_review',
                input_admission=str(admission),input_admission_sha256=gate.sha(admission),prediction_audit=str(OUT/'PREDICTION_AUDIT.json'),
                prediction_audit_sha256=gate.sha(OUT/'PREDICTION_AUDIT.json'),elapsed_seconds=time.monotonic()-begun,
                new_test_targets_read=False,independent_period_admitted=False,training_updates=0,scoring_release=False))
            eid=event('major_milestone',complete);status(event='finite_sampling_queue_completed',event_id=eid)
            handoff('guarded_period_inputs_and_predictions_complete_pending_release_review',False)
    except BaseException as exc:
        evidence=OUT/'queue/STOP.json';gate.write(evidence,dict(at=gate.now(),error=repr(exc),artifacts_preserved=True,new_test_targets_read=False,automatic_restart=False))
        paused=isinstance(exc,InterruptedError);eid=None if paused else event('blocking_failure',evidence)
        status(event='user_stop' if paused else 'sampling_blocking_failure',event_id=eid,error=repr(exc));handoff('guarded_period_input_inference_blocked',False);raise
    finally:
        gate.need(lock.read_text()==str(os.getpid()),'Period worker lock owner changed');lock.unlink()

if __name__=='__main__':run()
