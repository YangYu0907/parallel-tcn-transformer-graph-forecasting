from common import *
import subprocess,traceback

def emit(kind,p):
    eid='chronological_prefix_v14_'+kind+'_'+gate.sha(p)
    gate.write(B/'event_driven_automation/inbox'/(eid+'.json'),dict(schema='caiso_research_event_v1',event_id=eid,event=kind,evidence_path=str(p),at=gate.now(),trial=str(HERE)));return eid
def main():
    gate.guard(True);sealcheck();assert not gate.LOCK.exists(),'Existing numerical worker'
    lock=HERE/'queue/manager.lock';lock.parent.mkdir(parents=True,exist_ok=True)
    with lock.open('x') as f:f.write(str(os.getpid()))
    try:
        h=gate.read(B/'HANDOFF.json');h.update(at=gate.now(),status='one_prefix_FULL_and_specialist_pilot_running',training_active=True,current_process=os.getpid(),current_plan=str(HERE/'PROTOCOL.json'),current_plan_complete=False,current_stage='prefix_internal_cross_fitting')
        h['chronological_expert_pilot_v14']=dict(directory=str(HERE),status=str(HERE/'queue/status.json'),artifacts=str(ART),seed=SEED,scope='one_prefix_feasibility_not_independent_confirmation');gate.write(B/'HANDOFF.json',h)
        for script in ['train.py','specialist.py','score.py','audit_result.py']:
            gate.boundary();write(HERE/'queue/status.json',dict(at=gate.now(),pid=os.getpid(),event='step_process_started',script=script))
            child=subprocess.Popen([sys.executable,str(HERE/script)],cwd=str(HERE));write(HERE/'queue/child.json',dict(at=gate.now(),pid=child.pid,manager_pid=os.getpid(),script=str(HERE/script)))
            code=child.wait()
            if code:
                p=HERE/'WORKER_STOP.json'
                if p.exists() and gate.read(p).get('user_stop'):raise InterruptedError('Worker saved at user stop')
                raise RuntimeError(script+' exited '+str(code)+'; inspect stderr and saved checkpoints')
        p=HERE/'queue/completion.json';write(p,dict(at=gate.now(),status='finite_prefix_pilot_and_audit_complete',result_sha256=gate.sha(HERE/'RESULT.json'),audit_sha256=gate.sha(HERE/'AUDIT.json'),decision=str(HERE/'DECISION.json'),complete_research_experiment=False))
        h=gate.read(B/'HANDOFF.json');h.update(at=gate.now(),status='one_prefix_pilot_completed_audited_V7_retained',training_active=False,current_process=None,current_plan_complete=True,current_stage='prefix_expert_error_library_ready',next_bounded_action='Diagnose chronological relative-error signal before any router or additional prefix; no automatic expansion.');h['chronological_expert_pilot_v14'].update(result=str(HERE/'RESULT.json'),audit=str(HERE/'AUDIT.json'));gate.write(B/'HANDOFF.json',h)
        eid=emit('audited_result_ready',p);write(HERE/'queue/status.json',dict(at=gate.now(),pid=os.getpid(),event='finite_mechanism_queue_completed',event_id=eid))
    except BaseException as e:
        p=HERE/'queue/STOP.json';write(p,dict(at=gate.now(),error=repr(e),traceback=traceback.format_exc(),checkpoints_preserved=True,automatic_restart=False))
        h=gate.read(B/'HANDOFF.json');h.update(at=gate.now(),status='prefix_pilot_stopped_checkpoints_preserved',training_active=False,current_process=None);gate.write(B/'HANDOFF.json',h)
        paused=isinstance(e,InterruptedError);eid=None if paused else emit('blocking_failure',p)
        write(HERE/'queue/status.json',dict(at=gate.now(),pid=os.getpid(),event='user_stop_at_stage_boundary' if paused else 'step_stopped_or_failed',event_id=eid,error=repr(e)));raise
    finally:
        assert lock.read_text()==str(os.getpid());lock.unlink()
if __name__=='__main__':main()
