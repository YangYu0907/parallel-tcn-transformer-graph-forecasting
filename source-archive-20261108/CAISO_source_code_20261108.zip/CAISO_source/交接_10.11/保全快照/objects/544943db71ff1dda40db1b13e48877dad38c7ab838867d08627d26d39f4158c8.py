from pathlib import Path
import json, hashlib, shutil, os
from datetime import datetime, timezone
from pypdf import PdfReader

P=Path(r'F:\CAISO_论文\manuscript_20261001_v7_focused')
B=Path(r'F:\CAISO_论文\CAISO_feature_fusion_rev12\asof_retraining_branch_20260913')
OLD=Path(r'F:\CAISO_论文\manuscript_20260930_v7_integrated')
now=datetime.now(timezone.utc).isoformat()
def sha(p):
 h=hashlib.sha256()
 with p.open('rb') as f:
  for x in iter(lambda:f.read(1024*1024),b''): h.update(x)
 return h.hexdigest()
def write(p,v):
 tmp=p.with_name(p.name+'.tmp')
 tmp.write_text(json.dumps(v,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
 os.replace(tmp,p)
qa=json.loads((P/'qa/CONTENT_QA.json').read_text(encoding='utf-8'))
assert qa['status']=='passed' and qa['checks']==151
visual={n:{'pages':len(PdfReader(P/(n+'.pdf')).pages),'inspected_pages':list(range(1,c+1)),'full_page_visual_check':'passed; no clipped content, overlapping text, broken equations or unreadable relocated tables observed'} for n,c in [('Energy_manuscript',25),('Energy_supplementary',18)]}
for n,d in visual.items(): assert d['pages']==len(d['inspected_pages'])
final={'at':now,'status':'passed','scope':'Editorial relocation, synchronized figures/tables and document QA; no new predictive experiment or external peer review.', 'content_checks':qa['checks'],'content_evidence':'CONTENT_QA.json','visual_review':visual,'visual_reviewer':'Assistant, all 43 full-page renders inspected','main':{'pages':25,'tables':7,'figures':14,'references':63,'editable_equations':10},'supplement':{'pages':18,'tables':18,'figures':7},'unchanged_model_results':True,'complete_component_table_relocated_to':'Table S17','complete_component_figure_relocated_to':'Fig. S6','complete_matched_panel_table_relocated_to':'Table S18','complete_matched_panel_figure_relocated_to':'Fig. S7','original_source_version_preserved':str(OLD),'all_prior_evidence_preserved':True,'new_Fig6_scope':'Both single-branch controls, both tasks, both MAE and RMSE; all four design pairs retained.', 'main_overall_comparison_tables_complete':True,'main_material_qualifications_retained':True,'test_targets_accessed':False,'model_training_started':False}
write(P/'qa/FINAL_QA.json',final)
(P/'修订说明.txt').write_text('''V7收尾版：正文与补充材料同步修订（2026-10-01）

1. 正文现为25页、7张表、14幅图；补充材料18页、18张表、7幅图。
2. 原表6的完整组件对照移至补充表S17，原图6移至补充图S6。正文表6、图6聚焦两个任务的完整时间分支比较；图6同时显示MAE和RMSE，并提供英文、中文、矢量和栅格版本。
3. 原表8的开发期及9月匹配融合数据全部移至补充表S18；原图15全部移至补充图S7。没有将两个面板的最佳数字混用。
4. 动态图、原CAISO拼接比较、匹配融合显著性及60分钟表现的详细数据保留在补充材料。正文集中讲已验证收益，保留必要的简短说明与补充材料引用。完整主结果表4、5保持原样，未按正负方向删除比较行。
5. V7所有数值、原始结果及模型均未修改；原稿目录完整保留。63篇参考文献、10个可编辑公式及核验清单保持不变。
6. 已完成151项内容一致性检查，以及正文25页和补充材料18页的逐页视觉检查。这是文稿和数值一致性核验，不是外部同行评审。
7. 当前仍保留一次有限改进机会；新独立数据准入前不启动训练，不以已查看的测试结果调参。本文稿更新本身没有新增训练或读取新测试目标。

文件：Energy_manuscript.docx / .pdf；Energy_supplementary.docx / .pdf。
绘图数据和完整比较见evidence；可复现脚本见source；英文及中文图件见figures。
''',encoding='utf-8')
manifest={'schema':'caiso_manuscript_delivery_v1','at':now,'revision':'v7_focused_20261001','directory':str(P),'source_version':str(OLD),'status':'editorial_package_complete','model':'Retained V7 and frozen backbone comparisons, unchanged','qa':str(P/'qa/FINAL_QA.json'),'deliverables':[str(P/n) for n in ['Energy_manuscript.docx','Energy_manuscript.pdf','Energy_supplementary.docx','Energy_supplementary.pdf']], 'files':[]}
for f in sorted(P.rglob('*')):
 if f.is_file() and f.name!='DELIVERY_MANIFEST.json': manifest['files'].append({'path':str(f.relative_to(P)),'bytes':f.stat().st_size,'sha256':sha(f)})
write(P/'DELIVERY_MANIFEST.json',manifest)
# Append the current editorial outcome; retain all experiment decisions and states.
hp=B/'HANDOFF.json'; backup=P/'qa/HANDOFF_before_editorial_update.json'
if not backup.exists(): shutil.copy2(hp,backup)
h=json.loads(hp.read_text(encoding='utf-8-sig'))
h['focused_manuscript_20261001']={'at':now,'status':'completed_verified','directory':str(P),'main_docx':str(P/'Energy_manuscript.docx'),'main_pdf':str(P/'Energy_manuscript.pdf'),'supplement_docx':str(P/'Energy_supplementary.docx'),'supplement_pdf':str(P/'Energy_supplementary.pdf'),'qa':str(P/'qa/FINAL_QA.json'),'manifest':str(P/'DELIVERY_MANIFEST.json'),'old_version_preserved':str(OLD),'V7_and_all_reported_results_unchanged':True,'main_figures':14,'main_tables':7,'references':63,'main_pages':25,'supplement_pages':18,'supplement_tables':18,'supplement_figures':7,'new_training':False,'new_test_access':False,'editorial_scope':'Complete component and matched-fusion comparisons relocated together; main focuses verified gains and retains material qualifications and supplement references.'}
h['current_manuscript']=str(P/'Energy_manuscript.docx')
h['current_manuscript_manifest']=str(P/'DELIVERY_MANIFEST.json')
h['manuscript_editing_deferred_by_user']=False
h['latest_editorial_user_authorization']='2026-10-01: update tables, figures and references together; detailed remaining comparisons in supplementary material.'
h['last_updated_utc']=now
# Latest user explicitly authorized this editorial pass; candidate admission remains mandatory.
if 'final_improvement_opportunity' in h:
 h['final_improvement_opportunity']['manuscript_edits_deferred_until_decision']=False
 h['final_improvement_opportunity']['latest_editorial_revision']=str(P)
write(hp,h)
# Add the handoff backup to delivery provenance after creation.
manifest['files'].append({'path':str(backup.relative_to(P)),'bytes':backup.stat().st_size,'sha256':sha(backup)})
write(P/'DELIVERY_MANIFEST.json',manifest)
print(json.dumps({'status':'completed_verified','files_hashed':len(manifest['files']),'main_pages':25,'supplement_pages':18,'V7_unchanged':True,'training_started':False,'candidate_status':h.get('final_improvement_opportunity',{}).get('status')},ensure_ascii=False))
