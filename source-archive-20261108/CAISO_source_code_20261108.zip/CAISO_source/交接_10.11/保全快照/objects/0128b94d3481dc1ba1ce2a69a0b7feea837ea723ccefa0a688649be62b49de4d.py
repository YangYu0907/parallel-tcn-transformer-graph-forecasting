from support import *
import subprocess,traceback
def status(**kw):write(HERE/'STATUS.json',dict(at=old.now(),pid=os.getpid(),**kw))
def emit(event,path):
    eid='unified_distribution_'+event+'_'+sha(path);dest=old.B/'event_driven_automation/inbox'/(eid+'.json')
    if not dest.exists():write(dest,dict(schema='caiso_research_event_v1',event_id=eid,event=event,at=old.now(),evidence_path=str(path),evidence_sha256=sha(path)))
    return eid
def main():
    lock=HERE/'MANAGER.lock'
    with lock.open('x') as f:json.dump(dict(pid=os.getpid()),f)
    child=None
    try:
        verify();checked(True);status(event='awaiting_exit_monitor_binding',worker_pid=None)
        deadline=time.monotonic()+45
        while not (HERE/'START_READY.json').exists():
            checked()
            if time.monotonic()>deadline:raise TimeoutError('Exit monitor not bound')
            time.sleep(.2)
        ready=read(HERE/'START_READY.json');assert ready['manager_pid']==os.getpid()
        import psutil
        assert psutil.pid_exists(ready['exit_monitor_pid'])
        commands=[]
        for task in TASKS:
            for seed in SEEDS:
                for arm in ARMS:
                    commands.append(([str(HERE/'worker.py'),'--task',task,'--seed',str(seed),'--arm',arm],HERE/'fits'/f'{task}_{seed}_{arm}'/'COMPLETE.json'))
        commands.extend([([str(HERE/'evaluate.py')],HERE/'RESULT.json'),([str(HERE/'audit.py')],HERE/'AUDIT.json')])
        for i,(cmd,proof) in enumerate(commands):
            if proof.exists():
                if proof.name=='COMPLETE.json':
                    pr=read(proof);assert sha(proof.parent/'raw.npz')==pr['prediction_sha256']
                continue
            checked(True)
            with (HERE/'worker.log').open('a',encoding='utf-8') as log:
                child=subprocess.Popen([sys.executable,'-u']+cmd,cwd=HERE,stdout=log,stderr=subprocess.STDOUT)
                status(event='step_process_started',worker_pid=child.pid,step=i+1,total_steps=len(commands),command=cmd)
                while child.poll() is None:
                    # Local safety polling, no model wake-up messages.
                    try:checked()
                    except BaseException:
                        # Workers checkpoint and check themselves. Allow brief graceful exit before interrupt.
                        try:child.wait(timeout=20)
                        except subprocess.TimeoutExpired:child.terminate();child.wait(timeout=20)
                        raise
                    time.sleep(2)
                code=child.returncode
            if code:raise RuntimeError('Worker exit '+str(code)+': '+' '.join(cmd)+'; no automatic retry')
        path=HERE/'AUDIT.json';assert read(path)['status']=='passed'
        eid=emit('audited_result_ready' if read(HERE/'RESULT.json')['screen_passed'] else 'needs_analysis',path)
        status(event='finite_sampling_queue_completed',worker_pid=None,event_id=eid,evidence_path=str(path))
    except InterruptedError as e:status(event='user_stop',classification='user_stop',worker_pid=None,error=str(e))
    except Exception as e:
        path=HERE/'FAILURE.json';write(path,dict(at=old.now(),error=repr(e),traceback=traceback.format_exc(),automatic_retry=False))
        eid=emit('blocking_failure',path);status(event='sampling_blocking_failure',worker_pid=None,event_id=eid,error=repr(e))
    finally:
        if read(lock).get('pid')==os.getpid():lock.unlink()
if __name__=='__main__':main()

