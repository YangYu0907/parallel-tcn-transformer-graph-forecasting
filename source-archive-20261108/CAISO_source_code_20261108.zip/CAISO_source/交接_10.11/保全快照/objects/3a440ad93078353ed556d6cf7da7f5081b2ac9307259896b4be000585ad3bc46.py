"""One fixed June-only refit per seed and matched global-weight control."""
from pathlib import Path
import gc, json, os, sys, time
HERE=Path(__file__).resolve().parent
sys.path.insert(0,str(HERE.parent/'context_expert_v1_20260929'))
import gate
TRIAL=gate.HERE
OUT=HERE/'final_gates'

def boundary():
    gate.boundary()
    for folder in (HERE,OUT,OUT/'queue'):
        for name in ('STOP_REQUESTED','STOP_REQUESTED.json'):
            if (folder/name).exists():raise InterruptedError('User stop: '+str(folder/name))
def guard():boundary();gate.guard()
def status(**v):gate.write(OUT/'queue/status.json',dict(at=gate.now(),pid=os.getpid(),**v))
def event(kind,evidence):
    ident='guarded_final_gates_'+kind+'_'+gate.sha(evidence)
    gate.write(gate.ROOT/'event_driven_automation/inbox'/(ident+'.json'),dict(schema='caiso_research_event_v1',event_id=ident,event=kind,
        evidence_path=str(evidence),at=gate.now(),new_test_targets_read=False,trial=str(HERE)))
    return ident
def handoff(stage,active):
    h=gate.read(gate.ROOT/'HANDOFF.json')
    h.update(at=gate.now(),status=stage,current_stage=stage,current_process=os.getpid() if active else None,
        training_active=active,current_plan_complete=False,complete_research_experiment=False)
    h.setdefault('guarded_confirmation',{}).update(stage=stage,final_gate_refit_active=active,gate_status=str(OUT/'queue/status.json'),
        final_gate_protocol=str(OUT/'PROTOCOL.json'),structure_admission=str(HERE/'structure_admission/RESULT.json'),
        test_targets_read=False,independent_period_admitted=False,core_backbone_training=False)
    gate.write(gate.ROOT/'HANDOFF.json',h)

def prepare():
    boundary();gate.need(not (OUT/'PROTOCOL.json').exists(),'Final fit registration already exists')
    p=gate.verify();source=gate.read(HERE/'structure_admission/RESULT.json')
    gate.need(source['source_structure_candidates']>0 and not source['test_targets_read'],'Source feasibility absent')
    for path,digest in source['bindings'].items():gate.need(gate.sha(path)==digest,'Source admission binding changed')
    manifest=gate.read(p['dataset_manifest']);paths={k:str(gate.resolve(v['path'])) for k,v in manifest['artifacts'].items()}
    bindings={}
    for path in [Path(__file__),TRIAL/'core.py',TRIAL/'gate.py',TRIAL/'support_guard_pilot.py',TRIAL/'PROTOCOL.json',
                 TRIAL/'SEAL.json',TRIAL/'support_guard_pilot/DECISION.json',HERE/'structure_admission/RESULT.json',
                 HERE/'SOURCE_REGISTRATION.json',HERE/'CONTINUATION.md',Path(p['dataset_manifest'])]:
        bindings[str(path)]=gate.sha(path)
    for key in ('features.npy','scalers.json','state_thresholds.json'):
        bindings[paths[key]]=gate.sha(paths[key])
    for c in p['cases']:
        for path in (Path(c['checkpoint']),TRIAL/'cache'/f'{c["seed"]}_{c["model"]}.npz',TRIAL/'cache'/f'{c["seed"]}_{c["model"]}.json'):
            bindings[str(path)]=gate.sha(path)
    result=dict(at=gate.now(),status='registered_before_final_fits_and_new_numeric_input_access',
        candidate='HORIZON_GUARDED',seeds=p['seeds'],arms=['HORIZON_MIX','STATIC_MIX'],fixed_epochs=20,
        optimizer=dict(name='Adam',lr=.001,weight_decay=.0001),batch_size=4096,objective='USD MAE; same float32 node-scaled expert algebra as development fits',
        seed_offset=4000,training_origins='All3397 June development origins, no new test data',paths=paths,expert_cases=p['cases'],
        early_stopping=False,hyperparameter_search=False,initialization='Every horizon/global logit starts[4,0,0]',
        fallback='Per-node June min/max support of current price_level/change60m/volatility3h OR observed price deviation above existing TRAINq99; fallback to terminal FULL',
        support_fields=[0,21,22],bounds_inclusive=True,guard_threshold_search=False,
        context_model_retrained=False,expert_optimizer_updates=0,core_elements_preserved=True,
        final_test_arms=['HORIZON_GUARDED','FULL','DLinear','Persistence','HORIZON_MIX','STATIC_GUARDED','EQUAL_GUARDED','FULL_SELECTED'],
        maximum_seconds=3600,save_every_updates=128,bindings=bindings,
        new_test_targets_read=False,next_required='Independently audit and freeze final gates; freeze complete input/inference/statistical pipeline before target release')
    gate.write(OUT/'PROTOCOL.json',result)
    print(json.dumps(dict(status='six_fixed_fits_registered',fits=len(p['seeds'])*2,epochs=20,backbone_updates=0)))

def verify(p):
    for path,digest in p['bindings'].items():gate.need(gate.sha(path)==digest,'Frozen final-fit input changed: '+path)

def fit(p,seed,arm,experts,truth,node_scale,guard_info,np,torch,core,started):
    folder=OUT/f'{seed}_{arm}';folder.mkdir(parents=True,exist_ok=True)
    receipt=folder/'receipt.json'
    if receipt.exists():
        r=gate.read(receipt);gate.need(gate.sha(folder/'MODEL.json')==r['model_sha256'],'Completed gate changed');return
    ex=experts.reshape(-1,3);y=truth.reshape(-1)
    usd=np.broadcast_to(node_scale[None,:,None],truth.shape).astype(np.float32).reshape(-1).copy()
    horizon=np.tile(np.arange(12,dtype=np.int64),len(truth)*30)
    te,ty,tu,th=[torch.from_numpy(x) for x in (ex,y,usd,horizon)]
    model=core.Router(arm,seed+p['seed_offset'])
    opt=torch.optim.Adam(model.parameters(),lr=p['optimizer']['lr'],weight_decay=p['optimizer']['weight_decay'])
    rng=np.random.default_rng(seed+p['seed_offset'])
    state=dict(epoch=0,offset=0,order=None,updates=0,losses=[])
    cp=folder/'checkpoint.pt'
    identity=dict(protocol_sha256=gate.sha(OUT/'PROTOCOL.json'),seed=seed,arm=arm,rows=len(ex))
    if cp.exists():
        saved=torch.load(cp,map_location='cpu',weights_only=False)
        gate.need(saved['identity']==identity,'Final gate checkpoint identity')
        model.load_state_dict(saved['weights']);opt.load_state_dict(saved['optimizer'])
        rng.bit_generator.state=saved['numpy_rng'];torch.set_rng_state(saved['torch_rng']);state=saved['progress'];del saved
    def save():
        value=dict(identity=identity,weights=model.state_dict(),optimizer=opt.state_dict(),numpy_rng=rng.bit_generator.state,
                   torch_rng=torch.get_rng_state(),progress=state)
        gate.atomic(cp,lambda f:torch.save(value,f))
    try:
        if not cp.exists():save()
        while state['epoch']<p['fixed_epochs']:
            guard();gate.need(time.monotonic()-started<p['maximum_seconds'],'Final refit time budget exhausted')
            if state['order'] is None:state['order']=rng.permutation(len(ex));state['offset']=0;state['loss_sum']=0.
            model.train()
            while state['offset']<len(ex):
                guard();gate.need(time.monotonic()-started<p['maximum_seconds'],'Final refit time budget exhausted')
                ids=state['order'][state['offset']:state['offset']+p['batch_size']]
                opt.zero_grad(set_to_none=True)
                # z is unused by these two fixed gate families; do not compute unused context features.
                pred,w=model(te[ids],th[ids],te[ids])
                loss=torch.mean(torch.abs(pred-ty[ids])*tu[ids])
                gate.need(bool(torch.isfinite(loss)),'Nonfinite final gate loss')
                loss.backward();gate.need(all(v.grad is not None and bool(torch.isfinite(v.grad).all()) for v in model.parameters()),'Nonfinite gradient')
                opt.step();state['offset']+=len(ids);state['updates']+=1;state['loss_sum']+=float(loss.detach())*len(ids)
                if state['updates']%p['save_every_updates']==0:save()
            state['losses'].append(state['loss_sum']/len(ex));state['epoch']+=1;state['order']=None;state['offset']=0;save()
            status(event='final_gate_fitting',seed=seed,arm=arm,epoch=state['epoch'],epochs=p['fixed_epochs'],test_targets_read=False)
        model.eval()
        with torch.no_grad():weights=torch.softmax(model.logits,dim=-1).cpu().numpy()
        record=dict(at=gate.now(),arm=arm,seed=seed,expert_order=['FULL','DLinear','Persistence'],identity=identity,
                    logits=model.logits.detach().cpu().numpy().tolist(),weights=weights.tolist(),guard=guard_info,
                    epochs=state['epoch'],updates=state['updates'],train_loss_trace=state['losses'],checkpoint_sha256=gate.sha(cp),
                    selection='Fixed epoch20; training loss does not select a checkpoint',new_test_targets_read=False)
        gate.write(folder/'MODEL.json',record)
        gate.write(receipt,dict(at=gate.now(),status='final_gate_fit_complete_pending_audit',model_sha256=gate.sha(folder/'MODEL.json'),
                               checkpoint_sha256=gate.sha(cp),identity=identity,expert_updates=0))
        print(json.dumps(dict(seed=seed,arm=arm,epochs=state['epoch'],status='fit_complete')),flush=True)
    finally:
        if not receipt.exists():save()
        del model,opt,te,ty,tu,th;gc.collect()

def run():
    boundary();p=gate.read(OUT/'PROTOCOL.json');verify(p)
    lock=OUT/'queue/manager.lock';lock.parent.mkdir(parents=True,exist_ok=True)
    with lock.open('x',encoding='utf-8') as f:f.write(str(os.getpid()))
    try:
        with gate.exclusive('guarded_confirmation_final_gates_june_only'):
            handoff('guarded_confirmation_final_gates_fitting',True)
            np,torch,lim=gate.runtime();import core
            start=time.monotonic()
            scalers=gate.read(p['paths']['scalers.json']);center=np.array(scalers['price_center'])[0,:,0];scale=np.array(scalers['price_scale'])[0,:,0]
            q99=np.array(gate.read(p['paths']['state_thresholds.json'])['thresholds'])[1]
            feature=np.load(p['paths']['features.npy'],mmap_mode='r')
            for seed in p['seeds']:
                with np.load(TRIAL/'cache'/f'{seed}_FULL.npz',allow_pickle=False) as f, np.load(TRIAL/'cache'/f'{seed}_DLinear.npz',allow_pickle=False) as d:
                    origins=f['origins'];gate.need(len(origins)==3397 and np.array_equal(origins,d['origins']) and np.array_equal(f['truth'],d['truth']),'Final fit cache alignment')
                    last=feature[origins-1].copy()
                    raw=np.stack([f['prediction'],d['prediction'],np.broadcast_to((last[:,:,0].astype(np.float64)*scale+center)[:,:,None],f['truth'].shape)],axis=-1)
                    ex=((raw-center[None,:,None,None])/scale[None,:,None,None]).astype(np.float32)
                    y=((f['truth']-center[None,:,None])/scale[None,:,None]).astype(np.float32)
                values=last[:,:,[0,21,22]];gate.need(bool(np.isfinite(values).all() and np.isfinite(ex).all() and np.isfinite(y).all()),'Nonfinite June values')
                guard_info=dict(lower=values.min(0).tolist(),upper=values.max(0).tolist(),fields=[0,21,22],
                                price_center=center.tolist(),price_scale=scale.tolist(),train_q99=q99.tolist(),bounds_inclusive=True,
                                training_origin_count=3397,training_origin_sha256=__import__('hashlib').sha256(origins.tobytes()).hexdigest())
                for arm in p['arms']:fit(p,seed,arm,ex,y,scale,guard_info,np,torch,core,start)
                del raw,ex,y,last;gc.collect()
            feature._mmap.close()
            verify(p)
            complete=OUT/'queue/completion.json'
            models=[OUT/f'{seed}_{arm}'/'MODEL.json' for seed in p['seeds'] for arm in p['arms']]
            gate.write(complete,dict(at=gate.now(),status='six_final_gates_fitted_pending_independent_audit',fits=len(models),
                protocol_sha256=gate.sha(OUT/'PROTOCOL.json'),models={str(path):gate.sha(path) for path in models},
                elapsed_seconds=time.monotonic()-start,expert_updates=0,test_targets_read=False,independent_period_admitted=False))
            eid=event('major_milestone',complete);status(event='finite_sampling_queue_completed',event_id=eid)
            handoff('guarded_confirmation_final_gates_fit_complete_pending_audit',False)
    except BaseException as exc:
        evidence=OUT/'queue/STOP.json';gate.write(evidence,dict(at=gate.now(),error=repr(exc),saved_checkpoints_preserved=True,test_targets_read=False,automatic_restart=False))
        paused=isinstance(exc,InterruptedError);eid=None if paused else event('blocking_failure',evidence)
        status(event='user_stop' if paused else 'sampling_blocking_failure',event_id=eid,error=repr(exc))
        handoff('guarded_confirmation_final_gate_refit_blocked',False);raise
    finally:
        gate.need(lock.read_text()==str(os.getpid()),'Final fit manager ownership changed');lock.unlink()

if __name__=='__main__':
    if sys.argv[1:]==['prepare']:prepare()
    elif not sys.argv[1:]:run()
    else:raise SystemExit('Use prepare or no argument')
