"""Timestamp-only nested development windows before new source scores or fits."""
from resolve_source import *
def main():
 with c.numeric('Timestamp-only V7 coverage and forward-window registration'):
  import numpy as np
  p=c.T/'adaptive_experts_v4_20260929/panel.npz'
  pred=c.T/'spike_specialist_v7_20260930/predictions'/f'{c.SEEDS[0]}.npz'
  with np.load(p) as z:cut=z['cutoff'];avail=z['available'];orig=z['origins']
  with np.load(pred) as z:ids=z['eval_indices']
  for seed in c.SEEDS[1:]:
   with np.load(c.T/'spike_specialist_v7_20260930/predictions'/f'{seed}.npz') as z:assert np.array_equal(ids,z['eval_indices'])
  t=cut[ids];available=avail[ids].max(axis=1);days=t//86400;unique=np.unique(days)
  assert len(ids)==698 and len(unique)>=32 and np.all(np.diff(t)>0)
  windows=[]
  bounds=[17]
  for block in np.array_split(np.arange(17,len(unique)),3):bounds.append(int(block[-1])+1)
  for i,(a,b) in enumerate(zip(bounds[:-1],bounds[1:]),1):
   cal_start=unique[a-5]*86400;eval_start=unique[a]*86400
   fit=np.flatnonzero((days<unique[a-5])&(available<cal_start)&(t+3600<cal_start))
   cal=np.flatnonzero((days>=unique[a-5])&(days<unique[a])&(available<eval_start)&(t+3600<eval_start))
   ev=np.flatnonzero((days>=unique[a])&(days<=unique[b-1]))
   assert all(len(x)>0 for x in [fit,cal,ev])
   assert available[fit].max()<t[cal].min() and available[cal].max()<t[ev].min()
   windows.append(dict(id=i,fit=fit.tolist(),calibration=cal.tolist(),evaluation=ev.tolist(),
     fit_origins=len(fit),calibration_origins=len(cal),evaluation_origins=len(ev),
     dates={key:[str(np.datetime64(int(v),'D')) for v in np.unique(days[ix])] for key,ix in [('fit',fit),('calibration',cal),('evaluation',ev)]},
     max_fit_label_release=int(available[fit].max()),calibration_first_cutoff=int(t[cal].min()),
     max_calibration_label_release=int(available[cal].max()),evaluation_first_cutoff=int(t[ev].min())))
  evs=np.concatenate([np.array(w['evaluation']) for w in windows]);assert len(evs)==len(np.unique(evs))
  out=dict(at=c.now(),status='frozen_before_new_fits',rule='Use causal V7 prediction support only. First12 observed UTC issue dates fit, next5 calibrate; split remaining observed issue dates into3 contiguous nearly equal windows via numpy.array_split. Expanding fit and rolling5-date calibration. Require full horizon and all target releases strictly before next stage. Retain actual calendar gaps.',
   original_source_origins=len(orig),causal_V7_origins=len(ids),causal_V7_dates=len(unique),evaluation_origins=len(evs),evaluation_dates=len(unique)-17,
   source_panel_sha256=c.sha(p),V7_index_sha256=c.sha(pred),original_panel_indices=ids.tolist(),
   origins=orig[ids].tolist(),cutoff=t.tolist(),available=available.tolist(),windows=windows,
   source_contract_scope_clarification='FEATURE_CONTRACT preserve_full_698_evaluation means preserve original V7 evidence and all698 source-feature rows; it does not permit fitting on the same698 evaluation labels. This newly frozen forward comparison evaluates only the later observed issue dates. No claim that its error equals the original698-panel error.',
   date_semantics='UTC prediction cutoff date, not delivery date. Actual metadata contains45 unique issue dates; previous planning assumption42 failed an assertion before fits, now replaced by timestamp-only rule.',
   target_values_read=False,new_model_fits=0,scope='Already-inspected development only; not independent confirmation',V7_replaced=False)
  c.write(H/'WINDOWS.json',out)
  print(json.dumps({k:out[k] for k in ['evaluation_origins','evaluation_dates','causal_V7_origins']},ensure_ascii=False))
  print(json.dumps([{k:w[k] for k in ['id','fit_origins','calibration_origins','evaluation_origins','dates']} for w in windows],ensure_ascii=False))
if __name__=='__main__':main()
