from pathlib import Path
from datetime import datetime,timezone
import json,os,hashlib,shutil
P=Path(__file__).resolve().parent; B=P.parent.parent.parent.parent
def read(p):return json.loads(Path(p).read_text(encoding='utf-8-sig'))
def sha(p):
    h=hashlib.sha256()
    with Path(p).open('rb') as f:
        for b in iter(lambda:f.read(1048576),b''):h.update(b)
    return h.hexdigest()
def write(p,obj):
    p=Path(p);t=p.with_name('.f'+os.urandom(4).hex());t.write_text(json.dumps(obj,ensure_ascii=False,indent=2),encoding='utf-8');os.replace(t,p)
now=datetime.now(timezone.utc).isoformat()
sample=read(P/'FREE_SAMPLE.json');qa=read(P/'SAMPLE_QA.json');assert qa['passed'] and qa['node_hour_rows']==720
assert sha(P/'dam_jan01.zip')==sample['sha256'] and sample['bytes']==13649715
for old,new in [('DECISION.json','DECISION_BEFORE_FREE.json'),('QA.json','QA_BEFORE_FREE.json')]:
    assert not (P/new).exists(); shutil.copyfile(P/old,P/new)
d=read(P/'DECISION.json')
d['at']=now;d['status']='public_sample_complete_exact_archive_identity_pending'
d['free_api_sample']=dict(path=str(P/'dam_jan01.zip'),sha256=sample['sha256'],bytes=sample['bytes'],nodes=30,MCC_hours_per_node=24,MCC_rows=720,filename_and_size_match=True,archive_identity_proved=False)
d['official_archive']='Public catalogue and equivalent-named free GroupZip sample obtained. Direct S3 object metadata requires authorization; unsigned HEAD403. Free API supplies no Last-Modified/ETag. Do not infer equality from matching size.'
d['completed']+=['Downloaded one free GroupZip sample and streamed component metadata','Confirmed all30 registered nodes have24 DAM-MCC hours without duplicates','Matched file name and exact size to archive catalogue; internal ZIP timestamps precede delivery but lack timezone']
d['missing']=['Exact archive-object identity using authoritative checksum or byte comparison, and archive timestamp/availability semantics','Catalogue timestamp timezone and its relation to object metadata','Coverage and timing proof beyond the one sample, including3 absent dates and later-modified periods']
d['next']='Finish archive identity via user-approved existing AWS account: one metadata request, then at most one13.65MB object download if checksum alone is inadequate; no batch. Alternatively obtain publisher confirmation tying public GroupZip bytes to immutable archived object. No price model fit before evidence and frozen matched scope.'
for n in ['FREE_SAMPLE_PLAN.json','FREE_SAMPLE.json','FREE_GROUP_HEAD.json','SAMPLE_QA.json','dam_jan01.zip','sample_qa.py','free_sample.py','bulk_guide.pdf','bulk_native.html','bulk_client.js']:
    d['evidence'][str(P/n)]=sha(P/n)
write(P/'DECISION.json',d)
report=f'''日前拥堵历史版本补证：当前结果
更新：{now}

已完成：
• 恢复并交叉核对DAM发布时间、更正记录及官方更正政策。样例120行/24小时能关联到提前发布的报告；这只是报告关联。
• 免费查完2023-06-01至2025-05-31的官方归档目录：应有731天，列出728份日文件。缺2025-04-03、04、05。
• 284份目录的修改日期早于交付日，其余444份不满足该初筛条件。早期档案存在2024年迁移/回填时间痕迹；这不能等同于价格修改，也不能证明当年原值。284份均尚未准入。
• 已通过免费GroupZip取得2025-01-01样本（13,649,715字节）。30个注册节点×24小时的DAM拥堵分量MCC齐全，共720行，无重复、无缺漏。
• 文件名、精确字节数与官方归档目录一致；ZIP内4个分量的时间均为2024-12-31 12:11左右（ZIP不含时区）。报告54730450发布时间为2024-12-31 20:10:56 UTC；目录lastModified为31-Dec-2024 20:11:52（时区未声明）。这些是吻合线索，尚非原档逐字节一致性证明。

当前缺口：
1. 免费API未返回原始对象Last-Modified/ETag；目录没有对象校验值。需查证对象时间、版本保留语义和免费文件是否与原档一致。
2. 直接访问原始S3对象的匿名HEAD返回403，已停止，未绕过权限。官方归档下载需要自有AWS账户并由请求者承担可能的费用；免费样本本身已取得，无需为普通历史数值重复付费。
3. 一天通过不能推出全时期通过。缺失日期、较晚修改文件须逐项另证，不能因结果好坏删除日期。

下一步已缩小为一次样本身份核验：如果已有获准的AWS账户，先读取对象元数据；可验证的校验值足够时不下载，否则最多下载这一份13.65MB文件作SHA256比对。若无账户，可向发布方核实免费GroupZip与原始归档的对应关系及时间语义，询证草稿已准备但未发送。不启动约9.77GB整库下载。

尚不能保证何时取得外部权限/证明；这是原始版本证据缺口，不是本机内存或训练速度的问题。
本轮训练0次，新增盲测目标读取0次，18个V7/论文保护文件保持原哈希。本地事件监听保留；研究未完成。本轮为同一执行者程序重读和来源交叉核对，不是独立人员签字。

原始文件SHA256：{sample['sha256']}
结构核验：SAMPLE_QA.json；全时期目录：ARCHIVE_COVERAGE.json；完整决策：DECISION.json。

官方来源：
https://www.caiso.com/documents/readiness-notes-new-price-correction-summary-report-in-oasis.pdf
https://www.caiso.com/documents/presentation-release-activation-review-dame-and-edam-apr-23-2026.pdf
https://www.caiso.com/notices/new-tool-now-available-on-caiso-oasis-website
https://oasis-bulk.caiso.com/OASIS_Data_Portal_User_Guide_v3.pdf
'''
(P/'补证结果.txt').write_text(report,encoding='utf-8')
with (P/'SOURCE_REQUEST_DRAFT.txt').open('a',encoding='utf-8') as f:
    f.write('\nAdditional evidence: the free OASIS GroupZip endpoint returned the same filename and exact13,649,715-byte size. Its SHA256 is '+sample['sha256']+'. All30 registered nodes have24 MCC hours. Please confirm whether this public GroupZip is byte-identical to the archived object and what evidence establishes its first availability; filename/size alone is not assumed sufficient.\n')
hf=B/'HANDOFF.json';raw=hf.read_bytes();h=read(hf)
h['current_stage']='DAM_free_sample_complete_archive_identity_pending'
h['current_work_status']='DAM publication logs and728-file archive catalogue recovered; one free DAM sample verified30nodes x24MCC hours. Exact archive identity/time semantics pending; no new accuracy results.'
h['current_authorized_work']='Complete free source provenance inquiry. Request approval before any existing-account requester-pays archive verification; no batch downloads or new training yet.'
h['dam_vintage_20261009'].update(at=now,status=d['status'],free_sample=d['free_api_sample'],admitted=False)
h['next_action']=d['next'];h['next_bounded_action']=d['next']
assert hf.read_bytes()==raw;write(hf,h)
q=read(P/'QA.json');q.update(at=now,sample_MCC_nodes=30,sample_MCC_hours_per_node=24,sample_MCC_rows=720,free_sample_sha256=sample['sha256'],archive_identity_confirmed=False,source_admitted=False,decision_sha256=sha(P/'DECISION.json'))
write(P/'QA.json',q)
print(json.dumps(dict(status=d['status'],sample_MCC_rows=720,source_admitted=False,decision_sha256=sha(P/'DECISION.json')),ensure_ascii=False))
