"""Post-test descriptive consolidation and independent arithmetic review; no fitting."""
from pathlib import Path
from collections import defaultdict
from datetime import date
import sys, math

HERE = Path(__file__).resolve().parent
B = HERE.parent
D = B / 'h1_final_evaluation_v1_20260927'
sys.path.insert(0, str(D))
from runtime_gate import c, verify_release, commit_inventory


def main():
    freeze = verify_release()
    inventory = commit_inventory(freeze)
    result_path = D / 'TEST_RESULTS.json'
    audit = c.read(D / 'TEST_AUDIT.json')
    c.need(audit['status'] == 'passed' and audit['result_sha256'] == c.sha(result_path), 'H1 audit mismatch')
    c.need(not (HERE / 'REVIEW.json').exists(), 'Review already committed')
    with c.exclusive('Post-test profile and statistical arithmetic review; no training'):
        np, limiter = c.runtime()
        result = c.read(result_path)
        with np.load(D / 'scoring_targets.npz', allow_pickle=False) as z:
            truth, states = z['truth'], z['states']
        grouped = defaultdict(list)
        for case in freeze['cases']:
            c.guard()
            with np.load(inventory['cases'][case['id']]['prediction_path'], allow_pickle=False) as z:
                grouped[case['variant']].append(z['prediction'] - truth)
        main_rows = {r['model']: r for r in result['main_results']}
        checks = 0
        state_decomposition = {}
        def same(a, b):
            nonlocal checks
            c.need(math.isclose(float(a), float(b), rel_tol=1e-10, abs_tol=1e-9), f'Arithmetic mismatch: {a}, {b}')
            checks += 1
        for name, errors in grouped.items():
            e = np.stack(errors)
            profile = result['profiles'][name]
            for h in range(12):
                same(abs(e[:, :, :, h]).mean(), profile['horizons'][h]['MAE'])
                same(np.sqrt((e[:, :, :, h] ** 2).mean((1, 2))).mean(), profile['horizons'][h]['RMSE_mean_seed'])
            for node in range(30):
                same(abs(e[:, :, node, :]).mean(), profile['nodes'][node]['MAE'])
            ae_total, se_total = float(abs(e).sum()), float((e ** 2).sum())
            state_decomposition[name] = []
            for k in range(6):
                mask = states == k
                part = e[:, mask]
                same(abs(part).mean(), profile['states'][k]['MAE'])
                same(np.sqrt((part ** 2).mean(1)).mean(), profile['states'][k]['RMSE_mean_seed'])
                state_decomposition[name].append(dict(state=k, count=int(mask.sum()),
                    population_percent=100 * float(mask.mean()),
                    absolute_error_share_percent=100 * float(abs(part).sum()) / ae_total,
                    squared_error_share_percent=100 * float((part ** 2).sum()) / se_total))
            same(abs(e).mean(), main_rows[name]['MAE'])
            same(np.sqrt((e ** 2).mean((1, 2, 3))).mean(), main_rows[name]['RMSE_mean_seed'])

        # Separate implementation: explicit membership and multinomial-weight matrix,
        # unlike the production bincount and per-replicate ratio loop.
        days = result['calendar_days']
        keys = sorted({date.fromisoformat(d).isocalendar()[:2] for d in days})
        membership = np.array([[date.fromisoformat(d).isocalendar()[:2] == k for d in days] for k in keys], float)
        counts = np.asarray(result['daily_prediction_counts'], float)
        weekly_count = membership @ counts
        choices = np.random.default_rng(20260926).integers(len(keys), size=(2000, len(keys)))
        frequency = np.array([(choices == i).sum(1) for i in range(len(keys))], float).T
        den = frequency @ weekly_count
        full_sum = np.asarray(result['profiles']['FULL']['daily_absolute_error_sums'])
        full_rep = (frequency @ (membership @ full_sum)) / den
        pvalues = []
        for row in result['comparisons']:
            other_sum = np.asarray(result['profiles'][row['comparator']]['daily_absolute_error_sums'])
            other_rep = (frequency @ (membership @ other_sum)) / den
            delta = other_rep - full_rep
            rate = 100 * delta / other_rep
            diff = (other_sum.sum() - full_sum.sum()) / counts.sum()
            p = (1 + int(np.sum(abs(delta - diff) >= abs(diff)))) / 2001
            pvalues.append(p)
            same(diff, row['difference'])
            same(p, row['p_value_approximate'])
            for value, reference in zip(np.quantile(delta, [.025, .975]), row['difference_ci95']): same(value, reference)
            for value, reference in zip(np.quantile(rate, [.025, .975]), row['improvement_ci95']): same(value, reference)
        adjusted = [0.] * len(pvalues)
        running = 0.
        for rank, index in enumerate(sorted(range(len(pvalues)), key=lambda i: pvalues[i])):
            running = max(running, (len(pvalues) - rank) * pvalues[index])
            adjusted[index] = min(1., running)
        for p, row in zip(adjusted, result['comparisons']): same(p, row['holm_p_value'])

        full = main_rows['FULL']
        comparisons = []
        for row in result['comparisons']:
            name = row['comparator']; other = main_rows[name]
            fp = result['profiles']['FULL']; op = result['profiles'][name]
            seed_full = {r['seed']: r for r in result['seed_results'] if r['model'] == 'FULL'}
            seeds = [r for r in result['seed_results'] if r['model'] == name and r['seed'] in seed_full]
            gains = {k: 100 * (other[k] - full[k]) / other[k] for k in ('MAE','RMSE_mean_seed','near_MAE','H12_MAE')}
            comparisons.append(dict(comparator=name, comparator_MAE=other['MAE'], full_MAE=full['MAE'],
                improvements_percent=gains, primary_holm_p=row['holm_p_value'], primary_classification=row['classification'],
                nodes_with_lower_MAE=sum(a['MAE'] < b['MAE'] for a,b in zip(fp['nodes'],op['nodes'])), node_count=30,
                horizons_with_lower_MAE=sum(a['MAE'] < b['MAE'] for a,b in zip(fp['horizons'],op['horizons'])), horizon_count=12,
                months_with_lower_MAE=sum(fp['months'][m]['MAE'] < op['months'][m]['MAE'] for m in fp['months']), observed_months=len(fp['months']),
                matched_seed_MAE_gains=[dict(seed=r['seed'], improvement_percent=100*(r['MAE']-seed_full[r['seed']]['MAE'])/r['MAE']) for r in seeds]))
        europe_path = c.HERE / 'evaluation/TEST_RESULTS.json'
        europe_audit = c.read(c.HERE / 'evaluation/TEST_AUDIT.json')
        c.need(europe_audit['status'] == 'passed', 'European audit missing')
        c.write(HERE / 'REVIEW.json', dict(status='passed_profiles_and_independent_bootstrap_arithmetic',at=c.now(),
            result_sha256=c.sha(result_path), h1_audit_sha256=c.sha(D/'TEST_AUDIT.json'), europe_result_sha256=c.sha(europe_path),
            source_code_sha256=c.sha(__file__), arithmetic_checks=checks, H1=main_rows['FULL'], comparisons=comparisons,
            state_error_decomposition=state_decomposition, bootstrap_calendar_weeks=len(keys),
            statistics_scope='Predeclared approximate calendar-week bootstrap and Holm; this verifies arithmetic, not finite-sample validity of assumptions.',
            descriptive_scope='All nodes, horizons, months, states and seed directions retained. Slice counts and secondary gains are descriptive, not new significance tests.',
            review_operator='Separate implementation by same Codex operator; no independent human peer review claimed',
            fits=0, optimizer_steps=0, new_model_selection=False, frozen_outputs_modified=False,
            remaining=['Descriptive fusion/graph diagnostics and fair compute-cost summaries','Final evidence-to-claim mapping','Manuscript and figure consolidation after pause is lifted'],
            complete_research_experiment=False))
        print({'status':'passed','arithmetic_checks':checks,'review':str(HERE/'REVIEW.json')})

if __name__ == '__main__': main()
