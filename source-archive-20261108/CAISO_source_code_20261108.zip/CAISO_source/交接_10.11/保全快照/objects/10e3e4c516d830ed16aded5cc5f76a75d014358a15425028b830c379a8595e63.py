import support as s
import os,time,json,traceback
def status(**kw):s.write('STATUS.json',dict(at=s.now(),pid=os.getpid(),**kw))
def main():
 lock=s.N/'MANAGER.lock'
 with lock.open('x') as f:json.dump(dict(pid=os.getpid()),f)
 try:
  s.guard(True);p=s.verify();status(event='awaiting_exit_monitor_binding');start=time.monotonic()
  while not (s.N/'START_READY.json').exists():
   if time.monotonic()-start>55:raise TimeoutError('Exit monitor handshake missing')
   time.sleep(.2)
  import psutil
  ready=s.read(s.N/'START_READY.json');assert ready['manager_pid']==os.getpid() and psutil.pid_exists(ready['exit_monitor_pid'])
  start=time.monotonic()
  def tick(**kw):
   s.guard();elapsed=time.monotonic()-start
   if elapsed>p['total_budget_seconds']:raise TimeoutError('Finite total budget exhausted; no automatic retry')
   s.write('PROGRESS.json',dict(at=s.now(),pid=os.getpid(),elapsed_seconds=elapsed,**kw))
  with s.base.numeric('New version-bound weather information matched first-entry risk trial'):
   status(event='step_process_started',stage='source_collection',new_model_fits=0)
   import collect
   source=collect.main(tick)
   if not source['source_gate_passed']:
    s.write('DECISION.json',dict(at=s.now(),status='source_coverage_gate_failed',source=source,new_fits=0,V7_replaced=False));evidence=s.N/'DECISION.json';event='needs_analysis'
   else:
    status(event='step_process_started',stage='matched_risk_training',source_admitted_origins=source['admitted'])
    import experiment,audit
    experiment.main(tick);result=audit.main(tick);evidence=s.N/'RESULT.json';event='audited_result_ready' if result['statistical_increment_supported'] else 'needs_analysis'
  eid=s.emit(event,evidence);status(event='finite_mechanism_queue_completed',event_id=eid,evidence=str(evidence),V7_replaced=False)
 except InterruptedError as e:status(event='user_stop_before_launch',classification='user_stop',error=str(e))
 except BaseException as e:
  s.write('FAILURE.json',dict(at=s.now(),error=repr(e),traceback=traceback.format_exc(),automatic_retry=False));eid=s.emit('blocking_failure',s.N/'FAILURE.json');status(event='step_stopped_or_failed',event_id=eid,error=repr(e))
 finally:
  if s.read(lock)['pid']==os.getpid():lock.unlink()
if __name__=='__main__':main()
