from pathlib import Path
import json,hashlib,datetime,psutil,sys,os
B=Path("C:\\Users\\于阳\\CAISO_feature_fusion_rev12\\asof_retraining_branch_20260913");V=B/'phase_sampling_support_v3_20260923';A=B/'audits/sampling_support_20260923'
def read(p):return json.loads(p.read_text(encoding='utf-8-sig'))
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def put(p,d):
 with p.open('x',encoding='utf-8') as f:json.dump(d,f,ensure_ascii=False,indent=2)
sys.path.insert(0,str(V/'source'));import manager
plan=manager.verify();source_admission=manager.gate.require_mechanisms_complete()
receipts=[]
for step in plan['steps']:
 p=V/'queue/steps'/(step['id']+'.json')
 if not p.exists():break
 r=read(p);assert r['step']==step and r['exit_code']==0 and r['marker']==manager.marker(step) and r['execution_seal_sha256']==sha(V/'EXECUTION_SEAL.json')
 receipts.append({'step':step['id'],'sha256':sha(p),'marker':r['marker']})
assert len(receipts)>=4
audit=read(V/'dataset/schedule_audit.json');mathqa=read(V/'runner_math_qa.json');mathreceipt=read(V/'runner_math_execution.json')
assert audit['status']=='passed' and audit['construction_algorithm_imported'] is False and audit['all_schedule_checks_passed']
assert mathqa['status']=='passed' and mathqa['resume_exact'] and mathqa['optimizer_recipe_exact'] and mathreceipt['report_sha256']==sha(V/'runner_math_qa.json') and mathreceipt['exit_code']==0
state=read(V/'queue/status.json');cmd=state['command']
policy=cmd[cmd.index('--policy')+1];seed=int(cmd[cmd.index('--seed')+1]);var=cmd[cmd.index('--variant')+1]
checkpoint=read(V/f'runs/{policy}/backbone/{seed}_{var}/latest.json')
assert sha(B/checkpoint['path'])==checkpoint['sha256'] and checkpoint['steps']>0
workers=[]
for pid in [19200,state['child_pid'],12720,14052]:
 p=psutil.Process(pid);workers.append({'pid':pid,'created':p.create_time(),'cmdline':p.cmdline()})
assert not psutil.pid_exists(16180) and not psutil.pid_exists(6676)
lock=read(Path('D:/Desktop/数据科学_论文/研究优化_20260818/logs/NEURAL_RUN.lock'))
assert lock['pid']==state['child_pid'] and abs(psutil.Process(lock['pid']).create_time()-lock['created'])<0.01
assert Path(state['stderr']).stat().st_size==0
rows=[]
for sd in [20260813,20260814]:
 for name in ['FULL','TCN','EQUAL','CONCAT','GLOBAL','GTF','STATIC','SELF']:
  folder=B/f'stages/query/{sd}_{name}/runs/CONTROL'
  s=read(folder/'selection.json');a=read(folder/'control_audit.json')
  assert a['status']=='passed' and a['selection_sha256']==sha(folder/'selection.json') and a['selected_predictions_replayed']
  rows.append({'seed':sd,'variant':name,'selection_sha256':sha(folder/'selection.json'),'audit_sha256':sha(folder/'control_audit.json'),'scope':s['selection_scope'],'metrics':{k:s['june_metrics'][k] for k in ['mae','rmse','near_h1_4_mae','h12_mae']}})
event_ids=['mechanisms_complete_5f48f5b23527d23c5d2cb39a49a14a5b7c8cfb490273956abbbca77c5b70a2fa','sampling_blocking_failure_a897732939223f601a37b222df2b691f07b8c75d931d6ff90cbe76db207c2629']
resolution={'status':'mechanism96_audited_v2_infeasibility_resolved_in_isolated_v3_actual_training_running','at':datetime.datetime.now(datetime.timezone.utc).isoformat(),'outer_event_id':'b6869cebca0e19e0e2efc79a2472f44695ac5155c55a2a97d225e17adbebe65b','handled_inner_event_ids':event_ids,'dedup_rule':'Both mechanism completion and subsequent v2 compile failure are handled by this resolution. On duplicate delivery inspect live v3; do not retry v2, create duplicate processes or repeat notification.',
'mechanism_completion_sha256':source_admission,'mechanism96_receipts_and_markers_verified':True,'all16_dense_control_stage_metrics':rows,'numeric_stage_audits_verified':True,'common_registered284_mechanism_rescoring_still_pending':True,
'diagnosis_sha256':sha(A/'diagnosis.json'),'v2_zero_support_hours':5,'v2_failed_before_training':True,'v2_sources_and_failures_preserved':True,
'v3_protocol_sha256':sha(V/'PROTOCOL.json'),'v3_execution_seal_sha256':sha(V/'EXECUTION_SEAL.json'),'v3_sampling_audit_sha256':sha(V/'dataset/schedule_audit.json'),'v3_math_qa_sha256':sha(V/'runner_math_qa.json'),'v3_math_qa_exit_code':0,'v3_completed_preparation_receipts':receipts,
'v3_epoch_sampling':[{k:r[k] for k in ['epoch','hourly_anchors','additive_unique_origins','repeat_unique_origins','fallback_original_origins','nonhourly_added_count','optimizer_updates']} for r in audit['epochs']],
'v3_coverage':audit['coverage'],'live_state':state,'latest_checkpoint':checkpoint,'processes':workers,'shared_lock':lock,
'launch_record':str(V/'launch_83d878b3c5d6/launch.json'),'available_physical_GiB':psutil.virtual_memory().available/2**30,
'science_interpretation':'On dense June3397, FULL still does not consistently outperform GTF/GLOBAL. SELF removes cross-node messages and gives mixed seed results (S1 better all four; S2 FULL better MAE/RMSE/near but worse H12). Dynamic graph and full fusion superiority are not established; coverage and estimation error remain hypotheses.',
'next_matched_comparison':'ADDITIVE vs REPEAT at6048 updates within FULL/TCN and2seeds, then ORIGINAL at3024 on common284/dense3397/278blocks; all outcomes and protected metrics retained.',
'theory':[{'url':'https://arxiv.org/abs/2405.15124','supports':'Data size and model capacity interact; motivates coverage/sufficiency experiment, not exact thresholds or guaranteed gains.'},{'url':'https://arxiv.org/abs/1902.10486','supports':'Retaining prior examples motivates hourly protection; transfer from continual learning is a design inference.'},{'url':'https://jmlr.org/papers/v8/sugiyama07a.html','supports':'Input distribution mismatch motivates diagnosis; conditional invariance is not asserted.'}],
'review_independence_scope':'Original mechanism stages and unchanged numeric runner audited by distinct existing code; new support schedule checked by separate invariant/oracle algorithms executed by same primary operator; no second-person review asserted.',
'paper_polishing_paused':True,'heldout_targets_read':False,'complete_research_experiment':False,'periodic_model_wakeup':False}
put(A/'resolution.json',resolution)
hp=B/'HANDOFF.json';old=hp.read_bytes();h=json.loads(old.decode('utf-8-sig'));(A/'HANDOFF_before_transition.json').write_bytes(old)
h.update(status='all96_mechanisms_audited_support_v3_sampling_running',at=resolution['at'],queue_pid=19200,live_status=str((V/'queue/status.json').relative_to(B)),observed_queue_state=state)
h['mechanism_continuation'].update(status='all96_steps_completed_and_independently_audited',completed_steps=96,active_worker_pid=None,manager_exited=True,current_case=None,current_step=None,current_checkpoint=None,completion='mechanism_controls_20260920/queue/completion.json',completion_sha256=source_admission)
old_sampling=h['next_isolated_sampling_experiment']
h['superseded_sampling_v2']=dict(old_sampling,status='infeasible_five_zero_support_hours_before_training_preserved',manager_exited=True,blocking_event=event_ids[1],resolution='audits/sampling_support_20260923/resolution.json')
h['next_isolated_sampling_experiment']={'protocol':str((V/'PROTOCOL.json').relative_to(B)),'protocol_sha256':sha(V/'PROTOCOL.json'),'status':'actual_training_running_after_schedule_and_numeric_audits','training_started':True,'training_ready':True,'manager_started':True,'manager_pid':19200,'active_worker_pid':state['child_pid'],'exit_bridge_pid':12720,'live_status':str((V/'queue/status.json').relative_to(B)),'source':str((V/'source/manager.py').relative_to(B)),'scheduler_source':str((V/'source/schedule.py').relative_to(B)),'scheduler_sha256':sha(V/'source/schedule.py'),'original_hourly_samples_retained_each_epoch':2016,'added_nonhourly_samples_each_epoch':2011,'zero_support_hourly_repetitions_each_epoch':5,'models':['FULL','TCN'],'new_arms':['REPEAT','ADDITIVE'],'seeds':[20260813,20260814],'fresh_runs':8,'budget_updates_each':6048,'new_total_updates':48384,'finite_queue_steps':20,'completed_queue_steps':len(receipts),'execution_seal':str((V/'EXECUTION_SEAL.json').relative_to(B)),'execution_seal_sha256':sha(V/'EXECUTION_SEAL.json'),'independent_manager_review':str((V/'MANAGER_REVIEW.json').relative_to(B)),'independent_manager_review_sha256':sha(V/'MANAGER_REVIEW.json'),'actual_schedule_compiled':True,'actual_schedule_audit_passed':True,'actual_numeric_math_QA_passed':True,'sample_sufficiency_established':False,'common_selected_backbone_panels_pending':True,'fixed_TRAIN_per_epoch_diagnostic_curves_pending':True,'launch_record':str((V/'launch_83d878b3c5d6/launch.json').relative_to(B)),'postlaunch_verified':'audits/sampling_support_20260923/resolution.json','current_checkpoint':checkpoint,'purpose':'Coverage expansion retaining all original hours;5 unsupported rows identical across arms; no core/loss/optimizer change','review_independence_scope':resolution['review_independence_scope']}
h['event_automation'].update(watcher_pid=14052,manager_exit_bridge=str((V/'watch_manager_exit.ps1').relative_to(B)),exit_bridge_pid=12720,manager_start_utc_ticks=639257452215876518,binding='event_driven_automation/process_monitors/sampling_exit_19200_639257452215876518.status.json',additional_exit_bridges=[],retired_bridge_pids=[3600,13344])
h['event_driven_automation'].update(manager_pid=19200,status='watching_support_v3_sampling',watcher_pid=14052,at=resolution['at'])
h['latest_mechanism_completion_and_sampling_recovery']='audits/sampling_support_20260923/resolution.json'
h['handled_events']=event_ids
h['next_actions']=[
'The mechanism completion event and the v2 infeasibility event were handled together in audits/sampling_support_20260923/resolution.json. Do not retry v2 or repeat the same user notification.',
'All96 mechanism steps are completed/audited. Sampling v3 manager19200 and worker are already running; verify live status/PID creation/checkpoints and do not duplicate.',
'V3 passed actual schedule audit and numeric math QA. It retains2016 hourly anchors, adds2011 within-hour nonhour windows, repeats5 original zero-support anchors; both arms have4032 slots per epoch and6048 updates/model.',
'Complete common registered284/dense3397/balanced278-hour summaries of all original mechanism cases; preserve exact original12 registered results. Stage-level dense summaries are available but are not full common-panel evidence.',
'After the finite8-model sampling queue and audits finish, implement/run one bound common inference for12 ORIGINAL/REPEAT/ADDITIVE FULL/TCN checkpoints across284/3397/278 panels and all nodes/phases/horizons/frozen states. Same-layer backbone comparisons only.',
'Score registered fixed TRAIN diagnostic panel on all retained epoch checkpoints before declaring sufficient data.',
'Apply preregistered coverage attribution and protected performance gates; retain all mixed/negative results. Only new bounded literature-grounded changes after diagnosis.',
'Resolve third-seed scope, freeze models and finish source/data admission before heldout target access; no test-driven tuning; paper polishing remains paused.'
]
h['complete_research_experiment']=False
tmp=hp.with_name('HANDOFF.v3.pending')
with tmp.open('x',encoding='utf-8') as f:json.dump(h,f,ensure_ascii=False,indent=2)
assert hp.read_bytes()==old;os.replace(tmp,hp)
put(A/'handoff_transition_receipt.json',{'at':resolution['at'],'before_sha256':hashlib.sha256(old).hexdigest(),'after_sha256':sha(hp),'resolution_sha256':sha(A/'resolution.json')})
print(json.dumps({'status':resolution['status'],'checkpoint_updates':checkpoint['steps'],'epoch':checkpoint['epoch'],'physical_GiB':resolution['available_physical_GiB'],'actual_sampling_audit_passed':True,'actual_math_qa_passed':True,'coverage':audit['coverage'],'paths':{'resolution':str(A/'resolution.json'),'handoff':str(hp)}},ensure_ascii=False))
