"""Original frozen deployment combiner with registered anchor/path substitutions. No fitting."""
def combine(p,x,outputs,anchor):
    m4=legacy('confirm_v4',B/'adaptive_experts_v4_20260929','worker.py')
    m5=legacy('confirm_v5',B/'adaptive_experts_v5_20260929','worker.py')
    m7=legacy('confirm_v7',V7,'worker.py');feat7=legacy('confirm_v7_features',V7,'prepare.py')
    sc=read(p['training_paths']['scalers.json']);th=read(p['training_paths']['state_thresholds.json']);scale=np.array(sc['price_scale'])[0,:,0];center=np.array(sc['price_center'])[0,:,0];q=np.array(th['thresholds'])
    last=np.array(x[:,-1]);raw=last[:,:,0]*scale+center;reg=m7.regime(last,sc,th);gbx=dense(last)
    with np.load(A4/'panel.npz') as z:dev={k:z[k] for k in z.files}
    fold=read(B/'adaptive_experts_v4_20260929/FOLDS.json')[-1];assert fold['id']==3
    support=dev['last'][fold['train']][:,:,[0,21,22]];support_lo=support.min((0,1));support_hi=support.max((0,1));current=last[:,:,[0,21,22]]
    allowed=~np.any((current<support_lo)|(current>support_hi),-1)
    oi=[];ni=[];fx=[];px=[];cx=[];dur=[]
    for i in range(len(x)):
        nodes=np.flatnonzero(reg[i]==2)
        if not len(nodes):continue
        hh=np.array(x[i]);f=m5.shape_features(hh[-72:,nodes,0],hh[-1,nodes],nodes,sc,q[1]);a,b,d=feat7.new_features(hh,nodes,sc,th)
        fx.append(f);px.append(np.column_stack([f,a]));cx.append(np.column_stack([f,a,b]));dur.append(d);oi.extend([i]*len(nodes));ni.extend(nodes.tolist())
    oi=np.array(oi,int);ni=np.array(ni,int);replay_records=[];allfiles={}
    if len(oi):fx=np.concatenate(fx);px=np.concatenate(px);cx=np.concatenate(cx);dur=np.concatenate(dur)
    with np.load(A7/'H1_features.npz') as z:hfeat={k:z[k] for k in z.files}
    with np.load(A5/'H1_features.npz') as z:oldfeat={k:z[k] for k in z.files}
    temps=read(V7/'TRAIN_CALIBRATION.json')['rows']
    for seed in SEEDS:
        pulse(stage='V7_fixed_deployment',seed=seed)
        full=outputs[(seed,anchor)];persist=np.broadcast_to(raw[:,:,None],full.shape)
        gb=load(B/'adaptive_experts_v2_20260929/models'/f'{seed}_GB_DELTA.pkl')['model'].predict(gbx).reshape(full.shape)*scale.mean()+raw[:,:,None]
        tar=m4.tar_predict(load(A4/'models'/f'{seed}_TAR_POOL.pkl'),last,sc,reg)
        experts=np.stack([full,outputs[(seed,'DLinear')],persist,gb,tar],-1)
        X=np.column_stack([gbx,((full-persist)/scale[None,:,None]).ravel(),((experts[...,1]-full)/scale[None,:,None]).ravel()]).astype(np.float32)
        functions=np.stack([load(functional_path(seed,anchor,k))['model'].predict(X).reshape(full.shape) for k in range(2)],-1)
        # Freeze the last development fold's completed calibration state; no new-period labels.
        with np.load(fold_path(seed,anchor)) as z:oldfunctions=z['functions']
        oldfull=development_anchor(seed,anchor)
        cal=m4.Calibration();maxready=0
        for j in sorted(fold['calibration']+fold['evaluation']):
            for h in range(12):
                ready=int(dev['available'][j,h]);now=min(p['origins_utc_seconds'])-300;assert ready<=now
                residual=(dev['truth'][j,:,h]-oldfull[j,:,h])[:,None]-oldfunctions[j,:,h]
                cal.observe((j,h),int(dev['cutoff'][j]),ready,now,dev['observable_regime'][j],h,residual);maxready=max(maxready,ready)
        bias,count=cal.bias(min(p['origins_utc_seconds'])-300);groups=reg[:,:,None]*3+np.arange(12)[None,None,:]//4
        mean=functions[...,0]+bias[groups,0];median=functions[...,1]+bias[groups,1]
        w,_=m7.correction_weights(experts,mean,median,allowed[:,:,None]&(count[groups]>=3));base=(w*experts).sum(-1)
        # Base-only control falls back to FULL at active extremes, isolating specialist addition.
        base[reg==2]=full[reg==2]
        methods={c['variant']:outputs[(seed,c['variant'])] for c in p['models'] if c['seed']==seed}
        methods.update(BASE_FROZEN=base,PERSISTENCE=persist,DAILY_SEASONAL=np.asarray(x[:,:12,:,0],float).transpose(0,2,1)*scale[None,:,None]+center[None,:,None])
        with np.load(A5/'models'/f'{seed}_distributions.npz') as z:quant=z['quantiles'];prior=z['prior'];oldmus=z['mus']
        mu=np.empty((len(oi),12,3));mdelta=0.
        for k in range(3):
            model=load(A5/'models'/f'{seed}_destination{k}.pkl')['model']
            if len(oi):mu[:,:,k]=model.predict(m5.expand(fx)).reshape(-1,12)
            expected=oldmus[oldfeat['origin_index'],oldfeat['node'],:,k]
            got=model.predict(m5.expand(oldfeat['X'])).reshape(-1,12);d=float(abs(got-expected).max());assert d<1e-10;mdelta=max(mdelta,d)
        for variant,features in [('CONTEXT',cx),('DURATION',px),('FIXED',None)]:
            if variant=='FIXED':prob=np.broadcast_to(prior,(len(oi),12,3))
            else:
                preds={};hp={};row=next(r for r in temps if r['seed']==seed and r['variant']==variant)
                for task in ('hazard','postexit'):
                    temp=next(r['temperature'] for r in row['fit_log'] if r['task']==task)
                    model=load(A7/'models'/f'{seed}_{variant}_{task}.pkl')['model']
                    if len(oi):preds[task]=m7.temperature(model.predict_proba(m7.expand(features,dur)),temp)
                    hf=hfeat['context' if variant=='CONTEXT' else 'price'];hp[task]=m7.temperature(model.predict_proba(m7.expand(hf,hfeat['duration'])),temp)
                hprob,_=m7.survival_probabilities(hp['hazard'][:,1].reshape(-1,12),hp['postexit'].reshape(-1,12,3))
                with np.load(A7/'models'/f'{seed}_{variant}_probabilities.npz') as z:expected=z['probabilities'][hfeat['origin_index'],hfeat['node']]
                d=float(abs(hprob-expected).max());assert d<1e-10
                replay_records.append(dict(seed=seed,variant=variant,h1_probability_max_error=d,amplitude_max_error=mdelta))
                if len(oi):prob,_=m7.survival_probabilities(preds['hazard'][:,1].reshape(-1,12),preds['postexit'].reshape(-1,12,3))
            pred=base.copy()
            if len(oi):
                ratio=np.repeat(q[0,ni]/q[1,ni],12);sign=np.repeat(np.sign(raw[oi,ni]-np.array(th['center'])[ni]),12)
                am,aq=m7.mixture(mu.reshape(-1,3),quant,prob.reshape(-1,3),ratio,sign)
                am=am.reshape(-1,12)*q[1,ni,None]+np.array(th['center'])[ni,None];aq=aq.reshape(-1,12)*q[1,ni,None]+np.array(th['center'])[ni,None]
                f=full[oi,ni];chosen,weights=m7.specialist(f,am,aq)
                # Separately expressed bounded correction verifies the output algebra.
                u=am-f;v=aq-f;independent=f+np.where(u*v>0,.75*np.sign(u)*np.minimum(abs(u),abs(v)),0.)
                assert np.allclose(chosen,independent,atol=1e-10,rtol=1e-12)
                pred[oi,ni]=chosen
            name={'CONTEXT':'V7_FROZEN','DURATION':'V7_DURATION','FIXED':'V7_FIXED'}[variant];methods[name]=pred
            assert np.array_equal(pred[reg!=2],base[reg!=2])
        path=ART/'predictions'/f'{seed}_all.npz';save(path,origins=p['origins_utc_seconds'],**methods);allfiles[str(path)]=gate.sha(path)
        write(HERE/'deployment_state'/f'{seed}.json',dict(seed=seed,fold=3,pooled_support_lower=support_lo.tolist(),pooled_support_upper=support_hi.tolist(),calibration_bias=bias.tolist(),calibration_days=count.tolist(),last_feedback_publication=maxready,new_test_feedback=False))
    write(HERE/'COMBINER_AUDIT.json',dict(status='passed',specialist_replays=replay_records,active_node_origins=len(oi),nonextreme_preservation=True,independent_correction_arithmetic=True,forecast_files=allfiles))
