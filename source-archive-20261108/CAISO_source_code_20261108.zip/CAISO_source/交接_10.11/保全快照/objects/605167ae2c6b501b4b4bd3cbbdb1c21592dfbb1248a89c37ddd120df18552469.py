"""Finite supplemental queue: synthetic QA, TRAIN/June LASSO, scalar audit."""
import argparse,os,sys,subprocess,uuid,json
import gate
Q=gate.HERE/'queue'
def status(event,**kw):
    value=dict(event=event,at=gate.now(),pid=os.getpid(),**kw)
    path=Q/'events'/(uuid.uuid4().hex+'.json');gate.write(path,value);gate.write(Q/'status.json',value,True);return path

def notify(kind,path):
    eid='caiso_baselines_v2_'+kind+'_'+gate.sha(path)
    body=dict(schema='caiso_research_event_v1',event_id=eid,event=kind,evidence_path=str(path),complete_research_experiment=False)
    dest=gate.ROOT/'event_driven_automation/inbox'/(eid+'.json')
    if dest.exists():gate.need(gate.read(dest)==body,'Event collision')
    else:
        tmp=dest.with_name('tmp_'+uuid.uuid4().hex+'.tmp')
        with tmp.open('x',encoding='utf-8') as f:json.dump(body,f,ensure_ascii=False,indent=2);f.flush();os.fsync(f.fileno())
        tmp.rename(dest)
    return eid

def main(args):
    gate.verify();gate.predecessor()
    import psutil
    owner=dict(pid=os.getpid(),created=psutil.Process().create_time(),token=uuid.uuid4().hex)
    Q.mkdir(parents=True,exist_ok=True);lock=Q/'QUEUE.lock';child=None
    with lock.open('x',encoding='utf-8') as f:json.dump(owner,f);f.flush();os.fsync(f.fileno())
    plan=[('synthetic_QA','numeric_qa.py',[],gate.HERE/'numeric_qa.json','passed'),
          ('reuse_converged','reuse_converged.py',[],gate.HERE/'reuse_audit.json','passed'),
          ('LASSO_fit','lear_runner.py',['fit'],gate.HERE/'lear/completion.json','completed_pending_independent_formula_audit'),
          ('LASSO_audit','lear_runner.py',['audit'],gate.HERE/'lear/numeric_audit.json','passed'),
          ('naive','naive.py',[],gate.HERE/'naive/completion.json','completed'),
          ('prediction_audit','audit_predictions.py',[],gate.HERE/'prediction_audit.json','passed'),
          ('summary','summarize.py',[],gate.HERE/'summary.json','finite_baselines_audited')]
    try:
        blocks=list((Q/'blocks').glob('*.json'))
        if blocks:gate.need(args.resume_after_event is not None and (Q/'blocks'/(args.resume_after_event+'.json')).exists(),'Reviewed recovery event required')
        for step,script,argv,marker,expected in plan:
            gate.verify();gate.guard(True);gate.need(not gate.LOCK.exists(),'Another numeric worker active')
            rp=Q/'steps'/(step+'.json')
            if rp.exists():
                r=gate.read(rp);gate.need(r['exit_code']==0 and r['seal_sha256']==gate.sha(gate.HERE/'PREPARATION_SEAL.json') and r['marker_sha256']==gate.sha(marker),'Prior step changed');continue
            gate.need(not marker.exists(),'Marker without exit receipt; recover by explicit review')
            command=[sys.executable,'-X','utf8',str(gate.HERE/script)]+argv
            out=Q/'logs'/(step+'_'+owner['token']+'.stdout.log');err=out.with_name(out.name.replace('stdout','stderr'));out.parent.mkdir(parents=True,exist_ok=True)
            with out.open('xb') as fo,err.open('xb') as fe:
                child=subprocess.Popen(command,cwd=gate.ROOT,stdout=fo,stderr=fe,creationflags=getattr(subprocess,'CREATE_NO_WINDOW',0))
                status('step_process_started',step=step,child_pid=child.pid,stdout=str(out),stderr=str(err));code=child.wait()
            gate.need(code==0,f'{step} exit{code}: inspect {err}')
            gate.need(gate.read(marker)['status']==expected,'Marker status mismatch')
            gate.write(rp,dict(step=step,at=gate.now(),exit_code=code,seal_sha256=gate.sha(gate.HERE/'PREPARATION_SEAL.json'),marker=str(marker),marker_sha256=gate.sha(marker)))
        done=Q/'completion.json'
        gate.write(done,dict(status='three_CAISO_baselines_completed_and_audited',at=gate.now(),receipts={f.name:gate.sha(f) for f in (Q/'steps').glob('*.json')},
            battery_real_evaluation_completed=False,heldout_targets_read=False,complete_research_experiment=False))
        eid=notify('audited_result_ready',done);status('finite_sampling_queue_completed',event_id=eid,completion_sha256=gate.sha(done));return 0
    except Exception as exc:
        paused=False
        try:gate.boundary()
        except InterruptedError:paused=True
        path=status('user_stop' if paused else 'step_stopped_or_failed',reason=repr(exc),child_pid=child.pid if child else None)
        if not paused:
            eid=notify('blocking_failure',path);gate.write(Q/'blocks'/(eid+'.json'),dict(evidence=str(path),at=gate.now()));status('step_stopped_or_failed',event_id=eid,reason=repr(exc))
        return 3 if paused else 2
    finally:
        if child and child.poll() is None:child.wait()
        gate.need(gate.read(lock)==owner,'Queue owner changed');gate.write(Q/'lock_releases'/(owner['token']+'.json'),dict(owner=owner,at=gate.now()));lock.unlink()
if __name__=='__main__':
    p=argparse.ArgumentParser();p.add_argument('--resume-after-event');raise SystemExit(main(p.parse_args()))
