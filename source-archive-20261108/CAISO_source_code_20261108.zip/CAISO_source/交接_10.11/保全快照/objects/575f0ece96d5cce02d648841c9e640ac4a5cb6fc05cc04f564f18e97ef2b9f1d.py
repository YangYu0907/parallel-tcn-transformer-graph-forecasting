"""Pure new-branch FiLM math; original 36-task BB/MNP/Armijo equations. No file/data/weight readers."""

import copy
import numpy as np
import torch

SETTINGS = {'max_updates': 30, 'max_backtracks': 16, 'initial_step': 1.0, 'shrink': 0.5, 'armijo': 0.0001, 'bb_alpha_min': 0.001, 'bb_alpha_max': 1000.0, 'mnp_max_major': 5000, 'mnp_max_minor': 5000, 'mnp_gap_rtol': 1e-08, 'mnp_certificate_rtol': 1e-06, 'mnp_lstsq_rcond': 1e-13}

TASKS=tuple((year,group,metric) for year in (2023,2024,2025) for group in (3,4,5) for metric in ('mae','mse','near','h12'))

AGE_LOOKUP=(np.log1p(np.arange(289,dtype=np.float64))/np.log(289.)).astype(np.float32)

def masks(cache):
    for year,group,metric in TASKS:
        m=(np.asarray(cache['codes'])==group)&(cache['years']==year)[:,None,None]
        if metric=='near': m[:,:,4:]=False
        if metric=='h12': m[:,:,:11]=False
        w=m*cache['multiplicity'][:,None,None]
        yield metric,w,w.sum(dtype=np.float64)

def losses(pred,cache):
    err=pred-cache['truth']; values=[]; counts=[]
    for metric,w,n in masks(cache):
        if n<=0: raise RuntimeError('Empty risk task')
        values.append(float(((err**2 if metric=='mse' else abs(err))*w).sum()/n)); counts.append(n)
    return np.array(values),np.array(counts)

def metric(pred,truth):
    err=pred-truth; horizon=abs(err).mean((0,1))
    return dict(mae=float(abs(err).mean()),rmse=float(np.sqrt((err**2).mean())),h12_mae=float(horizon[-1]),near_h1_4_mae=float(horizon[:4].mean()),mae_by_horizon=horizon.tolist())

def acceptable(old,new,gradient,delta):
    linear=gradient@delta; bound=old+SETTINGS['armijo']*linear
    return bool(np.isfinite(new).all() and (linear<0).all() and (new<=bound).all()),linear,bound

def curvature(before,gradient,initial,previous_before=None,previous_gradient=None):
    before=np.asarray(before,np.float64); gradient=np.asarray(gradient,np.float64); initial=np.asarray(initial,np.float64)
    if before.ndim!=1 or gradient.shape!=(len(initial),len(before)) or not np.isfinite(before).all() or not np.isfinite(gradient).all() or not np.isfinite(initial).all() or (initial<=0).any(): raise RuntimeError('Invalid curvature inputs')
    if (previous_before is None)!=(previous_gradient is None): raise RuntimeError('Incomplete secant history')
    if previous_before is None:
        return dict(mode='initial_identity',alpha=np.ones(len(initial)).tolist(),raw_alpha=np.ones(len(initial)).tolist(),dot=None,secant_norm_squared=None)
    pb=np.asarray(previous_before,np.float64); pg=np.asarray(previous_gradient,np.float64)
    if pb.shape!=before.shape or pg.shape!=gradient.shape or not np.isfinite(pb).all() or not np.isfinite(pg).all(): raise RuntimeError('Invalid previous secant inputs')
    s=before-pb; ss=float(s@s)
    if not np.isfinite(ss) or ss<=0: raise RuntimeError('Zero/nonfinite actual secant displacement')
    y=(gradient-pg)/initial[:,None]; dot=y@s; raw=np.full(len(initial),SETTINGS['bb_alpha_min'])
    positive=dot>0; negative=dot<0
    raw[positive]=dot[positive]/ss; raw[negative]=np.linalg.norm(y[negative],axis=1)/np.sqrt(ss)
    if not np.isfinite(raw).all(): raise RuntimeError('Nonfinite curvature')
    alpha=np.clip(raw,SETTINGS['bb_alpha_min'],SETTINGS['bb_alpha_max'])
    return dict(mode='per_risk_secant',alpha=alpha.tolist(),raw_alpha=raw.tolist(),dot=dot.tolist(),secant_norm_squared=ss)

def vector(film): return np.concatenate([v.detach().cpu().numpy().ravel().astype(np.float64) for v in film.parameters()])

def assign(film,values):
    pos=0
    with torch.no_grad():
        for value in film.parameters():
            n=value.numel(); value.copy_(torch.tensor(values[pos:pos+n].reshape(value.shape),dtype=value.dtype)); pos+=n
    if pos!=len(values): raise RuntimeError('Parameter vector shape')

def years_from_ns(ns):
    return (np.asarray(ns).astype('datetime64[ns]').astype('datetime64[Y]').astype(np.int64)+1970).astype(np.int16)

def normalizer(cache):
    total=0.; first=np.zeros(32); second=np.zeros(32)
    for i in range(0,len(cache['z']),64):
        z=np.asarray(cache['z'][i:i+64],np.float64); m=np.broadcast_to(cache['mask'][i:i+64,:,None],z.shape[:-1]); w=np.broadcast_to(cache['multiplicity'][i:i+64,None,None],z.shape[:-1])[m].astype(np.float64); v=z[m]
        total+=w.sum(); first+=(v*w[:,None]).sum(0); second+=(v*v*w[:,None]).sum(0)
    if total<=0: raise RuntimeError('Empty normalization fit')
    mean=first/total; std=np.sqrt(np.maximum(second/total-mean*mean,0)); std=np.where(std<=1e-8,1,std)
    return mean.astype(np.float32),std.astype(np.float32),total

def age_features(x,scale,center,q):
    if x.ndim!=4 or x.shape[1:]!=(288,30,29) or q.shape!=(2,30): raise ValueError('Duration historical schema')
    history=(x[:,:,:,0].double()*scale+center-center).abs()
    lengths=torch.stack([torch.cumprod((history>threshold).flip(1).to(torch.int16),dim=1).sum(1) for threshold in q],dim=-1)
    return torch.as_tensor(AGE_LOOKUP,device=x.device)[lengths]

def active(x,scale,center,q99):
    # Match original USD reconstruction/threshold, including float64 rounding.
    last=x[:,-1,:,0].double()*scale+center
    return (last-center).abs()>q99


class Readout(torch.nn.Module):
    def __init__(self, backbone, mean, std, seed):
        super().__init__()
        from models.factory import build_film
        self.head = copy.deepcopy(backbone.head).eval().requires_grad_(False)
        self.film = build_film(seed, mean, std)
        if sum(p.numel() for p in self.film.parameters()) != 3232:
            raise RuntimeError('FiLM parameter count changed')
    def forward(self,z,mask,age):
        return self.head(self.film(z,mask,age))


def predict(model,cache,boundary=None):
    pos=0; result=[]
    scale=np.asarray(cache['metadata']['scale'])[None,:,None]
    center=np.asarray(cache['metadata']['center'])[None,:,None]
    model.eval()
    with torch.inference_mode():
        for size in cache['sizes']:
            if boundary is not None: boundary()
            size=int(size)
            if size<1 or size>4: raise RuntimeError('Original batch size changed')
            z=torch.from_numpy(np.array(cache['z'][pos:pos+size]))
            m=torch.from_numpy(np.array(cache['mask'][pos:pos+size]))
            age=torch.from_numpy(np.array(cache['age'][pos:pos+size]))
            result.append(model(z,m,age).numpy().astype(np.float64)*scale+center)
            pos+=size
    if pos!=len(cache['z']): raise RuntimeError('Original batch coverage')
    pred=np.concatenate(result)
    normal=np.broadcast_to(~cache['mask'][:,:,None],pred.shape)
    if not np.array_equal(pred[normal],cache['native'][normal]):
        raise RuntimeError('Ordinary prediction changed')
    return pred


def gradients(model,cache,resume=None,progress=None,boundary=None):
    """Original F64 32-origin accumulation; construct risk masks per chunk.

    Denominators and arithmetic are unchanged, while avoiding 36 full cached
    weight arrays. A persisted partial sum resumes at an exact chunk boundary.
    """
    model=copy.deepcopy(model).double()
    parameters=list(model.film.parameters())
    counts=np.array([n for _,_,n in masks(cache)],np.float64)
    if (counts<=0).any(): raise RuntimeError('Empty gradient task')
    result=np.zeros((len(TASKS),3232)); values=np.zeros(len(TASKS)); offset=0
    if resume is not None:
        offset=int(resume['offset'])
        result=np.asarray(resume['gradient'],np.float64).copy()
        values=np.asarray(resume['losses'],np.float64).copy()
        if (result.shape!=(36,3232) or values.shape!=(36,) or
            not np.array_equal(counts,resume['counts']) or offset<0 or offset>len(cache['z']) or
            (offset!=len(cache['z']) and offset%32) or
            not np.isfinite(result).all() or not np.isfinite(values).all()):
            raise RuntimeError('Invalid resumed full-risk gradient accumulator')
    scale=torch.tensor(cache['metadata']['scale'],dtype=torch.float64)[None,:,None]
    center=torch.tensor(cache['metadata']['center'],dtype=torch.float64)[None,:,None]
    for i in range(offset,len(cache['z']),32):
        if boundary is not None: boundary()
        end=min(i+32,len(cache['z']))
        z=torch.tensor(np.array(cache['z'][i:end]),dtype=torch.float64)
        mask=torch.tensor(np.array(cache['mask'][i:end]))
        age=torch.tensor(np.array(cache['age'][i:end]),dtype=torch.float64)
        err=model(z,mask,age)*scale+center-torch.tensor(np.array(cache['truth'][i:end]),dtype=torch.float64)
        for k,(year,group,metric_name) in enumerate(TASKS):
            selected=(np.asarray(cache['codes'][i:end])==group)&(cache['years'][i:end]==year)[:,None,None]
            if metric_name=='near': selected[:,:,4:]=False
            if metric_name=='h12': selected[:,:,:11]=False
            weight=selected*cache['multiplicity'][i:end,None,None]
            loss=((err.square() if metric_name=='mse' else err.abs())*torch.tensor(weight,dtype=torch.float64)).sum()/counts[k]
            values[k]+=float(loss.detach())
            gs=torch.autograd.grad(loss,parameters,retain_graph=k<len(TASKS)-1)
            result[k]+=np.concatenate([v.numpy().ravel() for v in gs])
        if progress is not None:
            progress(dict(offset=end,gradient=result,losses=values,counts=counts))
        if boundary is not None: boundary()
    return result,values,counts


def direction(gradient,initial,previous_before=None,previous_gradient=None,before=None):
    from film_mnp import cone
    curve=curvature(before,gradient,initial,previous_before,previous_gradient)
    return curve,cone(gradient,initial*np.asarray(curve['alpha']),SETTINGS)
