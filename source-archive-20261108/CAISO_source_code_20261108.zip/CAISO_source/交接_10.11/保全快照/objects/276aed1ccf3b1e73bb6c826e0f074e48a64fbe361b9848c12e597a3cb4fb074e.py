"""Scheduled official-model synthetic QA and separate actual TRAIN/June adapter checks."""
import argparse,copy,json,time
import external_train as r

def synthetic():
    r.preparation_check()
    with r.exclusive("external_official_models_synthetic_QA"):
        runtime,limiter=r.numeric_runtime();torch,np=r.torch,r.np
        import adapter as a
        from official_models import make_model,vendor_receipt
        checks=[]
        def check(ok,label):
            if not ok:raise AssertionError(label)
            checks.append(label)
        generator=np.random.default_rng(913)
        x=generator.normal(size=(1,288,30,29)).astype(np.float32)
        for f in a.GLOBAL_FEATURES:x[:,:,:,f]=x[:,:,0:1,f]
        hist=generator.normal(size=(1,24,6)).astype(np.float32)
        future=generator.normal(size=(1,12,6)).astype(np.float32)
        q=np.empty((1,12,6,25),np.float32);q[:,:,:,:24]=hist.transpose(0,2,1)[:,None];q[:,:,:,24]=future
        price,marks=a.arrays_for_model(x,"iTransformer-X",q)
        recovered=np.empty_like(x);recovered[:,:,:,0]=price
        for j,f in enumerate(a.NODE_NONPRICE):recovered[:,:,:,f]=marks[:,:,j*30:(j+1)*30]
        for j,f in enumerate(a.GLOBAL_FEATURES):recovered[:,:,:,f]=marks[:,:,420+j,None]
        check(np.array_equal(x,recovered),"All29 historicalfields reconstruct exactly")
        check(np.array_equal(marks[:,::12,434:440],hist) and np.array_equal(marks[:,::24,440:],future),"Allpast/forecastvalues reconstruct exactly")
        def rejected(fn):
            try:fn()
            except (RuntimeError,ValueError):return True
            return False
        bad=x.copy();bad[0,0,1,8]+=1
        check(rejected(lambda:a.arrays_for_model(bad,"iTransformer-X",q)),"Nodevaryingglobalfield rejected")
        bad=x.copy();bad[0,0,0,19]=np.nan
        check(rejected(lambda:a.arrays_for_model(bad,"DLinear")),"UnmaterializedNaNage rejected evenforprice-onlyadapter")
        check(rejected(lambda:a.arrays_for_model(x,"iTransformer-X")),"MissingQUERY rejectsX")
        badq=q.copy();badq[0,1,0,0]+=1
        check(rejected(lambda:a.arrays_for_model(x,"iTransformer-X",badq)),"InconsistenthistoricalQUERYdescriptors rejected")
        check(rejected(lambda:a.arrays_for_model(x,"unknown",q)),"Unregisteredmodel rejected")
        for name in ("DLinear","iTransformer-X"):
            profile=r.read(r.PROTOCOL)["fixed_profiles"][name]
            torch.manual_seed(512);model=make_model(name,profile).eval()
            p=torch.tensor(price,requires_grad=True);mark=torch.tensor(marks,requires_grad=True)
            out=model(p,mark)
            check(out.shape==(1,30,12) and bool(torch.isfinite(out).all()),name+"finite outputshape")
            if name=="DLinear":
                padded=torch.cat([p[:,:1].repeat(1,12,1),p,p[:,-1:].repeat(1,12,1)],dim=1)
                trend=torch.nn.functional.avg_pool1d(padded.transpose(1,2),25,stride=1).transpose(1,2)
                direct=model.core.Linear_Seasonal((p-trend).transpose(1,2))+model.core.Linear_Trend(trend.transpose(1,2))
                check(torch.equal(out,direct),"NativeDLinear MA25+twolinear exactformula")
                with torch.no_grad():check(torch.equal(model(p,mark),model(p,mark*9)),"DLinear nohidden covariateuse")
            else:
                with torch.no_grad():direct=model.core(p.detach(),mark.detach(),None,None).transpose(1,2)
                check(torch.equal(out.detach(),direct),"iTransformer officialcore wrapperparity")
                check(len(model.core.encoder.attn_layers)==2,"PrimaryiTransformer actually2layers")
            out.square().mean().backward()
            check(p.grad is not None and bool(torch.isfinite(p.grad).all()),name+"finitepricegradient")
            check(all(v.grad is not None and bool(torch.isfinite(v.grad).all()) for v in model.parameters() if v.requires_grad),name+"allactiveparametersconnected")
            if name=="iTransformer-X":
                check(mark.grad is not None and float(mark.grad[:,:,:434].abs().sum())>0 and float(mark.grad[:,:,434:].abs().sum())>0,"HistoricalandQUERYcovariatesbothconnected")
            before={k:v.clone() for k,v in model.state_dict().items()};rng_before=torch.get_rng_state().clone()
            with torch.no_grad():model(p.detach(),mark.detach())
            check(all(torch.equal(v,model.state_dict()[k]) for k,v in before.items()) and torch.equal(rng_before,torch.get_rng_state()),name+"frozeninference noRNG/statemutation")
        vendor_receipt()
        import compile_gate as gate
        result=dict(status="passed",sources=r.source_paths(),official_formula_parity=True,
            covariate_gradients_verified=True,adapter_lossless_verified=True,synthetic_only=True,
            checks=checks,check_count=len(checks),runtime=runtime,resources=gate.check_working_set(),
            actual_market_values_read=False,Q3_targets_read=False,test_2026_targets_read=False,
            formal_optimizer_steps=0)
        r.write(r.MODEL_QA,result);return result

def data_check(name):
    core,query_binding=r.core_metadata(name,20260813)
    with r.exclusive("external_actual_TRAIN_June_adapter_QA_"+name):
        runtime,limiter=r.numeric_runtime();np=r.np
        import adapter as a
        data=r.make_data(name);core_data=data.core;phase_values={}
        comparisons=[]
        for e in range(1,31):
            data.set_epoch(e);origins=data.origins("train")
            direct=np.load(core_data.paths[f"epoch{(e-1)%6+1}_origins.npy"],allow_pickle=False)
            if not np.array_equal(origins,direct) or len(origins)!=2016:raise RuntimeError("Actualphaseorigin mismatch")
            if e<=6:phase_values[e]=origins.copy()
            elif not np.array_equal(origins,phase_values[(e-1)%6+1]):raise RuntimeError("Actualphase6to7wrap mismatch")
        # Probe boundaries in eachsourcephase and June; allvalues remain insideTRAIN/June.
        for e in range(1,7):
            data.set_epoch(e)
            cases=[("train",np.array([0,1007,2015],np.int64))]
            if e==6:cases.append(("june",np.array([0,141,283],np.int64)))
            for part,index in cases:
                x,y=core_data.batch(part,index,with_target=True)
                price,marks,target=data.batch(part,index,name,with_target=True)
                if not np.array_equal(price,x[:,:,:,0]) or not np.array_equal(target,y):raise RuntimeError("Coreprice/targetparity")
                if name=="iTransformer-X":
                    expected=np.concatenate([x[:,:,:,f] for f in range(1,29) if f not in a.GLOBAL_FEATURES]+[x[:,:,0,:][:,:,a.GLOBAL_FEATURES]],axis=-1)
                    if not np.array_equal(marks[:,:,:434],expected):raise RuntimeError("Historicalfieldloss")
                    q=data.query.covariates(part,index)
                    if not np.array_equal(marks[:,::12,434:440],q[:,0,:,:24].transpose(0,2,1)) or not np.array_equal(marks[:,::24,440:],q[:,:,:,24]):
                        raise RuntimeError("QUERY descriptorloss")
                origins=data.origins(part)[index]
                for j,o in enumerate(origins):
                    pubs=core_data.publications[o-288:o]
                    cutoff=core_data.times[o-1]
                    if np.any(pubs<=0) or np.any(pubs>cutoff):raise RuntimeError("Unavailablehistorypublication")
                    age=np.clip((cutoff-pubs)/60/core_data.caps,0,1).astype(np.float32)
                    if not np.array_equal(x[j,:,:,19:21],np.broadcast_to(age[:,None,:],(288,30,2))):raise RuntimeError("Actualoriginageoverlay differs")
                comparisons.append(dict(epoch=e,part=part,origin_indices=index.tolist(),origins=origins.tolist()))
        original=np.load;opened=[]
        def spy(path,*args,**kwargs):
            opened.append(str(path));return original(path,*args,**kwargs)
        np.load=spy
        try:
            _,_,y=data.batch("june",np.array([0],np.int64),name,with_target=False)
        finally:np.load=original
        if y is not None or str(core_data.paths["target_scaled.npy"]) in opened:raise RuntimeError("Target-freeinference openedY")
        if len(data.origins("june"))!=284:raise RuntimeError("Junepopulation changed")
        result=dict(status="passed",model=name,sources=r.source_paths(),
            dataset_manifest_sha256=core["dataset_manifest_sha256"],query_binding=query_binding,
            actual_train_june_parity=True,all_phase_origins_verified=True,target_free_inference_verified=True,
            asof_age_overlay_verified=True,actual_market_values_read=True,
            read_scope="TRAIN/June only; no fitting or neural forward",probes=comparisons,epochs_cycled=30,
            Q3_targets_read=False,test_2026_targets_read=False,formal_optimizer_steps=0,
            independent_review_still_required=True,runtime=runtime)
        r.write(r.ROOT/"audits"/("data_"+name+".json"),result);return result

def main():
    p=argparse.ArgumentParser();p.add_argument("action",choices=("synthetic","data"));p.add_argument("--model",choices=("DLinear","iTransformer-X"),default="DLinear");a=p.parse_args()
    print(json.dumps(synthetic() if a.action=="synthetic" else data_check(a.model),ensure_ascii=True))
if __name__=="__main__":main()
