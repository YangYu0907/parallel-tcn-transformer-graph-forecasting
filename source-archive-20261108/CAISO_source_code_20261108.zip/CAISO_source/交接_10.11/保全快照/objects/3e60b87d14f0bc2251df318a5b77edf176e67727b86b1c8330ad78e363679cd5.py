"""Actual twelve parent states and disposable first-tail-update parity."""
import copy,json,sys,gc
import gate
def main():
 with gate.exclusive('budget_parent_qa'):
  np,torch,lim=gate.runtime()
  import train
  train.np=np;train.torch=torch
  # No original seals or checkpoints are modified.
  parent_seal=gate.read(gate.PARENT/'ADAPTER_LOCK.json')
  for p,d in parent_seal['bindings'].items():gate.need(gate.sha(gate.inside(p))==d,'Inherited binding changed')
  from compiled_data import CompiledData
  from model_io import build,explicit
  data=CompiledData(gate.V/'dataset/ADDITIVE/manifest.json');limits=gate.read(data.paths['context_limits.json'])['limits']
  original=gate.load('unchanged_prefix_update',gate.V/'source/train.py');original.torch=torch;original.np=np
  rows=[];shuffle_hash={}
  for c in gate.prepared_cases():
   gate.guard();path=gate.inside(c['terminal_checkpoint'])
   gate.need(gate.sha(path)==c['terminal_sha256'],'Terminal hash')
   saved=torch.load(path,map_location='cpu',weights_only=False)
   gate.need(saved['identity']==c['parent']['identity'] and saved['runtime']==train.runtime_stamp(),'Parent identity/runtime')
   gate.need(saved['scope']=='backbone_only' and saved['progress']['epoch']==6 and saved['progress']['steps']==6048 and saved['progress']['phase']=='epoch_complete','Terminal cursor')
   m=build(c['variant'],c['seed'],limits);m.load_state_dict(saved['state_dict'],strict=True);m.eval()
   opt=train.optimizer(m);opt.load_state_dict(saved['optimizer']);rng=np.random.default_rng(c['seed'])
   train.rng_set(saved['rng'],rng);gate.need(all(g['lr']==.0001 for g in opt.param_groups),'Terminal LR')
   order=rng.permutation(4032);sha=__import__('hashlib').sha256(order.tobytes()).hexdigest()
   if c['seed'] in shuffle_hash:gate.need(shuffle_hash[c['seed']]==sha,'Acrossmodel slot shuffle differs')
   shuffle_hash[c['seed']]=sha
   pred_path=gate.inside(saved['progress']['epochs'][-1]['prediction'])
   expected=np.load(pred_path,allow_pickle=False)[:24];zero_diff=formula_diff=0.
   with torch.no_grad():
    for start in range(0,24,4):
     x,y=data.batch('june',np.arange(start,start+4),with_target=False);gate.need(y is None,'Targetfree prefix QA')
     tx=torch.from_numpy(x);p=m(tx)['prediction'];p2=explicit(m,tx,c['variant'])
     usd=p.numpy().astype(np.float64)*data.scale[None,:,None]+data.center[None,:,None]
     zero_diff=max(zero_diff,float(np.max(np.abs(usd-expected[start:start+4]))))
     formula_diff=max(formula_diff,float((p-p2).abs().max()))
   gate.need(zero_diff==0 and formula_diff<=1e-9,'Prefix/formula differs')
   # One disposable TRAIN update, original versus new expression, with identical RNG.
   data.set_epoch(1);x,y=data.batch('train',order[:4]);tx=torch.from_numpy(x);ty=torch.from_numpy(y)
   m.train();peer=copy.deepcopy(m).train();oo=train.optimizer(peer);oo.load_state_dict(copy.deepcopy(saved['optimizer']))
   train.rng_set(saved['rng'],np.random.default_rng());train.update(m,opt,tx,ty)
   train.rng_set(saved['rng'],np.random.default_rng());original.update(peer,oo,tx,ty)
   gate.need(train.fingerprint(m)==train.fingerprint(peer),'First continuation update differs')
   for i,v in opt.state_dict()['state'].items():
    for k,t in v.items():gate.need(torch.equal(t,oo.state_dict()['state'][i][k]),'Optimizer moment differs')
   gate.need(all(float(v['step'])==6049 for v in opt.state_dict()['state'].values()),'Optimizer counter reset')
   rows.append(dict(case=c['id'],terminal_sha256=c['terminal_sha256'],prefix_origins=24,prefix_max_difference=zero_diff,
    independent_formula_difference=formula_diff,first_tail_update_bit_exact=True,optimizer_counter=6049,epoch7_shuffle_sha256=sha))
   del saved,m,peer,opt,oo;gc.collect()
   print(json.dumps(dict(event='parent_qa',case=c['id'],status='passed')),flush=True)
  gate.write(gate.HERE/'parent_qa.json',dict(status='passed',at=gate.now(),cases=rows,disposable_train_updates_per_parent=2,
   formal_training_started=False,heldout_targets_read=False,sources={gate.rel(p):gate.sha(p) for p in gate.HERE.glob('*.py')}))
  print(json.dumps(dict(status='passed',cases=len(rows),prefix_origins=24*len(rows))))
if __name__=='__main__':main()
