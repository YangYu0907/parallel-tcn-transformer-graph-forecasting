"""Finite direct event-probability experiment; immutable V7 point outputs."""
from pathlib import Path
import os,sys,json,time,pickle,importlib.util,warnings
N=Path(__file__).resolve().parent
F=N.parent/'four_arm_03'
spec=importlib.util.spec_from_file_location('bound_fourarm_parent',F/'pilot.py')
parent=importlib.util.module_from_spec(spec);spec.loader.exec_module(parent)
c=parent.c
import numpy as np
from scipy.special import softmax,logsumexp
from scipy.optimize import minimize_scalar

def write(name,obj):c.write(N/name,obj)
def read(name):return c.read(N/name)
def guard(launch=False):
    for key in ['STOP_REQUESTED','STOP_REQUESTED.json']:
        if (N/key).exists():raise InterruptedError('Local user stop')
    return parent.guard(launch)
def save(path,**kw):c.npz_save(path,**kw)
def dump(path,obj):
    path.parent.mkdir(parents=True,exist_ok=True)
    tmp=path.with_suffix('.tmp')
    with tmp.open('wb') as f:pickle.dump(obj,f,protocol=5)
    os.replace(tmp,path)
def load(path):
    with path.open('rb') as f:return pickle.load(f)
def labels(d):
    y=np.zeros(len(d['truth']),dtype=np.int64)
    y[d['truth']<d['threshold_lo']]=1
    y[d['truth']>d['threshold_hi']]=2
    return y
def temperature(logits,y):
    def loss(t):
        z=logits/t
        return float(np.mean(logsumexp(z,axis=1)-z[np.arange(len(y)),y]))
    res=minimize_scalar(loss,bounds=(.25,4.),method='bounded',options={'xatol':1e-6,'maxiter':100})
    assert res.success and np.isfinite(res.fun)
    return float(res.x)
def fit_model(X,y,fit,cal,seed):
    from sklearn.linear_model import LogisticRegression
    from sklearn.exceptions import ConvergenceWarning
    assert np.array_equal(np.unique(y[fit]),[0,1,2])
    model=LogisticRegression(C=1.,solver='lbfgs',max_iter=500,tol=1e-4,random_state=seed,class_weight=None)
    with warnings.catch_warnings(record=True) as ws:
        warnings.simplefilter('always',ConvergenceWarning)
        model.fit(X[fit],y[fit])
    if any(issubclass(w.category,ConvergenceWarning) for w in ws):
        raise RuntimeError('Fixed500iteration logistic did not converge; no automatic extension')
    t=temperature(model.decision_function(X[cal]),y[cal])
    return model,t
def verify():
    parent.verify()
    pr=read('PROTOCOL.json')
    for path,h in pr['bindings'].items():assert c.sha(path)==h,path
    return pr
def qa():
    rng=np.random.default_rng(2718);X=rng.normal(size=(240,5));y=np.tile(np.arange(3),80)
    fit=np.arange(240)<120;cal=(np.arange(240)>=120)&(np.arange(240)<180)
    m,t=fit_model(X,y,fit,cal,17)
    y2=y.copy();y2[180:]=(y2[180:]+1)%3
    m2,t2=fit_model(X,y2,fit,cal,17)
    p=softmax(m.decision_function(X)/t,axis=1)
    assert np.array_equal(m.coef_,m2.coef_) and np.array_equal(m.intercept_,m2.intercept_) and t==t2
    assert np.allclose(p.sum(1),1) and (p>0).all()
    assert np.allclose(m.predict_proba(X),softmax(m.decision_function(X),axis=1))
    assert np.allclose(softmax((m.decision_function(X)+37)/t,axis=1),p)
    assert np.allclose(-np.log(p[np.arange(len(y)),y]),logsumexp(m.decision_function(X)/t,axis=1)-(m.decision_function(X)/t)[np.arange(len(y)),y])
    write('QA.json',dict(at=c.now(),status='passed',synthetic_only=True,checks=6,
        future_labels_leave_fits_and_calibration_unchanged=True,proper_probability_simplex=True,
        point_outputs_untouched=True,real_data_fits=0))
def register():
    guard(True);assert not (N/'PROTOCOL.json').exists()
    parent.verify();assert c.read(F/'AUDIT.json')['status']=='passed'
    with c.numeric('Direct event probability prefit and synthetic QA'):
        qa();support=[]
        for w in [1,2,3]:
            guard();d=parent.prepare_data(c.SEEDS[0],w,'new');y=labels(d)
            for part in ['fit','cal','evaluate']:
                support.append(dict(window=w,part=part,cells=int(d[part].sum()),
                    class_support=[dict(label=i,cells=int((d[part]&(y==i)).sum()),dates=len(np.unique(d['days'][d[part]&(y==i)]))) for i in range(3)]))
            assert len(np.unique(y[d['fit']]))==3
        write('PREFIT.json',dict(at=c.now(),support=support,method='Metadata/support only; no new result ranking or model fitting'))
    paths=[N/'risk_model.py',N/'manager.py',N/'audit.py',N/'QA.json',N/'PREFIT.json',
        F/'PROTOCOL.json',F/'RESULT.json',F/'AUDIT.json',F/'SUMMARY.json',F/'CLOSEOUT.json',F/'CAP_DIAGNOSIS.json',
        parent.H/'SOURCE_AUDIT.json',parent.H/'WINDOWS.json',parent.H/'FEATURE_CONTRACT.json',
        c.FIRST/'CONFIRMATION_ADMISSION_STATUS.json',c.B/'mechanism_repair_v18_20260930/SOURCE_ADMISSION_FOLLOWUP.json']
    protocol=dict(at=c.now(),status='registered_before_any_real_classifier_fit',
        user_authorization='2026-10-04 explicit request: 请你继续实验，给我一个符合我要求的结果. Authorizes this one new finite diagnostic, not universal-gain claims or altering the closed four-arm result.',
        hypothesis='Direct event classification can test whether quantile-derived tail probability extraction misses useful signal from admitted flexible-ramp awards.',
        scope='Known development428origins,28UTCissue dates,30nodes,12horizons,3seeds. Same fit/calibration/evaluation windows as four_arm_03. Not independent confirmation.',
        G2='Not admitted: previously read CAISOH1/September and Europe2016; Europe2017 version/DST/three-market mapping unresolved. No new target access.',
        candidate='N: calibrated direct three-class logistic with new information',
        controls=dict(O='matched logistic old information',C='existing new-information quantile-derived probabilities',A='existing old-information quantile-derived probabilities',K='fit-only nodewise three-class frequencies with add-one smoothing'),
        labels='Low below fit-only nodeq01;high above fit-only nodeq99;otherwise normal. Same thresholds as parent. Not equivalent to all original S2/S5 labels; both definitions are reported separately.',
        point_policy='V7 predictions byte-equivalent throughout; no correction, no mean/median switching. Event risk head is distinct from interval CDF. No change in WIS/interval coverage is claimed.',
        learner=dict(class_name='LogisticRegression',C=1.,solver='lbfgs',max_iter=500,tol=1e-4,class_weight=None,temperature_bounds=[.25,4.],
            calibration='Single positive temperature by natural-frequency multiclass logloss on existing held chronological calibration block. No tuning on evaluation.'),
        seeds=c.SEEDS,windows=[1,2,3],information=['old','new'],max_real_classifier_fits=18,
        budget_seconds=3600,hyperparameter_grid=False,automatic_extension=False,
        transformations='Identical parent robust fit-only scaling and clipping; old and new input definitions inherited unchanged.',
        acceptance='N pooled low/high Brier and logloss each nonworse than O,C,K; strictly lower signed-average Brier than O and C; at least2seed signed-average Brier improvements vsC; per-window signed-average Brier nonworse thanC; eachsignedendpoint>=5issue dates. FixedV7 point preservation required. Failure closes this head; no price correction is launched.',
        statistics='One12test Holm family:N vsO,C,K crossed with low/high Brier/logloss. Paired2000resamples of7-calendar-day buckets within window; seed-mean cell scores; real gaps preserved. Exploratory only.',
        diagnostics='All3windows,seeds,horizons,nodes,original6states; AP,ROC,10%alarm threshold and reliability bins descriptive only. No selector uses future state.',
        successful_next_stage='No automatic price intervention. If risk gate passes, register a separately matched magnitude experiment after inspecting feasibility; fresh confirmation still required.',
        sources=[dict(url='https://www.sciencedirect.com/science/article/pii/S0360544222003206',use='Energy2022 event probability with logistic and market variables. Publisher indexed abstract/introduction verified; direct fulltext403. No CAISO performance guarantee.'),
            dict(url='https://proceedings.mlr.press/v70/guo17a.html',use='ICML2017 held-out temperature calibration. Original study is not this EPF model; current extension is empirical.')],
        core_elements_retained=['dynamicGNN','TCN','Transformer','parallelbranches','adaptivefeaturefusion','originalhead'],
        V7_replaced=False,new_test_targets_read=False,protected_files=18,bindings={str(x):c.sha(x) for x in paths})
    write('PROTOCOL.json',protocol)
    print(json.dumps(dict(status='frozen',max_fits=18,resources=guard(True))),flush=True)
def run_case(seed,window,info,tick):
    case=f'w{window}_{seed}_{info}';out=N/'fits'/case;done=out/'DONE.json'
    if done.exists():
        z=c.read(done);assert z['protocol_sha256']==c.sha(N/'PROTOCOL.json')
        for f,h in z['outputs'].items():assert c.sha(f)==h
        return
    tick(stage='fit',case=case);d=parent.prepare_data(seed,window,info);y=labels(d)
    model_path=out/'model.pkl'
    if model_path.exists():
        artifact=load(model_path);assert artifact['protocol_sha256']==c.sha(N/'PROTOCOL.json')
        model,t=artifact['model'],artifact['temperature']
    else:
        model,t=fit_model(d['X'],y,d['fit'],d['cal'],seed)
        dump(model_path,dict(model=model,temperature=t,protocol_sha256=c.sha(N/'PROTOCOL.json')))
    tick(stage='predict',case=case)
    ev=d['evaluate'];logits=model.decision_function(d['X'][ev]);prob=softmax(logits/t,axis=1)
    # Reuse exactly the parent's fixed-point probability baseline.
    path=F/'fits'/case/('C.npz' if info=='new' else 'A.npz')
    ck=c.read(path.parent/'COMPLETE.json');assert c.sha(path)==ck['outputs'][str(path)]
    with np.load(path) as z:
        q=z['q'][ev];point=z['point'][ev]
    assert np.array_equal(point,d['point'][ev])
    low=parent.distribution.cdf_numpy(q,d['risk_lo'][ev]);high=1-parent.distribution.cdf_numpy(q,d['risk_hi'][ev])
    qp=np.column_stack([1-low-high,low,high]);assert qp.min()>=-1e-12
    nodes=d['node'][ev];prior=np.empty((30,3))
    for k in range(30):
        counts=np.bincount(y[d['fit']&(d['node']==k)],minlength=3).astype(float)+1
        prior[k]=counts/counts.sum()
    payload={key:d[key][ev] for key in ['truth','h','node','state','days','origin','point','threshold_lo','threshold_hi']}
    payload.update(y=y[ev],logits=logits,p=prob,p_raw=softmax(logits,axis=1),p_cdf=qp,p_clim=prior[nodes],window=np.full(ev.sum(),window))
    save(out/'out.npz',**payload)
    write(str(Path('fits')/case/'DONE.json'),dict(at=c.now(),case=case,temperature=t,n_iter=model.n_iter_.tolist(),
        protocol_sha256=c.sha(N/'PROTOCOL.json'),outputs={str(x):c.sha(x) for x in [model_path,out/'out.npz']}))

def losses(prob,y):
    out={}
    for side,j in [('low',1),('high',2)]:
        lab=(y==j).astype(float);p=np.clip(prob[:,j],1e-12,1-1e-12)
        out[side+'_brier']=(prob[:,j]-lab)**2
        out[side+'_logloss']=-lab*np.log(p)-(1-lab)*np.log1p(-p)
    return out
def parts(d):
    yield 'overall',np.ones(len(d['y']),bool)
    for w in [1,2,3]:yield f'window{w}',d['window']==w
    for h in range(12):yield f'H{h+1}',d['h']==h
    for s in range(6):yield f'S{s}',d['state']==s
    for node in range(30):yield f'node{node}',d['node']==node
def score(tick):
    from sklearn.metrics import average_precision_score,roc_auc_score
    data={};rows=[];diagnostics=[]
    for seed in c.SEEDS:
        allinfo={}
        for info in ['old','new']:
            payload=[]
            for window in [1,2,3]:
                path=N/'fits'/f'w{window}_{seed}_{info}'/'out.npz'
                with np.load(path) as z:payload.append({k:z[k] for k in z.files})
            allinfo[info]={k:np.concatenate([a[k] for a in payload]) for k in payload[0]}
        old,new=allinfo['old'],allinfo['new']
        for key in ['truth','origin','h','state','point','y','p_clim']:assert np.array_equal(old[key],new[key])
        d=new
        for arm,prob in [('N',new['p']),('O',old['p']),('C',new['p_cdf']),('A',old['p_cdf']),('K',new['p_clim'])]:
            ll=losses(prob,d['y']);data[(arm,seed)]={**ll,**{k:d[k] for k in ['days','window','h','y']}}
            for part,m in parts(d):
                if m.any():rows.append(dict(seed=seed,arm=arm,part=part,cells=int(m.sum()),dates=len(np.unique(d['days'][m])),**{k:float(v[m].mean()) for k,v in ll.items()}))
            for side,j in [('low',1),('high',2)]:
                yy=(d['y']==j);pr=prob[:,j];alarm=pr>=.1
                bins=[]
                for lo,hi in zip(np.linspace(0,1,11)[:-1],np.linspace(0,1,11)[1:]):
                    m=(pr>=lo)&((pr<hi) if hi<1 else pr<=hi)
                    bins.append(dict(lo=float(lo),hi=float(hi),cells=int(m.sum()),mean_probability=float(pr[m].mean()) if m.any() else None,event_rate=float(yy[m].mean()) if m.any() else None))
                diagnostics.append(dict(seed=seed,arm=arm,side=side,positive_cells=int(yy.sum()),positive_dates=len(np.unique(d['days'][yy])),
                    AP=float(average_precision_score(yy,pr)),ROC=float(roc_auc_score(yy,pr)),alarm_threshold=.1,
                    hits=int((alarm&yy).sum()),false_alarms=int((alarm&~yy).sum()),misses=int((~alarm&yy).sum()),
                    original_S2_mean_high_probability=float(prob[d['state']==2,2].mean()),original_S5_mean_low_probability=float(prob[d['state']==5,1].mean()),
                    reliability=bins))
        tick(stage='score',seed=seed)
    summary=[]
    for arm in ['N','O','C','A','K']:
        for part in sorted(set(x['part'] for x in rows)):
            rr=[x for x in rows if x['arm']==arm and x['part']==part]
            assert len(rr)==3
            summary.append(dict(arm=arm,part=part,cells=rr[0]['cells'],dates=rr[0]['dates'],**{k:float(np.mean([x[k] for x in rr])) for k in losses(np.ones((2,3))/3,np.array([0,1]))}))
    ref=data[('N',c.SEEDS[0])];keys,gi=np.unique(np.column_stack([ref['window'],ref['days']//7]),axis=0,return_inverse=True)
    rng=np.random.default_rng(20261005);draws=[]
    for _ in range(2000):
        ids=np.concatenate([rng.choice(np.flatnonzero(keys[:,0]==w),size=int((keys[:,0]==w).sum()),replace=True) for w in [1,2,3]])
        draws.append(np.bincount(ids,minlength=len(keys)))
    draws=np.asarray(draws);counts=np.bincount(gi,minlength=len(keys));tests=[]
    for ctrl in ['O','C','K']:
        for endpoint in ['low_brier','high_brier','low_logloss','high_logloss']:
            delta=np.mean([data[(ctrl,s)][endpoint]-data[('N',s)][endpoint] for s in c.SEEDS],axis=0)
            sums=np.bincount(gi,weights=delta,minlength=len(keys));bs=(draws@sums)/(draws@counts)
            pv=min(1.,2*min((1+int((bs<=0).sum()))/2001,(1+int((bs>=0).sum()))/2001))
            tests.append(dict(candidate='N',control=ctrl,endpoint=endpoint,benefit=float(delta.mean()),CI95=np.quantile(bs,[.025,.975]).tolist(),p=pv,blocks=len(keys)))
    last=0
    for rank,i in enumerate(np.argsort([x['p'] for x in tests])):
        last=max(last,min(1.,(len(tests)-rank)*tests[i]['p']));tests[i]['p_holm']=last
    def row(arm,part='overall'):return next(x for x in summary if x['arm']==arm and x['part']==part)
    checks=[]
    def ck(name,val):checks.append(dict(name=name,passed=bool(val)))
    for ctrl in ['O','C','K']:
        for side in ['low','high']:
            for loss in ['brier','logloss']:
                k=side+'_'+loss;ck(f'N {k} retained vs{ctrl}',row('N')[k]<=row(ctrl)[k]+1e-12)
    for ctrl in ['O','C']:ck(f'N signed average Brier improves vs{ctrl}',sum(row('N')[s+'_brier'] for s in ['low','high'])<sum(row(ctrl)[s+'_brier'] for s in ['low','high']))
    ck('atleast2seeds signedaverage Brier improvevsC',sum(sum(data[('N',s)][k].mean() for k in ['low_brier','high_brier'])<sum(data[('C',s)][k].mean() for k in ['low_brier','high_brier']) for s in c.SEEDS)>=2)
    for window in [1,2,3]:ck(f'window{window} signedaverage Brier retainedvsC',sum(row('N',f'window{window}')[k] for k in ['low_brier','high_brier'])<=sum(row('C',f'window{window}')[k] for k in ['low_brier','high_brier'])+1e-12)
    for j in [1,2]:ck(f'class{j} evaluatedpositive dates>=5',len(np.unique(ref['days'][ref['y']==j]))>=5)
    write('ALL_RESULTS.json',rows);write('SUMMARY.json',summary);write('STATISTICS.json',tests);write('DIAGNOSTICS.json',diagnostics)
    result=dict(at=c.now(),screen_passed=all(x['passed'] for x in checks),checks=checks,overall={a:row(a) for a in ['N','O','C','A','K']},
        point_predictions_changed=False,point_improvement_not_claimed=True,V7_replaced=False,independent_confirmation=False,new_test_targets_read=False,
        scope='428known development origins,28UTCissue dates,3seeds; mean metrics. Risk probabilities only; not an improved full distribution or spike amplitude result.')
    write('RESULT.json',result)
    write('SCORING_BINDINGS.json',{str(N/f):c.sha(N/f) for f in ['ALL_RESULTS.json','SUMMARY.json','STATISTICS.json','DIAGNOSTICS.json','RESULT.json']})
    return result
if __name__=='__main__':register()
