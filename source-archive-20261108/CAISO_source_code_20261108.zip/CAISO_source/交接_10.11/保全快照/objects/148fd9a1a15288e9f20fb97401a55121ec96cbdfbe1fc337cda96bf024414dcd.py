"""Write all directions from the sealed results; no selection or training."""
from pathlib import Path
import json,hashlib,os
R=Path(__file__).resolve().parent;W=R.parent;Z=W.parent
def read(p):return json.loads(p.read_text(encoding='utf-8-sig'))
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
r=read(W/'RESULT.json');a=read(W/'AUDIT.json')
assert r['audit_sha256']==sha(W/'AUDIT.json') and a['passed']
def table(metrics):
    lines=['模型\t方向\tBrier\tLog loss\tPrecision%\tRecall%\tTP\tFP\tFPR%\tAP']
    for arm,values in metrics.items():
        for sign,m in values.items():
            lines.append(f"{arm}\t{sign}\t{m['brier']:.9f}\t{m['logloss']:.9f}\t{100*m['precision']:.5f}\t{100*m['recall']:.5f}\t{m['TP']}\t{m['FP']}\t{100*m['FPR']:.5f}\t{m['AP']}")
    return lines
lines=['天气信息：时间前缀与固定物理分组对照结果（2026-10-09）',
'范围：同一已暴露开发面板，2025年1—5月、369910个起点-节点对、151个日期；2个扩展时间前缀。不是独立盲测。',
'标签数：上涨1422对，下跌116对；相关节点/起点不能当作独立尖峰事件。',
'工程恢复：Windows临时路径超过260字符；已做进程内短临时文件名修复。原方案/原失败/检查点均保留，恢复仅完成剩余3个模型，共4个新拟合、2个复用模型。',
'审核：84项指标不同公式重算通过、51个三日块、2000次重采样、8个预定比较的Holm校正；18个保护文件哈希未变。审核代码复算与训练同一操作者，不冒称独立人员审核。',
'结论：GROUPED候选未过预定门槛；滚动COARSE有局部下跌概率收益，未同时解决双向尖峰识别。无价格修正接入，无V7替换，无新测试目标读取。','',
'全部面板（HISTORY/COARSE/GROUPED均按各自时间前缀更新；FROZEN_*沿用原模型）：']
lines += table(r['aggregate'])
for fold,arms in r['results'].items():
    lines+=['',f'时间段 {fold}']+table({k:v['metrics'] for k,v in arms.items()})
for month,arms in r['all_months'].items():
    lines+=['',f'月份 {month}（全部月份完整保留）']+table(arms)
lines+=['','预定探索性比较：差值为候选损失减对照损失，负值较好；不能因未校正区间不含零就宣称多重校正后显著。']
for v in r['statistics']:
    lines.append(f"{v['candidate']} vs {v['control']} {v['sign']} {v['metric']}: difference={v['difference']:.10g}, CI95={v['CI95']}, raw_p={v['p']:.6f}, Holm_p={v['exploratory_Holm_p']:.6f}")
c=r['aggregate']['COARSE'];f=r['aggregate']['FROZEN_COARSE']
lines += ['', '事实与待检验原因：',
f"滚动COARSE下跌logloss降低{100*(1-c['down']['logloss']/f['down']['logloss']):.3f}%，Holm p=0.031984；Brier降低{100*(1-c['down']['brier']/f['down']['brier']):.3f}%，Holm p=0.097951。不能将前者推广为所有概率指标均显著改善。",
'下跌TP从38到40，FP从6461到5768；上涨TP从308到309，FP从3174到3577。时间更新没有消除干预代价冲突。',
'分组聚合可能丢失局地信息、概率关系可能随时期变化、下跌有效事件稀少；本对照未分别识别这些原因，不能把猜测写成物理因果结论。',
'下一步：停止此分组候选及同面板的阈值/月份搜索，保留COARSE为未确认信息对照。先对日前拥堵/约束数据做限定的历史版本与来源核验。仅在准入证据成立后注册 HISTORY vs HISTORY+DAM、COARSE vs COARSE+DAM 的同信息、同预算前缀对照；上涨/下跌均完整报告。',
'收益与代价：复用当前天气缓存与对照，避免再下载天气或盲目扩大神经网络；新增拥堵信息可能更有节点区分度，但历史修订版本与30节点覆盖可能无法核实。来源合法也不保证预测有效。未通过准入时不训练、也不将当前下载时间当作历史发布时间。',
'文献依据：',
'Cawley & Talbot (JMLR,2010): https://jmlr.org/papers/v11/cawley10a.html — 有限验证集上的反复模型选择会引入选择偏差；本次结果仍属于探索性证据。',
'Lim et al. (IJF,2021), Temporal Fusion Transformers: https://doi.org/10.1016/j.ijforecast.2021.03.012 — 输入选择与门控的建模动机，不保证本研究分组策略有效。',
'CAISO价格更正报告：https://www.caiso.com/library/price-correction-reports — 2024年10月后更正汇总转入OASIS；当前历史查询不能直接视为当时已发布的原始值。',
'研究整体未完成；动态图稳定性、尖峰完整系统的独立确认及相应消融仍须证据。正文润色保持暂停。']
path=W/'本轮完整结果.txt';path.write_text('\n'.join(lines)+'\n',encoding='utf-8')
print(path)
