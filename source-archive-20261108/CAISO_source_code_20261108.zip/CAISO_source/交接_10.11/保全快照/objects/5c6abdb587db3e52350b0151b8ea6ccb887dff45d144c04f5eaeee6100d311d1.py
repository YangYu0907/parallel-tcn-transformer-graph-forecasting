import hashlib
import json
import os
from datetime import datetime
from pathlib import Path

A = Path(r'C:\Users\于阳\CAISO_V7_成功实验归档_20261002')
B = A / '研究资料/CAISO_feature_fusion_rev12/asof_retraining_branch_20260913'
O = A / '修补总复盘_20261004'
now = datetime.now().astimezone().isoformat()

def write_json(p, value):
    tmp = p.with_name(p.name + '.tmp')
    tmp.write_text(json.dumps(value, ensure_ascii=False, indent=2) + '\n', encoding='utf-8')
    os.replace(tmp, p)

plan = {
    'at': now,
    'scope': 'Historical synthesis requested by user; no new training or target release',
    'retained_point_model': 'V7 unchanged',
    'registry': str(O / '修补路线登记.json'),
    'report': str(O / '综合复盘与下一步.txt'),
    'priority_order': [
        {'order': 1, 'action': 'Use historical trial registry to deduplicate each proposed experiment',
         'new_model_fits': 0},
        {'order': 2, 'action': 'Close evidence mapping for already completed fair-input and component-ablation experiments; seek independent-data admission for already frozen anchored probability candidate',
         'new_model_fits': 0, 'test_targets_must_remain_sealed_until_admission_and_freeze': True},
        {'order': 3, 'action': 'Audit only compatibility and event-coverage gaps in the existing 22935-origin/116-date chronological library and source inventory; reuse prior oracle and routing diagnostics',
         'new_model_fits': 0, 'must_not_rebuild_existing_library_or_inspect_sealed_targets': True},
        {'order': 4, 'action': 'Choose at most one new point-price hypothesis only after new evidence identifies information or representation absent from prior trials',
         'status': 'conditional_not_launched', 'compute_budget_must_be_registered_before_execution': True},
        {'order': 5, 'action': 'Freeze complete matched comparisons and score genuinely independent admitted data once; otherwise retain V7 and finish existing evidence package',
         'status': 'admission_pending'}
    ],
    'reopening_requirements': [
        'Identify the closest existing trial and its preserved outcome',
        'Specify a material change in forecast-time information, representation or capacity rather than a renamed gate',
        'Provide evidence for incremental forward skill and a matched control that isolates the change',
        'Fix task, panel, parent model, availability contract, deployment semantics and statistical unit',
        'Declare development/calibration/confirmation separation and finite compute/stop rules',
        'Separate positive direction versus original baseline, non-regression versus V7, and uncertainty/support requirements'
    ],
    'not_novel_without_new_evidence': [
        'onset/recovery/persistence split or a same-information event classifier',
        'TAR/GB expert expansion or cross-node event memory',
        'natural-frequency calibration, temperature/cap relaxation, fixed scalar shrinkage',
        'horizon ID, same frozen-backbone temporal readout, fixed blending grid',
        'same top-k/static-dynamic mixture, channel attention or sigmoid renamed from two-logit softmax',
        'PCGrad on the previously closed configuration',
        'retraining the six frozen anchored-probability recipes',
        'generic rolling calibration presented as never implemented'
    ],
    'teacher_issue_status': {
        'graph_cross_task_advantage': 'matched evidence exists; stable advantage unresolved',
        'input_fairness': 'specified price-only FULL/iTransformer/DLinear experiment completed; scope limited',
        'V7_component_ablations': '12 variants and targeted refits completed; necessity differs by module',
        'spike_amplitude': 'unresolved; occurrence and interval gains are different claims',
        'probabilistic_forecasting': 'implemented; frozen candidate independent confirmation pending'
    },
    'resources': {'single_numeric_worker': True, 'start_memory_GiB': 5,
                  'runtime_memory_GiB': 4, 'scheduled_model_wakeups': False,
                  'existing_local_event_watcher': 'preserve', 'new_worker_launched': False},
    'guardrails': ['Retain all positive and negative comparisons', 'No posthoc metric-wise output switching',
                   'No merging different panels into a best-version leaderboard',
                   'No manuscript change or V7 promotion during this review']
}
write_json(O / 'NEXT_ACTIONS.json', plan)

# Preserve the complete prior handoff before adding a current, authoritative pointer.
hpath = B / 'HANDOFF.json'
prior = hpath.read_bytes()
h = json.loads(prior.decode('utf-8-sig'))
backup = O / ('HANDOFF_before_review_' + datetime.now().strftime('%Y%m%d_%H%M%S_%f') + '.json')
backup.write_bytes(prior)
pointer = {'at': now, 'report': plan['report'], 'plan': str(O / 'NEXT_ACTIONS.json'),
           'registry': plan['registry'], 'source_count': 69, 'trial_family_count': 42,
           'new_fits': 0, 'new_test_targets_read': False,
           'previous_handoff_backup': str(backup),
           'decision': 'Review complete. Reuse existing evidence and frozen candidates; require material new evidence before another point-model search.'}
h['historical_repair_review_20261004'] = pointer
h['current_authorized_work'] = 'Historical repair review completed at user request. V7 retained. Existing fair-input, ablation and frozen probability evidence reconciled. No new model launched.'
h['next_actions'] = [x['action'] for x in plan['priority_order']]
h['next_action'] = plan['priority_order'][1]['action']
h['last_updated_at'] = now
write_json(hpath, h)

# Verify source provenance and the prior protected-file hashes; no model inference.
def sha(p):
    d = hashlib.sha256()
    with open(p, 'rb') as f:
        for block in iter(lambda: f.read(1024 * 1024), b''):
            d.update(block)
    return d.hexdigest()

checks = json.loads((O / '复盘核验.json').read_text(encoding='utf-8'))
assert len(checks['protected_file_checks']) == 18
assert all(sha(x['path']) == x['expected'] for x in checks['protected_file_checks'])
assert json.loads(hpath.read_text(encoding='utf-8'))['historical_repair_review_20261004'] == pointer
assert backup.read_bytes() == prior
for name in ['NEXT_ACTIONS.json', '修补路线登记.json', '证据索引.json', '已有消融复算.json']:
    json.loads((O / name).read_text(encoding='utf-8'))
artifacts = [p for p in O.iterdir() if p.is_file() and p.name != 'DELIVERY_CHECK.json']
write_json(O / 'DELIVERY_CHECK.json', {
    'at': now, 'json_parse': 'passed', 'handoff_pointer': 'passed',
    'protected_files_unchanged': 18, 'handoff_backup_verified': True,
    'artifacts': [{'path': str(p), 'sha256': sha(p)} for p in artifacts],
    'new_fits': 0, 'test_targets_loaded': False
})
print(json.dumps({'report': plan['report'], 'handoff_updated': True,
                  'protected_files_unchanged': 18, 'new_fits': 0}, ensure_ascii=False))
