from common import *
def main():
  r=gate.read(HERE/'RESULT.json');a=gate.read(HERE/'AUDIT.json');aa=gate.read(HERE/'ATTRIBUTION_AUDIT.json')
  assert a['status']==aa['status']=='passed' and a['result_sha256']==aa['result_sha256']==gate.sha(HERE/'RESULT.json')
  n=preserved();rank=r['rankings']
  selected=[x for x in rank if x['feature']=='congestion_absolute_share' and x['horizon']=='H1']
  sources=gate.read(HERE/'RESIDUAL_SOURCE_REVIEW.json');cases=gate.read(HERE/'CASE_TRACES.json')
  decision=dict(at=gate.now(),status='fit_free_diagnosis_completed_no_candidate_admitted',fits=0,new_test_period_access=False,
    price_forecasts_changed=False,V7_retained=True,protected_files_verified=n,
    headline='Component trajectories sharpen the description of sudden recovery versus persistent congestion, but fixed precursor associations do not replicate consistently across periods. A three-component forecast also needs its June2026 accounting contract resolved.',
    facts=[
      'S3 pooled absolute movement is47.18%energy,51.76%congestion,1.06%loss. This is a descriptive decomposition, not a causal decomposition of prediction error.',
      'The largest added-SSE S3 example follows LMP1140.6407 to63.1886USD/MWh in5minutes; energy610.0218 to51.6827 and congestion511.2812 to9.7746 fall together. FrozenFULL~139 andV7~546 differ because the correction retains a large elevated-price expectation.',
      'The largest S5 benefit example is predominantly congestion before the origin and retains high congestion afterward. It is an illustration selected by error magnitude, not proof of a general routing rule.',
      'Fixed congestion-share H1 rank score has equal-date AUC0.8948 in inspectedH1,0.5585 inTRAIN_CAL,0.3962 inTRAIN_FIT. H1 first-step S3 has only4UTCdates; monthlyJanuary AUC0.1875 versusMarch0.9100. Do not choose a new threshold from this contrast.',
      'June22/23 known target components leave1620cell residuals(max12.4800USD/MWh),allS0/S1. Original source CSV spot checks reproduce the archive. GHG reporting changes are documented officially, but exact shadow-price matching remains unresolved. This does not explain the MarchS3/S5 events.',
      '20of259332TRAIN target labels differ at a float32 inverse-scaling threshold tie. Frozen labels retained; maximum raw/inverse price difference<0.0001USD/MWh. This arithmetic boundary issue is not evidence for the largeS3 errors.'
    ],
    next_actions=[
      'PreserveV7 and the complete current paper/result evidence. NoV28 or automatic component-head fit.',
      'Before any physical component-reconstruction model, identify the missing June2026 term from the official report and version-specific source; retain every original forecast and raw value.',
      'A new routing experiment would require an earlier-only, independently dated demonstration of the proposed energy/congestion interaction, not just a strong association on the inspectedMarch events.',
      'If that evidence cannot be established, close architecture search and useV7 with supported claims and complete comparisons.'
    ],
    not_established=['All-state dominance','A calibrated recovery detector','A causal energy-versus-congestion error attribution','Statistical significance or independent confirmation for the15diagnostic scores'],
    evidence=dict(result=str(HERE/'RESULT.json'),arithmetic_audit=str(HERE/'AUDIT.json'),attribution_audit=str(HERE/'ATTRIBUTION_AUDIT.json'),
      cases=str(HERE/'CASE_TRACES.json'),source_residual=str(HERE/'RESIDUAL_SOURCE_REVIEW.json')))
  write(HERE/'DECISION.json',decision)
  write(HERE/'REVIEW_CN.json',dict(at=gate.now(),结论='完成不新增训练的归因诊断；V7保持原样，尚无足够证据启动分量预测或新门控。',
    主要发现=['大幅回落不是单纯拥塞下降，能源价和拥塞价可能同时骤降。','拥塞占比在已查看开发期有较强区分力，但训练/校准/月份之间不稳定，不能按开发期挑阈值。','六月出现尚未核清名称的价格分量残差，已保留单独记录，不强行归入能源或删去记录。'],
    原预测与新假设='现有预测、权重、论文和所有正负结果未改动；本次没有新的精度结果。',
    范围='698起点、42日期、30节点、12步既有开发面板；对应训练极端历史21611节点起点。第一步S3/S5区分只有141格、9日期，其中S3仅4日期。',
    单一指标示例=selected,案例=cases['cases'],审核=dict(独立公式检查=a['check_count'],分量加权复算=aa['manual_weighted_attribution_checks'],保留文件=n,
       说明='独立代码/公式，同一操作者；不是外部专家审核。'),
    文件=str(HERE/'DECISION.json')))
  h=gate.read(B/'HANDOFF.json');write(HERE/'HANDOFF_before_component_review.json',h)
  h.update(at=gate.now(),status='component_event_diagnosis_complete_V7_retained',research_training_active=False,numeric_diagnostic_active=False,
    complete_research_experiment=False,next_action='No new training admitted by component diagnosis. First resolveJune2026 unaccounted component reporting semantics and establish earlier-only precursor stability before proposing any component/gating variant. V7 and paper remain unchanged.',
    component_event_diagnosis=dict(directory=str(HERE),decision=str(HERE/'DECISION.json'),review=str(HERE/'REVIEW_CN.json'),audit=str(HERE/'AUDIT.json'),attribution_audit=str(HERE/'ATTRIBUTION_AUDIT.json'),fits=0,active=False))
  gate.write(B/'HANDOFF.json',h)
  write(HERE/'status.json',dict(at=gate.now(),pid=os.getpid(),status='completed_and_reviewed',fits=0,numeric_worker_active=False,
    background_experiment_started=False,notification='Direct active-turn response; no duplicate inbox event or timed wakeup.',V7_preserved=True))
  print('Fit-free diagnosis and220arithmetic checks complete;17protected files unchanged. No further worker queued.')
if __name__=='__main__':main()
