"""Synthetic, invariant and numerical checks; no research forecast fitting."""
from pathlib import Path
import sys
HERE = Path(__file__).resolve().parent
sys.path.insert(0, str(HERE.parent / 'context_expert_v1_20260929'))
import gate


def main():
    with gate.exclusive('V17 synthetic conditional risk kernel verification only'):
        np, limiter = gate.runtime(False)
        from risk_gate import (distribution_decision, ConditionalRiskGate, Settings,
                               chronological_mask, feature_matrix)
        checks = {}
        # A harmful upward specialist correction and a harmful downward one.
        for name, r, d in [('upward_overcorrection', [-10., -12., -8.], -20.),
                           ('downward_overcorrection', [10., 12., 8.], 20.)]:
            g, da, ds = distribution_decision(r, np.ones(3), d)
            assert abs(g-.5) < 1e-12 and da < 0 and ds < 0
            checks[name] = dict(weight=g, expected_MAE_delta=da, expected_MSE_delta=ds)
        # A rare, large tail moves the mean upward, while a majority at baseline
        # makes every positive change worsen absolute risk. Must retain V7.
        g, _, _ = distribution_decision([0., 100.], [.99, .01], 10.)
        assert g == 0
        checks['mean_median_conflict_falls_back'] = True
        assert distribution_decision([-5., -6.], [1., 1.], 20.)[0] == 0
        checks['wrong_direction_rejected'] = True
        rng = np.random.default_rng(9103)
        worst = 0.
        # Independent dense numerical oracle is confined to synthetic QA;
        # production uses the analytic mean and convex bisection only.
        for _ in range(200):
            r = rng.normal(size=31) * rng.uniform(.2, 10.)
            w = rng.uniform(size=31); w /= w.sum()
            d = rng.uniform(-15, 15)
            g, da, ds = distribution_decision(r, w, d)
            actual_da = float(w @ (abs(r-g*d)-abs(r)))
            actual_ds = float(w @ ((r-g*d)**2-r**2))
            assert 0 <= g <= 1 and actual_da <= 1e-9 and actual_ds <= 1e-9
            assert np.isclose(da, actual_da, atol=1e-9) and np.isclose(ds, actual_ds, atol=1e-9)
            grid = np.linspace(0, 1, 2001)
            losses = abs(r[None, :] - grid[:, None]*d) @ w
            valid = losses <= float(abs(r) @ w) + 1e-12
            mse = (r[None, :] - grid[:, None]*d)**2 @ w
            gap = float(w @ (r-g*d)**2) - float(mse[valid].min())
            worst = max(worst, gap)
            assert gap < 1e-8
        checks['random_convex_risk_cases'] = 200
        checks['maximum_objective_gap_to_dense_QA_oracle'] = worst
        eligible = chronological_mask(np.array([300000,300000,300000]),
            np.array([303600]*3), np.array([304000,9999999,304000]),
            np.array([200000,200000,400000]), 600000)
        assert eligible.tolist() == [True, False, False]
        checks['release_and_backbone_chronology'] = True
        n = 2400; x = rng.normal(size=(n, 6)); r = 4*x[:, 0]+rng.normal(size=n)
        issue = np.repeat(np.arange(30)*86400 + 1000000, 80)
        test_model = ConditionalRiskGate(Settings(trees=8, depth=2))
        args = (x, r, issue, issue+3600, issue+7200, issue-86400, int(issue.max()+4*86400))
        try:
            test_model.fit(*args)
            raise AssertionError('Research admission lock bypassed')
        except RuntimeError:
            pass
        test_model.fit(*args, synthetic_only=True)
        base = np.full(10, 100.); full = np.full(10, 150.)
        out, g, changes = test_model.predict(x[:10], base, full, np.ones(10),
            np.array([True]*5+[False]*5), np.array([True,False,False,False,False]*2))
        assert np.array_equal(out[5:], base[5:]) and out[0] == base[0]
        assert np.all((out >= base) & (out <= full)) and np.all(changes <= 1e-8)
        checks['protected_domains_bitwise_unchanged'] = True
        checks['real_fit_admission_lock'] = True
        # Insufficient local date support must yield exactly the parent.
        test_model.settings = Settings(minimum_dates=100)
        out, g, _ = test_model.predict(x[:10], base, full, np.ones(10), np.ones(10,bool), np.zeros(10,bool))
        assert np.array_equal(out, base) and not g.any()
        checks['unsupported_context_fallback'] = True
        context = x[:10]; probs = np.tile([.3,.3,.4], (10,1))
        payload = dict(context=context, duration=np.ones(10), horizon=np.ones(10),
            probabilities=probs, v7=base, full=full, scale=np.ones(10))
        original = feature_matrix(**payload)
        # Future truth/state/release are absent from the public prediction API.
        import inspect
        assert not {'truth','state','available','future_price'} & set(inspect.signature(feature_matrix).parameters)
        assert np.array_equal(original, feature_matrix(**payload))
        checks['feature_API_excludes_future_labels'] = True
        gate.write(HERE/'KERNEL_QA.json', dict(at=gate.now(), status='passed', checks=checks,
            script_sha256=gate.sha(__file__), kernel_sha256=gate.sha(HERE/'risk_gate.py'),
            synthetic_forest_fitted=True, research_model_fitted=False, price_targets_read=False,
            warning='Synthetic correctness is not CAISO forecast improvement; estimated risk constraints do not guarantee realized risk.'))
        print('V17 kernel: synthetic and invariant QA passed; no research fit.')


if __name__ == '__main__':
    main()
