from pathlib import Path
import sys,json,psutil,hashlib
a=Path(__file__).resolve().parent
b=a.parents[1]
sys.path.insert(0,str(b/'source'))
import backbone_train as io
assert io.read(a/'independent_review.json')['status']=='passed_for_stale_lock_recovery'
assert io.stop_reason(b) is None
paths=[io.GLOBAL_LOCK,b/'mechanism_controls_20260920/queue/QUEUE.lock',b/'phase_sampling_additive_v2_20260920/queue/QUEUE.lock']
expected={str(p.resolve()) for p in paths}
boot=psutil.boot_time()
checks=[]
for path in paths:
 assert str(path.resolve()) in expected
 owner=io.read(path)
 assert owner['created'] < boot
 try:
  proc=psutil.Process(owner['pid'])
  assert abs(proc.create_time()-owner['created'])>0.01, 'Original lock owner is still alive'
 except psutil.NoSuchProcess:
  pass
 digest=io.sha(path)
 destination=path.with_name(path.stem+'.stale_20260923_'+owner['token'][:8]+'.lock')
 assert destination.resolve().parent==path.resolve().parent and not destination.exists()
 checks.append(dict(path=str(path),owner=owner,sha256=digest,preserved_path=str(destination)))
io.write(a/'stale_lock_quarantine_admission.json',dict(status='verified_dead_owners_only',boot_time=boot,locks=checks))
for row in checks:
 source=Path(row['path']); destination=Path(row['preserved_path'])
 assert io.sha(source)==row['sha256'] and io.read(source)==row['owner']
 source.rename(destination)
 assert io.sha(destination)==row['sha256'] and not source.exists()
io.write(a/'stale_lock_quarantine_receipt.json',dict(status='preserved_three_stale_locks',at=io.now(),locks=checks,no_recursive_operations=True,no_checkpoints_removed=True))
print(json.dumps(dict(status='preserved_three_stale_locks',count=len(checks))))
