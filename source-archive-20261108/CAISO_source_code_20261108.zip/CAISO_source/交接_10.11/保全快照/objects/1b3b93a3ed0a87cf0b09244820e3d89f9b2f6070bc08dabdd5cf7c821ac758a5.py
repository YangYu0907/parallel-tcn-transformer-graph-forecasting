from experiment import *
import psutil

def main():
    verify();assert old.parent.verify_protected()==18
    r=old.read(HERE/'RESULT.json');a=old.read(HERE/'AUDIT.json');d=old.read(HERE/'DIAGNOSIS.json')
    assert a['result_sha256']==old.sha(HERE/'RESULT.json')==d['result_sha256']
    assert not r['screen_passed']
    launch=old.read(HERE/'LAUNCH.json');status=old.read(HERE/'STATUS.json')
    receipt=old.B/f"event_driven_automation/process_monitors/sampling_exit_{launch['manager_pid']}_{launch['manager_start_utc_ticks']}.exit.json"
    assert old.read(receipt)['terminal_handled']
    active=[]
    for p in psutil.process_iter(['pid','name','cmdline']):
        if p.info['pid']==os.getpid():continue
        if (p.info['name'] or '').lower()=='python.exe' and any(str(HERE) in s for s in (p.info['cmdline'] or [])):active.append(p.info)
    assert not active,active
    listener=psutil.Process(launch['filesystem_listener_pid']);assert any('watch.ps1' in s for s in listener.cmdline())
    lines=['LMP分量 × 状态转换：有限匹配实验完成报告',
        '结论：8次分类器拟合完成，组合候选未通过既定筛选，不替换V7，不扩展训练。',
        '本轮具体检验老师尖峰意见中的“已发生极端价之后，如何判断回落/持续或再次极端”。没有解决S2新尖峰起始预测，也没有宣称解决动态图等全部五项意见。',
        '', '范围与公平性',
        '只使用此前已检查的历史TRAIN，两个时间窗口；结果均为H8–H12、当前已极端的节点×预测步单元。不是新的独立测试。',
        f"窗口1为805单元/25日期，窗口2为930单元/17日期；两窗口重叠{d['overlapping_dates']}个日期，合并仅{d['unique_dates']}个不同日期，不能当成两次独立复制。",
        '每组都使用相同起点、节点、12步训练标签、树配置、80轮和种子。四组为原价格/增加能量拥塞损耗历史分量，交叉直接端点概率/逐步二状态转换。',
        '转换模型训练使用前一步真实状态监督；预测时对前一步状态概率求和，允许回落后重返极端。真实未来状态不作为推理输入。',
        '这不是8次神经网络重训。骨干、幅度专家和V7均保持冻结；仅拟合8个轻量HGB分类器。',
        '971份来源元数据与缓存哈希通过继承准入；来源仍为既有回溯契约，不代表发布方逐值版本认证。',
        '', '全部概率指标：越小越好；不同于价格MAE/RMSE']
    for row in r['probes']:
        lines.append(f"窗口{row['fold']}")
        for arm in row['arms']:
            s=arm['scores'];tr=arm['train_scores']
            lines.append(f"{arm['arm']}: Brier={s['brier']:.9f}, logloss={s['log_loss']:.9f}, 日期等权Brier={s['date_brier']:.9f}, 日期等权logloss={s['date_log_loss']:.9f}; 训练Brier={tr['brier']:.9f}")
            for g in arm['groups']:
                lines.append(f"  S{g['state']}: {g['cells']}单元/{g['dates']}日期, Brier={g['brier']:.9f}, logloss={g['log_loss']:.9f}, 日期等权Brier={g['date_brier']:.9f}, 日期等权logloss={g['date_log_loss']:.9f}")
        base=row['arms'][0]['scores'];tp=row['arms'][2]['scores'];tc=row['arms'][3]['scores']
        lines.append(f"相对匹配DIRECT_PRICE，TRANSITION_PRICE总体Brier降低{100*(1-tp['brier']/base['brier']):.4f}%；组合TRANSITION_COMPONENT变化{100*(tc['brier']/base['brier']-1):+.4f}%（正为变差）。")
        lines.append('筛选记录：'+str(row['checks']))
    lines+=['', '进一步误差分解（事后诊断，不用于改阈值或选模型）']
    for row in d['probes']:
        x={z['arm']:z for z in row['arms']};b=x['DIRECT_PRICE'];t=x['TRANSITION_PRICE'];c=x['TRANSITION_COMPONENT']
        lines.append(f"窗口{row['fold']}：原价格转换模型ROC-AUC {b['roc_auc']:.6f}→{t['roc_auc']:.6f}；加入分量的转换模型ROC-AUC {c['roc_auc']:.6f}。")
        lines.append(f"实际未来仍/再极端的S5上，平均预测回落概率：直接{b['mean_p_extreme']:.6f}，转换{t['mean_p_extreme']:.6f}，分量转换{c['mean_p_extreme']:.6f}。")
        lines.append(f"组合模型对总体Brier差值的S3/S4/S5加权贡献：{[round(z['total_brier_difference_contribution'],9) for z in c['state_contributions']]}。")
    lines+=['事实：价格转换模型的概率排序和总体评分在两个窗口改善，但S5误差均变差；组合模型S3/S4改善，被S5回退抵消。',
        '事实：分量信息在训练内降低误差，却未稳定提高时间留出区分能力。不能将其说成分量无效，也不能将失败唯一归因于容量或概念漂移。',
        '解释性假设：状态转换概率存在整体回落偏高，新增历史分量的时间迁移信号不足；少量相关日期和跨状态混淆仍是主要核查对象。',
        'S3/S4/S5由未来状态定义，用于评分。不能在运行时用这些标签决定是否启用某个专家；事后挑选模型会泄漏未来。',
        '恢复概率、概率校准、尖峰幅度是不同问题；Brier改善不能直接换算为价格RMSE下降。',
        '', '决定与后续边界',
        '按登记关闭本组合候选，保留全部结果。价格转换模型仅保留为研究线索，不进行事后替补晋级或修改通过门槛。',
        '本次排除了“把历史LMP分量与转换模型简单相加就能兼顾所有状态”的当前实现，未排除整个机制家族。',
        '如开展下一轮，优先区分排序与校准问题：在训练期内另设带时间隔离的校准块，先检查纯价格转换模型的过高回落概率能否校准；所有对照同样校准，最终检验仍置后。需要新登记，不能在本轮探针标签上拟合再宣称通过。',
        '此前的全局权重/校准尝试已失败，下一轮必须明确新信息或新结构差别与时间交叉拟合条件；若只是再调全局回落权重，不值得重做。',
        '另需核准预测时点可获得的局部约束、备用、停机等信息。文献机制可支持调查，但缺少版本证据时不能进入训练。',
        '不继续扩大模型搜索。不将已反复查看的窗口称为独立测试。正式替换仍需新的来源准入和独立确认。',
        '', '老师意见对应状态（本轮增量）',
        '1 图模块跨数据集作用：本轮未改变图，未新增解决证据。',
        '2 输入公平性：本轮2×2对照严格匹配；不能据此宣布论文所有外部基线公平性工作已完成。',
        '3 V7消融：本轮未修改V7，已有修订消融需保留，未新增V7组件结论。',
        '4 尖峰：获得更具体的回落/持续冲突证据，尚未达到全面改善，S2起始尚不在本轮范围。',
        '5 概率预测：这里是事件状态概率；不等于电价区间/分布预测，已有区间修订须单独评估。',
        '', '文献依据及查阅边界',
        'Mount等，Energy Economics28(2006)62–80：时变转换概率思想，出版社摘要已核验；并不保证CAISO本实现有效。https://doi.org/10.1016/j.eneco.2005.09.008',
        'Godin与Ibrahim，Energy Economics102(2021)105506：拥塞分量模式动机；书目信息/摘要已核验，出版社全文访问受限，不主张完整复现。https://doi.org/10.1016/j.eneco.2021.105506',
        'Guo等，ICML2017：区分预测区分度与概率校准；其温度缩放结果不是对电价或本HGB的有效性保证。https://proceedings.mlr.press/v70/guo17a.html',
        'Lago等，Applied Energy293(2021)116983：信息可比、时间评估和完整报告。https://arxiv.org/abs/2008.08004',
        '', '运行与复核',
        f"8次拟合和评分{r['numeric_seconds']:.3f}秒；94项合成检查、313项独立公式/推理重放检查、16项事后分解恒等式通过。独立脚本由同一操作者完成，不声称外部审核。",
        '18份保护文件哈希不变；所有点预测未更新。管理进程已正常退出，退出事件已核验。本地文件监听保留，不创建定时唤醒。']
    (HERE/'REPORT_CN.txt').write_text('\n'.join(lines)+'\n',encoding='utf-8')
    old.write(HERE/'CLOSEOUT.json',dict(at=old.now(),status='closed_failed_preregistered_screen',actual_fits=8,
        full_prefix_fits=0,V7_replaced=False,new_test_targets_read=False,automatic_retry=False,
        result_sha256=old.sha(HERE/'RESULT.json'),audit_sha256=old.sha(HERE/'AUDIT.json'),
        diagnosis_sha256=old.sha(HERE/'DIAGNOSIS.json'),report_sha256=old.sha(HERE/'REPORT_CN.txt'),
        protected_files=18,numerical_worker_active=False,exit_receipt=str(receipt),exit_receipt_sha256=old.sha(receipt)))
    old.write(HERE/'EVENT_REVIEW.json',dict(at=old.now(),event_id=status['event_id'],status='analyzed_and_closed',
        evidence_sha256=old.sha(HERE/'AUDIT.json'),closure_sha256=old.sha(HERE/'CLOSEOUT.json'),
        duplicate_action='Do not repeat notification or fitting for unchanged evidence; delivered in active user turn'))
    h=old.read(old.B/'HANDOFF.json');old.write(HERE/'HANDOFF_BEFORE_CLOSEOUT.json',h)
    h['last_action_at']=old.now();h['latest_status']='component_transition_2x2_closed_failed_retention_V7_preserved'
    h['component_transition_20261004']=dict(directory=str(HERE),stage='closed_failed_probability_screen',
        launch=launch,protocol_sha256=old.sha(HERE/'PROTOCOL.json'),actual_fits=8,full_prefix_fits=0,
        result_sha256=old.sha(HERE/'RESULT.json'),audit_sha256=old.sha(HERE/'AUDIT.json'),
        report=str(HERE/'REPORT_CN.txt'),event_id=status['event_id'],event_review=str(HERE/'EVENT_REVIEW.json'),
        V7_replaced=False,new_test_targets_read=False,numerical_worker_active=False)
    h['next_actions']=[
        'V7 and18 protected files retained. Fixed 2x2 component/transition probe closed, 8fits; do not repeat or promote a nonselected control on duplicate events.',
        'Pure-price transitions improve overall probability scores and rank in both old inner windows but degrade future-extreme S5. Components do not resolve this. No new price accuracy or spike-onset claims.',
        'Only consider separately registered leakage-free calibration/source-information work with matched controls and explicit difference from prior failed global weighting; no automatic sweep or full-prefix fit.',
        'Five teacher issues and independent confirmation remain unfinished. Preserve existing fairness/ablation/interval evidence separately; keep local event listener, no timed model wakeups.'
    ]
    old.write(old.B/'HANDOFF.json',h);verify()
    print('Closed; report and handoff saved,18protected unchanged; listener alive.')
if __name__=='__main__':main()
