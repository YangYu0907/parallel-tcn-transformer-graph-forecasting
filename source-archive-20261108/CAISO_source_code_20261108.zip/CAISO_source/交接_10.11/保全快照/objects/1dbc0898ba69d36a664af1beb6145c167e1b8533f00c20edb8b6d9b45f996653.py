"""Execute the four frozen arms with disk-backed matrices and exact resume."""
from pathlib import Path
import os,gc,pickle,time
import numpy as np
from scipy.optimize import minimize_scalar
import support as s
import compare as registered
from features import calendar
import disk_hgb
W=Path(__file__).resolve().parent.parent
def read_arm(arm):
    j=W/f'{arm}_complete.json'
    if not j.exists():return None
    q=s.read(j)
    assert all(s.sha(Path(p))==h for p,h in q['bindings'].items())
    return q
def run(p,tick):
    if (s.N/'FEATURES_READY.json').exists():
        f=s.read(s.N/'FEATURES_READY.json');assert s.sha(s.N/'ROWS.npz')==f['rows_sha256']
        with np.load(s.N/'ROWS.npz') as z:rows=z['row'];where=z['weather_row']
        assert s.read(s.N/'SUPPORT.json')['passed']
    else:
        prepared=registered.prepare(p,tick)
        if prepared is None:
            s.write('RESULT.json',dict(at=s.now(),stage='insufficient_event_support',model_fits=0,accuracy_result=False,V7_replaced=False,new_test_targets_read=False));return
        rows,where=prepared
    N=registered.N
    y=np.asarray(np.load(N/'labels.npy',mmap_mode='r')[rows]);role=np.asarray(np.load(N/'role.npy',mmap_mode='r')[rows]);times=np.asarray(np.load(N/'times.npy',mmap_mode='r')[rows]);nodes=np.asarray(np.load(N/'nodes.npy',mmap_mode='r')[rows])
    fit=np.flatnonzero(role==0);cal=np.flatnonzero(role==1);evaluation=np.flatnonzero(role==2)
    assert times[fit].max()+3600<=times[cal].min() and times[cal].max()+3600<=times[evaluation].min()
    results={};saved=dict(y=y[evaluation],time=times[evaluation],node=nodes[evaluation],cal_y=y[cal],cal_time=times[cal])
    for arm in p['arms']:
        existing=read_arm(arm)
        if existing:
            results[arm]=existing['result']
            with np.load(W/f'{arm}_probabilities.npz') as z:saved[arm]=z['evaluation'];saved['cal_'+arm]=z['calibration']
            continue
        start=time.monotonic()
        def arm_tick(**kw):tick(arm=arm,completed_model_fits=len(results),**kw)
        disk_hgb.TICK=arm_tick
        weather=None if arm=='HISTORY' else np.load(s.N/f'weather_{arm}.npy',mmap_mode='r')
        def design(ii):
            x=np.load(N/'features.npy',mmap_mode='r');hist=np.asarray(x[rows[ii]],np.float32);x._mmap.close()
            a=np.concatenate([hist,calendar(times[ii]).astype(np.float32)],axis=1)
            if weather is not None:a=np.concatenate([a,np.asarray(weather[where[ii]],np.float32)],axis=1)
            assert np.isfinite(a).all();return a
        target=W/f'{arm}_design.npy';done=W/f'{arm}_design.json'
        if not done.exists():
            d=design(fit[:1]).shape[1]
            mm=np.lib.format.open_memmap(target,mode='w+',dtype=np.float32,shape=(len(fit),d),fortran_order=True);mm._mmap.close()
            for begin in range(0,len(fit),8192):
                ii=fit[begin:begin+8192];a=design(ii)
                mm=np.load(target,mmap_mode='r+');mm[begin:begin+len(ii)]=a;mm.flush();mm._mmap.close();del a
                if begin%65536==0:arm_tick(stage='disk_design',done=begin,total=len(fit),features=d)
            s.base.write(done,dict(at=s.now(),sha256=s.sha(target),rows=len(fit),features=d))
        else:assert s.sha(target)==s.read(done)['sha256']
        modelpath=s.N/'models'/f'{arm}.pkl';progress=W/f'{arm}_fit.json'
        if modelpath.exists():
            assert progress.exists() and s.sha(modelpath)==s.read(progress)['sha256']
            with modelpath.open('rb') as f:model=pickle.load(f)
        else:model=disk_hgb.DiskHGB(**p['learner'])
        for it in [20,40,60,80]:
            if getattr(model,'n_iter_',0)>=it:continue
            arm_tick(stage='matched_information_fit',trees=it,fit_pairs=len(fit))
            mm=np.load(target,mmap_mode='r');model.set_params(max_iter=it);model.fit(mm,y[fit]);mm._mmap.close()
            registered.save_model(arm,model)
            s.base.write(progress,dict(at=s.now(),completed_iterations=it,sha256=s.sha(modelpath),elapsed_seconds=time.monotonic()-start))
        assert model.classes_.tolist()==[0,1,2] and model.n_iter_==80
        def predict(ii):
            out=np.empty((len(ii),3))
            for begin in range(0,len(ii),8192):
                sub=ii[begin:begin+8192];out[begin:begin+len(sub)]=model.predict_proba(design(sub))
                if begin%65536==0:arm_tick(stage='matched_information_predict',done=begin,total=len(ii))
            return out
        cp0=predict(cal);ep0=predict(evaluation)
        temperature=float(minimize_scalar(lambda t:registered.old.logscore(registered.old.temp(cp0,t),y[cal]),bounds=(.5,2),method='bounded').x)
        cp=registered.old.temp(cp0,temperature);ep=registered.old.temp(ep0,temperature)
        thresholds=[float(np.quantile(cp[y[cal]!=c,c],.99,method='higher')) for c in [1,2]]
        results[arm]=dict(temperature=temperature,thresholds=thresholds,metrics=registered.old.metrics(ep,y[evaluation],thresholds))
        saved[arm]=ep;saved['cal_'+arm]=cp
        probpath=W/f'{arm}_probabilities.npz';s.base.npz_save(probpath,evaluation=ep,calibration=cp)
        s.base.write(W/f'{arm}_complete.json',dict(at=s.now(),result=results[arm],elapsed_seconds=time.monotonic()-start,bindings={str(x):s.sha(x) for x in [modelpath,probpath,target]}))
        del model,cp0,ep0,cp,ep;gc.collect();arm_tick(stage='arm_complete',arm_elapsed_seconds=time.monotonic()-start)
    s.save('PREDICTIONS.npz',**saved)
    s.write('RESULT_PENDING_AUDIT.json',dict(at=s.now(),scope='Known TRAIN calendar-thinned information diagnostic, not independent confirmation and not point-price improvement',model_fits=4,fit_pairs=len(fit),cal_pairs=len(cal),eval_pairs=len(evaluation),results=results,V7_replaced=False,new_test_targets_read=False,engineering='Disk-backed equivalent HGB; exact stock-sklearn synthetic replay passed'))
    registered.event_ledger(rows,p,tick)
    import score_audit
    score_audit.run(p,tick)
