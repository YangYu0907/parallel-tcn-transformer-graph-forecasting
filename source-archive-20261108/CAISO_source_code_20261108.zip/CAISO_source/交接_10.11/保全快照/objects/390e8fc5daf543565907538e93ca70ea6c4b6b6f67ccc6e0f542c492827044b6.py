"""Original scalar attention plus one zero-initialized channel correction gate."""
import math
import torch
from torch import nn
from torch.nn import functional as F
from models.clip_model import ClipFusion
from models.model_feature_fusion_rev12 import FeatureFusionModel


def residual_weights(attention, tcn, transformer, context, beta):
    query = attention.query(context).unsqueeze(2) + attention.horizon_embedding
    keys = attention.key(torch.stack((tcn, transformer), dim=2))
    logits = torch.einsum('bnhd,bnkd->bnhk', query, keys) / math.sqrt(tcn.shape[-1])
    logits = logits + attention.branch_bias
    base = logits.softmax(dim=-1)
    coordinate = query.unsqueeze(3) * keys.unsqueeze(2) / math.sqrt(tcn.shape[-1])
    centered = coordinate - coordinate.mean(dim=-1, keepdim=True)
    baseline_logits = logits.unsqueeze(-1).expand_as(centered)
    # Subtract the same-shaped reference to preserve the scalar path bitwise at beta=0.
    # Algebraically this is softmax(scalar_logits + beta*centered_scores).
    shift = (baseline_logits + beta * centered).softmax(dim=3) - baseline_logits.softmax(dim=3)
    return base.unsqueeze(-1) + shift


class ResidualFusion(ClipFusion):
    def __init__(self, seed, context_limits):
        super().__init__('FULL', seed, context_limits)
        self.residual_scale = nn.Parameter(torch.zeros(()))

    def forward(self, x):
        if x.ndim != 4 or x.shape[1:] != (288, 30, 29):
            raise ValueError('Expected original fixed historical schema')
        encoded, adjacency, context = self.graph(x)
        tcn = self.tcn(encoded)
        batch, _, nodes, hidden = encoded.shape
        low = FeatureFusionModel.low_frequency_history(encoded)
        sequence = low.permute(0, 2, 3, 1).reshape(batch * nodes, hidden, -1)
        tokens = F.avg_pool1d(sequence, 6, 6, ceil_mode=True).transpose(1, 2)
        transformer = self.transformer(tokens).reshape(batch, nodes, hidden)
        weights = residual_weights(self.attention, tcn, transformer, context, self.residual_scale)
        fused = weights[..., 0, :] * tcn.unsqueeze(2) + weights[..., 1, :] * transformer.unsqueeze(2)
        observed = self.observed_context(x)
        features = fused + self.price_context(observed).unsqueeze(2)
        return dict(prediction=self.head(features), branch_weights=weights,
                    fused_features=fused, dynamic_adjacency=adjacency,
                    transformer_features=transformer, observed_context=observed,
                    head_features=features)
