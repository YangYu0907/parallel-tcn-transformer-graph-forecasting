"""Read-only numerical diagnostics of the frozen specialist. Never fit or deploy."""
from pathlib import Path
import sys, json, os, uuid, pickle, math
HERE = Path(__file__).resolve().parent
ROOT = HERE.parent
B = ROOT.parent
sys.path.insert(0, str(B/'context_expert_v1_20260929'))
import gate
A = Path('C:/Users/于阳/CAISO_temporary_storage')

def write(name, d):
    p=HERE/name; t=p.with_name('.'+p.name+'.'+uuid.uuid4().hex+'.tmp')
    with t.open('xb') as f:
        f.write(json.dumps(d,ensure_ascii=False,indent=2,allow_nan=False).encode('utf-8'));f.flush();os.fsync(f.fileno())
    os.replace(t,p)

def load(p):
    with Path(p).open('rb') as f:return pickle.load(f)

def register():
    assert not (HERE/'PROTOCOL.json').exists()
    manifest=gate.read(B/'phase_sampling_support_v3_20260923/dataset/ADDITIVE/manifest.json')
    inputs=[A/'spike_specialist_v7_20260930/TRAIN_features.npz',A/'spike_specialist_v7_20260930/H1_features.npz',
            A/'adaptive_experts_v5_20260929/TRAIN_prepared.npz',B/'spike_specialist_v7_20260930/TRAIN_CALIBRATION.json']
    inputs += [gate.resolve(manifest['artifacts'][k]['path']) for k in ['scalers.json','state_thresholds.json','timestamps_seconds.npy']]
    for seed in [20260813,20260814,20260815]:
        inputs += [A/f'spike_specialist_v7_20260930/{part}/{seed}{suffix}' for part,suffix in [
            ('audited','.npz'),('predictions','.npz'),('models','_CONTEXT_probabilities.npz')]]
        inputs += [A/f'adaptive_experts_v5_20260929/models/{seed}_distributions.npz']
    inputs += [A/f'spike_specialist_v7_20260930/models/20260813_CONTEXT_{task}.pkl' for task in ['hazard','postexit']]
    write('PROTOCOL.json',dict(at=gate.now(),scope='Existing TRAIN/calibration and the previously inspected V7 698-origin development panel only.',
        classification='Post-hoc diagnosis, not confirmatory testing or model selection',
        questions=['Check centering, state labels, first-exit masks and probability reconstruction.',
                   'Quantify target-dependent per-origin weighting and calibration-population support.',
                   'Decompose predicted continuing-spike probability into no-exit survival and post-exit recurrence.',
                   'Use realized exit/state substitutions only as non-deployable diagnostic counterfactuals; no new forecasts are exported.',
                   'Check whether probability correction alone could remove amplitude errors.'],
        fixed_substitutions=['SAVED','KNOWN_EXIT','KNOWN_POSTEXIT','KNOWN_BOTH'],
        no_fit=True,no_threshold_search=True,new_test_targets_allowed=False,
        bindings={str(p):gate.sha(p) for p in inputs},code_sha256=gate.sha(__file__),
        protected=gate.read(B/'multi_round_mechanism_v21_20261001/RETAINED_BASELINE_HASHES.json')['files']))

def run():
    p=gate.read(HERE/'PROTOCOL.json');assert gate.sha(__file__)==p['code_sha256']
    with gate.exclusive('Frozen specialist survival/post-exit and training-weight diagnosis only'):
        np,limiter=gate.runtime(False)
        for path,h in {**p['bindings'],**p['protected']}.items():assert gate.sha(path)==h,path
        def read_np(path):
            with np.load(path,allow_pickle=False) as z:return {k:z[k] for k in z.files}
        tr=read_np(A/'spike_specialist_v7_20260930/TRAIN_features.npz')
        he=read_np(A/'spike_specialist_v7_20260930/H1_features.npz')
        v5=read_np(A/'adaptive_experts_v5_20260929/TRAIN_prepared.npz')
        manifest=gate.read(B/'phase_sampling_support_v3_20260923/dataset/ADDITIVE/manifest.json')
        sc=gate.read(gate.resolve(manifest['artifacts']['scalers.json']['path']))
        th=gate.read(gate.resolve(manifest['artifacts']['state_thresholds.json']['path']))
        ts=np.load(gate.resolve(manifest['artifacts']['timestamps_seconds.npy']['path']),mmap_mode='r')
        center=np.array(th['center']);q=np.array(th['thresholds']);scale=np.array(sc['price_scale'])[0,:,0]
        assert np.array_equal(np.array(sc['price_center'])[0,:,0],center)
        expected=(abs(v5['y'])>v5['ratio'][:,None]).astype(int)+(abs(v5['y'])>1).astype(int)
        assert np.array_equal(expected,tr['classes']) and np.array_equal(v5['origins'],tr['origins'])
        assert np.array_equal(v5['nodes'],tr['nodes'])
        cls=tr['classes'];first=np.array([next((j for j,k in enumerate(row) if k<2),12) for row in cls])
        hs=np.arange(12)[None,:];risk=hs<=first[:,None];event=hs==first[:,None];post=hs>=first[:,None]
        assert np.array_equal(risk, np.cumprod(np.concatenate([np.ones((len(cls),1),int),(cls[:,:-1]==2).astype(int)],1),1).astype(bool))
        days=np.asarray(ts[tr['origins']]//86400)
        weighting=[];support={}
        for part in ['fit','cal']:
            ix=tr[part];counts=np.unique(days[ix],return_counts=True)[1]
            support[part]={'origin_node_pairs':int(ix.sum()),'distinct_UTC_dates':len(counts),
                'largest_date_pair_fraction':float(counts.max()/counts.sum()),
                'concentration_effective_dates':float(counts.sum()**2/(counts.astype(float)**2).sum()),
                'note':'Concentration statistic, not an estimated independent-event sample size.'}
            for task,mask,label in [('hazard',risk,event),('postexit',post,cls)]:
                mask=mask[ix];label=label[ix];length=mask.sum(1);w=np.broadcast_to(1/np.maximum(length,1)[:,None],mask.shape)
                k=2 if task=='hazard' else 3
                for h in [None,*range(12)]:
                    active=mask.copy() if h is None else mask & (hs==h)
                    n=int(active.sum())
                    if not n:continue
                    yy=label[active].astype(int);ww=w[active]
                    weighting.append({'part':part,'task':task,'horizon':None if h is None else h+1,'cells':n,
                        'unweighted_class_frequency':(np.bincount(yy,minlength=k)/n).tolist(),
                        'training_weighted_class_frequency':(np.bincount(yy,weights=ww,minlength=k)/ww.sum()).tolist()})
        # If future duration determines weight, the weighted target can differ even at fixed X.
        synthetic={'two_identical_histories_exit_at_h1_or_no_exit':{'unweighted_h1_exit_rate':.5,
            'inverse_realized_duration_weighted_h1_exit_rate':1/(1+1/12)},
            'meaning':'Algebraic estimand check only. This is not runtime leakage and does not by itself explain the observed S3 failure.'}
        # Replay existing probability estimators on already used TRAIN calibration histories.
        temp={r['task']:r['temperature'] for row in gate.read(B/'spike_specialist_v7_20260930/TRAIN_CALIBRATION.json')['rows'] if row['seed']==20260813 and row['variant']=='CONTEXT' for r in row['fit_log']}
        def expand(x,d):return np.column_stack([np.repeat(x,12,0),np.tile(np.arange(1,13)/12,len(x)),(np.repeat(d,12)+np.tile(np.arange(1,13),len(x)))/288]).astype(np.float32)
        def temperature(v,t):
            v=np.log(np.maximum(v,1e-12))/t;v-=v.max(-1,keepdims=True);v=np.exp(v);return v/v.sum(-1,keepdims=True)
        cx=expand(tr['context'][tr['cal']],tr['duration'][tr['cal']]);calpred={}
        for task in ['hazard','postexit']:
            gate.guard();model=load(A/f'spike_specialist_v7_20260930/models/20260813_CONTEXT_{task}.pkl')['model']
            calpred[task]=temperature(model.predict_proba(cx),temp[task])
        cs=np.cumprod(1-calpred['hazard'][:,1].reshape(-1,12),1)
        cp=(1-cs[:,:,None])*calpred['postexit'].reshape(-1,12,3);cp[:,:,2]+=cs
        saved=read_np(A/'spike_specialist_v7_20260930/models/20260813_CONTEXT_probabilities.npz')
        assert np.allclose(cp,saved['calibration_probability'],rtol=1e-12,atol=1e-12)
        def scores(prob,labels):
            pp=prob.reshape(-1,3);yy=labels.ravel();one=np.eye(3)[yy]
            return {'brier':float(((pp-one)**2).sum(1).mean()),'logloss':float(-np.log(np.maximum(pp[np.arange(len(yy)),yy],1e-12)).mean()),
                    'mean_probabilities':pp.mean(0).tolist(),'observed_frequency':one.mean(0).tolist()}
        calibration=scores(cp,cls[tr['cal']])
        def atoms_from(mu,quantiles,ratio,sign):
            at=mu[...,None]+quantiles[None,:,:];at[:,0]=np.clip(at[:,0],-ratio[:,None],ratio[:,None])
            for k in [1,2]:
                sg=np.where(at[:,k]>=0,1.,-1.);sg=np.where(abs(at[:,k])<1e-12,sign[:,None],sg)
                at[:,k]=sg*np.clip(abs(at[:,k]),ratio[:,None] if k==1 else 1.,1. if k==1 else np.inf)
            return at
        def summary_functions(at,prob):
            flat=at.reshape(len(at),-1);w=np.broadcast_to(prob[:,:,None]/at.shape[2],at.shape).reshape(flat.shape)
            mean=(flat*w).sum(1);order=np.argsort(flat,axis=1);ss=np.take_along_axis(flat,order,1);cw=np.take_along_axis(w,order,1).cumsum(1)
            return mean,ss[np.arange(len(at)),np.argmax(cw>=.5,axis=1)]
        def correct(f,mean,median):
            a,b=mean-f,median-f;return f+.75*np.where(a*b>0,np.where(abs(a)<=abs(b),a,b),0.)
        output=[]
        for seed in [20260813,20260814,20260815]:
            gate.guard();raw=read_np(A/f'spike_specialist_v7_20260930/predictions/{seed}.npz')
            audited=read_np(A/f'spike_specialist_v7_20260930/audited/{seed}.npz')
            pd=read_np(A/f'spike_specialist_v7_20260930/models/{seed}_CONTEXT_probabilities.npz')
            ds=read_np(A/f'adaptive_experts_v5_20260929/models/{seed}_distributions.npz')
            mapping={int(k):j for j,k in enumerate(raw['eval_indices'])}
            use=np.array([int(k) in mapping for k in he['origin_index']])
            pos=np.array([mapping[int(k)] for k in he['origin_index'][use]]);nodes=he['node'][use];oi=he['origin_index'][use]
            truth=audited['truth'][pos,nodes];states=audited['states'][pos,nodes];labels=states-3
            assert (labels>=0).all() and (labels<3).all() and len(labels)*12==int((audited['states']>=3).sum())
            sv=pd['survival'][use];pp=pd['postexit'][use];hazard=pd['hazard'][use]
            assert np.allclose(sv,np.cumprod(1-hazard,1),rtol=1e-12,atol=1e-12)
            probs=(1-sv[:,:,None])*pp;probs[:,:,2]+=sv
            assert np.allclose(probs,raw['CONTEXT_probabilities'][pos,nodes],rtol=1e-12,atol=1e-12)
            actual_sv=np.cumprod((labels==2).astype(int),axis=1)
            one=np.eye(3)[labels]
            combinations={}
            for name,s,t in [('SAVED',sv,pp),('KNOWN_EXIT',actual_sv,pp),('KNOWN_POSTEXIT',sv,one),('KNOWN_BOTH',actual_sv,one)]:
                tmp=(1-s[:,:,None])*t;tmp[:,:,2]+=s;combinations[name]=tmp
            assert np.allclose(combinations['KNOWN_BOTH'],one)
            ratio=np.repeat(q[0,nodes]/q[1,nodes],12)
            sign=np.repeat(np.sign(he['context'][use,17]),12)
            at=atoms_from(ds['mus'][oi,nodes].reshape(-1,3),ds['quantiles'],ratio,sign)
            f=audited['FULL'][pos,nodes];v=audited['CONTEXT'][pos,nodes];shape=f.shape
            estimates={}
            for name,prob in combinations.items():
                m,med=summary_functions(at,prob.reshape(-1,3));m=m.reshape(shape)*q[1,nodes,None]+center[nodes,None];med=med.reshape(shape)*q[1,nodes,None]+center[nodes,None]
                pred=correct(f,m,med);estimates[name]=pred
                if name=='SAVED':
                    assert np.allclose(m,raw['CONTEXT_mean'][pos,nodes],rtol=1e-11,atol=1e-8)
                    assert np.allclose(med,raw['CONTEXT_median'][pos,nodes],rtol=1e-11,atol=1e-8)
                    assert np.allclose(pred,v,rtol=1e-11,atol=1e-8)
            delta=(v-truth)**2-(f-truth)**2;groups=[]
            for s in [3,4,5]:
                mask=states==s;harm=np.maximum(delta[mask],0);den=harm.sum()
                weighted=lambda a:float((a[mask]*harm).sum()/den) if den else None
                row={'state':s,'cells':int(mask.sum()),
                     'positive_harm_weighted_survival_probability':weighted(sv),
                     'positive_harm_weighted_recurrence_probability':weighted((1-sv)*pp[:,:,2]),
                     'counterfactual_error_metrics':{name:{'mae':float(abs(pr[mask]-truth[mask]).mean()),'rmse':float(np.sqrt(((pr[mask]-truth[mask])**2).mean()))} for name,pr in estimates.items()}}
                chosen=at[np.arange(len(at)),labels.ravel()]*np.repeat(q[1,nodes],12)[:,None]+np.repeat(center[nodes],12)[:,None]
                z=chosen.reshape(*shape,31)[mask];yt=truth[mask]
                row['true_state_component']={'mean_signed_bias':float((z.mean(1)-yt).mean()),
                    'truth_below_atom_support_fraction':float((yt<z.min(1)).mean()),
                    'truth_above_atom_support_fraction':float((yt>z.max(1)).mean())}
                groups.append(row)
            output.append({'seed':seed,'observed_extreme_pairs':len(pos),'probability_metrics':scores(probs,labels),'states':groups})
        for path,h in p['protected'].items():assert gate.sha(path)==h,path
        write('RESULT.json',dict(at=gate.now(),status='complete_fit_free_diagnostic',support=support,
            implementation_checks={'centering_equal':True,'target_classes_replayed':True,'risk_masks_replayed':True,'probability_sum_and_survival_replayed':True,'saved_calibration_and_predictions_replayed':True},
            training_weighting=weighting,synthetic_weighting_example=synthetic,calibration_scores=calibration,seeds=output,
            oracle_warning='Known-exit and known-state substitutions use realized development outcomes. They are impossible at runtime, are not model results and cannot update manuscript performance tables. Their differences are non-additive and not causal effects.',
            fits=0,new_test_targets_read=False,forecasts_modified=False,protected_files_verified=len(p['protected']),
            audit_scope='Reconstructed by separate code using saved intermediate arrays and current scalers; same operator, not external human review.',protocol_sha256=gate.sha(HERE/'PROTOCOL.json')))
        print(json.dumps({'status':'complete_fit_free_diagnostic','fits':0,'support':support,'first_seed_state_diagnosis':output[0]['states']}))

if __name__=='__main__':{'register':register,'run':run}[sys.argv[1]]()
