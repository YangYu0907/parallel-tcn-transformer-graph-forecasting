"""Finite frozen twenty-model evaluation queue with event-triggered terminal notification."""
import argparse,json,os,subprocess,sys,uuid
import gate
Q=gate.HERE/'queue'
def emit(event,**kw):
    v=dict(event=event,at=gate.now(),pid=os.getpid(),**kw)
    p=Q/'events'/(uuid.uuid4().hex+'.json');gate.write(p,v);gate.write(Q/'status.json',v,True);return p
def notify(kind,p):
    eid='mechanism_common_'+kind+'_'+gate.sha(p)
    out=gate.ROOT/'event_driven_automation/inbox'/(eid+'.json')
    body=dict(schema='caiso_research_event_v1',event_id=eid,event=kind,evidence_path=str(p),complete_research_experiment=False)
    if out.exists():gate.need(gate.read(out)==body,'Event collision')
    else:gate.write(out,body)
    return eid
def main(args):
    seal=gate.verify()
    if list((Q/'blocks').glob('*.json')):
        gate.need(args.resume_after_event is not None and (Q/'blocks'/(args.resume_after_event+'.json')).exists(),'Reviewed recovery event required')
    import psutil
    owner=dict(pid=os.getpid(),created=psutil.Process().create_time(),token=uuid.uuid4().hex)
    Q.mkdir(parents=True,exist_ok=True);lock=Q/'QUEUE.lock'
    with lock.open('x',encoding='utf-8') as f:json.dump(owner,f);f.flush();os.fsync(f.fileno())
    child=None
    plan=[]
    plan=[
        ('evaluate','evaluate.py',[],gate.HERE/'result.json','twenty_cases_scored_pending_audit'),
        ('audit','audit.py',[],gate.HERE/'numeric_audit.json','passed'),
        ('summary','summarize.py',[],gate.HERE/'summary.json','twenty_frozen_models_evaluated_and_audited')]
    try:
        for step,script,argv,marker,status in plan:
            gate.verify();gate.boundary()
            rp=Q/'steps'/(step+'.json')
            if rp.exists():
                r=gate.read(rp)
                gate.need(r['exit_code']==0 and r['seal_sha256']==gate.sha(gate.SEAL) and r['marker_sha256']==gate.sha(marker),'Completed receipt changed')
                continue
            gate.need(not marker.exists(),'Marker without completed exit receipt; review before recovery')
            gate.guard(True);gate.need(not gate.LOCK.exists(),'Another numerical worker active')
            cmd=[sys.executable,str(gate.HERE/script)]+argv
            out=Q/'logs'/(step+'_'+owner['token']+'.stdout.log')
            err=out.with_name(out.name.replace('stdout','stderr'));out.parent.mkdir(parents=True,exist_ok=True)
            with out.open('xb') as fo,err.open('xb') as fe:
                child=subprocess.Popen(cmd,cwd=gate.ROOT,stdout=fo,stderr=fe,creationflags=getattr(subprocess,'CREATE_NO_WINDOW',0))
                emit('step_process_started',step=step,child_pid=child.pid,command=cmd,stdout=str(out),stderr=str(err))
                code=child.wait()
            gate.need(code==0,f'{step} exited {code}; inspect {err}')
            gate.need(gate.read(marker)['status']==status,'Success marker invalid')
            gate.write(rp,dict(step=step,exit_code=code,at=gate.now(),seal_sha256=gate.sha(gate.SEAL),
                marker=gate.rel(marker),marker_sha256=gate.sha(marker),stdout=str(out),stderr=str(err)))
        complete=Q/'completion.json'
        gate.write(complete,dict(status='twenty_model_common_evaluation_and_audit_completed',at=gate.now(),
            seal_sha256=gate.sha(gate.SEAL),receipts={p.name:gate.sha(p) for p in (Q/'steps').glob('*.json')},
            summary_sha256=gate.sha(gate.HERE/'summary.json'),heldout_targets_read=False,complete_research_experiment=False))
        eid=notify('audited_result_ready',complete)
        emit('finite_sampling_queue_completed',scope='frozen_twenty_model_common_evaluation',completion_sha256=gate.sha(complete),event_id=eid)
        return 0
    except Exception as exc:
        paused=False
        try:gate.boundary()
        except InterruptedError:paused=True
        p=emit('user_stop' if paused else 'step_stopped_or_failed',reason=repr(exc),child_pid=child.pid if child else None)
        if not paused:
            eid=notify('blocking_failure',p)
            gate.write(Q/'blocks'/(eid+'.json'),dict(evidence=gate.rel(p),at=gate.now(),seal_sha256=gate.sha(gate.SEAL)))
            emit('step_stopped_or_failed',reason=repr(exc),event_id=eid,evidence_path=str(p))
        return 3 if paused else 2
    finally:
        if child and child.poll() is None:child.wait()
        gate.need(gate.read(lock)==owner,'Manager owner changed')
        gate.write(Q/'lock_releases'/(owner['token']+'.json'),dict(owner=owner,at=gate.now()));lock.unlink()
if __name__=='__main__':
    p=argparse.ArgumentParser();p.add_argument('--resume-after-event');raise SystemExit(main(p.parse_args()))

