"""Read-only numerical attribution: no fitting, new routing or held-out data."""
from common import *
import json

with gate.exclusive('adaptive_v2_user_requested_attribution_only'):
    np,lim=gate.runtime(False)
    audit=gate.read(HERE/'AUDIT.json')
    assert audit['status']=='passed' and audit['result_sha256']==gate.sha(HERE/'RESULT.json')
    p=gate.read(HERE/'PROTOCOL.json');m=gate.read(p['dataset_manifest'])
    paths={k:gate.resolve(v['path']) for k,v in m['artifacts'].items()}
    center=np.array(gate.read(paths['scalers.json'])['price_center'])[0,:,0]
    q=np.array(gate.read(paths['state_thresholds.json'])['thresholds'])
    with np.load(HERE/'feedback.npz') as z:
        cutoff=z['cutoff'];available=z['available']
    rows=[];coverage=[]
    for seed in p['seeds']:
        with np.load(HERE/'cache'/f'{seed}_experts.npz') as z:
            experts=z['experts'];truth=z['truth'];origins=z['origins']
        deviation=np.abs(truth-center[None,:,None])
        active=np.abs(experts[:,:,0,2]-center)>q[1]
        codes=(deviation>q[0][None,:,None]).astype(np.uint8)+(deviation>q[1][None,:,None]).astype(np.uint8)+3*active[:,:,None]
        bystate={s:[] for s in range(6)}
        for f in (1,2,3):
            with np.load(HERE/'folds'/f'{seed}_fold{f}.npz') as z:
                tr=z['train_indices'];ev=z['eval_indices'];w=z['JOINT4_weights'].astype(np.float64)
                pred=z['JOINT4'];cond=z['conditional'];unsupported=z['unsupported'];release=z['releases']
            sample=(tr[:,None]*360+np.arange(360)).reshape(-1)
            if len(sample)>96000:
                sample=np.sort(np.random.default_rng(seed+f*1000).choice(sample,96000,replace=False))
            sample_codes=codes.reshape(-1)[sample]
            sampled_origins=sample//360
            dates=cutoff.astype('datetime64[s]').astype('datetime64[D]')
            coverage.append(dict(seed=seed,fold=f,training_origins=len(tr),sampled_cells=len(sample),
                eligible_training_states=[dict(state=s,cells=int((codes[tr]==s).sum()),
                  dates=int(np.unique(dates[tr][(codes[tr]==s).any((1,2))]).size)) for s in range(6)],
                training_states=[dict(state=s,cells=int((sample_codes==s).sum()),
                  dates=int(np.unique(dates[sampled_origins[sample_codes==s]]).size)) for s in range(6)],
                evaluation_states=[dict(state=s,cells=int((codes[ev]==s).sum()),
                  dates=int(np.unique(dates[ev][(codes[ev]==s).any((1,2))]).size)) for s in range(6)]))
            anchor=.25+.5*unsupported[:,:,None]
            raw_weight=w.copy();raw_weight[:,:,:,0]-=anchor
            raw_weight/=(1-anchor)[:,:,:,None]
            # Recover pre-anchor ranking from saved weights. This does not generate predictions.
            predicted_best=raw_weight.argmax(-1)
            cond_best=np.maximum(cond,0).argmin(-1)
            ex=experts[ev];y=truth[ev];ef=ex[:,:,:,0]-y;en=pred-y;delta=pred-ex[:,:,:,0]
            assert np.allclose(en*en-ef*ef,2*ef*delta+delta*delta,rtol=1e-8,atol=1e-8)
            for s in range(6):
                mask=codes[ev]==s;n=int(mask.sum())
                if not n:continue
                xm=ex[mask];ym=y[mask];wm=w[mask];e=np.abs(xm-ym[:,None])
                bystate[s].append(dict(n=n,fold=f,
                    full_top_risk_count=int((predicted_best[mask]==0).sum()),
                    full_top_context_count=int((cond_best[mask]==0).sum()),
                    full_actual_best_count=int((e.argmin(-1)==0).sum()),
                    full_bias_sum=float(ef[mask].sum()),candidate_bias_sum=float(en[mask].sum()),
                    full_abs_sum=float(np.abs(ef[mask]).sum()),candidate_abs_sum=float(np.abs(en[mask]).sum()),
                    full_sse=float((ef[mask]**2).sum()),candidate_sse=float((en[mask]**2).sum()),
                    full_weight_sum=float(wm[:,0].sum()),
                    weighted_delta_by_expert=(wm*(xm-xm[:,:1])).sum(0).tolist(),
                    extra_sse_cross_term=float((2*ef[mask]*delta[mask]).sum()),
                    extra_sse_delta_term=float((delta[mask]**2).sum()),
                    unsupported_cells=int(np.broadcast_to(unsupported[:,:,None],y.shape)[mask].sum())))
        for s,parts in bystate.items():
            n=sum(d['n'] for d in parts)
            summed={k:sum(d[k] for d in parts) for k in parts[0] if k not in ('n','fold','weighted_delta_by_expert')}
            out=dict(seed=seed,state=s,count=n,**summed,
                weighted_delta_by_expert=np.sum([d['weighted_delta_by_expert'] for d in parts],0).tolist(),
                per_fold=parts)
            out.update(full_mean_weight=summed['full_weight_sum']/n,
                full_top_risk_fraction=summed['full_top_risk_count']/n,
                full_top_context_fraction=summed['full_top_context_count']/n,
                full_actual_best_fraction=summed['full_actual_best_count']/n,
                full_bias=summed['full_bias_sum']/n,candidate_bias=summed['candidate_bias_sum']/n,
                delta_MAE=(summed['candidate_abs_sum']-summed['full_abs_sum'])/n,
                delta_SSE=summed['candidate_sse']-summed['full_sse'])
            rows.append(out)
        guard()
    mean_states=[]
    for s in range(6):
        subset=[r for r in rows if r['state']==s]
        keep=['full_mean_weight','full_top_risk_fraction','full_top_context_fraction',
              'full_actual_best_fraction','full_bias','candidate_bias','delta_MAE','delta_SSE']
        mean_states.append(dict(state=s,count_per_seed=subset[0]['count'],
            **{k:float(np.mean([r[k] for r in subset])) for k in keep}))
    lag_minutes=(available-cutoff[:,None])/60.
    result=dict(at=gate.now(),status='attribution_of_recorded_predictions_only',
        scope='June development;3 seeds;fixed saved predictions. Descriptive attribution, not independent mechanism confirmation.',
        means=mean_states,per_seed=rows,meta_training_coverage=coverage,
        label_release_minutes_after_issuance=dict(median=float(np.median(lag_minutes)),
          p95=float(np.quantile(lag_minutes,.95)),maximum=float(lag_minutes.max())),
        fitted_models=0,new_prediction_rules=0,new_test_targets_read=False,
        result_sha256=gate.sha(HERE/'RESULT.json'),script_sha256=gate.sha(__file__))
    gate.write(HERE/'ATTRIBUTION.json',result)
    print(json.dumps(dict(means=mean_states,coverage_first_seed=coverage[:3],delay=result['label_release_minutes_after_issuance']),ensure_ascii=False))
