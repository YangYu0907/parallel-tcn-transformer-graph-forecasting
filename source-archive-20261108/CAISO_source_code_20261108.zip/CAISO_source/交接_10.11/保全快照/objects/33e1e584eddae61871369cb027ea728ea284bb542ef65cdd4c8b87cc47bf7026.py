"""Write complete evidence report and close this event without starting another fit."""
from core import *
import shutil
USER_EVENT='0a9b8ccb77421ffa9c5280df28da3cdfd408d62195e198a75d3c121c5c91b985'
EMITTER='integrated_regime_needs_analysis_fe3b228b5edb255b7a5ead3bbdb7a3e1d37c76217206eb0a4281eee67a38be9e'
def main():
    verify()
    r=read(HERE/'RESULT.json');a=read(HERE/'AUDIT.json');diag=read(HERE/'POSTHOC_DIAGNOSIS.json')
    attr=read(HERE/'ROUTING_ATTRIBUTION.json');inter=read(HERE/'SUPPORT_INTERVENTION.json');st=read(HERE/'STATISTICS.json')
    event=read(B/'event_driven_automation'/'inbox'/(EMITTER+'.json'))
    assert event['evidence_sha256']==sha(HERE/'AUDIT.json')
    assert a['result_sha256']==sha(HERE/'RESULT.json') and a['statistics_sha256']==sha(HERE/'STATISTICS.json')
    assert attr['source_diagnosis_sha256']==sha(HERE/'POSTHOC_DIAGNOSIS.json')
    assert attr['support_intervention_sha256']==sha(HERE/'SUPPORT_INTERVENTION.json')
    at=now()
    nextplan=dict(at=at,status='designed_not_launched_no_automatic_queue_expansion',
        basis='Completed original finite queue plus one no-fit support intervention. Preserve V7 and all original evidence.',
        established_facts=[
            'Overall MAE and H12 improve on matched FULL; three router seeds are not independent backbone replications.',
            'In S3 H8-H12, 83.59% of cells have neither added expert pointing toward truth from FULL.',
            'The ordinary class head violates its prefix-defined class interval in 43.11% of S3 tail cells; repairing this alone has negligible aggregate effect.',
            'S2 tail loss increase comes mainly from iTransformer contribution; S3 loss increases from both; S4 MSE increase mainly from iTransformer.',
            'Risk probabilities as explicit router inputs do not show significant incremental MAE benefit against NO_RISK.',
            'Nominal90% interval coverage is87.71%; down-side probability has rare high-confidence false alarms.'],
        point_next_matched_control=dict(hypothesis='A current-extreme persistence-versus-recovery predictor plus support-consistent absolute-price recovery head may reduce S3/S4 overshoot.',
            information='Current-extreme gate uses only history and earlier-prefix thresholds. Future regime may label training data, never select a deployed expert.',
            arms=['retained integrated COMPLETE','ordinary-head correction only','transition-aware correction with same corrected head'],
            fixed_parts='FULL, iTransformer, H1-H7, current-nonextreme point outputs and all V7 artifacts; compare all seed/regime/horizon directions.',
            training_design='Fresh chronological out-of-prefix correction predictions; matched fitting sample/order/budget; no future-informed router training. Freeze exact parameters before fits.',
            expected_benefit='Targets observed extrapolation and persistence/recovery confusion rather than generic architecture capacity.',
            tradeoff='Earlier recovery can underpredict genuinely persistent spikes S5. Preserving current-nonextreme outputs also leaves S2 onset errors unchanged.',
            decision='Must improve on existing COMPLETE and retain positive directions; insufficient state support is not success. No thresholds chosen on already inspected forward outcomes.',
            confirmation='New independent period and three independent backbone seeds still required for manuscript replacement.'),
        interval_next_matched_control=dict(method='Time-adaptive conformal calibration vs fixed CQR with identical saved point forecasts',
            prereq='Verify label release/version and maturity before each calibration update; available truth is not inferred only from delivery timestamps.',
            benefit='Could improve realized marginal coverage with no point forecast changes.',
            cost='Potentially wider intervals; long-time coverage theory does not guarantee all-state coverage or lower point error.',
            currently_started=False),
        literature=[
            dict(title='Janczura and Weron, Energy Economics32 (2010)1059-1073',url='https://www.sciencedirect.com/science/article/abs/pii/S0140988310000885',
                 inspected='Publisher abstract, introduction and method snippets',support='Different base/spike/drop dynamics and state transitions; no guarantee of forecast dominance.'),
            dict(title='Christensen, Hurn and Lindsay, International Journal of Forecasting28 (2012)400-411',url='https://eprints.gla.ac.uk/38583/',
                 inspected='Author institution abstract; attempted working-paper PDF fetch failed',support='Separate spike-occurrence probability task; our recovery implementation is not copied or proven by that paper.'),
            dict(title='Gibbs and Candes, NeurIPS2021, Adaptive Conformal Inference Under Distribution Shift',
                 url='https://proceedings.neurips.cc/paper/2021/hash/0d441de75945e5acbc865406fc9a2559-Abstract.html',
                 inspected='Official abstract',support='Online adaptation of interval coverage; delayed labels must be handled explicitly here.'),
            dict(title='Montero-Manso et al., FFORMA, International Journal of Forecasting',url='https://robjhyndman.com/papers/fforma.pdf',
                 inspected='Author PDF',support='Feature-based forecast combination; does not guarantee it beats fixed averaging.'),
            dict(title='Cawley and Talbot, JMLR2010',url='https://jmlr.org/papers/v11/cawley10a.html',
                 support='Repeated development selection must be distinguished from independent confirmation.')],
        new_test_targets_read=False,V7_replaced=False,periodic_model_wakeups=False)
    write(HERE/'NEXT_MATCHED_CONTROL.json',nextplan)
    lines=['整合式实验：完整结果与事件处理报告',at,'',
        '结论：整体和60分钟预测取得开发期改善；未通过全部状态不回退的登记门槛。保留V7，未替换论文主结果。',
        '队列完成不等于全研究完成。本次处理没有新增训练；只做了无拟合归因和一次预登记的范围一致性干预。',
        '',
        '一、完成与核验',
        '原队列：6次新骨干拟合、27个专家/分位数头、9次路由拟合，数值预算15496.125秒（约4.30小时）。',
        '原结果779项独立算术/抽样推理复核通过；本次干预另有84项算术检查。两者均为同一操作者的单独程序核验，非外部人工评审。',
        '18项V7/论文保护文件哈希仍一致。管理进程按记录正常结束，未有训练进程；旧PID22000已被其他应用复用，不能将PID存在误认成训练仍在运行。',
        '本地事件监听器PID5216保留。无定时模型唤醒，无新测试目标读取。',
        '',
        '二、比较范围',
        '前向历史开发：2025年1—5月，1387起点、81个UTC日期、30节点、12步；来源是既有历史TRAIN池。',
        '元学习拟合2024年7—9月；校准2024年10—12月；各阶段专家仅用更早训练前缀。信息集为同样的288步历史价格。',
        '下表为三个路由初始化的误差均值；只有一个骨干种子。不是三个独立骨干重复，也不是V7旧698起点面板或新的独立测试。',
        'H1—H7与本轮匹配FULL逐值相同；这一保证不等于新模型与V7跨面板性能一致。',
        '',
        '三、总体均值（USD/MWh；改善率=(FULL-新系统)/FULL）',
        '指标 | FULL | COMPLETE三路由种子均值 | 改善率']
    for k,label in [('mae','总体MAE'),('rmse','总体RMSE'),('near_mae','5—20分钟MAE'),('h12_mae','60分钟MAE')]:
        q=diag['headline'][k];pct=0. if k=='near_mae' else q['improvement_pct']
        lines.append(f"{label} | {q['FULL']:.6f} | {q['COMPLETE_mean']:.6f} | {pct:.4f}%")
    lines+=['','四、完整点预测比较（所有方向均保留）','模型 | MAE | RMSE | 近端MAE | H12MAE']
    for row in r['rows']:
        lines.append(row['model']+' | '+' | '.join(f"{row[k]:.6f}" for k in ['mae','rmse','near_mae','h12_mae']))
    lines+=['所有_CHECKED模型因校准状态门槛失败而保持FULL，表中的原始COMPLETE改善不能冒称通过保护门槛后的部署收益。',
        '','五、S0—S5均值','状态 | 单元数/日期数 | FULL MAE/RMSE | 新系统MAE/RMSE | MAE/RMSE改善率']
    for q in diag['states']:
        lines.append(f"S{q['state']} | {q['FULL']['cells']}/{q['dates']} | {q['FULL']['mae']:.6f}/{q['FULL']['rmse']:.6f} | {q['COMPLETE_mean']['mae']:.6f}/{q['COMPLETE_mean']['rmse']:.6f} | {q['improvement_pct']['mae']:.4f}%/{q['improvement_pct']['rmse']:.4f}%")
    lines+=['S0—S2为当前未极端、未来分别普通/较高偏离/极端；S3—S5为当前已极端、未来分别普通/较高偏离/仍极端。阈值来自更早训练。',
        '日期不是独立事件数，节点与重叠预测单元不能用来扩充独立样本数。',
        '','六、配对时间块统计（探索性）',st['method'],'对照 | 对照MAE减新系统MAE | 95%区间 | Holm p']
    for row in st['rows']:
        lines.append(f"{row['control']} | {row['mae_difference']:.6f} | [{row['ci95'][0]:.6f},{row['ci95'][1]:.6f}] | {row['holm_p']:.6f}")
    lines+=['新系统相对FULL与NO_SPIKE有总体MAE增益；相对FIXED50、NO_RISK未达到本检验族显著标准。不能据此声称自适应路由已经全面优于固定组合。',
        '这些p值只属于总体MAE比较；不外推为H12、每种状态或所有指标显著。',
        '','七、概率区间','模型/方式 | WIS | 90%覆盖率/宽度 | 80%覆盖率/宽度']
    for row in r['probability']:
        u,v=row['intervals']
        lines.append(f"{row['model']}/{row['method']} | {row['wis']:.6f} | {u['coverage']*100:.3f}%/{u['width']:.6f} | {v['coverage']*100:.3f}%/{v['width']:.6f}")
    lines+=['完整系统CQR均值WIS4.674840，相对同点预测经验区间的5.191693降低9.955%；名义90%与80%区间实际覆盖87.706%、77.726%，覆盖仍不足。',
        '概率区间已实现和评价，不等于校准问题已解决。WIS使用当前点预测作为中心项，各模型口径相同。',
        '上侧尖峰：Brier0.003835，常数先验0.004561；PR-AUC0.341441，发生率0.004556。',
        '下侧尖峰：Brier0.000596875，常数先验0.000362368，仍较差。高概率档204单元，平均预测98.86%，实测仅18.63%；这是过度自信证据，不是整体模型不识别任何尖峰。',
        '','八、深入归因与实际完成的有限核验',
        '1. S3的40—60分钟共有457单元；83.59%中两个新增专家都不能把FULL预测往真实值方向拉回。该诊断用真值事后计算，绝不作为部署路由。',
        '2. 此范围常规专家43.11%输出越出自身以训练阈值定义的普通状态区间，体现条件幅度外推不一致；不等于训练样本整体最小/最大范围。',
        '3. 已登记并完成一次无拟合干预：仅将普通条件均值投影回该区间，固定概率、极端头、路由权重与H1—H7。前向平均MAE仅从7.790226到约7.790177；S5的RMSE仍轻微回退。未通过门槛，不采用。',
        '4. 精确误差分解说明，S2尾部MAE回退主要来自iTransformer增量；S3两个专家都贡献额外误差；S4的MSE增加主要来自iTransformer。',
        '5. S4的2025-04-20仅11个单元产生约267542的额外平方误差，超过该状态净增加，其他日期部分抵消。该日期保留，不删样本；它说明少数高估影响RMSE，但不能单独归结市场机制。',
        '6. S5中941/1220个单元落在固定不改的H1—H7；既有保护也限制了整类改善空间。不能为了更好数字静默放弃保护。',
        '7. 仅普通输出限幅的微小效果排除了其作为充分修复的解释。更合理的待检验原因是尖峰持续/回落识别和新增专家预测方向不足；尚未证明是哪项市场外生因素造成。',
        '','九、老师五项意见目前对应情况',
        '动态图跨数据集优势：本轮没有新增STATIC/SELF匹配验证，未解决。',
        '输入公平性：本轮FULL与iTransformer等统一历史价格信息；解决了这轮比较口径，不能追溯声称旧论文所有比较已改成同输入。',
        'V7校正模块拆分：本轮完成新增系统NO_SPIKE、NO_RISK对照；不等于原V7所有小模块的完整拆分已补齐。',
        '尖峰：上侧概率、持续尖峰状态部分改善；S2、S3、S4仍有回退，未彻底解决。',
        '概率预测：80/90%区间、风险概率、WIS与覆盖比较已完成；跨期覆盖和下侧风险校准仍需改进。',
        '','十、下一项有限匹配对照与收益代价',
        '优先检验历史可观测的当前极端状态下，尖峰持续/回落分类与有范围约束的绝对价格回落头；对照原COMPLETE及仅改幅度头。保持骨干、当前非极端输出、H1—H7和V7不变。',
        '收益假设：减少回落时错误延续高价。代价：过早判断回落会伤害持续尖峰S5；限制当前极端分支也不会改善S2新尖峰。不得保证全优。',
        '区间单独考虑自适应共形校准，对照固定CQR；只在真实已发布且成熟的标签可核验时更新。可能扩大区间；不改变点预测，也不保证每种状态覆盖。',
        '这些对照已写为NEXT_MATCHED_CONTROL.json设计文件，未启动新训练。原有限队列不自动扩容。独立测试准入、骨干三种子和V7同面板比较仍是发布新版的条件。',
        '','文献与查阅范围：']
    for lit in nextplan['literature']:
        lines += [lit['title'],lit['url'],lit.get('inspected','本研究先前已核验')+'；'+lit['support']]
    lines+=['','原结果和完整逐种子状态值：RESULT.json；统计：STATISTICS.json；概率：PROBABILITY_REPLAY.npz。',
        '本次归因：POSTHOC_DIAGNOSIS.json、ROUTING_ATTRIBUTION.json；单项干预：SUPPORT_INTERVENTION_PROTOCOL.json、SUPPORT_INTERVENTION.json。',
        '正文润色暂缓；不因有限队列完成而标记整项研究完成。']
    report=HERE/'REPORT_CN.txt';tmp=HERE/('.r'+uuid.uuid4().hex[:10]+'.tmp');tmp.write_text('\n'.join(lines),encoding='utf-8');os.replace(tmp,report)
    closure=dict(at=at,status='finite_integrated_experiment_analyzed_not_promoted',event_id=EMITTER,user_event_id=USER_EVENT,
        main_audit_checks=779,posthoc_intervention_arithmetic_checks=84,external_human_review=False,
        main_training_seconds=read(HERE/'BUDGET.json')['seconds'],new_fits_this_analysis=0,
        screen_passed=False,V7_replaced=False,new_test_targets_read=False,protected_files=verify_protected(),
        current_numeric_process=None,event_listener_pid=5216,periodic_model_wakeups=False,research_completed=False,
        retained_files={n:sha(HERE/n) for n in ['RESULT.json','AUDIT.json','STATISTICS.json','POSTHOC_DIAGNOSIS.json','ROUTING_ATTRIBUTION.json','SUPPORT_INTERVENTION.json','REPORT_CN.txt','NEXT_MATCHED_CONTROL.json']},
        manager_exit_evidence=str(B/'event_driven_automation/process_monitors/sampling_exit_22000_639266360160977869.exit.json'),
        process_note='Original manager22000 exited; that PID is now an unrelated biz_helper.exe. Process identity checked, no unrelated process stopped.')
    write(HERE/'CLOSURE.json',closure)
    hpath=B/'HANDOFF.json';backup=HERE/'HANDOFF_BEFORE_RESULT_ANALYSIS.json'
    if not backup.exists():shutil.copy2(hpath,backup)
    h=read(hpath)
    stage='Integrated historical experiment analyzed: aggregate/H12 improvement, state and interval calibration gates not passed; V7 retained; no active numeric worker'
    h.update(current_stage=stage,current_work_status='finite_integrated_analysis_completed',latest_status='integrated_analyzed_not_promoted',
             status='integrated_analyzed_not_promoted',research_training_active=False,numeric_diagnostic_active=False,training_active=False,
             current_process=None,ongoing_numeric_process=None,active_queue_status=None,live_status=None,
             manuscript_polishing_paused=True,complete_research_experiment=False,event_listener_pid=5216,
             current_authorized_work='Completed integrated historical development, no-fit attribution and one support-consistency check; next matched controls designed, not launched; independent qualification pending.')
    h['next_actions']=[
        'Use REPORT_CN and complete RESULT matrix; no replacement of V7 or original paper results.',
        'Before any new fitting, freeze the bounded persistence/recovery-head control and matched budget; no further scalar weight or clipping search.',
        'Qualify independent future sources and label availability; add backbone seed replication and a same-panel V7 comparison before claiming a new final model.',
        'If interval calibration is run, bind label release/maturity before online updates and retain identical point forecasts.',
        'Keep local event listener; register identity-bound exit monitor for every future manager; no periodic wakeups.']
    entry=h['reviewer_integrated_regime_20261003']
    entry.update(status='completed_analyzed_not_promoted',numeric_active=False,manager_pid=None,exit_monitor_pid=None,
        result=str(HERE/'RESULT.json'),audit=str(HERE/'AUDIT.json'),report=str(report),diagnosis=str(HERE/'POSTHOC_DIAGNOSIS.json'),
        closure=str(HERE/'CLOSURE.json'),next_control=str(HERE/'NEXT_MATCHED_CONTROL.json'),
        last_manager_pid=22000,screen_passed=False,whole_research_complete=False,
        latest_delivery_ack=str(HERE/'EVENT_RESULT_HANDLED.json'),numeric_seconds=closure['main_training_seconds'])
    for key in ['event_automation','event_driven_automation']:
        entry=h.get(key,{})
        entry.update(current_at=at,mode='local_OS_events_only',watcher_pid=5216,manager_pid=None,bridge_pid=None,
                     exit_bridge_pid=None,manager_exit_watcher_pid=None,current_exit_monitor=None,
                     status='listening_for_real_new_events_no_active_training',periodic_model_wakeup=False,
                     research_training_active=False,last_check='watch.ps1 PID5216 identity verified; original manager exited and lock absent; no duplicate run')
        h[key]=entry
    ids=h.setdefault('handled_event_ids',[])
    for eid in [USER_EVENT,EMITTER]:
        if eid not in ids:ids.append(eid)
    ack=dict(at=at,event_id=EMITTER,user_event_id=USER_EVENT,status='analyzed_and_reported_once',
             event_sha256=sha(B/'event_driven_automation/inbox'/(EMITTER+'.json')),evidence_sha256=sha(HERE/'AUDIT.json'),
             closure=str(HERE/'CLOSURE.json'),report=str(report),duplicate_training_started=False,notification_reemitted=False)
    write(HERE/'EVENT_RESULT_HANDLED.json',ack);h['last_handled_event']=ack
    write(hpath,h)
    assert verify_protected()==18 and all(sha(HERE/n)==v for n,v in closure['retained_files'].items())
    print(json.dumps(dict(status=closure['status'],report=str(report),event_handled=True,protected_files=18),ensure_ascii=False))
if __name__=='__main__':main()

