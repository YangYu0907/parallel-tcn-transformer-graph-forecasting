"""Separate scoring implementation; saved predictions only, no fitted predictor called."""
import support as s
import numpy as np,hashlib,json
from sklearn.metrics import average_precision_score
ARMS=['EXISTING','WEATHER','WEATHER_INTERACTION']

def counts(y,p,alarm,dates,eventtime):
 y=y.astype(bool);pp=np.clip(p,1e-12,1-1e-12);tp=int(np.sum(y&alarm));fp=int(np.sum(~y&alarm));events=int(y.sum())
 times=np.unique(eventtime[y]);clusters=int(1+np.sum(np.diff(times)>3600)) if len(times) else 0
 return dict(n=len(y),events=events,event_dates=int(len(np.unique(dates[y]))),event_clusters=clusters,alerts=int(alarm.sum()),TP=tp,FP=fp,
  prevalence=float(y.mean()),precision=tp/(tp+fp) if tp+fp else None,recall=tp/events if events else None,FPR=float(alarm[~y].mean()) if (~y).any() else None,
  brier=float(np.mean((p-y)**2)),logloss=float(np.mean(-y*np.log(pp)-(~y)*np.log1p(-pp))),AP=float(average_precision_score(y,p)) if events else None)

def main(tick):
 p=s.verify();source=s.read(s.N/'SOURCE_ADMISSION.json');assert source['source_gate_passed'];bindings=0;bytecount=0
 for f in (s.N/'objects').glob('*.json'):
  r=s.read(f);raw=f.with_suffix('.bin').read_bytes();assert hashlib.sha256(raw).hexdigest()==r['sha256'];assert hashlib.md5(raw).hexdigest()==r['etag'];bindings+=1;bytecount+=len(raw)
 with np.load(s.N/'weather.npz') as z:mask=z['admitted'];cutoff=z['cutoff'];available=z['available'];origins=z['origins']
 assert np.all(available[mask]<=cutoff[mask]);assert s.sha(s.N/'weather.npz')==source['weather_sha256']
 for i in np.flatnonzero(mask):
  r=s.read(s.N/'cycles'/f'{i:04d}.json');assert r['admitted'];assert r['cutoff']==int(cutoff[i]);assert r['cycle']==int((cutoff[i]//3600-3)*3600)
  times=[]
  for key in r['receipt_keys']:
   rr=s.read(s.N/'objects'/(hashlib.sha256(key.encode()).hexdigest()[:32]+'.json'));times.append(rr['last_modified'])
  assert max(times)==available[i] and max(times)<=cutoff[i]
 tick(stage='independent_probability_scoring',bound_source_objects=bindings)
 result=s.read(s.N/'FIT_COMPLETE.json');pieces=[];checks=0
 for f in result['folds']:
  assert f['fit_last_available']<f['calibration_first_cutoff'] and f['calibration_last_available']<f['evaluation_first_cutoff'];checks+=2
  with np.load(s.N/f"fold{f['fold']}.npz") as z:d={k:z[k] for k in z.files if not k.startswith('CAL_')}
  assert np.array_equal(d['ids'],f['evaluation']);assert np.all(mask[d['ids']])
  for arm in ARMS:
   assert s.sha(s.N/'models'/f"f{f['fold']}_{arm}.pkl")==f['arms'][arm]['model_sha'];checks+=1
   prob=d[arm];assert np.isfinite(prob).all() and np.all(prob>=0) and np.all(prob.sum(-1)<=1+1e-10) and np.all(np.diff(prob,axis=2)>=-1e-10)
   threshold=np.array(f['arms'][arm]['alarm_thresholds']);assert np.array_equal(d['ALARM_'+arm],prob>threshold[None,None])
  pieces.append(d)
 data={k:np.concatenate([d[k] for d in pieces]) for k in pieces[0] if not k.startswith('cal_')}
 assert len(np.unique(data['ids']))==len(data['ids']);nm=data['normal'];dates=np.broadcast_to((data['cutoff']//86400)[:,None],nm.shape)[nm]
 eventtime=(data['cutoff'][:,None]+(data['tau']+1)*300)[nm];nodes=np.broadcast_to(np.arange(30)[None],nm.shape)[nm]
 rows=[];losses={};node_rows=[]
 for arm in ARMS:
  for h in range(12):
   for side in [1,2]:
    y=((data['tau']<=h)&(data['kind']==side))[nm];prob=data[arm][:,:,h,side-1][nm];alarm=data['ALARM_'+arm][:,:,h,side-1][nm]
    m=counts(y,prob,alarm,dates,eventtime);rows.append(dict(arm=arm,horizon=h+1,side=side,**m))
    if h==11:
     pp=np.clip(prob,1e-12,1-1e-12);losses[arm,side,'brier']=(prob-y)**2;losses[arm,side,'logloss']=-y*np.log(pp)-(~y)*np.log1p(-pp)
     for node in range(30):
      ii=nodes==node;node_rows.append(dict(arm=arm,node=node,side=side,**counts(y[ii],prob[ii],alarm[ii],dates[ii],eventtime[ii])))
 # Calendar-aligned 3-day clusters; gaps are never concatenated into adjacent observations.
 blocks=np.unique(dates//3);rng=np.random.default_rng(20261004);draw=rng.integers(0,len(blocks),size=(2000,len(blocks)));sizes=np.array([np.sum(dates//3==b) for b in blocks]);stats=[]
 for arm in ARMS[1:]:
  for side in [1,2]:
   for metric in ['brier','logloss']:
    delta=losses['EXISTING',side,metric]-losses[arm,side,metric];sums=np.array([delta[dates//3==b].sum() for b in blocks]);est=float(delta.mean());boot=sums[draw].sum(1)/sizes[draw].sum(1)
    pv=float((1+np.sum(abs(boot-est)>=abs(est)))/(len(boot)+1));stats.append(dict(arm=arm,side=side,metric=metric,positive_means_candidate_improves=est,CI95=np.quantile(boot,[.025,.975]).tolist(),p=pv,calendar_blocks=len(blocks)))
 order=np.argsort([r['p'] for r in stats]);prev=0.
 for rank,j in enumerate(order):prev=max(prev,min(1.,stats[j]['p']*(len(stats)-rank)));stats[j]['p_holm']=prev
 headline={arm:{str(side):next(r for r in rows if r['arm']==arm and r['horizon']==12 and r['side']==side) for side in [1,2]} for arm in ARMS}
 candidate=headline['WEATHER_INTERACTION'];base=headline['EXISTING'];screen={}
 for side in ['1','2']:
  c,b=candidate[side],base[side]
  screen[side]=dict(brier=c['brier']<b['brier'],logloss=c['logloss']<b['logloss'],precision=c['precision'] is not None and b['precision'] is not None and c['precision']>=b['precision'],recall=c['recall'] is not None and b['recall'] is not None and c['recall']>=b['recall'],FPR=c['FPR']<=.02,support=c['event_dates']>=5 and c['event_clusters']>=5)
 passed=all(all(v.values()) for v in screen.values());statistical=passed and all(r['p_holm']<.05 and r['positive_means_candidate_improves']>0 for r in stats if r['arm']=='WEATHER_INTERACTION')
 out=dict(at=s.now(),status='matched_information_experiment_completed',screen_passed=passed,statistical_increment_supported=statistical,screen=screen,
  source=source,fit_count=result['fits'],evaluated_origins=len(data['ids']),normal_origin_node_pairs=int(nm.sum()),unique_UTC_dates=int(len(np.unique(dates))),H12=headline,all_horizons=rows,nodes_H12=node_rows,comparisons=stats,
  candidate='WEATHER_INTERACTION declared before fitting; WEATHER is diagnostic arm, not fallback candidate selected by scores',
  new_test_targets_read=False,V7_replaced=False,point_error_improvement_established=False,physical_graph_test_done=False,tail_model_fitted=False,
  next='Consider conditional tail and fresh independent confirmation only after reviewing information support; no automatic weight/threshold search')
 s.write('RESULT.json',out);s.write('AUDIT.json',dict(at=s.now(),type='Separate implementation by same agent, not external human review',source_objects_rehashed=bindings,bytes_rehashed=bytecount,metadata_cutoffs_recomputed=int(mask.sum()),fit_and_model_checks=checks,paired_common_panel=True,chronological_purge=True,probability_mass_and_monotonicity=True,calibration_alarm_replay=True,all_protected_files_unchanged=True,all_conditions_pass=True))
 s.save('scoring.npz',**data)
 return out
