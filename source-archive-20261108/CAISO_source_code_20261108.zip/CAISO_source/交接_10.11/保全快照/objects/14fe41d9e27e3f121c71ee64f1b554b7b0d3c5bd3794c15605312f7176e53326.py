from support import *
import ast
assert not (N/'MANAGER.lock').exists()
assert not (N/'local/20260813/latest.pt').exists()
p=read(N/'PROTOCOL.json');key=str(N/'experiment.py')
assert c.sha(N/'experiment.before_schedule_fix.py')==p['bindings'][key]
ast.parse((N/'experiment.py').read_text(encoding='utf-8'))
old=p['bindings'][key];p['bindings'][key]=c.sha(N/'experiment.py')
p['implementation_repairs']=[dict(at=c.now(),reason='CompiledData default train list is2016base origins; explicitly activate already registered epoch1 additive4032schedule before caching. No model had been fitted; declared4032budget retained.',old_sha=old,new_sha=p['bindings'][key],failed_cache_preserved='local/20260813/train_base2016_preserved.npz',new_or_changed_hyperparameters=False)]
p['local_head']['train']='4032origins from already registered ADDITIVE epoch1 schedule; explicitly selected before caching'
write('PROTOCOL.json',p);write('SCHEDULE_REPAIR.json',p['implementation_repairs'][0])
print('Corrected schedule before all new fitting; protocol and failed cache preserved.')
