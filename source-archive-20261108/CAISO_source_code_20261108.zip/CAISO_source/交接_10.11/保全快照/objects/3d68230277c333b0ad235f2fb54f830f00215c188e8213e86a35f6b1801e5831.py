"""Restart-only resource-floor preservation; the sealed training queue is unchanged."""
import argparse
import hashlib
import json
import sys
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
TARGET = "control_backbone_20260814_CONCAT"
FLOOR = 8.240825653076172
EVIDENCE = ROOT / "post_backbone_queue_io_v2/events/e75490743e884fd4aeeb1d81fa7f4ff3.json"

def retained_required(step, required):
    return max(float(required), FLOOR) if step["id"] == TARGET else required

def visible_event(name, values):
    values = dict(values)
    if name in ("waiting_for_resource_boundary", "known_resource_guard_waiting_with_state_preserved") and values.get("step") == TARGET:
        values["required_GiB"] = max(float(values["required_GiB"]), FLOOR)
        values["retained_pre_reboot_resource_guard"] = str(EVIDENCE)
    return values

def main():
    global FLOOR
    parser = argparse.ArgumentParser()
    parser.add_argument("action", choices=("run", "self-test"))
    parser.add_argument("--queue-source")
    args = parser.parse_args()
    if args.action == "self-test":
        checks = [
            retained_required({"id": TARGET}, 5) == FLOOR,
            retained_required({"id": TARGET}, 9.0) == 9.0,
            retained_required({"id": "other"}, 1.0) == 1.0,
            visible_event("waiting_for_resource_boundary", {"step": TARGET, "required_GiB": 5})["required_GiB"] == FLOOR,
            visible_event("step_process_started", {"step": TARGET, "index": 106}) == {"step": TARGET, "index": 106},
            visible_event("waiting_for_resource_boundary", {"step": "other", "required_GiB": 1}) == {"step": "other", "required_GiB": 1},
        ]
        if not all(checks):
            raise RuntimeError("Resource-floor preservation QA failed")
        print(json.dumps({"status": "passed", "checks": len(checks), "training_started": False}))
        return 0
    expected = ROOT / "source/post_backbone_queue.py"
    if not args.queue_source or Path(args.queue_source).resolve() != expected.resolve():
        raise RuntimeError("Exact original queue source is required")
    evidence = json.loads(EVIDENCE.read_text(encoding="utf-8-sig"))
    if (evidence["event"] != "known_resource_guard_waiting_with_state_preserved"
            or evidence["step"] != TARGET or evidence["required_GiB"] != FLOOR):
        raise RuntimeError("Original retry-floor evidence differs")
    # Carry forward any later escalation too, if another Windows restart occurs.
    for path in (ROOT / "post_backbone_queue_io_v2/events").glob("*.json"):
        row = json.loads(path.read_text(encoding="utf-8-sig"))
        if row.get("step") == TARGET and row.get("event") in (
                "waiting_for_resource_boundary", "known_resource_guard_waiting_with_state_preserved"):
            required = float(row["required_GiB"])
            if not 0 < required < 1024:
                raise RuntimeError("Invalid retained resource floor")
            FLOOR = max(FLOOR, required)
    sys.path.insert(0, str(ROOT / "source"))
    import post_backbone_queue as original
    prior_resource_ready = original.resource_ready
    prior_event = original.event
    def resource_ready(step, required):
        return prior_resource_ready(step, retained_required(step, required))
    def event(name, **values):
        return prior_event(name, **visible_event(name, values))
    original.resource_ready = resource_ready
    original.event = event
    print(json.dumps({"event": "pre_reboot_resource_floor_retained", "floor_GiB": FLOOR,
                      "only_step": TARGET, "original_training_sources_changed": False,
                      "recovery_source_sha256": hashlib.sha256(Path(__file__).read_bytes()).hexdigest()}), flush=True)
    return original.run()

if __name__ == "__main__":
    sys.exit(main())