"""Read-only graph/feature diagnostics on original TRAIN or VALID inputs."""
from pathlib import Path
import sys,time,importlib.util,json,gc
HERE=Path(__file__).resolve().parent;ROOT=HERE.parent
sys.path.insert(0,str(ROOT/'context_expert_v1_20260929'))
import gate


def module(name,path):
    spec=importlib.util.spec_from_file_location(name,path);obj=importlib.util.module_from_spec(spec);sys.modules[name]=obj;spec.loader.exec_module(obj);return obj


def main():
    output=HERE/'STRUCTURE_PROBE.json'
    if output.exists():raise RuntimeError('Diagnostic already completed')
    protocol_path=HERE/'STRUCTURE_PROBE_PROTOCOL.json'
    caiso_seal=gate.read(ROOT/'budget_mechanisms_v1_20260925/EXECUTION_LOCK.json')
    protected=gate.read(HERE/'RETAINED_BASELINE_HASHES.json')['files']
    for p,h in protected.items():assert gate.sha(p)==h,p
    checkpoints=[]
    for seed in (20260813,20260814,20260815):
        for variant in ('FULL','CONCAT','EQUAL'):
            folder=ROOT/('budget_extension_v1_20260925' if variant=='FULL' else 'budget_mechanisms_v1_20260925')/'runs'/f'{seed}_{variant}'
            cp=ROOT/gate.read(folder/'completion.json')['selected_checkpoint']
            assert gate.read(folder/'audit.json')['status']=='passed'
            assert gate.sha(cp)==gate.read(cp.with_suffix('.receipt.json'))['sha256']
            checkpoints.append((seed,variant,cp))
    e=ROOT/'energy_confirmation_v1_20260926'
    files=[Path(__file__),ROOT/caiso_seal['dataset_manifest'],ROOT/caiso_seal['train_diagnostic'],e/'europe_model.py',e/'data/train_valid.npz']+[p for _,_,p in checkpoints]
    for seed in (20260813,20260814,20260815):
        for mode in ('FULL','STATIC','SELF'):
            p=e/'runs'/f'{mode}_{seed}_0.001/best.pt'
            assert gate.sha(p)==gate.read(p.parent/'result.json')['checkpoint_sha256'];files.append(p)
    protocol=dict(at=gate.now(),scope='CAISO original fixedTRAIN288 inputs, FULL/CONCAT/EQUAL3seeds; Europe2015validation inputs FULL/STATIC/SELF3seeds. No new prices/targets or fits.',
        measurements=['cross-node adjacency mass and concentration','self/cross message norm ratio','adjacency variation only between actual consecutive physical observations','branch cosine and weighted-fusion norm cancellation','attention variability across channels cannot be inferred from scalar branch attention'],
        interpretation='Descriptive mechanism diagnostics only; no accuracy or causal superiority assertion and no model selection from test errors.',
        memory='Existing5GiBlaunch4GiBruntime; single numericworker; C scratch2GiBlaunch1GiBruntime for bounded probe if needed; Fmetadata32MiB.',
        budget_seconds=1200,bindings={str(p):gate.sha(p) for p in files})
    if protocol_path.exists():assert gate.read(protocol_path)['bindings']==protocol['bindings']
    else:gate.write(protocol_path,protocol)
    started=time.monotonic()
    def check(**kw):
        gate.guard()
        if time.monotonic()-started>1200:raise TimeoutError('Read-only probe1200seconds cap')
        for name in ('STOP_REQUESTED','STOP_REQUESTED.json'):
            if (HERE/name).exists():raise InterruptedError('User stop')
        if kw:gate.write(HERE/'STRUCTURE_PROBE_STATUS.json',dict(at=gate.now(),status='running',**kw))
    with gate.exclusive('V21 read-only graph and nonlinear-fusion diagnosis'):
        np,torch,lim=gate.runtime(True)
        from compiled_data import CompiledData
        from models.factory import build_backbone
        dataset=CompiledData(caiso_seal['dataset_manifest'])
        origins=np.load(ROOT/caiso_seal['train_diagnostic'],allow_pickle=False)
        assert origins.shape==(288,) and (origins+12<=210528).all()
        dataset.origins['probe']=origins
        limits=gate.read(dataset.paths['context_limits.json'])['limits']
        rows=[]
        def summarize(tag,seed,mode,records,times,maxgap):
            adj=np.concatenate(records['adj']);cos=np.concatenate(records['cos']);ratio=np.concatenate(records['ratio']);weights=np.concatenate(records['weights']);message=np.concatenate(records['message'])
            nodes=adj.shape[-1];diag=np.diagonal(adj,axis1=-2,axis2=-1)
            gap=np.diff(times);neighbors=(gap>0)&(gap<=maxgap)
            variation=np.abs(np.diff(adj,axis=0)).sum((-2,-1))/nodes
            row=dict(task=tag,seed=seed,mode=mode,origins=len(adj),cross_mass_mean=float((1-diag).mean()),self_mass_p10_p50_p90=np.quantile(diag,[.1,.5,.9]).tolist(),
                effective_neighbors_mean=float((1/np.square(adj).sum(-1)).mean()),
                cross_to_self_message_norm_mean=float(message.mean()),branch_cosine_mean=float(cos.mean()),
                weighted_norm_retention_mean=float(ratio.mean()),weighted_norm_retention_p10=float(np.quantile(ratio,.1)),
                mean_tcn_weight=float(weights[...,0].mean()),tcn_weight_std=float(weights[...,0].std()),
                real_neighbor_pairs=int(neighbors.sum()),adjacency_neighbor_l1_mean=float(variation[neighbors].mean()) if neighbors.any() else None,
                adjacency_temporal_std_mean=float(adj.std(0).mean()))
            raw=HERE/'structure_arrays'/f'{tag}_{seed}_{mode}.npz'
            gate.atomic(raw,lambda f:np.savez_compressed(f,adjacency=adj,cosine=cos,weighted_norm_retention=ratio,weights=weights,cross_self_message_ratio=message,timestamps=times))
            row['arrays']=str(raw);row['sha256']=gate.sha(raw);rows.append(row)
            gate.write(HERE/'structure_receipts'/f'{tag}_{seed}_{mode}.json',row)
            print(f'Diagnosed {tag} {seed} {mode}',flush=True)
        def observe(model,x,out,captured,records,europe=False):
            u=out['local'] if europe else captured['local'];v=out['distant'] if europe else out['transformer_features']
            w=out['weights'] if europe else out['branch_weights'];adj=out['adjacency'] if europe else out['dynamic_adjacency']
            un=u.double().norm(dim=-1);vn=v.double().norm(dim=-1)
            cos=(u.double()*v.double()).sum(-1)/(un*vn).clamp_min(1e-12)
            fused=w[...,:1]*u.unsqueeze(2)+w[...,1:]*v.unsqueeze(2)
            denom=w[...,0]*un.unsqueeze(2)+w[...,1]*vn.unsqueeze(2)
            ratio=fused.double().norm(dim=-1)/denom.clamp_min(1e-12)
            projection=model.graph.input_projection(x.unsqueeze(-1) if europe else x)
            values=model.graph.message(projection);eye=torch.eye(adj.shape[-1],dtype=adj.dtype)
            selfmsg=torch.einsum('bij,btjd->btid',adj*eye,values)
            crossmsg=torch.einsum('bij,btjd->btid',adj*(1-eye),values)
            msg=crossmsg.double().norm(dim=-1).mean((1,2))/selfmsg.double().norm(dim=-1).mean((1,2)).clamp_min(1e-12)
            for key,value in [('adj',adj),('cos',cos),('ratio',ratio),('weights',w),('message',msg)]:records[key].append(value.cpu().numpy())
        for seed,mode,path in checkpoints:
            check(task='CAISO',seed=seed,mode=mode)
            model=build_backbone(mode,seed,limits);cp=torch.load(path,map_location='cpu',weights_only=False);model.load_state_dict(cp['state_dict']);model.eval();del cp
            before={k:v.clone() for k,v in model.state_dict().items()};rng=torch.get_rng_state().clone()
            captured={};handle=model.tcn.register_forward_hook(lambda m,i,o:captured.update(local=o.detach()))
            records={k:[] for k in ('adj','cos','ratio','weights','message')}
            with torch.no_grad():
                for start in range(0,288,4):
                    check();xx,yy=dataset.batch('probe',np.arange(start,start+4),with_target=False);assert yy is None
                    x=torch.from_numpy(xx);out=model(x);observe(model,x,out,captured,records)
            handle.remove();assert all(torch.equal(v,model.state_dict()[k]) for k,v in before.items()) and torch.equal(rng,torch.get_rng_state())
            summarize('CAISO_TRAIN',seed,mode,records,dataset.times[origins],3600)
            del model,before,records;gc.collect()
        del dataset;gc.collect()
        # Import the unchanged Europe model against its own pure common helpers.
        ec=module('common',e/'common.py');em=module('v21_europe_model',e/'europe_model.py')
        with np.load(e/'data/train_valid.npz',allow_pickle=False) as z:prices=z['prices'];valid=z['valid']
        assert valid.shape==(365,) and (np.diff(valid)==24).all()
        for seed in (20260813,20260814,20260815):
            for mode in ('FULL','STATIC','SELF'):
                check(task='Europe',seed=seed,mode=mode)
                model=em.build(mode,seed);cp=torch.load(e/'runs'/f'{mode}_{seed}_0.001/best.pt',map_location='cpu',weights_only=False);model.load_state_dict(cp['model']);model.eval();del cp
                before={k:v.clone() for k,v in model.state_dict().items()};rng=torch.get_rng_state().clone();records={k:[] for k in ('adj','cos','ratio','weights','message')}
                with torch.no_grad():
                    for start in range(0,365,8):
                        check();x=torch.from_numpy(np.stack([prices[o-168:o] for o in valid[start:start+8]]).astype('float32'))
                        out=model(x,details=True);observe(model,x,out,{},records,True)
                assert all(torch.equal(v,model.state_dict()[k]) for k,v in before.items()) and torch.equal(rng,torch.get_rng_state())
                summarize('Europe_VALID',seed,mode,records,valid,24)
                del model,before,records;gc.collect()
        for p,h in protected.items():assert gate.sha(p)==h
        gate.write(output,dict(at=gate.now(),status='completed_descriptive_probe',protocol_sha256=gate.sha(protocol_path),rows=rows,training_updates=0,targets_read=False,new_test_targets_read=False,V7_preserved=True,seconds=time.monotonic()-started,
            caveat='Weighted norm ratio for CONCAT is a counterfactual equal mixture of its branches, NOT its actual concat representation. No causal or forecast accuracy claim.'))
        gate.write(HERE/'STRUCTURE_PROBE_STATUS.json',dict(at=gate.now(),status='completed',cases=len(rows),training_updates=0))

if __name__=='__main__':
    try:main()
    except Exception as exc:
        import traceback
        gate.write(HERE/'STRUCTURE_PROBE_STATUS.json',dict(at=gate.now(),status='stopped_with_receipts',error=str(exc),traceback=traceback.format_exc()))
        raise
