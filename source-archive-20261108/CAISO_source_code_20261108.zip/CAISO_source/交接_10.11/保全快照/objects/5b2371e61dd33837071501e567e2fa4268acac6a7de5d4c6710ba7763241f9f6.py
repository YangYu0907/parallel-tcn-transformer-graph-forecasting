"""Metadata and resource gates for the separately registered frozen-backbone adapter pilot."""
from pathlib import Path
from contextlib import contextmanager
from datetime import datetime,timezone
import hashlib,json,os,sys,uuid
HERE=Path(__file__).resolve().parent;ROOT=HERE.parent
COMMON=ROOT/'common_sampling_evaluation_20260923'
V=ROOT/'phase_sampling_support_v3_20260923'
SEAL=HERE/'ADAPTER_LOCK.json'
LOCK=Path('D:/Desktop/数据科学_论文/研究优化_20260818/logs/NEURAL_RUN.lock')
sys.path.insert(1,str(ROOT/'source'))
import compile_gate as cg
def now():return datetime.now(timezone.utc).isoformat()
def read(p):return json.loads(Path(p).read_text(encoding='utf-8-sig'))
def need(x,m):
    if not x:raise RuntimeError(m)
def inside(p):
    p=Path(p);p=(ROOT/p if not p.is_absolute() else p).resolve()
    need(p.is_relative_to(ROOT),'Path outside branch');return p
def rel(p):return str(inside(p).relative_to(ROOT))
def sha(p):
    h=hashlib.sha256()
    with Path(p).open('rb') as f:
        for x in iter(lambda:f.read(1048576),b''):h.update(x)
    return h.hexdigest()
def atomic(p,writer,replace=False):
    p=inside(p);p.parent.mkdir(parents=True,exist_ok=True)
    t=p.with_name('t_'+uuid.uuid4().hex+'.pending')
    with t.open('xb') as f:writer(f);f.flush();os.fsync(f.fileno())
    if replace:os.replace(t,p)
    else:t.rename(p)
def write(p,v,replace=False):
    raw=json.dumps(v,ensure_ascii=False,allow_nan=False,indent=2).encode()
    atomic(p,lambda f:f.write(raw),replace)
def boundary():
    for folder in (ROOT,HERE,HERE/'queue',V,COMMON):
        for name in ('STOP_REQUESTED','STOP_REQUESTED.json'):
            if (folder/name).exists():raise InterruptedError('User stop '+str(folder/name))
    p=read(ROOT.parent/'RESEARCH_PAUSED.json')
    if p.get('status')!='resumed_by_user' or p.get('stop_preparation_and_training'):raise InterruptedError('Research paused')
def guard(launch=False):
    boundary();r=cg.resources();floor=5 if launch else 4
    if min(r.values())<floor:raise MemoryError(f'Adapter needs {floor}GiB physical+commit; actual {r}')
    return r
@contextmanager
def exclusive(action):
    guard(True)
    import psutil
    o=dict(pid=os.getpid(),created=psutil.Process().create_time(),token=uuid.uuid4().hex,action=action)
    with LOCK.open('x',encoding='utf-8') as f:json.dump(o,f);f.flush();os.fsync(f.fileno())
    try:cg.bound_process();guard();yield
    finally:
        need(read(LOCK)==o,'Lock owner changed');write(HERE/'lock_releases'/(o['token']+'.json'),dict(owner=o,at=now()));LOCK.unlink()
def runtime(torch_needed=True):
    cg.bound_process()
    import numpy as np
    from threadpoolctl import threadpool_limits,threadpool_info
    lim=threadpool_limits(1)
    need(all(x['num_threads']==1 for x in threadpool_info()),'Numerical thread limit')
    if torch_needed:
        import torch
        torch.set_num_threads(1);torch.set_num_interop_threads(1);torch.use_deterministic_algorithms(True)
        guard();return np,torch,lim
    guard();return np,lim

MP=ROOT/'matched_panel_v1_20260924'
EX=ROOT/'matched_external_evaluation_v2_20260925'
def verify():
    boundary();s=read(SEAL)
    need(s['status']=='sealed_offhour_adapter_trial' and len(s['cases'])==6,'Unsealed six-case trial')
    need([(c['seed'],c['arm']) for c in s['cases']]==[(s,a) for s in (20260813,20260814,20260815) for a in ('GLOBAL','OFFHOUR')],'Case panel changed')
    for p,d in s['bindings'].items():need(sha(inside(p))==d,'Bound source/input changed '+p)
    return s
def seal():
    boundary();need(not SEAL.exists(),'Preserve immutable trial');bindings={}
    def bind(p,expected=None):
        p=inside(p);d=sha(p);need(expected is None or d==expected,'Bound input changed '+str(p));bindings[rel(p)]=d
        return read(p) if p.suffix=='.json' else d
    for base in (MP,):
        for name,key in [('EXECUTION_LOCK.json','bindings'),('EVALUATION_LOCK.json','bindings'),('numeric_audit.json','output_bindings'),('checkpoint_audit.json','bindings')]:
            obj=bind(base/name)
            for p,d in obj[key].items():bind(p,d)
        bind(base/'queue/completion.json','dc6c759b75da62450ee90ffbc9d9c3227fda9b50d12949dae5f59000c8f62f30')
        bind(base/'summary.json')
    done=bind(EX/'queue/completion.json','ea3f98e751d9d1ec8f6193de5ce5b674be3f2c72da0d68c41a5e26e4a0e84396')
    bind(EX/'summary.json',done['summary_sha256']);bind(EX/'result.json')
    for name,key in [('numeric_audit.json','output_bindings'),('checkpoint_audit.json','bindings')]:
        a=bind(EX/name);need(a['status']=='passed' and a['result_sha256']==sha(EX/'result.json'),'External common audit missing')
        for p,d in a[key].items():bind(p,d)
    for name,d in done['receipts'].items():
        rr=bind(EX/'queue/steps'/name,d);need(rr['exit_code']==0,'External recovery exit failed');bind(rr['marker'],rr['marker_sha256'])
    bind(ROOT/'audits/matched_external_completion_verified_20260925.json')
    bind(ROOT/'audits/offhour_adapter_bounded_design_20260924.json')
    for p in sorted(HERE.glob('*.py')):compile(p.read_text(encoding='utf-8'),str(p),'exec');bind(p)
    for name in ('PROTOCOL.json','launch_reviewed.ps1','watch_manager_exit.ps1','synthetic_qa.json','real_model_qa.json','source_review.json'):bind(HERE/name)
    for name in ('synthetic_qa.json','real_model_qa.json'):
        qa=read(HERE/name);need(qa['status']=='passed','QA missing')
        for p,d in qa['sources'].items():bind(p,d)
    review=read(HERE/'source_review.json')
    need(review['status']=='passed' and review['synthetic_qa_sha256']==sha(HERE/'synthetic_qa.json') and review['real_model_qa_sha256']==sha(HERE/'real_model_qa.json'),'Source review missing')
    for p,d in review['sources'].items():bind(p,d)
    bind(COMMON/'audit.py');bind(COMMON/'reductions.py')
    old=read(COMMON/'EVALUATION_LOCK.json');mp=read(MP/'EVALUATION_LOCK.json')
    rows=read(COMMON/'result.json')['results']+read(MP/'result.json')['results']
    parents={c['seed']:dict(c) for c in old['cases']+mp['cases'] if c['variant']=='FULL' and c['policy']=='ADDITIVE'}
    need(set(parents)=={20260813,20260814,20260815},'Parent panel differs')
    cases=[]
    for seed in (20260813,20260814,20260815):
        p=parents[seed];row=next(r for r in rows if r['id']==p['id'])
        p['dense_receipt']=row['dense_receipt'];p['reference_panels']=row['panels']
        rr=bind(p['dense_receipt']);bind(rr['artifact'],rr['artifact_sha256'])
        bind(p['selected_checkpoint']);bind(p['selected_prediction'])
        for arm in ('GLOBAL','OFFHOUR'):cases.append(dict(id=f'{seed}_{arm}',seed=seed,arm=arm,parent=p,optimizer_steps=2016,adapter_trainable_parameters=552))
    report=dict(status='sealed_offhour_adapter_trial',at=now(),bindings=bindings,cases=cases,
        dataset_manifest=rel(V/'dataset/ADDITIVE/manifest.json'),train_diagnostic=old['train_diagnostic'],
        selection='June3397 dense; explicit separate refinement scope',heldout_targets_read=False,complete_research_experiment=False)
    write(SEAL,report);print(json.dumps(dict(status=report['status'],cases=6,bound_files=len(bindings),seal_sha256=sha(SEAL))))
if __name__=='__main__':
    if sys.argv[1]=='seal':seal()
    else:
        s=verify();need(not LOCK.exists(),'Numerical worker active');print(json.dumps(dict(status='passed',cases=6,resources=guard(True))))
