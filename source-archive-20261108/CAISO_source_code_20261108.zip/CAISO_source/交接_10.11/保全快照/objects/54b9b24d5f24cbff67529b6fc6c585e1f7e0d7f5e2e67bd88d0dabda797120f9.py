from common import *
import numpy as np
from sklearn.metrics import log_loss,brier_score_loss
def main():
 r=read(E/'RESULT.json');audit=read(E/'AUDIT.json');assert audit['passed'] and r['audit_sha256']==sha(E/'AUDIT.json')
 diagnostic=[]
 for fi,name in enumerate(r['summary']):
  cell=E/f'q{fi+1}_tend';cal=read(cell/'CAL.json')
  with np.load(cell/'PRED.npz') as a:
   row={'fold':name,'temperature':cal['temperature'],'cal_raw_NLL':float(log_loss(a['cal_y'],a['cal_raw'],labels=[0,1,2])),'cal_NLL':float(log_loss(a['cal_y'],a['calibration'],labels=[0,1,2])),'eval_raw_NLL':float(log_loss(a['y'],a['eval_raw'],labels=[0,1,2])),'eval_NLL':float(log_loss(a['y'],a['evaluation'],labels=[0,1,2]))}
   for c in [1,2]:
    row[str(c)]={'event_frequency':float(np.mean(a['y']==c)),'raw_mean_probability':float(a['eval_raw'][:,c].mean()),'mean_probability':float(a['evaluation'][:,c].mean()),'raw_brier':float(brier_score_loss(a['y']==c,a['eval_raw'][:,c])),'calibrated_brier':float(brier_score_loss(a['y']==c,a['evaluation'][:,c]))}
  diagnostic.append(row)
 write(E/'DIAGNOSIS.json',dict(at=now(),status='posthoc_diagnostic_not_new_candidate',calibration=diagnostic,observed='Calibration reduces total multiclass NLL in both CAL and EVAL, but uncalibrated Q1 UP already has large Brier error. Therefore simply removing the calibration step does not resolve this failure.',not_inferred='No causal proof that weather causes false alarms; conditional distribution shift and sparse-event feature overfit remain hypotheses. No raw-probability variant is selected using evaluation labels.',model_updates=0))
 protected=read(Z/'PROTECTED_FILES.json')
 assert all(sha(k)==h for k,h in protected.items())
 decision=dict(at=now(),status='closed_no_stable_increment',result_sha256=sha(E/'RESULT.json'),audit_sha256=sha(E/'AUDIT.json'),source_verification_passed=True,prediction_and_score_replay_passed=True,independent_person_review=False,new_fits=4,reused_baseline_cells=6,training_seconds=sum(v['seconds'] for v in r['fits']),observed='Apr-May UP P/R and both proper scores improve on COARSE; Q1 UP strongly worsens and both windows DOWN P/R worsen versus COARSE. No Holm32 improvement significant. Full promotion gate fails.',V7_changed=False,new_test_targets_read=False,point_price_integration=False,protected_files_unchanged=len(protected),active_training=False,whole_research_complete=False,closed_search='No tuning weather lag, region, season, leaf budget, thresholds or selecting raw/calibrated outputs using these results.',next_matched_comparison={'status':'not_launched_requires_qualified_information','contrast':'Frozen existing strongest weather/price classifier versus same classifier plus exact same-valid-time forecast revisions or original-version nodal congestion values, on identical full-calendar population and model budget. Source qualification comes first.','weather_revision_gap':'Existing archive cycles are3h apart and contain leads3,4,5 only; no same-valid-time overlap. Do not relabel this tendency as forecast revisions. Requires separate exact older lead6+ original objects and availability proof.','DAM_gap':'13 local DOWN dates still lack original-value/release linkage; obtain entire prescribed calendar rather than selecting positive-event dates.','benefit':'Potentially tests genuinely new forecast news or nodal stress rather than another gate on unchanged snapshots.','cost':'Weather revision requires new extraction/source audit; DAM may require unavailable archived versions. Cost and value unproven, do not launch a large download automatically from a local Apr-May win.','literature':'Hirsch and Ziel, The Energy Journal2024, https://arxiv.org/abs/2211.13002; distinguishes fundamentals and updates, and reports limited mean predictability. No CAISO guarantee.'},listener_pid=15020,periodic_model_wakeups=False)
 write(E/'DECISION.json',decision)
 status=read(E/'STATUS.json')
 write(E/'HANDLED.json',dict(at=now(),payload_event_id=status['event_id'],result_sha256=sha(E/'RESULT.json'),foreground_reported=True,duplicate_retraining_forbidden=True))
 path=B/'HANDOFF.json';raw=path.read_bytes();h=json.loads(raw.decode('utf-8-sig'))
 h['current_status']='weather_tendency_completed_no_stable_increment'
 h['weather_tendency_20261011'].update(status=decision['status'],active_training=False,completed_fits=4,result=str(E/'RESULT.json'),audit=str(E/'AUDIT.json'),diagnosis=str(E/'DIAGNOSIS.json'),decision=str(E/'DECISION.json'),report=str(E/'REPORT.txt'),progress=read(E/'PROGRESS.json'),terminal_status=status)
 events=h.setdefault('reported_and_consumed_payload_events',[])
 if isinstance(events,list):
  if status['event_id'] not in events:events.append(status['event_id'])
 else:events[status['event_id']]=dict(at=now(),record=str(E/'HANDLED.json'))
 h['next_actions']=['Retain all four completed tendency models and six reused control cells; no promotion, no lag/region/threshold search on this panel.','Resolve new information availability before another signal trial: original-version nodal DAM values or same-valid-time forecast revision objects; current lag tendency is not a revision.','Retain frozen V7 and original paper; graph benefit and independent confirmation remain open. No new blind target reading.','No active numerical manager; local event listener retained. Whole research not completed.']
 assert path.read_bytes()==raw
 tmp=path.with_name('.h'+uuid.uuid4().hex[:8]);tmp.write_text(json.dumps(h,ensure_ascii=False,indent=2),encoding='utf-8');os.replace(tmp,path)
 print(json.dumps({'status':decision['status'],'protected':len(protected),'training_seconds':decision['training_seconds'],'audit_checks':len(audit['checks']),'active_training':False,'result_sha256':decision['result_sha256']}))
if __name__=='__main__':main()

