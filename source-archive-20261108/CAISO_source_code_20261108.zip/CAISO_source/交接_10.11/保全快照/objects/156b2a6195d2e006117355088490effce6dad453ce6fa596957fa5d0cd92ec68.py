"""First passage risk; no probability trained on outcome-selected samples."""
from common import *
import numpy as np,gc
from scipy.optimize import minimize_scalar
from sklearn.ensemble import HistGradientBoostingClassifier
from sklearn.metrics import average_precision_score,log_loss
H=[1,4,12]
def probabilities(p,t):
 z=np.log(np.maximum(p,1e-12))/t;z-=z.max(1,keepdims=True);a=np.exp(z);return a/a.sum(1,keepdims=True)
def prepare(tick):
 with np.load(T/'spike_transition_v12_20260930/TRAIN.npz') as z:d={k:z[k] for k in ['X','origins','nodes','days','current_extreme']}
 keep=d['origins']%12==0
 order=np.lexsort((d['nodes'][keep],d['origins'][keep]))
 oo=d['origins'][keep][order];nn=d['nodes'][keep][order];X=d['X'][keep][order];days=d['days'][keep][order];ext=d['current_extreme'][keep][order]
 origins=np.unique(oo);assert len(oo)==len(origins)*30 and np.array_equal(nn,np.tile(np.arange(30),len(origins)))
 assert np.array_equal(oo,np.repeat(origins,30))
 m=read(B/'phase_sampling_support_v3_20260923/dataset/ADDITIVE/manifest.json')
 paths={k:resolve(v['path']) for k,v in m['artifacts'].items()}
 for k in ['raw_prices.npy','state_thresholds.json','timestamps_seconds.npy']:
  tick(step='verify_source',file=k);assert sha(paths[k])==m['artifacts'][k]['sha256']
 prices=np.load(paths['raw_prices.npy'],mmap_mode='r');times=np.load(paths['timestamps_seconds.npy'],mmap_mode='r')
 th=read(paths['state_thresholds.json']);q=np.array(th['thresholds'])[1];center=np.array(th['center'])
 dates=np.unique(days);c1=int(dates[int(.6*len(dates))]);c2=int(dates[int(.8*len(dates))]);day0=times[origins-1]//86400
 roles=np.where(day0<c1,0,np.where(day0<c2,1,2));roles[(roles==0)&(times[origins+11]>=c1*86400-172800)]=-1;roles[(roles==1)&(times[origins+11]>=c2*86400-172800)]=-1
 assert (origins+12<=210528).all();assert times[origins[roles==0]+11].max()<times[origins[roles==1]-1].min()
 assert times[origins[roles==1]+11].max()<times[origins[roles==2]-1].min()
 hist=X.reshape(-1,30,90);cc=np.corrcoef(hist[roles==0,:,0],rowvar=False);np.fill_diagonal(cc,-np.inf)
 neighbors=np.argsort(-np.nan_to_num(cc,nan=-np.inf),axis=1,kind='stable')[:,:5]
 # Hist input values at t are known; labels in t+1..t+12 are constructed separately.
 local=np.column_stack([X[:,:75],np.eye(30,dtype=np.float32)[nn]])
 neighbour=hist[:,neighbors,:][:,:,:,[0,5,1,2]].reshape(-1,20)
 cross=np.column_stack([local,neighbour]);ys=[];first=[]
 for j,o in enumerate(origins):
  path=np.asarray(prices[o:o+12,:,0],float).T-center[:,None]
  exceed=np.abs(path)>q[:,None];hit=exceed.any(1);pos=exceed.argmax(1)
  fc=np.where(hit,np.where(path[np.arange(30),pos]>0,1,2),0)
  ys.append(np.column_stack([np.where(hit&(pos<h),fc,0) for h in H]));first.extend(np.where(hit,pos+1,0).tolist())
  if j%1000==0:tick(step='event_labels',origins=j)
 y=np.concatenate(ys);r=np.repeat(roles,30);ret=~ext
 data=dict(LOCAL=local[ret],CROSS=cross[ret],y=y[ret],role=r[ret],origin=oo[ret],node=nn[ret],days=days[ret],first_hit=np.array(first)[ret],neighbors=neighbors)
 rows=[]
 for role in range(3):
  for j,h in enumerate(H):
   for s in range(3):
    a=(data['role']==role)&(data['y'][:,j]==s)
    rows.append(dict(role=['fit','calibration','forward_development'][role],horizon=h,event=['none','up','down'][s],pairs=int(a.sum()),dates=len(np.unique(data['days'][a]))))
 table('ONSET_SUPPORT.csv',rows)
 write(ROOT/'ONSET_ADMISSION.json',dict(at=now(),origins=len(origins),nonextreme_pairs=int(ret.sum()),split_UTC_days=[c1,c2],purge_days=2,horizons=H,support=rows,interpretation='First upper/lower crossing within horizon, not end-horizon S2 price error; hourly starts overlap across nodes. Previously admitted TRAIN only.',neighbours=neighbors.tolist(),current_extreme_excluded_by_issue_time_only=True))
 npz_save(ROOT/'onset_data.npz',**data);del prices,d;gc.collect();return data
def score(y,p,pc,yc,node,days,model,h):
 rows=[]
 for c in [1,2]:
  truth=y==c;caltruth=yc==c
  negatives=pc[~caltruth,c];threshold=float(np.quantile(negatives,.99,method='higher'))
  alarm=p[:,c]>threshold
  rows.append(dict(model=model,horizon=h,event=['none','up','down'][c],brier=float(((p[:,c]-truth)**2).mean()),logloss=float(log_loss(truth,p[:,c],labels=[False,True])),pr_auc=float(average_precision_score(truth,p[:,c])) if truth.any() else None,prevalence=float(truth.mean()),threshold=threshold,recall=float(alarm[truth].mean()) if truth.any() else None,false_positive_rate=float(alarm[~truth].mean()),event_pairs=int(truth.sum()),event_dates=len(np.unique(days[truth])),all_pairs=len(y)))
 return rows
def main():
 with numeric('reviewer v2 first passage risk matched comparison'):
  verify_sources();tick=budget('onset',1800);d=load(ROOT/'onset_data.pkl') if (ROOT/'onset_data.pkl').exists() else prepare(tick)
  fit=d['role']==0;cal=d['role']==1;ev=d['role']==2;rows=[];outputs={k:d[k][ev] for k in ['y','origin','node','days']};details=[]
  for j,h in enumerate(H):
   y=d['y'][:,j];yf=y[fit];yc=y[cal];ye=y[ev]
   support=all(np.sum(yf==s)>=20 and len(np.unique(d['days'][fit][yf==s]))>=3 and np.sum(yc==s)>=10 for s in [0,1,2])
   if not support:
    details.append(dict(horizon=h,status='insufficient_class_support'));continue
   globalp=np.bincount(yf,minlength=3)/len(yf);prior=np.empty((30,3))
   for n in range(30):
    yy=y[fit&(d['node']==n)];prior[n]=(np.bincount(yy,minlength=3)+30*globalp)/(len(yy)+30)
   pp=prior[d['node']];outputs[f'PRIOR_H{h}']=pp[ev];rows+=score(ye,pp[ev],pp[cal],yc,d['node'][ev],d['days'][ev],'PRIOR',h)
   for arm in ['LOCAL','CROSS']:
    tick(model=arm,horizon=h);path=ROOT/'onset_models'/f'{arm}_{h}.pkl'
    model=load(path) if path.exists() else HistGradientBoostingClassifier(max_iter=20,max_leaf_nodes=7,min_samples_leaf=100,learning_rate=.05,l2_regularization=1,early_stopping=False,warm_start=True,random_state=20260813)
    xf=d[arm][fit]
    for it in [20,40,60,80]:
     if getattr(model,'n_iter_',0)>=it:continue
     tick(model=arm,horizon=h,iteration=it);model.set_params(max_iter=it);model.fit(xf,yf);dump(path,model)
    assert model.classes_.tolist()==[0,1,2]
    pc=model.predict_proba(d[arm][cal]);pe=model.predict_proba(d[arm][ev])
    temp=float(minimize_scalar(lambda t:log_loss(yc,probabilities(pc,t),labels=[0,1,2]),bounds=(.5,2),method='bounded').x)
    for name,t in [(arm+'_RAW',1.),(arm+'_CAL',temp)]:
     ep=probabilities(pe,t);cp=probabilities(pc,t);outputs[f'{name}_H{h}']=ep;rows+=score(ye,ep,cp,yc,d['node'][ev],d['days'][ev],name,h)
    details.append(dict(model=arm,horizon=h,temperature=temp,fit_pairs=int(fit.sum()),calibration_pairs=int(cal.sum()),evaluation_pairs=int(ev.sum())))
    del model,xf;gc.collect()
  table('ONSET_RESULTS.csv',rows);npz_save(ROOT/'onset_forward_predictions.npz',**outputs)
  arms=['PRIOR','LOCAL_CAL','CROSS_CAL'];summary={a:{k:float(np.mean([r[k] for r in rows if r['model']==a])) for k in ['brier','logloss','pr_auc','recall','false_positive_rate']} for a in arms} if rows else {}
  supported=len([x for x in details if x.get('status')=='insufficient_class_support'])==0
  passed=bool(supported and summary and all(summary['CROSS_CAL'][k]<summary[a][k] for a in ['PRIOR','LOCAL_CAL'] for k in ['brier','logloss']) and all(r['false_positive_rate']<=.02 for r in rows if r['model']=='CROSS_CAL') and summary['CROSS_CAL']['recall']>summary['LOCAL_CAL']['recall'])
  if passed:
   passed=all(next(r['brier'] for r in rows if r['model']=='CROSS_CAL' and r['horizon']==h and r['event']==e)<=next(r['brier'] for r in rows if r['model']=='LOCAL_CAL' and r['horizon']==h and r['event']==e) for h in H for e in ['up','down'])
  write(ROOT/'ONSET_RESULT.json',dict(at=now(),summary=summary,fits=6 if supported else len([x for x in details if 'model' in x]),details=details,screen_pass=passed,point_predictions_changed=False,new_test_targets_read=False,interpretation='Risk development experiment only; no V7 integration or independent-confirmation claim',protected=verify_protected()))
  tick(status='completed',screen_pass=passed);print(json.dumps(summary))
if __name__=='__main__':
 try:main()
 except Exception as e:progress(stage='onset',status='blocked',error=repr(e));raise
