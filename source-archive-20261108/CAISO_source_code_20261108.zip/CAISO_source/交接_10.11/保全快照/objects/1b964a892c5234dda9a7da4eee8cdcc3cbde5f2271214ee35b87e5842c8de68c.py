"""Pin the unchanged candidate set and feature-only admission worker."""
from pathlib import Path
import sys
HERE=Path(__file__).resolve().parent
sys.path.insert(0,str(HERE.parent/'energy_confirmation_v1_20260926'))
import common as c

def main():
    c.boundary();c.need(not c.SHARED_LOCK.exists(),'Another numerical worker')
    dest=HERE/'FEATURE_AUDIT_FREEZE.json';c.need(not dest.exists(),'Preserve existing freeze')
    source=c.BRANCH/'h1_source_inputs_v1_20260927'
    previous=source/'INPUT_AUDIT_FREEZE.json';f=c.read(previous);r=c.read(source/'SOURCE_INPUT_REVIEW.json')
    c.need(r['status']=='source_value_linkage_receipts_verified_not_final_admission','Source review missing')
    c.need(r['freeze_sha256']==c.sha(previous) and r['result_sha256']==c.sha(source/'SOURCE_INPUT_RESULT.json'),'Source review changed')
    q=c.read(HERE/'QA.json');c.need(q['status']=='passed','Feature QA failed')
    bind=dict(f['bindings']);bind[str(previous)]=c.sha(previous)
    for p,d in q['sources'].items():c.need(c.sha(p)==d,'QA source changed')
    # Bind the complete official-window, archive and independently checked
    # metadata inventory, not merely the derived list of candidate origins.
    old_audit=c.read(c.BRANCH/'h1_metadata_audit_20260924/result.json')
    bind.update(old_audit['bindings'])
    for p in [source/'SOURCE_INPUT_RESULT.json',source/'SOURCE_INPUT_REVIEW.json',source/'queue/completion.json',HERE/'QA.json']+list(HERE.glob('*.py'))+list(HERE.glob('*.ps1')):
        bind[str(p)]=c.sha(p)
    for p,d in bind.items():c.need(c.sha(p)==d,'Frozen identity changed: '+p)
    c.write(dest,dict(status='sealed_H1_features_only_no_predictions_or_scoring',at=c.now(),
        parent_input_freeze=str(previous),bindings=bind,origins=f['origins'],models_or_features_changed=False,
        allowed_actions=['Read fixed metadata-qualified historical input dependencies','Reconcile source publication cutoffs','Construct fixed29features and check direct equations','Write hashes and admission counts without exporting market values'],
        fit_calls=0,gradient_steps=0,G6_signed=False,H1_target_release=False,
        final_admission_rule='Use every registered candidate satisfying source identity, all input constituent cutoffs, completeness and fixed feature equations. No price/error-based filtering; any unexplained implementation mismatch stops the entire release.',
        original_candidates=1002,original_registered=3743,volatility_absolute_tolerance=2e-5,volatility_relative_tolerance=1e-6))
    print('Feature-only freeze prepared; no H1 predictions or scores authorized')

if __name__=='__main__':main()
