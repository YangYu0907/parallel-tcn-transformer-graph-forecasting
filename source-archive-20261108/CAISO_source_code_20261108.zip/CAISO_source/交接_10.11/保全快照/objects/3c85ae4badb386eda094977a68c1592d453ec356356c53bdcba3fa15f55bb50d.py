import support as s
import shutil
def main():
 p=s.read(s.R/'output_benefit_20261004/PROTOCOL.json')
 protected=s.read(s.R/'output_benefit_20261004/PROTECTED_FILES.json');s.write('PROTECTED_FILES.json',protected)
 assert s.read(s.N/'QA.json')['passed'];assert s.read(s.N/'SOURCE_PROBE.json')['admitted']
 dependencies=[s.N/x for x in ['support.py','weather_source.py','collect.py','experiment.py','audit.py','manager.py','qa.py','SOURCE_PROBE.json','QA.json']]
 dependencies += [s.A/'老师意见修订_20261003/revision_common.py',s.B/'source/compile_gate.py']
 for file in (s.N/'vendor').rglob('*'):
  if file.is_file() and file.suffix in ['.py','.pyd','.dll']:dependencies.append(file)
 deps=[p['panel'],p['folds'],p['scalers'],str(s.B/'dataset/compiled_train_june/build_16b2377c02a74effb6983991b6bed066/state_thresholds.json')]
 q=dict(at=s.now(),status='registered_before_new_model_fit',authorization='User immediately starts information-admission -> tail -> graph -> integrated confirmation sequence; existing V7 is preserved',
  panel=p['panel'],folds=p['folds'],scalers=p['scalers'],thresholds=deps[-1],source_budget_seconds=14400,total_budget_seconds=18000,
  scope='New regional WEATHER information-value diagnostic on previously inspected 1002-origin 2026H1 panel. 698 nominal evaluation origins; no fresh independent test claim.',
  source=dict(archive='https://hrrrzarr.s3.amazonaws.com',product='operational HRRR forecasts fcst only; no anl/reanalysis',
   cycle='floor(cutoff UTC hour)-3 hours, fixed, no alternate-cycle fallback',leads=[3,4,5],variables=['2m TMP','10m UGRD','10m VGRD'],derived='Temperature Celsius and wind magnitude; linear interpolation from same-cycle hourly fields; hourly slopes and curvature explicitly not 5-minute physical derivatives',
   locations=[['Sacramento',38.58,-121.49],['Fresno',36.74,-119.79],['LosAngeles',34.05,-118.24]],
   mapping='Same regional vector made available to all models/nodes, explicit node-state interactions tested separately; not nodal injections',
   admission='Every GET object raw MD5==ETag, retained SHA256 and bytes, all exact metadata/value Last-Modified <= cutoff. Late revisions rejected. Archive publication evidence; not a timestamped local capture from 2026.',
   missing='Exclude only source failures/publication violations; retain complete rejected-origin register. Same common panel all arms. No outcome-based selection or imputation.',minimum_coverage=.9,network_workers=8,numeric_processes=1),
  arms=['EXISTING','WEATHER','WEATHER_INTERACTION'],primary_candidate='WEATHER_INTERACTION; cannot substitute WEATHER post hoc based on outcomes',
  task='Three-class competing first-entry hazard conditioned on current price within original TRAIN q90 of node center; first future absolute departure > originalTRAINq99; horizon1..12',
  existing_inputs='Same 29 archived causal historical channels + node one-hot + horizon, no future states, prices, or undisclosed forecasts',
  chronology='Three existing chronological development windows. For each, all eligible prior origins; last3UTCdates for calibration; fit/cal labels strictly available before next stage cutoff. No prior fitted V7 errors used as labels.',
  learner=dict(max_leaf_nodes=7,min_samples_leaf=100,learning_rate=.05,l2_regularization=1,early_stopping=False,random_state=20260813),iterations=80,max_model_fits=9,
  seed_note='HGB has no row subsampling here. One fixed seed; no artificial claim of three independent random restarts.',
  calibration='One scalar temperature per arm/fold on past at-risk examples, [.5,2]; alarm threshold at calibration negative-example99th percentile, strict >, no evaluation threshold tuning',
  metrics='All12horizons and H12pernode: Brier, logloss, AP, precision, recall, FPR, alerts, base rate, eventUTCdates and1h-separated eventclusters; no overlap cells treated as independent events',
  statistics='2000 paired bootstrap replicates over real UTC3-day blocks, gaps retained. Holm family8 H12 tests (two added arms x two signs x two proper scores).',
  screen='Primary candidate both signs lower Brier/logloss, nonworse precision/recall, FPR<=.02, >=5 eventdates and >=5eventclusters. Statistical increment requires all four primary Holm comparisons<.05 in favorable direction. No guaranteed point-error gain.',
  next_gates='No point integration or GPD promotion without incremental information support; physical prior still needs real topology/version admission; new-system ablations and untouched confirmation remain required.',
  resource='One numeric worker, singleCPU thread limits, 8 bounded HTTP acquisition threads; unchanged5GiBlaunch4GiBruntime;4GiBdiskreserve; no scheduled model wakeups',
  V7_replaced=False,new_test_targets_read=False,all_results_retained=True,
  references=[dict(url='https://rapidrefresh.noaa.gov/hrrr/',supports='Operational hourly regional numerical weather forecasts'),dict(url='https://mesowest.utah.edu/html/hrrr/zarr_documentation/html/python_data_loading.html',supports='Forecast vs analysis, archived grid/coordinate/time structure'),dict(url='https://mesowest.utah.edu/html/hrrr/zarr_documentation/html/zarr_variables.html',supports='Retrospective precision changes and missing solar forecast caveat; solar deliberately excluded'),dict(url='https://arxiv.org/abs/2008.08004',supports='Fair inputs and chronological forecast evaluation'),dict(url='https://doi.org/10.1016/j.ijforecast.2011.02.019',supports='Electricity price spike occurrence as a distinct prediction problem; no transfer guarantee')],
  bindings={str(f):s.sha(f) for f in dependencies+[__file__]+deps})
 s.write('PROTOCOL.json',q);print(dict(registered=True,bound_files=len(q['bindings']),protected=len(protected),max_fits=9,source_budget_hours=4))
if __name__=='__main__':main()
