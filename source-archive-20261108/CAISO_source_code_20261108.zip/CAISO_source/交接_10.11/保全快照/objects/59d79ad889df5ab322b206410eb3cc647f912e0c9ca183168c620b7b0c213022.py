"""Register a single finite joint-content hypothesis; no test data reads."""
from pathlib import Path
import hashlib, json
HERE = Path(__file__).resolve().parent
ROOT = HERE.parent
OLD = ROOT/'residual_attention_v1_20260928'
PRIOR = ROOT/'graph_prior_v1_20260929'
def read(p): return json.loads(p.read_text(encoding='utf-8-sig'))
def sha(p): return hashlib.sha256(p.read_bytes()).hexdigest()
def write(p, obj):
    with p.open('x', encoding='utf-8') as f: json.dump(obj, f, ensure_ascii=False, indent=2, allow_nan=False)
def change(text, old, new):
    if old not in text: raise ValueError('Missing source anchor: '+old)
    return text.replace(old,new)
def main():
    old = read(OLD/'PROTOCOL.json')
    controls=[]
    for seed in old['seeds']:
        for variant in ('FULL_CONT','CONCAT_CONT'):
            folder=OLD/'runs'/f'{seed}_{variant}'
            audit=read(folder/'audit.json')
            assert audit['status']=='passed' and audit['completion_sha256']==sha(folder/'completion.json')
            controls.append(dict(seed=seed,variant=variant,directory=str(folder),completion_sha256=sha(folder/'completion.json'),audit_sha256=sha(folder/'audit.json')))
    for name in ('gate.py','selection.py','launch.ps1','watch_manager_exit.ps1'):
        s=(PRIOR/name).read_text(encoding='utf-8-sig')
        if name=='gate.py': s=change(s,"'graph_prior_'","'aff_joint_'")
        (HERE/name).write_text(s,encoding='utf-8-sig' if name.endswith('.ps1') else 'utf-8')
    s=(OLD/'common.py').read_text(encoding='utf-8')
    s=change(s,'from model import ResidualFusion','from model import JointFusion')
    s=s.replace('ResidualFusion','JointFusion').replace("'RESIDUAL'","'AFF'")
    s=change(s,"state=dict(state);state['residual_scale']=torch.zeros(())","state=dict(state);state.update({k:v for k,v in m.state_dict().items() if k.startswith('joint_content.')})")
    (HERE/'common.py').write_text(s,encoding='utf-8')
    s=(PRIOR/'train.py').read_text(encoding='utf-8').replace('graph_prior','aff_joint').replace('PRIOR','AFF').replace('prior fits','AFF fits').replace('graph-prior','joint-content')
    (HERE/'train.py').write_text(s,encoding='utf-8')
    s=(OLD/'audit.py').read_text(encoding='utf-8')
    s=change(s,'import common as c','import common as c\nfrom pathlib import Path\nfrom execution import verify_training')
    s=change(s,'g.verify();protocol=','verify_training();protocol=')
    s=change(s,"run=g.HERE/'runs'/f'{seed}_{variant}';r=g.read(run/'completion.json')","run=(g.HERE/'runs'/f'{seed}_{variant}' if variant=='AFF' else Path(next(x for x in protocol['reused_controls'] if x['seed']==seed and x['variant']==variant)['directory']));r=g.read(run/'completion.json')")
    s=change(s,"g.write(run/'audit.json'","g.write(g.HERE/'case_audits'/f'{seed}_{variant}.json'")
    s=s.replace('RESIDUAL','AFF').replace('residual_separate','aff_joint_separate').replace('finite_residual_trial','finite_aff_joint_trial').replace('residual_improvement','aff_improvement')
    s=change(s,'training_updates=9*2016','training_updates=3*2016,reused_control_updates=6*2016')
    (HERE/'audit.py').write_text(s,encoding='utf-8')
    s=(PRIOR/'manager.py').read_text(encoding='utf-8').replace("['PRIOR']","['AFF']").replace('graph_prior','aff_joint')
    (HERE/'manager.py').write_text(s,encoding='utf-8')
    budget=dict(old['budget'],fits=9,fits_maximum=9,new_fits_planned=3,reused_control_fits=6,
                training='Original trainable parameters plus1136 joint-content parameters. Shared loss, data, optimizer, schedule and prediction head unchanged.')
    protocol=dict(status='registered_before_candidate_training',authorization='User authorized literature-backed bounded experiments and automatic follow-up of unexpected results.',
        scope='Exploratory TRAIN/June only after original independent tests; no changed-model confirmation on previously inspected tests.',
        decision_basis='Stable graph prior failed all3seed matched MAE comparisons. Close that family. Earlier scalar/channel residual provided negligible benefit; test a different joint-content attention generator, not another scalar gate magnitude.',
        hypothesis='Joint local and across-node content of both branches may provide useful feature-wise fusion weights beyond the existing context-query attention. This remains unproven for this price task.',
        formula='u=(TCN+Transformer)/2+horizon_embedding; delta=MLP_local(u)+MLP_global(mean_nodes(u)); feature branch logits=original scalar logits+[delta/2,-delta/2]; softmax across2branches; weighted features before shared head.',
        adaptation='AFF-inspired local/global content, LayerNorm8 instead of BatchNorm, node pooling, existing horizon conditioning, zero-initialized final projections to preserve the original function. Not a literal reproduction of the vision architecture.',
        variants=['AFF','FULL_CONT','CONCAT_CONT'],seeds=old['seeds'],parents=old['parents'],reused_controls=controls,budget=budget,
        control_reuse='Exact original runtime, parent, data, optimizer, RNG, updates, selector and metric code are required. Replay initial and selected predictions; otherwise halt rather than silently reuse.',
        selection=old['selection'],evaluation=old['evaluation'],
        stopping_rule='Exactly3 new2epoch continuations and separate array/replay audit. If promotion rule fails, close this family; do not add learning-rate, bottleneck, loss, epoch or initialization sweeps. No additional candidate family automatically queued.',
        interpretation='Screen incremental package performance against original FULL_CONT and CONCAT_CONT; does not isolate parameter count, prove graph advantage, or establish independent generalization. Success needs matched content/capacity controls and a source-admitted unused period.',
        required_after_success=['Feature-content versus matched constant correction control; EQUAL comparison on same continuation budget','Confirm useful channel correction with fixed-weight diagnostic','Source admission and freeze before new-period test'],
        risks=['1136 extra parameters and repeated development selection can overfit','Global node pooling can blur heterogeneous locations','Two epochs evaluate bounded continuation, not exhaustive convergence','Positive pilot cannot replace original63confirmed cases'],
        resource=dict(launch_GiB=5,runtime_GiB=4,single_numerical_worker=True,threads=1),
        literature=[dict(url='https://arxiv.org/abs/2009.14082',basis='Dai et al., Attentional Feature Fusion, WACV2021: jointly condition channel fusion on local/global feature content; evidence from vision, not EPF.'),dict(url='https://jmlr.org/papers/v11/cawley10a.html',basis='Finite validation can be overfit through model selection; bound this trial and require fresh confirmation.')],
        all_core_elements_preserved=True,test_access_permitted=False,original63_cases_unchanged=True,periodic_model_wakeups=False)
    protocol['evaluation']['promotion']='Mean dense MAE below both FULL_CONT and CONCAT_CONT, at least2/3seed wins versus FULL_CONT; dense/hourly MAE,RMSE,near,H12 means no worse than original epoch12FULL beyond1e-8. All directions retained. Pilot only, no significance claim.'
    write(HERE/'PROTOCOL.json',protocol)
    bindings={p:v for p,v in read(OLD/'EXECUTION_SEAL.json')['bindings'].items() if Path(p).is_relative_to(ROOT/'source') or Path(p).is_relative_to(ROOT/'common_sampling_evaluation_20260923')}
    manifest=ROOT/'phase_sampling_support_v3_20260923/dataset/ADDITIVE/manifest.json';bindings[str(manifest)]=sha(manifest)
    for parent in protocol['parents']: bindings[parent['checkpoint']]=parent['sha256']
    for ref in controls:
        for name in ('completion.json','audit.json','run_start.json'):
            path=Path(ref['directory'])/name;bindings[str(path)]=sha(path)
    for path in list(HERE.glob('*.py'))+list(HERE.glob('*.ps1'))+[HERE/'PROTOCOL.json']: bindings[str(path)]=sha(path)
    write(HERE/'EXECUTION_SEAL.json',dict(status='sealed_development_only',stage='QA',bindings=bindings,test_access_permitted=False))
    print('Registered one AFF-inspired candidate,3newfits+6reused controls; no training launched')
if __name__=='__main__':main()
