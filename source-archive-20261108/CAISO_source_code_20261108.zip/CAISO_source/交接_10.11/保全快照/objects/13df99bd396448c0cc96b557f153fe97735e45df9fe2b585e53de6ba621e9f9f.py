import fcommon as c
import subprocess,traceback,os
def emit(event,path):
    key='v21_fusion_diagnosis_'+event+'_'+c.sha(path)
    c.write(c.ROOT/'event_driven_automation/inbox'/(key+'.json'),dict(schema='caiso_research_event_v1',event_id=key,event=event,evidence_path=str(path),at=c.now(),periodic=False))
    return key
def main():
    try:
        from diagnosis import verify
        verify()
        for script in ('diagnosis.py','diagnosis_audit.py'):
            c.check(True)
            c.write(c.HERE/'DIAGNOSIS_STATUS.json',dict(at=c.now(),pid=os.getpid(),event='step_process_started',script=script,model_fits=0))
            p=subprocess.run(['D:/Documents/conda_envs/tcn_air/python.exe','-u',str(c.HERE/script)],cwd=str(c.HERE))
            if p.returncode:raise RuntimeError(script+' exit='+str(p.returncode))
        key=emit('needs_analysis',c.HERE/'DIAGNOSIS_AUDIT.json')
        c.write(c.HERE/'DIAGNOSIS_STATUS.json',dict(at=c.now(),pid=os.getpid(),event='finite_mechanism_queue_completed',event_id=key,status='audited_diagnosis_complete',model_fits=0))
    except BaseException as exc:
        stop=isinstance(exc,InterruptedError)
        try:c.check()
        except InterruptedError:stop=True
        except Exception:pass
        f=c.HERE/'DIAGNOSIS_FAILURE.json';c.write(f,dict(at=c.now(),error=str(exc),traceback=traceback.format_exc()))
        key=None if stop else emit('blocking_failure',f)
        c.write(c.HERE/'DIAGNOSIS_STATUS.json',dict(at=c.now(),pid=os.getpid(),event='user_stop_before_launch' if stop else 'step_stopped_or_failed',classification='user_stop' if stop else 'failure',event_id=key))
        raise
if __name__=='__main__':main()
