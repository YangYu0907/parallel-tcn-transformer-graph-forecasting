from pathlib import Path
import sys,os,uuid,json,shutil,time
HERE=Path(__file__).resolve().parent;ROUND=HERE.parent;ROOT=ROUND.parent
ART=Path('C:/Users/于阳/CAISO_temporary_storage/multi_round_mechanism_v21_20261001/fusion_pilot')
sys.path.insert(0,str(ROOT/'context_expert_v1_20260929'))
import gate
sys.path.append(str(ROOT/'matched_panel_v1_20260924'))
now=gate.now;read=gate.read;sha=gate.sha;write=gate.write
def check(launch=False):
    gate.guard(launch)
    for d in (HERE,ROUND):
        for n in ('STOP_REQUESTED','STOP_REQUESTED.json'):
            if (d/n).exists():raise InterruptedError('User stop '+str(d/n))
    ART.mkdir(parents=True,exist_ok=True)
    if shutil.disk_usage(ART).free<(2 if launch else 1)*1024**3:raise OSError('C numerical reserve')
    if shutil.disk_usage(HERE).free<32*1024**2:raise OSError('F metadata reserve')
def atomic(p,fn):
    p=Path(p);assert p.resolve().is_relative_to(ART.resolve())
    p.parent.mkdir(parents=True,exist_ok=True);t=p.with_name('.'+p.name+'.'+uuid.uuid4().hex+'.tmp')
    with t.open('xb') as f:fn(f);f.flush();os.fsync(f.fileno())
    os.replace(t,p)
def art_json(p,obj):atomic(p,lambda f:f.write(json.dumps(obj,ensure_ascii=False,allow_nan=False).encode('utf8')))
def preserved():
    for p,h in read(ROUND/'RETAINED_BASELINE_HASHES.json')['files'].items():assert sha(p)==h,p
def verify():
    for p,h in read(HERE/'SEAL.json')['bindings'].items():assert sha(p)==h,p
    preserved();check()
    return read(HERE/'PROTOCOL.json')
def case_model(case,torch,limits):
    from models.factory import build_backbone
    assert sha(case['parent'])==case['parent_sha256']
    model=build_backbone(case['variant'],case['seed'],limits)
    model.load_state_dict(torch.load(case['parent'],map_location='cpu',weights_only=False)['state_dict'],strict=True)
    return model.eval().requires_grad_(False)
class Budget:
    def __init__(self):
        self.path=HERE/'BUDGET.json';self.used=read(self.path)['seconds'] if self.path.exists() else 0.;self.start=time.monotonic()
    def check(self):
        elapsed=self.used+time.monotonic()-self.start
        write(self.path,dict(at=now(),seconds=elapsed,maximum_seconds=7200))
        check()
        if elapsed>=7200:raise TimeoutError('Fixed two-hour F budget exhausted; incomplete is not pass')
