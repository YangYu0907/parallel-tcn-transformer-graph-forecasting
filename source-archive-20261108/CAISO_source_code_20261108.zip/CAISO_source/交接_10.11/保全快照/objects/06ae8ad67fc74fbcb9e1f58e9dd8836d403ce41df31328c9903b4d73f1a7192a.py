import json,time,hashlib,concurrent.futures
from pathlib import Path
from flow_control import Controller
W=Path(__file__).resolve().parent;P=W.parent/'lm_1009'
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def main():
    free={'physical':5,'commit':6};checks=[]
    c=Controller(107);assert c.observe(16,260,free,200,0)==2 and c.pilot_done
    checks.append('Retains2when16batchdescriptivegainexceeds20percent')
    c=Controller(107);assert c.observe(16,600,free,200,0)==1
    checks.append('Slowpilotreturns1')
    for free1,peak,retries in [({'physical':2.9,'commit':6},200,0),(free,512,0),(free,200,3)]:
        c=Controller(107);assert c.observe(1,10,free1,peak,retries)==1
        assert c.observe(16,200,free,100,0)==1
    checks.append('Memoryandnetworkpressurefallbackaremonotonic')
    assert sha(W/'source_support.py')==sha(P/'source_support.py')
    assert sha(W/'decoder.py')==sha(P/'decoder.py')
    checks.append('Unchangedguard1GiBhardcapanddecoderbyteidentity')
    source=(W/'manager.py').read_text(encoding='utf-8')
    assert 'ThreadPoolExecutor(max_workers=2)' in source and 'max_workers=4' not in source
    assert 'compare.run' not in source
    # Scheduling an ordered task list with out-of-order completion must visit once.
    for target in [1,2]:
        iterator=iter(range(12));pending={};visited=[];maximum=0
        with concurrent.futures.ThreadPoolExecutor(max_workers=2) as pool:
            def submit():
                item=next(iterator,None)
                if item is None:return False
                def fetch(i):
                    time.sleep(.001*(1+i%3));return i
                pending[pool.submit(fetch,item)]=item
                return True
            for _ in range(2):submit()
            while pending:
                maximum=max(maximum,len(pending))
                done,_=concurrent.futures.wait(pending,return_when=concurrent.futures.FIRST_COMPLETED)
                for future in done:
                    item=pending.pop(future);assert future.result()==item;visited.append(item)
                    while len(pending)<target:
                        if not submit():break
        assert sorted(visited)==list(range(12)) and len(set(visited))==12 and maximum<=2
    checks.append('Outofordercompletionexactlyoncependingatmost2')
    result=dict(passed=True,checks=checks,network_requests=0,model_fits=0,
                original_decoder_sha256=sha(W/'decoder.py'),original_source_guard_sha256=sha(W/'source_support.py'),
                scientific_sample_or_learner_changes=False)
    (W/'FLOW_QA.json').write_text(json.dumps(result,indent=2),encoding='utf-8')
    print(json.dumps(result))
if __name__=='__main__':main()

