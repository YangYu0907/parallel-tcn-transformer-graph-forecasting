"""Serial finite metadata collection and source-feasibility screen; targets closed."""
from pathlib import Path
from datetime import datetime,timedelta,timezone
from urllib.request import Request,urlopen
from urllib.parse import urlencode
from collections import Counter,deque
from array import array
import csv,io,json,os,sys,time,zipfile
HERE=Path(__file__).resolve().parent
sys.path.insert(0,str(HERE.parent/'context_expert_v1_20260929'))
import gate
UTC=timezone.utc
STREAMS={'price':('RTM','PRICES',{'PRC_INTVL_LMP':'price'}),
         'rtd':('RTD','SYSTEM LOAD',{'SLD_FCST':'rtd'}),
         'dam':('DAM','ALL',{'SLD_FCST':'dam_load','SLD_REN_FCST':'dam_renewable'})}
INPUT_START=datetime(2026,6,15,tzinfo=UTC)
TEST_START=datetime(2026,7,1,tzinfo=UTC)
TEST_END=datetime(2026,9,1,tzinfo=UTC)
PUBLICATION_START=datetime(2026,6,14,tzinfo=UTC)
PUBLICATION_END=datetime(2026,9,30,tzinfo=UTC)

def sec(s):
    d=datetime.fromisoformat(s.replace('Z','+00:00'))
    gate.need(d.tzinfo is not None,'Naive source timestamp');return int(d.timestamp())
def stamp(d):return d.strftime('%Y%m%dT%H:%M-0000')
def event(kind,evidence):
    eid='guarded_confirmation_metadata_'+kind+'_'+gate.sha(evidence)
    gate.write(gate.ROOT/'event_driven_automation/inbox'/(eid+'.json'),dict(
        schema='caiso_research_event_v1',event_id=eid,event=kind,evidence_path=str(evidence),
        at=gate.now(),trial=str(HERE),new_test_targets_read=False))
    return eid
def status(**kwargs):gate.write(HERE/'metadata_queue/status.json',dict(at=gate.now(),pid=os.getpid(),**kwargs))
def handoff(stage,active,**extra):
    h=gate.read(gate.ROOT/'HANDOFF.json')
    h.update(at=gate.now(),status=stage,current_stage=stage,training_active=False,
             current_process=os.getpid() if active else None,current_plan_complete=False)
    h['guarded_confirmation']=dict(directory=str(HERE),stage=stage,metadata_active=active,
        metadata_status=str(HERE/'metadata_queue/status.json'),mechanism_result=str(HERE/'mechanisms/RESULT.json'),
        source_registration=str(HERE/'SOURCE_REGISTRATION.json'),test_targets_read=False,
        independent_period_admitted=False,periodic_wakeups=False,**extra)
    gate.write(gate.ROOT/'HANDOFF.json',h)
def bounds():
    a=PUBLICATION_START
    while a<PUBLICATION_END:
        b=min(a+timedelta(days=14),PUBLICATION_END);yield a,b;a=b
def parse(body,stream):
    selected=[];total=0
    with zipfile.ZipFile(io.BytesIO(body)) as z:
        for name in z.namelist():
            gate.need(z.getinfo(name).file_size<80_000_000,'Metadata expansion guard')
            with z.open(name) as f:
                if not name.lower().endswith('.csv'):
                    raise RuntimeError('Non-CSV metadata: '+f.read(1200).decode('utf-8','replace'))
                rows=csv.DictReader(io.TextIOWrapper(f,encoding='utf-8-sig',newline=''))
                needed={'REPORT_NAME','PUBLICATION_DATE_GMT','INTERVAL_START_GMT','INTERVAL_END_GMT','ATLPUBVERSION','STATUS','OASIS_REC_STAT'}
                gate.need(needed.issubset(rows.fieldnames or []),'Publication schema mismatch')
                for row in rows:
                    total+=1;k=STREAMS[stream][2].get(row['REPORT_NAME'])
                    if k is None or row['STATUS']!='Push Completed' or row['OASIS_REC_STAT']!='V':continue
                    a=sec(row['INTERVAL_START_GMT']);b=sec(row['INTERVAL_END_GMT'])
                    if b<=INPUT_START.timestamp() or a>=TEST_END.timestamp():continue
                    selected.append(dict(stream=k,start=a,end=b,published=sec(row['PUBLICATION_DATE_GMT']),
                        version=row['ATLPUBVERSION'],publication_id=row.get('PUBLICATION_ID'),
                        report=row['REPORT_NAME']))
    gate.need(total>0,'Empty metadata query')
    return total,selected
def prefix_bad(values):
    p=array('I',[0]);count=0
    for value in values:count+=not value;p.append(count)
    return p
def rolling_max(values,width):
    q=deque();out=array('q',[0])*(len(values)+1)
    for i,v in enumerate(values):
        while q and q[0]<=i-width:q.popleft()
        while q and values[q[-1]]<=v:q.pop()
        q.append(i);out[i+1]=values[q[0]]
    return out

def screen(receipts):
    start=int(INPUT_START.timestamp());end=int(TEST_END.timestamp());n=(end-start)//300
    keys=('price','rtd','dam_load','dam_renewable')
    latest={k:array('q',[0])*n for k in keys};first={k:array('q',[0])*n for k in keys};counts=Counter()
    for receipt in receipts:
        for row in gate.read(Path(receipt['ledger'])):
            k=row['stream'];lo=max(0,(row['start']-start)//300);hi=min(n,(row['end']-start)//300)
            if hi<=lo:continue
            counts[k]+=1
            for i in range(lo,hi):
                latest[k][i]=max(latest[k][i],row['published'])
                if row['version']=='New' and (first[k][i]==0 or row['published']<first[k][i]):first[k][i]=row['published']
    bad={k:prefix_bad(v) for k,v in latest.items()}
    p864=rolling_max(latest['price'],864);p288=rolling_max(latest['price'],288)
    r288=rolling_max(latest['rtd'],288);d288=rolling_max(latest['dam_load'],288)
    d300={k:rolling_max(latest[k],300) for k in ('dam_load','dam_renewable')}
    firstbad=prefix_bad(first['price']);neg=array('q',(-v for v in first['price']));target_min=rolling_max(neg,12)
    records=[];reasons=Counter();qualified_days=set()
    for origin in range((int(TEST_START.timestamp())-start)//300,n-11,12):
        cutoff=start+(origin-1)*300;flags=[]
        if (bad['price'][origin]-bad['price'][origin-864]+bad['price'][origin-2016]-bad['price'][origin-2304]+bad['price'][origin-4032]-bad['price'][origin-4320]):flags.append('price_publication_coverage_gap')
        if max(p864[origin],p288[origin-2016],p288[origin-4032])>cutoff:flags.append('price_latest_publication_after_cutoff')
        qs=((origin-1)//12-23)*12;qe=((origin+11)//12+1)*12
        for k in ('rtd','dam_load','dam_renewable'):
            a,b,last=(origin-288,origin,r288[origin]) if k=='rtd' else (origin-288,qe,max(d288[origin],d300[k][qe])) if k=='dam_load' else (qs,qe,d300[k][qe])
            if bad[k][b]-bad[k][a]:flags.append(k+'_publication_coverage_gap')
            if last>cutoff:flags.append(k+'_latest_publication_after_cutoff')
        if firstbad[origin+12]-firstbad[origin]:flags.append('target_initial_publication_missing')
        elif -target_min[origin+12]<=cutoff:flags.append('a_target_initial_publication_not_after_cutoff')
        when=datetime.fromtimestamp(start+origin*300,UTC).isoformat()
        records.append(dict(target_start_utc=when,cutoff_utc=datetime.fromtimestamp(cutoff,UTC).isoformat(),
            metadata_candidate=not flags,reasons=flags))
        reasons.update(flags)
        if not flags:qualified_days.add(when[:10])
    gate.write(HERE/'source_screen/origins.json',records)
    summary=dict(at=gate.now(),status='metadata_screen_complete_not_numeric_admission',
        registered_hourly_origins=len(records),metadata_candidates=sum(r['metadata_candidate'] for r in records),
        candidate_UTC_dates=len(qualified_days),all_reason_counts=dict(reasons),publication_event_counts=dict(counts),
        raw_price_or_forecast_values_read=False,test_targets_read=False,source_content_versions_bound=False,
        training_contract_compatibility_passed=False,independent_period_admitted=False,
        required_remaining=['Acquire exact raw sources without target-value decoding','Bind per-archive retrieval and publication coverage','Verify input completeness and trained feature contract','Freeze complete deployment pipeline before target release'],
        rule='Same dependency-window/version-time inequalities as prior H1 metadata gate; no sample filtering on price or error')
    gate.write(HERE/'source_screen/SUMMARY.json',summary)
    return summary

def main():
    gate.boundary();lock=HERE/'metadata_queue/manager.lock';lock.parent.mkdir(parents=True,exist_ok=True)
    with lock.open('x',encoding='utf-8') as f:f.write(str(os.getpid()))
    try:
        with gate.exclusive('guarded_confirmation_metadata_only'):
            handoff('guarded_confirmation_source_metadata_running',True)
            jobs=[(a,b,k) for a,b in bounds() for k in STREAMS]
            registration=HERE/'metadata_queue/PROTOCOL.json'
            if not registration.exists():gate.write(registration,dict(at=gate.now(),query_allowlist=['ATL_PUB'],
                source_registration_sha256=gate.sha(HERE/'SOURCE_REGISTRATION.json'),script_sha256=gate.sha(__file__),
                publication_start=PUBLICATION_START.isoformat(),publication_end=PUBLICATION_END.isoformat(),
                windows=[dict(start=a.isoformat(),end=b.isoformat(),stream=k) for a,b,k in jobs],
                request_start_gap_seconds=8,maximum_attempts=2,maximum_elapsed_seconds=1800,
                target_values_requested=False))
            receipts=[];begun=time.monotonic();last_request=-float('inf')
            for j,(a,b,k) in enumerate(jobs):
                gate.guard();gate.need(time.monotonic()-begun<1800,'Finite metadata time budget reached')
                ident=a.strftime('%Y%m%d')+'_'+b.strftime('%Y%m%d')+'_'+k
                path=HERE/'publication_receipts'/(ident+'.json')
                if path.exists() and gate.read(path).get('status')=='passed':
                    receipt=gate.read(path);gate.need(gate.sha(receipt['body'])==receipt['body_sha256'],'Cached body integrity');receipts.append(receipt);continue
                params=dict(queryname='ATL_PUB',market_run_id=STREAMS[k][0],oasis_section=STREAMS[k][1],status='ALL',
                    atlpubversion='ALL',version=1,startdatetime=stamp(a),enddatetime=stamp(b),resultformat=6)
                url='https://oasis.caiso.com/oasisapi/SingleZip?'+urlencode(params);attempts=[]
                for attempt in (1,2):
                    delay=max(0,8-(time.monotonic()-last_request))
                    if delay:time.sleep(delay)
                    gate.guard();last_request=time.monotonic()
                    status(event='metadata_request',completed=j,total=len(jobs),query=ident,attempt=attempt)
                    try:
                        with urlopen(Request(url,headers={'User-Agent':'CAISO-academic-source-admission/1.0'}),timeout=40) as response:
                            body=response.read(15_000_001);gate.need(len(body)<=15_000_000,'Compressed metadata limit')
                            headers={key:response.headers[key] for key in ('Date','Content-Type','Last-Modified') if response.headers[key]}
                        total,records=parse(body,k)
                        bodypath=HERE/'publication_receipts'/(ident+'.response');gate.atomic(bodypath,lambda f:f.write(body))
                        ledger=HERE/'publication_receipts'/(ident+'.records.json');gate.write(ledger,records)
                        receipt=dict(at=gate.now(),status='passed',params=params,url=url,body=str(bodypath),body_sha256=gate.sha(bodypath),
                            ledger=str(ledger),ledger_sha256=gate.sha(ledger),metadata_rows=total,relevant_events=len(records),headers=headers,attempts=attempts,
                            contains_market_values=False)
                        gate.write(path,receipt);receipts.append(receipt);break
                    except Exception as exc:
                        attempts.append(dict(at=gate.now(),attempt=attempt,error=repr(exc)))
                        gate.write(path,dict(status='failed',params=params,url=url,attempts=attempts))
                        if attempt==2:raise
                print(json.dumps(dict(completed=j+1,total=len(jobs),query=ident,relevant_events=receipt['relevant_events'])),flush=True)
            summary=screen(receipts)
            completion=HERE/'metadata_queue/completion.json';gate.write(completion,dict(at=gate.now(),status='metadata_feasibility_screen_completed',
                summary=str(HERE/'source_screen/SUMMARY.json'),summary_sha256=gate.sha(HERE/'source_screen/SUMMARY.json'),
                completed_queries=len(receipts),independent_period_admitted=False,test_targets_read=False))
            eid=event('major_milestone' if summary['metadata_candidates'] else 'needs_analysis',completion)
            status(event='finite_sampling_queue_completed',event_id=eid)
            handoff('guarded_confirmation_metadata_screen_complete',False,summary=str(HERE/'source_screen/SUMMARY.json'))
    except BaseException as exc:
        evidence=HERE/'metadata_queue/STOP.json';gate.write(evidence,dict(at=gate.now(),error=repr(exc),test_targets_read=False,
            partial_receipts_preserved=True,automatic_restart=False))
        paused=False
        try:gate.boundary()
        except InterruptedError:paused=True
        eid=None if paused else event('blocking_failure',evidence)
        status(event='user_stop' if paused else 'sampling_blocking_failure',event_id=eid,error=repr(exc));raise
    finally:
        gate.need(lock.read_text()==str(os.getpid()),'Metadata manager lock changed');lock.unlink()

if __name__=='__main__':main()
