"""Source-value checks. No forecasting, learning, scoring, or target API."""
import bisect
import csv
from datetime import datetime
import io
import math
import struct
import zipfile

COMPONENTS = ('LMP_PRC', 'LMP_ENE_PRC', 'LMP_CONG_PRC', 'LMP_LOSS_PRC')
EPOCH = int(datetime.fromisoformat('2023-06-01T00:00:00+00:00').timestamp())

def second(s):
    d = datetime.fromisoformat(s.replace('Z', '+00:00'))
    if d.tzinfo is None:
        raise ValueError('Source timestamp has no timezone')
    return int(d.timestamp())

def index(s):
    delta = second(s) - EPOCH
    if delta % 300:
        raise ValueError('Source timestamp off five-minute grid')
    return delta // 300

def merged(ranges):
    result = []
    for a,b in sorted(ranges):
        if a >= b:
            raise ValueError('Empty/reversed dependency')
        if result and a <= result[-1][1]:
            result[-1][1] = max(b,result[-1][1])
        else:
            result.append([a,b])
    return result

def packed(s):
    x = float(s)
    if not math.isfinite(x):
        raise ValueError('Nonfinite permitted historical source')
    value = struct.pack('<f', x)
    if not math.isfinite(struct.unpack('<f', value)[0]):
        raise ValueError('Historical value exceeds float32 range')
    return value

def permitted_value(row, stream, entity, allowed):
    """Inspect time/identity first. Never numerically parse excluded MW cells."""
    i = index(row['INTERVALSTARTTIME_GMT'])
    if i not in allowed:
        return None
    if stream == 'price':
        if row['NODE_ID'].strip() != entity:
            raise ValueError('Registered node identity mismatch')
        item = row['XML_DATA_ITEM'].strip()
        if item not in COMPONENTS:
            raise ValueError('Unexpected price component')
        component = COMPONENTS.index(item)
    else:
        wanted = {'TAC_AREA_NAME':'CA ISO-TAC', 'XML_DATA_ITEM':
            'SYS_FCST_5MIN_MW' if stream == 'rtd' else 'SYS_FCST_DA_MW',
            'MARKET_RUN_ID':'RTM' if stream == 'rtd' else 'DAM',
            'EXECUTION_TYPE':'RTD' if stream == 'rtd' else 'DAM'}
        if any(row[k].strip() != v for k,v in wanted.items()):
            return None
        component = 0
    return (i,component),packed(row['MW'])

def read_source(path, stream, entity, allowed, pulse=lambda: None):
    values = {}; equal_duplicates = 0; raw_rows = 0; headers = []
    with zipfile.ZipFile(path) as z:
        members = [s for s in z.namelist() if s.lower().endswith('.csv')]
        if not members:
            raise ValueError('No source CSV')
        for member in members:
            with z.open(member) as f, io.TextIOWrapper(f,encoding='utf-8-sig',newline='') as t:
                rows = csv.DictReader(t); headers.append(rows.fieldnames)
                required = {'INTERVALSTARTTIME_GMT','XML_DATA_ITEM','MW'}
                required |= {'NODE_ID'} if stream == 'price' else {'TAC_AREA_NAME','MARKET_RUN_ID','EXECUTION_TYPE'}
                if not required.issubset(rows.fieldnames or []):
                    raise ValueError('Source schema changed')
                for row in rows:
                    raw_rows += 1
                    if raw_rows % 8192 == 0:
                        pulse()
                    if None in row:
                        raise ValueError('Malformed source CSV row')
                    item = permitted_value(row,stream,entity,allowed)
                    if item is None:
                        continue
                    key,value = item
                    if key in values:
                        if stream == 'price' or values[key] != value:
                            raise ValueError('Duplicate/conflicting permitted source key')
                        equal_duplicates += 1
                    values[key] = value
    return values,dict(csv_members=members,headers=headers,rows_traversed=raw_rows,
        permitted_numeric_cells=len(values),equal_forecast_duplicates=equal_duplicates)

class ByteLookup:
    """Metadata-authorized union of input dependencies; no target slice access."""
    def __init__(self, cache, row_bytes):
        self.cache = cache; self.starts = [a for a,b,p in cache]; self.row_bytes = row_bytes
    def cell(self, row, position):
        j = bisect.bisect_right(self.starts,row)-1
        if j < 0 or not self.cache[j][0] <= row < self.cache[j][1]:
            raise PermissionError('Row is outside registered historical inputs')
        if not 0 <= position < self.row_bytes//4:
            raise ValueError('Column outside registered shape')
        a,b,p = self.cache[j]; offset = (row-a)*self.row_bytes+position*4
        return p[offset:offset+4]
