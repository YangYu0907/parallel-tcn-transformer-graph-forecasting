"""Compile origin-only sampling extensions after the existing queue completes.

No price, feature, prediction or heldout arrays are decoded. Original compiled
artifacts and their independent audit remain immutable and hash-bound.
"""
from collections import Counter
from datetime import datetime, timezone
from pathlib import Path
import argparse
import copy
import json
import sys
import uuid

sys.path.insert(0, str(Path(__file__).resolve().parent))
import preflight as gate
from schedule import build_sampling_plan, InfeasiblePlan

HERE, ROOT = gate.HERE, gate.ROOT
DATA = HERE / 'dataset'
REVIEW = HERE / 'COMPILER_REVIEW.json'


def source_paths():
    return [Path(__file__), HERE/'source/preflight.py', HERE/'source/schedule.py',
            HERE/'DIAGNOSTIC_PANEL_RULE.json', HERE/'PROTOCOL.json']


def metadata_check(require_prior=True):
    identity = gate.parent_admission()
    gate.source_review(REVIEW, source_paths())
    prior = gate.require_mechanisms_complete() if require_prior else None
    return dict(parent_identity=identity, prior_completion_sha256=prior,
                source_review_sha256=gate.sha(REVIEW))


def describe(origins, times):
    unique = sorted(set(origins))
    stamps = [int(times[o]) for o in unique]
    dates = [datetime.fromtimestamp(t, timezone.utc) for t in stamps]
    return dict(presentations=len(origins), unique_origins=len(unique),
                unique_clock_hours=len({t//3600 for t in stamps}),
                unique_calendar_days=len({d.date().isoformat() for d in dates}),
                unique_origins_by_year=dict(sorted(Counter(str(d.year) for d in dates).items())),
                unique_origins_by_month=dict(sorted(Counter(d.strftime('%Y-%m') for d in dates).items())),
                unique_origins_by_clock_phase=dict(sorted(Counter(str((t//300)%12) for t in stamps).items())),
                first_utc=min(dates).isoformat(), last_utc=max(dates).isoformat(),
                independent_sample_count_estimated=False, state_values_read=False)


def compile_plan():
    admission = metadata_check()
    gate.launch_guard()
    with gate.original.exclusive('compile_additive_sampling_metadata_only'):
        import compile_gate
        compile_gate.bound_process()
        import numpy as np
        gate.original.resource_guard()
        parent = gate.read(gate.PARENT)
        # Only origin and timestamp arrays are decoded; hash checks cover their provenance.
        needed = ['train_origins.npy', 'timestamps_seconds.npy'] + [f'epoch{e}_origins.npy' for e in range(1,7)]
        inputs = {}
        for name in needed:
            row = parent['artifacts'][name]
            path = gate.inside(row['path'])
            if gate.sha(path) != row['sha256']:
                raise RuntimeError('Parent origin/timestamp artifact changed: ' + name)
            values = np.load(path, allow_pickle=False)
            if values.ndim != 1 or values.dtype != np.dtype('int64'):
                raise RuntimeError('Expected one-dimensional int64 metadata: ' + name)
            inputs[name] = values.tolist()
        times = inputs['timestamps_seconds.npy']
        if len(times) != 219168 or any(b-a != 300 for a,b in zip(times,times[1:])):
            raise RuntimeError('Parent timestamps are not the exact regular five-minute prefix')
        eligible = inputs['train_origins.npy']
        if len(eligible) != 72316 or len(set(eligible)) != len(eligible) or any(o<288 or o+12>210528 for o in eligible):
            raise RuntimeError('Parent admitted TRAIN membership/boundary differs')
        anchors = [inputs[f'epoch{e}_origins.npy'] for e in range(1,7)]
        try:
            plan = build_sampling_plan(anchors, eligible, times, 210528)
        except InfeasiblePlan as exc:
            gate.write(HERE/'failures'/f'infeasible_{uuid.uuid4().hex}.json',
                       dict(status='infeasible', protocol_sha256=gate.sha(HERE/'PROTOCOL.json'),
                            certificate=exc.certificate, training_started=False))
            raise
        rule = gate.read(HERE/'DIAGNOSTIC_PANEL_RULE.json')
        panel = gate.diagnostic_panel(eligible, times, rule)

        def save_array(path, values):
            array = np.asarray(values, dtype=np.int64)
            if path.exists():
                previous = np.load(path, allow_pickle=False)
                if previous.dtype != array.dtype or not np.array_equal(previous, array):
                    raise RuntimeError('Immutable sampling array differs: ' + str(path))
            else:
                gate.original.atomic(path, lambda stream: np.save(stream, array, allow_pickle=False))
            return dict(path=str(path.relative_to(ROOT)), sha256=gate.sha(path))

        panel_artifact = save_array(DATA/'train_diagnostic_origins.npy', panel)
        plan.update(schema='caiso_additive_real_schedule_v1',
                    protocol_sha256=gate.sha(HERE/'PROTOCOL.json'),
                    scheduler_source_sha256=gate.sha(HERE/'source/schedule.py'),
                    compiler_source_sha256=gate.sha(__file__),
                    parent_manifest_sha256=gate.sha(gate.PARENT),
                    parent_audit_sha256=gate.sha(gate.PARENT.parent/'audit.json'),
                    prior_completion_sha256=admission['prior_completion_sha256'],
                    diagnostic_panel=dict(rule_sha256=gate.sha(HERE/'DIAGNOSTIC_PANEL_RULE.json'),
                                          artifact=panel_artifact, coverage=describe(panel,times)),
                    coverage={p: describe([o for e in plan['epochs'] for o in e[p]], times) for p in gate.POLICIES},
                    decoded_artifact_names=needed,
                    price_feature_or_target_values_decoded=False, heldout_targets_read=False)
        gate.immutable_json(DATA/'schedule.json', plan)
        for policy in gate.POLICIES:
            manifest = copy.deepcopy(parent)
            phase = dict(dataset_revision=parent['dataset_revision'], epochs=[],
                         every_shifted_origin_eligible=True, shared_across_variants_and_seeds=True,
                         June_hourly_origins=284, June_dense_origins=3397,
                         origin_selection_uses_Q3_errors=False, sampling_policy=policy,
                         original_hourly_origins_retained_each_epoch=2016,
                         diagnostic_panel=panel_artifact)
            for epoch, row in enumerate(plan['epochs'],1):
                origins = row[policy]
                name = f'epoch{epoch}_origins.npy'
                art = save_array(DATA/policy/name, origins)
                manifest['artifacts'][name] = art
                manifest['artifacts'][f'epoch{epoch}_phases.npy'] = save_array(
                    DATA/policy/f'epoch{epoch}_phases.npy', [(times[o]//300)%12 for o in origins])
                phase['epochs'].append(dict(epoch=epoch, origins_path=art['path'], count=len(origins),
                    sha256=art['sha256'], updates=len(origins)//4, max_target_end_exclusive=max(origins)+12))
            unique = sorted({o for row in plan['epochs'] for o in row[policy]})
            manifest['artifacts']['unique_phase_origins.npy'] = save_array(DATA/policy/'unique_phase_origins.npy',unique)
            phase['unique_origins'] = len(unique)
            gate.immutable_json(DATA/policy/'phase_manifest.json',phase)
            manifest['artifacts']['phase_manifest.json'] = dict(
                path=str((DATA/policy/'phase_manifest.json').relative_to(ROOT)),
                sha256=gate.sha(DATA/policy/'phase_manifest.json'))
            manifest['status'] = 'sampling_extension_pending_independent_origin_audit'
            manifest['training_allowed'] = False
            manifest['sampling_extension'] = dict(policy=policy, protocol_sha256=gate.sha(HERE/'PROTOCOL.json'),
                schedule_sha256=gate.sha(DATA/'schedule.json'), parent_manifest_sha256=gate.sha(gate.PARENT),
                parent_audit_sha256=gate.sha(gate.PARENT.parent/'audit.json'))
            gate.immutable_json(DATA/policy/'manifest.json',manifest)
        if metadata_check() != admission:
            raise RuntimeError('Metadata changed during sampling compilation')
        receipt = dict(status='compiled_sampling_metadata_pending_independent_audit',
            schedule_sha256=gate.sha(DATA/'schedule.json'),
            manifests={p:gate.sha(DATA/p/'manifest.json') for p in gate.POLICIES},
            source_review_sha256=gate.sha(REVIEW), training_started=False,
            actual_target_values_read=False, heldout_targets_read=False)
        gate.immutable_json(DATA/'compile_completion.json',receipt)
        return receipt


def main():
    parser=argparse.ArgumentParser(description=__doc__)
    parser.add_argument('action',choices=('check','run'))
    args=parser.parse_args()
    result = metadata_check() if args.action=='check' else compile_plan()
    print(json.dumps(result,ensure_ascii=True))


if __name__=='__main__':
    main()
