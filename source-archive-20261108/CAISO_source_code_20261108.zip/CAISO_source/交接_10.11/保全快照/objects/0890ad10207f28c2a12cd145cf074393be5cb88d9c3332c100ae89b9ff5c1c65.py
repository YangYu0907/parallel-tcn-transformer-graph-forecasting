"""Validate preserved data and I/O repair, without any new model fitting."""
from pathlib import Path
import os, sys, json, importlib.util
for key in ['OMP_NUM_THREADS','MKL_NUM_THREADS','OPENBLAS_NUM_THREADS','NUMEXPR_NUM_THREADS']: os.environ[key]='1'
R=Path(__file__).resolve().parent;W=R.parent;Z=W.parent
sys.path[:0]=[str(R),str(W),str(Z),str(Z/'fit4_1009')]
import support as s
from safe_io import install
write=install(s)
import numpy as np
import compare
from features import calendar
import audit

def main():
    assert not (R/'PROTOCOL.json').exists(),'Existing recovery registration'
    s.verify();p=s.read(W/'PROTOCOL.json')
    for item in [p,s.read(W/'QA.json')]:
        for path,h in item['bindings'].items(): assert s.sha(path)==h,path
    assert not (W/'MANAGER.lock').exists() and not (W/'RESULT.json').exists()
    paths=[W/'PROTOCOL.json',W/'QA.json',W/'FAILURE.json',R/'safe_io.py',R/'manager.py',R/'prepare.py',R/'launch.ps1']
    paths += list((W/'Q1_2025').glob('*/COMPLETE.json'))
    protocol=dict(at=s.now(),purpose='Engineering I/O repair only; same registered models, indices, losses, seeds, metrics and freeze rules',root_cause='Old UUID temporary basename produced263-character Windows path for Q2 HISTORY/DESIGN.json',remaining_new_fits=3,completed_new_fits=1,reused_model_cells=2,global_source_modified=False,V7_replaced=False,new_test_targets_read=False,periodic_model_wakeups=False,bindings={str(v):s.sha(v) for v in paths})
    write(R/'PROTOCOL.json',protocol)
    checks=[]
    test=W/'Q2_partial_2025'/'HISTORY'/'IO_QA.json'
    assert not test.exists()
    data={'text':'检查点保留','nested':{'shape':[1277197,29]},'nan':None}
    try:
        write(test,data)
        assert test.read_text(encoding='utf-8')==json.dumps(data,ensure_ascii=False,indent=2,allow_nan=False)
        data['overwrite']=True;write(test,data);assert s.read(test)==data
        original_bytes=test.read_bytes()
        try: write(test,{'bad':float('nan')})
        except ValueError: pass
        else: raise AssertionError('Non-finite JSON accepted')
        assert test.read_bytes()==original_bytes
        checks.append('Long-path atomic create/replace and serialization equal; failed serialization preserves destination')
        try:write(Z.parent/'DISALLOWED_IO_QA.json',{})
        except AssertionError:pass
        else:raise AssertionError('Path escape accepted')
        assert not list(test.parent.glob('.j*'));checks.append('Root escape rejected and no temporary leftovers')
    finally:
        if test.exists():test.unlink()
    with s.base.numeric('Checkpoint and full-row recovered design verification; zero training'):
        count=0
        for arm in p['arms']:
            cell=W/'Q1_2025'/arm;rec=s.read(cell/'COMPLETE.json')
            for path,h in rec['bindings'].items():assert s.sha(path)==h,path
            with np.load(cell/'PREDICTIONS.npz') as a:
                pr=a['evaluation'];ths=rec['result']['thresholds']
                alarms=np.column_stack([pr[:,c]>ths[c-1] for c in [1,2]])
                m=audit.summarize(a['y'],pr,alarms)
                for sign in ['up','down']:
                    for key in ['brier','logloss','TP','FP','precision','recall','FPR']:
                        assert abs(m[sign][key]-rec['result']['metrics'][sign][key])<1e-12
                        count+=1
        checks.append('Three completed cell bindings and42 metric equalities replayed')
        with np.load(W/'INDICES.npz') as a:
            fit=a['Q2_partial_2025_fit'];rows=a['row'];tm=a['time']
        target=W/'Q2_partial_2025'/'HISTORY'/'design.npy';before=s.sha(target)
        mm=np.load(target,mmap_mode='r');x=np.load(compare.N/'features.npy',mmap_mode='r')
        assert mm.shape==(len(fit),29) and mm.dtype==np.float32
        for begin in range(0,len(fit),8192):
            ii=fit[begin:begin+8192]
            expected=np.concatenate([np.asarray(x[rows[ii]],np.float32),calendar(tm[ii]).astype(np.float32)],axis=1)
            assert np.array_equal(mm[begin:begin+len(ii)],expected),begin
            if begin%131072==0:s.guard()
        mm._mmap.close();x._mmap.close();assert s.sha(target)==before
        metadata=target.with_name('DESIGN.json');assert not metadata.exists()
        write(metadata,dict(at=s.now(),sha256=before,rows=len(fit),features=29,recovered_after_full_row_equality=True))
        checks.append('All1277197 cached HISTORY rows exactly equal source histories and calendar; no data rewriting')
    bound=[R/'PROTOCOL.json',R/'prepare.py',R/'safe_io.py',metadata,target]
    result=dict(at=s.now(),passed=True,checks=checks,completed_cell_metric_equalities=count,remaining_new_fits=3,bindings={str(v):s.sha(v) for v in bound})
    write(R/'QA.json',result)
    print(json.dumps(result,ensure_ascii=False))
if __name__=='__main__':main()
