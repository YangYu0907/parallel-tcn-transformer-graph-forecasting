"""Fixed low-LR continuation, preserving six-epoch models and every prefix artifact."""
import argparse,copy,hashlib,json,random,sys,uuid,gc
import gate
np=torch=None
def fingerprint(model):
 h=hashlib.sha256()
 for k,v in sorted(model.state_dict().items()):h.update(k.encode());h.update(v.detach().cpu().contiguous().numpy().tobytes())
 return h.hexdigest()
def runtime_stamp():
 return dict(python=sys.version,executable=sys.executable,numpy=np.__version__,torch=torch.__version__,threads=1,interop=1,deterministic=True)
def optimizer(model):return torch.optim.AdamW(model.parameters(),lr=.0001,weight_decay=.0001,betas=(.9,.999),eps=1e-8)
def weighted_huber(p,y,w):
 gate.need(w.ndim==1 and len(w)==len(p) and torch.isfinite(w).all() and (w>0).all(),'Invalid origin weights')
 point=torch.nn.functional.huber_loss(p,y,delta=.5,reduction='none')
 return (point*w.reshape((-1,)+(1,)*(p.ndim-1))).mean()

def update(model,opt,x,y,weights=None):
 opt.zero_grad(set_to_none=True);p=model(x)['prediction'];loss=weighted_huber(p,y,torch.ones(len(p),dtype=p.dtype) if weights is None else weights)
 gate.need(torch.isfinite(loss),'Nonfinite Huber');loss.backward()
 gate.need(all(p.grad is not None and torch.isfinite(p.grad).all() for p in model.parameters() if p.requires_grad),'Missing/nonfinite gradient')
 norm=torch.nn.utils.clip_grad_norm_(model.parameters(),1.);gate.need(torch.isfinite(norm),'Gradient norm')
 opt.step();return float(loss.detach()),float(norm)
def rng_get(rng):
 return dict(torch=torch.get_rng_state().clone(),numpy_generator=copy.deepcopy(rng.bit_generator.state),numpy_global=np.random.get_state(),python=random.getstate())
def rng_set(r,rng):
 torch.set_rng_state(r['torch']);rng.bit_generator.state=copy.deepcopy(r['numpy_generator']);np.random.set_state(r['numpy_global']);random.setstate(r['python'])
def validate(state):
 e=state['epoch'];gate.need(6<=e<=12,'Epoch range')
 if state['phase']=='epoch_complete':
  gate.need(state['steps']==e*1008 and len(state['epochs'])==e and state['offset']==0 and state['order'] is None,'Complete cursor')
 else:
  gate.need(state['phase']=='train' and 7<=e<=12 and len(state['epochs'])==e-1,'Train epoch')
  gate.need(state['offset']%4==0 and 0<=state['offset']<=4032 and np.array_equal(np.sort(state['order']),np.arange(4032)),'Shuffle cursor')
  gate.need(state['steps']==(e-1)*1008+state['offset']//4,'Update cursor')
def checkpoint(run,model,opt,rng,state,identity,name=None):
 validate(state);p=run/'checkpoints'/(name or ('c_'+uuid.uuid4().hex+'.pt'))
 value=dict(identity=identity,runtime=runtime_stamp(),state_dict=copy.deepcopy(model.state_dict()),optimizer=copy.deepcopy(opt.state_dict()),
  rng=rng_get(rng),progress=copy.deepcopy(state),model_training=model.training,scope='phase_weighted_continuation_backbone_only',
  scheduler=dict(epoch=state['epoch'],rule='epochs7to12_fixed_terminal_lr',lr=.0001))
 gate.atomic(p,lambda f:torch.save(value,f))
 ref=dict(path=gate.rel(p),sha256=gate.sha(p),steps=state['steps'],epoch=state['epoch'],phase=state['phase'],at=gate.now(),identity=identity)
 gate.write(p.with_suffix('.receipt.json'),ref);gate.write(run/'latest.json',ref,True);return ref
def recover(run,identity):
 refs=[]
 for p in (run/'checkpoints').glob('*.receipt.json'):
  r=gate.read(p);target=gate.inside(r['path'])
  gate.need(target.parent==(run/'checkpoints').resolve() and target.with_suffix('.receipt.json')==p and gate.sha(target)==r['sha256'] and r['identity']==identity,'Resume receipt')
  refs.append(r)
 if not refs:return None
 if (run/'latest.json').exists():gate.need(gate.read(run/'latest.json') in refs,'Pointer without receipt')
 r=max(refs,key=lambda r:(r['steps'],r['epoch'],r['phase']=='epoch_complete',r['at']))
 value=torch.load(gate.inside(r['path']),map_location='cpu',weights_only=False)
 gate.need(value['identity']==identity and value['runtime']==runtime_stamp() and value['scope']=='phase_weighted_continuation_backbone_only','Resume identity/runtime')
 return value
def evaluate(model,data,part,order):
 import reductions as red
 origins=data.origins[part];pred=np.empty((len(origins),30,12),np.float64);truth=np.empty_like(pred);codes=np.empty(pred.shape,np.uint8)
 q=np.array(gate.read(data.paths['state_thresholds.json'])['thresholds'],np.float64)
 model.eval();before=fingerprint(model);rng=torch.get_rng_state().clone()
 # Preserve requires_grad flags: floating-point dispatch changed previously when disabled.
 with torch.no_grad():
  for start in range(0,len(order),4):
   gate.guard();ix=order[start:start+4];x,y=data.batch(part,ix)
   pred[ix]=model(torch.from_numpy(x))['prediction'].numpy().astype(np.float64)*data.scale[None,:,None]+data.center[None,:,None]
   truth[ix]=y.astype(np.float64)*data.scale[None,:,None]+data.center[None,:,None]
   codes[ix]=red.codes(truth[ix],x[:,-1,:,0],data.center,data.scale,q)
 gate.need(fingerprint(model)==before and torch.equal(rng,torch.get_rng_state()) and np.isfinite(pred).all(),'Evaluation mutated model/RNG or nonfinite')
 return dict(origins=origins.copy(),prediction=pred,truth=truth,codes=codes)
def save_eval(run,name,arrays):
 p=run/'evaluation'/(name+'_'+uuid.uuid4().hex+'.npz');gate.atomic(p,lambda f:np.savez(f,**arrays))
 return dict(path=gate.rel(p),sha256=gate.sha(p))
def run(case_id,resume=False):
 global np,torch
 seal=gate.verify();case=next(c for c in seal['cases'] if c['id']==case_id)
 run=gate.HERE/'runs'/case_id
 gate.need(resume==run.exists(),'Existing run needs resume; missing run cannot resume')
 identity=dict(case=case,execution_lock_sha256=gate.sha(gate.SEAL),protocol_sha256=gate.sha(gate.HERE/'PROTOCOL.json'))
 with gate.exclusive('budget_'+case_id):
  np,torch,lim=gate.runtime();sys.path.append(str(gate.COMMON))
  import reductions as red
  from compiled_data import CompiledData
  from model_io import build
  data=CompiledData(seal['dataset_manifest']);weight_table=np.asarray(gate.read(gate.HERE/'WEIGHTS.json')['weights'],np.float32);diag=np.load(gate.inside(seal['train_diagnostic']),allow_pickle=False)
  gate.need(diag.shape==(288,) and (diag+12<=210528).all(),'TRAIN diag')
  data.origins['diagnostic']=diag
  limits=gate.read(data.paths['context_limits.json'])['limits']
  model=build(case['variant'],case['seed'],limits);opt=optimizer(model);rng=np.random.default_rng(case['seed'])
  parent=torch.load(gate.inside(case['terminal_checkpoint']),map_location='cpu',weights_only=False)
  gate.need(parent['identity']==case['parent']['identity'] and parent['runtime']==runtime_stamp(),'Parent identity/runtime')
  gate.need(parent['progress']['epoch']==6 and parent['progress']['steps']==6048 and parent['progress']['phase']=='epoch_complete','Terminal parent required')
  model.load_state_dict(parent['state_dict'],strict=True);opt.load_state_dict(parent['optimizer'])
  gate.need(all(g['lr']==.0001 for g in opt.param_groups),'Terminal LR not floor')
  rng_set(parent['rng'],rng);model.train(parent['model_training']);state=copy.deepcopy(parent['progress'])
  state['train_curves_new']=[]
  start=dict(identity=identity,runtime=runtime_stamp(),parent_checkpoint_sha256=case['terminal_sha256'],parent_fingerprint=fingerprint(model),
   parent_steps=6048,active_parameters=sum(p.numel() for p in model.parameters() if p.requires_grad),scope='matched_phase_weighting_epochs7to12')
  if (run/'run_start.json').exists():gate.need(gate.read(run/'run_start.json')==start,'Run start changed')
  else:gate.write(run/'run_start.json',start)
  saved=recover(run,identity) if resume else None
  if saved:
   model.load_state_dict(saved['state_dict'],strict=True);opt.load_state_dict(saved['optimizer']);rng_set(saved['rng'],rng)
   model.train(saved['model_training']);state=saved['progress'];del saved
  for g in opt.param_groups:gate.need(g['lr']==.0001 and g['weight_decay']==.0001 and g['betas']==(.9,.999) and g['eps']==1e-8,'Optimizer recipe')
  validate(state)
  try:
   if not (run/'prefix_replay.json').exists():
    gate.need(state['steps']==6048,'Prefix replay absent beyond parent')
    z=evaluate(model,data,'june',np.arange(len(data.origins['june'])))
    previous=parent['progress']['epochs'][-1];original=np.load(gate.inside(previous['prediction']),allow_pickle=False)
    diff=float(np.max(np.abs(z['prediction']-original)));gate.need(diff==0,'Terminal prefix prediction differs')
    gate.write(run/'prefix_replay.json',dict(status='passed',maximum_prediction_difference=diff,origins=284,parent_sha256=case['terminal_sha256']))
   del parent
   if not (run/'latest.json').exists():checkpoint(run,model,opt,rng,state,identity)
   while state['phase']=='train' or state['epoch']<12:
    gate.guard()
    if state['phase']=='epoch_complete':
     epoch=state['epoch']+1
     state.update(phase='train',epoch=epoch,offset=0,order=rng.permutation(4032),train_huber_sum=0.,gradient_norm_sum=0.)
     checkpoint(run,model,opt,rng,state,identity)
    epoch=state['epoch'];data.set_epoch((epoch-1)%6+1)
    gate.need(len(data.origins['train'])==4032 and (data.origins['train']+12<=210528).all(),'Repeated TRAIN phase escaped')
    model.train();validate(state)
    while state['offset']<4032:
     gate.boundary();ix=state['order'][state['offset']:state['offset']+4];x,y=data.batch('train',ix)
     loss,norm=update(model,opt,torch.from_numpy(x),torch.from_numpy(y),torch.from_numpy(weight_table[data.origins['train'][ix]%12]))
     state['steps']+=1;state['offset']+=4;state['train_huber_sum']+=loss*4;state['gradient_norm_sum']+=norm*4
     if state['steps']%32==0 or state['offset']==4032:
      checkpoint(run,model,opt,rng,state,identity);gate.guard()
      print(json.dumps(dict(event='budget_progress',case=case_id,epoch=epoch,steps=state['steps'],at=gate.now())),flush=True)
    arr=evaluate(model,data,'june',np.arange(284));ref=save_eval(run,'epoch'+str(epoch)+'_june',arr)
    diag_arr=evaluate(model,data,'diagnostic',np.arange(288));diagref=save_eval(run,'epoch'+str(epoch)+'_train',diag_arr)
    name='e'+str(epoch)+'_'+uuid.uuid4().hex+'.pt'
    row=dict(epoch=epoch,june=red.headline(arr['prediction']-arr['truth']),lr=.0001,train_origins=4032,
     optimizer_steps=state['steps'],train_huber_mean=state['train_huber_sum']/4032,gradient_norm_mean=state['gradient_norm_sum']/4032,
     checkpoint=gate.rel(run/'checkpoints'/name),evaluation=ref,source_phase=(epoch-1)%6+1,
     weights_sha256=gate.sha(gate.HERE/'WEIGHTS.json'),shuffle_sha256=hashlib.sha256(state['order'].tobytes()).hexdigest(),
     phase_counts=np.bincount(data.origins['train']%12,minlength=12).tolist())
    state['epochs'].append(row);state['train_curves_new'].append(dict(epoch=epoch,evaluation=diagref,metrics=red.breakdown(diag_arr['prediction']-diag_arr['truth'],diag_arr['codes'],diag)))
    state.update(phase='epoch_complete',offset=0,order=None);checkpoint(run,model,opt,rng,state,identity,name)
    print(json.dumps(dict(event='epoch_complete',case=case_id,epoch=epoch,mae=row['june']['mae'])),flush=True)
   validate(state);gate.need(state['steps']==12096,'Finite budget incomplete')
   best=None
   for row in state['epochs']:
    if best is None or row['june']['mae']<best['june']['mae']-1e-6:best=row
   path=gate.inside(best['checkpoint']);rr=gate.read(path.with_suffix('.receipt.json'));gate.need(gate.sha(path)==rr['sha256'],'Selected checkpoint')
   selected=torch.load(path,map_location='cpu',weights_only=False);model.load_state_dict(selected['state_dict'],strict=True);del selected;gc.collect()
   dense=data.origins['june_dense'];panels,blocks=red.panels(dense,data.origins['june']);reg=panels['June284']
   order=np.r_[reg,np.flatnonzero(~np.isin(np.arange(len(dense)),reg))]
   arr=evaluate(model,data,'june_dense',order);dense_ref=save_eval(run,'selected_dense',arr)
   if best['epoch']<=6:expected=np.load(gate.inside(best['prediction']),allow_pickle=False)
   else:
    with np.load(gate.inside(best['evaluation']['path']),allow_pickle=False) as z:expected=z['prediction']
   gate.need(np.array_equal(arr['prediction'][reg],expected),'Selected registered predictions changed')
   metric_panels={pn:red.breakdown((arr['prediction']-arr['truth'])[ix],arr['codes'][ix],dense[ix]) for pn,ix in panels.items()}
   gate.verify()
   gate.write(run/'completion.json',dict(status='phase_weighted_run_completed_pending_audit',at=gate.now(),identity=identity,epochs=state['epochs'],
    selected_epoch=best['epoch'],selected_checkpoint=best['checkpoint'],optimizer_steps=12096,new_updates=6048,prefix_updates=6048,
    dense_evaluation=dense_ref,panels=metric_panels,train_curves_new=state['train_curves_new'],
    heldout_targets_read=False,complete_research_experiment=False))
   print(json.dumps(dict(event='budget_case_completed',case=case_id,selected_epoch=best['epoch'])),flush=True)
   return 0
  except (InterruptedError,MemoryError) as exc:
   if state['steps']<12096 or state['phase']!='epoch_complete':cp=checkpoint(run,model,opt,rng,state,identity)
   else:cp=gate.read(run/'latest.json')
   gate.write(run/'stops'/('stop_'+uuid.uuid4().hex+'.json'),dict(at=gate.now(),reason=repr(exc),checkpoint=cp));return 3
if __name__=='__main__':
 p=argparse.ArgumentParser();p.add_argument('--case',required=True);p.add_argument('--resume',action='store_true');x=p.parse_args()
 raise SystemExit(run(x.case,x.resume))
