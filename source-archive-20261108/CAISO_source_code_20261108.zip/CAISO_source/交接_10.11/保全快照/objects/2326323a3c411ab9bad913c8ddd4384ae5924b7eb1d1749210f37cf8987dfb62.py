from pathlib import Path
import os,sys,json
E=Path(__file__).resolve().parent;W=E.parent;Z=W.parent;B=Z.parent.parent;D=W/'dam_batch_1009'
for key in ['OMP_NUM_THREADS','MKL_NUM_THREADS','OPENBLAS_NUM_THREADS','NUMEXPR_NUM_THREADS']:os.environ[key]='1'
sys.path.insert(0,str(Z));sys.path.insert(0,str(Z/'fit4_1009'))
import support as s
sys.path.insert(0,str(E))
read=s.read;sha=s.sha;now=s.now
def write(path,data):
 p=Path(path);assert p.resolve().is_relative_to(E.resolve());p.parent.mkdir(parents=True,exist_ok=True)
 tmp=p.with_name('.j'+os.urandom(4).hex());tmp.write_text(json.dumps(data,ensure_ascii=False,indent=2,allow_nan=False),encoding='utf-8');os.replace(tmp,p)
def save(path,**arrays):
 import numpy as np
 p=Path(path);assert p.resolve().is_relative_to(E.resolve());p.parent.mkdir(parents=True,exist_ok=True);tmp=p.with_name('.n'+os.urandom(4).hex())
 with tmp.open('wb') as f:np.savez_compressed(f,**arrays)
 os.replace(tmp,p)
def guard(launch=False):
 for n in ['STOP_REQUESTED','STOP_REQUESTED.json']:
  if (E/n).exists():raise InterruptedError('User stop '+str(E/n))
 return s.guard(launch)
def verify():
 p=read(E/'PROTOCOL.json')
 for path,h in p['bindings'].items():assert sha(path)==h,path
 for path,h in read(Z/'PROTECTED_FILES.json').items():assert sha(path)==h,path
 assert read(E/'QA.json')['passed']
 return p
