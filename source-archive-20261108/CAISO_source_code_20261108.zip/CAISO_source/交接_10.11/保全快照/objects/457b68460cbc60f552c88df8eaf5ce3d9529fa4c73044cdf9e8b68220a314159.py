"""Separate formula/scoring replay; same operator, not external peer review."""
from common import *
import math

ARMS=['FULL','V7','ONSET_ONLY','EXIT_ONLY','COMBINED']

def scalar_rule(b,f,mu,md,p,ext,c):
    a=mu-b;z=md-b
    step=0. if a*z<=0 else math.copysign(min(abs(a),abs(z)),a)
    onset=b;exit_only=b
    if not ext and (b-c)*step>0:onset=b+.75*p*step
    if ext and step*(f-b)>0 and abs(f-c)<abs(b-c):
        exit_only=b+.75*(1-p)*math.copysign(min(abs(f-b),abs(step)),f-b)
    return onset,exit_only,exit_only if ext else onset

def main():
    with gate.exclusive('V12 separate model replay, formula and all-direction scoring audit'):
        np,lim=gate.runtime(False);verify();start_budget()
        from sklearn.metrics import average_precision_score,roc_auc_score
        tr=readnp(ART/'TRAIN.npz');he=readnp(ART/'H1_INPUTS.npz');panel=readnp(A/'adaptive_experts_v4_20260929/panel.npz');ids=he['eval_indices']
        adm=gate.read(HERE/'DATA_ADMISSION.json')
        for p,h in adm['artifacts'].items():assert gate.sha(p)==h,p
        assert tr['days'][tr['fit']].max()<tr['days'][tr['cal']].min()-1
        assert not np.any(tr['fit']&tr['cal'])
        assert set(tr['origins'][tr['fit']]).isdisjoint(tr['origins'][tr['cal']])
        y=panel['truth'][ids];st=panel['states'][ids];days=panel['days'][ids]
        low=np.broadcast_to(panel['low_volatility'][ids,:,None],y.shape)
        m=gate.read(B/'phase_sampling_support_v3_20260923/dataset/ADDITIVE/manifest.json');q=np.array(gate.read(gate.resolve(m['artifacts']['state_thresholds.json']['path']))['thresholds'])[1]
        def basic(e):return dict(mae=float(abs(e).mean()),rmse=float(np.sqrt(np.mean(e*e))))
        def metrics(p):
            e=p-y;positive=np.maximum(e,0);s3=st==3
            return dict(**basic(e),near_mae=float(abs(e[:,:,:4]).mean()),h12_mae=float(abs(e[:,:,11]).mean()),low_volatility_mae=float(abs(e[low]).mean()),
                S3_positive_error_q99=float(np.quantile(positive[s3],.99)),S3_severe_overestimate_rate=float((e>q[None,:,None])[s3].mean()),
                states={str(s):basic(e[st==s]) for s in range(6)},nodes=[basic(e[:,n]) for n in range(30)],horizons=[basic(e[:,:,h]) for h in range(12)])
        rows=[];replays=[];stored={};events=[];activation=[]
        for seed in SEEDS:
            check(stage='audit_predictions',seed=seed)
            out=readnp(ART/f'predictions/{seed}.npz');receipt=gate.read(HERE/f'receipts/{seed}.json');assert gate.sha(ART/f'predictions/{seed}.npz')==receipt['sha256']
            for p,h in receipt['models'].items():assert gate.sha(p)==h,p
            old=readnp(A/f'spike_specialist_v7_20260930/predictions/{seed}.npz');assert np.array_equal(old['CONTEXT'],out['V7']) and np.array_equal(out['origins'],he['origins'])
            old=readnp(A/f'adaptive_experts_v4_20260929/experts/{seed}.npz');assert np.array_equal(old['experts'][ids,...,0],out['FULL']);del old
            assert np.array_equal(out['current_extreme'],he['current_extreme'])
            ext=np.broadcast_to(he['current_extreme'][...,None],y.shape);center=np.broadcast_to(he['center'][None,:,None],y.shape)
            flat=[out[k].ravel() for k in ('V7','FULL','conditional_mean','conditional_median','event_probability')]
            replay=np.array([scalar_rule(*v) for v in zip(*flat,ext.ravel(),center.ravel())]).T.reshape(3,*y.shape)
            for j,name in enumerate(ARMS[2:]):assert np.allclose(replay[j],out[name],rtol=0,atol=1e-10),name
            assert np.array_equal(out['EXIT_ONLY'][~ext],out['V7'][~ext]);assert np.array_equal(out['ONSET_ONLY'][ext],out['V7'][ext])
            assert np.all(out['COMBINED'][ext]>=np.minimum(out['FULL'],out['V7'])[ext]-1e-10)
            assert np.all(out['COMBINED'][ext]<=np.maximum(out['FULL'],out['V7'])[ext]+1e-10)
            # Re-run sparse deterministic prediction rows from saved estimators.
            pair=np.linspace(0,he['X'].shape[0]*30-1,400,dtype=int)
            for mode in (0,1):
                use=pair[he['current_extreme'].ravel()[pair]==mode]
                if not len(use):use=np.flatnonzero(he['current_extreme'].ravel()==mode)[:50]
                xx=np.column_stack([np.repeat(he['X'].reshape(-1,90)[use],12,axis=0),np.tile(np.arange(1,13)/12,len(use))]).astype(np.float32)
                for task,key in [('mean','conditional_mean'),('median','conditional_median'),('event','event_probability')]:
                    obj=load(ART/f'models/{seed}_{mode}_{task}.pkl');model=obj['model'];assert model.n_iter_==80
                    assert obj['identity']['rows']==int((tr['fit']&(tr['current_extreme']==mode)).sum())
                    if task=='event':
                        temp=gate.read(HERE/f'calibration/{seed}_{mode}.json')['temperature'];p=model.predict_proba(xx)[:,1];p=np.clip(p,1e-9,1-1e-9);pr=1/(1+np.power((1-p)/p,1/temp))
                    else:pr=model.predict(xx)*100.+np.repeat(he['raw_now'].ravel()[use],12)
                    assert np.allclose(pr.reshape(-1,12),out[key].reshape(-1,12)[use],rtol=1e-10,atol=1e-8)
                replays.append(dict(seed=seed,mode=mode,pairs=len(use),horizons=12))
            stored[seed]={a:out[a] for a in ARMS}
            for name,p in stored[seed].items():
                assert np.isfinite(p).all();r=metrics(p)
                assert math.isclose(r['mae'],math.fsum(abs(p-y).ravel())/y.size,rel_tol=1e-13)
                rows.append(dict(seed=seed,arm=name,**r))
            activation.append(dict(seed=seed,changes_by_state={str(s):int(np.sum((abs(out['COMBINED']-out['V7'])>1e-10)&(st==s))) for s in range(6)}))
            for mode in (0,1):
                mask=ext if mode else ~ext;ev=(st%3==2)[mask];p=out['event_probability'][mask]
                events.append(dict(seed=seed,mode=mode,cells=len(ev),prevalence=float(ev.mean()),brier=float(np.mean((p-ev)**2)),AUPRC=float(average_precision_score(ev,p)),AUROC=float(roc_auc_score(ev,p)),recall_at_half=float(np.mean(p[ev]>=.5)),false_positive_rate_at_half=float(np.mean(p[~ev]>=.5))))
            save(ART/f'audited/{seed}.npz',truth=y,states=st,**stored[seed])
        scalar=['mae','rmse','near_mae','h12_mae','low_volatility_mae','S3_positive_error_q99','S3_severe_overestimate_rate'];summary={}
        for name in ARMS:
            rr=[r for r in rows if r['arm']==name];a={k:float(np.mean([r[k] for r in rr])) for k in scalar}
            a['states']={str(s):{k:float(np.mean([r['states'][str(s)][k] for r in rr])) for k in ('mae','rmse')} for s in range(6)}
            for g,n in [('nodes',30),('horizons',12)]:a[g]=[{k:float(np.mean([r[g][i][k] for r in rr])) for k in ('mae','rmse')} for i in range(n)]
            summary[name]=a
        f=summary['FULL'];b=summary['V7'];c=summary['COMBINED'];lost=[];triples=[]
        for k in scalar[:5]:triples.append((k,f[k],b[k],c[k]))
        for g,n in [('states',6),('nodes',30),('horizons',12)]:
            for j in range(n):
                ix=str(j) if g=='states' else j
                for k in ('mae','rmse'):triples.append((f'{g}.{j}.{k}',f[g][ix][k],b[g][ix][k],c[g][ix][k]))
        for name,a,old,new in triples:
            if old<a and not new<a:lost.append(dict(metric=name,FULL=a,V7=old,COMBINED=new))
        checks=dict(previous_positive_directions_preserved=not lost,overall_MAE_RMSE_not_worse_than_V7=c['mae']<=b['mae'] and c['rmse']<=b['rmse'],
            S2_both_improved=all(c['states']['2'][k]<min(b['states']['2'][k],f['states']['2'][k]) for k in ('mae','rmse')),
            S3_both_repaired=all(c['states']['3'][k]<min(b['states']['3'][k],f['states']['3'][k]) for k in ('mae','rmse')),
            severe_overestimation_reduced=c['S3_positive_error_q99']<b['S3_positive_error_q99'] and c['S3_severe_overestimate_rate']<=b['S3_severe_overestimate_rate'])
        for state in ('2','3'):
            checks['S'+state+'_two_seed_support']=sum(all(next(r for r in rows if r['seed']==s and r['arm']=='COMBINED')['states'][state][k]<next(r for r in rows if r['seed']==s and r['arm']=='V7')['states'][state][k] for k in ('mae','rmse')) for s in SEEDS)>=2
        weeks=np.unique(days//7);wc=np.array([(days//7==w).sum()*360 for w in weeks]);rng=np.random.default_rng(93012);boot=rng.integers(0,len(weeks),(2000,len(weeks)));comparisons=[]
        for name in ARMS[:-1]:
            delta=np.mean([abs(stored[s][name]-y)-abs(stored[s]['COMBINED']-y) for s in SEEDS],0).sum((1,2));ws=np.array([delta[days//7==w].sum() for w in weeks]);bs=ws[boot].sum(1)/wc[boot].sum(1)
            comparisons.append(dict(control=name,absolute_MAE_gain=float(delta.sum()/y.size),CI95=np.quantile(bs,[.025,.975]).tolist(),p=float(min(1,2*min((sum(bs<=0)+1)/2001,(sum(bs>=0)+1)/2001)))))
        running=0.
        for rank,j in enumerate(sorted(range(4),key=lambda j:comparisons[j]['p'])):running=max(running,min(1,(4-rank)*comparisons[j]['p']));comparisons[j]['holm_p']=running
        write(HERE/'RESULT.json',dict(at=gate.now(),scope='Fixed698 already-inspected H1 development origins,42UTCdates,30nodes,12horizons; not independent confirmation',summary=summary,seed_results=rows,checks=checks,positive_directions_lost=lost,comparisons=comparisons,event_diagnostics=events,activation=activation,original_core_unchanged=True,new_test_targets_read=False,
            inference_scope='Exploratory calendar-week clusters; seeds and overlapping cells are not independent observations. Three frozen neural seed chains; deterministic specialist repetitions are not three independent datasets.'))
        write(HERE/'AUDIT.json',dict(at=gate.now(),status='passed',result_sha256=gate.sha(HERE/'RESULT.json'),model_replays=replays,scalar_policy_replayed_cells_per_seed=int(y.size),original_FULL_V7_exact=True,operator_scope='Separate formula and saved-model prediction replay by same operator; not external peer review',future_state_codes_used_for_routing=False,new_test_targets_read=False))
        write(HERE/'DECISION.json',dict(at=gate.now(),status='V12_passed_development_needs_independent_confirmation' if all(checks.values()) else 'V12_closed_not_promoted_V7_retained',passes_full_development_gate=all(checks.values()),checks=checks,paper_results_replaced=False,automatic_extra_search=False,complete_research_experiment=False))
        check(stage='audit_complete');print(json.dumps(dict(checks=checks,combined={k:c[k] for k in scalar},lost_positive_directions=len(lost))),flush=True)
if __name__=='__main__':main()
