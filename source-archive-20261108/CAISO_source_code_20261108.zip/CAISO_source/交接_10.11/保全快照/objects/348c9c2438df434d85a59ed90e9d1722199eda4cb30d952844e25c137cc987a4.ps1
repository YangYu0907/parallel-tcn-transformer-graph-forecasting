$ErrorActionPreference = 'Stop'
$trial = $PSScriptRoot
$branch = Split-Path -Parent (Split-Path -Parent $trial)
$py = 'D:\Documents\conda_envs\tcn_air\python.exe'
$managerFile = Join-Path $trial 'manager.py'
$statePath = Join-Path $trial 'STATUS.json'
$env:PYTHONIOENCODING = 'utf-8'
if (Test-Path -LiteralPath (Join-Path $trial 'MANAGER.lock')) { throw 'Existing manager lock; verify before launching' }
if (Test-Path -LiteralPath (Join-Path $trial 'START_READY.json')) { throw 'Prior launch receipt exists; explicit recovery required' }
$process = Start-Process -FilePath $py -ArgumentList @('-u', ('"' + $managerFile + '"')) -WindowStyle Hidden -PassThru -WorkingDirectory $trial -RedirectStandardOutput (Join-Path $trial 'manager.stdout.log') -RedirectStandardError (Join-Path $trial 'manager.stderr.log')
$ticks = $process.StartTime.ToUniversalTime().Ticks
$exitScript = Join-Path $branch 'event_driven_automation\watch_manager_exit.ps1'
$exitArgs = @('-NoProfile','-ExecutionPolicy','Bypass','-File',('"' + $exitScript + '"'),'-ManagerProcessId',$process.Id,'-ManagerStartUtcTicks',$ticks,'-ManagerScript',('"' + $managerFile + '"'),'-StatusPath',('"' + $statePath + '"'))
$monitor = Start-Process -FilePath 'powershell.exe' -ArgumentList $exitArgs -WindowStyle Hidden -PassThru -RedirectStandardOutput (Join-Path $trial 'exit.stdout.log') -RedirectStandardError (Join-Path $trial 'exit.stderr.log')
$receipt = Join-Path $branch ('event_driven_automation\process_monitors\mechanism_exit_' + $process.Id + '_' + $ticks + '.status.json')
$timer = [Diagnostics.Stopwatch]::StartNew()
while (!(Test-Path -LiteralPath $receipt) -and $timer.Elapsed.TotalSeconds -lt 15) { Start-Sleep -Milliseconds 200 }
if (!(Test-Path -LiteralPath $receipt)) { throw 'Exit monitor receipt absent; manager will safely time out without starting work' }
$ready = @{at=[DateTime]::UtcNow.ToString('o');manager_pid=$process.Id;manager_start_utc_ticks=$ticks;exit_monitor_pid=$monitor.Id;receipt=$receipt;periodic_model_wakeups=$false}
$tmp = Join-Path $trial 'START_READY.tmp'
$ready | ConvertTo-Json -Depth 5 | Set-Content -LiteralPath $tmp -Encoding UTF8
Move-Item -LiteralPath $tmp -Destination (Join-Path $trial 'START_READY.json')
$ready | ConvertTo-Json -Depth 5 | Set-Content -LiteralPath (Join-Path $trial 'LAUNCH.json') -Encoding UTF8
$ready | ConvertTo-Json -Depth 5
