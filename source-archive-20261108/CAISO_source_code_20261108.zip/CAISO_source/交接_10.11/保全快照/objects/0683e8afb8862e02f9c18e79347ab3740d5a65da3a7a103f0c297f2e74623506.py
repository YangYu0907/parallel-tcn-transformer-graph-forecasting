"""Record full trial closure and precise next-step scope; immutable trial untouched."""
from pathlib import Path
from datetime import datetime,timezone
import json,hashlib,os,uuid
HERE=Path(__file__).resolve().parent;TRIAL=HERE.parent;ROOT=TRIAL.parent
def read(p):return json.loads(p.read_text(encoding='utf-8-sig'))
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def write(p,v):
    tmp=p.with_name('t_'+uuid.uuid4().hex+'.pending')
    with tmp.open('x',encoding='utf-8') as f:
        json.dump(v,f,ensure_ascii=False,indent=2,allow_nan=False);f.flush();os.fsync(f.fileno())
    os.replace(tmp,p)
def mean(v):return sum(v)/len(v)
def main():
    assert not (HERE/'DECISION.json').exists(),'Event already handled'
    r=read(TRIAL/'RESULT.json');a=read(TRIAL/'AUDIT.json');d=read(HERE/'RESULT.json');da=read(HERE/'AUDIT.json')
    assert a['status']==da['status']=='passed'
    assert a['result_sha256']==sha(TRIAL/'RESULT.json') and da['result_sha256']==sha(HERE/'RESULT.json')
    assert not r['exploratory_promotion_gate_passed']
    event='77eff8f94465cc3a093233e6c8b35da4601121b0601444047b6ffcc9b49c7858'
    seeds=[20260813,20260814,20260815];aff=r['means']['AFF'];cont=r['means']['FULL_CONT'];cat=r['means']['CONCAT_CONT']
    per_seed=[]
    for seed in seeds:
        cases={v:next(c for c in r['cases'] if c['seed']==seed and c['variant']==v) for v in ['AFF','FULL_CONT','CONCAT_CONT']}
        e=cases['AFF']['epochs'];per_seed.append(dict(seed=seed,selected_epoch=cases['AFF']['selected_epoch'],epoch_MAE=[x['metrics']['June3397']['mae'] for x in e],
            MAE={v:cases[v]['metrics']['June3397']['mae'] for v in cases},
            improvement_vs_FULL_pct=100*(cases['FULL_CONT']['metrics']['June3397']['mae']-cases['AFF']['metrics']['June3397']['mae'])/cases['FULL_CONT']['metrics']['June3397']['mae']))
    phase_summary=[]
    for phase in range(12):
        metrics={v:mean([next(c for c in r['cases'] if c['seed']==seed and c['variant']==v)['metrics']['June3397']['by_phase'][phase]['mae'] for seed in seeds]) for v in ['AFF','FULL_CONT','CONCAT_CONT']}
        phase_summary.append(dict(phase=phase,mean_seed_MAE=metrics))
    with_joint=d['means']['with_joint']['June3397'];without_joint=d['means']['without_joint']['June3397']
    effect=100*(without_joint['mae']-with_joint['mae'])/without_joint['mae']
    at=datetime.now(timezone.utc).isoformat()
    decision=dict(at=at,status='finite_AFF_family_closed_not_promoted',event_id=event,
        scope='Three-seed mean on all3397June development origins,30nodes,12horizons; no ensemble or untouched-test claim.',
        complete_research_experiment=False,original63_cases_unchanged=True,
        result=dict(means=r['means'],aff_improvement_percent=r['aff_improvement_percent'],per_seed=per_seed,phase_summary=phase_summary,
            seed_MAE_wins_over_FULL=3,seed_MAE_wins_over_CONCAT=sum(x['MAE']['AFF']<x['MAE']['CONCAT_CONT'] for x in per_seed),
            registered_protection_passed=True,registered_promotion_passed=False,
            factual_conclusion='Small consistent MAE improvement over matched FULL continuation; all12panel/headline mean errors improved over FULL_CONT. Primary dense MAE still higher than CONCAT_CONT, with opposite ranking on hourly panel. The predefined gate failed; no post-hoc selection of the favorable panel.'),
        diagnostic=dict(with_joint=with_joint,without_joint=without_joint,mean_correction_benefit_pct=effect,
            positive_correction_seeds=sum(x['correction_benefit_percent']['June3397']['mae']>0 for x in d['rows']),
            prediction_mean_absolute_shift=mean([x['prediction_absolute_shift'] for x in d['rows']]),
            description='Inference-only zeroing with learned weights fixed and original FULL path exactly replayed. This measures use of the correction, not isolated causal training benefit or a retrained parameter-matched ablation.',
            day_cluster_sensitivity=d['development_day_intervals']),
        facts=['All3AFFseeds selectepoch1 and have higher development MAE at epoch2; automatic training extension lacks supporting evidence.',
               'The package improves over FULL_CONT in all3seeds, but the mean primary gap to CONCAT_CONT remains1.933%.',
               'Correct arithmetic and replay do not establish independent generalization or a universally better graph/fusion component.'],
        hypotheses=['Additional joint-content flexibility may be redundant with existing representations; fixed-weight sensitivity cannot isolate training interactions.',
                    'Hourly versus off-hour model rankings reflect different error profiles; this does not by itself identify a data-processing error or its cause.',
                    'Small development improvements may partly reflect finite-sample selection; another development sweep would not resolve independent confirmation.'],
        decision='Retain original FULL as the existing manuscript main model; archive this as a completed post-test exploratory refinement. No further AFF hyperparameter, capacity, loss or epoch grid. Original core elements and all comparison directions retained.',
        next_matched_comparison=dict(status='Conditional plan only; not launched after the failed gate',
            comparison='If new development evidence later justifies further AFF work: same1136parameter content-conditioned correction versus input-independent correction, with matched FULL_CONT/CONCAT_CONT and EQUAL budget.',
            purpose='Separate content dependence from added capacity and ordinary continuation; do not claim the present zeroing diagnostic is this retrained control.',
            benefit='Can resolve mechanism attribution more directly than another capacity sweep.',
            cost='At least3newmatched-control fits plus any missing EQUALcontinuations; these do not eliminate the need for an unused test. Deferred because current predefined performance gate failed.',
            prerequisites=['A separately registered decision supported by new TRAIN/development evidence','Unchanged selection and evaluation scopes','Source-admitted unused period before any changed-model confirmation']),
        source_admission=dict(Europe2017='Metadata inventory only; exact historical timestamp semantics and model/input freeze unresolved. Price values remain sealed.',CAISO='No new unused period admitted for changed-model confirmation.'),
        literature=[dict(url='https://arxiv.org/abs/2009.14082',basis='AFF motivates joint local/global feature conditioning; published vision evidence does not establish price-task superiority.'),
                    dict(url='https://jmlr.org/papers/v11/cawley10a.html',basis='Repeated finite-sample model selection can overfit; motivates closing the bounded family and requiring fresh confirmation.')],
        current_training_active=False,new_optimizer_updates_this_review=0,new_test_targets_read=False,periodic_model_wakeups=False,
        bindings={str(p):sha(p) for p in [TRIAL/'RESULT.json',TRIAL/'AUDIT.json',TRIAL/'queue/completion.json',HERE/'RESULT.json',HERE/'AUDIT.json',HERE/'DIAGNOSTIC_REGISTRATION.json']})
    write(HERE/'DECISION.json',decision)
    handoff=ROOT/'HANDOFF.json';raw=handoff.read_bytes()
    with (HERE/'HANDOFF_before_closure.json').open('xb') as f:f.write(raw)
    h=json.loads(raw.decode('utf-8-sig'));h['at']=at;h['status']='bounded_post_test_AFF_trial_closed_not_promoted'
    trial=h['aff_joint_trial_20260929'];trial.update(at=at,status=decision['status'],training_active=False,manager_pid=None,numerical_worker_pid=None,exit_bridge_pid=None,current_case=None,
        state='All3fits and9case arithmetic audit complete; fixed-weight diagnosis complete; predefined promotion gate not passed.',
        result=str(TRIAL/'RESULT.json'),audit=str(TRIAL/'AUDIT.json'),decision=str(HERE/'DECISION.json'),diagnostic=str(HERE/'RESULT.json'))
    trial['next_actions']=['Preserve original63frozen cases and completed manuscript evidence','No additional training or parameter grid automatically queued','Conditional matched-control plan is recorded, not completed','Do not open new test targets without source admission and freeze']
    h['current_authorized_work']=dict(at=at,status='bounded_experiment_and_diagnostic_complete_no_training_queued',training_active=False,numeric_diagnostic_active=False,manager_pid=None,numerical_worker_pid=None,exit_bridge_pid=None,
        watcher_pid=23596,watcher_state='Event-only listener retained idle; no periodic wakeups',all_core_elements_preserved=True,original63_cases_unchanged=True,new_test_targets_read=False,manuscript_polishing_paused=True,
        review_decision=str(HERE/'DECISION.json'),next_actions=trial['next_actions'],complete_research_experiment=False,
        scope_note='Original63finalcomparisons remain available. This event closes the finite exploratory amendment; it does not declare universal component superiority, publishability or all research complete.')
    h['next_actions']=h['current_authorized_work']['next_actions'];write(handoff,h)
    write(HERE/'EVENT_HANDLED.json',dict(at=at,event_id=event,status='verified_diagnosed_and_closed',decision=str(HERE/'DECISION.json'),decision_sha256=sha(HERE/'DECISION.json'),duplicate_notification_emitted=False,new_training_started=False))
    print(json.dumps(dict(status=decision['status'],MAE=aff['June3397']['mae'],gain_FULL_pct=r['aff_improvement_percent']['FULL_CONT']['June3397']['mae'],gain_CONCAT_pct=r['aff_improvement_percent']['CONCAT_CONT']['June3397']['mae'],fixed_weight_correction_benefit_pct=effect),ensure_ascii=False))
if __name__=='__main__':main()
