from probe import *
from datetime import datetime,timezone
import psutil
def main():
 original=c.read(U/'RESULT.json');pool=c.read(P/'RESULT.json');diag=c.read(U/'DIAGNOSIS.json');sup=c.read(P/'TRAIN_SUPPORT.json')
 c.verify();verify(c.read(P/'PROTOCOL.json'))
 au=c.read(P/'AUDIT.json')
 assert au['result_sha256']==c.sha(P/'RESULT.json') and au['predictions_sha256']==c.sha(P/'PREDICTIONS.npz')
 assert not any(v['promising'] for v in pool['gates'].values())
 assert not psutil.pid_exists(18148)
 watcher=psutil.Process(23836);assert 'watch.ps1' in ' '.join(watcher.cmdline())
 assert not c.s.base.LOCK.exists()
 event_path=c.B/'event_driven_automation/inbox/wi_3364c71ce24583cdf9cdb261.json'
 event=c.read(event_path);assert event['evidence_sha256']==c.sha(U/'RESULT.json')
 delivery='0ea060c9aee137100e2aeecbb0ab778904eeb8d5aa68bf636a26c97c075fb95d'
 decision=dict(at=c.now(),status='finite_DAM_feature_and_probability_pool_candidates_closed_not_admitted',
  handled_delivery_event_id=delivery,handled_payload_event_id=event['event_id'],result_sha256=event['evidence_sha256'],
  completed=dict(new_event_tree_fits=8,following_scalar_fits=4,new_backbone_fits=0,protected_files_unchanged=18),
  facts=[
   'Training retention fixes sample-history loss but does not establish stable DAM incremental value.',
   'HISTORY_DAM increases aggregate precision5.20%to7.31%, decreases recall23.35%to21.80%, and worsens Brier.',
   'COARSE_DAM improves aggregate Brier0.00403972to0.00402176 and logloss0.0225900to0.0219954; recall8.23%to6.75% declines; original Holm logloss0.1439.',
   'Q2 HISTORY_DAM has131 non-UP pairs and4 UP pairs at probability>=.5. This diagnoses overconfidence, not physical causality.',
   'Additional CAL-only probability pools have mixed outcomes: HISTORY aggregate improvements fail temporal/uncertainty gates. COARSE_POOL logloss Holm8=.015992 but Brier Holm8=.209895 and alarm recall degrades.',
   'All eight frozen-temperature/raw score alarm sets match exactly at corresponding CAL99th percentile: extra monotone calibration alone cannot change this fixed-rank alarm decision.',
   'TRAIN-only DOWN support: full history20/24 event dates, DAM-proven subset6/10; unproven14 dates,108 positive pairs,16 gap-based clusters. More negative examples cannot substitute for missing positive-event provenance.',
   'No new prices, heldout labels, V7 predictions or manuscript text changed. All raw results retained.'],
  closed_repeats=['same nine-DAM flat feature fits on these prefixes','same two DAM probability pools','temperature-only changes advertised as new alarm information','repeated downloads of the same late-generated cached days','threshold/month/seed fishing'],
  next_authorized_work=[
   dict(stage='Training-only source support and mechanism evidence',status='support census completed',
        next='Target the14 missing DOWN event dates in provenance inquiry only; use truly separate historical source/version evidence, not the same overwritten cache. No lowering source or support gates.'),
   dict(stage='Incremental model value',status='not established for present DAM feature/pool family',
        next='Require a new supported signal or a distinct training-only demonstrated defect before a new finite matched experiment. Existing gain/loss records are the controls.'),
   dict(stage='Teacher graph, probability and confirmation requirements',status='remain open according to existing teacher ledger',
        next='Graph claim requires matched graph comparison; event-probability scores here are not price-interval validation or point MAE improvement. Independent-person review and new-period source admission still needed.')
  ],
  source_scope=original['source_scope'],independent_person_review=False,
  verification_scope='Hash bindings, different-formula numerical checks and scalar optimizer replay by the same operator',
  research_complete=False,automatic_continuation_enabled=True,requires_user_continue=False,user_paused=False,
  active_training_process=False,event_listener_pid=23836,event_listener_alive=True,new_background_manager=False,
  periodic_model_wakeups=False,foreground_results_reported_directly_no_duplicate_event=True,V7_replaced=False)
 write('DECISION.json',decision)
 lines=['CAISO 天气与日前拥堵：2026-10-10本轮完整结果',
  '结论：8组完整训练历史+同来源掩码模型已完成；随后4个CAL-only概率组合已完成。均未获准替换V7。',
  '比较范围：2025-01-01至2025-05-31，151个UTC日期，369910个节点-预测起点样本，30节点；1422个UP标签样本，116个DOWN标签样本。不是1422次独立电网事件。',
  '第一前缀评估1—3月，第二前缀评估4—5月；所有结果属于已暴露开发面板。无独立新时期确认。',
  '来源：回溯的官方缓存XML与近时间发布记录相互印证；不是用户当时抓取的不可变版本证据。',
  'HISTORY=历史价格/分量+日历+共同来源掩码；COARSE再加27维天气；DAM加9维已准入日前拥堵；完整训练历史保留。',
  'POOL=(1-g)*PARENT+g*DAM；g只用各自时间在前CAL的自然分布最小化logloss。HALF固定0.5。没有按EVAL改阈值。',
  'V7、18个保护文件及主干结构未改变；没有读新测试目标，没有新价格点预测结果。',
  '核查由同一操作者以不同公式/标量优化器重算，不等同独立人员审核。','',
  '第一阶段：8个树模型；Brier/logloss越小越好，P/R/FPR按百分比。']
 def table(title,rec):
  lines.append(title);lines.append('方法 | Brier | Logloss | Precision% | Recall% | TP | FP | FPR% | AP')
  for k,v in rec.items():
   lines.append(f"{k} | {v['brier']:.8f} | {v['logloss']:.8f} | {v['precision']*100:.4f} | {v['recall']*100:.4f} | {v['TP']} | {v['FP']} | {v['FPR']*100:.4f} | {v['AP']:.6f}")
  lines.append('')
 table('8模型汇总',original['aggregate'])
 for k,v in original['results'].items():table('8模型 '+k,{a:x['metrics'] for a,x in v.items()})
 for k,v in original['all_months'].items():table('8模型 '+k,v)
 lines.extend(['第二阶段：冻结预测，新增4个标量权重拟合，无新增树或主干训练。'])
 table('组合汇总（全部方向）',pool['aggregate'])
 for k,v in pool['results'].items():table('组合 '+k,v)
 for k,v in pool['all_months'].items():table('组合 '+k,v)
 lines.append('CAL权重（历史预测权重为1-g；拥堵预测权重为g）')
 for f,groups in pool['weights'].items():
  for g,rec in groups.items():lines.append(f"{f} {g}: g={rec['weight']:.12f}")
 for title,rows in [('原8模型探索性配对检验',original['statistics']),('新增概率组合探索性配对检验',pool['statistics'])]:
  lines.extend(['',title,'差值=候选-对照；全部保留，未经整个研究历程的全局选择校正。'])
  for z in rows:lines.append(f"{z['candidate']} vs {z['control']} {z['metric']}: delta={z['difference']:.10g}, CI95={z['CI95']}, raw_p={z['p']:.8f}, Holm8={z['exploratory_Holm8_p']:.8f}")
 lines.extend(['','诊断与决策',*decision['facts'],'','后续准入与避免重复'])
 for rec in decision['next_authorized_work']:lines.extend([rec['stage']+'：'+rec['status'],rec['next']])
 lines.extend(['','成本与收益','本轮8组HGB约274.5秒；追加4个概率权重拟合与重算约5.4秒（不含交互、代码与整理）。',
  '概率组合确实带来部分汇总收益，但不能以该收益替代跨期告警质量、DOWN识别及尖峰价格MAE/RMSE验收。',
  '同一特征/权重方向现已收口；全研究未完成。当前没有训练进程在运行，文件事件监听继续保留。','',
  '原始文献及本轮适用范围',
  'Gneiting & Ranjan, Combining Predictive Distributions: https://arxiv.org/abs/1106.1638 （支持检验概率组合与校准的权衡，不保证优于各专家）',
  'Kull et al., Beta calibration: https://proceedings.mlr.press/v54/kull17a.html （说明校准方法有假设与适用范围；本轮没有另加校准模型）',
  'Cawley & Talbot, JMLR2010: https://jmlr.org/papers/v11/cawley10a.html （反复开发选择的偏差；须另做独立确认）'])
 report=P/'本轮完整结果.txt';report.write_text('\n'.join(lines),encoding='utf-8-sig')
 # Atomic handoff update with an exact backup and concurrent-write guard.
 handoff=c.B/'HANDOFF.json';before=handoff.read_bytes();h=json.loads(before.decode('utf-8-sig'))
 backup=P/'HANDOFF_BEFORE.json';assert not backup.exists();backup.write_bytes(before)
 h['retained_dam_20261010'].update(status='eight_fits_complete_audited_not_admitted',manager_alive=False,
   result=str(U/'RESULT.json'),audit=str(U/'AUDIT.json'),diagnosis=str(U/'DIAGNOSIS.json'),information_gate_passed=False)
 h['dam_probability_pool_20261010']=dict(at=c.now(),status=decision['status'],path=str(P),protocol=str(P/'PROTOCOL.json'),result=str(P/'RESULT.json'),
   audit=str(P/'AUDIT.json'),decision=str(P/'DECISION.json'),report=str(report),train_support=str(P/'TRAIN_SUPPORT.json'),
   new_tree_fits=0,new_scalar_fits=4,active_training=False,independent_person_review=False,V7_replaced=False)
 consumed=h.setdefault('reported_and_consumed_payload_events',[])
 if event['event_id'] not in consumed:consumed.append(event['event_id'])
 h['latest_handled_source_event']=dict(at=c.now(),delivery_event_id=delivery,payload_event_id=event['event_id'],evidence=str(U/'RESULT.json'),
   evidence_sha256=event['evidence_sha256'],decision=str(P/'DECISION.json'),duplicate_notification=False)
 h['latest_autonomous_continuation'].update(current_phase=str(P/'DECISION.json'),status='finite_weather_DAM_trials_completed_not_admitted',
   active_training=False,requires_user_continue=False,next_evidence='Historical DOWN source/version gaps and independently admitted confirmation remain open; no repeated same-input fits')
 h['current_work_status']='天气/日前拥堵有限对照及追加概率组合完成，候选未准入；训练期来源缺口台账已核验，全研究未完成。'
 h['automatic_continuation_paused']=False
 h['training_active']=False;h['research_training_active']=False
 h['event_listener_pid']=23836;h['periodic_model_wakeups']=False
 h['last_updated_at']=c.now()
 assert handoff.read_bytes()==before,'Concurrent HANDOFF modification'
 temp=handoff.with_name('.h'+os.urandom(4).hex());temp.write_text(json.dumps(h,ensure_ascii=False,indent=2,allow_nan=False),encoding='utf-8');os.replace(temp,handoff)
 write('HANDLED.json',dict(at=c.now(),delivery_event_id=delivery,payload_event_id=event['event_id'],evidence_verified=True,manager_exit_verified=True,
   event_listener_verified_pid=23836,result_sha256=c.sha(P/'RESULT.json'),audit_sha256=c.sha(P/'AUDIT.json'),report_sha256=c.sha(report),
   decision_sha256=c.sha(P/'DECISION.json'),handoff_sha256=c.sha(handoff),no_duplicate_model_runs=True,new_background_process=False))
 print(json.dumps(dict(report=str(report),decision=str(P/'DECISION.json'),status=decision['status'],event_listener_alive=True,
  scalar_fits=4,independent_person_review=False,protected_files_unchanged=18,active_training=False),ensure_ascii=False))
if __name__=='__main__':main()

