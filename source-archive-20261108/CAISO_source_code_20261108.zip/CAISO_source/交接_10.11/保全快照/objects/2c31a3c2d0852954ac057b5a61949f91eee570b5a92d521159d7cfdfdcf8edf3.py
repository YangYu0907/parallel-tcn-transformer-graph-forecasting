"""Concrete complete final test manifest, still requiring responsible release."""
from pathlib import Path
import sys
from runtime_gate import HERE,c,FREEZE
from predictor import cases

def main():
    c.boundary();c.need(not c.SHARED_LOCK.exists(),'Numerical worker active')
    c.need(not FREEZE.exists(),'Preserve final freeze')
    F=c.BRANCH/'h1_feature_admission_v1_20260927';S=c.BRANCH/'h1_source_inputs_v1_20260927'
    q=c.read(HERE/'RUNTIME_QA.json');c.need(q['status']=='passed' and len(q['cases'])==33,'Final runtime QA incomplete')
    for p,d in q['sources'].items():c.need(c.sha(p)==d,'Final runtime changed after QA')
    fr=c.read(F/'FEATURE_ADMISSION_REVIEW.json');c.need(fr['status']=='verified_features_and_causal_dependencies' and fr['qualified_origins']==1002,'Feature admission review failed')
    feature=c.read(F/'FEATURE_ADMISSION_RESULT.json');parent=c.read(S/'INPUT_AUDIT_FREEZE.json')
    bindings=dict(c.read(F/'FEATURE_AUDIT_FREEZE.json')['bindings'])
    for p in list(HERE.glob('*.py'))+list(HERE.glob('*.ps1'))+[HERE/'RUNTIME_QA.json',HERE/'EFFECTIVE_PROTOCOL.json',HERE/'monthly_admission.csv',HERE/'all_origin_admission.csv',
        F/'FEATURE_ADMISSION_RESULT.json',F/'FEATURE_ADMISSION_REVIEW.json',F/'FEATURE_AUDIT_FREEZE.json',Path(feature['publication_routing']),Path(feature['origin_receipts'])]:bindings[str(p)]=c.sha(p)
    manifest=c.read(c.BRANCH/'phase_sampling_support_v3_20260923/dataset/ADDITIVE/manifest.json');thresholds=c.BRANCH/manifest['artifacts']['state_thresholds.json']['path']
    bindings[str(thresholds)]=manifest['artifacts']['state_thresholds.json']['sha256']
    import importlib.metadata as im
    runtime=dict(python=sys.version,executable=sys.executable,packages={n:im.version(n) for n in ('numpy','torch','scipy')})
    runtime_files=[Path(sys.executable)]+list(Path(sys.executable).parent.glob('python*.dll'))
    for package in ('numpy','torch'):
        root=Path(im.distribution(package).locate_file(package))
        runtime_files += [root/'__init__.py']+list(root.rglob('*.pyd'))+list(root.rglob('*.dll'))
    for p in runtime_files+[c.HERE/'evaluation/paired_statistics.py',c.HERE/'evaluation/STATISTICS_QA.json']:
        bindings[str(p.resolve())]=c.sha(p)
    for p,d in bindings.items():c.need(c.sha(p)==d,'Final bound source changed: '+p)
    registered=cases(parent);names=list(dict.fromkeys(r['variant'] for r in registered));spec=c.read(HERE/'EFFECTIVE_PROTOCOL.json')
    final=dict(status='frozen_before_H1_test_access',at=c.now(),scope=spec['effective_scope'],bindings=bindings,cases=registered,
        comparison_names=[v for v in names if v!='FULL'],origins=parent['origins'],nodes=parent['nodes'],horizons=list(range(1,13)),
        input_freeze=str(S/'INPUT_AUDIT_FREEZE.json'),publication_routing=feature['publication_routing'],feature_receipts=feature['origin_receipts'],
        state_thresholds=str(thresholds),runtime_qa=str(HERE/'RUNTIME_QA.json'),statistics=str(c.HERE/'evaluation/STATISTICAL_SPECIFICATION.json'),
        runtime=runtime,model_count=13,neural_seed_cases=30,statistical_baseline_cases=3,cells_per_seed=360720,days=56,
        target_definition=spec['targets'],target_mask='Every one of1002origins x30nodes x12horizons; nonfinite targets block scoring, never select exclusions',
        signed_responsible_release_required=True,G6_signed=False,H1_predictions_computed=False,H1_scores_computed=False,
        no_test_tuning=True,complete_research_experiment=False)
    c.write(FREEZE,final)
    digest=c.sha(FREEZE)
    text='''# CAISO H1 final evaluation package\n\n- Scope: 1002 registered source-qualified origins on56UTCdates; 30nodes and12five-minute horizons (360720targets per case). May has no qualified origins.\n- Models: 30frozen neural seed cases across10families, plus persistence, previous-day and LASSO-ARX-H; 33prediction cases. FULL retains all required modules.\n- Selection: completed TRAIN/June choices only. No new training, model changes, score-based exclusions or H1 retuning.\n- Source contract: raw report values linked exactly to archived historical predictors and complete official publication/revision coverage through retrieval; qualification is retrospective and does not establish unfiltered operational deployment.\n- Source and feature checks: 222reports, 4192296historical values and all1002actual288x30x29inputs passed.\n- Evaluation: all predictions committed before final targets; primary pooled MAE, registered secondary errors, all nodes/horizons/months/states and all three seeds. Paired real-calendar-week bootstrap2000draws; Holm over all12primary comparisons.\n- Final worker: 33adapters passed fixed June replay; all30neuralmodels also passed3397-origin replay. No H1 error has been read.\n- Gate: actual responsible approval of this exact package is required by the original TEST_LOCK.json signed model-and-feature requirement. Signature is currently absent.\n\nFinal manifest SHA-256: `'''+digest+'`\n'
    (HERE/'FINAL_PACKAGE_REVIEW.md').write_text(text,encoding='utf-8')
    print('Final package frozen; actual responsible release remains required: '+digest)

if __name__=='__main__':main()
