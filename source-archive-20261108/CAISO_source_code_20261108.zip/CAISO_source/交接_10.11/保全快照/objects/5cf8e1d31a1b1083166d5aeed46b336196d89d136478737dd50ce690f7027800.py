"""Training-only support census and closure records. No new forecasts or target release."""
from probe import *
def counts(ii,ar):
 times=np.unique(ar['time'][ii]);dates=np.unique(times//86400)
 return dict(pairs=int(len(ii)),UTC_dates=int(len(dates)),origin_gap_1h_clusters=int(1+np.sum(np.diff(times)>3600)) if len(times) else 0,
  nodes=int(len(np.unique(ar['node'][ii]))),first_origin=str(np.datetime64(int(times[0]),'s')) if len(times) else None,
  last_origin=str(np.datetime64(int(times[-1]),'s')) if len(times) else None)
def main():
 c.verify()
 with c.s.base.numeric('Training-only source support census after finite DAM trials'):
  guard(True)
  with np.load(U/'INDICES.npz') as z:ar={k:z[k] for k in z.files}
  prot=c.read(U/'PROTOCOL.json');out={}
  for f in prot['folds']:
   fit=ar[f['name']+'_fit'];out[f['name']]={}
   for v,name in [(1,'UP'),(2,'DOWN')]:
    ii=fit[ar['y'][fit]==v]
    out[f['name']][name]=dict(full_history=counts(ii,ar),DAM_admitted=counts(ii[ar['source_valid'][ii]],ar),
      DAM_unproven=counts(ii[~ar['source_valid'][ii]],ar))
  for path,h in c.read(c.Z/'PROTECTED_FILES.json').items():assert c.sha(path)==h,path
  write('TRAIN_SUPPORT.json',dict(at=c.now(),scope='Training prefixes only; no new targets. Counts are positive forecast-origin clusters, not verified independent physical outages.',
   folds=out,no_source_rule_relaxation=True,minimum_training_dates_and_clusters=20,protected_files_unchanged=18,
   next='Do not repeat downloading the same overwritten cached dates. Additional DOWN covariates require an independently traceable historical forecast/version source or a newly admitted period; existing DOWN pooled alarms remain unqualified.',
   new_model_fits=0))
 print(json.dumps(out,ensure_ascii=False))
if __name__=='__main__':main()

