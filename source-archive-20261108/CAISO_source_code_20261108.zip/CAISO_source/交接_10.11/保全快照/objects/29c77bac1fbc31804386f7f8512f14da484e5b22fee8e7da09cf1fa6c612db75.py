"""Independent stdlib-only reviewer tests; no real model/data/numeric runtime."""
from copy import deepcopy
from hashlib import sha256
from pathlib import Path
from types import SimpleNamespace
from unittest.mock import patch
import argparse
import ast
import json
import sys

HERE = Path(__file__).resolve().parents[1]
ROOT = HERE.parent
sys.path.insert(0, str(HERE / 'source'))
import train as runner


def structure(node):
    return ast.dump(node, include_attributes=False)


def functions(path):
    tree = ast.parse(path.read_text(encoding='utf-8-sig'))
    return tree, {node.name: node for node in tree.body
                  if isinstance(node, (ast.FunctionDef, ast.ClassDef))}


def metadata_fixture(policy='ADDITIVE'):
    def digest(path):
        return sha256(str(Path(path).resolve()).encode()).hexdigest()
    parent_path = ROOT / 'dataset/compiled_train_june/manifest.json'
    child_path = runner.policy_manifest(policy)
    parent_audit_path = parent_path.parent / 'audit.json'
    parent = dict(status='parent', dataset_revision='fixed_revision', training_allowed=False,
        prefix_stop=219168, artifacts={
            'features.npy': dict(path='fixed/features.npy', sha256='frozen'),
            'phase_manifest.json': dict(path='fixed/phase.json', sha256='frozen_phase')})
    extension = dict(policy=policy, protocol_sha256=digest(runner.SAMPLING_PROTOCOL),
        schedule_sha256=digest(HERE / 'dataset/schedule.json'),
        parent_manifest_sha256=digest(parent_path), parent_audit_sha256=digest(parent_audit_path))
    child = deepcopy(parent)
    child.update(status='sampling_extension_pending_independent_origin_audit', sampling_extension=extension)
    child['artifacts']['phase_manifest.json'] = dict(
        path=str((child_path.parent / 'phase_manifest.json').relative_to(ROOT)), sha256='new_phase')
    schedule_audit_path = HERE / 'dataset/schedule_audit.json'
    schedule_audit = dict(status='passed', independent=True,
        auditor_source_sha256=digest(HERE / 'source/audit_schedule.py'),
        all_schedule_checks_passed=True, fixed_TRAIN_diagnostic_panel_verified=True,
        manifests={policy: digest(child_path)}, protocol_sha256=extension['protocol_sha256'],
        schedule_sha256=extension['schedule_sha256'])
    policy_audit = dict(sampling_policy=policy, sampling_schedule_audit_sha256=digest(schedule_audit_path),
        all_schedule_checks_passed=True, inherited_parent_audit_sha256=extension['parent_audit_sha256'],
        inherited_parent_manifest_sha256=extension['parent_manifest_sha256'])
    phase = dict(epochs=[dict(count=4032, updates=1008) for _ in range(6)])
    evidence = dict(qa='bound')
    records = {
        runner.SAMPLING_PROTOCOL: dict(bindings={}), parent_path: parent, child_path: child,
        schedule_audit_path: schedule_audit, child_path.parent / 'audit.json': policy_audit,
        child_path.parent / 'phase_manifest.json': phase, runner.LOCK: dict(sampling_evidence=evidence)}
    records = {str(k.resolve()): v for k, v in records.items()}
    return records, digest, child, schedule_audit, policy_audit, phase, evidence


def run(source_execution_receipt):
    checks = []
    def check(value, label):
        if not value:
            raise AssertionError(label)
        checks.append(label)

    old_tree, old = functions(ROOT / 'source/backbone_train.py')
    new_tree, new = functions(HERE / 'source/train.py')
    exact = ('optimizer', 'EpochCosine', 'update', 'rng_state', 'restore_rng', 'payload',
             'restore', 'checkpoint', 'load_checkpoint', 'recover_receipt', 'validate_state',
             'evaluate_june', 'resource_guard', 'exclusive', 'numeric_runtime')
    for name in exact:
        check(structure(old[name]) == structure(new[name]), 'Unmodified parent AST: ' + name)
    adapted = deepcopy(new['parent_admission_contract'])
    adapted.name = 'admission'
    check(structure(adapted) == structure(old['admission']), 'Original causal admission preserved exactly')

    # Normalize only the three specifically authorized orchestration changes by AST.
    body = deepcopy(new['train'])
    check(isinstance(body.body[0], ast.Import) and body.body[0].names[0].name == 'preflight',
          'Training imports metadata preflight first')
    check(structure(body.body[1]) == structure(ast.parse('preflight.require_mechanisms_complete()').body[0]) and
          structure(body.body[2]) == structure(ast.parse('preflight.launch_guard()').body[0]),
          'Prior queue completion and launch resource guards precede admission and numerical imports')
    body.body = body.body[3:]
    old_run = next(n for n in old['train'].body if isinstance(n, ast.Assign) and
                   any(isinstance(t, ast.Name) and t.id == 'run' for t in n.targets))
    new_run = next(n for n in body.body if isinstance(n, ast.Assign) and
                   any(isinstance(t, ast.Name) and t.id == 'run' for t in n.targets))
    check(isinstance(new_run.value, ast.Call) and isinstance(new_run.value.func, ast.Name) and
          new_run.value.func.id == 'run_directory', 'Canonical policy-specific run directory is mandatory')
    new_run.value = deepcopy(old_run.value)
    new_with = next(n for n in body.body if isinstance(n, ast.With))
    old_with = next(n for n in old['train'].body if isinstance(n, ast.With))
    check(isinstance(new_with.items[0].context_expr, ast.Call) and
          new_with.items[0].context_expr.func.id == 'exclusive', 'Exclusive global numerical lock retained')
    new_with.items[0].context_expr = deepcopy(old_with.items[0].context_expr)
    check(structure(body) == structure(old['train']),
          'Complete training loop identical after permitted namespace/preflight/action-label normalization')
    locations = {runner.run_directory(p, v, s) for p in runner.POLICIES
                 for v in ('FULL', 'TCN') for s in (20260813, 20260814)}
    check(len(locations) == 8 and all(p.is_relative_to(HERE / 'runs') for p in locations) and
          all(not p.is_relative_to(ROOT / 'runs') for p in locations),
          'Eight fresh run namespaces are unique and disjoint from original runs')
    for values in [('OTHER', 'FULL', 20260813), ('REPEAT', 'CONCAT', 20260813),
                   ('ADDITIVE', 'TCN', 20260815)]:
        try:
            runner.run_directory(*values)
        except ValueError:
            checks.append('Reject unregistered case ' + repr(values))
        else:
            raise AssertionError('Unregistered case accepted')

    for policy in runner.POLICIES:
        def exercise(mutator=None):
            records, digest, child, schedule_audit, policy_audit, phase, evidence = metadata_fixture(policy)
            if mutator:
                mutator(child, schedule_audit, policy_audit, phase)
            with patch.object(runner, 'read', lambda p: deepcopy(records[str(Path(p).resolve())])), \
                 patch.object(runner, 'sha', digest), patch.object(runner, 'bindings_check', lambda x: None), \
                 patch.object(runner, 'runner_evidence', lambda: evidence), \
                 patch.object(runner, 'stop_reason', lambda p: None):
                return runner.sampling_admission(runner.policy_manifest(policy), 'FULL', 20260813)
        check(exercise()['sampling_policy'] == policy, 'Mocked certified metadata admitted: ' + policy)
        mutations = [
            ('frozen feature descriptor changed', lambda c, s, a, p: c['artifacts']['features.npy'].update(sha256='changed')),
            ('missing independent status', lambda c, s, a, p: s.update(independent=False)),
            ('stale auditor source', lambda c, s, a, p: s.update(auditor_source_sha256='stale')),
            ('wrong manifest certification', lambda c, s, a, p: s['manifests'].update({policy: 'stale'})),
            ('unverified fixed TRAIN panel', lambda c, s, a, p: s.update(fixed_TRAIN_diagnostic_panel_verified=False)),
            ('wrong policy audit', lambda c, s, a, p: a.update(sampling_policy='OTHER')),
            ('stale parent audit', lambda c, s, a, p: a.update(inherited_parent_audit_sha256='stale')),
            ('4031-origin epoch', lambda c, s, a, p: p['epochs'][0].update(count=4031)),
            ('incorrect per-epoch updates', lambda c, s, a, p: p['epochs'][0].update(updates=1007)),
            ('missing sixth epoch', lambda c, s, a, p: p['epochs'].pop()),
            ('changed causal cutoff metadata', lambda c, s, a, p: c.update(prefix_stop=219169)),
        ]
        for label, mutator in mutations:
            try:
                exercise(mutator)
            except (ValueError, RuntimeError):
                checks.append(policy + ' fails closed: ' + label)
            else:
                raise AssertionError('Corrupt metadata accepted: ' + label)

    for counts, total, accepted in [([4032] * 6, 6048, True), ([2016] * 6, 3024, False),
                                    ([4032] * 5, 5040, False), ([4032] * 6, 6047, False)]:
        with patch.object(runner, 'sampling_admission', lambda *args: {'sampling_policy': 'ADDITIVE'}), \
             patch.object(runner, 'parent_admission_contract', lambda *args: {'epoch_counts': counts, 'total_updates': total}):
            try:
                runner.admission(runner.policy_manifest('ADDITIVE'), 'FULL', 20260813)
            except RuntimeError:
                check(not accepted, 'Budget rejection ' + str((counts, total)))
            else:
                check(accepted, 'Exact 4032 x 6 / 6048 budget admitted')
    for physical, commit, accepted in [(4., 4., True), (3.99, 6., False), (6., 3.99, False)]:
        fake_gate = SimpleNamespace(resources=lambda: dict(available_physical_GiB=physical, available_commit_GiB=commit))
        with patch.dict(sys.modules, {'compile_gate': fake_gate}):
            try:
                runner.resource_guard()
            except MemoryError:
                check(not accepted, 'Resource rejection ' + str((physical, commit)))
            else:
                check(accepted, 'Original 4 GiB runtime floor retained')

    audit_tree, audit_functions = functions(HERE / 'source/audit_result.py')
    _, old_audit_functions = functions(ROOT / 'source/audit_backbone_result.py')
    check(structure(audit_functions['summarize']) == structure(old_audit_functions['summarize']),
          'Raw USD MAE/RMSE/near/H12 independent reducer unchanged')
    audit_text = (HERE / 'source/audit_result.py').read_text(encoding='utf-8')
    required_truth_checks = [
        "truth_scaled = np.stack([target[int(o):int(o)+12].T.copy() for o in origins]).astype(np.float64)",
        "truth = truth_scaled * scale[None, :, None] + center[None, :, None]",
        "total_updates == identity['total_updates'] == completion['optimizer_steps'] == 6048",
        "row['june']['mae'] < selected['june']['mae'] - 1e-6",
        "identity == runner.admission(runner.policy_manifest(policy), variant, seed)",
    ]
    check(all(line in audit_text for line in required_truth_checks),
          'Audit uses same June284 truth/selection, doubled budget and current certified identity')
    main_guard = next(n for n in audit_tree.body if isinstance(n, ast.If) and
                      isinstance(n.test, ast.Compare) and isinstance(n.test.left, ast.Name) and n.test.left.id == '__name__')
    with_node = next(n for n in main_guard.body if isinstance(n, ast.With))
    check(any(isinstance(n, ast.Import) and n.names[0].name == 'numpy' for n in with_node.body),
          'Audit imports NumPy only inside exclusive numerical lock after preflight')
    math_text = (HERE / 'source/runner_math_qa.py').read_text(encoding='utf-8')
    old_review = json.loads((ROOT / 'phase_sampling_additive_v2_20260920/audits/before_math_path_fix/independent_runner_review.json').read_text(encoding='utf-8-sig'))
    old_math_digest = old_review['sources'][str(Path('phase_sampling_additive_v2_20260920') / 'source/runner_math_qa.py')]
    current_math_bytes = (HERE / 'source/runner_math_qa.py').read_bytes()
    recovered_math_bytes = current_math_bytes.replace(
        b"folder = runner.VARIANT_ROOT/'_qa'/('m_'+uuid.uuid4().hex[:12])",
        b"folder = runner.VARIANT_ROOT/'audits/math_attempts'/uuid.uuid4().hex").replace(
        b"baseline_run, resumed_run = folder/'c', folder/'r'",
        b"baseline_run, resumed_run = folder/'continuous', folder/'resumed'")
    check(sha256(recovered_math_bytes).hexdigest() == old_math_digest,
          'Only the two QA fixture path assignments changed since prior independent review')
    check("folder = runner.VARIANT_ROOT/'_qa'/('m_'+uuid.uuid4().hex[:12])" in math_text and
          "baseline_run, resumed_run = folder/'c', folder/'r'" in math_text,
          'Synthetic checkpoint fixture uses the reviewed short Windows namespace')
    longest_paths = []
    for location in sorted(locations):
        pending = location / 'checkpoints' / ('epoch6_complete_' + 'f' * 32 + '.receipt.json.' + 'f' * 32 + '.pending')
        check(len(str(pending)) < 260, 'Production atomic receipt respects Windows MAX_PATH: ' + str(location.relative_to(HERE)))
        longest_paths.append(str(pending))
    for short_name in ('c', 'r'):
        pending = HERE / '_qa' / ('m_' + 'f' * 12) / short_name / 'checkpoints' / ('checkpoint_' + 'f' * 32 + '.receipt.json.' + 'f' * 32 + '.pending')
        check(len(str(pending)) < 260, 'Synthetic atomic receipt respects Windows MAX_PATH: ' + short_name)
        longest_paths.append(str(pending))
    check(all(s in math_text for s in ('preflight.require_mechanisms_complete()', 'preflight.launch_guard()',
          "with runner.exclusive('sampling_synthetic_training_math'):", 'runtime, limiter = runner.numeric_runtime()',
          'runner.runner_evidence(require_math=False)')),
          'Prepared numerical QA is guarded by source review, prior completion, resources and lock')
    check(all(s in math_text for s in ('runner.restore(saved', 'Continuous and disk-resumed training are bitwise identical',
          'left.permutation(4032), right.permutation(4032)', 'counts = [9, 11, 8, 10, 7, 13]',
          'First AdamW update matches independent bias-corrected equation')),
          'Prepared numerical QA covers actual disk resume, independent update equation and paired shuffles')

    receipt_path = Path(source_execution_receipt)
    receipt = json.loads(receipt_path.read_text(encoding='utf-8-sig'))
    source_report = json.loads(runner.SOURCE_QA.read_text(encoding='utf-8-sig'))
    check(receipt.get('status') == 'completed' and receipt.get('exit_code') == 0 and
          receipt.get('report_sha256') == runner.sha(runner.SOURCE_QA) and
          Path(receipt['stderr']).read_text(encoding='utf-8-sig') == '' and
          source_report.get('sources') == runner.source_paths(),
          'Developer source-QA actual successful execution is bound to current complete sources')
    check(not any(k in sys.modules for k in ('numpy', 'torch', 'compiled_data')),
          'Independent static audit never imported numeric runtime or market data adapter')
    return dict(status='passed_static_only', checks=checks, check_count=len(checks),
        sources=runner.source_paths(), source_qa_receipt=str(receipt_path),
        source_qa_receipt_sha256=runner.sha(receipt_path), source_qa_report_sha256=runner.sha(runner.SOURCE_QA),
        independent_auditor_source_sha256=runner.sha(__file__),
        numeric_math_QA_executed=False, actual_market_arrays_read=False, numerical_lock_acquired=False,
        unchanged_training_math=True, isolated_paths_verified=True,
        maximum_checked_atomic_path_characters=max(map(len, longest_paths)),
        checkpoint_path_fix_only_verified=True,
        limitations=['Numerical math QA remains a mandatory execution gate before sealing/training.',
                     'Fixed TRAIN diagnostic panel is registered; per-epoch common-population evaluation remains pending.'])


if __name__ == '__main__':
    parser = argparse.ArgumentParser()
    parser.add_argument('--source-execution-receipt', required=True)
    parser.add_argument('--output', required=True)
    args = parser.parse_args()
    result = run(args.source_execution_receipt)
    path = Path(args.output).resolve()
    if not path.is_relative_to(HERE / 'audits'):
        raise ValueError('Static review output must stay in isolated audits')
    with path.open('x', encoding='utf-8') as stream:
        json.dump(result, stream, indent=2)
    print(json.dumps({'status': result['status'], 'check_count': result['check_count'], 'output': str(path)}))
