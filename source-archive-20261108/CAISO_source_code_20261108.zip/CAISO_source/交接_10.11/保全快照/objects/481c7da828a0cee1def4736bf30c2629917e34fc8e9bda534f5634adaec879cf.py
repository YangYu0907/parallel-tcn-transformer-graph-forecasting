"""Real binary storage-adapter equivalence and future publication exclusion checks."""
import numpy as np
from sklearn.ensemble import HistGradientBoostingClassifier
import disk_hgb
from common import *
def run():
 guard(True)
 rng=np.random.default_rng(614);x=rng.normal(size=(2400,29)).astype(np.float32);x[:,24]=np.arange(len(x))%30
 y=(x[:,0]+.7*x[:,1]+.2*(x[:,24]%3)+rng.normal(size=len(x))>2).astype(int);assert y.sum()>50
 path=E/'qa_design.npy';m=np.lib.format.open_memmap(path,mode='w+',dtype=np.float32,shape=x.shape,fortran_order=True);m[:]=x;m.flush();m._mmap.close()
 params=read(D/'PROTOCOL.json')['model_plan']['learner'];native=HistGradientBoostingClassifier(**params);disk=disk_hgb.DiskHGB(**params)
 for n in [20,40]:
  native.set_params(max_iter=n).fit(x,y);m=np.load(path,mmap_mode='r');disk.set_params(max_iter=n).fit(m,y);m._mmap.close()
 a=native.predict_proba(x);b=disk.predict_proba(x);diff=float(np.max(np.abs(a-b)));assert diff<1e-12
 from datetime import datetime,timedelta
 from zoneinfo import ZoneInfo
 counts=[]
 for day,expected in [('2024-03-10',23),('2024-11-03',25)]:
  start=datetime.fromisoformat(day).replace(tzinfo=ZoneInfo('America/Los_Angeles'));hours=int(((start+timedelta(days=1)).timestamp()-start.timestamp())//3600);assert hours==expected;counts.append(hours)
 # As-of predicate requires each exact containing hour and publication<=cutoff.
 def valid(cut,lookup):
  return all((int((cut+h)//3600*3600) in lookup and lookup[int((cut+h)//3600*3600)]<=cut) for h in [0,1800,3600])
 assert valid(7200,{7200:7100,10800:7190})
 assert not valid(7200,{7200:7100,10800:7201})
 assert not valid(7200,{7200:7100})
 q=dict(at=now(),passed=True,binary_adapter_native_max_abs=diff,binary_warm_start_iterations=40,DST_hours=counts,future_publication_rejected=True,missing_future_hour_rejected=True,scientific_fits=0)
 write(E/'QA.json',q);return q

