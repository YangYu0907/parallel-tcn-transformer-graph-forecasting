"""Record verified event handling and the actual successor; no new event."""
from pathlib import Path
import os,json,hashlib,psutil
from datetime import datetime,timezone
W=Path(__file__).resolve().parent;Z=W.parent.parent;B=Z.parent.parent
def read(p):return json.loads(p.read_text(encoding='utf-8-sig'))
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def write(p,v):
    t=p.with_name('.review_'+os.urandom(6).hex());t.write_text(json.dumps(v,ensure_ascii=False,indent=2),encoding='utf-8');os.replace(t,p)
def update(p,fn):
    raw=p.read_bytes();v=json.loads(raw.decode('utf-8-sig'));fn(v);assert p.read_bytes()==raw;write(p,v)
launch=read(W/'LAUNCH.json');pid=launch['manager_pid'];worker=psutil.Process(pid)
assert str(W/'manager.py') in worker.cmdline()
assert abs((launch['manager_start_utc_ticks']-621355968000000000)/1e7-worker.create_time())<.01
monitor=psutil.Process(launch['exit_monitor_pid']);assert 'watch_manager_exit.ps1' in ' '.join(monitor.cmdline())
receipt=read(Path(launch['receipt']));assert receipt['manager_pid']==pid and receipt['watcher_pid']==monitor.pid
listener=[p.pid for p in psutil.process_iter(['pid','cmdline']) if any(str(B/'event_driven_automation/watch.ps1').lower().replace('/','\\')==a.lower().replace('/','\\') for a in p.info['cmdline'] or [])]
assert len(listener)==1 and not (W/'FAILURE.json').exists()
source_event=read(B/'event_driven_automation/inbox/wi_8e01d0a020c12775b862cd62.json')
progress=read(W/'PROGRESS.json') if (W/'PROGRESS.json').exists() else read(W/'STATUS.json')
at=datetime.now(timezone.utc).isoformat()
review=dict(at=at,status='logging_failure_repaired_completed_HISTORY_reused',source_event_id=source_event['event_id'],delivery_event_id='5129da4cf5b4583433c0f42db208740f1d7bc4407b1421fac776a9b647601a1e',source_review=read(W/'SOURCE_REVIEW.json'),source_review_sha256=sha(W/'SOURCE_REVIEW.json'),launch=launch,listener_pid=listener[0],progress=progress,protocol_sha256=sha(W/'PROTOCOL.json'),training_guards='5GiB launch/4GiB runtime unchanged',storage_equivalence=read(W/'ENGINEERING_QA.json'),V7_replaced=False,new_test_targets_read=False,periodic_model_wakeups=False,same_agent_not_independent_person=True,next='Complete all4fixed arms and different-formula scoring; evaluate information gate. Only then consider separately registered point-price integration.')
write(W/'RUNNING_REVIEW.json',review)
ids=[review['source_event_id'],review['delivery_event_id']]
def hupdate(h):
    h.update(current_stage='four_matched_weather_information_fits',current_process=launch,manager_pid=pid,event_listener_pid=listener[0],numeric_diagnostic_active=True,training_active=True,research_training_active=True,latest_weather_extension=str(W/'RUNNING_REVIEW.json'))
    h['handled_event_ids']=list(dict.fromkeys(h.get('handled_event_ids',[])+ids));h['last_handled_event']=review
    e=h['mechanism_weather_extension_20261007'];e.update(at=at,stage='four_matched_weather_information_fits',launch=launch,latest_attempt=launch,manager_pid=pid,manager_start_utc_ticks=launch['manager_start_utc_ticks'],exit_monitor_pid=monitor.pid,exit_monitor_receipt=launch['receipt'],source_only=False,completed_source_cycles=5286,active_numeric_job=True,latest_progress=progress,latest_event_review=str(W/'RUNNING_REVIEW.json'),source_final_review=str(W/'SOURCE_REVIEW.json'),active_script=str(W/'manager.py'),continuation_protocol=str(W/'PROTOCOL.json'),continuation_protocol_sha256=sha(W/'PROTOCOL.json'),source_download_max_concurrency=0,completed_model_fits=progress.get('completed_model_fits',1),model_fits=progress.get('completed_model_fits',1),next=review['next'])
def lupdate(h):
    h.update(at=at,status='weather_sources_complete_four_information_fits_running',current_launch=launch,latest_attempt=launch,latest_progress_review=str(W/'RUNNING_REVIEW.json'),no_duplicate_restart=True)
    for key in ids:h.setdefault('handled',{}).setdefault(key,dict(at=at,classification='logging_schema_repaired_without_retraining_HISTORY',review=str(W/'RUNNING_REVIEW.json')))
update(B/'HANDOFF.json',hupdate);update(Z/'REVIEWED_SOURCE_EVENTS.json',lupdate)
print(json.dumps(dict(manager_pid=pid,exit_monitor_pid=monitor.pid,listener_pid=listener[0],progress=progress),ensure_ascii=False))
