"""Record handled graph outcome and actual separately authorized F launch."""
from pathlib import Path
import sys
HERE=Path(__file__).resolve().parent;ROOT=HERE.parent
sys.path.insert(0,str(ROOT/'context_expert_v1_20260929'))
import gate
def main():
    graph=HERE/'graph_pilot';fusion=HERE/'fusion_pilot'
    a=gate.read(graph/'AUDIT.json');d=gate.read(graph/'DECISION.json');diag=gate.read(graph/'DIAGNOSIS.json')
    event=ROOT/'event_driven_automation/inbox/v21_graph_unexpected_result_fe80117b1b4dbf68a7681fde842bc42efb0a57a4795928dbcb63d3c0a21ede1f.json'
    assert gate.sha(graph/'AUDIT.json')=='fe80117b1b4dbf68a7681fde842bc42efb0a57a4795928dbcb63d3c0a21ede1f'
    assert gate.sha(graph/'RESULT.json')==a['result_sha256']
    launch=gate.read(fusion/'LAUNCH.json')
    import psutil
    proc=psutil.Process(launch['manager_pid']);assert str(fusion/'manager.py') in ' '.join(proc.cmdline())
    assert psutil.pid_exists(launch['exit_listener_pid'])
    for p,h in gate.read(HERE/'RETAINED_BASELINE_HASHES.json')['files'].items():assert gate.sha(p)==h
    now=gate.now();status=gate.read(HERE/'CURRENT_STATUS.json')
    status.update(at=now,status='H_and_G_closed_F_frozen_feature_pilot_running')
    status['G'].update(status='audited_candidate_failed_closed',decision=str(graph/'DECISION.json'),audit=str(graph/'AUDIT.json'),diagnosis=str(graph/'DIAGNOSIS.json'),
        manager_exited=True,selected_epoch0_cases=15,mae_reduction_percent=d['mae_reduction_percent'],next='No extra edge/epoch search; retain original Europe model.')
    status['F'].update(status='registered_QA_passed_background_frozen_feature_preparation',protocol=str(fusion/'PROTOCOL.json'),qa=str(fusion/'QA.json'),launch=launch,cases=9,epochs_per_case=2,trainable_parameters=5312,
        next='Complete serial feature caches and bounded matched adapter fits, separate scorer/replay audit, then retention decision. No automatic promotion.')
    gate.write(HERE/'CURRENT_STATUS.json',status)
    h=gate.read(ROOT/'HANDOFF.json')
    h.update(updated_at=now,status='multi_round_development_F_running_V7_preserved',research_training_active=True)
    h['next_action']='V21-G closed after audited0of3seed gains; V21-F manager'+str(launch['manager_pid'])+' is preparing frozen features and running9matched nonlinear gated-value fits. Read its status/progress and verify actual manager/child before recovery; do not duplicate. Preserve V7/paper. On completion compare all directions then decide integration; fresh confirmation still not admitted and targets stay sealed.'
    h['multi_round_mechanism_v21'].update(at=now,status=status['status'],new_fits=15,completed_new_meta_fits=18,completed_graph_continuations=15,new_fits_note='15completed graph continuation cases plus18H regressors separately; F9new adapter fits pending.',numerical_worker_active=True,
        manager_pid=launch['manager_pid'],exit_listener_pid=launch['exit_listener_pid'],current_protocol=str(fusion/'PROTOCOL.json'),current_run_status=str(fusion/'status.json'),current_progress=str(fusion/'progress.json'))
    gate.write(ROOT/'HANDOFF.json',h)
    gate.write(HERE/'GRAPH_EVENT_HANDLED.json',dict(at=now,event_id='a755149985a13ce26fccbe91cdce2963e3d795331721e619b3568e06498d7443',event_path=str(event),audit_verified=True,
        outcome='Candidate not promoted; no duplicate inbox message',diagnosis=str(graph/'DIAGNOSIS.json'),next_launch=launch,V7_preserved=True,new_test_targets_read=False))
    print({'status':status['status'],'manager_pid':launch['manager_pid'],'V7_files_verified':17})
if __name__=='__main__':main()
