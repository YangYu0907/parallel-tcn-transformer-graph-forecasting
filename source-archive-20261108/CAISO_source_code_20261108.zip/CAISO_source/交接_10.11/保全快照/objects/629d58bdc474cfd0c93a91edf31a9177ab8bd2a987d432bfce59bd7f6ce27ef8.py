from common import *
import csv,hashlib,heapq,gc
V4=B/'adaptive_experts_v4_20260929';A4=ART.parent/'adaptive_experts_v4_20260929'
np=None

def shape_features(history,rows,nodes,sc,q):
    """history shape72xK; historical prices already normalized by original TRAIN scale."""
    scale=np.array(sc['price_scale'])[0,:,0];center=np.array(sc['price_center'])[0,:,0]
    z=history*scale[nodes][None,:]/q[nodes][None,:]
    now=z[-1];cols=[rows[:,FIELDS],now[:,None]]
    cols.extend([(now-z[-1-l])[:,None] for l in (1,3,6,12,36,71)])
    for n in (12,36,72):
        past=z[-n:];cols.extend([(now-past.min(0))[:,None],(now-past.max(0))[:,None],(now-past.mean(0))[:,None],(abs(past)>1).mean(0)[:,None]])
    cols.append(((71-np.argmax(abs(z),axis=0))/71)[:,None])
    return np.concatenate(cols,axis=1).astype(np.float32)

def prepare():
    for path,digest in gate.read(HERE/'SOURCE_BINDINGS.json')['bindings'].items():assert gate.sha(path)==digest,path
    with np.load(A4/'panel.npz') as z:data={k:z[k] for k in z.files}
    m=gate.read(B/'phase_sampling_support_v3_20260923/dataset/ADDITIVE/manifest.json');paths={k:gate.resolve(v['path']) for k,v in m['artifacts'].items()}
    for path,digest in gate.read(V4/'TRAIN_SOURCE_AUDIT.json')['bindings'].items():assert gate.sha(path)==digest,path
    sc=gate.read(paths['scalers.json']);th=gate.read(paths['state_thresholds.json']);q=np.array(th['thresholds']);center=np.array(th['center'])
    features=np.load(paths['features.npy'],mmap_mode='r');train=np.load(paths['train_origins.npy']);target=np.load(paths['target_scaled.npy'],mmap_mode='r');seconds=np.load(paths['timestamps_seconds.npy'],mmap_mode='r')
    price=raw_price(np.asarray(features[train-1]),sc);oi,ni=np.where(abs(price-center)>q[1]);origins=train[oi]
    rows=np.asarray(features[origins-1,ni]);X=[]
    for start in range(0,len(origins),2048):
        tick(stage='TRAIN_history_shape',done=start,total=len(origins));oo=origins[start:start+2048];nn=ni[start:start+2048]
        hist=np.asarray(features[oo[None,:]-1-np.arange(71,-1,-1)[:,None],nn[None,:],0])
        X.append(shape_features(hist,rows[start:start+2048],nn,sc,q[1]))
    X=np.concatenate(X);scale=np.array(sc['price_scale'])[0,:,0]
    y=(target[origins[:,None]+np.arange(12)[None,:],ni[:,None]]*scale[ni,None]+np.array(sc['price_center'])[0,ni,0,None]-center[ni,None])/q[1,ni,None]
    ratio=q[0,ni]/q[1,ni];classes=(abs(y)>ratio[:,None]).astype(int)+(abs(y)>1).astype(int)
    days=seconds[origins]//86400;unique=np.unique(days);split=unique[int(.9*len(unique))]
    cal=days>=split;fit=(days<split)&(seconds[origins+11]<seconds[origins[cal]].min()-300)
    assert fit.any() and cal.any()
    # Reconstruct exact admitted H1 historical inputs; only extreme-node histories needed.
    xpath=ART/'H1_features.npz'
    if xpath.exists():
        with np.load(xpath) as z:hX=z['X'];h_orig=z['origin_index'];h_nodes=z['node']
    else:
        f=gate.read(H1/'FINAL_TEST_FREEZE.json');parent=gate.read(gate.resolve(f['input_freeze']))
        with np.load(gate.resolve(f['publication_routing'])) as z:meta={k:z[k] for k in z.files}
        meta['epoch']=int(meta['epoch']);sys.path.insert(0,str(B/'h1_feature_admission_v1_20260927'))
        from history import CandidateHistoryReader
        receipts={int(x['origin']):x['input_sha256'] for x in gate.read(gate.resolve(f['feature_receipts']))}
        with Path(parent['config']['node_panel']).open(encoding='utf-8-sig',newline='') as fd:tac=[r['TAC_AREA_ID'] for r in csv.DictReader(fd)]
        reader=CandidateHistoryReader(parent,meta);hx=[];ho=[];hn=[]
        try:
            for j in np.flatnonzero((data['observable_regime']==2).any(1)):
                o=int(data['origins'][j]);nodes=np.flatnonzero(data['observable_regime'][j]==2);hist=reader.history(o,sc,tac,parent['age_caps'])
                assert hashlib.sha256(hist.tobytes()).hexdigest()==receipts[o]
                hx.append(shape_features(hist[-72:,nodes,0],hist[-1,nodes],nodes,sc,q[1]));ho.extend([int(j)]*len(nodes));hn.extend(nodes.tolist());tick()
            hX=np.concatenate(hx);h_orig=np.array(ho);h_nodes=np.array(hn);save(xpath,X=hX,origin_index=h_orig,node=h_nodes)
        finally:reader.close()
    write(HERE/'DATA_ADMISSION.json',dict(at=gate.now(),status='passed',TRAIN_extreme_node_origins=len(origins),TRAIN_cells=int(y.size),fit_cells=int(fit.sum()*12),calibration_cells=int(cal.sum()*12),
        TRAIN_fit_dates=len(np.unique(days[fit])),TRAIN_calibration_dates=len(np.unique(days[cal])),H1_extreme_node_origins=len(h_orig),historical_hash_checks=True,new_test_targets_read=False,
        input_sha256=gate.sha(xpath),fit_counts=np.bincount(classes[fit].ravel(),minlength=3).tolist(),calibration_counts=np.bincount(classes[cal].ravel(),minlength=3).tolist()))
    save(ART/'TRAIN_prepared.npz',X=X,y=y,classes=classes,origins=origins,nodes=ni,fit=fit,cal=cal,ratio=ratio)
    return data,X,y,classes,fit,cal,ratio,hX,h_orig,h_nodes,sc,th

def expand(X):return np.column_stack([np.repeat(X,12,axis=0),np.tile((np.arange(12)+1)/12,len(X))]).astype(np.float32)
def learner(path,X,y,seed,kind):
    from sklearn.ensemble import HistGradientBoostingClassifier,HistGradientBoostingRegressor
    identity=dict(protocol=gate.sha(HERE/'PROTOCOL.json'),seed=seed,kind=kind,rows=len(y),columns=X.shape[1])
    if path.exists():
        obj=load(path);assert obj['identity']==identity;model=obj['model']
    else:
        cls=HistGradientBoostingClassifier if kind=='transition' else HistGradientBoostingRegressor
        model=cls(max_iter=10,max_leaf_nodes=15,min_samples_leaf=50,learning_rate=.05,l2_regularization=1.,early_stopping=False,warm_start=True,random_state=seed)
    for it in range((getattr(model,'n_iter_',0)//10+1)*10,81,10):
        tick(stage='transition_model_fit',case=path.stem,iteration=it,total=80);model.set_params(max_iter=it);model.fit(X,y);dump(path,dict(identity=identity,model=model))
    return model
def temperature(p,t):
    a=np.log(np.maximum(p,1e-12))/t;a-=a.max(-1,keepdims=True);a=np.exp(a);return a/a.sum(-1,keepdims=True)
def mixture(mu,quantiles,prob,ratio,sign):
    atoms=mu[...,None]+quantiles[None,:,:]
    atoms[:,0]=np.clip(atoms[:,0],-ratio[:,None],ratio[:,None])
    for k in (1,2):
        s=np.where(atoms[:,k]>=0,1.,-1.);s=np.where(abs(atoms[:,k])<1e-12,sign[:,None],s)
        atoms[:,k]=s*np.clip(abs(atoms[:,k]),ratio[:,None] if k==1 else 1.,1. if k==1 else np.inf)
    weights=np.broadcast_to(prob[...,None]/quantiles.shape[1],atoms.shape).reshape(len(mu),-1);atoms=atoms.reshape(len(mu),-1)
    mean=(atoms*weights).sum(-1);order=np.argsort(atoms,axis=-1);a=np.take_along_axis(atoms,order,axis=-1);w=np.take_along_axis(weights,order,axis=-1)
    idx=np.argmax(np.cumsum(w,axis=-1)>=.5,axis=-1);median=a[np.arange(len(a)),idx]
    return mean,median

class Priors:
    def __init__(self,prior):self.prior=prior;self.days={};self.seen=set()
    def observe(self,j,h,issued,ready,now,mask,labels,p):
        assert ready<=now and issued<now and (j,h) not in self.seen;self.seen.add((j,h))
        if not mask.any():return
        key=(int(issued)//86400,h//4)
        if key not in self.days:self.days[key]=[np.zeros(3),np.zeros(3),0]
        row=self.days[key];row[0]+=np.bincount(labels[mask],minlength=3);row[1]+=p[mask].sum(0);row[2]+=int(mask.sum())
    def factors(self,now):
        out=np.ones((3,3))
        for h in range(3):
            days=sorted(d for d,k in self.days if k==h)[-7:];obs=5*self.prior.copy();exp=obs.copy()
            for d in days:
                a,p,n=self.days[(d,h)];w=np.exp(-np.log(2)*max(0,now/86400-d-1)/7)
                obs+=w*a/n;exp+=w*p/n
            out[h]=np.clip(obs/np.maximum(exp,1e-9),.5,2)
        return out

def replay(data,fold,rawp,mus,quantiles,prior,sc,th,experts,base,oldmean,oldmedian,allowed):
    ev=np.array(fold['evaluation']);tr=np.array(fold['train']);cal= Priors(prior);events=[]
    for j in np.concatenate([tr,ev]):
        for h in range(12):heapq.heappush(events,(int(data['available'][j,h]),int(j),h))
    output={k:base.copy() for k in ARMS};weights={k:np.zeros((len(ev),30,12,5 if k=='TRANSITION_ONLY' else 7)) for k in ARMS[1:]}
    calibrated=np.zeros((len(ev),30,12,3));means=np.zeros_like(base);medians=np.zeros_like(base);release=[]
    center=np.array(th['center']);q=np.array(th['thresholds']);ratio=np.repeat(q[0]/q[1],12)
    for pos,j in enumerate(ev):
        now=int(data['cutoff'][j]);observed=data['observable_regime'][j]==2
        while events and events[0][0]<=now:
            ready,k,h=heapq.heappop(events);mask=data['observable_regime'][k]==2
            # Destination labels are revealed only after this publication timestamp.
            labels=data['states'][k,:,h]%3
            cal.observe(k,h,int(data['cutoff'][k]),ready,now,mask,labels,rawp[k,:,h]);release.append((k,h,ready,now))
        pp=rawp[j]*cal.factors(now)[np.arange(12)//4][None,:,:];pp/=pp.sum(-1,keepdims=True)
        sign=np.repeat(np.sign(data['raw_last'][j]-center),12)
        mean,median=mixture(mus[j].reshape(-1,3),quantiles,pp.reshape(-1,3),ratio,sign)
        mean=mean.reshape(30,12)*q[1,:,None]+center[:,None];median=median.reshape(30,12)*q[1,:,None]+center[:,None]
        calibrated[pos]=pp;means[pos]=mean;medians[pos]=median
        expanded=np.concatenate([experts[j],mean[...,None],median[...,None]],axis=-1);full=experts[j,...,0]
        for arm in ARMS[1:]:
            ex=experts[j] if arm=='TRANSITION_ONLY' else expanded
            a,b=(oldmean[pos],oldmedian[pos]) if arm=='EXPERT_ONLY' else (mean-full,median-full)
            w,c=correction_weights(ex,a,b,allowed[pos]);forecast=(w*ex).sum(-1)
            output[arm][pos,observed]=forecast[observed];weights[arm][pos]=w
        if pos%64==0:tick(stage='delayed_transition_replay',done=pos,total=len(ev))
    return output,weights,calibrated,means,medians,np.array(release,np.int64)

def main():
    global np
    with gate.exclusive('V5 transition probability expert and matched controls'):
        np,lim=gate.runtime(False);verify();start_budget()
        data,X,y,classes,fit,cal,ratio,hX,ho,hn,sc,th=prepare();Xfit=expand(X[fit]);Xcal=expand(X[cal]);Xh=expand(hX)
        yc=classes[cal].ravel();yf=classes[fit].ravel();quantile_grid=(np.arange(31)+.5)/31
        for seed in SEEDS:
            classifier=learner(ART/'models'/f'{seed}_transition.pkl',Xfit,yf,seed,'transition');assert classifier.classes_.tolist()==[0,1,2]
            cp=classifier.predict_proba(Xcal);hp=classifier.predict_proba(Xh)
            from scipy.optimize import minimize_scalar
            temp=minimize_scalar(lambda t:-np.log(np.maximum(temperature(cp,t)[np.arange(len(yc)),yc],1e-12)).mean(),bounds=(.5,2),method='bounded').x
            hp=temperature(hp,temp);cp=temperature(cp,temp);mu=np.empty((len(Xh),3));quantiles=[];counts=[]
            for k in range(3):
                mask=yf==k;lear=learner(ART/'models'/f'{seed}_destination{k}.pkl',Xfit[mask],y[fit].ravel()[mask],seed+k+10,'destination')
                cm=yc==k;assert cm.sum()>=31,'Insufficient TRAIN calibration for a destination distribution'
                residual=y[cal].ravel()[cm]-lear.predict(Xcal[cm]);quantiles.append(np.quantile(residual,quantile_grid));counts.append(int(cm.sum()));mu[:,k]=lear.predict(Xh)
            quantiles=np.array(quantiles);prior=(np.bincount(yc,minlength=3)+1)/(len(yc)+3)
            rawp=np.broadcast_to(prior,(len(data['origins']),30,12,3)).copy();mus=np.zeros_like(rawp)
            rawp[ho,hn]=hp.reshape(len(ho),12,3);mus[ho,hn]=mu.reshape(len(ho),12,3)
            save(ART/'models'/f'{seed}_distributions.npz',rawp=rawp,mus=mus,quantiles=quantiles,prior=prior,temperature=np.array(temp))
            write(HERE/'receipts'/f'{seed}_TRAIN.json',dict(at=gate.now(),calibration_counts=counts,temperature=float(temp),fit_classes=np.bincount(yf,minlength=3).tolist(),TRAIN_calibration_NLL=float(-np.log(np.maximum(cp[np.arange(len(yc)),yc],1e-12)).mean())))
            with np.load(A4/'experts'/f'{seed}.npz') as z:experts=z['experts']
            for fold in gate.read(V4/'FOLDS.json'):
                out=ART/'folds'/f'{seed}_fold{fold["id"]}.npz';receipt=HERE/'receipts'/f'{seed}_fold{fold["id"]}.json'
                if receipt.exists():assert gate.sha(out)==gate.read(receipt)['sha256'];continue
                with np.load(A4/'folds'/f'{seed}_fold{fold["id"]}.npz') as z:
                    base=z['NEW5'];oldmean=z['corrected_mean'];oldmedian=z['corrected_median'];allowed=z['allowed']
                outputs,weights,pp,mean,median,releases=replay(data,fold,rawp,mus,quantiles,prior,sc,th,experts,base,oldmean,oldmedian,allowed)
                ev=np.array(fold['evaluation']);save(out,origins=data['origins'][ev],eval_indices=ev,releases=releases,probabilities=pp,mean=mean,median=median,**outputs,**{k+'_weights':w for k,w in weights.items()})
                write(receipt,dict(at=gate.now(),sha256=gate.sha(out),seed=seed,fold=fold['id'],evaluation_origins=len(ev)))
                print(json.dumps(dict(seed=seed,fold=fold['id'],complete=True)),flush=True)
            gc.collect()
        tick(stage='fits_complete');write(HERE/'FIT_COMPLETE.json',dict(at=gate.now(),status='three_seeds_three_controls_ready_for_audit',neural_updates=0,new_test_targets_read=False,
            artifacts={str(q):gate.sha(q) for q in (ART/'folds').glob('*.npz')}))
if __name__=='__main__':main()
