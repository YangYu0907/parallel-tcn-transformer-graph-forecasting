"""Historical node-wise convex graph gate; temporal/fusion modules are untouched."""
import math
import torch
from torch import nn
from torch.nn import functional as F
from models.clip_model import ClipFusion
from models.model_feature_fusion_rev12 import GraphEncoder
class GatedGraph(GraphEncoder):
    def dynamic_adjacency(self,projected):
        adjacency,context=super().dynamic_adjacency(projected)
        weight=self.spatial_gate(context).sigmoid()
        identity=torch.eye(projected.shape[2],dtype=projected.dtype,device=projected.device).unsqueeze(0)
        return (1-weight)*identity+weight*adjacency,context
def build_graph(mode,seed,limits):
    if mode=='FULL':return ClipFusion('FULL',seed,limits)
    if mode not in ('MIX','GATE'):raise ValueError('Unknown graph pilot')
    model=ClipFusion('FULL',seed,limits);model.graph_gate_mode=mode
    model.graph.__class__=GatedGraph
    with torch.random.fork_rng(devices=[]):
        torch.manual_seed(seed+910000)
        model.graph.spatial_gate=nn.Linear(32,1)
        nn.init.zeros_(model.graph.spatial_gate.weight);nn.init.zeros_(model.graph.spatial_gate.bias)
    if mode=='MIX':model.graph.spatial_gate.requires_grad_(False)
    return model
def inactive_name(mode,name):return mode=='MIX' and name.startswith('graph.spatial_gate.')
def explicit_graph(model,x):
    """Independent graph formula does not call graph.forward or dynamic_adjacency."""
    g=model.graph
    projected=F.linear(x,g.input_projection.weight,g.input_projection.bias)
    batch,steps,nodes,width=projected.shape
    sequence=projected.permute(0,2,1,3).reshape(batch*nodes,steps,width)
    _,hidden=g.context_gru(sequence);context=hidden[-1].reshape(batch,nodes,width)+g.node_embedding.unsqueeze(0)
    query=F.linear(context,g.query.weight);key=F.linear(context,g.key.weight)
    scores=query@key.transpose(-1,-2)/math.sqrt(width)
    eye=torch.eye(nodes,dtype=torch.bool,device=x.device)
    values,indices=scores.masked_fill(eye,-torch.inf).topk(g.top_k,dim=-1)
    sparse=torch.full_like(scores,-torch.inf).scatter(-1,indices,values).masked_fill(eye,0.)
    dynamic=sparse.softmax(-1)
    weight=torch.sigmoid(F.linear(context,g.spatial_gate.weight,g.spatial_gate.bias))
    identity=eye.to(x.dtype).unsqueeze(0)
    adjacency=(1-weight)*identity+weight*dynamic
    messages=torch.einsum('bij,btjd->btid',adjacency,F.linear(projected,g.message.weight))
    encoded=F.layer_norm(projected+F.linear(F.gelu(messages),g.output.weight,g.output.bias),
        g.norm.normalized_shape,g.norm.weight,g.norm.bias,g.norm.eps)
    return encoded,adjacency,context,weight
def explicit_forward(model,x):
    encoded,adjacency,context,weight=explicit_graph(model,x)
    b,t,n,d=encoded.shape
    local=model.tcn(encoded)
    sequence=encoded.permute(0,2,3,1).reshape(b*n,d,t)
    tokens=F.avg_pool1d(F.avg_pool1d(sequence,12,6,ceil_mode=True),6,6,ceil_mode=True).transpose(1,2)
    distant=model.transformer(tokens).reshape(b,n,d)
    queries=F.linear(context,model.attention.query.weight).unsqueeze(2)+model.attention.horizon_embedding
    keys=F.linear(torch.stack((local,distant),2),model.attention.key.weight)
    weights=(torch.einsum('bnhd,bnkd->bnhk',queries,keys)/math.sqrt(d)+model.attention.branch_bias).softmax(-1)
    fused=weights[...,:1]*local.unsqueeze(2)+weights[...,1:]*distant.unsqueeze(2)
    raw=torch.stack((x[:,-1,:,0],x[:,-1,:,0]-x[:,-12:,:,0].mean(1)),-1)
    observed=torch.clamp(raw,min=-model.context_limits,max=model.context_limits)
    features=fused+F.linear(observed,model.price_context.weight).unsqueeze(2)
    return model.head(features),fused,adjacency
