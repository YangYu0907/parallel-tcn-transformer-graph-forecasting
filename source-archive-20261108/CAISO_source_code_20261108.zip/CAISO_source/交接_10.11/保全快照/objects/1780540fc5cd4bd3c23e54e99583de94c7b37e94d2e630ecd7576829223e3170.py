"""Fit-free score attribution; does not select a new candidate."""
import common as c
import pickle
def main():
    p=c.verify();r=c.read(c.HERE/'RESULT.json');a=c.read(c.HERE/'AUDIT.json')
    assert a['status']=='passed' and c.sha(c.HERE/'RESULT.json')==a['result_sha256']
    reg=c.HERE/'ATTRIBUTION_PROTOCOL.json'
    description=dict(at=c.now(),scope='Post-result explanatory calculation on existing TRAIN-prefix development only',
        purpose='Separate training fit, temporal transport and population weighting; do not tune or replace failed CONTEXT.',
        computations=['Train and chronological evaluation Brier under both cell and equal-date aggregation',
                      'Class proportions and mean predicted probabilities under both aggregations',
                      'Feature range-support diagnostics against prior-date training min/max, grouped by price and additional context',
                      'No classifier fitting, probability recalibration, weight change, or new test access'],
        script_sha256=c.sha(__file__),result_sha256=c.sha(c.HERE/'RESULT.json'))
    if not reg.exists():c.write(reg,description)
    else:assert c.read(reg)['script_sha256']==description['script_sha256']
    with c.gate.exclusive('V22 fit-free generalization and aggregation attribution'):
        np,lim=c.gate.runtime(False)
        with np.load(p['library'],allow_pickle=False) as z:d={k:z[k] for k in z.files}
        with np.load(r['output'],allow_pickle=False) as z:saved={k:z[k] for k in z.files}
        y=(d['states']-3).astype(int);days=d['issued']//86400
        def score(yy,pp,dd):
            one=np.eye(3)[yy];err=np.square(one-pp).sum(-1);unique=np.unique(dd)
            return dict(cells=int(yy.size),dates=len(unique),cell_brier=float(err.mean()),
                equal_date_brier=float(np.mean([err[dd==day].mean() for day in unique])),
                cell_prevalence=[float((yy==k).mean()) for k in range(3)],
                equal_date_prevalence=[float(np.mean([(yy[dd==day]==k).mean() for day in unique])) for k in range(3)],
                cell_mean_probability=pp.mean(axis=(0,1)).tolist(),
                equal_date_mean_probability=np.mean([pp[dd==day].mean(axis=(0,1)) for day in unique],axis=0).tolist())
        rows=[]
        for i,f in enumerate(r['folds']):
            c.check();train=c.eligible(d,c.stamp(p['folds'][i][0]),np);test=(d['issued']>=c.stamp(p['folds'][i][0]))&(d['issued']<c.stamp(p['folds'][i][1]))
            item=dict(month=f['month'],arms={})
            for arm in ('PRICE','CONTEXT'):
                mpath=f['models'][arm]['path'];assert c.sha(mpath)==f['models'][arm]['sha256']
                with open(mpath,'rb') as fh:m=pickle.load(fh)['model']
                xx=c.matrix(d,arm,np);tr=xx[np.repeat(train,12)];te=xx[np.repeat(test,12)]
                ptr=m.predict_proba(tr).reshape(-1,12,3);pte=m.predict_proba(te).reshape(-1,12,3)
                assert np.allclose(pte,saved[arm][saved['fold']==i],atol=1e-14,rtol=0)
                lo=tr.min(0);hi=tr.max(0);vary=hi-lo>1e-8;outside=(te<lo-1e-8)|(te>hi+1e-8)
                feature_counts=outside.sum(0);ranks=np.argsort(-feature_counts)[:8]
                item['arms'][arm]=dict(train=score(y[train],ptr,days[train]),evaluation=score(y[test],pte,days[test]),
                    variable_features=int(vary.sum()),fraction_cells_outside_any_training_feature_range=float(outside.any(1).mean()),
                    outside_feature_fraction=float(outside.mean()),most_outside_features=[dict(column=int(k),count=int(feature_counts[k]),fraction=float(feature_counts[k]/len(te))) for k in ranks],
                    caution='Marginal range departure is descriptive, dimension-dependent, and is not proof of distribution shift as the cause of forecast error.')
            rows.append(item)
        aggregate={arm:score(saved['truth_class'],saved[arm],saved['issued']//86400) for arm in p['arms']}
        c.preserved()
        c.write(c.HERE/'ATTRIBUTION.json',dict(at=c.now(),status='fit_free_completed',rows=rows,aggregate=aggregate,
            attribution_scope='Feature richness, temporal generalization and weighting are empirically distinguished; causal attribution remains unproven.',
            new_fits=0,V7_unchanged=True,new_test_targets_read=False,script_sha256=c.sha(__file__)))
        print({'aggregate':aggregate,'train_eval_by_month':[{ 'month':x['month'],'arms':{k:{'train_brier':v['train']['cell_brier'],'train_date_brier':v['train']['equal_date_brier'],'eval_brier':v['evaluation']['cell_brier'],'eval_date_brier':v['evaluation']['equal_date_brier']} for k,v in x['arms'].items()}} for x in rows]})
if __name__=='__main__':main()
