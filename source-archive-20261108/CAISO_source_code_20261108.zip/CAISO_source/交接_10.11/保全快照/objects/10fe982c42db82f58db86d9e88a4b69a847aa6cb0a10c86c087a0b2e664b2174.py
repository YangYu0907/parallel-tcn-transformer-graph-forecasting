"""Small synthetic 30-epoch external lifecycle QA. Never reads market arrays."""
from pathlib import Path
import copy,json,random,time,uuid
import external_train as r

def execute():
    started=time.perf_counter()
    r.preparation_check()
    with r.exclusive("external_synthetic_30epoch_math"):
        runtime,limiter=r.numeric_runtime();torch,np=r.torch,r.np
        checks=[]
        def check(ok,label):
            if not ok:raise AssertionError(label)
            checks.append(label)
        def equal(a,b):
            if isinstance(a,torch.Tensor):return isinstance(b,torch.Tensor) and a.dtype==b.dtype and torch.equal(a,b)
            if isinstance(a,np.ndarray):return isinstance(b,np.ndarray) and a.dtype==b.dtype and np.array_equal(a,b)
            if isinstance(a,dict):return isinstance(b,dict) and a.keys()==b.keys() and all(equal(a[k],b[k]) for k in a)
            if isinstance(a,(list,tuple)):return type(a)==type(b) and len(a)==len(b) and all(equal(x,y) for x,y in zip(a,b))
            return a==b
        class Tiny(torch.nn.Module):
            def __init__(self):
                super().__init__()
                self.net=torch.nn.Sequential(torch.nn.Linear(3,7),torch.nn.GELU(),torch.nn.Dropout(.2),torch.nn.Linear(7,2))
            def forward(self,x,marks=None):return self.net(x)
        torch.manual_seed(71023);template=Tiny()
        x=torch.arange(39,dtype=torch.float32).reshape(13,3)/13-1
        y=torch.stack((x[:,0]*.8-2,-x[:,2]*.3+1),dim=1)
        model=copy.deepcopy(template).eval();ref=copy.deepcopy(template).eval();opt=r.optimizer(model)
        group=opt.param_groups[0]
        check(group["lr"]==.001 and group["weight_decay"]==.0001 and group["betas"]==(.9,.999) and group["eps"]==1e-8,"AdamW exact registered arguments")
        residual=ref(x[:4])-y[:4];absolute=residual.abs()
        direct=torch.where(absolute<=.5,.5*residual.square(),.5*(absolute-.25)).mean();direct.backward()
        norm=torch.linalg.vector_norm(torch.cat([p.grad.reshape(-1) for p in ref.parameters()]))
        factor=min(1.,1./(float(norm)+1e-6));expected={}
        for name,p in ref.named_parameters():
            g=p.grad*factor;expected[name]=p.detach()*(1-.001*.0001)-.001*g/(g.abs()+1e-8)
        loss,observednorm=r.update(model,opt,x[:4],y[:4])
        check(abs(loss-float(direct.detach()))<1e-7,"Mean Huber.5 independent piecewise formula")
        check(abs(observednorm-float(norm))<1e-6,"Global clipnorm independent concatenation")
        check(all(torch.allclose(p,expected[n],rtol=2e-6,atol=2e-7) for n,p in model.named_parameters()),"Independent first AdamW bias-corrected update")
        sch=r.EpochCosine(opt);rates=[]
        for e in range(1,31):sch.set_epoch(e);rates.append(opt.param_groups[0]["lr"])
        directrates=.0001+.5*(.001-.0001)*(1+np.cos(np.pi*np.arange(30)/29))
        check(np.allclose(rates,directrates,rtol=0,atol=1e-18) and rates[0]==.001 and rates[-1]==.0001,"All30 epochcosine rates and endpoints")
        check(r.phase_epoch(6)==6 and r.phase_epoch(7)==1 and r.phase_epoch(30)==6,"Phase6to7 wraps while cosine continues")
        def rejected(fn):
            try:fn()
            except (ValueError,RuntimeError):return True
            return False
        check(rejected(lambda:r.phase_epoch(31)) and rejected(lambda:r.EpochCosine.rate(31)),"Unregistered31st epoch rejected")
        def score_rows(scores):return [dict(epoch=e,june=dict(mae=v)) for e,v in enumerate(scores,1)]
        check(r.selection(score_rows([10.]*6))==dict(best_epoch=1,best_mae=10.,bad_epochs=0,early_stop=False),"No early stopping during mandatory6epochs")
        check(r.selection(score_rows([10.]*10))["bad_epochs"]==4 and not r.selection(score_rows([10.]*10))["early_stop"],"Patience begins at7")
        check(r.selection(score_rows([10.]*11))["early_stop"],"Earliest patience stop afterepoch11")
        check(rejected(lambda:r.selection(score_rows([10.]*12))),"Updates beyond firstpatience stop rejected")
        near=r.selection(score_rows([10.,9.9999995,9.999998]))
        check(near["best_epoch"]==3 and near["best_mae"]==9.999998,"1e-6 selection threshold and earliest tie")
        check(r.selection(score_rows([10.]*6+[9.,9.,9.,9.,8.]))["bad_epochs"]==0,"Improvement resets patience")
        counts=[9,11,8,10,7,13]
        maxsteps=5*sum((n+3)//4 for n in counts)
        identity=dict(scope="synthetic",epoch_counts=counts,maximum_updates=maxsteps,seed=20260813)
        folder=r.ROOT/"audits"/"mq"/uuid.uuid4().hex[:8]
        run1,run2=folder/"continuous",folder/"resumed"
        run1.mkdir(parents=True);run2.mkdir(parents=True)
        def fresh():
            m=copy.deepcopy(template).train();op=r.optimizer(m);sc=r.EpochCosine(op)
            torch.manual_seed(4811);np.random.seed(4811);random.seed(4811);rng=np.random.default_rng(20260813)
            return [m,op,sc,rng,r.initial_state()]
        def drive(parts,run,trace,stop_steps=(),flat_scores=False):
            m,op,sc,rng,state=parts
            while state["phase"]=="train" or (state["epoch"]<30 and not state["early_stop"]):
                if state["phase"]=="epoch_complete":
                    e=state["epoch"]+1;sc.set_epoch(e)
                    state.update(phase="train",epoch=e,offset=0,order=rng.permutation(r.epoch_count(identity,e)),train_huber_sum=0.,gradient_norm_sum=0.)
                n=r.epoch_count(identity,state["epoch"])
                while state["offset"]<n:
                    pos=state["offset"];ix=state["order"][pos:pos+4]
                    loss,norm=r.update(m,op,x[ix],y[ix])
                    state["steps"]+=1;state["offset"]=min(pos+4,n)
                    state["train_huber_sum"]+=loss*len(ix);state["gradient_norm_sum"]+=norm*len(ix)
                    r.validate_state(state,identity)
                    trace.append(dict(step=state["steps"],epoch=state["epoch"],phase_epoch=r.phase_epoch(state["epoch"]),
                        offset=state["offset"],loss=loss,norm=norm,model=copy.deepcopy(m.state_dict()),
                        optimizer=copy.deepcopy(op.state_dict()),scheduler=sc.state_dict(),rng=r.rng_state(rng)))
                    if state["steps"] in stop_steps:
                        r.write(run/"STOP_REQUESTED.json",dict(synthetic=True,step=state["steps"]))
                        check(r.stop_reason(run) is not None,"SafeSTOP detection at completed update "+str(state["steps"]))
                        receipt=r.checkpoint(run,r.payload(m,op,sc,rng,identity,runtime,state))
                        check(receipt["steps"]==state["steps"],"Stopreceipt exactlycommitted cursor "+str(state["steps"]))
                        return parts,receipt
                e=state["epoch"]
                state["epochs"].append(dict(epoch=e,june=dict(mae=10. if flat_scores else 100.-e),lr=sc.rate(e)))
                state.update(phase="epoch_complete",offset=0,order=None,**r.selection(state["epochs"]))
                r.validate_state(state,identity)
            return parts,None
        reference_trace=[];baseline,_=drive(fresh(),run1,reference_trace)
        expected_payload=r.payload(*baseline[:4],identity,runtime,baseline[4])
        # Stop before June atphase6end, atfirstphase7update, amidphase7, later, andfinalupdate.
        stops=[5,sum((n+3)//4 for n in counts),sum((n+3)//4 for n in counts)+1,20,47,maxsteps]
        parts=fresh();resumed_trace=[]
        for stop in stops:
            parts,receipt=drive(parts,run2,resumed_trace,(stop,))
            check(receipt is not None,"Scheduled resume point reached "+str(stop))
            check(r.recover_receipt(run2)==receipt,"Durable receipt recovery "+str(stop))
            saved=r.load_checkpoint(run2,receipt)
            (run2/"STOP_REQUESTED.json").rename(run2/("STOP_ACKNOWLEDGED_"+str(stop)+".json"))
            m,op,sc,rng,_=fresh()
            state=r.restore(saved,m,op,sc,rng,identity,runtime);r.validate_state(state,identity)
            parts=[m,op,sc,rng,state]
        parts,_=drive(parts,run2,resumed_trace)
        actual_payload=r.payload(*parts[:4],identity,runtime,parts[4])
        check(len(reference_trace)==len(resumed_trace)==maxsteps,"Every optimizer update recorded across30epochs")
        check(all(equal(a,b) for a,b in zip(reference_trace,resumed_trace)),"Everypoint continuous/resumed model optimizer RNG andcursor bitwise equal")
        check(equal(expected_payload,actual_payload),"Final30epoch continuous/resumed payload bitwise equal")
        around=[v for v in resumed_trace if v["epoch"] in (6,7)]
        check(any(v["phase_epoch"]==6 for v in around) and any(v["phase_epoch"]==1 for v in around),"Numerical replay actuallycrosses6to7")
        check(rejected(lambda:r.restore(saved,m,op,sc,rng,dict(identity,seed=20260814),runtime)),"Changedidentity restore rejected")
        check(rejected(lambda:r.load_checkpoint(run2,dict(receipt,path=str(r.BUNDLE/"old/model.pt")))),"Oldbranch checkpoint rejectedbeforeopen")
        malformed=copy.deepcopy(saved["progress"]);malformed["steps"]+=1
        check(rejected(lambda:r.validate_state(malformed,identity)),"Malformedstepcursor rejected")
        malformed=copy.deepcopy(actual_payload["progress"]);malformed["bad_epochs"]=1
        check(rejected(lambda:r.validate_state(malformed,identity)),"Malformedpatiencestate rejected")
        flat_run1,flat_run2=folder/"flat_continuous",folder/"flat_resumed"
        flat_run1.mkdir();flat_run2.mkdir()
        flat_trace1=[];flat_parts1,_=drive(fresh(),flat_run1,flat_trace1,flat_scores=True)
        check(flat_parts1[4]["epoch"]==11 and flat_parts1[4]["early_stop"],"Actualtoyloop stops exactlyepoch11 onconstantJune")
        flat_trace2=[];pause_step=sum((counts[(e-1)%6]+3)//4 for e in range(1,10))
        flat_parts2,flat_receipt=drive(fresh(),flat_run2,flat_trace2,(pause_step,),flat_scores=True)
        flat_saved=r.load_checkpoint(flat_run2,flat_receipt)
        check(flat_saved["progress"]["bad_epochs"]==2 and flat_saved["progress"]["best_epoch"]==1,"Checkpoint captures accumulatedpatience andearliestbest")
        (flat_run2/"STOP_REQUESTED.json").rename(flat_run2/"STOP_ACKNOWLEDGED.json")
        fm,fo,fs,fr,_=fresh()
        fstate=r.restore(flat_saved,fm,fo,fs,fr,identity,runtime)
        flat_parts2,_=drive([fm,fo,fs,fr,fstate],flat_run2,flat_trace2,flat_scores=True)
        check(all(equal(a,b) for a,b in zip(flat_trace1,flat_trace2)) and len(flat_trace1)==len(flat_trace2),"Earlystoptrajectory everypoint resumeexact")
        check(equal(r.payload(*flat_parts1[:4],identity,runtime,flat_parts1[4]),r.payload(*flat_parts2[:4],identity,runtime,flat_parts2[4])),"Earlystop completepayload andstopdecision resumeexact")
        check("compiled_data" not in __import__("sys").modules,"No marketdataadapter imported")
        import compile_gate as gate
        report=dict(status="passed",at=r.now(),checks=checks,check_count=len(checks),
            resume_exact=True,optimizer_recipe_exact=True,epoch_cosine_30_exact=True,phase6_to7_exact=True,
            selection_patience_exact=True,safe_stop_boundary_verified=True,synthetic_only=True,
            actual_market_values_read=False,Q3_targets_read=False,test_2026_targets_read=False,
            synthetic_optimizer_steps=1+2*maxsteps+2*flat_parts1[4]["steps"],formal_optimizer_steps=0,
            source_runtime=runtime,sources=r.source_paths(),resources=gate.check_working_set(),
            elapsed_seconds=time.perf_counter()-started,artifacts={str(p.relative_to(r.ROOT)):r.sha(p) for p in folder.rglob("*") if p.is_file()})
        r.write(r.MATH_QA,report);return report
if __name__=="__main__":print(json.dumps(execute(),ensure_ascii=True))
