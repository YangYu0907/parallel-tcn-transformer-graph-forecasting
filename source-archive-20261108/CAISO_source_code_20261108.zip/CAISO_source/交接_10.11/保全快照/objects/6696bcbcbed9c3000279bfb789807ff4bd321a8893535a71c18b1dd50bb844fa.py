from common import *
from design import design,temper,metric,U
import numpy as np,pickle,gc,time
from scipy.optimize import minimize_scalar
import disk_hgb
def dump(path,obj):
 tmp=path.with_name('.m'+os.urandom(4).hex())
 with tmp.open('wb') as f:pickle.dump(obj,f,protocol=5)
 os.replace(tmp,path)
def run(p,tick):
 with np.load(E/'INDICES.npz') as a:arr={k:a[k] for k in a.files}
 fit,cal,ev=arr['fit'],arr['cal'],arr['eval'];y=arr['y'];completed=0
 for arm in p['arms']:
  cell=E/arm;cell.mkdir(exist_ok=True)
  if (cell/'DONE.json').exists():
   rec=read(cell/'DONE.json');assert all(sha(path)==h for path,h in rec['bindings'].items());continue
  start=time.monotonic()
  def ct(**kw):tick(arm=arm,completed_fits=completed,**kw)
  if arm in p['new_arms']:
   target=cell/'x.npy';marker=cell/'DESIGN.json'
   if marker.exists():assert sha(target)==read(marker)['sha256']
   else:
    mm=np.lib.format.open_memmap(target,mode='w+',dtype=np.float32,shape=(len(fit),p['features'][arm]),fortran_order=True);mm._mmap.close()
    for begin in range(0,len(fit),8192):
     ii=fit[begin:begin+8192];v=design(arr,ii,arm);mm=np.load(target,mmap_mode='r+');mm[begin:begin+len(v)]=v;mm.flush();mm._mmap.close()
     if begin%65536==0:ct(stage='design',rows=begin,total=len(fit))
    write(marker,dict(sha256=sha(target)))
   mp=cell/'model.pkl';fp=cell/'FIT.json'
   if mp.exists():
    assert sha(mp)==read(fp)['sha256']
    with mp.open('rb') as f:model=pickle.load(f)
   else:model=disk_hgb.DiskHGB(**dict(p['learner'],max_leaf_nodes=p['capacity'][arm]))
   disk_hgb.TICK=ct
   for it in p['iterations']:
    if getattr(model,'n_iter_',0)>=it:continue
    ct(stage='fit',iterations=it);mm=np.load(target,mmap_mode='r');model.set_params(max_iter=it);model.fit(mm,(y[fit]==1).astype(np.int8));mm._mmap.close()
    dump(mp,model);write(fp,dict(at=now(),n_iter=it,sha256=sha(mp)))
   completed+=1
   if arm.endswith('2'):assert all(int(t[0].nodes['is_leaf'].sum())<=2 for t in model._predictors)
  else:
   old='COARSE_DAM' if arm=='R7' else arm;mp=U/'Q1_2025'/old/'model.pkl'
   with mp.open('rb') as f:model=pickle.load(f)
  def predict(ii):
   out=np.empty(len(ii))
   for begin in range(0,len(ii),8192):
    jj=ii[begin:begin+8192];out[begin:begin+len(jj)]=model.predict_proba(design(arr,jj,arm))[:,1]
    if begin%65536==0:ct(stage='predict',rows=begin,total=len(ii))
   return out
  cp0=predict(cal);truth=y[cal]==1
  def loss(t):
   q=np.clip(temper(cp0,t),1e-12,1-1e-12);return float(-np.where(truth,np.log(q),np.log1p(-q)).mean())
  temp=float(minimize_scalar(loss,bounds=(.5,2),method='bounded').x);cp=temper(cp0,temp)
  th=float(np.quantile(cp[~truth],.99,method='higher'))
  write(cell/'CAL_FROZEN.json',dict(at=now(),temperature=temp,threshold=th,model_sha256=sha(mp)))
  ep0=predict(ev);ep=temper(ep0,temp)
  save(cell/'PRED.npz',raw=ep0,q=ep,cal_raw=cp0,cal_q=cp)
  write(cell/'DONE.json',dict(at=now(),seconds=time.monotonic()-start,model_reused=arm not in p['new_arms'],bindings={str(path):sha(path) for path in [mp,cell/'CAL_FROZEN.json',cell/'PRED.npz']}))
  del model,cp,cp0;gc.collect()
 tick(stage='all_three_new_fits_finished',completed_fits=3)

