import common as c

def main():
    assert not (c.HERE/'SEAL.json').exists(),'Already registered'
    c.gate.boundary();c.protected()
    old=c.read(c.OLD/'PROTOCOL.json')
    cases=[x for x in old['cases'] if x['variant']=='FULL']
    assert [x['seed'] for x in cases]==[20260813,20260814,20260815]
    for case in cases:assert c.sha(case['parent'])==case['parent_sha256']
    p=dict(at=c.now(),status='registered_before_cache_or_fit',id='V26-temporal-memory-vs-summary',cases=cases,
        authorization='User: 继续，你再努力试一下. Bounded temporal-information follow-up; V7 remains preserved.',
        scope='Exploratory TRAIN/June3397, already used in development; no new independent test or V7 deployment claim.',
        hypothesis='Horizon-conditioned access to pre-summary temporal states may help where adding a gate to already-compressed summaries did not. Synthetic non-injectivity alone does not establish predictive utility.',
        candidate='TOKEN: original frozen FULL plus zero-initialized residual feature readout. Memory: eight three-step averages of the most recent24 TCN hidden positions, plus eight Transformer outputs before summary pooling; original output norms. Per-horizon query from original fused features plus frozen head horizon embedding. Key/value width16, softmax scaled by4, fixed positional keys, 2080 parameters. Original feature attention and prediction head remain unchanged.',
        control='SUMMARY: identical2080parameters, initialization,16memory positions and compute; first8values repeat TCNsummary, last8 repeat Transformersummary. Memory differs but all learned layers match. PARENT is unchanged frozen FULL. This probes temporal information jointly, not the independent causal effect of either branch.',
        freeze='All original graph, TCN, Transformer, fusion attention, context and prediction head parameters frozen/eval. Only residual readout learned. Zero output map reproduces parent exactly; training can still worsen results.',
        dataset_manifest=old['dataset_manifest'],
        training='All17102unique origins from six original ADDITIVE training arrays, two complete passes per arm; exact paired seed-based sample orders. No June targets in training.',
        validation='June3397 primary; June284 and balanced278 consistency panels. All nodes,horizons,states retained. Epoch0,1,2 selected by primary MAE; earliest tie1e-6.',
        lr=.001,weight_decay=.0001,batch_size=64,epochs=2,loss='normalized Huber delta0.5',grad_clip=1.,
        stage_one='Seed20260813 first, both arms. Expand to other2seeds only if TOKEN MAE improves>=0.5percent vs PARENT and beats SUMMARY, with RMSE,nearMAE,H12MAE no worse than PARENT. Otherwise close this pilot. This is an efficiency screen, not a test of impossibility.',
        final_gate='All3seeds completed; mean TOKEN MAE>=0.5percent better than PARENT and below SUMMARY, >=2seeds improve. Mean RMSE,nearMAE,H12MAE and every nonempty S0..5 MAE/RMSE do not worsen vs PARENT. Empty states insufficient. Gates only justify subsequent fully matched controls/V7 integration, not promotion.',
        inference='Descriptive development results; paired real7day-block bootstrap2000, two comparisons TOKENvsPARENT/SUMMARY with Holm. Few date blocks and repeated selection are explicitly retained; no fresh-confirmation significance claim.',
        maximum_reader_fits=6,maximum_seconds=7200,stop='No learning-rate,epoch,width,token-count or gate search; preserve all results; failed first-seed screen stops remaining fits.',
        resources=dict(single_numeric_worker=True,threads=1,launch_GiB=5,runtime_GiB=4,numeric='C temporary authorized',metadata='F project'),
        literature=[dict(url='https://arxiv.org/abs/2211.14730',supports='Local subseries representation; tokenization does not shorten output horizon or guarantee accuracy.'),dict(url='https://github.com/Thinklab-SJTU/Crossformer',supports='Temporal/cross-dimension token interaction inspires a readout probe; not replication or proof of superiority to CONCAT.')],
        new_test_targets_read=False,V7_preserved=True)
    c.write(c.HERE/'PROTOCOL.json',p)
    manifest=c.B/'phase_sampling_support_v3_20260923/dataset/ADDITIVE/manifest.json'
    paths=list(c.HERE.glob('*.py'))+[c.HERE/'PROTOCOL.json',manifest,manifest.parent/'audit.json',c.OLD/'PROTOCOL.json',c.OLD/'SEAL.json',c.B/'TASK_PARALLEL_DEVELOPMENT_REVISION_20261001.json',c.B/'source/compiled_data.py',c.B/'matched_panel_v1_20260924/reductions.py',c.B/'context_expert_v1_20260929/gate.py',c.B/'source/compile_gate.py']
    paths+=list((c.B/'source/models').glob('*.py'))
    for case in cases:
        paths.append(c.Path(case['parent']))
        for part in ('fit','june_dense'):paths.append(c.OLDART/case['id']/'cache'/part/'receipt.json')
    c.write(c.HERE/'SEAL.json',dict(at=c.now(),bindings={str(x):c.sha(x) for x in paths}))
    c.write(c.HERE/'status.json',dict(at=c.now(),status='registered',training_started=False))
    print('V26 registered: one candidate, matched control,2 to6 fits.')

if __name__=='__main__':main()
