"""Wait for an identified parent process exit, then run once. No timer wakeups."""
from pathlib import Path
import sys, os, json, subprocess, traceback, ctypes, uuid
HERE=Path(__file__).resolve().parent
sys.path.insert(0,str(HERE.parent))
from common import B, ROOT, read, write, sha, guard, now

def status(**kw):write(HERE/'STATUS.json',dict(at=now(),pid=os.getpid(),**kw))
def emit(kind,proof):
    eid='horizon_reviewer_'+kind+'_'+sha(proof)
    p=B/'event_driven_automation/inbox'/(eid+'.json')
    if not p.exists():
        temp=p.with_suffix('.'+uuid.uuid4().hex+'.tmp')
        temp.write_text(json.dumps(dict(schema='caiso_research_event_v1',event_id=eid,event=kind,
            evidence_path=str(proof),evidence_sha256=sha(proof),at=now()),ensure_ascii=False,indent=2),encoding='utf-8')
        os.replace(temp,p)
    return eid

def wait_parent(launch):
    # A Windows kernel handle binds the original process, including PID reuse protection.
    import psutil
    pid=launch['manager_pid'];expected=(launch['manager_start_utc_ticks']-621355968000000000)/1e7
    try:process=psutil.Process(pid)
    except psutil.NoSuchProcess:return
    if abs(process.create_time()-expected)>.01:raise RuntimeError('Parent PID reused')
    if str(Path(launch['manager_script'])).lower() not in ' '.join(process.cmdline()).lower():
        raise RuntimeError('Parent command mismatch')
    kernel=ctypes.WinDLL('kernel32',use_last_error=True)
    kernel.OpenProcess.argtypes=[ctypes.c_uint32,ctypes.c_int,ctypes.c_uint32];kernel.OpenProcess.restype=ctypes.c_void_p
    kernel.WaitForSingleObject.argtypes=[ctypes.c_void_p,ctypes.c_uint32];kernel.WaitForSingleObject.restype=ctypes.c_uint32
    kernel.CloseHandle.argtypes=[ctypes.c_void_p]
    handle=kernel.OpenProcess(0x00100000,False,pid)
    if not handle:
        if not psutil.pid_exists(pid):return
        raise OSError(ctypes.get_last_error(),'Parent wait handle failed')
    try:
        if not process.is_running():return
        if abs(process.create_time()-expected)>.01:raise RuntimeError('Parent identity changed')
        status(event='waiting_parent_process_exit',parent_pid=pid,model_wakeups=False,numerical_worker=False)
        if kernel.WaitForSingleObject(handle,0xFFFFFFFF)!=0:raise RuntimeError('Parent wait failed')
    finally:kernel.CloseHandle(handle)

def main():
    lock=HERE/'MANAGER.lock'
    with lock.open('x',encoding='utf-8') as f:json.dump(dict(pid=os.getpid(),at=now()),f)
    try:
        if (HERE/'COMPLETE.json').exists():status(event='already_completed');return
        policy=read(HERE/'PROTOCOL.json')
        for p,h in policy['code_sha256'].items():assert sha(p)==h,p
        wait_parent(read(ROOT/'LAUNCH.json'))
        parent=read(ROOT/'MANAGER_STATUS.json')
        if parent['event']!='finite_sampling_queue_completed' or not (ROOT/'FAIR_COMPLETE.json').exists():
            status(event='step_stopped_or_failed',parent_status=parent,automatic_retry=False,
                event_id=parent.get('event_id'),evidence_path=parent.get('evidence_path'));return
        guard(True)
        for n in ['STOP_REQUESTED','STOP_REQUESTED.json']:
            if (HERE/n).exists():raise InterruptedError('Follow-up stop')
        with (HERE/'worker.log').open('a',encoding='utf-8') as log:
            child=subprocess.Popen([sys.executable,'-u',str(HERE/'diagnose.py')],cwd=HERE,stdout=log,stderr=subprocess.STDOUT)
            status(event='step_process_started',worker_pid=child.pid)
            code=child.wait()
        if code:raise RuntimeError('Diagnostic worker exited '+str(code)+'; inspect worker.log')
        proof=HERE/'COMPLETE.json';assert proof.exists()
        eid=emit('needs_analysis',proof)
        status(event='finite_sampling_queue_completed',event_id=eid,evidence_path=str(proof))
    except InterruptedError as exc:
        status(event='user_stop',classification='user_stop',error=repr(exc))
    except Exception as exc:
        proof=HERE/'FAILURE.json';write(proof,dict(at=now(),error=repr(exc),traceback=traceback.format_exc(),automatic_retry=False))
        eid=emit('blocking_failure',proof)
        status(event='sampling_blocking_failure',event_id=eid,evidence_path=str(proof))
    finally:
        if read(lock).get('pid')==os.getpid():lock.unlink()

if __name__=='__main__':main()
