from common import *

def main():
    with gate.exclusive('V11 no-fit conditional decision audit'):
        np,lim=gate.runtime(False);verify();import modelmath as mm
        with np.load(A4/'panel.npz') as z:states=z['states'];days=z['days']
        records=[]
        for seed in SEEDS:
            with np.load(ART/f'matrix/{seed}.npz') as z:d={k:z[k] for k in z.files}
            st=states[d['origin_index'],d['node'],d['horizon']]
            for fold in (1,2,3):
                obj=load(ART/f'fits/{seed}_{fold}.pkl');ei=obj['evaluation_rows'];g=obj['guard']
                est=mm.predict(g['model'],d['X'][ei])+g['bias'];upper=mm.upper(g,d['X'][ei]);row=dict(seed=seed,fold=fold,partitions={})
                for part,ii in [('fit',obj['fit_rows']),('calibration',obj['calibration_rows']),('evaluation',ei)]:
                    pp={}
                    for state in (3,4,5):
                        jj=ii[st[ii]==state]
                        if not len(jj):pp[str(state)]=dict(cells=0);continue
                        e=d['experts'][jj]-d['truth'][jj,None]
                        pp[str(state)]=dict(cells=len(jj),dates=len(np.unique(d['days'][jj])),MAE=np.abs(e).mean(0).tolist(),RMSE=np.sqrt((e*e).mean(0)).tolist())
                    row['partitions'][part]=pp
                for state in (3,4,5):
                    sel=st[ei]==state
                    row['partitions']['evaluation'][str(state)].update(FULL_predicted_dual_advantage=int(np.sum((est[sel,:2]<0).all(1))),FULL_guarded_dual_advantage=int(np.sum((upper[sel,:2]<0).all(1))),V10_predicted_dual_advantage=int(np.sum((est[sel,2:]<0).all(1))),V10_guarded_dual_advantage=int(np.sum((upper[sel,2:]<0).all(1))))
                records.append(row)
        write(HERE/'POST_DIAGNOSIS.json',dict(at=gate.now(),status='no_fit_conditional_error_audit_complete',expert_order=['FULL','V7','V10'],records=records,new_test_targets_read=False,new_training=False,not_used_to_change_candidate=True))
        print('No-fit conditional diagnosis saved')
if __name__=='__main__':main()
