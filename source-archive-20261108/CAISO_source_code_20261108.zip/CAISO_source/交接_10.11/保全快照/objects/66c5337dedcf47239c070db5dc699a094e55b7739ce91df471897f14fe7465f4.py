"""Bounded, restartable caches from a newly trained, frozen as-of backbone only."""
from pathlib import Path
import uuid
import film_runtime as f

NAMES=('positions','sizes','z','native','weights','age','truth','mask','codes','multiplicity','origins','years')


def load(folder,part,identity=None):
    if part not in ('train','inner'):raise ValueError('FiLM caches are TRAIN/June only')
    receipt=f.read(folder/'cache'/part/'commit.json')
    if identity is not None and receipt['identity']!=identity:raise RuntimeError('Wrong new FiLM cache case')
    directory=f.inside(receipt['data_directory'])
    if not directory.is_relative_to(folder/'cache'/part):raise RuntimeError('Cache directory escape')
    if f.sha(directory/'commit.json')!=receipt['data_commit_sha256']:raise RuntimeError('Cache commit changed')
    f.check_commit(directory,identity)
    return dict(folder=directory,metadata=f.read(directory/'metadata.json'),
                **{name:f.np.load(directory/(name+'.npy'),mmap_mode='r',allow_pickle=False) for name in NAMES})


def close(cache):
    for value in cache.values():
        if isinstance(value,f.np.memmap):value._mmap.close()


def plan(data,part):
    np=f.np
    if part=='train':
        all_rows=np.concatenate([np.load(data.paths[f'epoch{i}_origins.npy'],allow_pickle=False) for i in range(1,7)])
        origins,multiplicity=np.unique(all_rows,return_counts=True)
        if np.any(origins+12>data.manifest['train_target_stop_exclusive']):raise RuntimeError('TRAIN phase escaped cutoff')
        data.origins['train']=origins
        return 'train',np.arange(len(origins),dtype=np.int64),multiplicity
    dense=data.origins['june_dense'];registered=data.origins['june']
    if (np.any(np.diff(dense)<=0) or not np.isin(registered,dense).all() or
        np.any(dense<data.manifest['train_target_stop_exclusive']) or np.any(dense+12>data.manifest['june_target_stop_exclusive'])):
        raise RuntimeError('June coverage/order/cutoff changed')
    positions=np.r_[np.searchsorted(dense,registered),np.flatnonzero(~np.isin(dense,registered))]
    return 'june_dense',positions,np.ones(len(dense),np.int64)


def build_part(folder,part,identity,data,model):
    np,torch=f.np,f.torch
    import film_math as math
    target=folder/'cache'/part
    if (target/'commit.json').exists():
        cache=load(folder,part,identity);close(cache);return
    data_part,positions,multiplicity=plan(data,part)
    thresholds=f.read(data.paths['state_thresholds.json'])
    if thresholds['quantiles']!=[.9,.99]:raise RuntimeError('Actual q90/q99 definitions required')
    q=np.asarray(thresholds['thresholds'],np.float64)
    if not np.array_equal(np.asarray(thresholds['center']),data.center):raise RuntimeError('State/scaler center mismatch')
    state_hash=f.fingerprint(model);rng=torch.get_rng_state().clone();chunks=[]
    for start in range(0,len(positions),64):
        f.boundary(folder,True)
        stop=min(start+64,len(positions));selected=target/'chunks'/f'{start:06d}'/'selected.json'
        if selected.exists():
            row=f.read(selected);directory=f.inside(row['directory'])
            if (not directory.is_relative_to(selected.parent) or
                row['commit_sha256']!=f.sha(directory/'commit.json')):raise RuntimeError('Chunk pointer changed')
            f.check_commit(directory,identity);chunks.append(directory);continue
        directory=selected.parent/('attempt_'+uuid.uuid4().hex)
        collected={name:[] for name in NAMES}
        with torch.no_grad():
            for offset in range(start,stop,4):
                f.boundary(folder)
                ids=positions[offset:min(offset+4,stop)]
                x,y=data.batch(data_part,ids)
                x=torch.from_numpy(x)
                scale=torch.tensor(data.scale,dtype=torch.float64)
                center=torch.tensor(data.center,dtype=torch.float64)
                quant=torch.tensor(q,dtype=torch.float64)
                mask=math.active(x,scale,center,quant[1]).numpy()
                if part=='train' and not mask.any():continue
                result=model(x);truth=y.astype(np.float64)*data.scale[None,:,None]+data.center[None,:,None]
                distance=abs(truth-data.center[None,:,None])
                codes=3*mask[:,:,None].astype(np.uint8)+(distance>q[0][None,:,None]).astype(np.uint8)+(distance>q[1][None,:,None]).astype(np.uint8)
                origins=data.origins[data_part][ids]
                values=dict(positions=ids,sizes=np.array([len(ids)],np.int64),z=result['head_features'].numpy(),
                    native=result['prediction'].numpy().astype(np.float64)*data.scale[None,:,None]+data.center[None,:,None],
                    weights=result['branch_weights'].numpy(),age=math.age_features(x,scale,center,quant).numpy(),
                    truth=truth,mask=mask,codes=codes,multiplicity=multiplicity[ids],origins=origins,
                    years=math.years_from_ns(data.times[origins]*10**9))
                for name,value in values.items():collected[name].append(value)
        shapes={'positions':(0,),'sizes':(0,),'z':(0,30,12,32),'native':(0,30,12),'weights':(0,30,12,2),
                'age':(0,30,2),'truth':(0,30,12),'mask':(0,30),'codes':(0,30,12),
                'multiplicity':(0,),'origins':(0,),'years':(0,)}
        dtypes={'positions':np.int64,'sizes':np.int64,'z':np.float32,'native':np.float64,
                'weights':np.float32,'age':np.float32,'truth':np.float64,'mask':np.bool_,
                'codes':np.uint8,'multiplicity':np.int64,'origins':np.int64,'years':np.int16}
        for name in NAMES:
            values=np.concatenate(collected[name]) if collected[name] else np.empty(shapes[name],dtypes[name])
            f.array(directory/(name+'.npy'),values)
        f.write(directory/'scope.json',dict(start=start,stop=stop,part=part,retained_origins=sum(len(v) for v in collected['origins'])))
        f.commit(directory,identity)
        f.write(selected,dict(directory=str(directory),commit_sha256=f.sha(directory/'commit.json')))
        chunks.append(directory)
    if f.fingerprint(model)!=state_hash or not torch.equal(rng,torch.get_rng_state()):
        raise RuntimeError('Cache computation altered the frozen backbone or global Torch RNG')
    output=target/('values_'+uuid.uuid4().hex);output.mkdir(parents=True)
    # Concatenation writes bounded slices, including retained original batch sizes.
    for name in NAMES:
        f.boundary(folder,True)
        samples=[np.load(p/(name+'.npy'),mmap_mode='r',allow_pickle=False) for p in chunks]
        total=sum(len(v) for v in samples);shape=(total,)+samples[0].shape[1:]
        destination=np.lib.format.open_memmap(output/(name+'.npy'),mode='w+',dtype=samples[0].dtype,shape=shape)
        offset=0
        for value in samples:
            f.boundary(folder)
            destination[offset:offset+len(value)]=value;offset+=len(value);value._mmap.close()
        destination.flush();destination._mmap.close()
    cache=dict(folder=output,**{name:np.load(output/(name+'.npy'),mmap_mode='r',allow_pickle=False) for name in NAMES})
    try:
        if len(cache['z'])==0 or int(cache['sizes'].sum())!=len(cache['z']):raise RuntimeError('Empty/inconsistent retained FiLM cache')
        metadata=dict(identity=identity,part=part,total_origins=len(positions),retained_origins=len(cache['origins']),
            scale=data.scale.tolist(),center=data.center.tolist(),q=q.tolist(),quantiles=[.9,.99],prefix_stop=data.manifest['prefix_stop'],
            original_batch_size=4,chunk_origins=64,train_skip_rule='only batches with no active historical node' if part=='train' else 'none',
            old_weights_or_normalizer_reused=False,years=np.unique(cache['years']).tolist(),
            registered_june_first=part=='inner',registered_june_count=len(data.origins['june']) if part=='inner' else None,
            source_chunks=[dict(path=str(p),sha256=f.sha(p/'commit.json')) for p in chunks])
        cache['metadata']=metadata
        if part=='train':
            mean,std,total=math.normalizer(cache)
            f.array(output/'normalizer_mean.npy',mean);f.array(output/'normalizer_std.npy',std)
            counts=np.array([count for _,_,count in math.masks(cache)])
            if len(counts)!=36 or (counts<=0).any():raise RuntimeError('New retained cache lacks an original risk task')
            f.write(output/'normalizer.json',dict(total_weight=total,scope='active TRAIN node-horizon features weighted by actual six-phase multiplicity',
                data_identity=identity,mean_sha256=f.sha(output/'normalizer_mean.npy'),std_sha256=f.sha(output/'normalizer_std.npy'),
                risk_counts=counts.tolist(),risk_order=[list(t) for t in math.TASKS],old_normalizer_reused=False))
        else:
            ref=identity['dense_evaluation'];native_path=f.inside(ref['path'])
            if f.sha(native_path)!=ref['sha256']:raise RuntimeError('Parent dense predictions changed')
            with np.load(native_path,allow_pickle=False) as saved:
                for start in range(0,len(cache['origins']),64):
                    ids=cache['positions'][start:start+64]
                    if not (np.array_equal(cache['origins'][start:start+64],saved['origins'][ids]) and
                            np.array_equal(cache['native'][start:start+64],saved['prediction'][ids]) and
                            np.array_equal(cache['truth'][start:start+64],saved['truth'][ids]) and
                            np.array_equal(cache['codes'][start:start+64],saved['codes'][ids])):
                        raise RuntimeError('Full parent dense population or predictions differ')
            metadata['registered_june_native_replay_exact']=True
            metadata['entire_dense_parent_replay_exact']=True
        f.write(output/'metadata.json',metadata);f.commit(output,identity)
    finally:close(cache)
    f.write(target/'commit.json',dict(status='committed',identity=identity,data_directory=str(output),data_commit_sha256=f.sha(output/'commit.json')))


def build(seed,variant):
    identity=f.admission(seed,variant);folder=f.stage(seed,variant)
    with f.exclusive('asof_film_cache',folder):
        runtime,limiter=f.numeric()
        from compiled_data import CompiledData
        data=CompiledData(identity['dataset_manifest']);model=f.frozen_backbone(identity,data)
        try:
            for part in ('train','inner'):build_part(folder,part,identity,data,model)
        except f.StopRequested as exc:
            row=dict(status='cache_stopped_at_batch_boundary',reason=str(exc),identity=identity,training_updates=0)
            f.write(folder/'events'/f'cache_stop_{uuid.uuid4().hex}.json',row);return row
        commits={part:f.sha(folder/'cache'/part/'commit.json') for part in ('train','inner')}
        result=dict(status='film_caches_completed_pending_independent_audit',identity=identity,cache_commits=commits,
                    runtime=runtime,training_updates=0,Q3_targets_read=False,test_2026_targets_read=False)
        path=folder/'cache_completion.json'
        if path.exists():
            if f.read(path)!=result:raise RuntimeError('Immutable FiLM cache completion changed')
        else:f.write(path,result)
        return result
