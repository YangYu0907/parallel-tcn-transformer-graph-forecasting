"""Synthetic math, interface and exact-resume checks; no real market arrays read."""
import copy,gc,json,random
import gate,runner
def main():
    # Verify inherited ORIGINAL and sampling audits/seals with metadata only.
    inherited=runner.original_admission(runner.base.policy_manifest('ADDITIVE'),'FULL',20260813)
    gate.need(inherited['total_updates']==6048,'Inherited budget')
    sources=runner.base.source_paths()
    for p in sorted(gate.HERE.glob('*.py')):sources[gate.rel(p)]=gate.sha(p);compile(p.read_text(encoding='utf-8'),str(p),'exec')
    sources[gate.rel(gate.HERE/'PROTOCOL.json')]=gate.sha(gate.HERE/'PROTOCOL.json')
    sources[gate.rel(gate.HERE/'watch_manager_exit.ps1')]=gate.sha(gate.HERE/'watch_manager_exit.ps1')
    checks=[];counts={}
    with gate.exclusive('synthetic_additive_mechanism_QA'):
        np,torch,limiter=gate.runtime(True);runner.base.np=np;runner.base.torch=torch
        from models.factory import build_backbone
        from models.component_controls import FusionAblation,explicit_forward,inactive_name
        limits=[[2.,3.] for _ in range(30)]
        generator=torch.Generator().manual_seed(82134)
        x=torch.randn((4,288,30,29),generator=generator);y=torch.randn((4,30,12),generator=generator)
        for seed in (20260813,20260814):
            full=build_backbone('FULL',seed,limits).eval()
            clone=FusionAblation('FULL',seed,limits).eval()
            gate.need(torch.equal(full(x)['prediction'],clone(x)['prediction']),'FULL formula changed')
            checks.append('FULL_formula_exact_'+str(seed));del clone
            fullstate=full.state_dict()
            for mode in ('GLOBAL','SELF'):
                model=build_backbone(mode,seed,limits)
                gate.need(set(model.state_dict())==set(fullstate) and all(torch.equal(v,fullstate[k]) for k,v in model.state_dict().items()),'Shared initialization differs')
                total=sum(p.numel() for p in model.parameters());active=sum(p.numel() for p in model.parameters() if p.requires_grad)
                gate.need(total==sum(p.numel() for p in full.parameters()),'Stored parameter count')
                frozen={k:v.clone() for k,v in model.named_parameters() if not v.requires_grad}
                gate.need(set(frozen)=={k for k,v in model.named_parameters() if inactive_name(mode,k)},'Inactive mask differs')
                model.eval()
                with torch.inference_mode():
                    out=model(x);p,f,a=explicit_forward(model,x)
                    gate.need(torch.allclose(p,out['prediction'],rtol=0,atol=1e-7),'Explicit prediction formula')
                    gate.need(torch.allclose(f,out['fused_features'],rtol=0,atol=1e-7),'Explicit fusion formula')
                    if mode=='SELF':gate.need(torch.equal(a,torch.eye(30).expand(4,-1,-1)),'SELF identity adjacency')
                    else:
                        expected=model.attention.branch_bias.softmax(-1).expand(4,30,12,2)
                        gate.need(torch.equal(out['branch_weights'],expected),'GLOBAL constant learned weights')
                counts[str(seed)+'_'+mode]=dict(total=total,active=active,frozen=total-active)
                checks.extend(['shared_initial_state_'+str(seed)+'_'+mode,'independent_formula_'+str(seed)+'_'+mode])
                model.train();opt=runner.base.optimizer(model);scheduler=runner.base.EpochCosine(opt);scheduler.set_epoch(1)
                rng=np.random.default_rng(seed);torch.manual_seed(seed+200000);np.random.seed(seed);random.seed(seed)
                # Same 4032-slot order; verify restoration of all RNGs and complete optimizer tensors.
                order=rng.permutation(4032)
                gate.need(np.array_equal(order,np.random.default_rng(seed).permutation(4032)),'Matched slot order')
                runner.base.update(model,opt,x,y)
                identity={'synthetic':True};runtime={'synthetic':True};state={'phase':'train','epoch':1,'steps':1,'offset':4,'order':order}
                saved=runner.base.payload(model,opt,scheduler,rng,identity,runtime,state)
                def steps(m,o,r):
                    for _ in range(2):
                        r.permutation(17);runner.base.update(m,o,x,y)
                steps(model,opt,rng);gold=copy.deepcopy(model.state_dict());goldopt=copy.deepcopy(opt.state_dict());goldrng=runner.base.rng_state(rng)
                restored=build_backbone(mode,seed,limits);ro=runner.base.optimizer(restored);rs=runner.base.EpochCosine(ro);rr=np.random.default_rng(1)
                got=runner.base.restore(saved,restored,ro,rs,rr,identity,runtime)
                gate.need(got['steps']==1 and np.array_equal(got['order'],order),'Restored cursor')
                steps(restored,ro,rr)
                gate.need(all(torch.equal(v,restored.state_dict()[k]) for k,v in gold.items()),'Resume parameters not exact')
                for key,value in goldopt['state'].items():
                    for field,v in value.items():gate.need(torch.equal(v,ro.state_dict()['state'][key][field]),'Resume Adam tensors')
                gate.need(torch.equal(torch.get_rng_state(),goldrng['torch']) and rr.bit_generator.state==goldrng['numpy_generator'],'Resume RNG')
                gate.need(all(torch.equal(v,restored.state_dict()[k]) for k,v in frozen.items()),'Inactive parameter drift')
                checks.extend(['active_gradients_and_frozen_tensors_'+str(seed)+'_'+mode,'exact_RNG_optimizer_resume_'+str(seed)+'_'+mode])
                del model,restored,opt,ro;gc.collect()
            del full;gc.collect()
        # Output namespace checks do not open any old-output file.
        try:gate.atomic(gate.ROOT/'runs/forbidden_qa_write.json',lambda f:f.write(b'x'))
        except RuntimeError:checks.append('old_output_write_rejected_before_open')
        else:raise RuntimeError('Output escape accepted')
        original=gate.boundary
        def paused():raise InterruptedError('synthetic local pause')
        gate.boundary=paused
        try:gate.need(runner.stop_reason(gate.HERE)=='synthetic local pause','New namespace pause ignored')
        finally:gate.boundary=original
        checks.append('new_namespace_stop_propagates')
        gate.need(runner.run_directory('ADDITIVE','GLOBAL',20260813)==gate.HERE/'runs/20260813_GLOBAL','Run route')
        gate.need(runner.run_directory('ADDITIVE','FULL',20260813)==runner.original_directory('ADDITIVE','FULL',20260813),'Inherited metadata route')
        checks.append('control_output_and_parent_metadata_routes_separate')
        # Existing independent reduction oracle checked on arbitrary errors.
        import reductions as producer
        oracle=gate.load('new_control_scalar_oracle',gate.HERE/'numeric_audit.py');oracle.np=np
        err=np.linspace(-4,5,24*30*12).reshape(24,30,12);states=(np.arange(err.size)%6).reshape(err.shape);origins=np.arange(120,144)
        oracle.compare(producer.breakdown(err,states,origins),oracle.oracle_breakdown(err,states,origins))
        checks.append('vectorized_metrics_against_scalar_fsum_oracle')
    gate.write(gate.HERE/'synthetic_qa.json',dict(status='passed',at=gate.now(),checks=checks,counts=counts,sources=sources,
        inherited_admission=inherited,real_market_arrays_read=False,heldout_targets_read=False,review_independence='Same operator; distinct formula/reduction oracles.'))
    print(json.dumps(dict(status='passed',checks=len(checks),parameters=counts)))
if __name__=='__main__':main()
