"""Metadata and resource gates for matched fixed-budget continuation."""
from pathlib import Path
from contextlib import contextmanager
from datetime import datetime,timezone
import hashlib,json,os,sys,uuid
HERE=Path(__file__).resolve().parent;ROOT=HERE.parent
COMMON=ROOT/'common_sampling_evaluation_20260923'
V=ROOT/'phase_sampling_support_v3_20260923'
SEAL=HERE/'EXECUTION_LOCK.json'
LOCK=Path('D:/Desktop/数据科学_论文/研究优化_20260818/logs/NEURAL_RUN.lock')
sys.path.insert(1,str(ROOT/'source'))
import compile_gate as cg
def now():return datetime.now(timezone.utc).isoformat()
def read(p):return json.loads(Path(p).read_text(encoding='utf-8-sig'))
def need(x,m):
    if not x:raise RuntimeError(m)
def inside(p):
    p=Path(p);p=(ROOT/p if not p.is_absolute() else p).resolve()
    need(p.is_relative_to(ROOT),'Path outside branch');return p
def rel(p):return str(inside(p).relative_to(ROOT))
def sha(p):
    h=hashlib.sha256()
    with Path(p).open('rb') as f:
        for x in iter(lambda:f.read(1048576),b''):h.update(x)
    return h.hexdigest()
def atomic(p,writer,replace=False):
    p=inside(p);p.parent.mkdir(parents=True,exist_ok=True)
    t=p.with_name('t_'+uuid.uuid4().hex+'.pending')
    with t.open('xb') as f:writer(f);f.flush();os.fsync(f.fileno())
    if replace:os.replace(t,p)
    else:t.rename(p)
def write(p,v,replace=False):
    raw=json.dumps(v,ensure_ascii=False,allow_nan=False,indent=2).encode()
    atomic(p,lambda f:f.write(raw),replace)
def boundary():
    for folder in (ROOT,HERE,HERE/'queue',V,COMMON):
        for name in ('STOP_REQUESTED','STOP_REQUESTED.json'):
            if (folder/name).exists():raise InterruptedError('User stop '+str(folder/name))
    p=read(ROOT.parent/'RESEARCH_PAUSED.json')
    if p.get('status')!='resumed_by_user' or p.get('stop_preparation_and_training'):raise InterruptedError('Research paused')
def guard(launch=False):
    boundary();r=cg.resources();floor=5 if launch else 4
    if min(r.values())<floor:raise MemoryError(f'Continuation needs {floor}GiB physical+commit; actual {r}')
    return r
@contextmanager
def exclusive(action):
    guard(True)
    import psutil
    o=dict(pid=os.getpid(),created=psutil.Process().create_time(),token=uuid.uuid4().hex,action=action)
    with LOCK.open('x',encoding='utf-8') as f:json.dump(o,f);f.flush();os.fsync(f.fileno())
    try:cg.bound_process();guard();yield
    finally:
        need(read(LOCK)==o,'Lock owner changed');write(HERE/'lock_releases'/(o['token']+'.json'),dict(owner=o,at=now()));LOCK.unlink()
def runtime(torch_needed=True):
    cg.bound_process()
    import numpy as np
    from threadpoolctl import threadpool_limits,threadpool_info
    lim=threadpool_limits(1)
    need(all(x['num_threads']==1 for x in threadpool_info()),'Numerical thread limit')
    if torch_needed:
        import torch
        torch.set_num_threads(1);torch.set_num_interop_threads(1);torch.use_deterministic_algorithms(True)
        guard();return np,torch,lim
    guard();return np,lim

def load(name,path):
 import importlib.util
 spec=importlib.util.spec_from_file_location(name,path);m=importlib.util.module_from_spec(spec);spec.loader.exec_module(m);return m

PARENT=ROOT/'budget_mechanisms_v1_20260925'
VARIANTS=('FULL','EQUAL','CONCAT')
def prepared_cases():
 cases=[]
 for seed in (20260813,20260814,20260815):
  for variant in VARIANTS:
   folder=ROOT/('budget_extension_v1_20260925' if variant=='FULL' else 'budget_mechanisms_v1_20260925')/'runs'/f'{seed}_{variant}'
   r=read(folder/'completion.json');a=read(folder/'audit.json')
   need(a['status']=='passed' and a['completion_sha256']==sha(folder/'completion.json'),'Missing parent audit')
   parent=dict(selected_checkpoint=r['selected_checkpoint'],selected_epoch=r['selected_epoch'],
    identity=r['identity'] if r['selected_epoch']>6 else r['identity']['case']['parent']['identity'],
    scope='budget_extension_backbone_only' if r['selected_epoch']>6 else 'backbone_only',
    dense_evaluation=r['dense_evaluation'],panels=r['panels'],completion=rel(folder/'completion.json'))
   cases.append(dict(id=f'{seed}_{variant}',seed=seed,variant=variant,parent=parent))
 return cases
def verify():
 boundary();s=read(SEAL)
 need(s['status']=='sealed_nine_branch_value_trials','Unsealed value trial')
 need([(c['seed'],c['variant']) for c in s['cases']]==[(seed,v) for seed in (20260813,20260814,20260815) for v in VARIANTS],'Case scope changed')
 for p,h in s['bindings'].items():need(sha(inside(p))==h,'Sealed artifact changed '+p)
 return s
def seal():
 boundary();need(not SEAL.exists(),'Seal exists');bindings={}
 def bind(p,h=None):
  p=inside(p);v=sha(p);need(h is None or v==h,'Changed input '+str(p));bindings[rel(p)]=v
  return read(p) if p.suffix=='.json' else v
 old=bind(PARENT/'EXECUTION_LOCK.json','0692a778acc2f1af9e9f2888d352f87b6c6ed42b6294f89e96320d6ec957cb9f')
 for p,h in old['bindings'].items():bind(p,h)
 done=bind(PARENT/'queue/completion.json','ff31931aa90ba5c5cf954708fc166592fe044924f79a05508ad8cdda3c93e8c5')
 bind(PARENT/'summary.json',done['summary_sha256'])
 for n,h in done['receipts'].items():
  r=bind(PARENT/'queue/steps'/n,h);need(r['exit_code']==0,'Prior exit');bind(r['marker'],r['marker_sha256'])
 for c in old['cases']:
  a=bind(PARENT/'runs'/c['id']/'audit.json');need(a['status']=='passed','Prior case audit')
  for p,h in a['output_bindings'].items():bind(p,h)
 diag=ROOT/'branch_fusion_diagnostic_20260925'
 for n in ('diagnostic.py','PROTOCOL.json','PROBE_LOCK.json','result.json','audit.json'):bind(diag/n)
 a=read(diag/'audit.json');need(a['status']=='passed' and a['result_sha256']==sha(diag/'result.json'),'Probe audit')
 for p,h in a['output_bindings'].items():bind(p,h)
 bind(ROOT/'audits/budget_mechanisms_completion_verified_20260925.json')
 cases=prepared_cases()
 for c in cases:
  p=inside(c['parent']['selected_checkpoint']);rr=bind(p.with_suffix('.receipt.json'));bind(p,rr['sha256'])
  bind(c['parent']['completion']);rr=c['parent']['dense_evaluation'];bind(rr['path'],rr['sha256'])
 for p in HERE.glob('*.py'):compile(p.read_text(encoding='utf-8'),str(p),'exec');bind(p)
 for n in ('PROTOCOL.json','launch_reviewed.ps1','watch_manager_exit.ps1','qa.json','source_review.json'):bind(HERE/n)
 qa=read(HERE/'qa.json');review=read(HERE/'source_review.json')
 need(qa['status']=='passed' and len(qa['cases'])==9 and review['status']=='passed' and review['qa_sha256']==sha(HERE/'qa.json'),'QA/review missing')
 for p,h in qa['sources'].items():bind(p,h)
 for p,h in review['sources'].items():bind(p,h)
 write(SEAL,dict(status='sealed_nine_branch_value_trials',at=now(),cases=cases,bindings=bindings,
  dataset_manifest=old['dataset_manifest'],train_diagnostic=old['train_diagnostic'],heldout_targets_read=False,complete_research_experiment=False))
 print(json.dumps(dict(status='sealed_nine_branch_value_trials',cases=9,bindings=len(bindings),sha256=sha(SEAL))))
if __name__=='__main__':
 if sys.argv[1]=='seal':seal()
 else:
  s=verify();need(not LOCK.exists(),'Numerical worker active');print(json.dumps(dict(status='passed',cases=9,resources=guard(True))))
