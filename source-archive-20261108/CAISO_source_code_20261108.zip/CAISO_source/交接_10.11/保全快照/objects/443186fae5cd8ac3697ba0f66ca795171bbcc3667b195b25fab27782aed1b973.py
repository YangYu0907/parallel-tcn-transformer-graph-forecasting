from common import *
import traceback,psutil
def status(**kw):write(E/'STATUS.json',dict(at=now(),pid=os.getpid(),**kw))
def main():
 start=time.monotonic();lock=E/'MANAGER.lock'
 with lock.open('x') as f:json.dump(dict(pid=os.getpid()),f)
 try:
  p=verify();guard(True);status(event='awaiting_exit_monitor_binding')
  while not (E/'START_READY.json').exists():
   if time.monotonic()-start>55:raise TimeoutError('Exit monitor missing')
   time.sleep(.2)
  ready=read(E/'START_READY.json');assert ready['manager_pid']==os.getpid()
  assert abs((ready['manager_start_utc_ticks']-621355968000000000)/1e7-psutil.Process().create_time())<.01
  receipt=read(ready['receipt']);assert receipt['manager_pid']==os.getpid() and receipt['watcher_pid']==ready['exit_monitor_pid']
  assert psutil.pid_exists(ready['exit_monitor_pid'])
  def tick(**kw):
   resources=guard();info=psutil.Process().memory_info()
   write(E/'PROGRESS.json',dict(at=now(),pid=os.getpid(),elapsed_seconds=time.monotonic()-start,rss_MiB=info.rss/2**20,resources=resources,**kw))
  status(event='step_process_started',stage='weather_tendency')
  with s.base.numeric('Four fixed weather-tendency matched classifiers'):
   import experiment
   experiment.run(p,tick)
  result=read(E/'RESULT.json');eid=s.emit('audited_result_ready' if result['passed_promotion_gate'] else 'needs_analysis',E/'RESULT.json')
  status(event='finite_mechanism_queue_completed',event_id=eid,whole_research_completed=False,new_model_fits=4)
 except InterruptedError as ex:status(event='user_stop_at_stage_boundary',classification='user_stop',error=str(ex))
 except BaseException as ex:
  write(E/'FAILURE.json',dict(at=now(),error=repr(ex),traceback=traceback.format_exc(),V7_replaced=False,new_test_targets_read=False))
  eid=s.emit('blocking_failure',E/'FAILURE.json');status(event='step_stopped_or_failed',event_id=eid,error=repr(ex))
 finally:
  if lock.exists() and read(lock)['pid']==os.getpid():lock.unlink()
if __name__=='__main__':main()

