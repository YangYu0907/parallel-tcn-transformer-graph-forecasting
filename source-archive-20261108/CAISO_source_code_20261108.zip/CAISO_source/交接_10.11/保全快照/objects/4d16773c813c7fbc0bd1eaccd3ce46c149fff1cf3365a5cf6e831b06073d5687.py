"""Frozen comparison of six external fits with all eighteen completed primary fits."""
import json,statistics
import gate
METRICS=('mae','rmse','near_h1_4_mae','h12_mae')
PANELS=('June284','June3397','balanced278')
def main():
    seal=gate.verify_evaluation();result=gate.read(gate.HERE/'result.json')
    for name in ('numeric_audit.json','checkpoint_audit.json'):
        a=gate.read(gate.HERE/name)
        gate.need(a['status']=='passed' and a['result_sha256']==gate.sha(gate.HERE/'result.json'),'New output audit missing')
        for p,d in a.get('output_bindings',a.get('bindings',{})).items():gate.need(gate.sha(gate.inside(p))==d,'Audited output changed')
    previous=gate.read(gate.PARENT/'result.json')['results']
    previous += [x for x in gate.read(gate.COMMON/'result.json')['results'] if x['policy']=='ADDITIVE']
    previous += gate.read(gate.ROOT/'additive_mechanism_controls_v2_20260924/result.json')['results']
    gate.need(len(previous)==18 and len(result['results'])==6,'Incomplete panel')
    comparisons=[];checks=[];rows={}
    with gate.exclusive('matched_external_population_join'):
        np,limiter=gate.runtime(False);gold=None
        for r in previous+result['results']:
            k=(r['seed'],r['variant']);gate.need(k not in rows,'Duplicate case');rows[k]=r
            p=gate.inside(r['dense_receipt']);rec=gate.read(p);artifact=gate.inside(rec['artifact'])
            gate.need(gate.sha(artifact)==rec['artifact_sha256'],'Prediction changed')
            with np.load(artifact,allow_pickle=False) as z:current=tuple(z[k] for k in ('origins','truth','codes'))
            if gold is None:gold=current
            else:gate.need(all(np.array_equal(x,y) for x,y in zip(current,gold)),'Unequal labels/origins/codes')
            checks.append(dict(case=r['id'],receipt=gate.rel(p),sha256=gate.sha(p)))
        for seed in (20260813,20260814,20260815):
            for name in ('DLinear','iTransformer-H'):
                f=rows[(seed,'FULL')];r=rows[(seed,name)]
                panels={pn:{m:dict(full=f['panels'][pn][m],reference=r['panels'][pn][m],
                    reduction_percent=100*(1-f['panels'][pn][m]/r['panels'][pn][m])) for m in METRICS} for pn in PANELS}
                comparisons.append(dict(seed=seed,full=f['id'],reference=r['id'],panels=panels))
        means={v:{pn:{m:dict(mean=statistics.mean(rows[(s,v)]['panels'][pn][m] for s in (20260813,20260814,20260815)),
             sample_sd=statistics.stdev(rows[(s,v)]['panels'][pn][m] for s in (20260813,20260814,20260815))) for m in METRICS} for pn in PANELS}
             for v in ('FULL','TCN','EQUAL','CONCAT','GLOBAL','SELF','DLinear','iTransformer-H')}
    gate.write(gate.HERE/'summary.json',dict(status='matched_external_panel_audited',at=gate.now(),new_fits=6,reused_fits=18,
        comparisons=comparisons,mean_and_seed_dispersion=means,common_labels_origins_state_codes_exact=True,population_checks=checks,
        all_positive_negative_directions_preserved=True,model_selection_changed=False,
        scope='Fixed6048update historical-information backbone-stage comparison; not convergence or heldout confirmation.',
        budget_adequacy_requires_learning_curve_review=True,FiLM_QUERY_refinement_comparison_pending=True,
        heldout_targets_read=False,complete_research_experiment=False))
    print(json.dumps(dict(status='matched_external_panel_audited',cases=24)))
if __name__=='__main__':main()
