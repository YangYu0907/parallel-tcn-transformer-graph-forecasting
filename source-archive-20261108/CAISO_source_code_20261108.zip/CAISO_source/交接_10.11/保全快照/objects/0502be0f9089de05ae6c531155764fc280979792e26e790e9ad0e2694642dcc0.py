"""Render the completed evidence to a readable Chinese report; no numerical fitting."""
from pathlib import Path
import json,datetime
N=Path(__file__).resolve().parent
def read(name):return json.loads((N/name).read_text(encoding='utf-8-sig'))
def main():
    local=read('LOCAL_RESULT.json'); entry=read('ENTRY_RESULT.json'); latency=read('LATENCY.json'); audit=read('POSTRUN_REVIEW.json')
    lines=['图旁路与首次进入预警：本轮结果与归因', '生成时间：'+datetime.datetime.now().astimezone().isoformat(),'',
        '结论：有限试验及审核完成，新模块未获准并入 V7。V7 模型、预测及论文保留文件未改；没有读取新的测试目标，也没有排入新一轮训练。',
        '本轮完成 3 个种子的本地预测头、3 项首次进入概率模型和两种负载情境的原型计时。开发累计记录约 11.0 分钟，不含本报告及追加标签审核。', '',
        '一、本地通路：还不能替代 SELF',
        '比较范围：同一 June3397 已知开发面板，30 节点、12 步；先按 June284 选择检查点，再报告全部 June3397。下表为三个种子的指标均值，单位 USD/MWh。',
        '指标 | 冻结上下文＋新本地头 | 既有 SELF | 相对 SELF 的误差增加']
    for k,title in [('mae','总体 MAE'),('rmse','总体 RMSE'),('near_mae','5–20分钟 MAE'),('h12_mae','60分钟 MAE')]:
        a=local['mean']['local'][k];b=local['mean']['SELF'][k]
        lines.append(f'{title} | {a:.4f} | {b:.4f} | {(a/b-1)*100:.2f}%')
    lines.extend(['全部三个种子的总体 MAE 均高于 SELF。这里检验的是低成本本地通路能否达到现有参考精度，并非证明所有图旁路架构无效。',
        '实现事实：只训练 34→64→12 的新预测头；来自 FULL 的输入投影和 GRU 保持冻结。本地头没有 SELF 中独立训练的完整时间分支。',
        '待检验归因：冻结上下文是否保留了独立预测所需信息、丢失完整时间表征是否形成瓶颈、有限优化预算是否充分，目前不能分开归因。不得据此直接增加轮次直到开发面板变好。',
        '“本地”指绕过学习到的图传播，输入仍包括原契约中的系统及派生变量，不能称为纯本节点价格模型。', '',
        '二、首次进入：风险函数有积极信号，邻居信息尚无总体增益',
        '比较范围：既有 TRAIN 内按日期划分的历史开发诊断，60/20/20 划分及 2 天清除边界；评估 38,436 个起点-节点对。三个风险模型是固定三项对照，不是三个随机种子。既有事件阈值沿用原 TRAIN 定义，因此不称为新独立测试。',
        '60分钟、上涨/下跌两类的简单宏平均（Brier 和 logloss 越低越好）：',
        '模型 | Brier | logloss | Recall | FPR'])
    labels={'LOCAL_HAZARD':'本地逐步风险','CROSS_HAZARD':'邻居增强逐步风险','CROSS_ENDPOINT':'邻居增强累计事件概率对照'}
    for name,d in entry['H12_mean'].items():lines.append(f"{labels[name]} | {d['brier']:.8f} | {d['logloss']:.8f} | {d['recall']:.2%} | {d['FPR']:.2%}")
    lines.extend(['CROSS_ENDPOINT 的历史文件名易引起误解：它预测的是“预测期内是否首次进入”，不是“期末价格是否处于极端”。本报告未改动冻结代码及结果文件名。',
        '邻居增强逐步风险相比累计事件对照：Brier 降低 9.80%，logloss 降低 11.16%。但其 Brier 比本地逐步风险高 1.24%，Recall 也较低。上述仅为开发观察，未宣称统计显著或价格误差改善。',
        '邻居增强逐步风险的 60 分钟分方向结果：',
        '方向 | 事件对数/日期数 | 告警数 | 命中数 | 误报数 | Precision | Recall | FPR'])
    for r in entry['rows']:
        if r['arm']=='CROSS_HAZARD' and r['horizon']==12:
            lines.append(f"{'上涨' if r['side']==1 else '下跌'} | {r['events']}/{r['event_dates']} | {r['alerts']} | {r['TP']} | {r['FP']} | {r['precision']:.2%} | {r['recall']:.2%} | {r['FPR']:.2%}")
    lines.extend(['具体症结：FPR 低于 2% 不代表告警可靠。下跌事件只有 41 个起点-节点对，14 次正确告警伴随 739 次误报，尚不适合据此进行非零价格修正。事件对数存在跨节点相关性，不能视作 41 次独立冲击。',
        '邻居特征在上涨类别的 AP 为 0.1681，本地为 0.1497；排序信号和校准后的概率质量不是同一件事。不能将 AP 上升直接解释成安全路由收益。',
        '追加描述性频率核查：上涨首次进入频率从拟合段 1.1809% 变为校准段 0.4876%、评估段 0.8247%；下跌为 0.1160%、0.0265%、0.1067%。这显示样本频率变化，但不足以单独证明概念漂移是全部原因。',
        '本次没有训练 KNN 幅度修正或联合门控；警报准确率不足时，不借助修正幅度或阈值搜索掩盖问题。', '',
        '三、计算代价与核验', '路径 | 中位数 ms | P99 ms | 最大值 ms'])
    for r in latency['rows']:lines.append(f"{r['scenario']} | {r['median_ms']:.2f} | {r['p99_ms']:.2f} | {r['max_ms']:.2f}")
    lines.extend(['每种情境 5 次预热、300 次重复，单线程 Batch 1。计时包括真实 V7 专家、准备好的输入快照复制、本地头、派生特征、风险模型计算和自然频率历史库 KNN；新预警模型及未来曲线使用计算负荷替身。',
        '未包含在线网络取数、来源刷新和完整输入物化；不是最终训练系统的全链路时延，也不是最坏时延保证。没有启用图计算跳过。',
        f"标签追加审核：从原始历史价格复算 {audit['first_crossing_labels_verified']:,} 对的首次越界时点与方向，差异为 {audit['label_errors']}。分别复核已存预测误差、风险计数、验收条件和时间划分。",
        '18 个受保护文件哈希未变。审核由另一份脚本复算，但仍在同一环境执行，不能称为外部独立复现。', '',
        '四、下一步与停止条件',
        '1. 本轮未通过接入条件，已关闭本候选的联合训练入口。V7 继续作为默认系统，原 TCN、Transformer、动态图 GNN、并行结构及自适应融合均保留。',
        '2. 图旁路若继续，应针对“冻结表征是否限制本地预测”做一项匹配检验：保留 FULL，复制并独立监督本地时间编码器，对照本轮冻结编码器。先查历史登记避免重复；不得把该建议说成已经运行或一定有效。收益可能来自本地表征更适合预测，代价是额外训练和推理。',
        '3. 首次进入优先补来源信息：已查看的 RTD/DAM 文件没有行级发布时间或版本标识，既有历史输入审核也未提供发布方值版本哈希。需要外部版本台账把完整未来曲线与当时截止时点绑定，不能把目标交割时间或下载时间当作发布时间。',
        '4. 通过信息准入后，才检验前瞻输入的增量；所有对照必须获得相同新输入。概率质量合格后，路由依据时间样本外的真实修正收益学习，分别约束上涨、下跌和常规状态，不以区间宽度代替预期收益。',
        '5. 联合模型及全部输入冻结、真正独立时期准入后才允许最终确认。当前没有取得“全指标改善”的证据；仅凭架构、风险概率或旧开发面板均不能保证该目标。', '',
        '理论依据与边界：',
        'Lim et al. Temporal Fusion Transformers for interpretable multi-horizon time series forecasting. International Journal of Forecasting 2021. https://doi.org/10.1016/j.ijforecast.2021.03.012',
        '该论文支持已知未来输入、可训练时间表征和选择性门控的设计动机，不保证本次冻结上下文方案达到 SELF。',
        'Lee et al. DeepHit: A Deep Learning Approach to Survival Analysis With Competing Risks. AAAI 2018. https://ojs.aaai.org/index.php/AAAI/article/view/11842',
        '该论文支持显式区分事件时间和竞争事件；本次 HGB 离散风险实现不是 DeepHit 复现，也不能由该文推导电价尖峰一定可预测。', '',
        '证据文件：PROTOCOL.json、LOCAL_RESULT.json、ENTRY_RESULT.json、LATENCY.json、AUDIT.json、POSTRUN_REVIEW.json、SOURCE_FOLLOWUP.json、DECISION.json。逐种子和全部预测期结果均保留，不混入论文旧版主表。'])
    (N/'本轮结果与归因.txt').write_text('\n'.join(lines)+'\n',encoding='utf-8')
    print(str(N/'本轮结果与归因.txt'))
if __name__=='__main__':main()
