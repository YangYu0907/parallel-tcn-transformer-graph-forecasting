from model import *
import argparse
from sklearn.ensemble import HistGradientBoostingRegressor
from threadpoolctl import threadpool_limits

def adjusted(q,d):
    q=np.sort(np.asarray(q,float),axis=1)
    m=q[:,MID].copy()
    center=np.clip(m,-d['cap'][d['h']],d['cap'][d['h']])*d['allow']
    q+= (center-m)[:,None]
    for j in range(MID-1,-1,-1):q[:,j]=np.minimum(q[:,j],q[:,j+1]-1e-8)
    for j in range(MID+1,len(Q)):q[:,j]=np.maximum(q[:,j],q[:,j-1]+1e-8)
    q[:,MID]=center
    return q

def run(task,seed,arm):
    verify();checked(True);out=HERE/'fits'/f'{task}_{seed}_{arm}'
    if (out/'COMPLETE.json').exists():
        proof=read(out/'COMPLETE.json')
        assert sha(out/'raw.npz')==proof['prediction_sha256']
        return
    out.mkdir(parents=True,exist_ok=True);d=data(task,seed);idx=np.flatnonzero(d['fit'])
    start=time.monotonic();tick=timer()
    with old.numeric(f'Unified {task} {seed} {arm}'),threadpool_limits(limits=1):
        torch.set_num_threads(1);torch.manual_seed(seed);rng=np.random.default_rng(seed)
        if arm=='INDEPENDENT':
            parts=[]
            for j,tau in enumerate(Q):
                path=out/f'q{j}.pkl'
                if path.exists():obj=load(path)
                else:obj=HistGradientBoostingRegressor(loss='quantile',quantile=float(tau),learning_rate=.05,
                    max_iter=20,max_leaf_nodes=7,min_samples_leaf=100,l2_regularization=1.,
                    early_stopping=False,warm_start=True,random_state=seed)
                for upto in [20,40,60]:
                    if hasattr(obj,'n_iter_') and obj.n_iter_>=upto:continue
                    tick(task=task,seed=seed,arm=arm,quantile=float(tau),iterations=upto)
                    obj.set_params(max_iter=upto);obj.fit(d['X'][idx],d['residual'][idx]);dump(path,obj)
                parts.append(obj.predict(d['X']))
            q=adjusted(np.column_stack(parts),d)
            model_files=[str(p) for p in out.glob('q*.pkl')]
        else:
            net=JointQuantiles(d['X'].shape[1],d['gaps'],d['cap'])
            opt=torch.optim.AdamW(net.parameters(),lr=.001,weight_decay=.0001)
            arrays={k:torch.from_numpy(d[k].astype(np.int64 if k=='h' else np.float32)) for k in ['X','h','allow','residual','risk_lo','risk_hi']}
            checkpoint=out/'checkpoint.pkl';epoch=0;offset=0;order=None
            history=[]
            if checkpoint.exists():
                ck=load(checkpoint);assert ck['protocol_sha256']==sha(HERE/'PROTOCOL.json')
                net.load_state_dict(ck['model']);opt.load_state_dict(ck['optimizer'])
                epoch=ck['epoch'];offset=ck['offset'];order=ck['order'];rng.bit_generator.state=ck['rng'];history=ck['history']
            def snap(ep,off,ordered):
                dump(checkpoint,dict(model=net.state_dict(),optimizer=opt.state_dict(),epoch=ep,offset=off,
                    order=ordered,rng=rng.bit_generator.state,history=history,protocol_sha256=sha(HERE/'PROTOCOL.json')))
            for ep in range(epoch,40):
                if ep!=epoch or order is None:order=rng.permutation(idx);offset=0
                epstart=time.monotonic();loss_total=0.;nb=0
                net.train()
                for k in range(offset,len(order),1024):
                    ii=order[k:k+1024];opt.zero_grad(set_to_none=True)
                    qbatch=net(arrays['X'][ii],arrays['h'][ii],arrays['allow'][ii],fix=arm=='FIXED_POINT')
                    loss=objective(qbatch,arrays['residual'][ii],arrays['risk_lo'][ii],arrays['risk_hi'][ii],arm)
                    if not torch.isfinite(loss):raise FloatingPointError('Nonfinite loss')
                    loss.backward();torch.nn.utils.clip_grad_norm_(net.parameters(),1.,error_if_nonfinite=True);opt.step()
                    loss_total+=float(loss.detach());nb+=1
                    if nb%16==0:
                        snap(ep,k+len(ii),order)
                        tick(task=task,seed=seed,arm=arm,epoch=ep+1,epochs=40,batch_offset=k+len(ii),training_cells=len(idx))
                history.append(dict(epoch=ep+1,mean_batch_objective=loss_total/max(nb,1),seconds=time.monotonic()-epstart))
                snap(ep+1,0,None);order=None;offset=0
                write(out/'TRAINING.json',history)
                tick(task=task,seed=seed,arm=arm,epoch=ep+1,epochs=40,epoch_seconds=history[-1]['seconds'])
            net.eval();chunks=[]
            with torch.no_grad():
                for a in range(0,len(d['truth']),4096):
                    chunks.append(net(arrays['X'][a:a+4096],arrays['h'][a:a+4096],arrays['allow'][a:a+4096],fix=arm=='FIXED_POINT').numpy())
                    if a%65536==0:tick(task=task,seed=seed,arm=arm,stage='predict',row=a)
            q=np.concatenate(chunks).astype(float);model_files=[str(checkpoint)]
        assert q.shape==(len(d['truth']),len(Q)) and np.isfinite(q).all() and (np.diff(q)>0).all()
        if task=='CAISO':assert np.array_equal(q[d['h']<4,MID],np.zeros(int((d['h']<4).sum())))
        save(out/'raw.npz',q=q);tick(task=task,seed=seed,arm=arm,stage='complete')
        write(out/'COMPLETE.json',dict(at=old.now(),task=task,seed=seed,arm=arm,
            elapsed_seconds=time.monotonic()-start,prediction_sha256=sha(out/'raw.npz'),
            models={f:sha(f) for f in model_files},protocol_sha256=sha(HERE/'PROTOCOL.json'),final_epoch=40 if arm!='INDEPENDENT' else None))

if __name__=='__main__':
    p=argparse.ArgumentParser();p.add_argument('--task',choices=TASKS,required=True);p.add_argument('--seed',type=int,choices=SEEDS,required=True);p.add_argument('--arm',choices=ARMS,required=True)
    a=p.parse_args();run(a.task,a.seed,a.arm)

