from common import *
import numpy as np
def main():
 with numeric('fair-input saved prediction arithmetic audit'):
  seal=read(ROOT/'FAIR_INPUT_SEAL.json');rows=[]
  for case in seal['cases']:
   r=ROOT/'fair_runs'/f"{case['seed']}_{case['model']}";c=read(r/'COMPLETE.json');assert c['steps']==12096 and sha(r/'selected_dense.npz')==c['prediction_sha'];assert sha(r/'best.pt')==c['checkpoint_sha']
   z=np.load(r/'selected_dense.npz');e=z['prediction']-z['truth'];metrics=dict(mae=float(np.mean(abs(e))),rmse=float(np.linalg.norm(e.ravel())/np.sqrt(e.size)),near_mae=float(abs(e[:,:,:4]).mean()),h12_mae=float(abs(e[:,:,-1]).mean()))
   for k,v in metrics.items():assert abs(v-c['selected_dense'][k])<1e-9
   records=c['epochs'];best=records[0]
   for record in records[1:]:
    if record['metrics']['mae']<best['metrics']['mae']-1e-6:best=record
   assert c['selected_epoch']==best['epoch'];rows.append(dict(model=case['model'],seed=case['seed'],origins=len(z['origins']),selected_epoch=c['selected_epoch'],**metrics))
   write(r/'AUDIT.json',dict(at=now(),status='saved_arithmetic_passed',completion_sha=sha(r/'COMPLETE.json'),selector_reproduced=True,metrics=metrics,review_scope='separate scorer, same operator'))
  table('FAIR_NEW_MODEL_RESULTS.csv',rows)
  write(ROOT/'FAIR_COMPLETE.json',dict(at=now(),status='six_price_only_training_runs_audited',new_results=rows,old_DLinear_reuse_manifest=seal['reuse_DLinear'],scope='June3397 development; not a new independent test',protected=verify_protected(),new_test_targets_read=False))
  print(json.dumps(rows))
if __name__=='__main__':main()
