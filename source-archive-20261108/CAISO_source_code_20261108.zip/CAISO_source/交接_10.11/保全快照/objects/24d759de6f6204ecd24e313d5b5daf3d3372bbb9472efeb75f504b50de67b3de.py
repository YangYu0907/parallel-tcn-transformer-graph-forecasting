"""Exact feasible-set presolve for degenerate zero-boundary MSE constraints.
Original runs are immutable. This is a solver repair, not a new gate or threshold.
"""
from engine import *

def constrained_solve(D,error,states,horizons,tick):
    import numpy as np
    from scipy.optimize import minimize
    obj=Objective(D,error,states,horizons);n=D.shape[1];forced=set();certificates=[]
    assert np.all(obj.quads>=-1e-14)
    for j,v in enumerate(obj.linear):
        # For nonnegative theta and nonnegative Q entries, every term is >=0.
        # A feasible L theta + theta'Q theta <=0 therefore forces these to zero.
        if np.all(v>=0):
            cols=np.flatnonzero((v>0)|(np.diag(obj.quads[j])>0)).tolist()
            if cols:
                forced.update(cols);certificates.append(dict(state=obj.names[j],linear=v.tolist(),quadratic_diagonal=np.diag(obj.quads[j]).tolist(),forced_zero=cols))
    free=np.array([j for j in range(n) if j not in forced],int)
    if not len(free):return np.zeros(n),dict(success=True,message='All coefficients forced to zero by exact sample MSE constraints',iterations=0,forced=sorted(forced),certificates=certificates)
    red=Objective(D[:,free],error,states,horizons)
    keep=[0]
    for j,ix in enumerate(red.groups):
        if np.any(red.D[ix]!=0):keep.append(1+j)
    start=1+len(red.groups)
    for j,(v,Q) in enumerate(zip(red.linear,red.quads)):
        if np.any(v!=0) or np.any(Q!=0):keep.append(start+j)
    scales=np.maximum(abs(red.cjac(np.zeros(len(free)))[keep]).max(1),1e-4)
    count=0
    def callback(t):
        nonlocal count
        count+=1;tick(iteration=count)
    sol=minimize(red.fun,np.zeros(len(free)),jac=red.jac,method='SLSQP',bounds=[(0.,1.)]*len(free),
        constraints=[dict(type='ineq',fun=lambda t:red.con(t)[keep]/scales,jac=lambda t:red.cjac(t)[keep]/scales[:,None])],
        callback=callback,options=dict(maxiter=120,ftol=1e-9,disp=False))
    theta=np.zeros(n);theta[free]=np.maximum(sol.x,0)
    if theta.sum()>1:theta/=theta.sum()
    return theta,dict(success=bool(sol.success),message=str(sol.message),iterations=int(sol.nit),forced=sorted(forced),
        certificates=certificates,retained_constraint_rows=keep,positive_constraint_scaling=scales.tolist())

def main():
    policy();checked(True)
    protocol=HERE/'SOLVER_REPAIR_PROTOCOL.json'
    if not protocol.exists():
        write(protocol,dict(at=now(),status='registered_before_market_resolve',source_sha256=sha(Path(__file__)),
            original_result_sha256=sha(HERE/'RESULT.json'),original_audit_sha256=sha(HERE/'AUDIT.json'),
            trigger='Fold2: feasible zero exists but SLSQP reports incompatible inequalities. Fold1 remains zero after one iteration. Training-only inspection identifies nonnegative S5 quadratic loss constraint forcing exact zero coefficients.',
            changes='Algebraically eliminate coefficients forced to zero by L>=0 and entrywise Q>=0. Drop constraints identically zero on remaining variables. Positive row scaling changes numerical conditioning only. Same objective, candidate class, regularization, zero start, 120iteration budget and original unscaled feasibility check.',
            unchanged=['features','parents','splits','loss','state constraints','calibration rules','scoring','weight bounds'],
            fits='Reuse original fold0. Re-solve original fold1 and fold2 problems once each. No alternative model selection, no retries.',
            no_forward_labels_for_repair_choice=True,all_original_files_preserved=True,automatic_promotion=False))
    assert read(protocol)['source_sha256']==sha(Path(__file__))
    with numeric('same-objective presolve repair, no architecture or threshold change'):
        import numpy as np
        start=time.monotonic();d=data();rs=folds(d);s=d['scale'];reports=[];raw=d['full'].copy();guarded=d['full'].copy();weights=np.zeros_like(d['full'][:,:,7:]);evaluated=np.zeros(len(raw),bool)
        base_seconds=read(HERE/'BUDGET.json')['seconds']
        def tick(**kw):
            checked();elapsed=time.monotonic()-start
            write(HERE/'REPAIR_PROGRESS.json',dict(at=now(),seconds=elapsed,**kw))
            if base_seconds+elapsed>600:raise TimeoutError('Shared600s gate budget')
        # Toy problem: a protected group forces theta0=0; theta1 can still help.
        D=np.array([[1.,0.],[1.,0.],[0.,-1.],[0.,-1.]])
        t,qa=constrained_solve(D,np.ones(4),np.array([0,0,1,1]),np.array([8,9,8,9]),lambda **kw:None)
        assert qa['success'] and t[0]==0 and t[1]>.1
        write(HERE/'REPAIR_QA.json',dict(at=now(),status='passed',forced_zero_exact=True,remaining_descent_preserved=True))
        for k,role in enumerate(rs):
            old=read(HERE/f'FROZEN_{k}.json');model=dict(old['model']);mask=np.repeat(role==0,150);ev=role==2;cal=role==1
            f=d['full'][:,:,7:].ravel()[mask]/s;i=d['other'][:,:,7:].ravel()[mask]/s;y=d['truth'][:,:,7:].ravel()[mask]/s
            D=transform(d['X'][mask],model)*(i-f)[:,None];st=d['states'][:,:,7:].ravel()[mask];hz=np.broadcast_to(np.arange(8,13),d['full'][:,:,7:].shape).ravel()[mask]
            if k:
                theta,sol=constrained_solve(D,f-y,st,hz,lambda **kw:tick(fold=k,**kw))
                obj=Objective(D,f-y,st,hz)
                model.update(theta=theta.tolist(),solver_success=sol['success'],solver_message=sol['message'],iterations=sol['iterations'],
                    normalized_objective=obj.fun(theta),min_constraint=float(obj.con(theta).min()),training_feasible=bool(obj.con(theta).min()>=-1e-7))
            else:sol=dict(reused_original_valid_fold=True)
            alpha=predict(d['X'],model).reshape(len(role),30,5);arr=d['full'].copy();arr[:,:,7:]+=alpha*(d['other'][:,:,7:]-d['full'][:,:,7:])
            calibration=assess(arr[cal],d['full'][cal],d['truth'][cal],d['states'][cal])
            accept=calibration['empirical_pass'] and model['solver_success'] and model['training_feasible']
            frozen=dict(at=now(),fold=k,model=model,presolve=sol,calibration=calibration,accept=accept)
            write(HERE/f'REPAIRED_FROZEN_{k}.json',frozen)
            raw[ev]=arr[ev];weights[ev]=alpha[ev]
            if accept:guarded[ev]=arr[ev]
            evaluated|=ev
            reports.append(dict(fold=k,model_solver_success=model['solver_success'],training_feasible=model['training_feasible'],mean_weight=float(alpha[ev].mean()),
                accept=accept,frozen_sha256=sha(HERE/f'REPAIRED_FROZEN_{k}.json'),forward=assess(arr[ev],d['full'][ev],d['truth'][ev],d['states'][ev])))
        save(HERE/'REPAIRED_REPLAY.npz',origins=d['origins'],evaluated=evaluated,raw=raw,checked=guarded,alpha=weights)
        write(HERE/'REPAIRED_RESULT.json',dict(at=now(),status='same_candidate_solver_repair_scored',folds=reports,
            raw=assess(raw[evaluated],d['full'][evaluated],d['truth'][evaluated],d['states'][evaluated]),
            checked=assess(guarded[evaluated],d['full'][evaluated],d['truth'][evaluated],d['states'][evaluated]),
            original_result_sha256=sha(HERE/'RESULT.json'),repair_protocol_sha256=sha(protocol),replay_sha256=sha(HERE/'REPAIRED_REPLAY.npz'),
            V7_replaced=False,automatic_promotion=False,new_test_targets_read=False,seconds=time.monotonic()-start))
        print(json.dumps(dict(folds=[{key:r[key] for key in ['fold','model_solver_success','training_feasible','mean_weight','accept']} for r in reports],raw=metric(raw[evaluated],d['truth'][evaluated]),checked=metric(guarded[evaluated],d['truth'][evaluated]))))

if __name__=='__main__':main()
