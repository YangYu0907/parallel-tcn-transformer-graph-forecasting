"""Frozen, finite ADDITIVE mechanism diagnostic; no held-out reader."""
from pathlib import Path
from contextlib import contextmanager
from datetime import datetime,timezone
import argparse,hashlib,importlib.util,json,os,sys,uuid
HERE=Path(__file__).resolve().parent;ROOT=HERE.parent;V=ROOT/'phase_sampling_support_v3_20260923';COMMON=ROOT/'common_sampling_evaluation_20260923'
CASES=[{'id': '20260813_STATIC', 'seed': 20260813, 'variant': 'STATIC'}, {'id': '20260813_GTF', 'seed': 20260813, 'variant': 'GTF'}, {'id': '20260814_STATIC', 'seed': 20260814, 'variant': 'STATIC'}, {'id': '20260814_GTF', 'seed': 20260814, 'variant': 'GTF'}, {'id': '20260815_STATIC', 'seed': 20260815, 'variant': 'STATIC'}, {'id': '20260815_GTF', 'seed': 20260815, 'variant': 'GTF'}]
SEAL=HERE/'EXECUTION_LOCK.json';EVAL_SEAL=HERE/'EVALUATION_LOCK.json'
LOCK=Path('D:/Desktop/数据科学_论文/研究优化_20260818/logs/NEURAL_RUN.lock')
sys.path.insert(1,str(ROOT/'source'));sys.path.append(str(V/'source'))
import compile_gate as resources_api
def need(ok,msg):
    if not ok:raise RuntimeError(msg)
def now():return datetime.now(timezone.utc).isoformat()
def read(p):return json.loads(Path(p).read_text(encoding='utf-8-sig'))
def sha(p):
    h=hashlib.sha256()
    with Path(p).open('rb') as f:
        for x in iter(lambda:f.read(1048576),b''):h.update(x)
    return h.hexdigest()
def inside(p):
    p=Path(p);p=(ROOT/p if not p.is_absolute() else p).resolve()
    need(p.is_relative_to(ROOT),'Path escaped branch');return p
def rel(p):return str(inside(p).relative_to(ROOT))
def atomic(p,writer,replace=False):
    p=inside(p);need(p.is_relative_to(HERE) or p.parent==ROOT/'event_driven_automation/inbox' or p.parent==ROOT/'audits/backbone_lock_releases','Write escaped new experiment')
    p.parent.mkdir(parents=True,exist_ok=True);tmp=p.parent/('t_'+uuid.uuid4().hex+'.tmp')
    with tmp.open('xb') as f:writer(f);f.flush();os.fsync(f.fileno())
    if replace:os.replace(tmp,p)
    else:tmp.rename(p)
def write(p,v,replace=False):atomic(p,lambda f:f.write(json.dumps(v,ensure_ascii=False,indent=2,allow_nan=False).encode()),replace)
def boundary():
    pause=read(ROOT.parent/'RESEARCH_PAUSED.json')
    if pause.get('status')!='resumed_by_user' or pause.get('stop_preparation_and_training'):raise InterruptedError('User pause')
    for base in (ROOT,HERE,V):
        for name in ('STOP_REQUESTED','STOP_REQUESTED.json'):
            if (base/name).exists():raise InterruptedError('User stop '+str(base/name))
def guard(launch=False):
    boundary();r=resources_api.resources()
    need(min(r.values())>=(5 if launch else 4),'Unchanged resource floor: '+str(r))
    import shutil
    need(shutil.disk_usage(HERE).free/1024**3 >= (2 if launch else 1),'Checkpoint disk reserve')
    return r
@contextmanager
def exclusive(action):
    guard(True);import psutil
    owner=dict(pid=os.getpid(),created=psutil.Process().create_time(),token=uuid.uuid4().hex,action=action)
    with LOCK.open('x',encoding='utf-8') as f:json.dump(owner,f);f.flush();os.fsync(f.fileno())
    try:resources_api.bound_process();guard();yield
    finally:
        need(read(LOCK)==owner,'Shared owner changed');write(HERE/'lock_releases'/(owner['token']+'.json'),dict(owner=owner,at=now()));LOCK.unlink()
def runtime(torch_needed=False):
    for key in ('OMP_NUM_THREADS','MKL_NUM_THREADS','OPENBLAS_NUM_THREADS','NUMEXPR_NUM_THREADS'):os.environ[key]='1'
    resources_api.bound_process()
    import numpy as np
    from threadpoolctl import threadpool_limits,threadpool_info
    limiter=threadpool_limits(1)
    need(all(x['num_threads']==1 for x in threadpool_info()),'Numerical thread cap')
    if torch_needed:
        import torch
        torch.set_num_threads(1);torch.set_num_interop_threads(1);torch.use_deterministic_algorithms(True);guard();return np,torch,limiter
    guard();return np,limiter
def load(name,p):
    spec=importlib.util.spec_from_file_location(name,p);m=importlib.util.module_from_spec(spec);spec.loader.exec_module(m);return m
def verify():
    boundary();s=read(SEAL);need(s['status']=='sealed_missing_matched_panel_runs','Execution unsealed')
    for p,d in s['bindings'].items():need(sha(inside(p))==d,'Source/input changed '+p)
    need(s['cases']==CASES,'Case set changed')
    return s
def verify_evaluation():
    verify();s=read(EVAL_SEAL)
    need(s['status']=='sealed_common_backbone_evaluation' and len(s['cases'])==6,'Evaluation seal invalid')
    for p,d in s['bindings'].items():need(sha(inside(p))==d,'Evaluation input changed '+p)
    return s
def seal():
    boundary();need(not SEAL.exists(),'Execution seal exists');bindings={}
    def bind(p,d=None):
        p=inside(p);digest=sha(p);need(d is None or digest==d,'Bad source digest');bindings[rel(p)]=digest
        return read(p) if p.suffix=='.json' else digest
    for p in sorted(HERE.glob('*.py')):bind(p)
    for name in ('PROTOCOL.json','original_study_protocol_snapshot.md','launch_reviewed.ps1','watch_manager_exit.ps1','synthetic_qa.json','source_review.json'):bind(HERE/name)
    qa=read(HERE/'synthetic_qa.json');need(qa['status']=='passed' and qa['heldout_targets_read'] is False,'QA missing')
    for p,d in qa['sources'].items():bind(p,d)
    review=read(HERE/'source_review.json');need(review['status']=='passed' and review['qa_sha256']==sha(HERE/'synthetic_qa.json'),'Review missing')
    for p,d in review['sources'].items():bind(p,d)
    for p in (V/'SAMPLING_RUNNER_LOCK.json',V/'EXECUTION_SEAL.json',COMMON/'EVALUATION_LOCK.json'):
        old=bind(p)
        for name,d in old.get('sources',{}).items():bind(name,d)
    for name in ('queue/completion.json','result.json','numeric_audit.json'):bind(COMMON/name)
    prior=ROOT/'additive_mechanism_controls_v2_20260924'
    bind(prior/'queue/completion.json','7389820d58e529c4420ca91d77bd52126724e5425854b1fcee0ad96b197828a5')
    for name in ('EXECUTION_LOCK.json','EVALUATION_LOCK.json','result.json','summary.json','numeric_audit.json','checkpoint_audit.json'):bind(prior/name)
    gg=ROOT/'graph_gate_v1_20260924'
    bind(gg/'queue/completion.json','e87c9c37f0dbcee99227e7206a6156beb1fefe03ffeab47e62c31d7aac55beee')
    for name in ('EXECUTION_LOCK.json','EVALUATION_LOCK.json','result.json','summary.json','numeric_audit.json','checkpoint_audit.json'):bind(gg/name)
    bind(ROOT/'audits/graph_gate_completion_verified_20260924.json')
    for parent in (COMMON,prior):
        audit=read(parent/'numeric_audit.json')
        need(audit['status']=='passed' and audit['result_sha256']==sha(parent/'result.json'),'Reused common output unaudited')
        for p,d in audit['output_bindings'].items():bind(p,d)
    comp=read(COMMON/'queue/completion.json')
    need(sha(COMMON/'result.json')=='752720144f8d189d189ddb97d82c838a1cc23b15fea76d3ce406207ffc5a9324','Parent result changed')
    parent_manifest=V/'dataset/ADDITIVE/manifest.json';m=bind(parent_manifest);bind(parent_manifest.parent/'audit.json')
    for row in m['artifacts'].values():bind(row['path'],row['sha256'])
    bind(V/'dataset/train_diagnostic_origins.npy');bind(V/'dataset/schedule_audit.json')
    for seed in (20260813,20260814):
        for variant in ('FULL','TCN'):
            folder=V/'runs/ADDITIVE/backbone'/f'{seed}_{variant}'
            c=bind(folder/'backbone_completion.json');a=bind(folder/'backbone_audit.json')
            need(a['status']=='passed' and a['backbone_completion_sha256']==sha(folder/'backbone_completion.json'),'Parent audit differs')
            bind(c['selected_checkpoint'],c['selected_checkpoint_sha256'])
    s=dict(status='sealed_missing_matched_panel_runs',at=now(),bindings=bindings,
        cases=CASES,
        dataset_manifest=rel(parent_manifest),train_diagnostic=rel(V/'dataset/train_diagnostic_origins.npy'),
        heldout_targets_read=False,complete_research_experiment=False)
    write(SEAL,s);print(json.dumps(dict(status=s['status'],bindings=len(bindings),seal_sha256=sha(SEAL))))
def seal_evaluation():
    execution=verify();need(not EVAL_SEAL.exists(),'Evaluation already sealed');bindings={rel(SEAL):sha(SEAL)};cases=[]
    def bind(p,d=None):
        p=inside(p);digest=sha(p);need(d is None or digest==d,'Evaluation source changed');bindings[rel(p)]=digest
        return read(p) if p.suffix=='.json' else digest
    for c in execution['cases']:
        run=HERE/'runs'/c['id'];cp=run/'backbone_completion.json';cc=bind(cp);au=bind(run/'backbone_audit.json')
        need(au['status']=='passed' and au['backbone_completion_sha256']==sha(cp),'Training not audited')
        epochs=[]
        for e in cc['epochs']:
            ck=inside(e['checkpoint']);rr=bind(ck.with_suffix('.receipt.json'));bind(ck,rr['sha256']);bind(e['prediction'],e['prediction_sha256'])
            epochs.append(dict(epoch=e['epoch'],checkpoint=e['checkpoint'],checkpoint_sha256=rr['sha256'],original_june=e['june']))
        chosen=next(x for x in cc['epochs'] if x['epoch']==cc['selected_epoch'])
        cases.append(dict(id=c['id'],policy='ADDITIVE',variant=c['variant'],seed=c['seed'],identity=cc['identity'],
            selected_epoch=cc['selected_epoch'],selected_checkpoint=cc['selected_checkpoint'],selected_prediction=chosen['prediction'],reference_metrics=cc['selected_june'],epochs=epochs))
    write(EVAL_SEAL,dict(status='sealed_common_backbone_evaluation',at=now(),bindings=bindings,cases=cases,
        dataset_manifest=execution['dataset_manifest'],train_diagnostic=execution['train_diagnostic'],heldout_targets_read=False))
if __name__=='__main__':
    p=argparse.ArgumentParser();p.add_argument('action',choices=('seal','check','seal-evaluation'));args=p.parse_args()
    if args.action=='seal':seal()
    elif args.action=='seal-evaluation':seal_evaluation()
    else:print(json.dumps(dict(status='passed',cases=len(verify()['cases']),resources=guard(True))))
