from common18 import *

def main():
    assert not (HERE/'PROTOCOL.json').exists(), 'Registration is immutable'
    ART.mkdir(parents=True, exist_ok=True)
    paper = Path('F:/CAISO_论文/manuscript_20260930_v7')
    protected = [B/'spike_specialist_v7_20260930/RESULT.json', B/'spike_specialist_v7_20260930/AUDIT.json',
                 B/'v7_confirmation_20260930/RESULT.json', B/'v7_confirmation_20260930/AUDIT.json',
                 paper/'Energy_manuscript.docx', paper/'Energy_manuscript.pdf',
                 paper/'Energy_supplementary.docx', paper/'Energy_supplementary.pdf', paper/'DELIVERY_MANIFEST.json']
    digests = {str(p): sha(p) for p in protected}
    for p in protected:
        dst=ART/'preserved'/p.parent.name/p.name
        dst.parent.mkdir(parents=True,exist_ok=True); shutil.copy2(p,dst); assert sha(dst)==digests[str(p)]
    write(HERE/'PRESERVATION.json', dict(at=now(), files=digests, copies=str(ART/'preserved'),
        full_V7_existing_backup=str(B/'v7_preservation_review_20260930/PRESERVATION.json')))
    protocol = dict(at=now(), status='registered_before_new_diagnostic_scores_and_control_fits',
        authorization='User approves bounded repair of Europe spatial and CAISO fusion comparison while preserving existing results',
        scope='Exploratory development only. Previously inspected H1 and Europe2015 are NOT new independent tests.',
        protected='All V7 checkpoints/results and manuscript remain byte-identical; no substitution with new results',
        mandatory=['TCN','Transformer','dynamic GNN','parallel temporal branches','adaptive feature attention'],
        europe=dict(question='Are spatial-model advantages predictable from available context, beyond a constant combination?',
            data='All365 validation days2015; 3markets,24h,3seeds; fixed previously selected checkpoints',
            evaluation_blocks=[[97,187],[187,277],[277,365]], fit_rule='Days [0,start-7), common across seeds; seven market-day purge',
            features='Per-market past168h level,volatility,ramp,cross-market spread,correlation,calendar,market identity,available model disagreement; no future labels',
            target='Daily-market MAE difference FULL minus STATIC or SELF, averaged over3seeds',
            estimator='One HGB per alternative per fold: squared_error,40iterations,4leaves,minleaf30,lr.05,l2=1,seed20260813,no earlystop,no search;6fits',
            candidate='Output-level feasibility probe: 0.25FULL +0.75softmax(predicted benefit / mean fitting FULL MAE) mixture of FULL,STATIC,SELF',
            controls=['FULL','STATIC','SELF','equal three-way mixture','constant same-form mixture from earlier fit loss','earlier-fit best fixed model'],
            oracle='Hindsight day-market best model only estimates unavailable selection headroom; never used as deployable result',
            proceed='Candidate improves average MAE overFULL,constant and equal mixture;RMSE<=FULL;2of3seed MAE betterFULL. Probe does not establish internal graph mechanism.'),
        caiso=dict(question='Does V7 attention retain an advantage when CONCAT and EQUAL receive the same correction procedure?',
            panel='Exact existing V4 three chronological folds:698 evaluation origins,42UTCdays,30nodes12h,3seeds',
            anchors=['FULL','CONCAT','EQUAL'], shared='Same trained DLinear,persistence,GB_DELTA,TAR_POOL,TRAIN-only specialist distribution/hazard,features,folds,publication-ready feedback,budgets',
            refits='CONCAT/EQUAL each receive their own anchor-relative mean/median HGB per fold and seed, original40iterations7leavesminleaf100lr.05l2=1;36fits maximum',
            FULL='Reuse original18 functional models; independently replay V7 exactly before any new fitting',
            prediction='Nonextreme: original V4 NEW5 correction/calibration. Current-extreme: original V7 CONTEXT specialist with same anchor-relative mean/median agreement and0.75bound.',
            reporting='All seeds,aggregate,near,H12,lowvol,node,horizon,states and paired real-calendar-week bootstrap2000;Holm overFULLvsCONCAT/EQUAL;exploratory only',
            success='No claim attention repaired unless FULL beats both corrected controls; original V7 positive directions still reported. Shared expert extension is matched downstream procedure, not universal component causality.'),
        budget=dict(numerical_seconds=3600, neural_updates=0, new_meta_fits_max=42, auto_search=False),
        resources='Single worker1thread,physical/commit launch5GiB runtime4GiB. C numerical artifacts launch2GiB/runtime1GiB disk;F only metadata floor32MiB.',
        independent_confirmation='A changed model requires a newly qualified, unseen period. September2026,H1andEurope2016 already viewed; none will be relabeled independent.',
        literature=[dict(url='https://arxiv.org/abs/1912.09363',basis='TFT gating suppresses unnecessary components; motivates conditional use, no guaranteed benefit'),
                    dict(url='https://www.ijcai.org/proceedings/2019/0264.pdf',basis='GraphWaveNet combines graph supports; learned adaptive adjacency is not itself time-varying. Output probe is not its replication.'),
                    dict(url='https://arxiv.org/abs/2008.08004',basis='Matched EPF comparisons and chronological evaluation'),
                    dict(url='https://jmlr.org/papers/v11/cawley10a.html',basis='Repeated finite-sample selection bias; bounded exploratory scope')])
    write(HERE/'PROTOCOL.json', protocol)
    bindings={str(p):sha(p) for p in HERE.glob('*.py')}
    bindings[str(HERE/'PROTOCOL.json')]=sha(HERE/'PROTOCOL.json')
    e=B/'energy_confirmation_v1_20260926'
    for p in [e/'data/train_valid.npz',B/'adaptive_experts_v4_20260929/FOLDS.json']:
        bindings[str(p)]=sha(p)
    for seed in SEEDS:
        for mode in ('FULL','STATIC','SELF'):
            for name in ('validation_predictions.npz','result.json','audit.json'):
                p=e/'runs'/f'{mode}_{seed}_0.001'/name; bindings[str(p)]=sha(p)
    write(HERE/'SEAL.json', dict(at=now(),bindings=bindings))
    write(HERE/'queue/status.json', dict(at=now(), event='registered', active=False))
    h=read(B/'HANDOFF.json'); write(HERE/'HANDOFF.before.json',h)
    h.update(status='bounded_mechanism_diagnosis_registered',current_plan_complete=False,complete_research_experiment=False,
             current_authorized_work='User-approved bounded Europe spatial diagnosis and CAISO matched V7 fusion controls; preserve completed V7 paper.',
             research_training_active=False,event_listener_pid=None,
             next_actions=['Run registered diagnostics under resource guards','Audit predictions independently','Decide one justified modification or close without overwriting V7'])
    h['mechanism_repair_v18']=dict(directory=str(HERE),protocol=str(HERE/'PROTOCOL.json'),status='registered',prior_scope_complete=True,new_test_targets_read=False)
    gate.write(B/'HANDOFF.json',h)
    print(json.dumps(dict(status='registered',preserved_files=len(digests),protocol_sha256=sha(HERE/'PROTOCOL.json'))))
if __name__=='__main__': main()
