"""Fresh constructors only. All fitted buffers must be supplied from this branch."""
VARIANTS=('TCN','FULL','EQUAL','CONCAT','GLOBAL','GTF','STATIC','SELF')
def build_backbone(variant,seed,context_limits):
    if variant not in VARIANTS or seed not in (20260813,20260814,20260815):raise ValueError('Unregistered variant/seed')
    if variant in ('TCN','FULL'):
        from .clip_model import ClipFusion
        return ClipFusion(variant,seed,context_limits)
    if variant in ('EQUAL','CONCAT'):
        from .fusion_controls import FusionAblation
        return FusionAblation(variant,seed,context_limits)
    from .component_controls import FusionAblation
    return FusionAblation(variant,seed,context_limits)
def build_film(seed,new_train_feature_mean,new_train_feature_std):
    if new_train_feature_mean is None or new_train_feature_std is None:raise ValueError('New TRAIN feature moments required')
    from .film import FiLM
    return FiLM(new_train_feature_mean,new_train_feature_std,seed)
def build_query(seed,selected_new_film_mean,selected_new_film_std):
    from .query import NodeResidual
    return NodeResidual(selected_new_film_mean,selected_new_film_std,seed)
