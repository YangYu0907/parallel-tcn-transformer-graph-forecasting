"""Isolated source-only resource contract; never used by model training."""
from pathlib import Path
from contextlib import contextmanager
import sys, os, json, time, uuid, ctypes, shutil
W=Path(__file__).resolve().parent
sys.path.insert(0,str(W.parent))
import support as original
sys.path.insert(0,str(W))
N=original.N; B=original.B; A=original.A; base=original.base
read=original.read; sha=original.sha; now=original.now; write=original.write
emit=original.emit; verify=original.verify
JOB=None
JOB_CAP=1024**3

# Windows job memory limit covers this process and its curl child.
class BASIC(ctypes.Structure):
    _fields_=[('PerProcessUserTimeLimit',ctypes.c_longlong),('PerJobUserTimeLimit',ctypes.c_longlong),
      ('LimitFlags',ctypes.c_uint32),('MinimumWorkingSetSize',ctypes.c_size_t),('MaximumWorkingSetSize',ctypes.c_size_t),
      ('ActiveProcessLimit',ctypes.c_uint32),('Affinity',ctypes.c_size_t),
      ('PriorityClass',ctypes.c_uint32),('SchedulingClass',ctypes.c_uint32)]
class IO(ctypes.Structure):
    _fields_=[(x,ctypes.c_ulonglong) for x in ['ReadOperationCount','WriteOperationCount','OtherOperationCount','ReadTransferCount','WriteTransferCount','OtherTransferCount']]
class EXT(ctypes.Structure):
    _fields_=[('BasicLimitInformation',BASIC),('IoInfo',IO),('ProcessMemoryLimit',ctypes.c_size_t),
      ('JobMemoryLimit',ctypes.c_size_t),('PeakProcessMemoryUsed',ctypes.c_size_t),('PeakJobMemoryUsed',ctypes.c_size_t)]

def install_limit():
    global JOB
    if JOB is not None:return
    k=ctypes.WinDLL('kernel32',use_last_error=True)
    k.CreateJobObjectW.argtypes=[ctypes.c_void_p,ctypes.c_wchar_p];k.CreateJobObjectW.restype=ctypes.c_void_p
    k.SetInformationJobObject.argtypes=[ctypes.c_void_p,ctypes.c_int,ctypes.c_void_p,ctypes.c_uint32]
    k.AssignProcessToJobObject.argtypes=[ctypes.c_void_p,ctypes.c_void_p]
    k.GetCurrentProcess.restype=ctypes.c_void_p
    job=k.CreateJobObjectW(None,None)
    if not job:raise ctypes.WinError(ctypes.get_last_error())
    limits=EXT()
    limits.BasicLimitInformation.LimitFlags=0x200|0x2000 # JOB_MEMORY | KILL_ON_JOB_CLOSE
    limits.JobMemoryLimit=JOB_CAP
    if not k.SetInformationJobObject(job,9,ctypes.byref(limits),ctypes.sizeof(limits)):
        raise ctypes.WinError(ctypes.get_last_error())
    if not k.AssignProcessToJobObject(job,k.GetCurrentProcess()):
        raise ctypes.WinError(ctypes.get_last_error())
    JOB=job
    base.cg.bound_process()

def memory():
    import psutil
    m=psutil.Process().memory_info()
    out={'rss_MiB':m.rss/2**20,'peak_rss_MiB':m.peak_wset/2**20,'private_MiB':m.private/2**20}
    if JOB:
        k=ctypes.WinDLL('kernel32',use_last_error=True)
        k.QueryInformationJobObject.argtypes=[ctypes.c_void_p,ctypes.c_int,ctypes.c_void_p,ctypes.c_uint32,ctypes.c_void_p]
        limits=EXT()
        if not k.QueryInformationJobObject(JOB,9,ctypes.byref(limits),ctypes.sizeof(limits),None):
            raise ctypes.WinError(ctypes.get_last_error())
        out['peak_job_commit_MiB']=limits.PeakJobMemoryUsed/2**20
        out['job_cap_MiB']=limits.JobMemoryLimit/2**20
    return out

def check_limits(resources,launch=False):
    floor=3.0 if launch else 2.0
    if min(resources.values())<floor:raise MemoryError('Source-only available memory floor '+str(resources))
    return resources

def guard(launch=False):
    for folder in [N,W,B,B/'context_expert_v1_20260929',B/'context_expert_v1_20260929/queue']:
        for name in ['STOP_REQUESTED','STOP_REQUESTED.json']:
            if (folder/name).exists():raise InterruptedError('User stop '+str(folder/name))
    p=read(B.parent/'RESEARCH_PAUSED.json')
    if p.get('stop_preparation_and_training') or p.get('status')!='resumed_by_user':
        raise InterruptedError('Research pause')
    if shutil.disk_usage(N).free<4*1024**3:raise OSError('Below 4GiB disk reserve')
    return check_limits(base.cg.resources(),launch)

@contextmanager
def source_exclusive(action):
    """Same global exclusive owner; source-only memory policy, no learner imports."""
    import psutil
    guard(True);install_limit()
    owner=dict(pid=os.getpid(),created=psutil.Process().create_time(),token=uuid.uuid4().hex,
               action=action,source_only=True,job_memory_cap_bytes=JOB_CAP)
    with base.LOCK.open('x',encoding='utf-8') as f:json.dump(owner,f)
    try:yield
    finally:
        if base.LOCK.exists() and read(base.LOCK)==owner:
            base.LOCK.unlink()
            write(W.name+'/lock_releases/'+owner['token']+'.json',dict(at=now(),owner=owner))
