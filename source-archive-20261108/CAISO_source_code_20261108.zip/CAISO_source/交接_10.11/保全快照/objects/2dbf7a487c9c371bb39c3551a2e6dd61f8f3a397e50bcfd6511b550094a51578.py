"""Formula, horizon-gradient sparsity, identity and exact-resume QA."""
import copy,io,json,importlib.util
import gate
def main():
 with gate.exclusive('horizon_adapter_synthetic_QA'):
  np,torch,lim=gate.runtime()
  from torch import nn
  from adapter import AdaptedFULL,HorizonAdapters,fingerprint
  from math_ops import objective,step
  import train
  train.torch=torch
  spec=importlib.util.spec_from_file_location('verified_shared_adapter',gate.PARENT/'adapter.py')
  old=importlib.util.module_from_spec(spec);spec.loader.exec_module(old)
  checks=[]
  class Head(nn.Module):
   def __init__(self):super().__init__();self.linear=nn.Linear(32,1)
   def forward(self,z):return self.linear(z).squeeze(-1)
  class Base(nn.Module):
   def __init__(self):super().__init__();self.head=Head()
   def forward(self,z):return dict(head_features=z,prediction=self.head(z))
  torch.manual_seed(913)
  base=Base().eval();x=torch.randn(4,30,12,32);y=torch.randn(4,30,12);mask=torch.tensor([True,False,True,False])
  m=AdaptedFULL(copy.deepcopy(base),20260813,'HORIZON')
  shared=old.AdaptedFULL(copy.deepcopy(base),20260813,'OFFHOUR')
  assert sum(p.numel() for p in m.parameters() if p.requires_grad)==6624
  for block in m.adapter.blocks:
   assert all(torch.equal(v,shared.adapter.state_dict()[k]) for k,v in block.state_dict().items())
  assert torch.equal(m(x,mask)['prediction'],shared(x,mask)['prediction'])
  checks+=['6624_parameters','12_initial_copies_match_shared_control','zero_identity']
  before=fingerprint(m.base);opt=train.opt_for(m);m.train()
  assert not m.base.training
  step(m,opt,x,y,mask)
  assert fingerprint(m.base)==before and all(p.grad is None for p in m.base.parameters())
  assert all(torch.count_nonzero(block.up.weight)>0 for block in m.adapter.blocks)
  assert torch.equal(m(x,mask)['prediction'][mask],base(x)['prediction'][mask])
  checks+=['base_frozen','all_horizons_receive_updates','hourly_exact_after_update']
  # Every per-horizon data loss has zero derivative to the other11 adapter blocks.
  for h in range(12):
   opt.zero_grad(set_to_none=True)
   loss=objective(m(x,mask)['prediction'][:,:,h],y[:,:,h]);loss.backward()
   for j,block in enumerate(m.adapter.blocks):
    if j==h:assert any(torch.count_nonzero(p.grad)>0 for p in block.parameters())
    else:assert all(p.grad is not None and torch.count_nonzero(p.grad)==0 for p in block.parameters())
  checks+=['all12_block_diagonal_data_gradient_checks']
  opt.zero_grad(set_to_none=True);objective(m(x,torch.ones(4,dtype=torch.bool))['prediction'],y).backward()
  assert all(p.grad is not None and torch.count_nonzero(p.grad)==0 for p in m.adapter.parameters())
  checks+=['all_hourly_data_gradient_zero']
  # Alter one block: all other horizon predictions stay exact.
  before_p=m(x,mask)['prediction'].detach()
  with torch.no_grad():m.adapter.blocks[11].up.bias.add_(.02)
  after_p=m(x,mask)['prediction'].detach()
  assert torch.equal(before_p[:,:,:11],after_p[:,:,:11])
  assert torch.equal(before_p[mask],after_p[mask])
  assert not torch.equal(before_p[~mask,:,11],after_p[~mask,:,11])
  checks+=['one_block_changes_one_horizon_only']
  ad=copy.deepcopy(m.adapter).double();xx=x[:1,:1].double().requires_grad_();z=ad(xx);manual=[]
  for h,block in enumerate(ad.blocks):
   v=xx[:,:,h]@block.down.weight.T+block.down.bias
   gelu=.5*v*(1+torch.erf(v/2**.5))
   manual.append(xx[:,:,h]+gelu@block.up.weight.T+block.up.bias)
  assert torch.allclose(z,torch.stack(manual,2),rtol=0,atol=1e-14)
  gradient=torch.autograd.grad((z*z).sum(),xx)[0];eps=1e-6
  plus=xx.detach().clone();minus=xx.detach().clone();plus[:,:,5,3]+=eps;minus[:,:,5,3]-=eps
  fd=float((((ad(plus)**2).sum()-(ad(minus)**2).sum())/(2*eps)).detach())
  assert abs(fd-float(gradient[:,:,5,3]))<1e-6
  checks+=['raw_GELU_formula_all_horizons','finite_difference']
  uninterrupted=copy.deepcopy(m);ou=train.opt_for(uninterrupted);ou.load_state_dict(copy.deepcopy(opt.state_dict()))
  stream=io.BytesIO();torch.save(dict(model=m.state_dict(),optimizer=opt.state_dict(),rng=torch.get_rng_state()),stream);stream.seek(0)
  saved=torch.load(stream,weights_only=False)
  resumed=AdaptedFULL(copy.deepcopy(base),20260813,'HORIZON');resumed.load_state_dict(saved['model'])
  ore=train.opt_for(resumed);ore.load_state_dict(saved['optimizer'])
  for model,optimizer in ((uninterrupted,ou),(resumed,ore)):
   torch.set_rng_state(saved['rng'])
   for _ in range(3):step(model,optimizer,x,y,mask)
  assert fingerprint(uninterrupted)==fingerprint(resumed)
  for i,v in ou.state_dict()['state'].items():
   for k,value in v.items():
    peer=ore.state_dict()['state'][i][k]
    assert torch.equal(value,peer) if torch.is_tensor(value) else value==peer
  checks+=['exact_optimizer_model_resume']
  from models.factory import build_backbone
  full=build_backbone('FULL',20260813,[[1.,1.]]*30).eval()
  actual=AdaptedFULL(full,20260813,'HORIZON').eval();history=torch.randn(4,288,30,29)*.1
  rng=torch.get_rng_state().clone();base_fp=fingerprint(full)
  with torch.inference_mode():
   original=full(history);out=actual(history,mask)
  assert torch.equal(out['prediction'],original['prediction'])
  assert torch.equal(out['branch_weights'],original['branch_weights']) and torch.equal(out['dynamic_adjacency'],original['dynamic_adjacency'])
  assert out['branch_weights'].shape==(4,30,12,2)
  assert torch.allclose(out['branch_weights'].sum(-1),torch.ones(4,30,12))
  assert fingerprint(full)==base_fp and torch.equal(rng,torch.get_rng_state())
  checks+=['actual_FULL_identity','adaptive_attention_dynamic_graph_preserved','no_eval_mutation_or_RNG']
  for bad in (torch.ones(4),torch.ones(3,dtype=torch.bool)):
   try:actual(history,bad)
   except ValueError:pass
   else:raise RuntimeError('Invalid mask accepted')
  checks+=['bad_mask_rejected']
  sources={gate.rel(p):gate.sha(p) for p in gate.HERE.glob('*.py')}
  gate.write(gate.HERE/'synthetic_qa.json',dict(status='passed',at=gate.now(),checks=checks,sources=sources,heldout_targets_read=False))
  print(json.dumps(dict(status='passed',checks=len(checks))))
if __name__=='__main__':main()
