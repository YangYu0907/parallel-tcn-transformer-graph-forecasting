"""Post-hoc accounting checks and deterministic illustrative cases, no fit."""
from common import *
from datetime import datetime,timezone
import math
def main():
  with gate.exclusive('Manual component attribution arithmetic and fixed worst-event trace'):
    np,lim=gate.runtime(False);r=gate.read(HERE/'RESULT.json');a=gate.read(HERE/'AUDIT.json')
    assert a['status']=='passed' and a['result_sha256']==gate.sha(HERE/'RESULT.json')
    with np.load(ART/'DEV_COMPONENTS.npz') as z:d={k:z[k] for k in z.files}
    with np.load(ART/'UNCHANGED_FORECASTS.npz') as z:f=z['FULL'].reshape(3,-1,12);v=z['V7'].reshape(3,-1,12)
    y=d['target'][...,0];checks=0
    for row in r['seed_error_conditioned_attribution']:
      idx=row['seed']-20260813;change=(v[idx]-y)**2-(f[idx]-y)**2;mask=d['states']==row['state']
      if row['condition']=='harmful':mask &= change>1e-8
      if row['condition']=='helpful':mask &= change<-1e-8
      if not mask.any():continue
      ii,hh=np.where(mask);z=d['target'][ii,hh]-d['last'][ii];z=np.column_stack([z,z[:,0]-z[:,1:].sum(1)])
      for key,w in [('component_movement',np.ones(len(ii))),('absolute_SSE_change_weighted_movement',abs(change[mask]))]:
        orig=row[key]
        if orig is None:continue
        total=math.fsum(w.tolist());numer=[math.fsum(float(ww)*abs(float(val)) for ww,val in zip(w,z[:,k])) for k in range(1,5)];den=math.fsum(numer)
        assert np.allclose(np.array(numer)/max(den,1e-12),orig['absolute_movement_share'],atol=1e-12,rtol=1e-12)
        for k in range(5):
          expected=math.fsum(float(ww)*float(val) for ww,val in zip(w,z[:,k]))/total
          assert math.isclose(expected,orig['mean_signed_change_USD_MWh'][k],rel_tol=1e-10,abs_tol=1e-9)
        checks+=1
    # Select illustrative cases by complete three-seed average error change,
    # not by how a curve looks. They never create a runtime rule.
    change=((v-y[None])**2-(f-y[None])**2).mean(0)
    chosen=[]
    for state,sign in [(3,1),(5,-1)]:
      values=np.where(d['states']==state,sign*change,-np.inf);ii,hh=np.unravel_index(np.argmax(values),values.shape)
      chosen.append((state,int(ii),int(hh)))
    fr=gate.read(B/'h1_source_inputs_v1_20260927/INPUT_AUDIT_FREEZE.json')
    sys.path.insert(0,str(B/'energy_confirmation_v1_20260926/admission'));from bounded_history import BoundedMember
    allowed=set(map(int,d['origin']))
    class C:
      def __init__(self,o):assert o in allowed;self.origin=o
      def allows(self,start,stop,kind):return kind=='past_only' and (start,stop)==(self.origin-288,self.origin)
    reader=BoundedMember(fr['config']['price_archive'],'values','<f4',(30,4));cases=[]
    try:
      for state,ii,hh in chosen:
        o=int(d['origin'][ii]);n=int(d['node'][ii]);past=np.frombuffer(reader.read(o-288,o,C(o),'past_only'),'<f4').reshape(288,30,4)[:,n]
        cases.append(dict(state=state,selection='Largest three-seed mean added SSE' if state==3 else 'Largest three-seed mean reduced SSE',
          origin=o,node_index=n,horizon=hh+1,issue_UTC=datetime.fromtimestamp(1685577600+(o-1)*300,timezone.utc).isoformat(),
          component_order=['LMP','ENERGY','CONGESTION','LOSS'],history=[dict(minutes_before_issue=m,values=past[-1-m//5].tolist()) for m in [60,30,15,5,0]],
          actual_target=d['target'][ii,hh].tolist(),FULL=f[:,ii,hh].tolist(),V7=v[:,ii,hh].tolist(),
          mean_SSE_change=float(change[ii,hh]),warning='Illustrative extremes selected after observing errors, not representative cases or deployment rules.'))
    finally:reader.close()
    write(HERE/'CASE_TRACES.json',dict(at=gate.now(),cases=cases,fits=0))
    write(HERE/'ATTRIBUTION_AUDIT.json',dict(at=gate.now(),status='passed',manual_weighted_attribution_checks=checks,
      result_sha256=gate.sha(HERE/'RESULT.json'),case_trace_sha256=gate.sha(HERE/'CASE_TRACES.json'),code_sha256=gate.sha(__file__),protected_files_verified=preserved(),fits=0))
    print(json.dumps(dict(checks=checks,cases=cases)))
if __name__=='__main__':main()
