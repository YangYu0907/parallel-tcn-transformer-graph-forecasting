"""Immutable second-stage seal binds candidate priors, QA and execution code."""
from pathlib import Path
import gate as g
TRAINING_SEAL=g.HERE/'TRAINING_SEAL.json'
def verify_training():
    g.verify();s=g.read(TRAINING_SEAL)
    g.need(s['status']=='sealed_finite_training','Training not sealed')
    for name,digest in s['bindings'].items():g.need(g.sha(name)==digest,'Training artifact changed: '+name)
    g.need(g.read(g.HERE/'QA.json')['status']=='passed','QA not passed')
    return s
def seal():
    g.verify();g.need(not TRAINING_SEAL.exists(),'Already sealed')
    r=g.read(g.HERE/'diagnostic/RESULT.json');a=g.read(g.HERE/'diagnostic/AUDIT.json')
    g.need(r['structural_gate_passed'] and a['training_screen_passed'] and a['result_sha256']==g.sha(g.HERE/'diagnostic/RESULT.json'),'Screen/audit failed')
    g.need(g.read(g.HERE/'QA.json')['status']=='passed','QA failed')
    files=list(g.HERE.glob('*.py'))+list(g.HERE.glob('*.ps1'))+[g.SEAL,g.HERE/'PROTOCOL.json',g.HERE/'QA.json',g.HERE/'diagnostic/RESULT.json',g.HERE/'diagnostic/AUDIT.json']
    files += [Path(row['prior_path']) for row in r['seeds']]
    old=g.ROOT/'residual_attention_v1_20260928'
    files += [old/name for name in ('EXECUTION_SEAL.json','PROTOCOL.json','AUDIT.json','common.py','train.py','selection.py')]
    for ref in g.read(g.HERE/'PROTOCOL.json')['reused_controls']:
        folder=Path(ref['directory']);record=g.read(folder/'completion.json')
        files += [folder/'completion.json',folder/'audit.json',folder/'run_start.json']
        for row in record['epochs']:files += [Path(row['evaluation']),Path(row['checkpoint']['path'])]
    g.write(TRAINING_SEAL,dict(status='sealed_finite_training',at=g.now(),bindings={str(p):g.sha(p) for p in files},
        new_fits=3,reused_controls=3,test_access_permitted=False))
    print('Finite training sealed')
if __name__=='__main__':seal()
