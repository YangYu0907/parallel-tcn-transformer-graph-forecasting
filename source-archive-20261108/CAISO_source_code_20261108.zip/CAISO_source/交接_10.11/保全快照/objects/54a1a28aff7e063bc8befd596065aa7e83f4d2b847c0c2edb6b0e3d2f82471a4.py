from common import *

def main():
 assert not (HERE/'PROTOCOL.json').exists()
 dm=gate.read(V14/'DATA.json');sd=V14/'skill_diagnostic'
 paths=[V14/'RESULT.json',V14/'AUDIT.json',V14/'DATA.json',V14/'DATA_AUDIT.json',V14/'SPECIALIST_COMPLETE.json',V14/'INTERPRETATION.json',
        sd/'PROTOCOL.json',sd/'COMMON_PANEL.json',B/'spike_transition_v12_20260930/modelmath.py',B/'spike_specialist_v7_20260930/worker.py',
        B/'adaptive_experts_v5_20260929/worker.py',B/'context_expert_v1_20260929/gate.py']+list(HERE.glob('*.py'))
 bindings={str(p):gate.sha(p) for p in paths}
 bindings.update(gate.read(V14/'RESULT.json')['artifacts']);bindings.update(gate.read(V14/'SPECIALIST_COMPLETE.json')['bindings'])
 for name in ['train.npy','valid_select.npy','evaluation.npy','scalers.json','state_thresholds.json','features.npy']:
  path=str(Path(dm['directory'])/name);bindings[path]=dm['artifacts'][path]
 for name in ['raw_prices','timestamps','forecast_publications']:bindings[dm[name]]=dm['parent_source_bindings'][dm[name]]
 bindings[dm['publication_ledger']]=gate.sha(dm['publication_ledger'])
 p=dict(at=gate.now(),status='registered_before_new_fits',purpose='One probability-calibration candidate and one independent onset-information diagnostic; no backbone retraining or grid',
  authorization='User2026-09-30 asks to continue literature-grounded changes while protecting positive results',
  scope='Already-inspected internal development;2024prefix; never relabel as untouched confirmation or replace originalV7/main-paper results',
  bindings=bindings,
  calibration=dict(folds=[['2024-09-01','2024-10-01'],['2024-10-01','2024-11-01'],['2024-11-01','2024-12-01'],['2024-12-01','2025-01-01']],
   fit='All earlier V14 out-of-time specialist errors whose labels are fully published before foldstart and whose horizon ends at least2days before foldstart; no class balancing',
   map='softmax(W log p+b), identity-centred fixedL2penalty0.01 on W-I and b. Optimize crossentropy only;12parameters. This regularization is a project choice, not claimed optimal by literature.',
   unchanged='All amplitude learners, residual atoms,0.25FULL anchor and mean/median agreement rule unchanged. Only the probability map changes.',
   controls=['FULL','uncalibrated_SPIKE_ARM','prior_BINARY_PROBE_reference','DIRICHLET_CALIBRATED solecandidate'],
   evaluation='Complete75date15092origin commonpanel, all nodes/horizons/states. Compare Brier,NLL and reliability on specialist domain; no probability-score improvement substituted for price improvement.',
   protection='Require every state/near/H12 MAE/RMSE no worse than prefixFULL, prior positive S3/S5 directions retained, aggregateMAE/RMSE no worse than priorbinaryprobe. Any violation closes this candidate; no coefficient search after evaluation.'),
  onset=dict(role='Information-value diagnostic only; no point forecasts or mainmodel corrections',
   minimum_events='Both TRAIN and validation require at least20positive origin-node pairs across3dates; otherwise stop as insufficient information, without loosening threshold.',
   train='Exactly all source-admitted TRAIN origins on clock hours before2024-05-30, currently non-extreme nodes; all12 future steps label whether any absolute deviation exceeds TRAINq99. No future-class-based sampling.',
   calibration='All311June2024clock-hour validation origins, non-extreme nodes, natural frequencies; scalar temperature0.5to2selectedbyNLL only. Fixed operating threshold=max calibrated probability among validation negatives (zero validation false positives); evaluate generalization, no safety guarantee.',
   evaluation='All22935alreadyadmitted2024H2origins, non-extreme nodes;labels loaded for scoring after model+calibration freeze. Both models share exactly the same examples and settings.',
   models=['SHORT90: exactexistingV12pre-origin90features','RECURRENCE103: SHORT90+13released-event-historyfeatures'],
   new_features=['Known node extreme-episode counts over1h,1day,7days,28days','log1pminutes since last known episode capped28days andnoepisodeflag','network mean episode counts over same4windows','known price-row coverage over1day,7days,28days'],
   availability='Episode starts require valid consecutive source rows, TRAINthresholds, and both final-version publication times plus interval end<=forecastcutoff. Counts use eventdeliverytimes within windows; unreleased events excluded. Feature coverage reported; missing history is not labelled no-event.',
   learner='One seed20260813; HGBbinaryclassifier80iterations,15leaves,minleaf50,lr.05,L2=1,noearlystop,classweightnone,checkpoint every10iterations. No oversampling or search.',
   success='AUPRC above short-history control, positive Brier skill versus TRAINfrequency, event recall>0 at validation-locked threshold with testFPR<=0.001. This is a diagnostic budget criterion, not a journal threshold. Report dates and false-positive consequences regardless.',
   freeze='Before evaluation labels, bind feature/weight/calibration/threshold hashes. No S0 pointforecast changed.'),
  theory=[dict(title='Beyond temperature scaling: Obtaining well-calibrated multiclass probabilities with Dirichlet calibration',venue='NeurIPS2019',url='https://papers.neurips.cc/paper_files/paper/2019/hash/8ca01ea920679a0fe3728441494041b9-Abstract.html',use='Multiclass probability-map calibration; identity penalty choice is ours'),
          dict(title='Forecasting spikes in electricity prices',venue='International Journal of Forecasting2012',doi='10.1016/j.ijforecast.2011.02.019',url='https://www.ncer.edu.au/papers/documents/WPNo70.pdf',use='Occurrence as conditional hazard and interevent timing; our HGB is an information probe, not a reproduction of ACH'),
          dict(title='The modeling and forecasting of extreme events in electricity spot markets',venue='International Journal of Forecasting2014',url='https://www.sciencedirect.com/science/article/pii/S0169207014000089',use='Recent extreme-event timings and covariates can help intensity prediction; publisherabstract/introductioninspected; no guarantee forCAISO')],
  resources=dict(single_worker=True,threads=1,launch_gib=5,runtime_gib=4,max_numeric_seconds=7200,artifacts=str(ART),periodic_wakeups=False),
  core_elements_preserved=True,independent_targets_read=False,automatic_main_result_replacement=False)
 write(HERE/'PROTOCOL.json',p)
 print('Registered V15 finite calibration and onset information checks')
if __name__=='__main__':main()
