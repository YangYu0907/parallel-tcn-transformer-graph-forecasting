"""Keep all directions and separate development promotion from confirmation."""
import sys
import gate as g

def main():
    g.verify()
    with g.exclusive('channel_summary'):
        np,torch,limiter=g.runtime()
        sys.path.append(str(g.ROOT/'common_sampling_evaluation_20260923'))
        import reductions as red
        from compiled_data import CompiledData
        data=CompiledData(str(g.MANIFEST));protocol=g.read(g.HERE/'PROTOCOL.json')
        new={};old={};all_rows=[]
        for seed in protocol['seeds']:
            run=g.HERE/'runs'/str(seed);r=g.read(run/'completion.json');a=g.read(run/'audit.json')
            g.need(a['status']=='passed' and a['completion_sha256']==g.sha(run/'completion.json'),'Case audit stale')
            g.need(g.sha(r['evaluation'])==r['evaluation_sha256'],'Prediction changed')
            with np.load(r['evaluation']) as z:new[seed]={k:z[k].copy() for k in z.files}
            all_rows.append(dict(seed=seed,model='CHANNEL',selected_epoch=r['selected_epoch'],panels=r['panels']))
        for c in protocol['immutable_controls']:
            g.need(g.sha(c['evaluation'])==c['evaluation_sha256'],'Comparator prediction changed')
            with np.load(c['evaluation']) as z:arr={k:z[k].copy() for k in z.files}
            g.need(np.array_equal(arr['origins'],new[c['seed']]['origins']) and np.array_equal(arr['truth'],new[c['seed']]['truth']), 'Comparator panel/truth differs')
            old[(c['seed'],c['variant'])]=arr
            completion=g.read(c['completion'])
            all_rows.append(dict(seed=c['seed'],model=c['variant'],selected_epoch=completion['selected_epoch'],panels=completion['panels']))
        origins=new[protocol['seeds'][0]]['origins'];panels,blocks=red.panels(origins,data.origins['june'])
        metrics=('mae','rmse','near_h1_4_mae','h12_mae');comparisons=[]
        for comparator in ('FULL','EQUAL','CONCAT'):
            result=dict(comparator=comparator,panels={})
            for name,ix in panels.items():
                seed_rows=[]
                for seed in protocol['seeds']:
                    n=new[seed];o=old[(seed,comparator)]
                    nm=red.headline((n['prediction']-n['truth'])[ix]);om=red.headline((o['prediction']-o['truth'])[ix])
                    seed_rows.append(dict(seed=seed,channel=nm,control=om,improvement_percent={m:100*(om[m]-nm[m])/om[m] for m in metrics}))
                nmean={m:float(np.mean([r['channel'][m] for r in seed_rows])) for m in metrics}
                omean={m:float(np.mean([r['control'][m] for r in seed_rows])) for m in metrics}
                # Calendar-day clusters keep all overlapping forecasts and seeds together.
                day=data.times[origins[ix]]//86400;days=np.unique(day)
                newabs=np.mean([np.abs(new[s]['prediction'][ix]-new[s]['truth'][ix]).mean((1,2)) for s in protocol['seeds']],axis=0)
                oldabs=np.mean([np.abs(old[(s,comparator)]['prediction'][ix]-old[(s,comparator)]['truth'][ix]).mean((1,2)) for s in protocol['seeds']],axis=0)
                ns=np.array([newabs[day==d].sum() for d in days]);os=np.array([oldabs[day==d].sum() for d in days]);counts=np.array([(day==d).sum() for d in days])
                rng=np.random.default_rng(20260927);pick=rng.integers(0,len(days),(2000,len(days)))
                nboot=ns[pick].sum(1)/counts[pick].sum(1);oboot=os[pick].sum(1)/counts[pick].sum(1)
                ci=np.quantile(100*(oboot-nboot)/oboot,[.025,.975]).tolist()
                result['panels'][name]=dict(channel_mean=nmean,control_mean=omean,seed_results=seed_rows,
                    improvement_percent={m:100*(omean[m]-nmean[m])/omean[m] for m in metrics},
                    exploratory_MAE_CI95=ci,observed_UTC_dates=len(days),confirmatory_significance_claim=False)
            comparisons.append(result)
        full=comparisons[0];concat=comparisons[2]
        protection=all(full['panels'][p]['channel_mean'][m]<=full['panels'][p]['control_mean'][m]+1e-8
                       for p in ('June3397','June284') for m in metrics)
        primary=(full['panels']['June3397']['improvement_percent']['mae']>0 and concat['panels']['June3397']['improvement_percent']['mae']>0)
        seed_consistency=sum(r['improvement_percent']['mae']>0 for r in full['panels']['June3397']['seed_results'])>=2
        summary=dict(status='three_channel_cases_numerically_audited',at=g.now(),comparisons=comparisons,
            promotion_checks=dict(primary_vs_FULL_and_CONCAT=primary,at_least_two_seeds_vs_FULL=seed_consistency,
                                  original_eight_mean_headlines_preserved=protection),
            development_gate_passed=bool(primary and seed_consistency and protection),
            all_cases=all_rows,scope='Exploratory TRAIN/June only; prior H1 and Europe2016 tests were inspected before amendment',
            new_test_targets_read=False,independent_confirmation_complete=False,
            future_test_status=g.read(g.HERE/'FUTURE_TEST_METADATA.json')['status'],
            next_action='Report all comparisons. No automatic extra model, graph modification, search, or test reuse.')
        g.write(g.HERE/'summary.json',summary)
        print(__import__('json').dumps(dict(status=summary['status'],development_gate_passed=summary['development_gate_passed'])))
if __name__=='__main__':main()
