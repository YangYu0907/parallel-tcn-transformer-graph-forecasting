"""Meaningful join/state/reduction checks; synthetic data only."""
import sys, math
import gate
def main():
    with gate.exclusive('twenty_case_synthetic_qa'):
        np,limiter=gate.runtime();r=gate.load_module('vector_qa',gate.COMMON/'reductions.py');a=gate.load_module('scalar_qa',gate.COMMON/'audit.py')
        dense=np.arange(24,60,dtype=np.int64);reg=dense[[0,12,24]]
        ids,blocks=r.panels(dense,reg);oi,ob=a.panels_oracle(dense,reg)
        gate.need(list(blocks)==ob and all(list(ids[k])==oi[k] for k in ids),'Panel oracle')
        error=np.broadcast_to(np.arange(1,13,dtype=np.float64),(36,30,12)).copy();states=np.zeros_like(error,dtype=np.uint8)
        expected=r.breakdown(error,states,dense);a.compare(expected,a.oracle_breakdown(error,states,dense))
        gate.need(expected['mae']==6.5 and expected['near_h1_4_mae']==2.5 and expected['h12_mae']==12 and abs(expected['rmse']-math.sqrt(650/12))<1e-12,'Known answer')
        gate.need(expected['by_state'][5]['mae'] is None and expected['by_state'][5]['count']==0,'Empty state')
        truth=np.broadcast_to(np.array([0.,1.,2.,3.]*3),(2,30,12)).copy()
        last=np.zeros((2,30));last[1]=3.;center=np.zeros(30);scale=np.ones(30);thresholds=np.array([[1.]*30,[2.]*30])
        codes=r.codes(truth,last,center,scale,thresholds)
        gate.need(codes[0,0].tolist()==[0,0,1,2]*3 and codes[1,0].tolist()==[3,3,4,5]*3,'Strict threshold and prior active semantics')
        sys.path.insert(0,str(gate.OLD));old=gate.load_module('join_qa',gate.OLD/'controls_summary.py')
        gate.need(old.origin_join([30,50,10,40,20],[20,30,10])==[4,0,2],'Nonprefix join')
        for source,desired in [([1,1],[1]),([1,2],[3]),([1,2],[1,1])]:
            try:old.origin_join(source,desired)
            except RuntimeError:pass
            else:raise RuntimeError('Bad origin accepted')
        bad=error.copy();bad[0,0,0]=np.nan
        try:r.headline(bad)
        except ValueError:pass
        else:raise RuntimeError('NaN accepted')
        gate.need('torch' not in sys.modules,'Torch import')
        sources={gate.rel(p):gate.sha(p) for p in list(gate.HERE.glob('*.py'))+[gate.COMMON/'reductions.py',gate.COMMON/'audit.py',gate.OLD/'controls_summary.py',gate.OLD/'panel_gate.py']}
        gate.write(gate.HERE/'synthetic_qa.json',dict(status='passed',at=gate.now(),sources=sources,
            checks=['panel_membership_oracle','known_answer_metrics','independent_group_reductions','explicit_empty_groups','threshold_equality','past_state_encoding','permuted_nonprefix_join','duplicate_source_rejected','missing_origin_rejected','duplicate_destination_rejected','nonfinite_rejected'],
            real_array_payloads_read=False,model_calls=0,heldout_targets_read=False))
        print('Synthetic checks passed')
if __name__=='__main__':main()
