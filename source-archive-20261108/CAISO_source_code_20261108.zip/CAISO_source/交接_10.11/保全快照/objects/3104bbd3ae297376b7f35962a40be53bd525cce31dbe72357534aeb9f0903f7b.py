from common import *
def main():
    with gate.exclusive('V9 causal TRAIN episode grouping and admission'):
        np,lim=gate.runtime(False);import modelmath as mm
        checks=mm.qa();ad=gate.read(V7/'DATA_ADMISSION.json')
        for p,h in ad['artifacts'].items():assert gate.sha(p)==h,p
        for p,h in gate.read(B/'adaptive_experts_v4_20260929/TRAIN_SOURCE_AUDIT.json')['bindings'].items():assert gate.sha(p)==h,p
        m=gate.read(B/'phase_sampling_support_v3_20260923/dataset/ADDITIVE/manifest.json');paths={k:gate.resolve(v['path']) for k,v in m['artifacts'].items()}
        sc=gate.read(paths['scalers.json']);th=gate.read(paths['state_thresholds.json'])
        with np.load(A7/'TRAIN_features.npz') as f:tr={k:f[k] for k in f.files}
        cache=np.load(paths['features.npy'],mmap_mode='r');seconds=np.load(paths['timestamps_seconds.npy'],mmap_mode='r');end=int(tr['origins'].max())
        onset=np.full(len(tr['origins']),-1,int)
        for n in range(30):
            ix=np.flatnonzero(tr['nodes']==n);z=(np.asarray(cache[:end,n,0],dtype=np.float64)*sc['price_scale'][0][n][0]+sc['price_center'][0][n][0]-th['center'][n])/th['thresholds'][1][n]
            seq=mm.onset(z,cache[:end,n,4]>0,seconds[:end]);onset[ix]=seq[tr['origins'][ix]-1];tick()
        assert (onset>=0).all(),'Observed extreme TRAIN row has missing price or invalid episode'
        fit=tr['fit'];keys=np.column_stack([tr['nodes'][fit],onset[fit]])
        unique,inv,counts=np.unique(keys,axis=0,return_inverse=True,return_counts=True)
        weights=np.ones(len(onset));weights[fit]=1/np.sqrt(counts[inv]);weights[fit]/=weights[fit].mean()
        save(ART/'episodes.npz',origins=tr['origins'],nodes=tr['nodes'],onset=onset,pair_weights=weights,fit=fit,cal=tr['cal'])
        gate.write(HERE/'EPISODE_SUPPORT.json',dict(at=gate.now(),fit_pairs=int(fit.sum()),fit_episodes=len(unique),capped_history_pairs_resolved=int((tr['duration'][fit]==288).sum()),max_pairs=int(counts.max()),top10_fraction=float(np.sort(counts)[-10:].sum()/fit.sum()),effective_count=float(counts.sum()**2/(counts*counts).sum()),raw_extreme_fraction=float((tr['classes'][fit]==2).mean()),weighted_extreme_fraction=float(np.average((tr['classes'][fit]==2).mean(1),weights=weights[fit])),weight_range=[float(weights[fit].min()),float(weights[fit].max())],independent_events_caution='node episodes can be cross-node dependent; not independent market-event count'))
        deps=[HERE/'PROTOCOL.json',A7/'TRAIN_features.npz',A7/'H1_features.npz',ART/'episodes.npz',V7/'DATA_ADMISSION.json',V7/'TRAIN_CALIBRATION.json',V7/'AUDIT.json',B/'adaptive_experts_v4_20260929/FOLDS.json',A4/'panel.npz',paths['state_thresholds.json'],paths['scalers.json']]
        for s in SEEDS:deps.extend([A7/'predictions'/f'{s}.npz',A4/'experts'/f'{s}.npz',A5/'models'/f'{s}_distributions.npz'])
        source={str(p):gate.sha(p) for p in deps};write(HERE/'SOURCE_BINDINGS.json',dict(at=gate.now(),bindings=source))
        write(HERE/'DATA_ADMISSION.json',dict(at=gate.now(),status='passed_before_fit',inherit=V7.as_posix(),actual_input_hashes_inherited=True,causal_onset=True,new_test_targets_read=False,development_only=True))
        write(HERE/'QA.json',dict(at=gate.now(),status='passed',checks=checks))
        code=[HERE/n for n in ('common.py','modelmath.py','worker.py','audit.py','manager.py','register.py')]
        code.extend([HERE/'QA.json',HERE/'DATA_ADMISSION.json',HERE/'SOURCE_BINDINGS.json',HERE/'PROTOCOL.json',T/'gate.py'])
        write(HERE/'EXECUTION_SEAL.json',dict(at=gate.now(),bindings={str(p):gate.sha(p) for p in code}))
        print(json.dumps(gate.read(HERE/'EPISODE_SUPPORT.json')))
if __name__=='__main__':main()
