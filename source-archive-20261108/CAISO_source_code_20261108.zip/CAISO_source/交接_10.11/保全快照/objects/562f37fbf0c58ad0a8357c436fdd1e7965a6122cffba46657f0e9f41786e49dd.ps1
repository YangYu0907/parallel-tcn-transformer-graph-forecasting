﻿param([switch]$CheckOnly,[switch]$SelfTest)
$ErrorActionPreference='Stop'
$taskRoot=Split-Path -Parent $PSScriptRoot
$branchRoot=Split-Path -Parent $taskRoot
$repoRoot=Split-Path -Parent $branchRoot
$sharedLock='D:\Desktop\数据科学_论文\研究优化_20260818\logs\NEURAL_RUN.lock'
Add-Type @'
using System;
using System.Runtime.InteropServices;
public static class EnergyMemoryCheck {
 [StructLayout(LayoutKind.Sequential)] public struct Memory {
  public uint length, load;
  public ulong totalPhys, availPhys, totalPage, availPage, totalVirtual, availVirtual, extended;
 }
 [DllImport("kernel32.dll", SetLastError=true)] public static extern bool GlobalMemoryStatusEx(ref Memory value);
 public static double[] Read() {
  var value=new Memory();value.length=(uint)Marshal.SizeOf(typeof(Memory));
  if(!GlobalMemoryStatusEx(ref value))throw new Exception("Memory query failed");
  return new[]{value.availPhys/1073741824.0,value.availPage/1073741824.0};
 }
}
'@
function Write-Receipt($name,$value) {
 $path=Join-Path $PSScriptRoot $name
 $temp=Join-Path $PSScriptRoot ([guid]::NewGuid().ToString('N')+'.tmp')
 $value | ConvertTo-Json -Depth 8 | Set-Content -LiteralPath $temp -Encoding UTF8
 Move-Item -LiteralPath $temp -Destination $path -Force
}
function Read-State {
 $pause=Get-Content -LiteralPath (Join-Path $repoRoot 'RESEARCH_PAUSED.json') -Raw -Encoding UTF8 | ConvertFrom-Json
 $stopped=$pause.stop_preparation_and_training -or $pause.status -ne 'resumed_by_user'
 foreach($rootPath in @($branchRoot,$taskRoot)) {
  foreach($marker in @('STOP_REQUESTED','STOP_REQUESTED.json')) {
   if(Test-Path -LiteralPath (Join-Path $rootPath $marker)) {$stopped=$true}
  }
 }
 $memory=[EnergyMemoryCheck]::Read()
 [ordered]@{at=[DateTime]::UtcNow.ToString('o');physical_GiB=$memory[0];commit_GiB=$memory[1];paused=[bool]$stopped;
  manager_lock=[bool](Test-Path -LiteralPath (Join-Path $taskRoot 'queue\manager.lock'));
  numerical_lock=[bool](Test-Path -LiteralPath $sharedLock);
  headroom_ready=($memory[0] -ge 5.25 -and $memory[1] -ge 5.25)}
}
if($CheckOnly) { Read-State | ConvertTo-Json; exit 0 }
if($SelfTest) {
 $probe=Start-Process -FilePath 'powershell.exe' -ArgumentList '-NoProfile -Command "Start-Sleep -Seconds 3"' -WindowStyle Hidden -PassThru
 $probe.EnableRaisingEvents=$true
 $job=Register-ObjectEvent -InputObject $probe -EventName Exited -SourceIdentifier 'EnergyProbe'
 $item=Wait-Event -SourceIdentifier 'EnergyProbe' -Timeout 15
 if(-not $item) {throw 'Native process exit event probe failed'}
 Remove-Event -EventIdentifier $item.EventIdentifier
 Unregister-Event -SourceIdentifier 'EnergyProbe'
 Write-Receipt 'event_selftest.json' @{status='passed';native_dotnet_process_exit=$true;at=[DateTime]::UtcNow.ToString('o')}
 $probe.Dispose();exit 0
}
$mutex=New-Object System.Threading.Mutex($false,'Local\CAISO_Energy_Resource_Resume_20260926')
if(-not $mutex.WaitOne(0)) {throw 'Existing resource event listener; duplicate rejected'}
$subscriptions=@()
$sourceId='EnergyResourceProcessStop_'+$PID
$session=[System.Diagnostics.Process]::GetCurrentProcess().SessionId
try {
 foreach($candidate in [System.Diagnostics.Process]::GetProcesses()) {
  try {
   if($candidate.Id -eq $PID -or $candidate.SessionId -ne $session -or $candidate.HasExited) {continue}
   $candidate.EnableRaisingEvents=$true
   $id=$sourceId+'_'+$candidate.Id
   $job=Register-ObjectEvent -InputObject $candidate -EventName Exited -SourceIdentifier $id
   $subscriptions+=@{id=$id;job=$job;process=$candidate}
  } catch { $candidate.Dispose() }
 }
 if($subscriptions.Count -eq 0) {throw 'No accessible current-session process exit sources'}
 Write-Receipt 'listener.json' ([ordered]@{pid=$PID;started=[DateTime]::UtcNow.ToString('o');mode='native_current_session_process_exit_events_no_timer';watched_processes=$subscriptions.Count;
  numerical_floor_preserved=5;launch_headroom=5.25;model_wakeups=$false;one_shot=$true})
 while($true) {
  $state=Read-State
  if(Test-Path -LiteralPath (Join-Path $taskRoot 'queue\completion.json')) {
   $done=Get-Content -LiteralPath (Join-Path $taskRoot 'queue\completion.json') -Raw -Encoding UTF8 | ConvertFrom-Json
   if($done.status -eq 'finite_european_train_valid_completed') {Write-Receipt 'resume_result.json' @{status='queue_already_completed'};break}
  }
  if($state.paused) {Write-Receipt 'resume_result.json' ([ordered]@{status='user_pause_respected';state=$state});break}
  if($state.headroom_ready -and -not $state.manager_lock -and -not $state.numerical_lock) {
   $queueState=Get-Content -LiteralPath (Join-Path $taskRoot 'queue\status.json') -Raw -Encoding UTF8 | ConvertFrom-Json
   if($queueState.event -ne 'step_stopped_or_failed' -or -not $queueState.reason.Contains('Resource floor:')) {throw 'Current queue state is not a diagnosed resource block'}
   $failure=Join-Path $taskRoot 'queue\failure.json'
   if(Test-Path -LiteralPath $failure) {
    $record=Get-Content -LiteralPath $failure -Raw -Encoding UTF8 | ConvertFrom-Json
    if(-not $record.reason.Contains('Resource floor:')) {throw 'Latest failure is not a resource block; manual diagnosis required'}
    Copy-Item -LiteralPath $failure -Destination (Join-Path $PSScriptRoot ('failure_before_resume_'+[guid]::NewGuid().ToString('N')+'.json'))
   }
   & (Join-Path $taskRoot 'launch.ps1') | Out-Null
   $launch=Get-Content -LiteralPath (Join-Path $taskRoot 'queue\launch.json') -Raw -Encoding UTF8 | ConvertFrom-Json
   Write-Receipt 'resume_result.json' ([ordered]@{status='launch_dispatched_after_resource_event';state=$state;launch=$launch;
      no_guard_bypass=$true;existing_results_reused=$true;next_case='audit existing first seed before any additional training'})
   break
  }
  # Native event wait. No timer, scheduler, sleep loop or model message.
  $event=Wait-Event
  Remove-Event -EventIdentifier $event.EventIdentifier
 }
} catch {
 Write-Receipt 'resume_result.json' ([ordered]@{status='listener_failed';at=[DateTime]::UtcNow.ToString('o');error=$_.Exception.Message})
 throw
} finally {
 foreach($entry in $subscriptions) {Unregister-Event -SourceIdentifier $entry.id;$entry.process.Dispose()}
 $mutex.ReleaseMutex();$mutex.Dispose()
}
