"""Recheck existing chronological receipts and actual release arrays, no prices."""
import support as s
def oldpath(p):
 text=str(p).replace('\\','/');marker='CAISO_temporary_storage/'
 return s.base.T/text.split(marker,1)[1] if marker in text else s.resolve(text)
def main():
 s.guard(True)
 with s.base.numeric('output_gate_prefix_release_audit'):
  import numpy as np
  source=s.B/'spike_specialist_v7_20260930/SOURCE_BINDINGS.json';d=s.read(source)
  verified=[]
  for name,h in d['bindings'].items():
   p=oldpath(name);assert s.sha(p)==h,p;verified.append(dict(path=str(p),sha256=h))
  adpath=s.B/'spike_specialist_v7_20260930/DATA_ADMISSION.json';ad=s.read(adpath)
  for name,h in ad['artifacts'].items():assert s.sha(oldpath(name))==h
  v4=s.base.T/'adaptive_experts_v4_20260929'
  with np.load(v4/'panel.npz',allow_pickle=False) as z:
   cutoff=z['cutoff'];available=z['available'];origins=z['origins']
  rows=[];total_releases=0
  for f in s.read(s.B/'adaptive_experts_v4_20260929/FOLDS.json'):
   fit=np.asarray(f['fit']);cal=np.asarray(f['calibration']);ev=np.asarray(f['evaluation']);tr=np.asarray(f['train'])
   fit_before_cal=bool(available[fit].max()<=cutoff[cal[0]])
   train_before_ev=bool(available[tr].max()<=cutoff[ev[0]])
   assert train_before_ev
   checks=[]
   for seed in [20260813,20260814,20260815]:
    path=v4/'folds'/f'{seed}_fold{f["id"]}.npz'
    receipt=s.read(s.B/'adaptive_experts_v4_20260929/receipts'/f'{seed}_fold{f["id"]}.json');assert s.sha(path)==receipt['sha256']
    with np.load(path,allow_pickle=False) as z:
     releases=z['releases'];assert np.array_equal(z['fit_indices'],fit);assert np.array_equal(z['calibration_indices'],cal);assert np.array_equal(z['eval_indices'],ev)
    assert np.all(releases[:,2]<=releases[:,3]) and np.all(cutoff[releases[:,0]]<releases[:,3])
    total_releases+=len(releases);checks.append(dict(seed=seed,release_rows=len(releases),release_order_verified=True))
   rows.append(dict(fold=f['id'],max_fit_label_publication=int(available[fit].max()),first_calibration_cutoff=int(cutoff[cal[0]]),
     fit_before_first_calibration=fit_before_cal,max_training_label_publication=int(available[tr].max()),
     first_evaluation_cutoff=int(cutoff[ev[0]]),training_before_evaluation=train_before_ev,release_checks=checks))
  with np.load(s.base.T/'spike_specialist_v7_20260930/TRAIN_features.npz',allow_pickle=False) as z:
   oo=z['origins'];fit=z['fit'];cal=z['cal']
  assert (oo+12<=210528).all() and not (fit&cal).any()
  strict_train_cal=bool(int(oo[fit].max())+12<int(oo[cal].min()))
  complete=all(r['fit_before_first_calibration'] for r in rows) and strict_train_cal
  s.write('PREFIX_RESULT.json',dict(status='checked',at=s.now(),folds=rows,causal_release_rows=total_releases,
   TRAIN_specialist_fit_max_origin=int(oo[fit].max()),TRAIN_specialist_cal_min_origin=int(oo[cal].min()),
   TRAIN_fit_before_calibration=strict_train_cal,fit_and_calibration_disjoint=True,TRAIN_before_H1=True,
   component_source_bindings_verified=verified,existing_prefix_boundary_checks_passed=complete,
   interpretation='Existing H1 chronological release evidence; many earlier development selections used H1, so this is not independent confirmation.',
   remaining='Full candidate must use precommitted whole-output V7 per row and verified earlier-only gate inputs; no transferred V7 residual on graph/local mixtures.',
   price_targets_read=False,model_fits=0,protected_verified=s.protected()))
 print(__import__('json').dumps(dict(prefix_boundary_checks_passed=complete,release_rows=total_releases,source_bindings=len(verified),folds=rows)))
if __name__=='__main__':main()
