"""Finite V7 deployment confirmation. Freeze -> inputs -> predictions -> release -> score.

The terminal chronological development state is carried forward without September
feedback. This deployment evaluation is distinct from the historical online folds.
No fitting, threshold selection, or score-based panel selection exists here.
"""
from pathlib import Path
from datetime import datetime, timezone
import csv, io, os, sys, json, pickle, hashlib, uuid, zipfile, gc, math, traceback
HERE=Path(__file__).resolve().parent; B=HERE.parent
ART=Path('C:/Users/于阳/CAISO_temporary_storage')/HERE.name
V17=B/'conditional_risk_v17_20260930'; V7=B/'spike_specialist_v7_20260930'
TMP=ART.parent; A4=TMP/'adaptive_experts_v4_20260929'; A5=TMP/'adaptive_experts_v5_20260929'; A7=TMP/V7.name
sys.path.insert(0,str(B/'context_expert_v1_20260929')); import gate
SEEDS=[20260813,20260814,20260815]
FIELDS=[0,21,22,23,24,15,16,25,26,27,28,8,9,10,11,12,13]
np=None

def write(p,v):
    p=Path(p); assert p.resolve().is_relative_to(HERE) or p.resolve().is_relative_to(ART)
    p.parent.mkdir(parents=True,exist_ok=True); t=p.with_name('.'+p.name+'.'+uuid.uuid4().hex)
    t.write_text(json.dumps(v,ensure_ascii=False,indent=2,allow_nan=False),encoding='utf-8');os.replace(t,p)
def save(p,**v):
    p=Path(p);p.parent.mkdir(parents=True,exist_ok=True);t=p.with_name('.'+p.name+'.'+uuid.uuid4().hex)
    with t.open('wb') as f:np.savez(f,**v)
    os.replace(t,p)
def read(p):return gate.read(p)
def pulse(**kw):
    gate.guard()
    for d in (HERE,HERE/'queue'):
        for n in ('STOP_REQUESTED','STOP_REQUESTED.json'):assert not (d/n).exists(),'User stop requested'
    if kw:write(HERE/'queue/status.json',dict(at=gate.now(),pid=os.getpid(),**kw))
def legacy(label,folder,file):
    old=sys.modules.get('common');c=gate.load(label+'_common',folder/'common.py');sys.modules['common']=c
    try:m=gate.load(label,folder/file)
    finally:
        if old is None:sys.modules.pop('common',None)
        else:sys.modules['common']=old
    m.np=np;return m
def load(p):
    with Path(p).open('rb') as f:return pickle.load(f)
def sec(s):return int(datetime.fromisoformat(s.replace('Z','+00:00')).timestamp())
def rows(p):
    with zipfile.ZipFile(p) as z:
        for n in z.namelist():
            if n.lower().endswith('.csv'):
                with z.open(n) as f:yield from csv.DictReader(io.TextIOWrapper(f,encoding='utf-8-sig'))
def verify(p):
    for f,h in p['bindings'].items():assert gate.sha(f)==h,('Frozen dependency changed',f)

def register():
    gate.boundary();assert not (HERE/'PROTOCOL.json').exists()
    source=read(V17/'source_admission/AUDIT.json');assert source['status']=='passed_separate_source_window_replay'
    access=read(V17/'PROJECT_ACCESS_REVIEW.json')
    parent=read(B/'guarded_confirmation_v1_20260929/evaluation/PROTOCOL.json')
    h1=read(B/'h1_final_evaluation_v1_20260927/FINAL_TEST_FREEZE.json')
    bindings={}
    def bind(p,h=None):
        p=Path(p);s=gate.sha(p);assert h is None or h==s,str(p);bindings[str(p)]=s
    for p,h in source['bindings'].items():bind(p,h)
    ledgers=[]
    for p in sorted((V17/'source_admission/audit_refresh').glob('*.json')):
        r=read(p);bind(p);bind(r['body'],r['sha256']);ledger=[]
        for row in rows(r['body']):
            stream={('RTM','PRC_INTVL_LMP'):'price',('RTD','SLD_FCST'):'rtd',('DAM','SLD_FCST'):'dam_load'}.get((r['params']['market_run_id'],row.get('REPORT_NAME')))
            if stream and row['STATUS']=='Push Completed' and row['OASIS_REC_STAT']=='V':
                ledger.append(dict(stream=stream,start=sec(row['INTERVAL_START_GMT']),end=sec(row['INTERVAL_END_GMT']),published=sec(row['PUBLICATION_DATE_GMT'])))
        out=HERE/'ledgers'/(p.stem+'.json');write(out,ledger);ledgers.append(str(out));bind(out)
    receipts=[]
    for p in sorted((V17/'source_queue/receipts').glob('*.json')):
        r=read(p);bind(p);bind(r['archive'],r['sha256'])
        rr=dict(r,archive_sha256=r['sha256'],job=dict(r['job'],entity=r['job']['params'].get('node','system')),original_receipt=str(p))
        out=HERE/'source_receipts'/p.name;write(out,rr);receipts.append(str(out));bind(out)
    models=[]
    for c in h1['cases']:
        if 'checkpoint' not in c:continue
        c=dict(c)
        for k in ('checkpoint','reference','completion','audit'):
            c[k]=str(gate.resolve(c[k]));bind(c[k],c[k+'_sha256'])
        models.append(c)
    for seed in SEEDS:
        files=[B/'adaptive_experts_v2_20260929/models'/f'{seed}_GB_DELTA.pkl',A4/'models'/f'{seed}_TAR_POOL.pkl',A4/'folds'/f'{seed}_fold3.npz',A4/'experts'/f'{seed}.npz',A5/'models'/f'{seed}_distributions.npz']
        files += [A4/'models'/f'{seed}_fold3_functional{k}.pkl' for k in range(2)]
        files += [A5/'models'/f'{seed}_destination{k}.pkl' for k in range(3)]
        files += [A7/'models'/f'{seed}_{v}_{task}.pkl' for v in ('CONTEXT','DURATION') for task in ('hazard','postexit')]
        for p in files:bind(p)
    for p in [A4/'panel.npz',A5/'H1_features.npz',A7/'H1_features.npz',V7/'TRAIN_CALIBRATION.json',V7/'RESULT.json',V7/'AUDIT.json',B/'adaptive_experts_v4_20260929/FOLDS.json',V17/'source_admission/AUDIT.json',V17/'PROJECT_ACCESS_REVIEW.json']:
        bind(p)
    for folder in ('spike_specialist_v7_20260930','adaptive_experts_v4_20260929','adaptive_experts_v5_20260929'):
        for p in (B/folder).glob('*.py'):bind(p)
    for p in [Path(__file__),B/'guarded_confirmation_v1_20260929/period_history.py',B/'energy_confirmation_v1_20260926/admission/bounded_history.py',B/'h1_feature_admission_v1_20260927/history.py']:
        bind(p)
    for k in ('scalers.json','state_thresholds.json','context_limits.json'):bind(parent['training_paths'][k])
    names=['V7_FROZEN','V7_DURATION','V7_FIXED','BASE_FROZEN']+[c['variant'] for c in models if c['seed']==SEEDS[0]]+['PERSISTENCE','DAILY_SEASONAL']
    p=dict(at=gate.now(),status='registered_before_numeric_new_period_access',candidate='V7_FROZEN',methods=names,seeds=SEEDS,models=models,
        origins_utc_seconds=source['candidates_utc_seconds'],nodes=parent['nodes'],tac=parent['tac'],age_caps=parent['age_caps'],training_paths=parent['training_paths'],dataset_manifest=parent['dataset_manifest'],
        source_receipts=receipts,publication_ledgers=ledgers,bindings=bindings,
        scope='All186 source-qualified September2026 origins on12 target-start UTC dates from the previously registered696 origins; no price/error exclusions.',
        version_scope=source['version_scope'],
        deployment='V7 CONTEXT specialist and all three backbone seeds retained. For nonextreme histories use latest chronological fold3 functional models, its pooled support bounds and end-of-development calibration state. Freeze state before September; no test-period feedback. This fixed deployment differs from online expanding-fold development evaluation and is labeled V7_FROZEN.',
        checkpoint_rule='Use the last chronological available fold, never choose by accuracy. No new fitting, model, threshold, loss, or parameter search.',
        controls='V7_DURATION changes specialist context only; V7_FIXED uses frozen TRAIN destination proportions; BASE_FROZEN omits specialist. Other backbones are frozen reference models, not matched training of the specialist.',
        statistics=dict(primary='mean seed overall MAE',secondary=['RMSE','near H1-4 MAE','H12 MAE','TRAIN-low-volatility MAE'],bootstrap_replicates=2000,bootstrap_seed=73017,mean_block_days=2,
            family=[n for n in names if n!='V7_FROZEN'],test='two-sided centered paired calendar-aware stationary bootstrap; Holm over all preset MAE comparisons; unadjusted95% intervals',
            profiles='all seeds/nodes/horizons/months/six states and support counts retained'),
        target_access='All forecasts committed and separately audited before target arrays formed; only enumerated input dependencies allowed earlier.',test_targets_read=False,training_updates=0)
    write(HERE/'PROTOCOL.json',p)
    h=read(B/'HANDOFF.json');h.update(at=gate.now(),status='V7_confirmation_registered_manuscript_revision_active',current_authorized_work='Freeze retained V7; finish finite independent confirmation and complete evidence-based English manuscript. No further model search. Full state tables in supplement; no standalone S3 main discussion.',training_active=False,paper_drafting_paused=False,manuscript_polishing_paused=False,complete_research_experiment=False)
    h['v7_confirmation']=dict(protocol=str(HERE/'PROTOCOL.json'),status_path=str(HERE/'queue/status.json'),artifacts=str(ART));gate.write(B/'HANDOFF.json',h)
    print('Registered',len(p['origins_utc_seconds']),len(names),flush=True)

def inputs(p):
    ap=HERE/'INPUT_ADMISSION.json';xp=ART/'features.npy'
    if ap.exists():
        a=read(ap);assert gate.sha(xp)==a['features_sha256'];return
    sys.path.insert(0,str(B/'guarded_confirmation_v1_20260929'));from period_history import History,independent_numeric_check
    reader=History(p,pulse);causal=reader.check_future_invariance();origins=p['origins_utc_seconds'];items=[]
    ART.mkdir(parents=True,exist_ok=True);tmp=ART/'features.partial.npy'
    x=np.lib.format.open_memmap(tmp,mode='w+',dtype=np.float32,shape=(len(origins),288,30,29))
    try:
        for i,o in enumerate(origins):
            pulse(stage='input_reconstruction',completed=i,total=len(origins));xx=reader.feature(o)
            delta,ratio=independent_numeric_check(xx,reader.parts(o),reader.scalers,reader.tac,reader.caps);x[i]=xx
            items.append(dict(origin=o,sha256=hashlib.sha256(xx.tobytes()).hexdigest(),equation_max_delta=delta,tolerance_ratio=ratio))
        x.flush()
    finally:x._mmap.close()
    assert not xp.exists();os.replace(tmp,xp)
    write(HERE/'INPUT_RECEIPTS.json',items);write(HERE/'INPUT_READ_LOG.json',reader.source_receipts)
    write(ap,dict(at=gate.now(),status='passed',origins=len(origins),features_sha256=gate.sha(xp),protocol_sha256=gate.sha(HERE/'PROTOCOL.json'),causal=causal,new_target_arrays_formed=False))

def neural(p,x,torch):
    from models.factory import build_backbone
    from compiled_data import CompiledData
    data=CompiledData(p['dataset_manifest']);limits=read(data.paths['context_limits.json'])['limits']
    adapter=gate.load('v7confirm_external',B/'matched_external_v1_20260924/model_adapter.py');out={};receipts=[]
    for c in p['models']:
        path=ART/'predictions'/(c['id']+'.npz');rp=HERE/'prediction_receipts'/(c['id']+'.json')
        if rp.exists():
            assert gate.sha(path)==read(rp)['sha256'];out[(c['seed'],c['variant'])]=np.load(path)['prediction'];receipts.append(read(rp));continue
        pulse(stage='neural_inference',case=c['id'])
        m=adapter.build_model(c['variant'],c['seed'],limits) if c['variant'] in ('DLinear','iTransformer-H') else build_backbone(c['variant'],c['seed'],limits)
        cp=torch.load(c['checkpoint'],map_location='cpu',weights_only=False);m.load_state_dict(cp['state_dict'],strict=True);del cp;m.eval()
        with np.load(c['reference']) as ref:
            sel=np.array([0,len(ref['origins'])//2,len(ref['origins'])-1]);ii=np.searchsorted(data.origins['june_dense'],ref['origins'][sel]);xx,_=data.batch('june_dense',ii)
            with torch.no_grad():replay=m(torch.from_numpy(xx))['prediction'].numpy().astype(float)*data.scale[None,:,None]+data.center[None,:,None]
            delta=abs(replay-ref['prediction'][sel]);assert np.all(delta<=1e-4+1e-6*abs(ref['prediction'][sel])),c['id']
        a=np.empty((len(x),30,12));state={k:v.detach().clone() for k,v in m.state_dict().items()};rng=torch.get_rng_state().clone()
        with torch.no_grad():
            for i in range(0,len(x),4):
                pulse();a[i:i+4]=m(torch.from_numpy(np.array(x[i:i+4],copy=True)))['prediction'].numpy().astype(float)*data.scale[None,:,None]+data.center[None,:,None]
        assert all(torch.equal(v,state[k]) for k,v in m.state_dict().items()) and torch.equal(rng,torch.get_rng_state())
        assert np.isfinite(a).all();save(path,origins=p['origins_utc_seconds'],prediction=a);out[(c['seed'],c['variant'])]=a
        r=dict(case=c['id'],sha256=gate.sha(path),checkpoint_sha256=c['checkpoint_sha256'],june_replay_max_error=float(delta.max()),weights_and_rng_unchanged=True);write(rp,r);receipts.append(r)
        del m,state;gc.collect()
    write(HERE/'NEURAL_AUDIT.json',dict(status='passed',cases=receipts));return out

def dense(last):return np.column_stack([np.repeat(last[:,:,FIELDS].reshape(-1,len(FIELDS)),12,axis=0),np.tile((np.arange(12)+1)/12,len(last)*30)]).astype(np.float32)

def combine(p,x,outputs):
    m4=legacy('confirm_v4',B/'adaptive_experts_v4_20260929','worker.py')
    m5=legacy('confirm_v5',B/'adaptive_experts_v5_20260929','worker.py')
    m7=legacy('confirm_v7',V7,'worker.py');feat7=legacy('confirm_v7_features',V7,'prepare.py')
    sc=read(p['training_paths']['scalers.json']);th=read(p['training_paths']['state_thresholds.json']);scale=np.array(sc['price_scale'])[0,:,0];center=np.array(sc['price_center'])[0,:,0];q=np.array(th['thresholds'])
    last=np.array(x[:,-1]);raw=last[:,:,0]*scale+center;reg=m7.regime(last,sc,th);gbx=dense(last)
    with np.load(A4/'panel.npz') as z:dev={k:z[k] for k in z.files}
    fold=read(B/'adaptive_experts_v4_20260929/FOLDS.json')[-1];assert fold['id']==3
    support=dev['last'][fold['train']][:,:,[0,21,22]];support_lo=support.min((0,1));support_hi=support.max((0,1));current=last[:,:,[0,21,22]]
    allowed=~np.any((current<support_lo)|(current>support_hi),-1)
    oi=[];ni=[];fx=[];px=[];cx=[];dur=[]
    for i in range(len(x)):
        nodes=np.flatnonzero(reg[i]==2)
        if not len(nodes):continue
        hh=np.array(x[i]);f=m5.shape_features(hh[-72:,nodes,0],hh[-1,nodes],nodes,sc,q[1]);a,b,d=feat7.new_features(hh,nodes,sc,th)
        fx.append(f);px.append(np.column_stack([f,a]));cx.append(np.column_stack([f,a,b]));dur.append(d);oi.extend([i]*len(nodes));ni.extend(nodes.tolist())
    oi=np.array(oi,int);ni=np.array(ni,int);replay_records=[];allfiles={}
    if len(oi):fx=np.concatenate(fx);px=np.concatenate(px);cx=np.concatenate(cx);dur=np.concatenate(dur)
    with np.load(A7/'H1_features.npz') as z:hfeat={k:z[k] for k in z.files}
    with np.load(A5/'H1_features.npz') as z:oldfeat={k:z[k] for k in z.files}
    temps=read(V7/'TRAIN_CALIBRATION.json')['rows']
    for seed in SEEDS:
        pulse(stage='V7_fixed_deployment',seed=seed)
        full=outputs[(seed,'FULL')];persist=np.broadcast_to(raw[:,:,None],full.shape)
        gb=load(B/'adaptive_experts_v2_20260929/models'/f'{seed}_GB_DELTA.pkl')['model'].predict(gbx).reshape(full.shape)*scale.mean()+raw[:,:,None]
        tar=m4.tar_predict(load(A4/'models'/f'{seed}_TAR_POOL.pkl'),last,sc,reg)
        experts=np.stack([full,outputs[(seed,'DLinear')],persist,gb,tar],-1)
        X=np.column_stack([gbx,((full-persist)/scale[None,:,None]).ravel(),((experts[...,1]-full)/scale[None,:,None]).ravel()]).astype(np.float32)
        functions=np.stack([load(A4/'models'/f'{seed}_fold3_functional{k}.pkl')['model'].predict(X).reshape(full.shape) for k in range(2)],-1)
        # Freeze the last development fold's completed calibration state; no new-period labels.
        with np.load(A4/'folds'/f'{seed}_fold3.npz') as z:oldfunctions=z['functions']
        with np.load(A4/'experts'/f'{seed}.npz') as z:oldfull=z['experts'][...,0]
        cal=m4.Calibration();maxready=0
        for j in sorted(fold['calibration']+fold['evaluation']):
            for h in range(12):
                ready=int(dev['available'][j,h]);now=min(p['origins_utc_seconds'])-300;assert ready<=now
                residual=(dev['truth'][j,:,h]-oldfull[j,:,h])[:,None]-oldfunctions[j,:,h]
                cal.observe((j,h),int(dev['cutoff'][j]),ready,now,dev['observable_regime'][j],h,residual);maxready=max(maxready,ready)
        bias,count=cal.bias(min(p['origins_utc_seconds'])-300);groups=reg[:,:,None]*3+np.arange(12)[None,None,:]//4
        mean=functions[...,0]+bias[groups,0];median=functions[...,1]+bias[groups,1]
        w,_=m7.correction_weights(experts,mean,median,allowed[:,:,None]&(count[groups]>=3));base=(w*experts).sum(-1)
        # Base-only control falls back to FULL at active extremes, isolating specialist addition.
        base[reg==2]=full[reg==2]
        methods={c['variant']:outputs[(seed,c['variant'])] for c in p['models'] if c['seed']==seed}
        methods.update(BASE_FROZEN=base,PERSISTENCE=persist,DAILY_SEASONAL=np.asarray(x[:,:12,:,0],float).transpose(0,2,1)*scale[None,:,None]+center[None,:,None])
        with np.load(A5/'models'/f'{seed}_distributions.npz') as z:quant=z['quantiles'];prior=z['prior'];oldmus=z['mus']
        mu=np.empty((len(oi),12,3));mdelta=0.
        for k in range(3):
            model=load(A5/'models'/f'{seed}_destination{k}.pkl')['model']
            if len(oi):mu[:,:,k]=model.predict(m5.expand(fx)).reshape(-1,12)
            expected=oldmus[oldfeat['origin_index'],oldfeat['node'],:,k]
            got=model.predict(m5.expand(oldfeat['X'])).reshape(-1,12);d=float(abs(got-expected).max());assert d<1e-10;mdelta=max(mdelta,d)
        for variant,features in [('CONTEXT',cx),('DURATION',px),('FIXED',None)]:
            if variant=='FIXED':prob=np.broadcast_to(prior,(len(oi),12,3))
            else:
                preds={};hp={};row=next(r for r in temps if r['seed']==seed and r['variant']==variant)
                for task in ('hazard','postexit'):
                    temp=next(r['temperature'] for r in row['fit_log'] if r['task']==task)
                    model=load(A7/'models'/f'{seed}_{variant}_{task}.pkl')['model']
                    if len(oi):preds[task]=m7.temperature(model.predict_proba(m7.expand(features,dur)),temp)
                    hf=hfeat['context' if variant=='CONTEXT' else 'price'];hp[task]=m7.temperature(model.predict_proba(m7.expand(hf,hfeat['duration'])),temp)
                hprob,_=m7.survival_probabilities(hp['hazard'][:,1].reshape(-1,12),hp['postexit'].reshape(-1,12,3))
                with np.load(A7/'models'/f'{seed}_{variant}_probabilities.npz') as z:expected=z['probabilities'][hfeat['origin_index'],hfeat['node']]
                d=float(abs(hprob-expected).max());assert d<1e-10
                replay_records.append(dict(seed=seed,variant=variant,h1_probability_max_error=d,amplitude_max_error=mdelta))
                if len(oi):prob,_=m7.survival_probabilities(preds['hazard'][:,1].reshape(-1,12),preds['postexit'].reshape(-1,12,3))
            pred=base.copy()
            if len(oi):
                ratio=np.repeat(q[0,ni]/q[1,ni],12);sign=np.repeat(np.sign(raw[oi,ni]-np.array(th['center'])[ni]),12)
                am,aq=m7.mixture(mu.reshape(-1,3),quant,prob.reshape(-1,3),ratio,sign)
                am=am.reshape(-1,12)*q[1,ni,None]+np.array(th['center'])[ni,None];aq=aq.reshape(-1,12)*q[1,ni,None]+np.array(th['center'])[ni,None]
                f=full[oi,ni];chosen,weights=m7.specialist(f,am,aq)
                # Separately expressed bounded correction verifies the output algebra.
                u=am-f;v=aq-f;independent=f+np.where(u*v>0,.75*np.sign(u)*np.minimum(abs(u),abs(v)),0.)
                assert np.allclose(chosen,independent,atol=1e-10,rtol=1e-12)
                pred[oi,ni]=chosen
            name={'CONTEXT':'V7_FROZEN','DURATION':'V7_DURATION','FIXED':'V7_FIXED'}[variant];methods[name]=pred
            assert np.array_equal(pred[reg!=2],base[reg!=2])
        path=ART/'predictions'/f'{seed}_all.npz';save(path,origins=p['origins_utc_seconds'],**methods);allfiles[str(path)]=gate.sha(path)
        write(HERE/'deployment_state'/f'{seed}.json',dict(seed=seed,fold=3,pooled_support_lower=support_lo.tolist(),pooled_support_upper=support_hi.tolist(),calibration_bias=bias.tolist(),calibration_days=count.tolist(),last_feedback_publication=maxready,new_test_feedback=False))
    write(HERE/'COMBINER_AUDIT.json',dict(status='passed',specialist_replays=replay_records,active_node_origins=len(oi),nonextreme_preservation=True,independent_correction_arithmetic=True,forecast_files=allfiles))

def predict():
    global np
    p=read(HERE/'PROTOCOL.json');verify(p)
    with gate.exclusive('V7 frozen independent confirmation inputs and predictions'):
        np,torch,lim=gate.runtime();inputs(p);x=np.load(ART/'features.npy',mmap_mode='r')
        try:out=neural(p,x,torch);combine(p,x,out)
        finally:x._mmap.close()
        verify(p)
        bindings={str(z):gate.sha(z) for z in [HERE/'PROTOCOL.json',HERE/'INPUT_ADMISSION.json',HERE/'NEURAL_AUDIT.json',HERE/'COMBINER_AUDIT.json',ART/'features.npy']}
        bindings.update(read(HERE/'COMBINER_AUDIT.json')['forecast_files'])
        write(HERE/'ALL_PREDICTIONS_COMMITTED.json',dict(at=gate.now(),status='all_predictions_committed_before_target_array',bindings=bindings,new_test_targets_read=False))
        pulse(stage='predictions_complete_pending_separate_release_review')

def main():
    try:
        if sys.argv[1:] == ['register']:register()
        elif sys.argv[1:] == ['predict']:predict()
        else:raise ValueError('register or predict')
    except BaseException as exc:
        write(HERE/'queue/STOP.json',dict(at=gate.now(),error=repr(exc),traceback=traceback.format_exc(),artifacts_preserved=True));raise
if __name__=='__main__':main()
