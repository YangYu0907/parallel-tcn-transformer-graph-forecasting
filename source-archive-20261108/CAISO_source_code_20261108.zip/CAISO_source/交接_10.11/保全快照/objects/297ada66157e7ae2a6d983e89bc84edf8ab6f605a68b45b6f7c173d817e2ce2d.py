"""Separate source-only recomputation. Never reads prices, targets, or forecast MW numbers."""
from pathlib import Path
from datetime import datetime, timezone
from collections import Counter, defaultdict
import csv, hashlib, io, json, sys, zipfile

HERE = Path(__file__).resolve().parent
sys.path.insert(0, str(HERE.parent / 'context_expert_v1_20260929'))
import gate

def stamp(value):
    dt = datetime.fromisoformat(value.replace('Z', '+00:00'))
    assert dt.tzinfo is not None, 'Timezone missing'
    return int(dt.timestamp())

def rows(path):
    data = Path(path).read_bytes()
    if zipfile.is_zipfile(io.BytesIO(data)):
        with zipfile.ZipFile(io.BytesIO(data)) as archive:
            for item in archive.infolist():
                assert item.filename.lower().endswith('.csv')
                assert item.file_size < 60_000_000
                with archive.open(item) as f:
                    yield from csv.DictReader(io.TextIOWrapper(f, encoding='utf-8-sig'))
    else:
        yield from csv.DictReader(io.StringIO(data.decode('utf-8-sig')))

def main():
    q = HERE / 'renewable_queue'
    with gate.exclusive('V16 separate metadata/content audit; no target reader or model fitting'):
        result = gate.read(q / 'completion.json')
        bindings = {str(q / 'completion.json'): gate.sha(q / 'completion.json')}
        receipts = []
        for path, sha in result['source_receipt_bindings'].items():
            assert gate.sha(path) == sha
            receipt = gate.read(path)
            assert gate.sha(receipt['body']) == receipt['sha256']
            bindings[path] = sha
            receipts.append(receipt)
        meta = []
        for r in result['inherited_metadata_bindings']:
            assert gate.sha(r['receipt']) == r['receipt_sha256']
            assert gate.sha(r['body']) == r['sha256']
            meta.append((r['body'], r['params']))
        meta.extend((r['body'], r['job']['params']) for r in receipts
                    if r['job']['params']['queryname'] == 'ATL_PUB')
        parse_query = lambda s: int(datetime.strptime(s, '%Y%m%dT%H:%M%z').timestamp())
        intervals = sorted((parse_query(p['startdatetime']), parse_query(p['enddatetime'])) for _, p in meta)
        end = stamp('2023-05-31T00:00:00Z')
        for start, stop in intervals:
            assert start <= end, 'Query coverage gap'
            end = max(end, stop)
        assert end >= stamp('2026-10-01T00:00:00Z')
        latest = {}
        versions = Counter()
        for body, params in meta:
            gate.guard()
            for r in rows(body):
                if (r.get('REPORT_NAME'), r.get('STATUS'), r.get('OASIS_REC_STAT')) != ('SLD_REN_FCST', 'Push Completed', 'V'):
                    continue
                a, b, publication = map(stamp, [r['INTERVAL_START_GMT'], r['INTERVAL_END_GMT'], r['PUBLICATION_DATE_GMT']])
                assert a % 3600 == b % 3600 == 0 and b > a
                versions[r['ATLPUBVERSION']] += 1
                for hour in range(a, b, 3600):
                    latest[hour] = max(publication, latest.get(hour, -1))
        assert dict(versions) == result['publication_versions']
        six = {(h, k) for h in ('NP15', 'SP15', 'ZP26') for k in ('Wind', 'Solar')}
        five = six - {('ZP26', 'Wind')}
        content, outside, first, last = defaultdict(dict), Counter(), {}, {}
        missing = duplicates = 0
        for receipt in receipts:
            if receipt['job']['params']['queryname'] != 'SLD_REN_FCST':
                continue
            for r in rows(receipt['body']):
                pair = (r['TRADING_HUB'], r['RENEWABLE_TYPE'])
                if pair not in six:
                    outside['|'.join(pair)] += 1
                    continue
                assert r['MARKET_RUN_ID'] == 'DAM' and r['XML_DATA_ITEM'] == 'RENEW_FCST_DA_MW'
                hour, stop = map(stamp, [r['INTERVALSTARTTIME_GMT'], r['INTERVALENDTIME_GMT']])
                assert hour % 3600 == 0 and stop - hour == 3600
                token = r['MW'].strip()
                if token.lower() in ('', 'nan', 'none', 'null', 'inf', '-inf'):
                    missing += 1
                    continue
                digest = hashlib.sha256(token.encode()).hexdigest()
                if pair in content[hour]:
                    assert content[hour][pair] == digest
                    duplicates += 1
                content[hour][pair] = digest
                first[pair] = min(hour, first.get(pair, hour))
                last[pair] = max(hour, last.get(pair, hour))
        assert dict(outside) == result['outside_registered_region_rows']
        assert missing == result['missing_value_tokens'] and duplicates == result['duplicate_identical_rows']
        admitted = {h: latest[h] for h, values in content.items() if six.issubset(values) and h in latest}
        production = gate.read(q / 'SOURCE_HOUR_ADMISSION.json')
        assert {r['interval_start']: r['last_publication'] for r in production['hours']} == admitted
        assert len(content) == result['forecast_hours'] and len(admitted) == result['complete_hours']
        np, limiter = gate.runtime(False)
        data = gate.read(HERE.parent / 'chronological_expert_pilot_v14_20260930/DATA.json')
        times = np.load(data['timestamps'], mmap_mode='r')
        coverage = {}
        for label, required in [('registered_six', six), ('availability_only_five_diagnostic', five)]:
            eligible = {h: latest[h] for h, values in content.items() if required.issubset(values) and h in latest}
            summary = {}
            for split in ('train', 'valid', 'evaluation'):
                origins = np.load(Path(data['directory']) / (split + '.npy'))
                selected_dates = set()
                n = 0
                for origin in origins:
                    cutoff = int(times[origin - 1])
                    needed = {int(t) // 3600 * 3600 for t in times[origin:origin + 12]}
                    if all(h in eligible and eligible[h] <= cutoff for h in needed):
                        n += 1
                        selected_dates.add(cutoff // 86400)
                summary[split] = dict(registered_origins=len(origins), metadata_and_forecast_content_eligible=n,
                                      eligible_issue_dates=len(selected_dates))
            coverage[label] = summary
        assert coverage['registered_six'] == result['development_origin_coverage']
        utc = lambda s: datetime.fromtimestamp(s, timezone.utc).isoformat()
        output = dict(at=gate.now(), status='source_counts_and_bindings_recomputed',
                      audit_type='Separate implementation, same agent; not external reviewer certification',
                      script_sha256=gate.sha(__file__), bindings=bindings,
                      publication_coverage='Continuous queried windows through retrieval; future query endpoint does not certify future activity',
                      source_hours=len(content), complete_six_hours=len(admitted), coverage=coverage,
                      field_presence={('|'.join(p)): dict(first=utc(first[p]), last=utc(last[p])) for p in sorted(first)},
                      outside_registered_region_rows=dict(outside),
                      alternative_contract='Five-field coverage is source feasibility only, not selected by target values; no feature contract or model trained.',
                      forecast_numeric_values_decoded=False, new_test_targets_read=False, training_started=False,
                      new_independent_period_admitted=False)
        gate.write(q / 'SOURCE_AUDIT.json', output)
        print(json.dumps(dict(status=output['status'], coverage=coverage), ensure_ascii=True))

if __name__ == '__main__':
    main()
