"""Pure functions for locked paired evaluation; no model or data-file access.

Inputs contain losses averaged across *individual* seeds, never ensemble
predictions. Synthetic QA must pass in the shared numerical slot before use.
"""
from datetime import date
from math import erfc,sqrt
import numpy as np

def holm(pvalues):
    p=np.asarray(pvalues,dtype=np.float64)
    if p.ndim!=1 or not np.isfinite(p).all() or ((p<0)|(p>1)).any():
        raise ValueError('Invalid p-values')
    order=np.argsort(p,kind='stable');adjusted=np.empty_like(p);largest=0.
    for rank,index in enumerate(order):
        largest=max(largest,(len(p)-rank)*p[index]);adjusted[index]=min(1.,largest)
    return adjusted

def calendar_clusters(days):
    """Actual ISO week identity; missing days are never filled or concatenated."""
    days=[date.fromisoformat(str(d)[:10]) for d in days]
    if len(set(days))!=len(days) or days!=sorted(days):raise ValueError('Daily rows must be unique and sorted')
    keys=[d.isocalendar()[:2] for d in days]
    unique=sorted(set(keys));index={key:i for i,key in enumerate(unique)}
    return np.asarray([index[key] for key in keys],dtype=np.int64),unique

def paired_week_bootstrap(days,full_sum,other_sum,counts,replicates=2000,seed=20260926):
    """Each sum is daily sum absolute error over nodes/horizons, mean over seeds.

    Daily counts are prediction units per seed. Unequal daily population sizes
    therefore receive their true weight in both estimates and resampled ratios.
    Positive difference/improvement favours FULL.
    """
    arrays=[np.asarray(x,dtype=np.float64) for x in (full_sum,other_sum,counts)]
    full,other,n=arrays
    if any(a.shape!=(len(days),) for a in arrays):raise ValueError('Daily shape mismatch')
    if not all(np.isfinite(a).all() for a in arrays) or np.any(n<=0) or np.any(full<0) or np.any(other<0):raise ValueError('Invalid daily errors/counts')
    cluster,keys=calendar_clusters(days);k=len(keys)
    if k<2:raise ValueError('At least two observed calendar weeks are required')
    fs=np.bincount(cluster,weights=full,minlength=k);bs=np.bincount(cluster,weights=other,minlength=k);ns=np.bincount(cluster,weights=n,minlength=k)
    f0=float(full.sum()/n.sum());b0=float(other.sum()/n.sum());difference=b0-f0
    if b0<=0:raise ValueError('Relative improvement undefined for zero comparator error')
    rng=np.random.default_rng(seed);deltas=np.empty(replicates);rates=np.empty(replicates)
    for i in range(replicates):
        choice=rng.integers(k,size=k);den=ns[choice].sum();fv=fs[choice].sum()/den;bv=bs[choice].sum()/den
        deltas[i]=bv-fv;rates[i]=100.*(bv-fv)/bv if bv>0 else np.nan
    if not np.isfinite(rates).all():raise ValueError('A bootstrap comparator error was zero')
    # Centred empirical bootstrap approximates the null distribution of difference.
    p=float((1+np.count_nonzero(np.abs(deltas-difference)>=abs(difference)))/(replicates+1))
    return dict(full_mae=f0,comparator_mae=b0,difference=difference,
      improvement_percent=100.*difference/b0,difference_ci95=np.quantile(deltas,[.025,.975]).tolist(),
      improvement_ci95=np.quantile(rates,[.025,.975]).tolist(),p_value_approximate=p,
      observed_days=len(days),observed_calendar_weeks=k,prediction_units_per_seed=int(n.sum()),
      replicates=replicates,seed=seed,calendar_week_keys=[list(x) for x in keys])

def dm_hac(days,full_daily_mean,other_daily_mean,lag=7):
    """Daily loss differential, positive means lower FULL loss."""
    parsed=[date.fromisoformat(str(d)[:10]) for d in days]
    if any((b-a).days!=1 for a,b in zip(parsed,parsed[1:])):raise ValueError('HAC-DM requires consecutive actual days')
    f=np.asarray(full_daily_mean,dtype=np.float64);b=np.asarray(other_daily_mean,dtype=np.float64)
    if f.shape!=b.shape or f.shape!=(len(days),) or len(days)<=lag+1 or not np.isfinite(f+b).all():raise ValueError('Invalid daily loss series')
    d=b-f;centered=d-d.mean();n=len(d)
    lrv=float(centered@centered/n)
    for j in range(1,lag+1):lrv+=2.*(1.-j/(lag+1.))*float(centered[j:]@centered[:-j]/n)
    if lrv<=0:return dict(status='degenerate_long_run_variance',mean_difference=float(d.mean()),p_value=None,lag=lag)
    statistic=float(d.mean()/sqrt(lrv/n));p=erfc(abs(statistic)/sqrt(2.))
    return dict(status='computed_asymptotic',mean_difference=float(d.mean()),statistic=statistic,p_value=p,lag=lag,n_days=n,long_run_variance=lrv)

def synthetic_checks():
    assert np.allclose(holm([.01,.04,.03]),[.03,.06,.06])
    assert np.allclose(holm([1.,0.,.5]),[1.,0.,1.])
    days=['2026-01-01','2026-01-02','2026-01-20','2026-02-02']
    idx,keys=calendar_clusters(days);assert idx.tolist()==[0,0,1,2] and len(keys)==3
    n=np.array([1,2,3,4]);a=paired_week_bootstrap(days,n*2,n*4,n)
    assert a['full_mae']==2 and a['comparator_mae']==4 and a['improvement_percent']==50
    assert np.allclose(a['difference_ci95'],[2,2]) and np.allclose(a['improvement_ci95'],[50,50])
    same=paired_week_bootstrap(days,n*2,n*2,n);assert same['p_value_approximate']==1
    rev=paired_week_bootstrap(days,n*4,n*2,n);assert rev['improvement_percent']==-100
    try:dm_hac(days,[1]*4,[2]*4,lag=1)
    except ValueError:pass
    else:raise AssertionError('Calendar gap incorrectly accepted')
    return dict(status='passed',checks=['Holm order and range','True calendar gaps retained','Counts-weighted pooled errors','Paired constant advantage','Null identity','Negative outcome preserved','HAC rejects calendar gaps'])
