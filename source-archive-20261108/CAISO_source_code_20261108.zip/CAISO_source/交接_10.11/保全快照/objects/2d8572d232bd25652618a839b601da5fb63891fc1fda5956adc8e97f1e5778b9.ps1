﻿$ErrorActionPreference='Stop'
$round=$PSScriptRoot
$branch=Split-Path -Parent $round
$trial=Join-Path $round 'conflict_pilot'
$manager=Join-Path $trial 'manager.py'
$status=Join-Path $trial 'status.json'
$python='D:\Documents\conda_envs\tcn_air\python.exe'
if (Test-Path -LiteralPath 'D:\Desktop\数据科学_论文\研究优化_20260818\logs\NEURAL_RUN.lock') { throw 'Numerical lock exists; inspect before starting' }
$existing=Get-CimInstance Win32_Process | Where-Object {$_.Name -match '^python(w)?\.exe$' -and $_.CommandLine -match 'multi_round_mechanism_v21_20261001'}
if ($existing) { throw 'A V21 Python process is already running' }
& $python -c 'import sys; sys.path.insert(0,sys.argv[1]); import common as c; c.verify(); c.check(True); print(c.gate.guard(True))' $trial
if($LASTEXITCODE -ne 0) { throw 'Preflight failed' }
$proc=Start-Process -FilePath $python -ArgumentList @('-u',('"'+$manager+'"')) -WorkingDirectory $trial -WindowStyle Hidden -RedirectStandardOutput (Join-Path $trial 'stdout.log') -RedirectStandardError (Join-Path $trial 'stderr.log') -PassThru
$ticks=$proc.StartTime.ToUniversalTime().Ticks
$watch=Join-Path $branch 'event_driven_automation\watch_manager_exit.ps1'
$ps=Join-Path $env:SystemRoot 'System32\WindowsPowerShell\v1.0\powershell.exe'
$listener=Start-Process -FilePath $ps -ArgumentList @('-NoProfile','-ExecutionPolicy','Bypass','-File',('"'+$watch+'"'),'-ManagerProcessId',$proc.Id,'-ManagerStartUtcTicks',$ticks,'-ManagerScript',('"'+$manager+'"'),'-StatusPath',('"'+$status+'"')) -WindowStyle Hidden -PassThru
$row=[ordered]@{at=[DateTime]::UtcNow.ToString('o');manager_pid=$proc.Id;manager_start_utc_ticks=$ticks;exit_listener_pid=$listener.Id;manager_script=$manager;status=$status;periodic=$false}
$dest=Join-Path $trial 'LAUNCH.json'
$tmp=$dest+'.'+[guid]::NewGuid().ToString('N')+'.tmp'
$row|ConvertTo-Json|Set-Content -LiteralPath $tmp -Encoding UTF8
Move-Item -LiteralPath $tmp -Destination $dest
$row|ConvertTo-Json
