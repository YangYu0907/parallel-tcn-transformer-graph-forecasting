from engine import HERE,TWO,REC,old,features_at,control_X,original_features,EXTRA_NAMES,checked
import ast,numpy as np
def main():
    checked(True);assert not (HERE/'PROTOCOL.json').exists()
    for p in HERE.glob('*.py'):ast.parse(p.read_text(encoding='utf-8'))
    old.verify()
    raw=np.random.default_rng(20261004).normal(size=(400,30));st=dict(center=[0.]*30,scale=[1.]*30,thresholds=[[1.]*30,[2.]*30])
    oo=np.array([300]);f,last=features_at(raw,oo,st);g,ll=original_features(raw,oo,st)
    assert np.array_equal(f[:,:,:37],g) and np.array_equal(last,ll)
    raw[300:]=-1e6;ff,l2=features_at(raw,oo,st)
    assert np.array_equal(f,ff) and np.array_equal(last,l2)
    # Exactly known event durations and leave-one-node-out co-occurrence.
    raw[:]=0;raw[288:300,0]=3;raw[294:300,1]=3;raw[298:300,2]=-3
    f,last=features_at(raw,oo,st);ex=f[0,:,37:]
    assert np.isclose(ex[0,12],12/72)
    assert np.isclose(ex[0,18],1/29) and np.isclose(ex[0,19],1/29)
    assert np.isclose(ex[1,18],1/29) and np.isclose(ex[2,18],0)
    old.write(HERE/'QA.json',dict(at=old.now(),status='passed',same_original_features=True,future_invariance=True,
        synthetic_signed_duration=True,exclude_self_from_network_breadth=True,syntax=True))
    files=list(HERE.glob('*.py'))+[HERE/'QA.json',TWO/'PROTOCOL.json',TWO/'AUDIT.json',TWO/'CLOSEOUT.json',TWO/'LOSS_ACCOUNTING.json']
    for fold in [1,2]:
        files += [TWO/f'REPLAY_fold{fold}.npz',TWO/f'fold{fold}/PREDICTIONS.npz',REC/f'fold{fold}/PREDICTIONS.npz',REC/f'fold{fold}/transition.pkl']
    old.write(HERE/'PROTOCOL.json',dict(at=old.now(),status='registered_before_fit',authorization='User explicitly: continue training',
        scope='Old historical TRAIN only; existing inspected outer periods stay exploratory; V7 unchanged.',
        hypothesis='Signed event history and cross-node co-exceedance can add information for recovery-versus-endpoint-extreme probabilities.',
        new_candidate_count=1,maximum_fits=6,probe_fits=4,conditional_final_fits=2,backbone_fits=0,amplitude_fits=0,
        maximum_seconds=1800,launch_memory_GiB=5,runtime_memory_GiB=4,single_numerical_worker=True,
        probe='Each earlier training prefix: first75% observed UTC dates fit, last25% probe,24h label purge. Fit all normalization and q99 on inner earlier fit only.',
        fitted_classifier='HistGradientBoostingClassifier;80iterations;7leaves;minleaf50;lr.05;l2=1;seed20260813;natural event frequency;fixed settings shared with matched original-feature control.',
        gate_feature_source='Only already available 288x30 price window; no new exogenous source, future states or future neighbor prices.',
        added_features=EXTRA_NAMES,old_features=37,node_onehot=30,horizon_feature=1,
        probe_admission='At least100cells and5dates of each outcome in training;5dates of each in probe.',
        probe_continue='Both folds require strictly lower cell-weighted AND equal-date-weighted Brier and log loss than matched original-feature classifier. No p-value target or threshold search.',
        final_continue='Only if both probes pass; fit enhanced classifier on each full earlier prefix using original statistics. Frozen recovery/extreme means and 50% mixture cap stay unchanged.',
        final_acceptance='Every old router initialization: all headline/horizon/state errors nonworse BASE by1e-6 and >=5dates per state; mean MAE/RMSE/H12 strictly lower than BASE and OLD_TWO in both folds.',
        safeguards='H1-H7 and current-nonextreme outputs unchanged. All18 V7/manuscript protected files checked. S2 cannot improve in this branch.',
        no_automatic_expansion=True,no_new_test=True,periodic_model_wakeups=False,
        literature=[dict(url='https://eprints.gla.ac.uk/38583/',title='Christensen et al.2012, Forecasting spikes in electricity prices',read='author institution abstract',support='Conditional hazard/point-process event history; exact features are our testable adaptation.'),
                    dict(url='https://cris.maastrichtuniversity.nl/en/publications/modeling-and-forecasting-multivariate-electricity-price-spikes/',title='Manner et al.2016, Modeling and forecasting multivariate electricity price spikes',read='author institution abstract',support='Cross-market event dependencies motivate past-only cross-node summaries; not physical topology or guaranteed forecast improvement.')],
        bindings={str(p):old.sha(p) for p in files}))
    print('Prepared and registered: 4 probe fits, at most2 additional classifier fits.')
if __name__=='__main__':main()
