from common import *
import math

def main():
    with gate.exclusive('V11 separate arithmetic, temporal and scoring audit'):
        np,lim=gate.runtime(False);verify();start_budget()
        for p,h in gate.read(HERE/'SOURCE_BINDINGS.json')['bindings'].items():assert gate.sha(p)==h,p
        with np.load(A4/'panel.npz') as z:data={k:z[k] for k in z.files}
        folds=gate.read(B/'adaptive_experts_v4_20260929/FOLDS.json');ids=np.concatenate([f['evaluation'] for f in folds])
        y=data['truth'][ids];st=data['states'][ids];days=data['days'][ids];low=np.broadcast_to(data['low_volatility'][ids,:,None],y.shape)
        def basic(e):return dict(mae=float(np.abs(e).mean()),rmse=float(np.sqrt(np.mean(e*e))))
        def metrics(p):
            e=p-y
            return dict(**basic(e),near_mae=float(np.abs(e[:,:,:4]).mean()),h12_mae=float(np.abs(e[:,:,11]).mean()),low_volatility_mae=float(np.abs(e[low]).mean()),states={str(s):basic(e[st==s]) for s in range(6)},nodes=[basic(e[:,j]) for j in range(30)],horizons=[basic(e[:,:,j]) for j in range(12)])
        def independent_predict(m,x):return np.einsum('ij,jk->ik',(x-m['center'])/m['scale'],m['coef'])+m['intercept']
        rows=[];audits=[];stored={};activation={}
        lut={int(o):j for j,o in enumerate(ids)}
        for seed in SEEDS:
            tick(stage='audit',seed=seed)
            with np.load(ART/f'matrix/{seed}.npz') as z:d={k:z[k] for k in z.files}
            assert gate.sha(ART/f'matrix/{seed}.npz')==gate.read(HERE/f'matrix_receipts/{seed}.json')['sha256']
            path=ART/f'predictions/{seed}.npz';assert gate.sha(path)==gate.read(HERE/f'receipts/{seed}.json')['sha256']
            with np.load(path) as z:out={k:z[k] for k in z.files}
            with np.load(ART.parent/f'risk_likelihood_v10_20260930/predictions/{seed}.npz') as z:
                assert np.array_equal(out['V7'],z['V7']) and np.array_equal(out['FULL'],z['FULL']) and np.array_equal(out['V10'],z['LIKELIHOOD'])
            for f in folds:
                artifact=ART/f'fits/{seed}_{f["id"]}.pkl'
                if not artifact.exists():continue
                obj=load(artifact);fi=obj['fit_rows'];ci=obj['calibration_rows'];ei=obj['evaluation_rows'];guard=obj['guard']
                assert set(fi).isdisjoint(ci) and set(fi).isdisjoint(ei) and set(ci).isdisjoint(ei)
                assert np.all(d['available'][np.r_[fi,ci]]<obj['cutoff']) and np.all(d['issued'][np.r_[fi,ci]]<obj['cutoff'])
                assert d['days'][fi].max()<d['days'][ci].min() and d['days'][ci].max()<d['days'][ei].min()
                # Independently solve the regularized least-squares problem using
                # augmented rows, rather than the worker's normal equations.
                xx=d['X'][fi];mu=xx.mean(0);sd=xx.std(0);sd=np.where(sd<1e-8,1,sd)
                ep=d['experts'][fi]-d['truth'][fi,None];sc=float(d['scale'])
                yy=np.column_stack([(abs(ep[:,0])-abs(ep[:,1]))/sc,(ep[:,0]**2-ep[:,1]**2)/sc**2,(abs(ep[:,2])-abs(ep[:,1]))/sc,(ep[:,2]**2-ep[:,1]**2)/sc**2])
                cy=yy.mean(0);coef=np.linalg.lstsq(np.vstack([(xx-mu)/sd,10*np.eye(16)]),np.vstack([yy-cy,np.zeros((16,4))]),rcond=None)[0]
                assert np.allclose(coef,guard['model']['coef'],atol=1e-9,rtol=1e-9)
                estimate=independent_predict(guard['model'],d['X'][ei]);sub=np.array([independent_predict(m,d['X'][ei]) for m in guard['jackknife']]);n=len(sub)
                variance=(n-1)/n*((sub-sub.mean(0))**2).sum(0)
                # Calibration bias and uncertainty independently recomputed by date.
                ec=d['experts'][ci]-d['truth'][ci,None]
                yc=np.column_stack([(abs(ec[:,0])-abs(ec[:,1]))/sc,(ec[:,0]**2-ec[:,1]**2)/sc**2,(abs(ec[:,2])-abs(ec[:,1]))/sc,(ec[:,2]**2-ec[:,1]**2)/sc**2])
                res=yc-independent_predict(guard['model'],d['X'][ci]);calmeans=np.array([res[d['days'][ci]==day].mean(0) for day in np.unique(d['days'][ci])])
                upper=estimate+calmeans.mean(0)+1.645*np.sqrt(variance+calmeans.var(0,ddof=1)/2)
                picks=[]
                for values in upper:
                    allowed=[]
                    if values[0]<0 and values[1]<0:allowed.append((max(values[:2]),0))
                    if values[2]<0 and values[3]<0:allowed.append((max(values[2:]),2))
                    picks.append(min(allowed)[1] if allowed else 1)
                picks=np.array(picks);rr=np.array([lut[int(o)] for o in d['origin_index'][ei]]);nn=d['node'][ei];hh=d['horizon'][ei]
                assert np.array_equal(picks,out['choice'][rr,nn,hh])
                assert np.array_equal(d['experts'][ei,picks],out['SELECTIVE'][rr,nn,hh])
                assert np.array_equal(d['experts'][ei,obj['globalchoice']],out['PAST_GLOBAL'][rr,nn,hh])
                audits.append(dict(seed=seed,fold=f['id'],fit_dates=len(guard['fit_dates']),calibration_dates=2,evaluation_cells=len(ei),maximum_coef_difference=float(abs(coef-guard['model']['coef']).max())))
            for arm in ARMS:
                assert np.isfinite(out[arm]).all() and np.array_equal(out[arm][~out['mask']],out['V7'][~out['mask']])
            assert np.array_equal(out['FIXED_HALF'][out['mask']],.5*(out['FULL'][out['mask']]+out['V7'][out['mask']]))
            stored[seed]={a:out[a] for a in ['FULL','V10',*ARMS]}
            for arm,p in stored[seed].items():
                m=metrics(p);assert math.isclose(m['mae'],math.fsum(abs(p-y).ravel())/y.size,rel_tol=1e-13)
                rows.append(dict(seed=seed,arm=arm,**m))
            activation[str(seed)]={str(s):np.bincount(out['choice'][st==s],minlength=3).tolist() for s in range(6)}
            save(ART/f'audited/{seed}.npz',truth=y,states=st,**stored[seed])
        scalar=['mae','rmse','near_mae','h12_mae','low_volatility_mae'];summary={}
        for arm in ['FULL','V10',*ARMS]:
            rr=[r for r in rows if r['arm']==arm];a={k:float(np.mean([r[k] for r in rr])) for k in scalar}
            a['states']={str(s):{k:float(np.mean([r['states'][str(s)][k] for r in rr])) for k in ('mae','rmse')} for s in range(6)}
            for group,n in [('nodes',30),('horizons',12)]:a[group]=[{k:float(np.mean([r[group][i][k] for r in rr])) for k in ('mae','rmse')} for i in range(n)]
            summary[arm]=a
        full=summary['FULL'];base=summary['V7'];candidate=summary['SELECTIVE'];failures=[];all_comparisons=[]
        for key in scalar:all_comparisons.append((key,full[key],base[key],candidate[key]))
        for group,n in [('states',6),('nodes',30),('horizons',12)]:
            for j in range(n):
                idx=str(j) if group=='states' else j
                for k in ('mae','rmse'):all_comparisons.append((f'{group}.{j}.{k}',full[group][idx][k],base[group][idx][k],candidate[group][idx][k]))
        for name,f,b,c in all_comparisons:
            if b<f and not c<f:failures.append(dict(metric=name,FULL=f,V7=b,SELECTIVE=c))
        negatives=[dict(metric=name,FULL=f,V7=b,SELECTIVE=c) for name,f,b,c in all_comparisons if not c<f]
        checks=dict(previous_positive_directions_preserved=not failures,recovery_RMSE_repaired=candidate['states']['3']['rmse']<full['states']['3']['rmse'],all_metrics_positive=not negatives,
             seeds=sum(next(r['mae'] for r in rows if r['arm']=='SELECTIVE' and r['seed']==s)<next(r['mae'] for r in rows if r['arm']=='FULL' and r['seed']==s) for s in SEEDS)>=2)
        weeks=np.unique(days//7);wc=np.array([(days//7==w).sum()*360 for w in weeks]);rng=np.random.default_rng(93031);ix=rng.integers(0,len(weeks),(2000,len(weeks)));comparisons=[]
        for arm in ('FULL','V7','FIXED_HALF','PAST_GLOBAL'):
            delta=np.mean([abs(stored[s][arm]-y)-abs(stored[s]['SELECTIVE']-y) for s in SEEDS],0).sum((1,2));ws=np.array([delta[days//7==w].sum() for w in weeks]);bs=ws[ix].sum(1)/wc[ix].sum(1)
            comparisons.append(dict(control=arm,absolute_MAE_gain=float(delta.sum()/y.size),CI95=np.quantile(bs,[.025,.975]).tolist(),p=float(min(1.,2*min((np.sum(bs<=0)+1)/2001,(np.sum(bs>=0)+1)/2001)))))
        running=0.
        for rank,j in enumerate(sorted(range(len(comparisons)),key=lambda j:comparisons[j]['p'])):
            running=max(running,min(1.,(4-rank)*comparisons[j]['p']));comparisons[j]['holm_p']=running
        write(HERE/'RESULT.json',dict(at=gate.now(),scope='Exploratory chronological routing on repeatedly inspected H1; not independent confirmation',summary=summary,seed_results=rows,choices_by_state=activation,expert_order=['FULL','V7','V10'],comparisons=comparisons,checks=checks,positive_directions_lost=failures,remaining_nonpositive_metrics=negatives,origins=698,dates=42,forecast_cells_per_seed=251280,core_changed=False,new_test_targets_read=False))
        write(HERE/'AUDIT.json',dict(at=gate.now(),status='passed',result_sha256=gate.sha(HERE/'RESULT.json'),ridge_and_routing_replays=audits,nonextreme_bitwise_preservation=True,strict_temporal_release_checks=True,numerical_review='Separate implementation same operator; not independent peer review',new_test_targets_read=False))
        write(HERE/'DECISION.json',dict(at=gate.now(),status='candidate_passed_exploratory_gate_needs_independent_confirmation' if all(checks.values()) else 'selective_candidate_closed_not_promoted',passes_full_development_gate=all(checks.values()),checks=checks,paper_results_replaced=False,automatic_extra_search=False,complete_research_experiment=False))
        print(json.dumps(dict(checks=checks,SELECTIVE={k:candidate[k] for k in scalar},lost_positive_directions=len(failures))),flush=True)
if __name__=='__main__':main()
