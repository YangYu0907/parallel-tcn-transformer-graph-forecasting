"""Finite metadata-only screen of a new September period. No target values."""
from pathlib import Path
from datetime import datetime,timedelta,timezone
from urllib.request import Request,urlopen
from urllib.parse import urlencode
import sys,time,json,os
HERE=Path(__file__).resolve().parent
B=HERE.parent
sys.path.insert(0,str(B/'context_expert_v1_20260929'));import gate
UTC=timezone.utc

def status(**kw):gate.write(HERE/'preflight/status.json',dict(at=gate.now(),pid=os.getpid(),**kw))

def main():
    with gate.exclusive('adaptive_v2_new_period_metadata_only'):
        gate.need(not (HERE/'source_screen/SUMMARY.json').exists(),'Metadata screen already complete')
        source=B/'guarded_confirmation_v1_20260929/collect_metadata.py'
        mod=gate.load('adaptive_metadata_source',source)
        mod.HERE=HERE
        mod.INPUT_START=datetime(2026,8,16,tzinfo=UTC)
        mod.TEST_START=datetime(2026,9,1,tzinfo=UTC)
        mod.TEST_END=datetime(2026,9,29,tzinfo=UTC)
        jobs=[];a=datetime(2026,8,15,tzinfo=UTC)
        end=datetime(2026,9,29,tzinfo=UTC)
        while a<end:
            b=min(a+timedelta(days=14),end)
            for k in mod.STREAMS:jobs.append((a,b,k))
            a=b
        registration=dict(at=gate.now(),status='registered_before_new_target_access',
            candidate_target_period_UTC=['2026-09-01T00:00:00Z','2026-09-29T00:00:00Z'],
            date_basis='All completed September UTC days before registration; no price/error inspection',
            prior_access_review='Existing registrations and target-release records cover H1 and July-August 2026, Europe2016; no September evaluation located in project access records',
            admission='All hourly origins meeting unchanged 30-node/29-feature source contract and12-step completeness',
            query_allowlist=['ATL_PUB'],source_helper=str(source),source_helper_sha256=gate.sha(source),
            publication_windows=[dict(start=a.isoformat(),end=b.isoformat(),stream=k) for a,b,k in jobs],
            maximum_attempts=2,request_start_gap_seconds=8,maximum_elapsed_seconds=900,
            new_test_values_read=False,metadata_feasibility_is_not_full_test_admission=True)
        if not (HERE/'SOURCE_REGISTRATION.json').exists():gate.write(HERE/'SOURCE_REGISTRATION.json',registration)
        receipts=[];last=0.;begun=time.monotonic()
        for j,(a,b,k) in enumerate(jobs):
            gate.guard();gate.need(time.monotonic()-begun<900,'Finite preflight limit')
            ident=a.strftime('%Y%m%d')+'_'+b.strftime('%Y%m%d')+'_'+k
            path=HERE/'publication_receipts'/(ident+'.json')
            if path.exists() and gate.read(path).get('status')=='passed':
                r=gate.read(path)
                gate.need(gate.sha(r['body'])==r['body_sha256'] and gate.sha(r['ledger'])==r['ledger_sha256'],'Cached metadata integrity')
                receipts.append(r);continue
            params=dict(queryname='ATL_PUB',market_run_id=mod.STREAMS[k][0],oasis_section=mod.STREAMS[k][1],
                status='ALL',atlpubversion='ALL',version=1,startdatetime=mod.stamp(a),enddatetime=mod.stamp(b),resultformat=6)
            url='https://oasis.caiso.com/oasisapi/SingleZip?'+urlencode(params)
            errors=[]
            for attempt in (1,2):
                wait=max(0,8-(time.monotonic()-last))
                if wait:time.sleep(wait)
                gate.guard();last=time.monotonic()
                status(stage='metadata_request',completed=j,total=len(jobs),query=ident,attempt=attempt)
                try:
                    with urlopen(Request(url,headers={'User-Agent':'CAISO-academic-source-admission/1.0'}),timeout=35) as response:
                        body=response.read(15_000_001)
                        gate.need(len(body)<=15_000_000,'Metadata body guard')
                    total,records=mod.parse(body,k)
                    bp=HERE/'publication_receipts'/(ident+'.response')
                    lp=HERE/'publication_receipts'/(ident+'.records.json')
                    gate.atomic(bp,lambda f:f.write(body));gate.write(lp,records)
                    r=dict(at=gate.now(),status='passed',params=params,url=url,body=str(bp),body_sha256=gate.sha(bp),
                        ledger=str(lp),ledger_sha256=gate.sha(lp),metadata_rows=total,relevant_events=len(records),attempts=errors)
                    gate.write(path,r);receipts.append(r);break
                except Exception as exc:
                    errors.append(dict(at=gate.now(),attempt=attempt,error=repr(exc)))
                    gate.write(path,dict(status='failed',params=params,attempts=errors))
                    if attempt==2:raise
            print(json.dumps(dict(completed=j+1,total=len(jobs),query=ident)),flush=True)
        summary=mod.screen(receipts)
        # The producer is independently replayed by a simple explicit timestamp-set check.
        latest={k:{} for k in ('price','rtd','dam_load','dam_renewable')};first={}
        for r in receipts:
            for row in gate.read(r['ledger']):
                k=row['stream']
                for t in range(row['start'],row['end'],300):
                    latest[k][t]=max(latest[k].get(t,0),row['published'])
                    if k=='price' and row['version']=='New':first[t]=min(first.get(t,row['published']),row['published'])
        rows=gate.read(HERE/'source_screen/origins.json')
        assert len(rows)==28*24
        for row in rows:
            o=mod.sec(row['target_start_utc']);cut=o-300;flags=[]
            price=list(range(o-864*300,o,300))+list(range(o-2304*300,o-2016*300,300))+list(range(o-4320*300,o-4032*300,300))
            if any(t not in latest['price'] for t in price):flags.append('price_publication_coverage_gap')
            if any(latest['price'].get(t,0)>cut for t in price):flags.append('price_latest_publication_after_cutoff')
            for k,lo,hi in [('rtd',o-86400,o),('dam_load',o-86400,o+3600),('dam_renewable',o-86400,o+3600)]:
                if any(t not in latest[k] for t in range(lo,hi,300)):flags.append(k+'_publication_coverage_gap')
                if any(latest[k].get(t,0)>cut for t in range(lo,hi,300)):flags.append(k+'_latest_publication_after_cutoff')
            if any(t not in first for t in range(o,o+3600,300)):flags.append('target_initial_publication_missing')
            elif any(first[t]<=cut for t in range(o,o+3600,300)):flags.append('a_target_initial_publication_not_after_cutoff')
            assert flags==row['reasons'],(row,flags)
        gate.write(HERE/'source_screen/AUDIT.json',dict(at=gate.now(),status='passed_timestamp_metadata_only',
            origins=len(rows),candidates=summary['metadata_candidates'],candidate_dates=summary['candidate_UTC_dates'],
            independent_explicit_timestamp_checks=True,script_sha256=gate.sha(__file__),
            summary_sha256=gate.sha(HERE/'source_screen/SUMMARY.json'),origins_sha256=gate.sha(HERE/'source_screen/origins.json'),
            test_targets_read=False,independent_period_admitted=False))
        status(stage='metadata_feasibility_complete',summary=summary)
        print(json.dumps(summary),flush=True)

if __name__=='__main__':
    try:main()
    except BaseException as exc:
        gate.write(HERE/'preflight/STOP.json',dict(at=gate.now(),error=repr(exc),test_targets_read=False))
        raise
