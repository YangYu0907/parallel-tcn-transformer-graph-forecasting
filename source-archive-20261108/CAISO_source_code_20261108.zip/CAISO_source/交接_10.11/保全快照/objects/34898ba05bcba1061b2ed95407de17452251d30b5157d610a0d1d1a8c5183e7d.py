"""Separate scalar error reductions and binding checks after locked scoring."""
import math
from runtime_gate import HERE,c,verify_release,commit_inventory,FREEZE

def main():
    f=verify_release();inventory=commit_inventory(f)
    with c.exclusive('Independent scalar H1 result audit'):
        np,limiter=c.runtime();result=c.read(HERE/'TEST_RESULTS.json')
        c.need(result['freeze_sha256']==c.sha(FREEZE) and result['target_sha256']==c.sha(HERE/'scoring_targets.npz'),'Result bindings changed')
        c.need(result['target_access_receipt_sha256']==c.sha(HERE/'TARGET_ACCESS_RECEIPT.json'),'Target access receipt changed')
        access=c.read(HERE/'TARGET_ACCESS_RECEIPT.json')
        c.need(access['prediction_commit_sha256']==c.sha(HERE/'ALL_PREDICTIONS_COMMITTED.json'),'Access before wrong prediction commit')
        c.need(sum(bool(r['target_rows_returned']) for r in access['receipts'])==1002,'Target access count')
        with np.load(HERE/'scoring_targets.npz',allow_pickle=False) as z:
            truth=z['truth'];states=z['states'];c.need(z['origins'].tolist()==f['origins'],'Scoring panel')
        c.need(truth.shape==(1002,30,12) and states.shape==truth.shape and np.isfinite(truth).all(),'Target shape')
        rows={v['id']:v for v in result['seed_results']};checks=[]
        for case in f['cases']:
            c.guard();entry=inventory['cases'][case['id']]
            with np.load(entry['prediction_path'],allow_pickle=False) as z:error=z['prediction']-truth
            values=error.ravel();n=len(values)
            ma=math.fsum(abs(float(v)) for v in values)/n
            rm=math.sqrt(math.fsum(float(v)**2 for v in values)/n)
            near=math.fsum(abs(float(v)) for v in error[:,:,:4].ravel())/(1002*30*4)
            far=math.fsum(abs(float(v)) for v in error[:,:,11].ravel())/(1002*30)
            for k,v in [('MAE',ma),('RMSE',rm),('near_MAE',near),('H12_MAE',far)]:
                c.need(math.isclose(v,rows[case['id']][k],rel_tol=1e-12,abs_tol=1e-10),'Scalar metric disagrees '+case['id']+' '+k)
            checks.append(case['id'])
        main={r['model']:r for r in result['main_results']}
        c.need(set(main)==set(r['variant'] for r in f['cases']),'Missing comparison family')
        for row in result['comparisons']:
            baseline=main[row['comparator']]['MAE'];full=main['FULL']['MAE']
            c.need(math.isclose(row['improvement_percent'],100*(baseline-full)/baseline,abs_tol=1e-10),'Improvement denominator')
        c.need(sum(s['prediction_cells'] for s in result['states'])==truth.size,'State counts do not exhaust targets')
        c.need(sum(result['daily_prediction_counts'])==truth.size,'Calendar counts')
        c.write(HERE/'TEST_AUDIT.json',dict(status='passed',at=c.now(),result_sha256=c.sha(HERE/'TEST_RESULTS.json'),
            freeze_sha256=c.sha(FREEZE),scalar_checked_cases=checks,scalar_metric_equalities=len(checks)*4,
            directions_and_denominators_verified=True,all_cases_preserved=True,
            review_scope='Separate compensated scalar summation and hash/panel/denominator checks by the same operator; not independent human peer review',
            complete_CAISO_numerical_evaluation=True,complete_research_experiment=False))
        print('Frozen H1 outputs and scalar metrics audited; all directions retained')

if __name__=='__main__':main()
