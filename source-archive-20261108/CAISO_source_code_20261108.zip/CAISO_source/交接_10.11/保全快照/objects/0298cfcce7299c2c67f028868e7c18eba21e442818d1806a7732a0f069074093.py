import json,hashlib,os
from pathlib import Path
from datetime import datetime,timezone
import psutil
P=Path(__file__).resolve().parent;Z=P.parent;B=Z.parent.parent
S=P/'resume2'
now=datetime.now(timezone.utc).isoformat()
def read(p):return json.loads(Path(p).read_text(encoding='utf-8-sig'))
def sha(p):return hashlib.sha256(Path(p).read_bytes()).hexdigest()
def write(p,v):
 p=Path(p);p.parent.mkdir(parents=True,exist_ok=True);temp=p.with_name(p.name+'.tmp')
 temp.write_text(json.dumps(v,ensure_ascii=False,indent=2)+'\n',encoding='utf-8');os.replace(temp,p)
event=read(B/'event_driven_automation/inbox/wi_0f5982289587a42774aeeef2.json')
assert sha(event['evidence_path'])==event['evidence_sha256']
launch=read(S/'LAUNCH.json');pid=launch['manager_pid'];status=read(S/'STATUS.json')
alive=psutil.pid_exists(pid) and str(P/'resume2_manager.py').lower() in ' '.join(psutil.Process(pid).cmdline()).lower()
qa=read(S/'QA.json');assert qa['passed']
progress=read(S/'PROGRESS.json') if (S/'PROGRESS.json').exists() else read(P/'PROGRESS.json')
review=dict(at=now,delivery_event_id='f5c21fb86c9c36dc02eac296ba48c9857f55b9ee760bf39e87b1677c389d2785',source_event_id=event['event_id'],
 cause='HTTP412 for mirror IDX using original AWS ETag; original source index not found by old cache lookup despite being preserved in completed source receipts',
 observed_http_status=412,cause_scope='Index precondition mismatch, not a measured model failure; mirror index body not admitted or substituted',
 repair='Resolve original index via retained completed-cycle receipts, validating SHA256/MD5/size and source cutoff; retain original mirror data checks',
 qa=str(S/'QA.json'),qa_sha256=sha(S/'QA.json'),resume_protocol=str(S/'PROTOCOL.json'),resume_protocol_sha256=sha(S/'PROTOCOL.json'),
 old_manager_pid=23200,old_manager_exited=not psutil.pid_exists(23200),
 numerical_manager_running=alive,current_launch=launch,current_status=status,mirror_cycles_verified=progress['completed_cycles'],
 production_source_cycles=85,production_total=5286,model_fits=0,new_test_targets_read=False,V7_replaced=False,
 automatic_full_restart=False,no_deadline_extension=True,no_quota_extension=True,periodic_model_wakeups=False,
 event_listener_pid=3936,event_listener_alive=psutil.pid_exists(3936))
if (S/'COST_STOP.json').exists():
 review['cost_stop']=read(S/'COST_STOP.json')
 review['stop_audit']=str(S/'STOP_AUDIT.json')
 review['next_resume_plan']=str(S/'NEXT_RESUME_PLAN.json')
if (S/'RESULT.json').exists():review['result']=read(S/'RESULT.json')
reviewpath=Z/'handled_events/review_f5c21fb86c9c36dc.json';write(reviewpath,review)
hp=B/'HANDOFF.json';before=hp.read_bytes();h=json.loads(before.decode('utf-8-sig'))
backup=S/'HANDOFF_BEFORE_EVENT.json'
if not backup.exists():backup.write_bytes(before)
stage='same_mirror_proof_cache_repair_running' if alive else ('weather_source_stopped_cost_gate_pending_budget_decision' if (S/'COST_STOP.json').exists() else 'same_mirror_proof_stopped_review_required')
ext=h['mechanism_weather_extension_20261007']
ext.update(at=now,stage=stage,active_numeric_job=alive,completed_source_cycles=85,
 active_script=str(P/'resume2_manager.py'),launch=launch,manager_pid=pid if alive else None,
 manager_start_utc_ticks=launch['manager_start_utc_ticks'],exit_monitor_pid=launch['exit_monitor_pid'] if alive else None,
 exit_monitor_receipt=launch['receipt'],mirror_index_repair=str(S/'PROTOCOL.json'),
 mirror_index_repair_sha256=sha(S/'PROTOCOL.json'),mirror_verified_cycles=progress['completed_cycles'],
 latest_event_review=str(reviewpath),model_fits=0,automatic_full_restart=False,
 next=('Await decision on prepared30hour source budget before any heavy source continuation; preserve24mirror and85production cycles' if (S/'COST_STOP.json').exists() else 'Complete unchanged mirror identity/cost proof; full extraction forbidden unless all32 and original budget gates pass'))
if (S/'STOP_AUDIT.json').exists():
 ext['mirror_stop_audit']=str(S/'STOP_AUDIT.json');ext['awaiting_budget_decision']=True;ext['next_resume_plan']=str(S/'NEXT_RESUME_PLAN.json')
h.update(at=now,last_updated_utc=now,current_stage=stage,current_process=launch if alive else None,
 numeric_diagnostic_active=alive,training_active=False,research_training_active=False,manager_pid=pid if alive else None,
 event_listener_pid=3936,periodic_model_wakeups=False,
 last_event_dedup_check=dict(at=now,delivery_event_id=review['delivery_event_id'],source_event_id=event['event_id'],decision=stage,review=str(reviewpath)),
 last_handled_event=event['event_id'])
internal_status=read(P/'resume/STATUS.json')
review['intermediate_code_repair']=dict(failure=str(P/'resume/FAILURE.json'),cause='Cache key stem mismatch; no additional network transfer; fixed and offline actual-fetch regression passed',event_id=internal_status['event_id'])
write(reviewpath,review)
for e in [review['delivery_event_id'],event['event_id'],internal_status['event_id'],status.get('event_id')]:
 if not e:continue
 if e not in h.setdefault('handled_event_ids',[]):h['handled_event_ids'].append(e)
assert hp.read_bytes()==before
write(hp,h)
history=read(Z/'REVIEWED_SOURCE_EVENTS.json')
history.update(at=now,current_launch=launch if alive else None,latest_review=str(reviewpath))
history['handled'][event['event_id']]='Original96index checksum/cutoff audited; same32 proof resumed without deadline/quota extension; state='+stage
history['handled'][internal_status['event_id']]='Cache adapter stem bug fixed; actual-fetch offline regression passed; same quotas/deadline and prior elapsed carried'
if status.get('event_id'):history['handled'][status['event_id']]='24mirror cycles independently replayed; time cost gate failed; preserved85productioncycles; prepared budget decision; no training'
write(Z/'REVIEWED_SOURCE_EVENTS.json',history)
print(json.dumps(dict(recorded=True,stage=stage,verified_mirror_cycles=progress['completed_cycles'],pid=pid,alive=alive),ensure_ascii=False))
