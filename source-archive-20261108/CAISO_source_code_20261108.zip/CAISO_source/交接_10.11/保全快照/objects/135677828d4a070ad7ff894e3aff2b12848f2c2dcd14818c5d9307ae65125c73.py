import support as s
import numpy as np,pickle,gc,os,hashlib,time
ACTIONS=['D','S','VD','VS','VL']
ROUTES=['PURE_DYNAMIC_SELF','PURE_STATIC_SELF','V7_DYNAMIC_SELF','V7_STATIC_SELF','V7_SELF_ONLY']
def headline(p,y,low=None):
 e=np.asarray(p,float)-np.asarray(y,float)
 out=dict(mae=float(abs(e).mean()),rmse=float(np.sqrt((e*e).mean())),near_mae=float(abs(e[:,:,:4]).mean()),h12_mae=float(abs(e[:,:,-1]).mean()))
 if low is not None:
  mask=np.broadcast_to(low[:,:,None],e.shape);out['low_volatility_mae']=float(abs(e[mask]).mean()) if mask.any() else None
 return out
def metrics(p,y,states,low):
 e=np.asarray(p,float)-np.asarray(y,float);r=headline(p,y,low)
 def basic(z):return dict(n=z.size,mae=float(abs(z).mean()),rmse=float(np.sqrt((z*z).mean()))) if z.size else None
 r['states']={str(k):basic(e[states==k]) for k in range(6)}
 r['nodes']=[basic(e[:,i]) for i in range(30)];r['horizons']=[basic(e[:,:,h]) for h in range(12)]
 return r
def features(last,b,c,unit):
 n=len(last);x=np.column_stack([np.repeat(last.reshape(-1,29),12,axis=0),b.ravel()/unit,c.ravel()/unit,(c-b).ravel()/unit,
  np.tile(np.repeat(np.eye(30,dtype=np.float32),12,axis=0),(n,1)),np.tile(np.eye(12,dtype=np.float32),(n*30,1))]).astype(np.float32)
 assert x.shape==(n*360,74) and np.isfinite(x).all();return x
def fit_model(name,X,target,seed,protocol,tick):
 from sklearn.ensemble import HistGradientBoostingRegressor
 path=s.N/'models'/name;path.parent.mkdir(exist_ok=True)
 identity=dict(protocol_sha256=s.sha(s.N/'PROTOCOL.json'),rows=len(target),columns=X.shape[1],seed=seed,
  X_sha256=hashlib.sha256(X.tobytes()).hexdigest(),y_sha256=hashlib.sha256(target.tobytes()).hexdigest())
 if path.exists():
  with path.open('rb') as f:obj=pickle.load(f)
  assert obj['identity']==identity;model=obj['model']
 else:
  kw=protocol['design']['learner'].copy();kw['max_iter']=10
  model=HistGradientBoostingRegressor(loss='squared_error',warm_start=True,random_state=seed,**kw)
 for it in [10,20,30,40]:
  if getattr(model,'n_iter_',0)>=it:continue
  tick(stage='fitting',model=name,iterations=it,total_iterations=40)
  model.set_params(max_iter=it);model.fit(X,target)
  tmp=path.with_suffix('.tmp')
  with tmp.open('wb') as f:pickle.dump(dict(identity=identity,model=model),f,protocol=5)
  os.replace(tmp,path)
 return model
def choose(scores,actions,anchor):
 out=anchor.copy();selected=np.zeros(anchor.shape,np.uint8)
 best=np.zeros(anchor.shape)
 for code,(gain,risk),action in zip(range(1,len(scores)+1),scores,actions):
  ok=(gain>best)&(risk>0)
  out[ok]=action[ok];selected[ok]=code;best[ok]=gain[ok]
 return out,selected
def main(tick):
 protocol=s.verify()
 with np.load(protocol['panel'],allow_pickle=False) as z:panel={k:z[k] for k in z.files}
 folds=s.read(protocol['folds']);global_ids=np.concatenate([f['evaluation'] for f in folds]);assert len(global_ids)==698
 data={k:v[global_ids] for k,v in panel.items()};del panel
 unit=float(np.asarray(s.read(protocol['scalers'])['price_scale'])[0,:,0].mean())
 days=data['cutoff']//86400;learned_mask=np.arange(698)>=len(folds[0]['evaluation']);rows=[];logs=[]
 for seed_index,case in enumerate(protocol['cases']):
  seed=case['seed'];dest=s.N/f'seed{seed_index}.npz'
  if dest.exists():
   assert s.read(s.N/f'seed{seed_index}.receipt.json')['sha256']==s.sha(dest);continue
  experts={}
  for key in ['FULL','STATIC','SELF']:
   with np.load(case[key],allow_pickle=False) as z:
    assert np.array_equal(z['origins'][global_ids],data['origins']);experts[key]=z['prediction'][global_ids]
  with np.load(case['V7'],allow_pickle=False) as z:
   assert np.array_equal(z['origins'],data['origins']);v7=z['CONTEXT']
  y=data['truth'];local=experts['SELF'];base={'D':local,'S':local,'VD':v7,'VS':v7,'VL':v7}
  candidate=dict(D=experts['FULL'],S=experts['STATIC'],VD=v7+.75*(experts['FULL']-v7),VS=v7+.75*(experts['STATIC']-v7),VL=v7+.75*(local-v7))
  output={'V7':v7,**experts,'HALF_DYNAMIC_SELF':.5*(experts['FULL']+local),'HALF_STATIC_SELF':.5*(experts['STATIC']+local),
   'V7_FIXED_DYNAMIC_SELF':.25*v7+.375*(experts['FULL']+local),'V7_FIXED_STATIC_SELF':.25*v7+.375*(experts['STATIC']+local)}
  selections={}
  for route in ROUTES:
   output[route]=(local if route.startswith('PURE') else v7).copy();output['RAW_'+route]=output[route].copy();selections[route]=np.zeros(y.shape,np.uint8)
  for fi in [1,2]:
   ev=np.flatnonzero(np.isin(global_ids,folds[fi]['evaluation']));cut=int(data['cutoff'][ev[0]])
   past=np.flatnonzero((data['cutoff']<cut)&(data['available'].max(1)<cut))
   caldays=np.unique(days[past])[-3:];cal=past[np.isin(days[past],caldays)];fit0=past[~np.isin(days[past],caldays)]
   fit=fit0[data['available'][fit0].max(1)<data['cutoff'][cal[0]]]
   assert len(fit)>0 and len(caldays)==3
   assert data['available'][fit].max()<data['cutoff'][cal[0]] and data['available'][cal].max()<cut
   fitcells=(fit[:,None]*360+np.arange(360)).ravel();query=np.r_[cal,ev];qcells=(query[:,None]*360+np.arange(360)).ravel()
   gains={}
   for ai,a in enumerate(ACTIONS):
    tick(stage='prepare_action',seed=seed,fold=fi+1,action=a,fit_origins=len(fit))
    X=features(data['last'],base[a],candidate[a],unit);xf=X[fitcells].copy();xq=X[qcells].copy();del X
    e0=base[a][fit]-y[fit];e1=candidate[a][fit]-y[fit]
    target=[((abs(e0)-abs(e1))/unit).ravel(),((e0*e0-e1*e1)/(unit*unit)).ravel()]
    predictions=[]
    for mi in range(2):
     model=fit_model(f's{seed_index}f{fi}a{ai}m{mi}.pkl',xf,target[mi],seed+1000*fi+mi,protocol,tick)
     predictions.append(model.predict(xq).reshape(len(query),30,12));del model
    gains[a]=predictions;del xf,xq,e0,e1,target;gc.collect()
   route_actions={'PURE_DYNAMIC_SELF':['D'],'PURE_STATIC_SELF':['S'],'V7_DYNAMIC_SELF':['VD','VL'],'V7_STATIC_SELF':['VS','VL'],'V7_SELF_ONLY':['VL']}
   log=dict(seed=seed,outer_fold=fi+1,fit=fit.tolist(),calibration=cal.tolist(),evaluation=ev.tolist(),
    removed_fit_boundary=sorted(set(fit0)-set(fit)),fit_last_available=int(data['available'][fit].max()),
    calibration_first_cutoff=int(data['cutoff'][cal[0]]),calibration_last_available=int(data['available'][cal].max()),evaluation_first_cutoff=cut,routes={})
   log['removed_fit_boundary']=[int(j) for j in log['removed_fit_boundary']]
   for route,acts in route_actions.items():
    anchor=local if route.startswith('PURE') else v7
    raw,sel=choose([gains[a] for a in acts],[candidate[a][query] for a in acts],anchor[query])
    cm=headline(raw[:len(cal)],y[cal],data['low_volatility'][cal]);bm=headline(anchor[cal],y[cal],data['low_volatility'][cal])
    checks={k:(cm[k] is not None and bm[k] is not None and cm[k]<=bm[k]+1e-12) for k in bm};enabled=all(checks.values())
    output['RAW_'+route][ev]=raw[len(cal):]
    if enabled:output[route][ev]=raw[len(cal):];selections[route][ev]=sel[len(cal):]
    log['routes'][route]=dict(enabled=enabled,calibration_metrics=cm,anchor_metrics=bm,checks=checks,
      raw_evaluation_action_fraction=float((sel[len(cal):]>0).mean()),final_evaluation_action_fraction=float((selections[route][ev]>0).mean()))
   logs.append(log);s.write(f'fold_s{seed_index}_{fi}.json',log)
   tick(stage='fold_complete',seed=seed,outer_fold=fi+1)
  s.save(f'seed{seed_index}.npz',**output,**{'ACTION_'+k:v for k,v in selections.items()},truth=y,states=data['states'],low=data['low_volatility'],origins=data['origins'],days=days,cutoff=data['cutoff'],learned_mask=learned_mask)
  s.write(f'seed{seed_index}.receipt.json',dict(at=s.now(),seed=seed,sha256=s.sha(dest),fits_completed=20,new_backbone_updates=0,new_test_targets_read=False))
  tick(stage='seed_complete',seed=seed,completed_seeds=seed_index+1,total_seeds=3)
  del experts,v7,output,candidate,base;gc.collect()
 s.write('FIT_COMPLETE.json',dict(at=s.now(),fits=60,seeds=3,known_panel_origins=698,learned_origins=453,no_hyperparameter_search=True))
