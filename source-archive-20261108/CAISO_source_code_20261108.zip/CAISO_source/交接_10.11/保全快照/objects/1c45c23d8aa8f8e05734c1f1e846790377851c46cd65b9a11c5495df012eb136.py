"""Contract, time-leakage, feature and decoder regression checks; zero fits."""
import ast,json,copy,sys
import numpy as np
import support as s
import features

def must_raise(action):
    try:action()
    except AssertionError:return
    raise AssertionError('Expected contract rejection')

def main():
    p=s.verify();checks=[]
    for name in ['manager.py','features.py','compare.py','score_audit.py','register.py']:
        ast.parse((s.N/name).read_text(encoding='utf-8'));checks.append('syntax_'+name)
    selected=s.read(s.N/'SELECTION.json');all_choices=selected['pilot']+selected['remaining']
    assert len({x['cycle'] for x in all_choices})==selected['cycles']
    assert len(selected['pilot'])==24 and all((x['cycle']//3600)%3==0 for x in all_choices)
    checks.append('fixed_clock_population_and24calendar_months')
    shape=(8,len(p['anchors']),3);a=np.arange(np.prod(shape),dtype=float).reshape(shape)+1
    r=dict(center_values=a.tolist(),patch_means=a.tolist(),choice=dict(cycle=0),source_available_by=100)
    at=features.at_times(a,0,3*3600);assert np.array_equal(at[...,0],a[...,0]) and np.array_equal(at[...,-1],a[...,1])
    assert np.array_equal(features.weather_features(r,10800,'COARSE',p),at[[0,2,3],:3,:].ravel())
    checks+=['hour_bracketing','old3city_feature_identity']
    must_raise(lambda:features.at_times(a,0,2*3600));must_raise(lambda:features.at_times(a,0,4*3600))
    late=copy.deepcopy(r);late['source_available_by']=10801
    must_raise(lambda:features.weather_features(late,10800,'MECHANISM',p))
    checks+=['no_extrapolated_or_late_forecast_values']
    base=features.weather_features(r,10800,'MECHANISM',p)
    changed=copy.deepcopy(r);changed['future_actual_prices']=[1e9];changed['future_actual_weather']=[-1e9]
    assert np.array_equal(base,features.weather_features(changed,10800,'MECHANISM',p));checks.append('future_actuals_not_read_by_adapter')
    targets=np.array([[0,11,-12],[0,-11,12],[0,1,2]])
    assert features.first_event(targets,0,10).tolist()==[1,2,0];checks.append('first_entry_competing_direction')
    with s.base.numeric('Supplement source/adapter QA only; no model fit'):
        import manager as m
        oldp=m.P
        # The original, retained byte proof supplies a single immutable geometry fixture.
        candidates=list((s.N.parent/'historical_weather_admission_20261005/grib_receipts').glob('*_F03_TMP.grib2'))
        assert candidates
        blob=candidates[0].read_bytes();assert m.grid_hash(blob)==p['grid_sha256']
        handle=m.ec.codes_new_from_message(blob)
        try:
            geo=m.geometry(handle,p);values=m.ec.codes_get_values(handle)
            replay=np.asarray(m.ec.codes_get_double_elements(handle,'values',[g['index'] for g in geo]))
            assert np.array_equal(replay,values[[g['index'] for g in geo]])
            s.write('GEOMETRY_QA.json',dict(at=s.now(),anchors=geo,fixture=str(candidates[0]),fixture_sha256=s.sha(candidates[0]),old3city_centers_identical=True))
        finally:m.ec.codes_release(handle)
        checks+=['original_grid_hash','11anchor_geometry','old3city_centers_reproduced','indexed_value_replay']
        with np.load(s.N.parent/'forecast_source_inventory_20261005/SOURCE_METADATA_QUALIFICATION.npz') as z:
            use=z['qualified']&np.isin(z['cycle'],[x['cycle'] for x in all_choices])
            roles={str(k):int(np.count_nonzero(use&(z['role']==k))) for k in [0,1,2]}
        s.base.verify_protected()
    s.write('QA.json',dict(at=s.now(),passed=True,checks=checks,origin_roles=roles,model_fits=0,new_test_targets_read=False,protected_files_unchanged=True))
    print(json.dumps(dict(passed=True,checks=len(checks),cycles=selected['cycles'],roles=roles),ensure_ascii=False))

if __name__=='__main__':main()
