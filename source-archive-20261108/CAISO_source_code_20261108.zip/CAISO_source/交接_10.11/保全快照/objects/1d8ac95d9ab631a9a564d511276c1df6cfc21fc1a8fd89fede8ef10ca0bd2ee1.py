"""Fixed TRAIN-only gradient probe; no optimizer update and no heldout data."""
from pathlib import Path
import sys,json
B=Path(__file__).resolve().parents[1]
sys.path.insert(0,str(B/'offhour_adapter_v1_20260925'))
import gate
def main():
 seal=gate.verify();rows=[]
 with gate.exclusive('train_only_horizon_gradient_probe'):
  np,torch,lim=gate.runtime()
  from compiled_data import CompiledData
  from models.factory import build_backbone
  from adapter import AdaptedFULL,fingerprint
  from math_ops import objective
  data=CompiledData(seal['dataset_manifest']);limits=gate.read(data.paths['context_limits.json'])['limits']
  for case in seal['cases']:
   if case['arm']!='OFFHOUR':continue
   r=gate.read(gate.HERE/'runs'/case['id']/'completion.json')
   for epoch in (0,r['selected_epoch']):
    path=gate.inside(r['epochs'][epoch]['checkpoint']);receipt=gate.read(path.with_suffix('.receipt.json'))
    gate.need(gate.sha(path)==receipt['sha256'],'Checkpoint changed')
    model=AdaptedFULL(build_backbone('FULL',case['seed'],limits),case['seed'],'OFFHOUR').eval()
    model.load_state_dict(torch.load(path,map_location='cpu',weights_only=False)['state_dict'],strict=True)
    before=fingerprint(model);per=[]
    for phase in (5,6):
     data.set_epoch(phase)
     starts=np.linspace(0,1007,8,dtype=int)*4
     for start in starts:
      gate.guard();ix=np.arange(start,start+4)
      origins=data.origins['train'][ix];gate.need((origins+12<=210528).all(),'TRAIN target cutoff')
      x,y=data.batch('train',ix);mask=torch.from_numpy((origins%12==0).copy())
      pred=model(torch.from_numpy(x),mask)['prediction'];y=torch.from_numpy(y)
      grad=[]
      for h in range(12):
       g=torch.autograd.grad(objective(pred[:,:,h],y[:,:,h]),tuple(model.adapter.parameters()),retain_graph=True)
       grad.append(torch.cat([v.flatten() for v in g]).detach().double())
      g=torch.stack(grad);n=torch.linalg.vector_norm(g,dim=1);valid=n>1e-14
      cos=g@g.T/(n[:,None]*n[None,:]).clamp_min(1e-30)
      pairs=[float(cos[i,j]) for i in range(12) for j in range(i+1,12) if valid[i] and valid[j]]
      near=g[:4].mean(0);last=g[11];den=float(near.norm()*last.norm())
      per.append(dict(phase=phase,slot_start=int(start),origins=origins.tolist(),active_offhour=int((~mask).sum()),
         pair_count=len(pairs),negative_pairs=sum(v<0 for v in pairs),near_h12_cosine=None if den<=1e-14 else float(near@last)/den))
    gate.need(fingerprint(model)==before,'Probe changed checkpoint')
    valid=[x['near_h12_cosine'] for x in per if x['near_h12_cosine'] is not None]
    rows.append(dict(seed=case['seed'],epoch=epoch,checkpoint=gate.rel(path),checkpoint_sha256=receipt['sha256'],
      batches=per,negative_near_h12_batches=sum(v<0 for v in valid),valid_batches=len(valid),
      mean_near_h12_cosine=sum(valid)/len(valid) if valid else None))
  gate.write(B/'audits/offhour_train_gradient_probe_20260925.json',dict(status='passed',at=gate.now(),rows=rows,
   design='Fixed8 evenly spaced batch starts in each TRAIN epoch5and6; 3seeds, zero and previouslyselected checkpoints; no data-driven slot choice.',
   interpretation='Descriptive task-gradient interference probe; negative minibatch cosines do not establish the unique cause of validation H12 regression.',
   sources={gate.rel(Path(__file__)):gate.sha(Path(__file__))},optimizer_updates=0,heldout_targets_read=False))
  print(json.dumps([dict(seed=x['seed'],epoch=x['epoch'],negative=x['negative_near_h12_batches'],valid=x['valid_batches'],cosine=x['mean_near_h12_cosine']) for x in rows]))
if __name__=='__main__':main()
