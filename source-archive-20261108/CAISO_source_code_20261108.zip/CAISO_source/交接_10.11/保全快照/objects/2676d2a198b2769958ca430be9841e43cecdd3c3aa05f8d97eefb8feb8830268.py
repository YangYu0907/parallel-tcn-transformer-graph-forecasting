"""Separate arithmetic and chronological replay, same operator, not external review."""
from pilot import *

def main():
    policy_check()
    with numeric('independent algebra replay of one conditional gate'):
        import numpy as np
        a=read(HERE/'RESULT.json');f=read(HERE/'GATE_FROZEN.json')
        assert sha(HERE/'REPLAY.npz')==a['replay_sha256']
        assert sha(HERE/'GATE_FROZEN.json')==a['gate_sha256']
        with np.load(HERE/'REPLAY.npz') as z:d={k:z[k] for k in z.files}
        assert np.isfinite(d['candidate']).all() and np.isfinite(d['X']).all()
        for key,weight in [('fixed25',.25),('fixed50',.5)]:
            matched=d['full'].copy()
            matched[:,:,7:]+=weight*(d['other'][:,:,7:]-d['full'][:,:,7:])
            assert np.array_equal(matched,d[key])
        fe=d['full'][:,:,7:]-d['truth'][:,:,7:]
        ce=d['fixed25'][:,:,7:]-d['truth'][:,:,7:]
        assert np.allclose((abs(fe)-abs(ce)).ravel()/f['scale'],d['scaled_gain_mae'],atol=1e-12)
        assert np.allclose((fe**2-ce**2).ravel()/f['scale']**2,d['scaled_gain_mse'],atol=1e-12)
        r=np.repeat(d['role'],150);days=np.repeat(d['dates'],150);fit=r==0;cal=r==1;ev=d['role']==2
        assert days[fit].max()<days[cal].min()<days[r==2].min()
        x=d['X'];med=np.median(x[fit],0);spread=np.maximum(np.percentile(x[fit],75,axis=0)-np.percentile(x[fit],25,axis=0),1e-6)
        design=np.c_[np.ones(len(x)),np.maximum(-6,np.minimum(6,(x-med)/spread))]
        pen=np.diag([0.]+[1.]*10)
        target=np.c_[d['scaled_gain_mae'],d['scaled_gain_mse']]
        coef=np.linalg.solve(design[fit].T.dot(design[fit])+fit.sum()*pen,design[fit].T.dot(target[fit]))
        assert np.allclose(coef,f['model']['coef'],rtol=1e-10,atol=1e-10)
        pred=design@coef
        residual=pred-target
        perday=np.array([residual[cal&(days==v)].sum(0)/(cal&(days==v)).sum() for v in np.unique(days[cal])])
        margin=np.maximum(0,perday.mean(0)+2*perday.std(0,ddof=1)/len(perday)**.5)
        assert np.allclose(margin,f['margin'],rtol=1e-10,atol=1e-10)
        support=((x>=x[fit].min(0))&(x<=x[fit].max(0))).all(1)
        alpha=.25*np.maximum(0,np.minimum(1,np.min((pred-margin)/(abs(pred)+margin+1e-8),1)))
        alpha[~support]=0;alpha=alpha.reshape(len(d['origins']),30,5)
        assert np.allclose(alpha,d['alpha'],atol=1e-10,rtol=1e-9)
        expected=d['full'].copy();expected[:,:,7:]=(1-alpha)*d['full'][:,:,7:]+alpha*d['other'][:,:,7:]
        assert np.allclose(expected,d['candidate'],atol=1e-10,rtol=1e-12)
        assert np.array_equal(d['candidate'][:,:,:7],d['full'][:,:,:7])
        checks=12
        for row,key in zip(a['rows'],['full','other','fixed25','fixed50','candidate']):
            err=d[key][ev]-d['truth'][ev]
            vals=dict(mae=np.sum(abs(err))/err.size,rmse=(np.sum(err**2)/err.size)**.5,
                      near_mae=np.sum(abs(err[:,:,:4]))/err[:,:,:4].size,h12_mae=np.sum(abs(err[:,:,-1]))/err[:,:,-1].size)
            for k,v in vals.items():assert abs(v-row[k])<1e-9;checks+=1
        for row in a['states']:
            mask=d['states'][ev]==row['state'];assert mask.sum()==row['cells'];checks+=1
            assert len(np.unique(d['dates'][ev][mask.any((1,2))]))==row['dates'];checks+=1
            for kind,key in [('parent','full'),('candidate','candidate')]:
                err=(d[key][ev]-d['truth'][ev])[mask]
                if len(err):
                    assert abs(np.sum(abs(err))/len(err)-row[kind]['mae'])<1e-9
                    assert abs(np.linalg.norm(err)/len(err)**.5-row[kind]['rmse'])<1e-9;checks+=2
                else:assert row[kind] is None
        parent=a['rows'][0];candidate=a['rows'][-1]
        expected_checks=dict(headline_nonworse=all(candidate[k]<=parent[k]+1e-10 for k in ['mae','rmse','near_mae','h12_mae']),
            beats_fixed25=candidate['mae']<a['rows'][2]['mae'],h12_beats_iTransformer=candidate['h12_mae']<a['rows'][1]['h12_mae'],
            every_horizon_nonworse=bool(np.all(abs(d['candidate'][ev]-d['truth'][ev]).mean((0,1))<=abs(d['full'][ev]-d['truth'][ev]).mean((0,1))+1e-10)),
            state_support=all(row['dates']>=5 for row in a['states']),
            state_nonworse=all(row['parent'] is not None and all(row['candidate'][k]<=row['parent'][k]+1e-10 for k in ['mae','rmse']) for row in a['states']),
            near_exact=bool(np.array_equal(d['candidate'][:,:,:7],d['full'][:,:,:7])))
        assert expected_checks==a['checks'] and all(expected_checks.values())==a['screen_passed'];checks+=8
        policy_check()
        write(HERE/'AUDIT.json',dict(at=now(),status='separate_formula_replay_passed',checks=checks,
             result_sha256=sha(HERE/'RESULT.json'),chronological_split_replayed=True,fit_excludes_forward_labels=True,
             original_core_and_V7_unchanged=verify_protected(),new_test_targets_read=False,
             independence='Separate script/algebra, same operator; not external human review'))
        print(json.dumps(dict(audit='passed',checks=checks)))

if __name__=='__main__':main()
