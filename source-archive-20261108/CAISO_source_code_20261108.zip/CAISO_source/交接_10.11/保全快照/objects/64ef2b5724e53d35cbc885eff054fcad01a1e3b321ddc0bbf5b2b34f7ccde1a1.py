"""Frozen TRAIN/June-only common evaluation gates; no tuning and no target extension."""
from pathlib import Path
from contextlib import contextmanager
from datetime import datetime, timezone
import argparse, hashlib, json, os, sys, uuid
HERE=Path(__file__).resolve().parent
ROOT=HERE.parent
V=ROOT/'phase_sampling_support_v3_20260923'
sys.path.insert(0,str(ROOT/'source'))
import compile_gate as resources_api
LOCK=Path('D:/Desktop/数据科学_论文/研究优化_20260818/logs/NEURAL_RUN.lock')
SEAL=HERE/'EVALUATION_LOCK.json'
def now():return datetime.now(timezone.utc).isoformat()
def read(p):return json.loads(Path(p).read_text(encoding='utf-8-sig'))
def need(value,message):
    if not value:raise RuntimeError(message)
def inside(p):
    p=Path(p);p=(ROOT/p if not p.is_absolute() else p).resolve()
    need(p.is_relative_to(ROOT),'Path escaped research branch')
    return p
def rel(p):return str(inside(p).relative_to(ROOT))
def sha(p):
    h=hashlib.sha256()
    with Path(p).open('rb') as f:
        for c in iter(lambda:f.read(1024*1024),b''):h.update(c)
    return h.hexdigest()
def atomic(p,writer,replace=False):
    p=inside(p);p.parent.mkdir(parents=True,exist_ok=True)
    temp=p.with_name(p.name+'.'+uuid.uuid4().hex+'.pending')
    with temp.open('xb') as f:writer(f);f.flush();os.fsync(f.fileno())
    if replace:os.replace(temp,p)
    else:temp.rename(p)
def write(p,value,replace=False):
    raw=json.dumps(value,ensure_ascii=False,indent=2,allow_nan=False).encode('utf-8')
    atomic(p,lambda f:f.write(raw),replace)
def boundary():
    for folder in (ROOT,HERE,HERE/'queue',V):
        for name in ('STOP_REQUESTED','STOP_REQUESTED.json'):
            if (folder/name).exists():raise InterruptedError('User stop: '+str(folder/name))
    p=read(ROOT.parent/'RESEARCH_PAUSED.json')
    if p.get('status')!='resumed_by_user' or p.get('stop_preparation_and_training'):
        raise InterruptedError('User paused research')
def guard(launch=False):
    boundary();r=resources_api.resources()
    floor=5 if launch else 4
    if min(r.values())<floor:raise MemoryError(f'Evaluation requires {floor} GiB physical RAM and commit; actual {r}')
    return r
@contextmanager
def exclusive(action):
    guard(True)
    import psutil
    owner=dict(pid=os.getpid(),created=psutil.Process().create_time(),token=uuid.uuid4().hex,action=action,at=now())
    with LOCK.open('x',encoding='utf-8') as f:json.dump(owner,f);f.flush();os.fsync(f.fileno())
    try:
        guard()
        resources_api.bound_process()
        yield
    finally:
        need(read(LOCK)==owner,'Numerical owner changed')
        write(HERE/'lock_releases'/(owner['token']+'.json'),dict(owner=owner,at=now()))
        LOCK.unlink()
def verify():
    boundary();s=read(SEAL)
    need(s['status']=='sealed_common_backbone_evaluation','Evaluation not sealed')
    for p,d in s['bindings'].items():need(sha(inside(p))==d,'Bound input changed: '+p)
    need(len(s['cases'])==12,'Expected exactly twelve cases')
    return s
def runtime(torch_needed=False):
    resources_api.bound_process()
    import numpy as np
    from threadpoolctl import threadpool_limits,threadpool_info
    limiter=threadpool_limits(1)
    need(all(x['num_threads']==1 for x in threadpool_info()),'Thread limit')
    if torch_needed:
        import torch
        torch.set_num_threads(1);torch.set_num_interop_threads(1)
        torch.use_deterministic_algorithms(True)
        guard()
        return np,torch,limiter
    guard();return np,limiter
def seal():
    boundary();need(not SEAL.exists(),'Immutable evaluation seal already exists')
    bindings={}
    def bind(p,expected=None):
        p=inside(p);d=sha(p)
        if expected is not None:need(d==expected,'Hash mismatch: '+rel(p))
        bindings[rel(p)]=d;return read(p) if p.suffix=='.json' else d
    comp=bind(V/'queue/completion.json','8f7b617467cda17f6066a9e961d5b0f567aabbcb20eafb3f1f377bd570c52955')
    need(comp['status']=='eight_sampling_backbones_independently_audited','Sampling not audited')
    need(not(V/'queue/QUEUE.lock').exists(),'Sampling manager has not exited')
    s=bind(V/'EXECUTION_SEAL.json',comp['execution_seal_sha256'])
    for p,d in s['sources'].items():bind(p,d)
    plan=bind(V/'PLAN.json')
    need(len(plan['steps'])==len(comp['step_receipts'])==20,'Incomplete finite queue')
    for step in plan['steps']:
        name=step['id']+'.json'
        rec=bind(V/'queue/steps'/name,comp['step_receipts'][name])
        need(rec['step']==step and rec['exit_code']==0,'Receipt does not prove success')
        marker=bind(rec['marker']['path'],rec['marker']['sha256'])
        need(marker['status']==step['success_status'],'Marker status mismatch')
    for p in sorted(HERE.glob('*.py')):bind(p)
    bind(HERE/'PROTOCOL.json')
    bind(HERE/'watch_manager_exit.ps1')
    qa=bind(HERE/'synthetic_qa.json')
    need(qa['status']=='passed','Synthetic evaluation QA missing')
    for p,d in qa['sources'].items():need(bind(p)==d,'QA source changed')
    parent=ROOT/'dataset/compiled_train_june/manifest.json'
    manifest=bind(parent,'f84ae6c3b3bcb9c8f0cf80dc34c6e102631c74aa0d012fd0263ba2beefe6c725')
    pa=bind(parent.parent/'audit.json')
    need(pa['status']=='passed' and pa['dataset_manifest_sha256']==sha(parent),'Parent dataset unaudited')
    need(manifest['prefix_stop']==219168 and manifest['train_target_stop_exclusive']==210528,'Cutoff differs')
    for row in manifest['artifacts'].values():bind(row['path'],row['sha256'])
    diag=V/'dataset/train_diagnostic_origins.npy'
    bind(diag);da=bind(V/'dataset/schedule_audit.json')
    need(da['status']=='passed','Diagnostic metadata not audited')
    bind(V/'dataset/schedule.json',da['schedule_sha256'])
    # Bind actual model sources, including original checkpoint admission lock.
    old_lock=bind(ROOT/'BACKBONE_LOCK.json')
    for p,d in old_lock['sources'].items():bind(p,d)
    new_lock=bind(V/'SAMPLING_RUNNER_LOCK.json')
    for p,d in new_lock['sources'].items():bind(p,d)
    cases=[]
    for policy in ('ORIGINAL','REPEAT','ADDITIVE'):
        for seed in (20260813,20260814):
            for variant in ('FULL','TCN'):
                base=ROOT/'runs/backbone'/f'{seed}_{variant}' if policy=='ORIGINAL' else V/'runs'/policy/'backbone'/f'{seed}_{variant}'
                cp=base/'backbone_completion.json';ap=base/'backbone_audit.json'
                c=bind(cp);a=bind(ap)
                need(a['status']=='passed' and a['backbone_completion_sha256']==sha(cp),'Stale case audit')
                need(c['scope']=='backbone_only' and c['optimizer_steps']==(3024 if policy=='ORIGINAL' else 6048),'Stage/budget mismatch')
                identity=c['identity']
                need(identity['variant']==variant and identity['seed']==seed,'Case identity mismatch')
                dm=bind(identity['dataset_manifest'],identity['dataset_manifest_sha256'])
                au=bind(inside(identity['dataset_manifest']).parent/'audit.json',identity['dataset_audit_sha256'])
                need(au['status']=='passed','Case data not audited')
                for k in ('features.npy','target_scaled.npy','scalers.json','context_limits.json','registered_june_origins.npy','june_origins.npy'):
                    need(dm['artifacts'][k]==manifest['artifacts'][k],'Shared input mismatch: '+k)
                epochs=[]
                for e in c['epochs']:
                    ck=inside(e['checkpoint']);r=bind(ck.with_suffix('.receipt.json'))
                    bind(ck,r['sha256']);bind(e['prediction'],e['prediction_sha256'])
                    need(r['identity']==identity and r['phase']=='epoch_complete','Epoch receipt mismatch')
                    epochs.append(dict(epoch=e['epoch'],checkpoint=e['checkpoint'],checkpoint_sha256=r['sha256'],original_june=e['june']))
                need([x['epoch'] for x in epochs]==list(range(1,7)),'Missing epoch')
                selected=next(e for e in c['epochs'] if e['epoch']==c['selected_epoch'])
                need(selected['checkpoint']==c['selected_checkpoint'],'Selected checkpoint not in epochs')
                bind(c['selected_checkpoint'],c['selected_checkpoint_sha256'])
                cases.append(dict(id=f'{policy}_{seed}_{variant}',policy=policy,seed=seed,variant=variant,
                    completion=rel(cp),audit=rel(ap),identity=identity,selected_epoch=c['selected_epoch'],
                    selected_checkpoint=c['selected_checkpoint'],selected_prediction=selected['prediction'],
                    reference_metrics=c['selected_june'],epochs=epochs))
    report=dict(status='sealed_common_backbone_evaluation',at=now(),bindings=bindings,cases=cases,
        dataset_manifest=rel(parent),train_diagnostic=rel(diag),heldout_targets_read=False,
        model_selection_changed=False,review_independence='Distinct numeric reduction/oracle algorithms executed by same operator; no second-person review asserted')
    write(SEAL,report)
    print(json.dumps(dict(status=report['status'],case_count=12,bound_files=len(bindings),seal_sha256=sha(SEAL))))
if __name__=='__main__':
    p=argparse.ArgumentParser();p.add_argument('action',choices=['seal','check']);a=p.parse_args()
    if a.action=='seal':seal()
    else:print(json.dumps(dict(status='passed',cases=len(verify()['cases']),resources=guard(True))))

