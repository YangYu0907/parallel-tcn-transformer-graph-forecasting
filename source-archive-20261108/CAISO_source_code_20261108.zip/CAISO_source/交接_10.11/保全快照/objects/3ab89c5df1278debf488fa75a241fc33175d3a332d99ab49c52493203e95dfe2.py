"""Finite authorized H1 prediction, scoring and audit; no auto-release."""
import os,subprocess,sys,uuid
from runtime_gate import HERE,c,verify_release
Q=HERE/'queue'

def status(event,**kw):
    body=dict(event=event,at=c.now(),pid=os.getpid(),**kw);p=Q/'events'/(uuid.uuid4().hex+'.json')
    c.write(p,body);c.write(Q/'status.json',body);return p
def notify(kind,path):
    key='h1_final_'+kind+'_'+c.sha(path);dest=c.BRANCH/'event_driven_automation/inbox'/(key+'.json')
    if not dest.exists():c.write(dest,dict(schema='caiso_research_event_v1',event_id=key,event=kind,evidence_path=str(path),complete_research_experiment=False,
        instruction='Frozen H1 final evaluation. Retain every direction; no test-driven tuning. Numerical completion precedes final manuscript and comprehensive review.'))
    return key
def main():
    verify_release();c.guard(True);c.need(not c.SHARED_LOCK.exists(),'Another numerical worker')
    import psutil,json
    Q.mkdir(parents=True,exist_ok=True);owner=dict(pid=os.getpid(),created=psutil.Process().create_time(),token=uuid.uuid4().hex)
    lock=Q/'QUEUE.lock'
    with lock.open('x',encoding='utf-8') as h:json.dump(owner,h);h.flush();os.fsync(h.fileno())
    child=None
    try:
        for script,marker in [('inference.py','ALL_PREDICTIONS_COMMITTED.json'),('score.py','TEST_RESULTS.json'),('audit.py','TEST_AUDIT.json')]:
            verify_release();c.guard(True);receipt=Q/(script+'.receipt.json')
            if receipt.exists():
                r=c.read(receipt);c.need(r['exit_code']==0 and r['marker_sha256']==c.sha(HERE/marker),'Step changed');continue
            c.need(not (HERE/marker).exists(),'Unreceipted completion needs explicit recovery review')
            out=Q/(script+'_'+owner['token']+'.stdout.log');err=Q/(script+'_'+owner['token']+'.stderr.log')
            with out.open('xb') as fo,err.open('xb') as fe:
                child=subprocess.Popen([sys.executable,'-X','utf8',str(HERE/script)],cwd=HERE,stdout=fo,stderr=fe,creationflags=getattr(subprocess,'CREATE_NO_WINDOW',0))
                status('step_process_started',step=script,child_pid=child.pid,stdout=str(out),stderr=str(err));code=child.wait()
            c.need(code==0,'Final worker stopped: '+str(err))
            c.write(receipt,dict(exit_code=code,at=c.now(),marker_sha256=c.sha(HERE/marker)))
        audit=c.read(HERE/'TEST_AUDIT.json');c.need(audit['status']=='passed','Result audit failed')
        done=Q/'completion.json';c.write(done,dict(status='frozen_H1_numerical_evaluation_audited',at=c.now(),
            result=str(HERE/'TEST_RESULTS.json'),result_sha256=c.sha(HERE/'TEST_RESULTS.json'),audit=str(HERE/'TEST_AUDIT.json'),audit_sha256=c.sha(HERE/'TEST_AUDIT.json'),complete_research_experiment=False))
        eid=notify('audited_result_ready',done);status('finite_sampling_queue_completed',event_id=eid)
    except Exception as exc:
        paused=False
        try:c.boundary()
        except InterruptedError:paused=True
        paused=paused or any((HERE/n).exists() for n in ('STOP_REQUESTED','STOP_REQUESTED.json'))
        p=status('user_stop' if paused else 'step_stopped_or_failed',reason=repr(exc))
        if not paused:
            eid=notify('blocking_failure',p);status('step_stopped_or_failed',reason=repr(exc),event_id=eid)
        return 3 if paused else 2
    finally:
        if child and child.poll() is None:child.wait()
        c.need(c.read(lock)==owner,'Final manager lock owner changed');c.write(Q/'lock_releases'/(owner['token']+'.json'),dict(owner=owner,at=c.now()));lock.unlink()
    return 0

if __name__=='__main__':raise SystemExit(main())
