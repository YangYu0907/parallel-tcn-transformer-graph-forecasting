"""Actual Windows long-path durability checks using synthetic bytes/arrays only."""
from pathlib import Path
import hashlib
import json
import os
import uuid
import win_stage_io as io

for name in ('OMP_NUM_THREADS', 'MKL_NUM_THREADS', 'OPENBLAS_NUM_THREADS'):
    os.environ[name] = '1'


def run():
    base = io.inside('audits/io_v2_runs')/uuid.uuid4().hex[:12]
    folder = base/('a'*90)/('b'*70)/('c'*65)
    path = folder/'payload.json'
    assert len(str(path)) > 300
    checks = []
    value = {'kind': 'synthetic', 'path': str(path.relative_to(io.ROOT)), 'value': 7}
    io.write(path, value)
    assert io.read(path) == value
    checks.append('actual_extended_path_json_write_read_over_300_characters')
    raw = path.read_bytes()
    assert io.sha(path) == hashlib.sha256(raw).hexdigest()
    checks.append('deep_path_sha256_matches_bytes')
    try:
        io.write(path, {'value': 8})
    except FileExistsError:
        pass
    else:
        raise AssertionError('Immutable commit overwrote an existing file')
    assert path.read_bytes() == raw
    checks.append('immutable_rename_rejects_overwrite_and_preserves_existing_bytes')
    io.write(path, {'version': 2}, replace=True)
    assert io.read(path) == {'version': 2}
    checks.append('explicit_atomic_replacement_commits_new_bytes')
    before = path.read_bytes()
    def interrupted(stream):
        stream.write(b'uncommitted partial bytes')
        raise RuntimeError('synthetic interruption before rename')
    try:
        io.atomic(path, interrupted, replace=True)
    except RuntimeError:
        pass
    else:
        raise AssertionError('Synthetic interrupted writer did not fail')
    assert path.read_bytes() == before
    checks.append('interrupted_writer_preserves_previous_committed_target')
    absent = folder/'never_committed.bin'
    try:
        io.atomic(absent, interrupted)
    except RuntimeError:
        pass
    assert not absent.exists()
    io.atomic(absent, lambda stream: stream.write(b'recovered'))
    assert absent.read_bytes() == b'recovered'
    checks.append('failed_first_write_leaves_no_target_and_clean_retry_succeeds')
    assert not str(path).startswith('\\\\?\\') and io.inside(str(path)) == path
    assert str(path.relative_to(io.ROOT)) == value['path']
    checks.append('persisted_metadata_keeps_ordinary_canonical_paths')
    assert io.path(os.fspath(path)) == path and io.inside(os.fspath(path)) == path
    checks.append('extended_OS_path_roundtrip_retains_canonical_identity')
    try:
        io.inside('../outside_branch.bin')
    except ValueError:
        pass
    else:
        raise AssertionError('Traversal escaped the branch')
    checks.append('branch_boundary_rejects_parent_traversal')
    import numpy as np
    array = np.arange(24, dtype=np.float64).reshape(4, 6)
    array_path = folder/'array.npy'
    io.atomic(array_path, lambda stream: np.save(stream, array, allow_pickle=False))
    assert np.array_equal(np.load(array_path, allow_pickle=False), array)
    mapped = np.load(array_path, mmap_mode='r', allow_pickle=False)
    assert np.array_equal(mapped, array)
    mapped._mmap.close()
    checks.append('numpy_save_load_and_readonly_memmap_accept_deep_StagePath')
    map_path = folder/'mapped.npy'
    mapped = np.lib.format.open_memmap(map_path, mode='w+', dtype=np.float32, shape=(2, 3))
    mapped[:] = 2
    mapped.flush()
    mapped._mmap.close()
    assert np.array_equal(np.load(map_path, allow_pickle=False), np.full((2, 3), 2, np.float32))
    checks.append('numpy_open_memmap_write_flush_and_reload_accept_deep_StagePath')
    found = {str(p.relative_to(base)) for p in base.rglob('*') if p.is_file()}
    assert str(path.relative_to(base)) in found and str(map_path.relative_to(base)) in found
    checks.append('deep_directory_walk_and_file_detection_work')
    report = {'status': 'passed', 'synthetic_only': True, 'checks': checks,
              'test_count': len(checks), 'tested_target_characters': len(str(path)),
              'helper_sha256': io.sha(Path(__file__).with_name('win_stage_io.py')),
              'qa_source_sha256': io.sha(__file__), 'test_directory': str(base.relative_to(io.ROOT)),
              'backbone_source_sha256': io.sha(io.ROOT/'source/backbone_train.py'),
              'real_market_arrays_read': False, 'global_Windows_settings_changed': False}
    io.write(base/'report.json', report)
    io.write(io.ROOT/'audits/win_stage_io_qa.json', report)
    return report


if __name__ == '__main__':
    print(json.dumps(run(), ensure_ascii=True))
