"""Close the finite optimizer pilot without selecting on secondary outcomes."""
import common as c
import statistics


def main():
    protocol = c.verify()
    audit = c.read(c.HERE / 'AUDIT.json')
    assert audit['status'] == 'passed'
    for name in ('result', 'decision'):
        assert c.sha(c.HERE / (name.upper() + '.json')) == audit[name + '_sha256']
    checked = 0
    rows = []
    with c.gate.exclusive('V21 finite optimizer terminal evidence verification'):
        np, torch, _ = c.gate.runtime(True)
        for case in protocol['cases']:
            result = c.read(c.HERE / 'runs' / case['run_id'] / 'result.json')
            assert result['selected_epoch'] == 0
            assert [x['epoch'] for x in result['history']] == [0, 1, 2]
            for item in result['history']:
                c.check()
                for key in ('prediction', 'checkpoint'):
                    assert c.sha(item[key]) == item[key + '_sha256']
                    checked += 1
                with np.load(item['prediction'], allow_pickle=False) as z:
                    err = z['prediction'] - z['truth']
                    codes = z['codes']
                    reported = item['metrics']['June3397']
                    assert abs(np.abs(err).mean() - reported['mae']) < 1e-9
                    assert abs(np.sqrt(np.square(err).mean()) - reported['rmse']) < 1e-9
                    checked += 2
                    states = []
                    for state in range(6):
                        e = err[codes == state]
                        m = reported['by_state'][state]
                        assert len(e) == m['count']
                        assert abs(np.abs(e).mean() - m['mae']) < 1e-9
                        assert abs(np.sqrt(np.square(e).mean()) - m['rmse']) < 1e-9
                        checked += 3
                        states.append({'state': state, 'mae': m['mae'], 'rmse': m['rmse']})
                    rows.append(dict(id=case['run_id'], arm=case['arm'], variant=case['variant'],
                                     seed=case['seed'], epoch=item['epoch'], mae=reported['mae'],
                                     rmse=reported['rmse'], states=states))
        c.fc.preserved()
        checked += 17
    summary = []
    for arm in ('SUM', 'PCGRAD'):
        for epoch in (0, 1, 2):
            subset = [r for r in rows if r['arm'] == arm and r['variant'] == 'FULL' and r['epoch'] == epoch]
            assert len(subset) == 3
            summary.append(dict(arm=arm, epoch=epoch,
                                mae=statistics.mean(r['mae'] for r in subset),
                                rmse=statistics.mean(r['rmse'] for r in subset),
                                states=[dict(state=s, **{k: statistics.mean(r['states'][s][k] for r in subset)
                                                        for k in ('mae', 'rmse')}) for s in range(6)]))
    review = dict(at=c.now(), status='completed_audited_not_promoted', cases=18, verified_epochs=54,
                  additional_raw_scoring_checks=checked, selected_epoch0_cases=18,
                  scope='June3397 inspected development, three seed metric means; no new final test',
                  fixed_epoch_FULL_summary=summary,
                  facts=[
                      'Both optimizer arms performed two training passes; all eighteen selected checkpoints remain epoch0 by the registered primary-MAE rule.',
                      'The fixed epoch2 PCGrad FULL reduces recovery S3 RMSE but raises overall MAE and S4/S5 RMSE relative to its starting V21-F model.',
                      'PCGrad attenuates several regressions relative to matched SUM at fixed epochs; it does not provide an admissible all-metric improvement over the starting model.',
                      'No best-secondary-metric checkpoint is promoted or substituted into the main result table.'
                  ],
                  interpretation='Local training-gradient conflict is real, but removing opposing gradient components is insufficient in this frozen-adapter configuration. Better discrimination of situations may require origin-available information or learned representations; neither additional capacity nor missing information is established by this pilot.',
                  next='Close this optimizer candidate without changing its losses, LR, epochs or selection. Before any further model addition, establish on chronological TRAIN-only out-of-sample records whether recovery versus continued-spike context is distinguishable at the prediction origin. No fresh independent panel is currently admitted; preserve V7 and sealed targets.',
                  next_matched_comparison_if_feasible='Same objective and capacity: a causal context-conditioned correction versus a context-blind correction, applied equally to FULL/EQUAL/CONCAT. Register one candidate only after adequate chronological support and a distinct input/representation hypothesis are demonstrated.',
                  benefits_and_costs='Conditional corrections could separate opposite update needs; estimating gates on rare events adds variance and can harm routine accuracy. A local gradient projection cannot guarantee unseen Pareto improvement.',
                  literature=protocol['literature'], V7_preserved=True, new_test_targets_read=False,
                  model_promoted=False, further_training_started=False, complete_research_experiment=False)
    c.write(c.HERE / 'OUTCOME_REVIEW.json', review)
    c.write(c.HERE / 'TERMINAL_VERIFICATION.json', dict(at=c.now(), status='passed', checks=checked,
             review_sha256=c.sha(c.HERE / 'OUTCOME_REVIEW.json'), audit_sha256=c.sha(c.HERE / 'AUDIT.json'),
             scope='Separate raw scoring of every saved epoch; same operator, no independent-person review'))
    failure = c.read(c.F / 'DIAGNOSIS_STATUS.json')
    da = c.read(c.F / 'DIAGNOSIS_AUDIT.json')
    assert da['status'] == 'passed' and da['diagnosis_sha256'] == c.sha(c.F / 'DIAGNOSIS.json')
    resolution = dict(at=c.now(), status='resolved_and_audited', prior_status=failure,
        repair=str(c.F / 'DIAGNOSIS_IO_REPAIR.json'), audit=str(c.F / 'DIAGNOSIS_AUDIT.json'),
        explanation='Finite progress-JSON sharing-violation retry; prior failure preserved. Rerun exited0 and197 arithmetic checks passed. No changed scientific computation or extra model fit.',
        duplicate_failure_notification_required=False)
    c.write(c.F / 'DIAGNOSIS_RESOLUTION.json', resolution)
    c.write(c.F / 'DIAGNOSIS_STATUS.json', dict(at=c.now(), event='diagnosis_completed', status='passed',
         resolution=str(c.F / 'DIAGNOSIS_RESOLUTION.json'), active=False))
    current = c.read(c.ROUND / 'CURRENT_STATUS.json')
    current.update(at=c.now(), status='H_G_F_and_gradient_conflict_closed_no_promotion', numerical_worker_active=False)
    current['F'].update(diagnosis=str(c.F / 'DIAGNOSIS.json'), diagnosis_audit=str(c.F / 'DIAGNOSIS_AUDIT.json'),
                        next=review['next'])
    current['gradient_conflict'] = dict(status=review['status'], cases=18,
        protocol=str(c.HERE / 'PROTOCOL.json'), result=str(c.HERE / 'RESULT.json'), audit=str(c.HERE / 'AUDIT.json'),
        decision=str(c.HERE / 'DECISION.json'), outcome_review=str(c.HERE / 'OUTCOME_REVIEW.json'),
        terminal_verification=str(c.HERE / 'TERMINAL_VERIFICATION.json'), launch=c.read(c.HERE / 'LAUNCH.json'),
        manager_exited=True, selected_epoch0_cases=18, new_model_promoted=False)
    c.write(c.ROUND / 'CURRENT_STATUS.json', current)
    handoff = c.read(c.ROOT / 'HANDOFF.json')
    handoff.update(updated_at=c.now(), status=current['status'], research_training_active=False,
                   complete_research_experiment=False, next_action=review['next'])
    handoff['multi_round_mechanism_v21'].update(at=c.now(), status=current['status'], new_fits=42,
        completed_gradient_conflict_fits=18, new_fits_note='15graph continuations +9Fadapter fits +18matched optimizer continuations;18H regressors recorded separately.',
        numerical_worker_active=False, manager_pid=None, exit_listener_pid=None,
        current_protocol=str(c.HERE / 'PROTOCOL.json'), current_run_status=str(c.HERE / 'status.json'),
        current_progress=str(c.HERE / 'progress.json'), latest_review=str(c.HERE / 'OUTCOME_REVIEW.json'),
        diagnostic_resolution=str(c.F / 'DIAGNOSIS_RESOLUTION.json'))
    c.write(c.ROOT / 'HANDOFF.json', handoff)
    c.write(c.ROUND / 'CONFLICT_EVENT_HANDLED.json', dict(at=c.now(), event_id=c.read(c.HERE / 'status.json')['event_id'],
        evidence_sha256=c.sha(c.HERE / 'AUDIT.json'), processed_in_active_fusion_event_turn=True,
        report_with_event='168e9e4a659eafcc084dd3e12ba8eb32ef980fe928c6e6c2525ee18a2dbbe34f',
        repeated_notification_required=False, V7_preserved=True))
    print({'status': current['status'], 'checked': checked, 'FULL_fixed_epochs': summary})


if __name__ == '__main__':
    main()
