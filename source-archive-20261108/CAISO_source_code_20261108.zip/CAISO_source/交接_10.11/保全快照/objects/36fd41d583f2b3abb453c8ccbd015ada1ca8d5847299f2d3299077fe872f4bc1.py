"""Finite renewable source/version coverage audit. No price-target reader or training."""
from probe_metadata import *
from datetime import timedelta
from email.utils import parsedate_to_datetime
import hashlib,traceback
ROOT=B.parent/'availability_reconstruction_20260913'

def sec(x):return int(datetime.fromisoformat(x.replace('Z','+00:00')).timestamp())
def fmt(x):return x.strftime('%Y%m%dT%H:%M-0000')
def moved(x):return Path(str(x).replace('C:\\Users\\于阳\\CAISO_feature_fusion_rev12',str(B.parent)))
def csvrows(body):
 if body[:2]==b'PK':
  with zipfile.ZipFile(io.BytesIO(body)) as z:
   for item in z.infolist():
    gate.need(item.filename.lower().endswith('.csv'),'NonCSV reply '+z.read(item)[:200].decode('utf8','replace'))
    gate.need(item.file_size<60_000_000,'Expansion limit')
    with z.open(item) as f:yield from csv.DictReader(io.TextIOWrapper(f,encoding='utf-8-sig',newline=''))
 else:yield from csv.DictReader(io.StringIO(body.decode('utf-8-sig')))

def event(kind,path):
 eid='renewable_admission_v16_'+kind+'_'+gate.sha(path)
 gate.write(B/'event_driven_automation/inbox'/(eid+'.json'),dict(schema='caiso_research_event_v1',event_id=eid,event=kind,evidence_path=str(path),at=gate.now(),trial=str(HERE),new_test_targets_read=False))
 return eid

def main():
 queue=HERE/'renewable_queue';status=queue/'status.json';ART.mkdir(parents=True,exist_ok=True)
 state=dict(at=gate.now(),pid=os.getpid(),event='source_preflight',status='running',training_started=False)
 gate.write(status,state)
 try:
  gate.boundary();gate.need(not (queue/'completion.json').exists(),'Already complete; no duplicate collection')
  jobs=[]
  for label,a,b in [('development','2023-06-01','2025-01-01'),('candidate','2026-09-01','2026-10-01')]:
   t=datetime.fromisoformat(a).replace(tzinfo=timezone.utc);end=datetime.fromisoformat(b).replace(tzinfo=timezone.utc)
   while t<end:
    nxt=min(t+timedelta(days=28),end);jobs.append(dict(id=label+'_'+t.strftime('%Y%m%d'),params=dict(queryname='SLD_REN_FCST',market_run_id='DAM',version=1,startdatetime=fmt(t),enddatetime=fmt(nxt),resultformat=6)));t=nxt
  # Refresh all publication activity after sources are retrieved. Reuse audited older raw ledgers.
  for a,b in [('2026-09-01','2026-09-16'),('2026-09-16','2026-10-01')]:
   jobs.append(dict(id='publication_'+a,params=dict(queryname='ATL_PUB',market_run_id='DAM',oasis_section='ALL',status='ALL',atlpubversion='ALL',version=1,startdatetime=a.replace('-','')+'T00:00-0000',enddatetime=b.replace('-','')+'T00:00-0000',resultformat=6)))
  protocol=queue/'PROTOCOL.json'
  if not protocol.exists():gate.write(protocol,dict(at=gate.now(),script_sha256=gate.sha(__file__),jobs=jobs,maximum_elapsed_seconds=1200,request_gap_seconds=8,attempts_per_request=1,
   scope='Source audit only: exact3tradinghubs by2renewabletypes, hourlytimestamps, complete historical publication ledger and input-slot coverage. No raw price/forecast numeric decoding, training, label scoring or test release.',
   candidate_period='September2026 metadata/source candidate only; separate access-history and price-input admission required',
   next_matched_comparison='Only after input and new-confirmation admission: existing prefix specialist versus same specialist plus released wind/solar forecast features, same splits/settings. No new model grid.',
   preserve='OriginalFULL,V7 and all historical results untouched',dependencies={str(B/'calibration_recurrence_v15_20260930/DECISION.json'):gate.sha(B/'calibration_recurrence_v15_20260930/DECISION.json')}))
  p=gate.read(protocol);gate.need(p['script_sha256']==gate.sha(__file__) and p['jobs']==jobs,'Protocol changed')
  begun=time.monotonic();last=-1e20;receipts=[]
  with gate.exclusive('V16 serial finite renewable source admission, no model fitting'):
   for i,job in enumerate(jobs):
    gate.guard();gate.need(time.monotonic()-begun<1200,'Source audit deadline');rp=queue/(job['id']+'.json')
    if rp.exists():
     r=gate.read(rp)
     if r.get('status')=='saved':gate.need(gate.sha(r['body'])==r['sha256'],'Cached source changed');receipts.append(r);continue
    gap=8-(time.monotonic()-last)
    if gap>0:time.sleep(gap)
    gate.guard();last=time.monotonic();state.update(at=gate.now(),event='source_request',completed=i,total=len(jobs),current=job['id']);gate.write(status,state)
    url='https://oasis.caiso.com/oasisapi/SingleZip?'+urlencode(job['params'])
    with urlopen(Request(url,headers={'User-Agent':'CAISO-academic-source-admission/1.0'}),timeout=40) as response:
     body=response.read(12_000_001);server=response.headers.get('Date')
    gate.need(len(body)<=12_000_000,'Source size');first=next(csvrows(body),None);gate.need(first is not None,'Empty source response')
    fp=ART/('renewable_'+job['id']+'.zip');temp=fp.with_suffix('.tmp');temp.write_bytes(body);os.replace(temp,fp)
    r=dict(status='saved',at=gate.now(),job=job,url=url,body=str(fp),sha256=gate.sha(fp),server_date=server,fields=list(first),numeric_values_decoded=False)
    gate.write(rp,r);receipts.append(r);print(json.dumps(dict(completed=i+1,total=len(jobs),source=job['id'])),flush=True)
   state.update(at=gate.now(),event='source_coverage_audit',completed=len(jobs));gate.write(status,state)
   # Reuse successful raw DAM monthly metadata, preferring repaired parents/children.
   inherited=[]
   for original in sorted((ROOT/'publication_collection').glob('pub_dam_*.json')):
    fixed=ROOT/'window_repairs'/original.name;rp=fixed if fixed.exists() else original;r=gate.read(rp)
    gate.need(r['status']=='ok','Unresolved monthly metadata '+str(rp));fp=moved(r['body_path']);gate.need(gate.sha(fp)==r['body_sha256'],'Legacy metadata hash')
    inherited.append(dict(receipt=str(rp),receipt_sha256=gate.sha(rp),body=str(fp),sha256=r['body_sha256'],params=r['params']))
   # Require contiguous publication query coverage, not merely report presence.
   spans=[]
   def parsetime(s):return int(datetime.strptime(s,'%Y%m%dT%H:%M%z').timestamp())
   for r in inherited:spans.append((parsetime(r['params']['startdatetime']),parsetime(r['params']['enddatetime'])))
   meta=[r for r in receipts if r['job']['params']['queryname']=='ATL_PUB']
   for r in meta:spans.append((parsetime(r['job']['params']['startdatetime']),parsetime(r['job']['params']['enddatetime'])))
   spans.sort();end=sec('2023-05-31T00:00:00Z')
   for left,right in spans:
    gate.need(left<=end,'Publication coverage gap');end=max(end,right)
   gate.need(end>=sec('2026-10-01T00:00:00Z'),'Publication coverage incomplete')
   latest={};counts=Counter()
   for r in inherited+meta:
    gate.guard()
    for row in csvrows(Path(r['body']).read_bytes()):
     if row.get('REPORT_NAME')!='SLD_REN_FCST' or row.get('STATUS')!='Push Completed' or row.get('OASIS_REC_STAT')!='V':continue
     a=sec(row['INTERVAL_START_GMT']);b=sec(row['INTERVAL_END_GMT']);pub=sec(row['PUBLICATION_DATE_GMT']);counts[row['ATLPUBVERSION']]+=1
     for t in range(a,b,3600):latest[t]=max(latest.get(t,0),pub)
   content={};duplicates=0;missing=0;expected={(hub,kind) for hub in ['NP15','SP15','ZP26'] for kind in ['Solar','Wind']}
   sources=[r for r in receipts if r['job']['params']['queryname']=='SLD_REN_FCST'];last_download=max(sec(r['at']) for r in sources)
   gate.need(all(int(parsedate_to_datetime(r['server_date']).timestamp())>=last_download for r in meta),'Publication refresh earlier than sources')
   for r in sources:
    for row in csvrows(Path(r['body']).read_bytes()):
     gate.need(row['MARKET_RUN_ID']=='DAM' and row['XML_DATA_ITEM']=='RENEW_FCST_DA_MW','Forecast task changed')
     a=sec(row['INTERVALSTARTTIME_GMT']);b=sec(row['INTERVALENDTIME_GMT']);gate.need(a%3600==0 and b-a==3600,'Hourly interval semantics changed')
     pair=(row['TRADING_HUB'],row['RENEWABLE_TYPE']);gate.need(pair in expected,'Unexpected location/type')
     token=row['MW'].strip();key=(a,pair);valuehash=hashlib.sha256(token.encode()).hexdigest()
     if token.lower() in ['', 'nan','none','null','inf','-inf']:missing+=1;continue
     if key in content:gate.need(content[key]==valuehash,'Overlapping archive values disagree');duplicates+=1
     content[key]=valuehash
   hours=Counter(t for t,_ in content);good={t for t,n in hours.items() if n==6 and t in latest};latest_good={t:latest[t] for t in good}
   # Only origin indices/times are read, never price labels.
   np,lim=gate.runtime(False);dm=gate.read(B/'chronological_expert_pilot_v14_20260930/DATA.json');root=Path(dm['directory']);ts=np.load(dm['timestamps'],mmap_mode='r');coverage={}
   for split in ['train','valid','evaluation']:
    origins=np.load(root/(split+'.npy'));ok=0;issues=[]
    for o in origins:
     cut=int(ts[o-1]);needed={int(ts[o+h])//3600*3600 for h in range(12)}
     flags=[t in latest_good and latest_good[t]<=cut for t in needed];passed=all(flags);ok+=passed
     if passed:issues.append(cut)
    coverage[split]=dict(registered_origins=len(origins),metadata_and_forecast_content_eligible=ok,eligible_issue_dates=len(set(t//86400 for t in issues)))
   gate.write(queue/'SOURCE_HOUR_ADMISSION.json',dict(at=gate.now(),hours=[dict(interval_start=t,last_publication=latest[t],complete_forecast_rows=True) for t in sorted(good)],all_candidate_target_values_sealed=True))
   result=dict(at=gate.now(),status='source_coverage_checked_pending_independent_review',requests=len(jobs),inherited_metadata_months=len(inherited),inherited_metadata_bindings=inherited,
    publication_versions=dict(counts),forecast_hours=len(hours),complete_hours=len(good),duplicate_identical_rows=duplicates,missing_value_tokens=missing,development_origin_coverage=coverage,
    role='Source/version feasibility only; late or missing forecasts excluded by immutable cutoff. Not yet a trained feature contract or a new independent test.',
    changed_structure='CISO absent in September2026flex-ramp sample; that branch is excluded until genuine entity/market mapping is established, never imputedzero or renamed.',
    requirements_remaining=['Independent source-hour recomputation and timestamp/unit contract','Fixed feature adapter and training-only normalization','Full model/controls freeze','New-period price and covariate admission plus access-history audit before any target release'],
    new_test_targets_read=False,training_started=False,core_models_changed=False,source_receipt_bindings={str(queue/(r['job']['id']+'.json')):gate.sha(queue/(r['job']['id']+'.json')) for r in receipts})
   gate.write(queue/'completion.json',result);state.update(at=gate.now(),status='finite_source_queue_completed',event='finite_mechanism_queue_completed',event_id=event('major_milestone',queue/'completion.json'));gate.write(status,state)
 except Exception:
  state.update(at=gate.now(),status='blocked',event='step_stopped_or_failed',error=traceback.format_exc());gate.write(queue/'FAILURE.json',state);state['event_id']=event('blocking_failure',queue/'FAILURE.json');gate.write(status,state);raise
if __name__=='__main__':main()
