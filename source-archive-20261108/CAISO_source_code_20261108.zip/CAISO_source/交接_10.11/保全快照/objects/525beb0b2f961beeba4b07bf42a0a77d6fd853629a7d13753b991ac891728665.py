"""Register one explicit network-recovery attempt; preserve scientific scope and old evidence."""
import json, shutil, hashlib, os, sys
from pathlib import Path
from datetime import datetime
V=Path(__file__).resolve().parent
Z=V.parent; U=Z/'net_restored_20261008'; C=U; B=Z.parent.parent
def read(p): return json.loads(Path(p).read_text(encoding='utf-8-sig'))
def sha(p):
    h=hashlib.sha256()
    with Path(p).open('rb') as f:
        for block in iter(lambda:f.read(1024*1024),b''): h.update(block)
    return h.hexdigest()
def write(name,data):
    p=V/name;p.parent.mkdir(parents=True,exist_ok=True)
    t=p.with_name(p.name+'.tmp')
    t.write_text(json.dumps(data,ensure_ascii=False,indent=2)+'\n',encoding='utf-8');os.replace(t,p)
def main():
    assert not (V/'PROTOCOL.json').exists(), 'Already registered'
    e=read(B/'event_driven_automation/inbox/wi_e1030bebdded7eee2824b797.json')
    assert sha(e['evidence_path'])==e['evidence_sha256']
    failure=read(e['evidence_path'])
    assert 'Bounded transfer attempts exhausted' in failure['error']
    assert not (U/'MANAGER.lock').exists()
    assert not Path(r'D:\Desktop\数据科学_论文\研究优化_20260818\logs\NEURAL_RUN.lock').exists()
    assert not (Z/'models').exists() and not (Z/'RESULT.json').exists()
    oldq=read(U/'PROTOCOL.json')
    for f,h in oldq['bindings'].items(): assert sha(f)==h,f
    for name in ['launch.ps1','MIRROR_REVIEW.json']:
        shutil.copy2(U/name,V/name)
        assert sha(U/name)==sha(V/name)
    cp=read(C/'CHECKPOINT.json')['cycle_hashes']
    fs=list((Z/'cycles').glob('*.json'));assert len(fs)==len(cp)==2105
    selected=read(Z/'SELECTION.json')
    choices={c['cycle']:c for c in selected['pilot']+selected['remaining']}
    hashes={};retained=released=headers=0;geometry=None
    for j,f in enumerate(fs):
        assert sha(f)==cp[f.stem]
        r=read(f);assert r['choice']==choices[int(f.stem)] and len(r['rows'])==24
        assert r['source_available_by']<=r['choice']['minimum_qualified_cutoff']
        if geometry is None:geometry=r['geometry']
        else:assert geometry==r['geometry']
        for x in r['receipts']:
            if x.get('local'): assert sha(Z/x['local'])==x['sha256'];retained+=1
            elif x.get('temporary_source_fragment'):
                raw=(Z/x['temporary_source_fragment']).resolve()
                release=raw.parent.parent.parent/'released_payloads'/f.name
                assert release.resolve().is_relative_to(Z.resolve())
                proof=read(release);assert proof['cycle_sha256']==cp[f.stem]
                assert any(a['sha256']==x['sha256'] and Path(a['path']).resolve()==raw for a in proof['files'])
                released+=1
            if x.get('native_response_headers'):
                h=x['native_response_headers'];assert h['etag']==x['source']['etag']
                lo,hi=x['range']
                assert h['content-range']==f"bytes {lo}-{hi}/{x['source']['bytes']}"
                headers+=1
        hashes[str(f)]=sha(f)
        if j%200==0:print(json.dumps({'audited_cycles':j}),flush=True)
    sys.path.insert(0,str(V));import manager as m
    objects=read(m.nt.m.I/'AUDITED_OBJECT_INDEX.json')['objects']
    from datetime import timezone
    opaque_cycles=[]
    for c in choices.values():
        prefix=datetime.fromtimestamp(c['cycle'],timezone.utc).strftime('hrrr.%Y%m%d/conus/hrrr.t%Hz.wrfsfcf')
        if any(not m.nt.single_part_identity({'source':objects[prefix+f'{lead:02d}.grib2']}) for lead in [3,4,5]):opaque_cycles.append(c['cycle'])
    assert len(opaque_cycles)==7
    write('OPAQUE_SOURCE_INVENTORY.json',dict(cycles=opaque_cycles,rule='Original AWS If-Match only; exact ETag+LastModified+size+range+GRIB; no mirror equivalence claim',docs=['https://docs.aws.amazon.com/AmazonS3/latest/API/API_Object.html','https://docs.aws.amazon.com/AmazonS3/latest/API/API_GetObject.html']))
    pending=[d for d in (U/'work').iterdir() if d.is_dir() and d.name not in cp]
    assert all(int(d.name) in choices for d in pending)
    # Copy staging evidence, never move or delete old attempts. Each payload will
    # still pass the unchanged identity/size/cutoff/GRIB checks before use.
    staged={}
    for d in pending:
        dest=V/'work'/d.name
        shutil.copytree(d,dest,ignore=(lambda folder,names:{x for x in names if '.grib2' in x}) if int(d.name) in opaque_cycles else None)
        for f in d.iterdir():
            if f.is_file() and (dest/f.name).exists():assert sha(f)==sha(dest/f.name);staged[str(dest/f.name)]=sha(f)
    write('STAGING_MANIFEST.json',{'copied_files':staged,'not_admitted_until_unchanged_validation':True})
    counters=read(U/'TRANSFER_COUNTERS.json')['counters']
    assert counters==failure['network']
    assert counters == {'reserved_bytes':181109371344,'reserved_requests':86206}
    counters = read(Z/'endpoint_fix_20261008/NEXT_RESUME_PLAN.json')['next_counters']
    counters['reserved_requests'] += 2 # current successful source HEAD checks
    write('RESUME_MANIFEST.json',{'at':datetime.now().astimezone().isoformat(),'cycle_hashes':hashes,
          'protected_source_checkpoint':sha(C/'CHECKPOINT.json')})
    write('RESUME_AUDIT.json',{'at':datetime.now().astimezone().isoformat(),'passed':True,
          'cycles':len(fs),'retained_sha_checks':retained,'released_manifest_checks':released,
          'range_header_checks':headers,'pending_cycles':[d.name for d in pending],
          'scope':'Separate source/hash/receipt/checkpoint replay; no independent-person or forecast-accuracy claim',
          'source_event':e,'model_fits':0,'new_test_targets_read':False})
    q=dict(oldq)
    q.update(at=datetime.now().astimezone().isoformat(),resume_cycles=len(fs),inherited_counters=counters,
          status='registered_user_authorized_transient_autoretry',connect_timeout_seconds=30,retry_backoff_seconds=5,
          maximum_transient_attempts=32,transient_retry_backoff_seconds=[5,15,30,60,120,240,300],
          recovery={'authorization':'用户明确要求：不稳定就自动尝试；不设总时长预算',
              'cause':'Intermittent TCP failures; user authorized in-process automatic transient retry; source, decoder, model, resource and quota guards unchanged',
              'parent_run':str(U),'parent_protocol_sha256':sha(U/'PROTOCOL.json'),
              'scientific_decoder_models_unchanged':True,'transport_provenance_preserved':True, 'automatic_retry':True,
               'bounded_transient_attempts_per_transfer':32,'nontransient_validation_attempts':2,'same_original_object_identity_required':True,'opaque_etag_requires_original_source':True},
          raw_retention='Preserve2105decodedsourcecycles and all old attempt evidence; validated new nonpilot payloads released after durable records',
          mirror_proof=str(V/'MIRROR_REVIEW.json'),automatic_full_restart=False)
    files=[V/n for n in ['manager.py','native_transport.py','launch.ps1','qa.py','QA.json',
        'MIRROR_REVIEW.json','RESUME_MANIFEST.json','RESUME_AUDIT.json','STAGING_MANIFEST.json','OPAQUE_SOURCE_INVENTORY.json','register_recovery.py','AUTO_RETRY_POLICY.json']]
    files += [U/'PROTOCOL.json',U/'FAILURE.json',C/'CHECKPOINT.json',U/'TRANSFER_COUNTERS.json',V/'NETWORK_READY.json',
              Z/'PROTOCOL.json',Z/'USER_TIME_POLICY_20261008.json',Z/'support.py']
    q['bindings']={str(f):sha(f) for f in files}
    write('PROTOCOL.json',q)
    sys.path.insert(0,str(V));import manager as m
    m.verify()
    raw=sum(f.stat().st_size for f in Z.rglob('*.grib2'))
    assert raw<q['maximum_retained_raw_bytes']
    print(json.dumps({'registered':True,'resume_cycles':len(fs),'pending_reused':len(pending),
        'raw_GiB':raw/1024**3,'time_budget':None,'model_fits':0}),flush=True)
if __name__=='__main__':main()

