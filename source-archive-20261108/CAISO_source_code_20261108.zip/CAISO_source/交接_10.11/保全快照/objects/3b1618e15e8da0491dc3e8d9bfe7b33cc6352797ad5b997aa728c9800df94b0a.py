"""Two bounded RTM publication requests; no price-value queries/readers."""
from pathlib import Path
from urllib.request import Request, urlopen
from urllib.parse import urlencode
import os, sys, time
HERE = Path(__file__).resolve().parent
sys.path.insert(0,str(HERE.parent/'context_expert_v1_20260929'))
import gate
reader = gate.load('v17_metadata_reader',HERE.parent/'stress_source_feasibility_v16_20260930/audit_renewable.py')
ART = Path('C:/Users/于阳/CAISO_temporary_storage')/HERE.name


def main():
    jobs = [('20260901T00:00-0000','20260916T00:00-0000'),
            ('20260916T00:00-0000','20261001T00:00-0000')]
    registration = HERE/'CONFIRMATION_METADATA_PROTOCOL.json'
    if not registration.exists():
        gate.write(registration,dict(at=gate.now(),candidate_period_UTC=['2026-09-01','2026-09-30'],
            date_basis='Completed UTC dates in the existing September candidate; chosen by calendar/source status only',
            jobs=jobs,request_budget=2,timeout_seconds=40,automatic_retry=False,
            values_forbidden='No PRC price query or numeric decoding; only ATL_PUB',
            limitations='Report-level metadata feasibility does not establish exact input completeness or untouched access history',
            training_release_requires=['Complete source and feature admission','Access-history audit','Chronological matched error-library support'],
            code_sha256=gate.sha(__file__)))
    assert gate.read(registration)['code_sha256'] == gate.sha(__file__)
    result = []; latest = {}; failure = None
    with gate.exclusive('V17 bounded September publication metadata feasibility, no target reading'):
        ART.mkdir(parents=True,exist_ok=True)
        for i,(a,b) in enumerate(jobs):
            gate.guard()
            receipt_path = HERE/f'RTM_PUBLICATIONS_{i}.json'
            if receipt_path.exists():
                receipt = gate.read(receipt_path)
                assert receipt['status']=='saved' and gate.sha(receipt['body'])==receipt['sha256']
            else:
                if i:
                    time.sleep(8)
                args=dict(queryname='ATL_PUB',market_run_id='RTM',oasis_section='ALL',status='ALL',
                    atlpubversion='ALL',version=1,startdatetime=a,enddatetime=b,resultformat=6)
                url='https://oasis.caiso.com/oasisapi/SingleZip?'+urlencode(args)
                try:
                    with urlopen(Request(url,headers={'User-Agent':'CAISO-academic-admission/1.0'}),timeout=40) as r:
                        body=r.read(12_000_001); server=r.headers.get('Date')
                    assert len(body)<=12_000_000
                    path=ART/f'rtm_publications_{i}.zip'; tmp=path.with_suffix('.tmp')
                    tmp.write_bytes(body);os.replace(tmp,path)
                    first=next(reader.rows(path))
                    assert 'PUBLICATION_DATE_GMT' in first and 'REPORT_NAME' in first
                    receipt=dict(status='saved',at=gate.now(),url=url,body=str(path),
                        sha256=gate.sha(path),server_date=server,params=args)
                    gate.write(receipt_path,receipt)
                except Exception as e:
                    failure=repr(e);break
            result.append(dict(path=str(receipt_path),sha256=gate.sha(receipt_path)))
            for row in reader.rows(receipt['body']):
                if (row.get('REPORT_NAME'),row.get('STATUS'),row.get('OASIS_REC_STAT')) != ('PRC_INTVL_LMP','Push Completed','V'):
                    continue
                a0,b0,pub=[reader.stamp(row[k]) for k in ('INTERVAL_START_GMT','INTERVAL_END_GMT','PUBLICATION_DATE_GMT')]
                for t in range(a0,b0,300):
                    latest[t]=max(pub,latest.get(t,-1))
            print('V17 RTM metadata request completed '+str(i+1),flush=True)
        start,end=reader.stamp('2026-09-01T00:00:00Z'),reader.stamp('2026-09-30T00:00:00Z')
        candidates=list(range(start,end,3600));known=eligible=0
        for origin in candidates:
            need=range(origin-288*300,origin,300)
            if all(t in latest for t in need):
                known+=1
                if all(latest[t]<=origin-300 for t in need):
                    eligible+=1
        gate.write(HERE/'CONFIRMATION_METADATA_RESULT.json',dict(at=gate.now(),
            status='metadata_probe_completed' if failure is None else 'source_probe_blocked',error=failure,
            receipts=result,registered_hourly_origins=len(candidates),
            covered_price_history_origins=known,price_history_publication_feasible_origins=eligible,
            scope='288 preceding5min intervals only; excludes not-yet-queried August prefix; no target/source values checked',
            dependency_note='Exact30node prices, other29feature inputs, full revision coverage, access history and forecast pipeline remain to be admitted',
            fresh_confirmation_admitted=False,price_values_read=False,model_fit_started=False))


if __name__=='__main__':
    main()
