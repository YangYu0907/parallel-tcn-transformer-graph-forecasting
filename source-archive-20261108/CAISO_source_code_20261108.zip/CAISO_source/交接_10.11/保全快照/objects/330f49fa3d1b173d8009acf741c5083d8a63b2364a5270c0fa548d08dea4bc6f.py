import common as c
import gc,os,time

def main():
    p=c.verify();qa=c.read(c.HERE/'QA.json')
    assert qa['status']=='passed' and qa['seal_sha256']==c.sha(c.HERE/'SEAL.json')
    assert not (c.HERE/'RESULT.json').exists(),'No duplicate completed trial'
    budget=c.Budget()
    with c.gate.exclusive('V27 bounded temporal memory matched pilot'):
        np,torch,lim=c.gate.runtime(True)
        from compiled_data import CompiledData
        import reductions as red
        from model import Reader,decode
        data=CompiledData(p['dataset_manifest'])
        limits=c.read(data.paths['context_limits.json'])['limits']
        train=np.unique(np.concatenate([np.load(data.paths[f'epoch{i}_origins.npy']) for i in range(1,7)]))
        assert len(train)==17102 and (train+12<=210528).all()
        data.origins['fit']=train
        assert len(data.origins['june_dense'])==3397
        q=np.array(c.read(data.paths['state_thresholds.json'])['thresholds'],dtype=np.float64)
        panels,_=red.panels(data.origins['june_dense'],data.origins['june'])
        seal=c.sha(c.HERE/'SEAL.json')

        def evaluate(case,base,reader,kind,old,mem):
            pred=np.empty((len(old['y']),30,12),np.float64)
            with torch.no_grad():
                for off in range(0,len(pred),64):
                    if off%512==0:budget.check(stage='validation',case=case['id'],arm=kind,completed=off,total=len(pred))
                    ids=np.arange(off,min(off+64,len(pred)));f=c.features(old,ids,torch,np)
                    memory=torch.from_numpy(np.array(mem[ids],copy=True))
                    pred[ids]=decode(base,f,reader,memory).numpy().astype(np.float64)*data.scale[None,:,None]+data.center[None,:,None]
            truth=old['y'].astype(np.float64)*data.scale[None,:,None]+data.center[None,:,None]
            codes=red.codes(truth,np.array(old['last']),data.center,data.scale,q)
            metrics={name:red.breakdown((pred-truth)[ids],codes[ids],data.origins['june_dense'][ids]) for name,ids in panels.items()}
            return pred,truth,codes,metrics

        results=[]
        for case in p['cases']:
            budget.check(stage='case_start',case=case['id'])
            casefile=c.HERE/'runs'/case['id']/'CASE.json'
            if casefile.exists():
                item=c.read(casefile);assert item['seal']==seal;results.append(item)
                if len(results)==1 and not item['first_seed_passed']:break
                continue
            base=c.base_model(case,limits,torch);fp=c.fingerprint(base)
            fit=c.old_cache(case,'fit',np);valid=c.old_cache(case,'june_dense',np)
            mf=c.memory(case,'fit',np);mv=c.memory(case,'june_dense',np)
            assert len(mf)==len(fit['y']) and len(mv)==len(valid['y'])
            arms={}
            for kind in ('MEAN','HORIZON'):
                folder=c.ART/case['id']/kind;folder.mkdir(parents=True,exist_ok=True)
                resultpath=c.HERE/'runs'/case['id']/(kind+'.json')
                if resultpath.exists():
                    row=c.read(resultpath);assert row['seal']==seal;arms[kind]=row;continue
                reader=Reader(case['seed'],kind);opt=torch.optim.AdamW(reader.parameters(),lr=p['lr'],weight_decay=p['weight_decay'])
                latest=folder/'latest.pt';epoch=1;offset=0;history=[]
                if latest.exists():
                    s=torch.load(latest,map_location='cpu',weights_only=False)
                    assert s['seal']==seal and s['case']==case and s['arm']==kind
                    reader.load_state_dict(s['reader']);opt.load_state_dict(s['optimizer'])
                    epoch,offset,history=s['epoch'],s['offset'],s['history']
                def save():
                    c.atomic(latest,lambda f:torch.save(dict(reader=reader.state_dict(),optimizer=opt.state_dict(),
                          seal=seal,case=case,arm=kind,epoch=epoch,offset=offset,history=history),f))
                def finish(e):
                    pred,truth,codes,metrics=evaluate(case,base,reader,kind,valid,mv)
                    pp=folder/f'epoch{e}.npz';cp=folder/f'epoch{e}.pt'
                    c.atomic(pp,lambda f:np.savez(f,prediction=pred,truth=truth,codes=codes,origins=data.origins['june_dense'],
                                               registered=data.origins['june'],timestamps=data.times[data.origins['june_dense']]))
                    c.atomic(cp,lambda f:torch.save(dict(reader=reader.state_dict(),seal=seal,case=case,arm=kind,epoch=e),f))
                    history.append(dict(epoch=e,metrics=metrics,prediction=str(pp),prediction_sha256=c.sha(pp),
                                        checkpoint=str(cp),checkpoint_sha256=c.sha(cp)))
                    c.write(c.HERE/'runs'/case['id']/(kind+'_history.json'),dict(history=history))
                try:
                    if not history:finish(0);save()
                    for e in range(epoch,3):
                        epoch=e;order=np.random.default_rng(case['seed']+2700000+e).permutation(len(train))
                        for off in range(offset,len(order),64):
                            c.gate.boundary()
                            ids=order[off:off+64];f=c.features(fit,ids,torch,np)
                            memory=torch.from_numpy(np.array(mf[ids],copy=True))
                            y=torch.from_numpy(np.array(fit['y'][ids],copy=True))
                            opt.zero_grad(set_to_none=True);out=decode(base,f,reader,memory)
                            loss=torch.nn.functional.huber_loss(out,y,delta=.5);assert torch.isfinite(loss)
                            loss.backward();torch.nn.utils.clip_grad_norm_(reader.parameters(),1.,error_if_nonfinite=True);opt.step()
                            offset=off+len(ids)
                            if offset%1024==0 or offset==len(order):
                                save();budget.check(stage='reader_training',case=case['id'],arm=kind,epoch=e,completed=offset,total=len(order))
                        if not any(row['epoch']==e for row in history):finish(e)
                        epoch=e+1;offset=0;save()
                    chosen=history[0]
                    for row in history[1:]:
                        if row['metrics']['June3397']['mae']<chosen['metrics']['June3397']['mae']-1e-6:chosen=row
                    arms[kind]=dict(at=c.now(),case=case,arm=kind,seal=seal,selected_epoch=chosen['epoch'],
                        selected=chosen,history=history,base_fingerprint=fp)
                    c.write(resultpath,arms[kind])
                except BaseException:
                    save();raise
                del reader,opt;gc.collect()
            assert c.fingerprint(base)==fp
            original=arms['HORIZON']['history'][0]['metrics']['June3397']
            assert arms['MEAN']['history'][0]['metrics']==arms['HORIZON']['history'][0]['metrics']
            first=c.gate_first(arms['HORIZON']['selected']['metrics']['June3397'],arms['MEAN']['selected']['metrics']['June3397'],original)
            item=dict(at=c.now(),case=case,seal=seal,arms=arms,first_seed_passed=first)
            c.write(casefile,item);results.append(item)
            del fit,valid,mf,mv,base;gc.collect()
            if len(results)==1 and not first:break
        c.protected();budget.check(stage='completed_pending_audit',completed_cases=len(results))
        c.write(c.HERE/'RESULT.json',dict(at=c.now(),status='completed_pending_separate_audit',cases=results,
             one_seed_pilot=True,reader_fits=2*len(results),new_test_targets_read=False,
             V7_preserved=True,scope=p['scope'],seal_sha256=seal))
        print('V27 completed',2*len(results),'matched reader fits; pending audit.')

if __name__=='__main__':main()
