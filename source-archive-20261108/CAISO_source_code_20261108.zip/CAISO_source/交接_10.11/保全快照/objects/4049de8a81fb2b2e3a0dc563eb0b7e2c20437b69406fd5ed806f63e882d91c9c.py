"""Timestamp-only feedback feasibility; never substitute delivery for publication."""
from pathlib import Path
from datetime import datetime
import sys, json
HERE=Path(__file__).resolve().parent
T=HERE.parent/'context_expert_v1_20260929'
sys.path.insert(0,str(T));import gate


def main():
    with gate.exclusive('June_feedback_publication_metadata_feasibility'):
        np,lim=gate.runtime(False)
        p=gate.read(T/'PROTOCOL.json');m=gate.read(p['dataset_manifest'])
        paths={k:gate.resolve(v['path']) for k,v in m['artifacts'].items()}
        ts=np.load(paths['timestamps_ns.npy'],mmap_mode='r')//10**9
        with np.load(T/'cache/20260813_FULL.npz') as z: origins=z['origins']
        a=HERE.parent.parent/'availability_reconstruction_20260913'
        ledger=a/'june_availability/interval_ledger.jsonl'
        index={}
        with ledger.open(encoding='utf-8') as f:
            for line in f:
                row=json.loads(line)
                if row['source']=='price':
                    sec=int(datetime.fromisoformat(row['interval_start']).timestamp())
                    index[sec]=row
        target=ts[origins[:,None]+np.arange(12)]
        cutoff=ts[origins-1]
        ready=np.full(target.shape,np.iinfo(np.int64).max,dtype=np.int64)
        missing=0;revised=0
        for ix in np.ndindex(target.shape):
            r=index.get(int(target[ix]),{})
            if r.get('status')!='event_linked_conditional' or not r.get('archive_values_share_last_event'):
                missing+=1;continue
            # Conservative: delivery end AND final-archive publication must have elapsed.
            # This does not pretend final-archive prices were the initial publications.
            ready[ix]=max(int(target[ix])+300,int(r['last_pub']))
            revised+=int(r.get('revised',False))
        valid=ready!=np.iinfo(np.int64).max
        delay=(ready[valid]-target[valid])/3600
        available={}
        for hours in (1,6,24,168):
            counts=[]
            for j,c in enumerate(cutoff):
                # Count origin-horizon records, NOT independent price events or node cells.
                mask=(cutoff[:j]>=c-hours*3600)[:,None] & (ready[:j]<=c)
                counts.append(int(mask.sum()))
            available[str(hours)+'h']=dict(median_available_records=float(np.median(counts)),
                origins_with_some_available_feedback=int(np.count_nonzero(counts)),
                origin_fraction_with_some_feedback=float(np.mean(np.array(counts)>0)))
        result=dict(at=gate.now(),status='timestamp_feasibility_only_not_full_release',
            scope='3397 June development origins; no new targets read; no router fit',
            metadata_ledger=str(ledger),metadata_sha256=gate.sha(ledger),
            origin_horizon_records=int(target.size),unmatched_records=missing,
            records_with_revision=int(revised),
            conservative_feedback_delay_hours=dict(zip(['minimum','median','p90','p99','maximum'],
                np.quantile(delay,[0,.5,.9,.99,1]).tolist())),
            fraction_available_by_1h=float(np.mean(delay<=1)),
            fraction_available_by_24h=float(np.mean(delay<=24)),
            recent_feedback_coverage=available,
            limitations=['Report-level final-vintage event binding, not original-value snapshots',
                'Repeated targets across overlapping origins are not independent feedback events',
                'Need exact target archive/compiled-value parity and timestamp provenance before real replay',
                'Published model-selection inputs themselves must be frozen before online replay start'],
            online_replay_admitted=False,training_started=False,
            script_sha256=gate.sha(__file__))
        gate.write(HERE/'FEEDBACK_FEASIBILITY.json',result)
        print(json.dumps(result),flush=True)


if __name__=='__main__':main()
