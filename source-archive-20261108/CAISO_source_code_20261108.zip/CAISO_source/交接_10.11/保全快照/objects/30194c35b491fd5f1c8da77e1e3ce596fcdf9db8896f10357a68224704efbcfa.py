"""Offline transport and source recovery checks, no remote requests."""
import json, hashlib, uuid
from pathlib import Path
import manager as run
nt=run.nt

def main():
    checks=[];run.s.verify()
    q=dict(maximum_attempts=2,deadline_unix=1,time_budget=None)
    nt.check(q);run.guard(dict(deadline_unix=1,total_deadline_unix=1))
    checks.append('Expired ETA cannot stop source or model phase; resource checks still run')
    nt.CANCEL.set()
    try:
        try:nt.check(q)
        except InterruptedError:pass
        else:raise AssertionError('Cancellation not honored')
    finally:nt.CANCEL.clear()
    checks.append('Explicit transport cancellation remains enforced')
    folder=run.W/'qa_fixture';folder.mkdir(exist_ok=True)
    key='hrrr.20230101/conus/hrrr.t00z.wrfsfcf03.grib2'
    source=dict(etag='"'+'a'*32+'"',last_modified_seconds=0,minimum_qualified_cutoff=1,bytes=20)
    fixture=folder/('metadata_'+uuid.uuid4().hex+'.grib2')
    fixture.write_bytes(b'abc')
    hp=Path(str(fixture)+'.headers')
    valid='HTTP/1.1 206 Partial Content\nETag: '+source['etag']+'\nLast-Modified: Thu, 01 Jan 1970 00:00:00 GMT\nContent-Length: 3\nContent-Range: bytes 3-5/20\n'
    hp.write_text(valid,encoding='utf-8')
    spec=dict(key=key,path=fixture,source=source,size=3,range=[3,5])
    assert nt.complete_part(spec)
    for change in [dict(etag='"'+'b'*32+'"'),dict(minimum_qualified_cutoff=-1),dict(bytes=21),dict(etag='"bad-2"')]:
        assert not nt.valid_or_rejected(dict(spec,source=dict(source,**change)))
    checks.append('Wrong object checksum, future mirror timestamp, wrong object size and multipart checksum are rejected')
    # Run real batch control flow against a process stub; first mirror rejection
    # must go to original AWS once, never relax any payload identity checks.
    output=folder/('fallback_'+uuid.uuid4().hex+'.grib2')
    fallback=dict(spec,path=output)
    original_popen=nt.subprocess.Popen;original_reserve=nt.reserve;configs=[]
    class Process:
        def __init__(self,args,**kw):
            config=Path(args[-1]).read_text(encoding='utf-8');configs.append(config)
            self.returncode=22 if len(configs)==1 else 0
            if self.returncode==0:
                output.write_bytes(b'abc');Path(str(output)+'.headers').write_text(valid,encoding='utf-8')
        def poll(self):return self.returncode
    try:
        nt.subprocess.Popen=Process;nt.reserve=lambda specs,q:None
        nt.batch([fallback],q,folder,'mock_fields')
        assert len(configs)==2 and nt.MIRROR+key in configs[0] and nt.AWS+key in configs[1]
        assert nt.complete_part(fallback)
    finally:nt.subprocess.Popen=original_popen;nt.reserve=original_reserve
    checks.append('Real batch control flow preserves two attempts and strictly validated original-source fallback')
    for config in configs:
        assert 'max-time = 240' in config and 'speed-time = 30' in config and 'If-Match:' in config
    checks.append('Per-request timeout, transfer-stall guard and conditional version request unchanged')
    # Final replay finds release records next to their originating work directory.
    for name in ['native_full_run_20261007','continuous_run_20261008']:
        payload=run.s.N/name/'work/123/fragment.grib2'
        assert payload.parent.parent.parent/'released_payloads/123.json'==run.s.N/name/'released_payloads/123.json'
    checks.append('Final source audit resolves both old and new payload release manifests')
    run.s.base.verify_protected()
    run.write('QA.json',dict(at=run.s.now(),passed=True,checks=checks,network_requests=0,model_fits=0))
    print(json.dumps(dict(passed=True,checks=len(checks),network_requests=0,model_fits=0)))

if __name__=='__main__':main()
