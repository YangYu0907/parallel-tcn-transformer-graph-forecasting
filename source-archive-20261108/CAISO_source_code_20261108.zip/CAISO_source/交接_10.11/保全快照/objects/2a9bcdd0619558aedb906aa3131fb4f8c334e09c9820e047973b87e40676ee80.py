from common import *
import subprocess,traceback

def emit(event,evidence):
 h=gate.sha(evidence);eid='calibration_recurrence_v15_'+event+'_'+hashlib.sha256(('v15|'+event+'|'+h).encode()).hexdigest()
 path=B/'event_driven_automation/inbox'/(eid+'.json')
 obj=dict(schema='caiso_research_event_v1',event_id=eid,event=event,at=gate.now(),evidence_path=str(evidence),evidence_sha256=h,scope='finite internal development, originalV7unchanged',complete_research_experiment=False)
 if not path.exists():gate.write(path,obj)
 return eid

def main():
 assert not (HERE/'completion.json').exists(),'Completed work must not be rerun'
 status=HERE/'queue/status.json';state=dict(at=gate.now(),pid=os.getpid(),status='running',stage='preflight')
 write(status,state)
 try:
  verify();gate.guard(True)
  assert not gate.LOCK.exists(),'Another numerical worker owns the shared lock'
  for script,result in [('calibration.py','CALIBRATION_RESULT.json'),('onset.py','ONSET_RESULT.json'),('audit.py','AUDIT.json')]:
   state.update(at=gate.now(),stage=script);write(status,state)
   if (HERE/result).exists():continue
   with (HERE/'queue'/('stdout_'+script+'.log')).open('ab') as out,(HERE/'queue'/('stderr_'+script+'.log')).open('ab') as err:
    child=subprocess.Popen([sys.executable,'-u',str(HERE/script)],stdout=out,stderr=err,cwd=HERE)
    state['worker_pid']=child.pid;write(status,state);code=child.wait()
   if code:raise RuntimeError(script+' exited '+str(code))
  audit=gate.read(HERE/'AUDIT.json');assert audit['status']=='passed'
  cal=gate.read(HERE/'CALIBRATION_RESULT.json');on=gate.read(HERE/'ONSET_RESULT.json')
  done=dict(at=gate.now(),status='audited',calibration_all_guardrails_pass=cal['all_guardrails_pass'],onset_information_diagnostic_pass=on['diagnostic_pass'],
   main_model_replaced=False,original_positive_results_retained=True,complete_research_experiment=False,independent_test=False,
   next_action='Review fixed-output attribution; do not add a search or deploy a point correction automatically.',bindings={str(HERE/f):gate.sha(HERE/f) for f in ['CALIBRATION_RESULT.json','ONSET_RESULT.json','AUDIT.json']})
  write(HERE/'completion.json',done);event='audited_result_ready' if cal['all_guardrails_pass'] and on['diagnostic_pass'] else 'unexpected_result'
  state.update(at=gate.now(),status='finite_mechanism_queue_completed',event='finite_mechanism_queue_completed',event_id=emit(event,HERE/'completion.json'),worker_pid=None);write(status,state)
 except Exception:
  state.update(at=gate.now(),status='blocked',traceback=traceback.format_exc());write(HERE/'FAILURE.json',state)
  state.update(event='step_stopped_or_failed',event_id=emit('blocking_failure',HERE/'FAILURE.json'));write(status,state);raise
if __name__=='__main__':main()
