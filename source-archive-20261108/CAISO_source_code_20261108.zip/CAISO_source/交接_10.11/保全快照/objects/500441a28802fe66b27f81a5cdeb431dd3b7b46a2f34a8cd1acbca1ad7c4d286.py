"""Bounded synthetic FiLM tests. Execute only in the root's serial numeric slot.

No CompiledData, backbone constructor, market cache, or old learned state is
opened. The real 3,232-parameter FiLM uses a small frozen synthetic shared head.
"""
import argparse
import copy
import json
import random
import time
import uuid
import film_runtime as f


def execute():
    started=time.perf_counter()
    folder=f.ROOT/'audits/film_synthetic_runs'/uuid.uuid4().hex
    with f.exclusive('asof_film_synthetic_math',folder):
        runtime,limiter=f.numeric()
        np,torch=f.np,f.torch
        import film_math as m
        import film_stage as stage
        import film_cache as caches
        from film_mnp import cone
        checks=[]
        def check(condition,label):
            if not condition:raise AssertionError(label)
            checks.append(label)
        def rejects(call,label):
            try:call()
            except (RuntimeError,ValueError,f.StopRequested):checks.append(label)
            else:raise AssertionError(label)

        class Head(torch.nn.Module):
            def __init__(self):
                super().__init__();self.linear=torch.nn.Linear(32,1)
                with torch.no_grad():self.linear.weight.fill_(.125);self.linear.bias.fill_(.2)
            def forward(self,z):return self.linear(z).squeeze(-1)
        class Holder(torch.nn.Module):
            def __init__(self):super().__init__();self.head=Head()

        generator=np.random.default_rng(731)
        n=35
        z=generator.normal(0,.1,(n,30,12,32)).astype(np.float32)
        z[...,31]=.5
        active=np.zeros((n,30),bool);active[:,::2]=True
        age=generator.uniform(0,1,(n,30,2)).astype(np.float32)
        codes=np.broadcast_to((np.arange(30)%3)[None,:,None],(n,30,12)).astype(np.uint8).copy()
        codes+=3*active[:,:,None].astype(np.uint8)
        cache=dict(z=z,mask=active,age=age,codes=codes,years=np.resize(np.array([2023,2024,2025],np.int16),n),
            multiplicity=np.resize(np.array([1,2,6],np.int64),n),sizes=np.array([4]*8+[3],np.int64),
            metadata=dict(scale=[2.]*30,center=[20.]*30))
        mean,std,total=m.normalizer(cache)
        weights=np.broadcast_to(cache['multiplicity'][:,None,None],z.shape[:-1])
        mask=np.broadcast_to(active[:,:,None],z.shape[:-1]);v=z.astype(np.float64)[mask];w=weights[mask].astype(np.float64)
        expected_mean=(v*w[:,None]).sum(0)/w.sum()
        expected_std=np.sqrt(np.maximum((v*v*w[:,None]).sum(0)/w.sum()-expected_mean**2,0))
        expected_std=np.where(expected_std<=1e-8,1,expected_std)
        check(np.array_equal(mean,expected_mean.astype(np.float32)) and np.array_equal(std,expected_std.astype(np.float32)) and total==w.sum(),
              'Fresh multiplicity-weighted active TRAIN normalizer matches independent moments')
        check(std[31]==1,'Constant-feature standard deviation uses the original fallback')
        template=Holder();model=m.Readout(template,mean,std,20260813).float().eval()
        check(sum(p.numel() for p in model.film.parameters())==3232 and not any(p.requires_grad for p in model.head.parameters()),
              'Only the real 3232 FiLM parameters are trainable; one frozen synthetic shared head')
        head_hash=f.fingerprint(model.head)
        with torch.inference_mode():
            cache['native']=np.concatenate([model.head(torch.from_numpy(z[i:i+4])).numpy().astype(np.float64)*2+20 for i in range(0,n,4)])
        cache['truth']=cache['native']+2.+generator.uniform(.01,.1,cache['native'].shape)
        initial=m.predict(model,cache)
        check(np.array_equal(initial,cache['native']),'Step zero is bitwise native in original 4/3 batch boundaries')
        before=m.vector(model.film)
        with torch.no_grad():model.film.fc2.bias.fill_(.01)
        after=m.predict(model,cache)
        normal=np.broadcast_to(~active[:,:,None],after.shape)
        check(np.array_equal(after[normal],initial[normal]) and (after[~normal]!=initial[~normal]).any(),
              'Active FiLM changes predictions and every inactive prediction is bitwise protected')
        m.assign(model.film,before)

        # Synthetic historical LMP verifies strict boundaries and reversed duration.
        x=torch.zeros((1,288,30,29),dtype=torch.float32)
        x[0,-3:,:,0]=torch.tensor([1.25,1.75,2.25])[:,None]
        scale=torch.full((30,),2.,dtype=torch.float64);center=torch.full((30,),20.,dtype=torch.float64)
        q=torch.stack((torch.full((30,),2.5),torch.full((30,),3.5))).double()
        actual_age=m.age_features(x,scale,center,q)
        lengths=np.empty((1,30,2),np.int64)
        raw=(x[:,:,:,0].double()*scale+center-center).abs().numpy()
        for node in range(30):
            for level in range(2):
                length=0
                for value in raw[0,::-1,node]:
                    if value>float(q[level,node]):length+=1
                    else:break
                lengths[0,node,level]=length
        check(np.array_equal(actual_age.numpy(),m.AGE_LOOKUP[lengths]) and np.array_equal(lengths[0,0],[2,1]),
              'q90/q99 durations use strict reconstructed-price thresholds and contiguous reverse lengths')
        x[0,-1,0,0]=1.75
        check(not bool(m.active(x,scale,center,q[1])[0,0]) and bool(m.active(x,scale,center,q[1])[0,1]),
              'Historical active mask excludes exact reconstructed q99 equality')
        risks,counts=m.losses(initial,cache)
        check(risks.shape==(36,) and (risks>0).all() and (counts>0).all(),
              'All 3 years x 3 active states x 4 actual risks have positive synthetic support')
        independently=[]
        for year,group,kind in m.TASKS:
            support=(cache['codes']==group)&(cache['years']==year)[:,None,None]
            if kind=='near':support[:,:,4:]=False
            if kind=='h12':support[:,:,:11]=False
            error=(initial-cache['truth'])[support];weight=weights[support]
            independently.append(((error**2 if kind=='mse' else abs(error))*weight).sum()/weight.sum())
        check(np.allclose(risks,independently,rtol=2e-15,atol=2e-15),'All 36 weighted risks match independently indexed cells')

        # Original full-weight implementation reproduced locally on synthetic data.
        def reference_gradients():
            readout=copy.deepcopy(model).double();params=list(readout.film.parameters())
            result=np.zeros((36,3232));values=np.zeros(36);full=list(m.masks(cache))
            for start in range(0,n,32):
                end=min(start+32,n)
                err=readout(torch.tensor(z[start:end],dtype=torch.float64),torch.tensor(active[start:end]),
                    torch.tensor(age[start:end],dtype=torch.float64))*2+20-torch.tensor(cache['truth'][start:end],dtype=torch.float64)
                for k,(kind,weight,count) in enumerate(full):
                    loss=((err.square() if kind=='mse' else err.abs())*torch.tensor(weight[start:end],dtype=torch.float64)).sum()/count
                    values[k]+=float(loss.detach())
                    derivative=torch.autograd.grad(loss,params,retain_graph=k<35)
                    result[k]+=np.concatenate([value.numpy().ravel() for value in derivative])
            return result,values,np.array([row[2] for row in full])
        gradient,double_losses,gradient_counts=m.gradients(model,cache)
        reference=reference_gradients()
        check(all(np.array_equal(left,right) for left,right in zip((gradient,double_losses,gradient_counts),reference)),
              'Bounded 32-origin gradients are bitwise identical to the original full-mask accumulation')
        partial={}
        def interrupt(values):
            partial.update({key:value.copy() if isinstance(value,np.ndarray) else value for key,value in values.items()})
            if values['offset']==32:raise f.StopRequested('synthetic gradient boundary')
        rejects(lambda:m.gradients(model,cache,progress=interrupt),'Synthetic stop saves the completed 32-origin gradient prefix')
        resumed=m.gradients(model,cache,resume=partial)
        check(all(np.array_equal(left,right) for left,right in zip((gradient,double_losses,gradient_counts),resumed)),
              'Resumed partial gradient/loss/count accumulation is bitwise exact')
        prefix_folder=folder/'prefix_double_buffer'
        f.save_gradient_prefix(prefix_folder,partial)
        first_pointer=f.read(prefix_folder/'gradient_latest.json')
        original_write=f.write
        try:
            def crash_before_pointer(path,value,replace=False):
                if path==prefix_folder/'gradient_latest.json':raise f.StopRequested('synthetic crash before prefix pointer')
                return original_write(path,value,replace)
            f.write=crash_before_pointer
            rejects(lambda:f.save_gradient_prefix(prefix_folder,dict(offset=n,gradient=gradient,losses=double_losses,counts=gradient_counts)),
                    'Crash between non-current gradient slot and pointer commit is injected safely')
        finally:f.write=original_write
        check(f.read(prefix_folder/'gradient_latest.json')==first_pointer and f.sha(f.inside(first_pointer['path']))==first_pointer['sha256'],
              'A/B gradient checkpoint preserves the previous complete prefix through a pre-pointer crash')
        f.save_gradient_prefix(prefix_folder,dict(offset=n,gradient=gradient,losses=double_losses,counts=gradient_counts))
        second_pointer=f.read(prefix_folder/'gradient_latest.json')
        with np.load(f.inside(second_pointer['path']),allow_pickle=False) as saved:
            check(second_pointer['path']!=first_pointer['path'] and np.array_equal(saved['gradient'],gradient) and int(saved['offset'])==n,
                  'A/B gradient checkpoint commits the exact next prefix using bounded two-slot storage')
        invalid=dict(partial,offset=31)
        rejects(lambda:m.gradients(model,cache,resume=invalid),'Non-boundary gradient resume cursor is rejected')
        double=copy.deepcopy(model).double();coordinate=3104;values=m.vector(double.film);epsilon=1e-5
        def double_risks(vector):
            m.assign(double.film,vector)
            with torch.inference_mode():
                pred=double(torch.tensor(z,dtype=torch.float64),torch.tensor(active),torch.tensor(age,dtype=torch.float64)).numpy()*2+20
            return m.losses(pred,cache)[0]
        right=values.copy();right[coordinate]+=epsilon
        left=values.copy();left[coordinate]-=epsilon
        finite=(double_risks(right)-double_risks(left))/(2*epsilon)
        check(np.allclose(finite,gradient[:,coordinate],rtol=2e-6,atol=2e-8),'Full-risk autograd agrees with central differences on an active FiLM coordinate')
        curve=m.curvature(np.array([1.,0.]),np.array([[2.,0.],[-3.,0.],[0.,0.]]),np.ones(3),np.zeros(2),np.zeros((3,2)))
        check(curve['alpha']==[2.,3.,.001],'BB positive/negative/zero curvature branches retain original clipping')
        solution=cone(np.array([[1.,0.],[0.,1.]]),np.ones(2),m.SETTINGS)
        check(solution['certificate_passed'] and solution['strict_common_descent'] and np.allclose(solution['direction'],[.5,.5]),
              'Finite Wolfe MNP returns the analytically known certified common direction')
        check(not cone(np.array([[1.,0.],[-1.,0.]]),np.ones(2),m.SETTINGS)['strict_common_descent'],
              'Opposing risks cannot receive a false strict common-descent certificate')
        ok,linear,bound=m.acceptable(np.ones(2),np.array([.9,.95]),np.eye(2),np.array([-.1,-.1]))
        check(ok and np.array_equal(linear,[-.1,-.1]) and np.array_equal(bound,np.ones(2)-1e-5),
              'Armijo uses actual raw-risk directional displacement and all-risk acceptance')

        # All state, RNG, original buffers, and owner-contained receipt recovery.
        identity=dict(synthetic_only=True,source_hashes=f.sources())
        fit=folder/'fit';rng=np.random.default_rng(44)
        state=dict(sequence=0,phase='ready',updates=0,next_attempt=1,attempts=0,initial=risks,
                   previous_before=None,previous_gradient=None,rows=[],stop_reason=None)
        receipt=f.save_fit(fit,model,state,identity,runtime,rng)
        expected_draws=(rng.random(3),np.random.random(3),torch.rand(3),random.random())
        changed=copy.deepcopy(model)
        with torch.no_grad():changed.film.fc2.bias.add_(.03)
        restored,selected=f.restore_fit(fit,changed,identity,runtime,rng)
        actual_draws=(rng.random(3),np.random.random(3),torch.rand(3),random.random())
        check(np.array_equal(m.vector(changed.film),before) and restored['phase']=='ready' and selected==receipt,
              'Full FiLM snapshot restores parameters and optimizer cursor from a committed receipt')
        check(np.array_equal(expected_draws[0],actual_draws[0]) and np.array_equal(expected_draws[1],actual_draws[1])
              and torch.equal(expected_draws[2],actual_draws[2]) and expected_draws[3]==actual_draws[3],
              'Resume restores generator/global NumPy/Torch/Python RNG states')
        wrong=copy.deepcopy(model)
        with torch.no_grad():wrong.head.linear.bias.add_(1)
        rejects(lambda:f.restore_fit(fit,wrong,identity,runtime,rng),'Changed frozen head is rejected before resume')
        wrong=copy.deepcopy(model)
        with torch.no_grad():wrong.film.mean.add_(1)
        rejects(lambda:f.restore_fit(fit,wrong,identity,runtime,rng),'Different newly fitted TRAIN buffers are rejected at resume')
        f.write(fit/'latest.json',dict(stale=True),replace=True)
        f.restore_fit(fit,model,identity,runtime,rng)
        check(f.read(fit/'latest.json')==receipt,'Latest pointer is recovered from complete immutable receipts')
        marker=folder/'STOP_REQUESTED';f.write(marker,dict(synthetic=True))
        rejects(lambda:f.boundary(folder/'nested/trials'),'Ancestor stage stop interrupts nested numeric work')
        marker.unlink()
        guard=f.backbone.resource_guard
        try:
            def shortage():raise MemoryError('synthetic commit/physical shortage')
            f.backbone.resource_guard=shortage
            rejects(lambda:f.boundary(folder,True),'Resource shortage becomes a resumable stop')
        finally:f.backbone.resource_guard=guard
        immutable=folder/'idempotent.json';f.exact_json(immutable,{'v':1});f.exact_json(immutable,{'v':1})
        rejects(lambda:f.exact_json(immutable,{'v':2}),'Idempotent committed pointer permits only identical values')

        # Actual finite attempt replay exercises gradient/trial commits, not a mock optimizer.
        attempt_folder=folder/'attempt_replay'
        attempt_state=copy.deepcopy(state)
        attempt_state['sequence']=0
        row,_,_=stage.attempt(attempt_folder,model,cache,attempt_state,identity)
        accepted_vector=m.vector(model.film)
        m.assign(model.film,before)
        replay,_,_=stage.attempt(attempt_folder,model,cache,attempt_state,identity)
        check(row==replay and np.array_equal(accepted_vector,m.vector(model.film)),
              'Finite BB/MNP attempt replays its immutable decision and exact assigned float32 vector')
        check(f.fingerprint(model.head)==head_hash,'Every synthetic FiLM computation leaves the frozen head unchanged')
        check('compiled_data' not in __import__('sys').modules,'No CompiledData or actual market cache was imported')
        report=dict(status='passed',synthetic_only=True,sources=f.sources(),checks=checks,
            test_count=len(checks),runtime=runtime,elapsed_seconds=time.perf_counter()-started,
            peak_working_set_bytes=__import__('psutil').Process().memory_info().peak_wset,
            full_empirical_gradient_resume_exact=True,full_snapshot_rng_resume_exact=True,
            original_risk_equations_verified=True,safe_stop_boundary_verified=True,
            ordinary_predictions_exact=True,normalizer_train_only_verified=True,
            numerical_case='35 synthetic origins, one synthetic frozen head and real FiLM',
            finite_synthetic_attempt_accepted=row['accepted'],synthetic_parameter_updates=int(row['accepted']),
            market_values_read=False,backbone_models_constructed=0,formal_film_training_started=False,
            checkpoint_test_directory=str(folder.relative_to(f.ROOT)))
        f.write(folder/'report.json',report)
        if f.QA.exists():raise RuntimeError('Preserve existing QA; explicit new revision required')
        f.write(f.QA,report)
        return report


if __name__=='__main__':
    parser=argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--run',action='store_true',help='Requires the scheduler-authorized serial numerical slot')
    args=parser.parse_args()
    if not args.run:parser.error('Numerical QA is explicit: --run')
    print(json.dumps(execute(),ensure_ascii=True))
