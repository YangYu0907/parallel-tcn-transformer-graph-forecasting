"""Fixed-capacity L2 logistic gate; old failed candidates are never overwritten."""
from pathlib import Path
import sys,time,os
HERE=Path(__file__).resolve().parent
EM=HERE.parent/'event_memory_gate_20261004'
sys.path.insert(0,str(EM))
import engine as previous
old=previous.old;TWO=previous.TWO;REC=previous.REC
import numpy as np
from scipy.special import expit
PENALTY=.01
def checked(launch=False):
    if any((HERE/p).exists() for p in ['STOP_REQUESTED','STOP_REQUESTED.json']):raise InterruptedError('Local stop')
    return previous.checked(launch)
def verify():
    previous.verify()
    protocol=old.read(HERE/'PROTOCOL.json')
    for p,h in protocol['bindings'].items():assert old.sha(p)==h,p
    return protocol
def tick(**kw):
    checked()
    elapsed=time.monotonic()-T0
    if elapsed>1800:raise TimeoutError('Fixed30minute budget')
    old.write(HERE/'PROGRESS.json',dict(at=old.now(),pid=os.getpid(),seconds=elapsed,**kw))
def transform(X,model):
    return np.clip((X-model['center'])/model['scale'],-6,6).astype('float64')
def objective(theta,Z,y):
    beta=theta[:-1];eta=Z@beta+theta[-1];p=expit(eta)
    val=float(np.mean(np.logaddexp(0,eta)-y*eta)+.5*PENALTY*np.dot(beta,beta))
    grad=np.r_[Z.T@(p-y)/len(y)+PENALTY*beta,np.mean(p-y)]
    return val,grad
def predict(X,model):return expit(transform(X,model)@model['theta'][:-1]+model['theta'][-1])
def fit(folder,X,y):
    from scipy.optimize import minimize
    folder.mkdir(parents=True)
    center=np.median(X,axis=0);q=np.quantile(X,[.25,.75],axis=0);s=q[1]-q[0];scale=np.where(s>=1e-6,s,1.)
    model=dict(center=center,scale=scale,protocol=old.sha(HERE/'PROTOCOL.json'),columns=X.shape[1],rows=len(y))
    Z=transform(X,model);theta=np.zeros(Z.shape[1]+1);theta[-1]=np.log(y.mean()/(1-y.mean()))
    count=[0]
    def callback(t):
        count[0]+=1
        if count[0]%20==0:
            tick(stage='fit',folder=str(folder),iteration=count[0]);old.save(folder/'ITERATE.npz',theta=t)
    solved=minimize(objective,theta,args=(Z,y),jac=True,method='L-BFGS-B',callback=callback,
        options=dict(maxiter=300,ftol=1e-12,gtol=1e-7,maxls=40))
    model['theta']=solved.x
    value,grad=objective(solved.x,Z,y)
    old.dump(folder/'model.pkl',model)
    old.write(folder/'FROZEN.json',dict(at=old.now(),sha256=old.sha(folder/'model.pkl'),optimizer_success=bool(solved.success),
        gradient_inf=float(abs(grad).max()),iterations=int(solved.nit),objective=value,penalty=PENALTY,
        note='One fixed start; no score/regularization search'))
    assert solved.success and abs(grad).max()<1e-5,'Numerical convergence not verified'
    return model
def probe(fold,raw,times):
    source=EM/f'probe{fold}';folder=HERE/f'probe{fold}';folder.mkdir()
    z=np.load(source/'ORIGINS.npz');st=old.read(source/'STATS.json')
    train=previous.make_rows(raw,times,z['train'],st)
    with np.load(source/'REPLAY.npz') as f:ev={k:f[k] for k in f.files}
    outputs={};trainrows={};proberows={}
    for arm in ['RIDGE_BASE','RIDGE_MEMORY']:
        tx=previous.control_X(train['X']) if arm=='RIDGE_BASE' else train['X']
        ex=previous.control_X(ev['X']) if arm=='RIDGE_BASE' else ev['X']
        model=fit(folder/arm,tx,train['y']);p=predict(ex,model);outputs[arm]=p
        trainrows[arm]=previous.scores(predict(tx,model),train['y'],train['days'])
        proberows[arm]=previous.scores(p,ev['y'],ev['days'])
    old.save(folder/'REPLAY.npz',y=ev['y'],days=ev['days'],ids=ev['ids'],**outputs)
    oldrow=old.read(source/'RESULT.json')
    controls={'TREE_BASE':oldrow['control'],'TREE_MEMORY':oldrow['memory']}
    primary=proberows['RIDGE_BASE']
    passed=previous.score_pass(primary,controls['TREE_BASE'])
    row=dict(fold=fold,train=trainrows,probe=proberows,controls=controls,passed=passed)
    old.write(folder/'RESULT.json',row);return row
def full_fit(fold,raw,times):
    folder=HERE/f'fold{fold}';folder.mkdir()
    z=np.load(old.OLD/f'fold{fold}_origins.npz');origins=z['train'][z['train']%12==0]
    st=old.read(old.OLD/f'fold{fold}_stats.json')['neural'];tr=previous.make_rows(raw,times,origins,st)
    model=fit(folder/'RIDGE_BASE',previous.control_X(tr['X']),tr['y']);ev=z['evaluate'];pred=[]
    for j in range(0,len(ev),32):
        tick(stage='full_inference',fold=fold,row=j);oo=ev[j:j+32]
        f,last=previous.original_features(raw,oo,st);nn=np.tile(np.repeat(np.arange(30),5),len(oo));hh=np.tile(np.arange(8,13)/12,len(oo)*30)
        X=np.column_stack([np.repeat(f.reshape(-1,37),5,0),np.eye(30)[nn],hh]).astype('float32')
        pred.append(predict(X,model).reshape(-1,30,5))
    old.save(folder/'PREDICTIONS.npz',origins=ev,probability=np.concatenate(pred))
def final_score(probes):
    rows=[];details=[];probability=[];outputs={}
    for fold in [1,2]:
        with np.load(TWO/f'REPLAY_fold{fold}.npz') as z:d={k:z[k] for k in z.files}
        with np.load(REC/f'fold{fold}/PREDICTIONS.npz') as z:h={k:z[k] for k in z.files}
        with np.load(TWO/f'fold{fold}/PREDICTIONS.npz') as z:x={k:z[k] for k in z.files}
        with np.load(HERE/f'fold{fold}/PREDICTIONS.npz') as z:p=z['probability'];assert np.array_equal(z['origins'],d['origins'])
        mask=np.broadcast_to(h['eligible'][:,:,None],p.shape);yy=(d['states'][:,:,7:]<5)[mask]
        days=np.broadcast_to(d['days'][:,None,None],p.shape)[mask]
        probability.append(dict(fold=fold,old=previous.scores(h['probability'][mask],yy,days),ridge=previous.scores(p[mask],yy,days)))
        out={}
        for seed in old.SEEDS:
            base=d[f'BASE_{seed}']
            candidate=previous.parent.correct(base,h['recovery'],x['extreme'],p,x['last'],h['eligible'],'TWO_REGIME')
            out[f'BASE_{seed}']=base;out[f'OLD_TWO_{seed}']=d[f'TWO_REGIME_{seed}'];out[f'RIDGE_{seed}']=candidate
            details.append(dict(fold=fold,seed=seed,qualification=old.parent.qualification(candidate,base,d['truth'],d['states'],d['days'])))
        for name,forecast in out.items():
            rows.append(dict(fold=fold,model=name,**old.parent.metrics(forecast,d['truth']),states=old.parent.state_metrics(forecast,d['truth'],d['states'],d['days'])))
        old.save(HERE/f'REPLAY_fold{fold}.npz',truth=d['truth'],states=d['states'],origins=d['origins'],days=d['days'],**out)
        outputs[fold]=out
    retention=all(v['qualification']['passed'] for v in details)
    contrast=all(np.mean([v[k] for v in rows if v['fold']==f and v['model'].startswith('RIDGE_')])<
        np.mean([v[k] for v in rows if v['fold']==f and v['model'].startswith(arm+'_')])
        for f in [1,2] for arm in ['BASE','OLD_TWO'] for k in ['mae','rmse','h12_mae'])
    # A gate improvement is not by itself a probability-interval claim.
    return dict(stage='full_screen_completed',probes=probes,rows=rows,details=details,probability=probability,
        retention_passed=retention,contrast_passed=contrast,screen_passed=retention and contrast,new_fits=6,
        interval_validation_pending=True)
def main():
    global T0
    T0=time.monotonic();verify();checked(True);previous.tick=tick
    with old.numeric('finite regularized logistic gate training'):
        raw,times,_,_=old.parent.arrays()
        probes=[probe(f,raw,times) for f in [1,2]]
        if all(p['passed'] for p in probes):
            for fold in [1,2]:full_fit(fold,raw,times)
            result=final_score(probes)
        else:result=dict(stage='stopped_at_inner_temporal_probe',probes=probes,new_fits=4,screen_passed=False,
            reason='Primary regularized original-feature classifier did not pass both chronological probes; no model switching to the diagnostic augmented arm.')
        verify();tick(stage='complete')
        old.write(HERE/'RESULT.json',dict(at=old.now(),**result,seconds=time.monotonic()-T0,V7_replaced=False,new_test_targets_read=False,
            scope='Inspected historical TRAIN. The two earlier-prefix probes overlap; not independent replications. All directions retained.'))
if __name__=='__main__':main()
