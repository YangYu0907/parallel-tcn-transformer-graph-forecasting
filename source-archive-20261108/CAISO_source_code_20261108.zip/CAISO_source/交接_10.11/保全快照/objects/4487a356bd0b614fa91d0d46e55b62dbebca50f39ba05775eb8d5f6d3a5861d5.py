"""Four frozen-expert DAM output-pool fits. Exposed development, never V7 admission."""
from pathlib import Path
import sys,os,json,time
P=Path(__file__).resolve().parent;W=P.parent;U=W/'retained_dam_1010'
sys.path.insert(0,str(U))
import common as c
for k in ['OMP_NUM_THREADS','MKL_NUM_THREADS','OPENBLAS_NUM_THREADS','NUMEXPR_NUM_THREADS']:os.environ[k]='1'
import numpy as np
from scipy.optimize import brentq,minimize_scalar
from sklearn.metrics import average_precision_score
def write(name,value):
 p=P/name;p.parent.mkdir(parents=True,exist_ok=True);q=p.with_name('.j'+os.urandom(4).hex())
 q.write_text(json.dumps(value,ensure_ascii=False,indent=2,allow_nan=False),encoding='utf-8');os.replace(q,p)
def save(name,**ar):
 p=P/name;q=p.with_name('.n'+os.urandom(4).hex())
 with q.open('wb') as f:np.savez_compressed(f,**ar)
 os.replace(q,p)
def guard(launch=False):
 for n in ['STOP_REQUESTED','STOP_REQUESTED.json']:
  if (P/n).exists():raise InterruptedError('User stop '+str(P/n))
 return c.guard(launch)
def metric(y,q,on):
 pos=y==1;q=np.clip(q,1e-12,1-1e-12);tp=int(np.sum(pos&on));fp=int(np.sum(~pos&on))
 return dict(brier=float(np.mean((q-pos)**2)),logloss=float(np.mean(np.where(pos,-np.log(q),-np.log1p(-q)))),
  precision=tp/(tp+fp) if tp+fp else 0.,recall=tp/int(pos.sum()) if pos.any() else 0.,TP=tp,FP=fp,
  events=int(pos.sum()),FPR=fp/int((~pos).sum()),AP=float(average_precision_score(pos,q)) if pos.any() else None,
  down_cases=int(np.sum(y==2)),false_UP_on_DOWN=int(np.sum(on&(y==2))))
def register():
 assert not (P/'PROTOCOL.json').exists()
 old=c.verify();guard(True)
 paths=[Path(__file__),U/'PROTOCOL.json',U/'RESULT.json',U/'AUDIT.json',U/'DIAGNOSIS.json',U/'common.py',
        c.Z/'support.py',Path(c.s.base.__file__),c.Z/'PROTECTED_FILES.json']
 for fold in old['folds']:
  for arm in old['arms']:
   cell=U/fold['name']/arm
   paths.extend([cell/'PREDICTIONS.npz',cell/'COMPLETE.json',cell/'CAL_FROZEN.json'])
 prot=dict(at=c.now(),status='registered_before_four_scalar_fits',folds=old['folds'],
  max_new_tree_fits=0,max_new_scalar_fits=4,groups=['HISTORY','COARSE'],
  arms_each_group=['PARENT','DAM','HALF','POOL'],
  scope='Exploratory already-exposed January-May2025 development. Not untouched confirmation; CAL allocation and previously fitted temperature unchanged.',
  reason='New audited DAM probabilities have not undergone late pooling; previous history/weather-only pool was different and remains closed. Test marginal complementarity, not another tree/threshold grid.',
  formula='q=(1-g)*q_parent+g*q_DAM; one g in[0,1] per group/fold minimizes natural-frequency binary CAL logloss. Zero allowed and respected. HALF is fixed .5 diagnostic control.',
  alarm='Original PARENT/DAM thresholds unchanged; each pooled CAL-negative .99 higher quantile and strict >. No target-driven threshold/month/weight changes.',
  freeze='All four scalar fits and thresholds written before any current EVAL scoring. This does not undo prior exposure of these same EVAL outcomes.',
  statistics='Pool vs respective PARENT and HALF x2groups x2proper scores=8 tests; paired3day blocks,2000 draws,seed20260813,Holm8. All months/folds reported. All inferential values exploratory after repeated development.',
  gate='For each POOL vs respective PARENT both Brier/logloss improve both folds, precision/recall nonworse both folds,FPR<=.02, both pooled proper-score Holm8 p<.05. Any admission still requires genuinely untouched source-admitted confirmation and OOF price integration.',
  stop='Four scalar fits only. Failed or zero-weight paths closed. No automatic alternate losses, grids, threshold shifts, favorable-month selection, or further pooling retries.',
  resources='Unchanged5GiB physical/commit launch,4GiB runtime,4GiBdisk reserve, shared numerical lock, one thread',
  source_scope=old['source_scope'],downward_support_not_sufficient=True,point_price_integration=False,V7_replaced=False,new_test_targets_read=False,
  independent_person_review=False,periodic_model_wakeups=False,whole_research_completed=False,
  literature=[dict(url='https://arxiv.org/abs/1106.1638',scope='Probability combinations/calibration tradeoffs, no dominance guarantee'),
   dict(url='https://jmlr.org/papers/v11/cawley10a.html',scope='Repeated selection can overfit finite evaluation; final confirmation required')],
  bindings={str(v):c.sha(v) for v in paths})
 write('PROTOCOL.json',prot)
 return prot
def verify(prot):
 for path,h in prot['bindings'].items():assert c.sha(path)==h,path
 for path,h in c.read(c.Z/'PROTECTED_FILES.json').items():assert c.sha(path)==h,path
def run():
 started=time.monotonic()
 assert not (P/'RESULT.json').exists(),'Completed probe must not rerun'
 prot=register() if not (P/'PROTOCOL.json').exists() else c.read(P/'PROTOCOL.json')
 verify(prot);guard(True)
 with c.s.base.numeric('Four CAL-only DAM probability-combination scalar fits; zero new trees'):
  frozen={};checks=0
  for fold in prot['folds']:
   name=fold['name'];frozen[name]={}
   for ctrl in prot['groups']:
    guard()
    with np.load(U/name/ctrl/'PREDICTIONS.npz') as a,np.load(U/name/(ctrl+'_DAM')/'PREDICTIONS.npz') as b:
     cy=a['cal_y'];ct=a['cal_time'];assert np.array_equal(cy,b['cal_y']) and np.array_equal(ct,b['cal_time'])
     ca=a['calibration'];cb=b['calibration']
    truth=cy==1;p0=np.where(truth,ca,1-ca);p1=np.where(truth,cb,1-cb);delta=p1-p0
    assert np.all(p0>0) and np.all(p1>0)
    def der(g):return -float(np.mean(delta/(p0+g*delta)))
    def obj(g):return -float(np.log(p0+g*delta).mean())
    g=0. if der(0)>=0 else (1. if der(1)<=0 else float(brentq(der,0,1,xtol=1e-13)))
    # Separate bounded objective optimizer validates derivative-root solution.
    alt=minimize_scalar(obj,bounds=(0.,1.),method='bounded',options={'xatol':1e-12})
    assert obj(g)<=min(obj(0),obj(1),obj(float(alt.x)))+1e-11
    cg=(1-g)*ca+g*cb;half=.5*(ca+cb)
    thresholds=dict(PARENT=c.read(U/name/ctrl/'CAL_FROZEN.json')['threshold'],DAM=c.read(U/name/(ctrl+'_DAM')/'CAL_FROZEN.json')['threshold'],
       HALF=float(np.quantile(half[~truth],.99,method='higher')),POOL=float(np.quantile(cg[~truth],.99,method='higher')))
    frozen[name][ctrl]=dict(weight=g,thresholds=thresholds,derivative_at_weight=der(g),cal_logloss=dict(PARENT=obj(0),DAM=obj(1),HALF=obj(.5),POOL=obj(g)),
      objective_replay_difference=float(obj(g)-obj(float(alt.x))),cal_pairs=len(cy),cal_freeze=fold['cal_freeze'])
    save(name+'_'+ctrl+'_CAL.npz',y=cy,time=ct,PARENT=ca,DAM=cb,HALF=half,POOL=cg)
    checks+=1
  write('CAL_FROZEN.json',dict(at=c.now(),weights=frozen,protocol_sha256=c.sha(P/'PROTOCOL.json'),before_current_eval_scoring=True,prior_eval_exposure=True))
  rows={};lists={};all_y=[];all_tm=[];all_node=[];calchecks=0
  for fold in prot['folds']:
   name=fold['name'];rows[name]={}
   for gi,ctrl in enumerate(prot['groups']):
    guard()
    with np.load(U/name/ctrl/'PREDICTIONS.npz') as a,np.load(U/name/(ctrl+'_DAM')/'PREDICTIONS.npz') as b:
     y=a['y'];tm=a['time'];node=a['node'];pa=a['evaluation'];pb=b['evaluation']
     assert all(np.array_equal(a[k],b[k]) for k in ['y','time','node'])
    if gi==0:all_y.append(y);all_tm.append(tm);all_node.append(node)
    g=frozen[name][ctrl]['weight'];qs=dict(PARENT=pa,DAM=pb,HALF=(pa+pb)*.5,POOL=(1-g)*pa+g*pb)
    for variant,q in qs.items():
     key=ctrl+'_'+variant;threshold=frozen[name][ctrl]['thresholds'][variant];on=q>threshold
     with np.load(P/(name+'_'+ctrl+'_CAL.npz')) as a:
      v=np.sort(a[variant][a['y']!=1]);assert v[int(np.ceil(.99*(len(v)-1)))]==threshold;calchecks+=1
     m=metric(y,q,on);rows[name][key]=m
     pos=y==1
     assert abs(np.dot(q-pos,q-pos)/len(y)-m['brier'])<1e-12
     ll=(-np.log(np.clip(q[pos],1e-12,1)).sum()-np.log(np.clip(1-q[~pos],1e-12,1)).sum())/len(y)
     assert abs(ll-m['logloss'])<1e-12;checks+=2
     if variant in ['PARENT','DAM']:
      source=ctrl if variant=='PARENT' else ctrl+'_DAM'
      orig=c.read(U/'RESULT.json')['results'][name][source]['metrics']
      for k,vv in m.items():assert abs(vv-orig[k])<1e-12;checks+=1
     lists.setdefault(key,[]).append(q);lists.setdefault(key+'_alarm',[]).append(on)
  y=np.concatenate(all_y);tm=np.concatenate(all_tm);node=np.concatenate(all_node)
  ar={k:np.concatenate(v) for k,v in lists.items()}
  assert np.all(tm[1:]>=tm[:-1])
  aggregates={k:metric(y,v,ar[k+'_alarm']) for k,v in ar.items() if not k.endswith('_alarm')}
  months=tm.astype('datetime64[s]').astype('datetime64[M]')
  monthly={str(m):{k:metric(y[months==m],v[months==m],ar[k+'_alarm'][months==m]) for k,v in ar.items() if not k.endswith('_alarm')} for m in np.unique(months)}
  block=(tm-tm.min()//86400*86400)//259200;nb=int(block.max()+1);counts=np.bincount(block,minlength=nb)
  ww=np.random.default_rng(20260813).multinomial(nb,np.full(nb,1/nb),size=2000);den=ww@counts;stats=[]
  for group in prot['groups']:
   candidate=group+'_POOL';qc=np.clip(ar[candidate],1e-12,1-1e-12);truth=y==1
   for suffix in ['PARENT','HALF']:
    ctrl=group+'_'+suffix;qb=np.clip(ar[ctrl],1e-12,1-1e-12)
    for met in ['brier','logloss']:
     delta=(qc-truth)**2-(qb-truth)**2 if met=='brier' else np.where(truth,np.log(qb/qc),np.log((1-qb)/(1-qc)))
     samples=ww@np.bincount(block,weights=delta,minlength=nb)/den
     pv=min(1.,2*min((np.count_nonzero(samples>=0)+1)/2001,(np.count_nonzero(samples<=0)+1)/2001))
     stats.append(dict(candidate=candidate,control=ctrl,metric=met,difference=float(delta.mean()),CI95=np.quantile(samples,[.025,.975]).tolist(),p=pv))
  prev=0.
  for rank,j in enumerate(np.argsort([x['p'] for x in stats])):
   prev=max(prev,min(1.,(8-rank)*stats[j]['p']));stats[j]['exploratory_Holm8_p']=prev
  gates={}
  for g in prot['groups']:
   pc=g+'_POOL';pb=g+'_PARENT'
   proper=all(fr[pc][k]<fr[pb][k] for fr in rows.values() for k in ['brier','logloss'])
   alarm=all(fr[pc][k]>=fr[pb][k] for fr in rows.values() for k in ['precision','recall']) and all(fr[pc]['FPR']<=.02 for fr in rows.values())
   statistical=all(x['difference']<0 and x['exploratory_Holm8_p']<.05 for x in stats if x['candidate']==pc and x['control']==pb)
   gates[g]=dict(proper_scores_both_folds=proper,alarm_quality_both_folds=alarm,statistical=statistical,promising=proper and alarm and statistical)
  save('PREDICTIONS.npz',y=y,time=tm,node=node,**ar)
  guard();verify(prot)
  write('RESULT.json',dict(at=c.now(),scope=prot['scope'],weights=frozen,results=rows,aggregate=aggregates,all_months=monthly,statistics=stats,gates=gates,
    new_tree_fits=0,new_scalar_fits=4,eval_pairs=len(y),eval_dates=len(np.unique(tm//86400)),up_label_pairs=int(np.sum(y==1)),down_label_pairs=int(np.sum(y==2)),
    downward_problem_solved=False,V7_replaced=False,automatic_admission=False,point_price_integration=False,new_test_targets_read=False,
    seconds=time.monotonic()-started,next='Close failed finite probability-pooling directions; all results remain exploratory. No further threshold/month/weight search. Successful candidates still require independent confirmation.'))
  write('AUDIT.json',dict(at=c.now(),passed=True,metric_and_objective_equalities=checks,calibration_threshold_replays=calchecks,
    review_scope='Same operator, separate formulas and scalar optimizer; not independent-person audit',independent_person_review=False,
    protected_files_unchanged=18,source_scope=prot['source_scope'],original_frozen_model_files_unchanged=True,
    result_sha256=c.sha(P/'RESULT.json'),protocol_sha256=c.sha(P/'PROTOCOL.json'),predictions_sha256=c.sha(P/'PREDICTIONS.npz'),cal_frozen_sha256=c.sha(P/'CAL_FROZEN.json')))
 print(json.dumps(dict(seconds=time.monotonic()-started,weights={f:{g:r['weight'] for g,r in v.items()} for f,v in frozen.items()},aggregate=aggregates,gates=gates,statistics=stats),ensure_ascii=False))
if __name__=='__main__':
 try:run()
 except BaseException as exc:
  import traceback
  write('FAILURE.json',dict(at=c.now(),error=repr(exc),traceback=traceback.format_exc()))
  raise

