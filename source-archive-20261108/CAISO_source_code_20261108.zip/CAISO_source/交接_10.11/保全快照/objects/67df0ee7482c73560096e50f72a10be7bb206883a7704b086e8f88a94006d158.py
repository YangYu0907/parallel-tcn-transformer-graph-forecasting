"""Fixed, input-defined phase diagnosis; no model fitting or new test access."""
from pathlib import Path
import sys, json
HERE=Path(__file__).resolve().parent; B=HERE.parent
sys.path.insert(0,str(B/'context_expert_v1_20260929'))
import gate
A=Path('C:/Users/于阳/CAISO_temporary_storage')

def main():
    with gate.exclusive('Input-defined spike phase diagnosis, no training'):
        np,lim=gate.runtime(False)
        ad=gate.read(B/'spike_specialist_v7_20260930/DATA_ADMISSION.json')
        for p,h in ad['artifacts'].items(): assert gate.sha(p)==h,p
        with np.load(A/'spike_specialist_v7_20260930/TRAIN_features.npz') as f: tr={k:f[k] for k in f.files}
        with np.load(A/'spike_specialist_v7_20260930/H1_features.npz') as f: he={k:f[k] for k in f.files}
        # Existing V5 cols:17=current normalized price,19=last-minus-15-min price.
        # Existing V7 col44:within-current-episode absolute drawdown.
        def phase(x):return (x[:,44]>0)&(np.sign(x[:,17])*x[:,19]<0)
        assert np.isfinite(tr['price']).all() and np.isfinite(he['price']).all()
        m=gate.read(B/'phase_sampling_support_v3_20260923/dataset/ADDITIVE/manifest.json')
        seconds=np.load(gate.resolve(m['artifacts']['timestamps_seconds.npy']['path']),mmap_mode='r')
        rows=[]
        def counts(scope,mask,labels,days,ph):
            for key,value in [('observed_retreat',True),('other_observed_extreme',False)]:
                ix=mask&(ph==value); y=labels[ix];cnt=np.bincount(y.ravel(),minlength=3)
                rows.append(dict(scope=scope,phase=key,pairs=int(ix.sum()),dates=int(len(np.unique(days[ix]))),cells=int(y.size),normal_intermediate_extreme_cells=cnt.tolist(),fractions=(cnt/y.size).tolist() if y.size else None))
        ph=phase(tr['price']); days=seconds[tr['origins']]//86400
        counts('TRAIN_fit',tr['fit'],tr['classes'],days,ph)
        counts('TRAIN_calibration',tr['cal'],tr['classes'],days,ph)
        with np.load(A/'adaptive_experts_v4_20260929/panel.npz') as f: states=f['states'];truth=f['truth'];h_days=f['days']
        with np.load(A/'spike_specialist_v7_20260930/predictions/20260813.npz') as f: ids=f['eval_indices']
        hi=he['origin_index']; hn=he['node']; eligible=np.isin(hi,ids); hp=phase(he['price'])
        counts('Inspected_H1_development',eligible,states[hi,hn]-3,h_days[hi],hp)
        dense=np.zeros(states.shape[:2],bool); dense[hi,hn]=hp
        mask=np.broadcast_to(dense[ids,:,None],truth[ids].shape); st=states[ids]; y=truth[ids]
        errors=[]
        for seed in (20260813,20260814,20260815):
            with np.load(A/f'recovery_guard_v8_20260930/predictions/{seed}.npz') as f:
                for arm in ('FULL','V7','CAL_GUARD'):
                    er=f[arm]-y; base=f['FULL']-y; added=np.maximum(er*er-base*base,0)
                    for s in (3,4,5):
                        allstate=st==s
                        for key,value in [('observed_retreat',True),('other_observed_extreme',False)]:
                            ix=allstate&(mask==value)
                            if ix.any():errors.append(dict(seed=seed,arm=arm,state=s,phase=key,cells=int(ix.sum()),mae=float(abs(er[ix]).mean()),rmse=float(np.sqrt(np.square(er[ix]).mean())),added_sse=float(added[ix].sum()),fraction_of_state_added_sse=float(added[ix].sum()/max(added[allstate].sum(),1e-12))))
            gate.guard()
        out=dict(at=gate.now(),status='diagnosis_complete_no_fit',phase_rule='Observed extreme at origin; within-episode absolute drawdown >0 AND signed 15-minute price change <0. No H1-tuned threshold. Otherwise other observed extreme.',columns=dict(current=17,change_15min=19,episode_drawdown=44),support=rows,errors=errors,limitations=['These are dependent origin-node pairs and overlapping horizons, not independent events.','H1 was inspected previously; these are exploratory diagnostics.','An observable decline does not determine the future destination.','No new prediction or training performed.'],bindings={str(p):gate.sha(p) for p in (HERE/'phase_diagnosis.py',B/'recovery_guard_v8_20260930/AUDIT.json',B/'spike_specialist_v7_20260930/DATA_ADMISSION.json')},new_test_targets_read=False)
        gate.write(HERE/'PHASE_DIAGNOSIS.json',out)
        print(json.dumps(dict(support=rows,first_seed=[r for r in errors if r['seed']==20260813]),ensure_ascii=False))
if __name__=='__main__':main()
