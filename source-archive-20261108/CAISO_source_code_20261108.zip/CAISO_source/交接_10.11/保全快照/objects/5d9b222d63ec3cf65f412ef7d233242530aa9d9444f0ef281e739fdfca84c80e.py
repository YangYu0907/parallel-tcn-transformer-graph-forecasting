from pathlib import Path
from datetime import datetime, timezone
import sys, os, json, uuid, time, shutil
HERE = Path(__file__).resolve().parent
B = HERE.parent
ART = Path('C:/Users/于阳/CAISO_temporary_storage') / HERE.name
V14 = B / 'chronological_expert_pilot_v14_20260930'
sys.path.insert(0, str(B / 'context_expert_v1_20260929'))
import gate
read, sha, now = gate.read, gate.sha, gate.now

def atomic(path, writer):
    path = Path(path)
    assert any(path.resolve().is_relative_to(x.resolve()) for x in (HERE, ART))
    path.parent.mkdir(parents=True, exist_ok=True)
    temp = path.with_name('.' + path.name + '.' + uuid.uuid4().hex + '.tmp')
    with temp.open('xb') as f:
        writer(f); f.flush(); os.fsync(f.fileno())
    for i in range(6):
        try: os.replace(temp, path); break
        except PermissionError:
            if i == 5: raise
            time.sleep(.05 * 2**i)

def write(path, obj):
    raw = json.dumps(obj, ensure_ascii=False, indent=2, allow_nan=False).encode('utf-8')
    atomic(path, lambda f: f.write(raw))

def stamp(x): return int(datetime.fromisoformat(x).replace(tzinfo=timezone.utc).timestamp())

def check(launch=False):
    for n in ('STOP_REQUESTED', 'STOP_REQUESTED.json'):
        if (HERE/n).exists(): raise InterruptedError('Local stop requested')
    gate.guard(launch)
    ART.mkdir(parents=True, exist_ok=True)
    assert shutil.disk_usage(HERE).free > 32*2**20, 'F metadata reserve'
    assert shutil.disk_usage(ART).free > (2 if launch else 1)*2**30, 'C reserve'

def preserved():
    paths=read(B/'multi_round_mechanism_v21_20261001/RETAINED_BASELINE_HASHES.json')['files']
    for path,digest in paths.items(): assert sha(path)==digest,path
    return len(paths)

def verify():
    for path,digest in read(HERE/'SEAL.json')['bindings'].items(): assert sha(path)==digest,path
    check(); return read(HERE/'PROTOCOL.json')

def eligible(d, start, np):
    return (d['issued']+3600 < start-2*86400) & (d['available'].max(axis=1)<start)

def split(d, start, end, np):
    outer = eligible(d, start, np)
    days = np.unique(d['issued'][outer]//86400)
    ncal = max(5, int(np.ceil(.2*len(days))))
    cut = int(days[-ncal]*86400)
    fit = eligible(d, cut, np)
    cal = outer & (d['issued']>=cut)
    test = (d['issued']>=start)&(d['issued']<end)
    assert len(np.unique(d['issued'][fit]//86400))>=15
    assert len(np.unique(d['issued'][cal]//86400))>=5
    assert not (fit&cal|fit&test|cal&test).any()
    assert fit.any() and cal.any() and test.any()
    return fit, cal, test, cut

def matrix(d, np):
    h=np.tile(np.arange(1,13),len(d['issued']))
    return np.column_stack([np.repeat(d['context'],12,axis=0),h/12,(np.repeat(d['duration'],12)+h)/288]).astype(np.float32)

def targets(y, np):
    first=np.where((y<2).any(axis=1),np.argmax(y<2,axis=1),12)
    h=np.arange(12)[None,:]
    return dict(hazard=(h<=first[:,None],(h==first[:,None]).astype(int)),postexit=(h>=first[:,None],y))

def weights(mask, kind, np):
    w=np.ones(int(mask.sum())) if kind=='NATURAL' else np.repeat(1/np.maximum(mask.sum(axis=1),1),12)[mask.ravel()]
    return w*len(w)/w.sum()

def temperature(p, t, np):
    logits=np.log(np.maximum(p,1e-12))/t
    z=np.exp(logits-logits.max(axis=-1,keepdims=True))
    return z/z.sum(axis=-1,keepdims=True)

def compose(hazard, post, support, np):
    q=post.copy()
    if support:
        q[:,0,2]=0
        q[:,0,:2]/=q[:,0,:2].sum(axis=-1,keepdims=True)
    s=np.cumprod(1-hazard,axis=1)
    out=(1-s[...,None])*q;out[:,:,2]+=s
    return out

def register():
    assert not (HERE/'PROTOCOL.json').exists(), 'Already registered'
    check(True); preserved()
    old=read(V14/'RESULT.json'); audit=read(V14/'AUDIT.json')
    assert audit['status']=='passed' and sha(V14/'RESULT.json')==audit['result_sha256']
    lib=next(x for x in old['artifacts'] if x.endswith('EXPERT_ERROR_LIBRARY.npz'))
    assert sha(lib)==old['artifacts'][lib]
    p=dict(at=now(),status='registered_before_any_V23_fit',authorization='User said 开始 after diagnosis and proposal to correct probability objectives and first-step support; existing V7 and manuscript remain frozen.',
      scope='Earlier-only exploratory 2024H2 origin-extreme library already inspected during V14/V22. No new independent test. Only S3/S4/S5; no inference about S0/S1/S2 or price error improvement.',
      purpose='Discriminate outcome-weighted probability estimation, temperature calibration objective, and first-step impossible re-entry. No new expert, feature, routing threshold, price loss or core update.',
      library=lib,folds=[['2024-09-01','2024-10-01'],['2024-10-01','2024-11-01'],['2024-11-01','2024-12-01'],['2024-12-01','2025-01-01']],
      eligibility='issued+3600 < fold_start-2real_calendar_days AND every final label available before fold_start. Last max(5,ceil(20percent)) eligible distinct UTC dates form calibration. Fit obeys same two-day purge and release test before first calibration date. At least15fit dates and5calibration dates. Feasibility metadata was inspected before registration; no V23 scores inspected.',
      features='Unchanged V7 CONTEXT151 columns plus horizon/12 and (observed duration+horizon)/288, total153. Core and input scalers frozen in V14 prefix. No outcome columns in features.',
      tasks='First-exit discrete hazard conditional on risk; destination classification on post-exit rows, with all three classes required in fit.',
      fit_weights={'LEGACY':'inverse number of eligible horizon rows per origin-node pair','NATURAL':'one per eligible horizon row'},
      weight_scale='Both fit arms normalized to mean1, equal total weight for each matched task, to hold L2 scale fixed. LEGACY is a matched reconstruction of the old relative objective, not a bitwise V7 replay.',
      classifier=dict(max_leaf_nodes=15,min_samples_leaf=50,learning_rate=.05,l2_regularization=1.,early_stopping=False,random_state=20260813),
      max_iter=80,checkpoint_interval=10,maximum_classifier_fits=16,maximum_seconds=900,
      calibration='Separate bounded scalar temperature per task in[0.5,2], minimize objective-matched held-back chronological NLL. Also cross the two calibration objectives on each fitted model for attribution, without additional fits. Raw probabilities retained.',
      primary_arms=['LEGACY','LEGACY_SUPPORT','NATURAL','NATURAL_SUPPORT'],
      diagnostic_arms=['LEGACY_NATCAL','NATURAL_LEGCAL','LEGACY_RAW','NATURAL_RAW','PRIOR','FROZEN_V14'],
      support_rule='Only at h1 set postexit extreme-class probability to0 and renormalize classes0/1; no same-step exit and re-entry. h2-12 unchanged.',
      prior='Smoothed per-horizon class frequency from the same fit subset, add0.5 per class. No outcome weighting.',
      candidate='NATURAL_SUPPORT is the only candidate; other variants cannot replace it after scoring.',
      primary='Mean multiclass Brier across all eligible origin-node-horizon cells, lower better.',
      secondary='Natural logloss, first-step hazard AUC/Brier, all states, horizons, months, UTC date support and leave-one-date-out sensitivity. No price output modified.',
      inference='2000 paired bootstrap replicates on seven-real-UTC-day blocks anchored Unix epoch, retain gaps. Candidate vsLEGACY and PRIOR one two-contrast family, centered two-sided bootstrap p with Holm. Exploratory uncertainty only.',
      screen='All required: pooled Brier and logloss lower than both LEGACY and PRIOR; candidate Brier below LEGACY in>=3/4months; first-step exit AUC>=LEGACY; each state>=5evaluation dates; lower95percent bootstrap bound of Brier gain vsLEGACY>0. Passing permits only a later price-retention check, not model promotion or independent-test claims.',
      resources={'single_numeric_worker':True,'threads':1,'launch_GiB':5,'runtime_GiB':4,'numeric_artifacts_on_C':True},
      theory=[{'url':'https://arxiv.org/abs/0912.0902','supports':'Gneiting2011: scoring target and outcome weighting; applying conditional Bernoulli weighting algebra here is our explicit derivation.'},
              {'url':'https://doi.org/10.1198/016214506000001437','supports':'Gneiting and Raftery2007: proper probability scoring; Brier/logloss assess forecast distributions.'},
              {'url':'https://proceedings.mlr.press/v70/guo17a.html','supports':'Guo et al2017: scalar temperature calibration. Positive scalar temperature preserves binary ordering; no guarantee of EPF gain.'},
              {'url':'https://jmlr.org/papers/v11/cawley10a.html','supports':'Limit repeated selection; freeze one candidate and report exploratory status.'}],
      stop='Stop if screen fails or finite budget exhausts; never loosen screen using outcomes. No automatic additional model training.',V7_unchanged=True,new_test_targets_read=False,model_promotion_allowed=False)
    write(HERE/'PROTOCOL.json',p)
    paths=list(HERE.glob('*.py'))+[HERE/'PROTOCOL.json',Path(lib),V14/'PROTOCOL.json',V14/'DATA.json',V14/'DATA_AUDIT.json',V14/'RESULT.json',V14/'AUDIT.json',V14/'FINAL_FREEZE.json',V14/'specialist.py',B/'spike_specialist_v7_20260930/worker.py',B/'context_expert_v1_20260929/gate.py',B/'root_cause_review_20261001/deep_mechanism_trace/DEEP_REVIEW.json']
    write(HERE/'SEAL.json',dict(at=now(),bindings={str(x):sha(x) for x in paths}))
    print('V23 registered: sixteen bounded classifier fits; no price-model change.')

if __name__=='__main__': register()
