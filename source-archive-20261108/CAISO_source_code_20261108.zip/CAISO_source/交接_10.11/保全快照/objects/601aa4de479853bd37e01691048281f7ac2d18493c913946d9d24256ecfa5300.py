"""One registered zero-fit diagnostic; no candidate promotion or parameter search."""
from pathlib import Path
import sys, gc, time, json
HERE=Path(__file__).resolve().parent
TRIAL=HERE.parent
sys.path.insert(0,str(TRIAL))
import gate as g
import common as c
from execution import verify_training
REG=HERE/'DIAGNOSTIC_REGISTRATION.json'

def verify():
    verify_training();p=g.read(REG)
    for name,digest in p['bindings'].items():g.need(g.sha(name)==digest,'Diagnostic binding changed: '+name)
    return p

def main():
    protocol=verify();g.need(not (HERE/'RESULT.json').exists(),'Diagnostic already complete')
    with g.exclusive('aff_joint_fixed_weight_diagnostic'):
        limiter=c.init();np,torch=c.np,c.torch;d=c.data();limits=g.read(d.paths['context_limits.json'])['limits']
        import reductions as red
        from models.factory import build_backbone
        from datetime import datetime
        from zoneinfo import ZoneInfo
        panels,_=red.panels(d.origins['june_dense'],d.origins['june'])
        def core(e):
            return dict(mae=float(np.abs(e).mean()),rmse=float(np.sqrt(np.square(e).mean())),near_h1_4_mae=float(np.abs(e[:,:,:4]).mean()),h12_mae=float(np.abs(e[:,:,11]).mean()))
        keys=('mae','rmse','near_h1_4_mae','h12_mae');rows=[];checks=0;started=time.monotonic()
        comparisons=[];paired_days={};all_day_labels=None
        trial_result=g.read(TRIAL/'RESULT.json')
        for seed in protocol['seeds']:
            r=g.read(TRIAL/'runs'/f'{seed}_AFF'/'completion.json')
            cp=torch.load(r['selected_checkpoint']['path'],map_location='cpu',weights_only=False)
            m=c.model(seed,'AFF',limits);m.load_state_dict(cp['model'],strict=True);m.eval();del cp
            with np.load(r['evaluation'],allow_pickle=False) as z:
                pred=z['prediction'].copy();truth=z['truth'].copy();origins=z['origins'].copy();states=z['codes'].copy()
            off=np.flatnonzero(~np.isin(np.arange(3397),panels['June284']))
            probe_groups=[panels['June284'][:4],off[:4]]
            correction_means=[];weight_shifts=[]
            with torch.no_grad():
                for ix in probe_groups:
                    x,_=d.batch('june_dense',ix);out=m(torch.from_numpy(x))
                    p=out['prediction'].numpy().astype(np.float64)*d.scale[None,:,None]+d.center[None,:,None]
                    g.need(np.array_equal(p,pred[ix]),'Original AFF replay mismatch');checks+=1
                    correction_means.append(float(out['fusion_correction'].abs().mean()))
            before={k:v.clone() for k,v in m.state_dict().items()}
            hook=m.joint_content.register_forward_hook(lambda module,args,output:torch.zeros_like(output))
            try:arr,metrics=c.evaluate(m,d)
            finally:hook.remove()
            g.need(np.array_equal(arr['truth'],truth) and np.array_equal(arr['origins'],origins),'Changed population');checks+=1
            g.need(all(torch.equal(v,before[k]) for k,v in m.state_dict().items()),'Parameters or buffers changed');checks+=1
            for panel,ix in panels.items():
                manual=core((arr['prediction']-truth)[ix])
                for key,value in manual.items():g.need(abs(value-metrics[panel][key])<1e-10,'Reduction mismatch');checks+=1
            plain=build_backbone('FULL',seed,limits).eval()
            plain.load_state_dict({k:v for k,v in m.state_dict().items() if not k.startswith('joint_content.')},strict=True)
            with torch.no_grad():
                for ix in probe_groups:
                    x,_=d.batch('june_dense',ix);xt=torch.from_numpy(x);base=plain(xt)
                    p=base['prediction'].numpy().astype(np.float64)*d.scale[None,:,None]+d.center[None,:,None]
                    g.need(np.array_equal(p,arr['prediction'][ix]),'Disabled correction not original FULL with same learned weights');checks+=1
                    weight_shifts.append(float((m(xt)['branch_weights']-base['branch_weights'].unsqueeze(-1)).abs().mean()))
            arrays=HERE/f'sensitivity_{seed}.npz'
            c.arrays(arrays,dict(origins=origins,truth=truth,with_joint=pred,without_joint=arr['prediction']))
            with_metrics={panel:core((pred-truth)[ix]) for panel,ix in panels.items()}
            without_metrics={panel:core((arr['prediction']-truth)[ix]) for panel,ix in panels.items()}
            row=dict(seed=seed,selected_epoch=r['selected_epoch'],with_joint=with_metrics,without_joint=without_metrics,
                correction_benefit_percent={panel:{k:100*(without_metrics[panel][k]-with_metrics[panel][k])/without_metrics[panel][k] for k in keys} for panel in panels},
                prediction_absolute_shift=float(np.abs(pred-arr['prediction']).mean()),probe_mean_abs_logit_correction=float(np.mean(correction_means)),
                probe_mean_abs_branch_weight_shift=float(np.mean(weight_shifts)),arrays=str(arrays),arrays_sha256=g.sha(arrays))
            rows.append(row)
            # Profile all original matched predictions: no favorable-phase selection.
            dates=np.array([datetime.fromtimestamp(float(t),ZoneInfo('America/Los_Angeles')).date().isoformat() for t in d.times[origins]])
            day_labels=np.unique(dates)
            if all_day_labels is None:all_day_labels=day_labels
            g.need(np.array_equal(day_labels,all_day_labels),'Dates changed across seeds');checks+=1
            for variant in ('FULL_CONT','CONCAT_CONT'):
                case=next(case for case in trial_result['cases'] if case['seed']==seed and case['variant']==variant)
                control_record=g.read(Path(case['completion']));control_path=control_record['evaluation']
                with np.load(control_path,allow_pickle=False) as z:
                    g.need(np.array_equal(z['origins'],origins) and np.array_equal(z['truth'],truth),'Control panel mismatch');checks+=1
                    control=z['prediction'].copy()
                diff=np.abs(control-truth)-np.abs(pred-truth)
                day_sums=np.array([diff[dates==day].sum(dtype=np.float64) for day in day_labels])
                day_counts=np.array([int((dates==day).sum())*30*12 for day in day_labels])
                paired_days.setdefault(variant,[]).append((day_sums,day_counts))
                prof={}
                for phase in range(12):
                    ix=np.flatnonzero(origins%12==phase);a=core((pred-truth)[ix]);b=core((control-truth)[ix])
                    prof[str(phase)]=dict(origins=len(ix),AFF=a,control=b,improvement_percent={k:100*(b[k]-a[k])/b[k] for k in keys})
                comparisons.append(dict(seed=seed,control=variant,by_phase=prof,mae_win_nodes=int((diff.mean((0,2))>0).sum()),mae_win_horizons=int((diff.mean((0,1))>0).sum()),
                    by_state=[dict(state=s,count=int((states==s).sum()),AFF=red.core((pred-truth)[states==s]),control=red.core((control-truth)[states==s])) for s in range(6)]))
            g.write(HERE/'progress.json',dict(at=g.now(),completed_seeds=len(rows),last=row))
            print(json.dumps(dict(seed=seed,correction_benefit_pct=row['correction_benefit_percent']['June3397']['mae'],MAE_with=with_metrics['June3397']['mae'],MAE_without=without_metrics['June3397']['mae'])),flush=True)
            del m,plain,arr,pred,truth,control;gc.collect()
        means={condition:{panel:{k:float(np.mean([r[condition][panel][k] for r in rows])) for k in keys} for panel in panels} for condition in ('with_joint','without_joint')}
        # Descriptive sensitivity interval only: already inspected, selected development
        # period; local-day clusters preserve all within-day dependence, not between-day.
        rng=np.random.default_rng(20260929);resample=rng.integers(0,len(all_day_labels),(2000,len(all_day_labels)))
        intervals={}
        for variant,values in paired_days.items():
            sums=np.mean([v[0] for v in values],axis=0);counts=values[0][1]
            g.need(all(np.array_equal(counts,v[1]) for v in values),'Day counts differ');checks+=1
            draws=sums[resample].sum(axis=1)/counts[resample].sum(axis=1)
            intervals[variant]=dict(mean_MAE_reduction=float(sums.sum()/counts.sum()),interval95=np.quantile(draws,[.025,.975]).tolist(),local_days=all_day_labels.tolist(),replicates=2000,
                interpretation='Exploratory day-cluster sensitivity, not independent confirmation or selection-adjusted significance; no p-value or promotion decision.')
        verify();out=HERE/'RESULT.json'
        g.write(out,dict(status='fixed_weight_diagnostic_complete',at=g.now(),rows=rows,means=means,comparisons=comparisons,development_day_intervals=intervals,
            optimizer_updates=0,new_test_targets_read=False,elapsed_seconds=time.monotonic()-started,
            interpretation='Zeroing the learned correction is an inference sensitivity, not retraining an ablation. Neither forecast variant is promoted or selected here.'))
        g.write(HERE/'AUDIT.json',dict(status='passed',at=g.now(),checks=checks,result_sha256=g.sha(out),exact_original_replays=24,exact_counterfactual_replays=24,
            scope='Same-operator separate reductions and original FULL reconstruction; not external independent review.'))
        print('Diagnostic passed',checks,flush=True)
if __name__=='__main__':main()
