"""IO-only recovery. Reuse all frozen models; do not call any fit operation."""
import pilot as p
from pilot import *
import shutil,traceback,importlib.util
RAW_WRITE=p.write
def native(obj):
 if isinstance(obj,np.generic):return native(obj.item())
 if isinstance(obj,np.ndarray):return native(obj.tolist())
 if isinstance(obj,dict):return {k:native(v) for k,v in obj.items()}
 if isinstance(obj,(list,tuple)):return [native(v) for v in obj]
 return obj
def repaired_write(name,obj):RAW_WRITE(name,native(obj))
def local_module(name,filename):
 path=P/filename
 if str(path) in c.read(P/'PROTOCOL.json')['bindings']:assert c.sha(path)==c.read(P/'PROTOCOL.json')['bindings'][str(path)]
 spec=importlib.util.spec_from_file_location(name,path);module=importlib.util.module_from_spec(spec);spec.loader.exec_module(module);return module
def main():
 guard(True);protocol=verify();start=time.monotonic();prior=c.read(P/'BUDGET.json')['seconds']
 assert c.read(P/'COMPLETION.json')['completed']==18
 assert not c.base.LOCK.exists()
 # Before examining scores, archive the failing state and bind every trained output.
 archive=P/'pre_io_repair';archive.mkdir(exist_ok=True);frozen={}
 for name in ['FAILURE.json','STATUS.json','PROGRESS.json','BUDGET.json','ALL_RESULTS.json','SUMMARY.json','STATISTICS.json']:
  source=P/name
  if source.exists():
   target=archive/name
   if not target.exists():shutil.copy2(source,target)
 for ckpath in sorted((P/'fits').glob('*/COMPLETE.json')):
  ck=c.read(ckpath);assert ck['protocol_sha256']==c.sha(P/'PROTOCOL.json')
  for path,h in {**ck['models'],**ck['outputs']}.items():assert c.sha(path)==h;frozen[path]=h
  frozen[str(ckpath)]=c.sha(ckpath)
 assert len(frozen)==288  #234model files+36outputs+18completion records
 expected={'values':[True,False,7,1.25],'array':[True,False]}
 test={'values':[np.bool_(True),np.bool_(False),np.int64(7),np.float64(1.25)],'array':np.array([True,False])}
 assert json.loads(json.dumps(native(test),allow_nan=False))==expected
 RAW_WRITE('IO_REPAIR_V2.json',dict(at=c.now(),status='registered_before_recovery',
   cause='NumPy boolean scalars in point_checks/detail were not serializable by standard json.dump',
   modification='Normalize NumPy scalar/array containers at writer boundary only. Explicitly load local bound scoring/audit/manager scripts by exact path, avoiding same-name modules from imported earlier studies. Frozen source, protocol, model files, outputs and scoring mathematics unchanged.',
   second_failure='Bare import audit selected an earlier-study module after support altered sys.path. Its function was not called because audit attribute was absent. Preserved recovery failure v1.',
   before_event='flex_information_blocking_failure_b51f34baf810aeb6415b59366537f4de487105d1eed6be0ef0e8f857bec93c82',
   repair_script_sha256=c.sha(P/'repair_io_finalize.py'),protocol_sha256=c.sha(P/'PROTOCOL.json'),
   backup=str(archive),models_and_outputs=frozen,serialization_qa_passed=True,new_training_fits=0,new_test_targets_read=False))
 p.write=repaired_write
 def tick(**kw):
  guard();seconds=prior+time.monotonic()-start
  repaired_write('BUDGET.json',dict(at=c.now(),seconds=seconds,maximum=21600))
  if seconds>21600:raise TimeoutError('Existing6hbudget preserved')
  repaired_write('RECOVERY_PROGRESS.json',dict(at=c.now(),pid=os.getpid(),seconds=seconds,**kw))
 with c.numeric('IO repair: no training; frozen scoring, audit and error decomposition'):
  if (P/'SCORING_BINDINGS.json').exists():
   bound=c.read(P/'SCORING_BINDINGS.json')
   for path,h in {**bound['inputs'],**bound['outputs']}.items():assert c.sha(path)==h,path
   assert (P/'REPORT_CN.txt').exists()
  else:
   score=local_module('fourarm_recovery_score','score.py');score.main(tick)
  # Previously written numerical tables must be exactly reproducible.
  for name in ['ALL_RESULTS.json','SUMMARY.json','STATISTICS.json']:
   assert c.read(P/name)==c.read(archive/name),name
  tick(stage='separate_formula_and_replay_audit')
  audit=local_module('fourarm_recovery_audit','audit.py');audit.audit()
  tick(stage='no_fit_error_decomposition')
  posthoc_diagnosis=local_module('fourarm_recovery_diagnosis','posthoc_diagnosis.py');posthoc_diagnosis.main()
  for path,h in frozen.items():assert c.sha(path)==h,path
  assert c.verify_protected()==18
  tick(stage='recovery_complete')
 result=c.read(P/'RESULT.json');aa=c.read(P/'AUDIT.json')
 repaired_write('RECOVERY_COMPLETE.json',dict(at=c.now(),status='passed',new_fits=0,all234models_and36outputs_unchanged=True,
   prior_three_numeric_tables_exact=True,separate_audit_checks=aa['checks'],source_protocol_unchanged=True,
   result_sha256=c.sha(P/'RESULT.json'),audit_sha256=c.sha(P/'AUDIT.json'),decomposition_sha256=c.sha(P/'ERROR_DECOMPOSITION.json'),
   V7_replaced=False,new_test_targets_read=False,scope='Foreground supervised recovery; no new training manager'))
 mgr=local_module('fourarm_recovery_event','manager.py')
 eid=mgr.emit('audited_result_ready' if result['point_screen_passed'] else 'needs_analysis',P/'AUDIT.json')
 mgr.status(event='finite_mechanism_queue_completed',event_id=eid,point_screen_passed=result['point_screen_passed'],probability_screen_passed=result['probability_screen_passed'],V7_replaced=False,recovery='IO_and_exact_module_resolution_no_refit')
 print(json.dumps(dict(status='recovery_complete',audit_checks=aa['checks'],point_pass=result['point_screen_passed'],probability_pass=result['probability_screen_passed'],new_fits=0)),flush=True)
if __name__=='__main__':
 try:main()
 except Exception as ex:
  RAW_WRITE('RECOVERY_FAILURE.json',dict(at=c.now(),error=repr(ex),traceback=traceback.format_exc(),new_fits=0));raise
