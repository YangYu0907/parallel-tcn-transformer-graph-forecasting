"""Independent frozen-FULL adapter audit using direct labels, scalar oracle and checkpoint cursors."""
import argparse,importlib.util,json,sys
import gate
def main(case_id):
    seal=gate.verify();case=next(c for c in seal['cases'] if c['id']==case_id)
    run=gate.HERE/'runs'/case_id;cp=run/'completion.json';result=gate.read(cp)
    gate.need(result['identity']['case']==case and result['identity']['seal_sha256']==gate.sha(gate.SEAL),'Run identity differs')
    with gate.exclusive('audit_adapter_'+case_id):
        np,torch,limiter=gate.runtime()
        spec=importlib.util.spec_from_file_location('adapter_scalar_oracle',gate.COMMON/'audit.py')
        oracle=importlib.util.module_from_spec(spec);spec.loader.exec_module(oracle);oracle.np=np
        manifest=gate.read(gate.inside(seal['dataset_manifest']))
        def art(name):return gate.inside(manifest['artifacts'][name]['path'])
        target=np.load(art('target_scaled.npy'),mmap_mode='r',allow_pickle=False)
        features=np.load(art('features.npy'),mmap_mode='r',allow_pickle=False)
        sc=gate.read(art('scalers.json'));center=np.array(sc['price_center'],np.float64)[0,:,0];scale=np.array(sc['price_scale'],np.float64)[0,:,0]
        q=np.array(gate.read(art('state_thresholds.json'))['thresholds'],np.float64)
        populations=dict(june=np.load(art('registered_june_origins.npy'),allow_pickle=False),
            dense=np.load(art('june_origins.npy'),allow_pickle=False),
            train=np.load(gate.inside(seal['train_diagnostic']),allow_pickle=False))
        gold={}
        for name,origins in populations.items():
            gate.guard();stop=210528 if name=='train' else 219168
            gate.need((origins>=288).all() and (origins+12<=stop).all(),'Label range escaped')
            truth=np.stack([target[o:o+12].T.copy() for o in origins]).astype(np.float64)*scale[None,:,None]+center[None,:,None]
            last=np.array(features[origins-1,:,0],np.float64)*scale+center
            state=np.empty(truth.shape,np.uint8)
            for i in range(len(origins)):
                for node in range(30):
                    act=abs(float(last[i,node]-center[node]))>float(q[1,node])
                    for h in range(12):
                        distance=abs(float(truth[i,node,h]-center[node]))
                        state[i,node,h]=3*int(act)+int(distance>q[0,node])+int(distance>q[1,node])
            gold[name]=(origins,truth,state)
        bindings={gate.rel(cp):gate.sha(cp)}
        def load(reference,part):
            p=gate.inside(reference['path']);gate.need(gate.sha(p)==reference['sha256'],'Evaluation changed')
            bindings[gate.rel(p)]=reference['sha256']
            with np.load(p,allow_pickle=False) as z:
                gate.need(set(z.files)=={'origins','truth','codes','prediction'},'Array schema differs')
                for key,expected in zip(('origins','truth','codes'),gold[part]):gate.need(np.array_equal(z[key],expected),'Direct label/state/origin differs')
                prediction=z['prediction']
            gate.need(prediction.shape==gold[part][1].shape and np.isfinite(prediction).all(),'Bad prediction')
            return prediction,prediction-gold[part][1]
        gate.need([x['epoch'] for x in result['epochs']]==[0,1,2],'All three checkpoints required')
        chosen=None;epoch_predictions={}
        for row in result['epochs']:
            gate.guard();p,e=load(row['evaluation'],'dense');epoch_predictions[row['epoch']]=p
            oracle.compare(row['selection_metrics'],oracle.head(e),'epoch'+str(row['epoch']))
            path=gate.inside(row['checkpoint']);receipt=gate.read(path.with_suffix('.receipt.json'))
            gate.need(gate.sha(path)==receipt['sha256'],'Checkpoint hash mismatch')
            saved=torch.load(path,map_location='cpu',weights_only=False)
            expected_steps=row['epoch']*1008
            gate.need(row['steps']==expected_steps==saved['progress']['steps']==receipt['steps'],'Optimizer budget mismatch')
            gate.need(saved['identity']==result['identity'] and saved['progress']['phase']=='epoch_complete','Checkpoint scope differs')
            gate.need(saved['scope']=='frozen_full_adapter_only','Wrong stage')
            for group in saved['optimizer']['param_groups']:
                gate.need(group['lr']==.001 and group['weight_decay']==.0001 and group['betas']==(.9,.999) and group['eps']==1e-8,'Optimizer recipe changed')
            counts=[float(v['step']) for v in saved['optimizer']['state'].values()]
            gate.need((not counts if expected_steps==0 else counts and all(x==expected_steps for x in counts)),'Adam state step mismatch')
            bindings[gate.rel(path)]=receipt['sha256'];bindings[gate.rel(path.with_suffix('.receipt.json'))]=gate.sha(path.with_suffix('.receipt.json'))
            original=torch.load(gate.inside(case['parent']['selected_checkpoint']),map_location='cpu',weights_only=False)
            base_state={k[len('base.'):]:v for k,v in saved['state_dict'].items() if k.startswith('base.')}
            gate.need(set(base_state)==set(original['state_dict']) and all(torch.equal(v,original['state_dict'][k]) for k,v in base_state.items()),'Frozen backbone tensors changed')
            adapter_state={k:v for k,v in saved['state_dict'].items() if k.startswith('adapter.')}
            gate.need(set(adapter_state)=={'adapter.down.weight','adapter.down.bias','adapter.up.weight','adapter.up.bias'} and sum(v.numel() for v in adapter_state.values())==552,'Adapter shape/parameter budget')
            gate.need(all(torch.isfinite(v).all() for v in adapter_state.values()),'Nonfinite adapter')
            if row['epoch']==0:
                zero_state={k:v.clone() for k,v in saved['state_dict'].items()}
                gate.need(torch.count_nonzero(adapter_state['adapter.up.weight'])==0 and torch.count_nonzero(adapter_state['adapter.up.bias'])==0,'Adapter must initialize as identity')
                br=gate.read(gate.inside(case['parent']['dense_receipt']))
                gate.need(gate.sha(gate.inside(br['artifact']))==br['artifact_sha256'],'Parent dense hash')
                with np.load(gate.inside(br['artifact']),allow_pickle=False) as zz:old=zz['prediction']
                gate.need(np.array_equal(p,old),'Epoch zero dense regression mismatch')
            del original
            if case['arm']=='OFFHOUR':gate.need(np.array_equal(p[populations['dense']%12==0],old[populations['dense']%12==0]),'Any epoch changed protected hourly predictions')
            if chosen is None or row['selection_metrics']['mae']<chosen['selection_metrics']['mae']-1e-6:chosen=row
            del saved
        gate.need(chosen['epoch']==result['selected_epoch'] and chosen['checkpoint']==result['selected_checkpoint'],'Selection differs')
        p,e=load(result['dense_evaluation'],'dense');dense=populations['dense']
        ids,blocks=oracle.panels_oracle(dense,populations['june'])
        gate.need(len(blocks)==278 and len(dense)==3397,'Panel support differs')
        compare={name:oracle.oracle_breakdown(e[ix],gold['dense'][2][ix],dense[ix]) for name,ix in ids.items()}
        oracle.compare(result['panels'],compare,'panels')
        gate.need(np.array_equal(p,epoch_predictions[result['selected_epoch']]),'Dense selection prediction mismatch')
        gate.need([x['epoch'] for x in result['train_curves']]==[0,1,2],'Fixed TRAIN curves missing')
        for curve in result['train_curves']:
            gate.guard();_,e=load(curve['evaluation'],'train')
            oracle.compare(curve['metrics'],oracle.oracle_breakdown(e,gold['train'][2],populations['train']))
        start=gate.read(run/'run_start.json')
        bindings[gate.rel(run/'run_start.json')]=gate.sha(run/'run_start.json')
        gate.need(result['base_unchanged'] is True and result['base_fingerprint']==start['base_fingerprint'],'Frozen base preservation record differs')
        other=gate.HERE/'runs'/(str(case['seed'])+('_OFFHOUR' if case['arm']=='GLOBAL' else '_GLOBAL'))/'run_start.json'
        if other.exists():
            peer=gate.read(other)
            gate.need(peer['student_initial_fingerprint']==start['student_initial_fingerprint'] and peer['base_fingerprint']==start['base_fingerprint'] and peer['adapter_initial_fingerprint']==start['adapter_initial_fingerprint'],'Matched initialization differs')
            peer_completion=other.parent/'completion.json'
            if peer_completion.exists():
                pc=gate.read(peer_completion);initial_path=gate.inside(pc['epochs'][0]['checkpoint'])
                initial_receipt=gate.read(initial_path.with_suffix('.receipt.json'))
                gate.need(gate.sha(initial_path)==initial_receipt['sha256'],'Peer initial checkpoint binding')
                initial=torch.load(initial_path,map_location='cpu',weights_only=False)['state_dict']
                gate.need(set(initial)==set(zero_state) and all(torch.equal(initial[k],v) for k,v in zero_state.items()),'Actual paired initial tensors differ')
                bindings[gate.rel(initial_path)]=initial_receipt['sha256']

        parent=case['parent']
        baseline_receipt=gate.read(gate.inside(parent['dense_receipt']))
        basepath=gate.inside(baseline_receipt['artifact'])
        gate.need(gate.sha(basepath)==baseline_receipt['artifact_sha256']==seal['bindings'][gate.rel(basepath)],'Parent dense reference changed')
        with np.load(basepath,allow_pickle=False) as z:
            gate.need(np.array_equal(z['origins'],dense) and np.array_equal(z['truth'],gold['dense'][1]),'Parent dense target mismatch')
            original_dense=z['prediction']
        selected_prediction,_=load(result['dense_evaluation'],'dense')
        protected=dense%12==0
        protected_difference=float(np.max(np.abs(selected_prediction[protected]-original_dense[protected])))
        if case['arm']=='OFFHOUR':gate.need(np.array_equal(selected_prediction[protected],original_dense[protected]),'Offhour adaptation changed hourly predictions')
        # Independent formula replay using frozen backbone and raw adapter tensors.
        from models.factory import build_backbone
        from compiled_data import CompiledData
        data=CompiledData(seal['dataset_manifest'])
        limits=gate.read(data.paths['context_limits.json'])['limits']
        base=build_backbone('FULL',case['seed'],limits).eval().requires_grad_(False)
        saved=torch.load(gate.inside(result['selected_checkpoint']),map_location='cpu',weights_only=False)
        weights=saved['state_dict'];base.load_state_dict({k[5:]:v for k,v in weights.items() if k.startswith('base.')},strict=True)
        probes=list(ids['June284'][:12])+[i for i,o in enumerate(dense) if int(o)%12!=0][:12]
        gate.need(len(probes)==len(set(probes))==24,'Independent probe support')
        replay_difference=0.
        with torch.inference_mode():
            for offset in range(0,24,4):
                gate.guard();ix=np.array(probes[offset:offset+4]);x,_=data.batch('june_dense',ix)
                out=base(torch.from_numpy(x))
                z=torch.nn.functional.linear(out['head_features'],weights['adapter.down.weight'],weights['adapter.down.bias'])
                delta=torch.nn.functional.linear(torch.nn.functional.gelu(z),weights['adapter.up.weight'],weights['adapter.up.bias'])
                predicted=base.head(out['head_features']+delta)
                mask=((data.times[dense[ix]]//300)%12==0)
                gate.need(np.array_equal(mask,dense[ix]%12==0),'Known origin phase definition')
                if case['arm']=='OFFHOUR':predicted=torch.where(~torch.from_numpy(mask)[:,None,None],predicted,out['prediction'])
                usd=predicted.numpy().astype(np.float64)*scale[None,:,None]+center[None,:,None]
                replay_difference=max(replay_difference,float(np.max(np.abs(usd-selected_prediction[ix]))))
        gate.need(replay_difference<=1e-9,'Independent selected-checkpoint formula replay mismatch')
        gate.verify()
        report=dict(status='passed',at=gate.now(),case=case_id,completion_sha256=gate.sha(cp),seal_sha256=gate.sha(gate.SEAL),
            selected_epoch=result['selected_epoch'],optimizer_steps=2016,output_bindings=bindings,
            hourly_prediction_max_difference=protected_difference,selected_formula_replay_origins=24,selected_formula_replay_max_difference=replay_difference,
            scope='Independent direct-label and scalar-metric audit plus optimizer cursor and initialization checks; same operator, not second-person review',
            heldout_targets_read=False,complete_research_experiment=False)
        gate.write(run/'audit.json',report)
        print(json.dumps(dict(status='passed',case=case_id,selected_epoch=result['selected_epoch'])),flush=True)
if __name__=='__main__':
    p=argparse.ArgumentParser();p.add_argument('--case',required=True);main(p.parse_args().case)

