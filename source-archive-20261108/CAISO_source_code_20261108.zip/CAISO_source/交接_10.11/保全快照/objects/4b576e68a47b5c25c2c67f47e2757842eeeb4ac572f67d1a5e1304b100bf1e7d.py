"""Finite serial queue; no clock-based model wakeups or automatic retry."""
from common import *
import subprocess,uuid,traceback
STATUS=ROOT/'MANAGER_STATUS.json'
def status(**kw):write(STATUS,dict(at=now(),pid=os.getpid(),**kw))
def emit(kind,evidence):
 eid='reviewer_v2_'+kind+'_'+sha(evidence);out=B/'event_driven_automation/inbox'/f'{eid}.json'
 if not out.exists():
  temp=out.with_suffix('.tmp');temp.write_text(json.dumps(dict(schema='caiso_research_event_v1',event_id=eid,event=kind,evidence_path=str(evidence),evidence_sha256=sha(evidence),at=now(),scope='reviewer revision, V7 protected'),ensure_ascii=False,indent=2),encoding='utf-8');os.replace(temp,out)
 return eid
def main():
 owner=ROOT/'MANAGER.lock'
 with owner.open('x',encoding='utf-8') as f:json.dump(dict(pid=os.getpid(),at=now()),f)
 try:
  seal=read(ROOT/'FAIR_INPUT_SEAL.json');verify_protected()
  for c in seal['cases']:
   guard(True);path=ROOT/'fair_runs'/f"{c['seed']}_{c['model']}"/'COMPLETE.json'
   if path.exists():continue
   log=ROOT/'logs'/f"{c['seed']}_{c['model']}.log";log.parent.mkdir(exist_ok=True)
   with log.open('a',encoding='utf-8') as f:
    child=subprocess.Popen([sys.executable,'-u',str(ROOT/'fair_inputs.py'),'run','--model',c['model'],'--seed',str(c['seed'])],cwd=ROOT,stdout=f,stderr=subprocess.STDOUT)
    status(event='step_process_started',case=c,worker_pid=child.pid,log=str(log));code=child.wait()
   if code:raise RuntimeError('Worker exit '+str(code)+'; see '+str(log))
   assert path.exists(),'Missing completed result'
  log=ROOT/'logs/audit.log'
  with log.open('a',encoding='utf-8') as f:
   child=subprocess.Popen([sys.executable,'-u',str(ROOT/'audit_fair.py')],cwd=ROOT,stdout=f,stderr=subprocess.STDOUT);status(event='step_process_started',case='separate_saved_output_audit',worker_pid=child.pid);code=child.wait()
  if code:raise RuntimeError('Audit failed, see '+str(log))
  proof=ROOT/'FAIR_COMPLETE.json';eid=emit('audited_result_ready',proof);status(event='finite_sampling_queue_completed',event_id=eid,evidence_path=str(proof))
 except Exception as e:
  failure=ROOT/('FAILURE_'+uuid.uuid4().hex+'.json');write(failure,dict(at=now(),error=repr(e),traceback=traceback.format_exc(),resume='Inspect saved state and resources; no automatic restart',protected=verify_protected()))
  try:guard(False)
  except InterruptedError:status(event='user_stop',classification='user_stop',evidence_path=str(failure));return
  except MemoryError:pass
  eid=emit('blocking_failure',failure);status(event='sampling_blocking_failure',event_id=eid,evidence_path=str(failure));raise
 finally:
  if read(owner).get('pid')==os.getpid():owner.unlink()
if __name__=='__main__':main()
