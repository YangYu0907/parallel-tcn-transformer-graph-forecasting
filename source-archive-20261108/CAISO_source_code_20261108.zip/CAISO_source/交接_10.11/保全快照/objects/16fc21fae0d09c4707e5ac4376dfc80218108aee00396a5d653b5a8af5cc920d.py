from pathlib import Path
import json
import manager as m

def main():
    f=m.P/'qa_fixture';f.mkdir(exist_ok=True)
    data=f/'part.grib2';data.write_bytes(b'fixture')
    header=Path(str(data)+'.headers');etag='"'+'a'*32+'"'
    header.write_text('HTTP/1.1 206 Partial Content\nETag: '+etag+'\nLast-Modified: Thu, 01 Jan 1970 00:00:00 GMT\nContent-Length: 7\nContent-Range: bytes 3-9/20\n',encoding='utf-8')
    x=dict(path=data,size=7,range=[3,9],source=dict(etag=etag,minimum_qualified_cutoff=1,bytes=20))
    assert m.complete_part(x);checks=['Eligible exact object and byte range accepted']
    for key,value in [('etag','"'+'b'*32+'"'),('minimum_qualified_cutoff',-1),('bytes',21),('etag','"multipart-2"')]:
        bad=dict(x,source=dict(x['source'],**{key:value}))
        try:m.complete_part(bad)
        except AssertionError:pass
        else:raise AssertionError('Mirror identity/time constraint was not enforced')
    checks.append('Wrong checksum, future version, wrong object size, and multipart identity rejected')
    original=m.s.write;captured=[]
    try:
        m.s.write=lambda name,data:captured.append(name)
        m.setup();m.nt.m.s.write('cycles/test.json',{});m.nt.s.write('download_receipts/test.json',{});m.nt.write('TRANSFER_COUNTERS.json',{})
        assert all(x.startswith(m.P.name+'/') for x in captured) and len(captured)==3
        checks.append('Decoder, receipts and counters isolated from original source records')
    finally:m.s.write=original
    m.s.verify();checks.append('Scientific parent/protected bindings unchanged')
    m.write('QA.json',dict(at=m.s.now(),passed=True,checks=checks,network_requests=0,model_fits=0))
    print(json.dumps(dict(passed=True,checks=len(checks),network_requests=0,model_fits=0)))

if __name__=='__main__':main()
