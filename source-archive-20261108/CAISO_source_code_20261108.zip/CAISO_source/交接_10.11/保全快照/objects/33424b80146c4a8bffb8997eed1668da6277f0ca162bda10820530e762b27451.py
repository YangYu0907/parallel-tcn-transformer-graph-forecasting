"""Unchanged six-epoch V3 optimizer loop, isolated official-model factory."""
import argparse,json,sys,types
import gate
base=gate.load('sealed_external_v3_loop',gate.V/'source/train.py')
original_admission=base.admission;original_directory=base.run_directory;original_stop=base.stop_reason
preflight=gate.load('sealed_sampling_preflight',gate.V/'source/preflight.py')
sys.modules['preflight']=preflight
def run_directory(policy,variant,seed):
    if variant=='FULL' and seed==20260813:return original_directory(policy,variant,seed)
    gate.need(policy=='ADDITIVE' and any(c['seed']==seed and c['variant']==variant for c in gate.CASES),'Unregistered external case')
    return gate.HERE/'runs'/f'{seed}_{variant}'
def admission(manifest,variant,seed):
    s=gate.verify()
    gate.need(any(c['seed']==seed and c['variant']==variant for c in s['cases']),'Unregistered external case')
    gate.need(gate.inside(manifest)==gate.inside(s['dataset_manifest']),'Changed dataset')
    witness=original_admission(manifest,'FULL',20260813)
    identity=dict(witness)
    identity.update(variant=variant,seed=seed,metadata_contract_witness_identity=witness,
        external_execution_lock_sha256=gate.sha(gate.SEAL),external_protocol_sha256=gate.sha(gate.HERE/'PROTOCOL.json'),
        external_model_QA_sha256=gate.sha(gate.HERE/'synthetic_qa.json'),
        diagnostic_scope='fixed6048update_history_only_external_comparison',
        profile=gate.read(gate.HERE/'PROTOCOL.json')['models'][variant]['profile'],
        original_model_qa_scope='Inherited witness certifies data/loop only; external model certified by external_model_QA_sha256')
    return identity
def stop_reason(run):
    try:gate.boundary()
    except InterruptedError as exc:return str(exc)
    return original_stop(run)
def install():
    base.admission=admission;base.run_directory=run_directory;base.stop_reason=stop_reason;base.atomic=gate.atomic
    # Lazy pure-Python routing: no Torch before admission/resource checks.
    factory=types.ModuleType('models.factory')
    from model_adapter import build_model
    factory.build_backbone=build_model
    sys.modules['models.factory']=factory
    return base
def main(a):
    install();gate.resources_api.bound_process()
    if a.action=='train':
        r=base.train(base.policy_manifest('ADDITIVE'),a.variant,a.seed,a.resume)
        print(json.dumps(r));return 3 if r['status']=='stopped_at_safe_boundary' else 0
    gate.verify();preflight.require_mechanisms_complete();preflight.launch_guard()
    admission(base.policy_manifest('ADDITIVE'),a.variant,a.seed)
    sys.modules['train']=base
    oracle=gate.load('unchanged_sampling_saved_output_oracle',gate.V/'source/audit_result.py')
    with base.exclusive('external_saved_output_selection_audit'):
        np,limiter=gate.runtime(False);oracle.np=np
        print(json.dumps(oracle.audit(a.seed,a.variant,'ADDITIVE')))
    return 0
if __name__=='__main__':
    p=argparse.ArgumentParser();p.add_argument('action',choices=('train','audit'))
    p.add_argument('--variant',choices=('DLinear','iTransformer-H'),required=True)
    p.add_argument('--seed',type=int,choices=(20260813,20260814,20260815),required=True)
    p.add_argument('--resume',action='store_true')
    raise SystemExit(main(p.parse_args()))
