from common import *

def main():
    with gate.exclusive('V10 admission and objective QA before fitting'):
        np,lim=gate.runtime(False);import modelmath as mm
        for p,h in gate.read(V7/'DATA_ADMISSION.json')['artifacts'].items():assert gate.sha(p)==h,p
        objective=gate.read(B/'spike_precision_diagnosis_20260930/RISK_OBJECTIVE_AUDIT.json')
        assert objective['status']=='exact_objective_mismatch_verified_no_model_fit'
        with np.load(A7/'TRAIN_features.npz') as f:tr={k:f[k] for k in f.files}
        with np.load(A7/'H1_features.npz') as f:he={k:f[k] for k in f.files}
        checks=mm.qa();risk,event,post=mm.risk_sets(tr['classes']);rows=[]
        for task,rm in [('hazard',risk),('postexit',post)]:
            r=rm[tr['fit']];old=np.repeat(1/np.maximum(r.sum(1),1),12)[r.ravel()]
            constant=old.sum()/r.sum();new=np.full(r.sum(),constant)
            assert np.allclose(new,new[0]) and abs(new.sum()-old.sum())<1e-8
            rows.append(dict(task=task,eligible_cells=int(r.sum()),total_weight=float(old.sum()),constant_weight=float(constant)))
        # Features and inference are unchanged; perturbing future labels cannot change
        # any saved input tensor. Label-dependent training risk sets are intentional.
        checks+=['synthetic known-hazard test independently passed','constant within-task weights','unchanged total weights and regularization scale','frozen core and existing input tensors']
        m=gate.read(B/'phase_sampling_support_v3_20260923/dataset/ADDITIVE/manifest.json');th=gate.resolve(m['artifacts']['state_thresholds.json']['path'])
        deps=[HERE/'PROTOCOL.json',A7/'TRAIN_features.npz',A7/'H1_features.npz',V7/'DATA_ADMISSION.json',V7/'AUDIT.json',A4/'panel.npz',th,B/'adaptive_experts_v4_20260929/FOLDS.json',B/'spike_precision_diagnosis_20260930/RISK_OBJECTIVE_AUDIT.json',B/'spike_precision_diagnosis_20260930/diagnose.py']
        for s in SEEDS:
            deps += [A7/f'predictions/{s}.npz',A7/f'models/{s}_CONTEXT_probabilities.npz',A4/f'experts/{s}.npz',A5/f'models/{s}_distributions.npz']
            assert gate.sha(A7/f'predictions/{s}.npz')==gate.read(V7/f'receipts/{s}.json')['sha256']
        write(HERE/'SOURCE_BINDINGS.json',dict(at=gate.now(),bindings={str(p):gate.sha(p) for p in deps}))
        write(HERE/'DATA_ADMISSION.json',dict(at=gate.now(),status='passed_before_fit',development_only=True,new_test_targets_read=False,actual_input_hashes_inherited=True,weights=rows))
        write(HERE/'QA.json',dict(at=gate.now(),status='passed',checks=checks))
        code=[HERE/n for n in ('common.py','modelmath.py','worker.py','audit.py','manager.py','register.py','PROTOCOL.json','SOURCE_BINDINGS.json','DATA_ADMISSION.json','QA.json')]+[T/'gate.py']
        write(HERE/'EXECUTION_SEAL.json',dict(at=gate.now(),bindings={str(p):gate.sha(p) for p in code}))
        print(json.dumps(dict(qa='passed',weights=rows)))
if __name__=='__main__':main()
