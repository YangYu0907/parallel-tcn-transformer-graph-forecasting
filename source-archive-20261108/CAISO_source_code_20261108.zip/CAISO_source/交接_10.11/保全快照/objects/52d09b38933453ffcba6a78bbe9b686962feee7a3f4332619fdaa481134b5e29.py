"""F-drive experiment gates. No changes to frozen sources or resource floors."""
from pathlib import Path
from contextlib import contextmanager
from datetime import datetime, timezone
import hashlib, json, os, sys, uuid

HERE = Path(__file__).resolve().parent
ROOT = HERE.parent
SOURCE = ROOT / 'source'
sys.path.insert(1, str(SOURCE))
import compile_gate as cg

MANIFEST = ROOT / 'phase_sampling_support_v3_20260923/dataset/ADDITIVE/manifest.json'
LOCK = Path('D:/Desktop/数据科学_论文/研究优化_20260818/logs/NEURAL_RUN.lock')
OLD_ROOT = Path('C:/Users/于阳/CAISO_feature_fusion_rev12/asof_retraining_branch_20260913')
SEAL = HERE / 'EXECUTION_SEAL.json'

def now(): return datetime.now(timezone.utc).isoformat()
def read(p): return json.loads(Path(p).read_text(encoding='utf-8-sig'))
def need(condition, message):
    if not condition: raise RuntimeError(message)
def sha(p): return cg.sha(p)
def atomic(p, writer):
    p = Path(p).resolve()
    need(p.is_relative_to(HERE), 'Write escaped new experiment')
    p.parent.mkdir(parents=True, exist_ok=True)
    temp = p.with_name('t_' + uuid.uuid4().hex + '.pending')
    with temp.open('xb') as f:
        writer(f); f.flush(); os.fsync(f.fileno())
    os.replace(temp, p)
def write(p, value):
    raw = json.dumps(value, ensure_ascii=False, indent=2, allow_nan=False).encode()
    atomic(p, lambda f: f.write(raw))
def boundary():
    for folder in (HERE, HERE/'queue', ROOT, OLD_ROOT):
        for name in ('STOP_REQUESTED', 'STOP_REQUESTED.json'):
            if (folder/name).exists(): raise InterruptedError('User stop ' + str(folder/name))
    for project in (ROOT.parent, OLD_ROOT.parent):
        p = project / 'RESEARCH_PAUSED.json'
        if p.exists():
            value = read(p)
            if value.get('stop_preparation_and_training'):
                raise InterruptedError('Research paused: ' + str(p))
def guard(launch=False):
    boundary(); values = cg.resources(); floor = 5 if launch else 4
    if min(values.values()) < floor:
        raise MemoryError(f'Existing {floor} GiB physical+commit floor: {values}')
    return values
@contextmanager
def exclusive(action):
    guard(True)
    import psutil
    owner = dict(pid=os.getpid(), created=psutil.Process().create_time(),
                 action=action, token=uuid.uuid4().hex)
    LOCK.parent.mkdir(parents=True, exist_ok=True)
    with LOCK.open('x', encoding='utf-8') as f:
        json.dump(owner, f); f.flush(); os.fsync(f.fileno())
    try:
        cg.bound_process(); guard(); yield
    finally:
        need(read(LOCK) == owner, 'Numerical lock owner changed')
        write(HERE/'lock_releases'/(owner['token']+'.json'), dict(owner=owner, at=now()))
        LOCK.unlink()
def runtime():
    cg.bound_process()
    import numpy as np
    import torch
    from threadpoolctl import threadpool_limits
    limiter = threadpool_limits(1)
    torch.set_num_threads(1); torch.set_num_interop_threads(1)
    torch.use_deterministic_algorithms(True)
    guard()
    return np, torch, limiter
def verify():
    boundary(); seal = read(SEAL)
    need(seal['status'] == 'sealed_development_only', 'Unsealed experiment')
    for path, digest in seal['bindings'].items():
        need(sha(path) == digest, 'Bound source/metadata changed: ' + path)
    return seal
def notify(kind, evidence):
    event_id = 'selection_alignment_' + kind + '_' + sha(evidence)
    value = dict(schema='caiso_research_event_v1', event_id=event_id, event=kind,
                 evidence_path=str(evidence), experiment_handoff=str(HERE/'PROTOCOL.json'),
                 complete_research_experiment=False, evaluation_scope='TRAIN_June_development_only')
    inbox = ROOT/'event_driven_automation/inbox'
    inbox.mkdir(parents=True, exist_ok=True)
    path = inbox/(event_id+'.json')
    if not path.exists():
        temp = inbox/('t_'+uuid.uuid4().hex+'.pending')
        temp.write_text(json.dumps(value, ensure_ascii=False, indent=2), encoding='utf-8')
        os.replace(temp, path)
    return event_id
