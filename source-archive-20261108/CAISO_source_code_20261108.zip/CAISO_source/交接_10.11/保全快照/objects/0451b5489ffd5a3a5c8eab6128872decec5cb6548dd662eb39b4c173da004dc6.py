"""Post-run attribution only. No fitting, threshold search, or forecast changes."""
from common import *

def main():
 global np
 with gate.exclusive('V15 fixed-output attribution, no fitting'):
  np,lim=initialize();verify();assert gate.read(HERE/'AUDIT.json')['status']=='passed'
  dm=gate.read(V14/'DATA.json');raw=np.load(dm['raw_prices'],mmap_mode='r');ts=np.load(dm['timestamps'],mmap_mode='r');th=gate.read(Path(dm['directory'])/'state_thresholds.json');c=np.array(th['center']);q=np.array(th['thresholds'])
  lib=readnp(A14/'EXPERT_ERROR_LIBRARY.npz');cal=readnp(ART/'calibration/predictions.npz');sel=cal['selected'];rows=[]
  for s in [3,4,5]:
   use=(lib['states'][sel]==s);y=lib['truth'][sel][use];models={}
   for name,pred in [('FULL',lib['FULL']),('SPIKE',lib['SPECIALIST']),('CALIBRATED',cal['prediction'])]:
    e=pred[sel][use]-y;models[name]=dict(bias=float(e.mean()),mae=float(abs(e).mean()),rmse=float(np.sqrt((e*e).mean())),overprediction_sse=float((e[e>0]**2).sum()),underprediction_sse=float((e[e<0]**2).sum()))
   rows.append(dict(state=s,models=models,raw_probability=lib['probabilities'][sel][use].mean(0).tolist(),calibrated_probability=cal['probability'][sel][use].mean(0).tolist()))
  pf=gate.read(HERE/'ONSET_MODEL_FREEZE.json');ev=readnp(ART/'onset/evaluation_probabilities.npz');labels=readnp(ART/'onset/evaluation_labels.npz');old=readnp(A14/'PREDICTIONS.npz')
  oo=ev['origin'];nn=ev['node'];index=np.searchsorted(old['origins'],oo);assert np.array_equal(old['origins'][index],oo)
  full=old['FULL'][index,nn];truth=np.asarray(raw[oo[:,None]+np.arange(12),nn[:,None],0],float);ext=abs(truth-c[nn,None])>q[1,nn,None]
  e=full-truth;totalS2=float((e[ext]**2).sum());onset=[]
  for name in ['SHORT90','RECURRENCE103']:
   alerted=ev[name]>pf['models'][name]['threshold'];flag=np.broadcast_to(alerted[:,None],e.shape);covered=float((e[ext&flag]**2).sum())/totalS2
   onset.append(dict(model=name,alerted_origin_node_pairs=int(alerted.sum()),s2_cells_covered=int((ext&flag).sum()),s2_total_cells=int(ext.sum()),s2_squared_error_covered_fraction=covered,
    unattainable_oracle_rmse_improvement_upper_pct=100*(1-np.sqrt(1-covered)),routine_and_intermediate_cells_exposed=int((flag&~ext).sum()),
    s2_overprediction_cells=int((flag&ext&(e>0)).sum()),s2_underprediction_cells=int((flag&ext&(e<0)).sum()),
    inference='Retrospective coverage upper bound only; assumes zero error on flagged true S2 and unchanged all other cells. No real correction or performance guarantee.'))
  result=dict(at=gate.now(),status='diagnosed_fixed_outputs',calibration_by_actual_state=rows,onset_fixed_threshold_coverage=onset,
   facts=['Multiclass calibration improves aggregate proper probability scores and overall RMSE but increases S3/S4 price RMSE; candidate closed by registered protections.',
    'Released-event recurrence adds onset ranking information on this historical panel; fixed conservative operating rule sacrifices recall. No price-error gain has yet been established.',
    'Predicting any spike within an hour does not identify its exact horizon, direction, amplitude or duration. Probability skill alone cannot justify adding a price correction.'],
   next_bounded_design='Retain originalV7. Do not tune another global probability scale. Before a point correction, train-only diagnose signed, horizon-specific residuals and onset label timing, and establish a new independent confirmation path. No additional fit authorized by this file.',
   untouched_components=['TCN','Transformer','dynamicGNN','parallelbranches','adaptivefeaturefusion','originalpredictionhead','originalV7results'],new_training_runs=0,main_model_replaced=False,
   result_bindings={str(HERE/f):gate.sha(HERE/f) for f in ['CALIBRATION_RESULT.json','ONSET_RESULT.json','AUDIT.json']})
  write(HERE/'ATTRIBUTION.json',result);charge();print(json.dumps(dict(calibration_by_actual_state=rows,onset_fixed_threshold_coverage=onset)))
if __name__=='__main__':main()
