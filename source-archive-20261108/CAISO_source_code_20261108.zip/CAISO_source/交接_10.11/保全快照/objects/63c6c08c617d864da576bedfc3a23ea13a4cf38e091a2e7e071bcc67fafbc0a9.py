from engine import *
import subprocess,traceback

def status(**d):write(HERE/'STATUS.json',dict(at=now(),pid=os.getpid(),**d))
def emit(event,path):
    eid='direct_gate_'+event+'_'+sha(path);p=B/'event_driven_automation/inbox'/(eid+'.json')
    if not p.exists():write(p,dict(schema='caiso_research_event_v1',event_id=eid,event=event,at=now(),evidence_path=str(path),evidence_sha256=sha(path)))
    return eid
def main():
    lock=HERE/'MANAGER.lock'
    with lock.open('x') as f:json.dump(dict(pid=os.getpid()),f)
    try:
        policy();checked(True)
        if (HERE/'AUDIT.json').exists():status(event='already_completed');return
        for script,proof in [('engine.py','RESULT.json'),('audit.py','AUDIT.json')]:
            if (HERE/proof).exists():continue
            with (HERE/'worker.log').open('a',encoding='utf-8') as log:
                child=subprocess.Popen([sys.executable,'-u',str(HERE/script)],cwd=HERE,stdout=log,stderr=subprocess.STDOUT)
                status(event='step_process_started',worker_pid=child.pid,step=script);code=child.wait()
            if code:checked();raise RuntimeError(script+' exit '+str(code)+'; no automatic retry')
        path=HERE/'AUDIT.json';eid=emit('needs_analysis',path)
        status(event='finite_sampling_queue_completed',event_id=eid,evidence_path=str(path),worker_pid=None)
    except InterruptedError as e:status(event='user_stop',classification='user_stop',error=str(e))
    except Exception as e:
        path=HERE/'FAILURE.json';write(path,dict(at=now(),error=repr(e),traceback=traceback.format_exc(),automatic_retry=False))
        eid=emit('blocking_failure',path);status(event='sampling_blocking_failure',event_id=eid,evidence_path=str(path),worker_pid=None)
    finally:
        if read(lock).get('pid')==os.getpid():lock.unlink()
if __name__=='__main__':main()
