"""Executable synthetic checks, separate formula and checkpoint/resume oracle."""
import copy, io, random, sys
import gate as g

def main():
    with g.exclusive('channel_attention_synthetic_QA'):
        np,torch,limiter=g.runtime()
        from models.factory import build_backbone
        import model as new
        import train
        train.np=np;train.torch=torch
        checks={};limits=np.ones((30,2))*10
        for seed in (20260813,20260814,20260815):
            scalar=build_backbone('FULL',seed,limits);channel=new.ChannelFusion(seed,limits)
            g.need(list(scalar.state_dict())==list(channel.state_dict()),'Parameter names differ')
            g.need(all(torch.equal(v,channel.state_dict()[k]) for k,v in scalar.state_dict().items()),'Initial tensors differ')
            counts=[sum(p.numel() for p in m.parameters() if p.requires_grad) for m in (scalar,channel)]
            g.need(counts==[50467,50467],'Parameter capacity mismatch')
        checks['all_three_seed_initial_tensors_and_50467_parameters_identical']=True
        scalar.eval();channel.eval();torch.manual_seed(111)
        x=torch.randn(1,288,30,29)*.1
        original=new.channel_weights
        def broadcast(attention,tcn,transformer,context):
            return attention(tcn,transformer,context).unsqueeze(-1).expand(-1,-1,-1,-1,32)
        try:
            new.channel_weights=broadcast
            with torch.no_grad():a=scalar(x);b=channel(x)
            for key in ('prediction','fused_features','dynamic_adjacency','head_features'):
                g.need(torch.equal(a[key],b[key]),'Unintended forward change: '+key)
            checks['scalar_broadcast_recovers_original_forward_exactly']=True
        finally:new.channel_weights=original
        with torch.no_grad():
            t=torch.randn(2,30,32);z=torch.randn_like(t);c=torch.randn_like(t)
            actual=original(channel.attention,t,z,c).numpy()
            at=channel.attention
            q=c.numpy()@at.query.weight.numpy().T
            q=q[:,:,None,:]+at.horizon_embedding.numpy()
            k=np.stack([t.numpy(),z.numpy()],axis=2)@at.key.weight.numpy().T
            logits=q[:,:,:,None,:]*k[:,:,None,:,:]+at.branch_bias.numpy()[None,None,None,:,None]
            ex=np.exp(logits-logits.max(axis=3,keepdims=True));expected=ex/ex.sum(axis=3,keepdims=True)
            g.need(np.max(np.abs(actual-expected))<3e-7,'NumPy channel oracle differs')
            g.need(np.max(np.abs(actual.sum(axis=3)-1))<2e-7,'Weights fail simplex')
            g.need(float(actual.std(axis=-1).mean())>1e-4,'Weights accidentally tied over channels')
            weights=original(at,t,t,c)
            fused=weights[...,0,:]*t.unsqueeze(2)+weights[...,1,:]*t.unsqueeze(2)
            g.need(torch.allclose(fused,t.unsqueeze(2).expand_as(fused),atol=5e-7),'Equal-branch identity')
        checks['numpy_formula_simplex_channel_variation_equal_branch_identity']=True
        # Direct interrupted/uninterrupted synthetic optimizer sequence.
        seed=20260813;channel=new.ChannelFusion(seed,limits);opt=train.optimizer(channel)
        torch.manual_seed(seed+200000);np.random.seed(seed);random.seed(seed);rng=np.random.default_rng(seed)
        channel.train();y=torch.zeros(1,30,12)
        train.update(channel,opt,x,y)
        snapshot=dict(model=copy.deepcopy(channel.state_dict()),optimizer=copy.deepcopy(opt.state_dict()),rng=train.rng_get(rng))
        buf=io.BytesIO();torch.save(snapshot,buf);buf.seek(0)
        loss1=train.update(channel,opt,x,y);expected_weights=copy.deepcopy(channel.state_dict());expected_rng=train.rng_get(rng)
        recovered=new.ChannelFusion(seed,limits);opt2=train.optimizer(recovered)
        loaded=torch.load(buf,weights_only=False)
        recovered.load_state_dict(loaded['model']);opt2.load_state_dict(loaded['optimizer']);train.rng_set(loaded['rng'],rng)
        recovered.train();loss2=train.update(recovered,opt2,x,y)
        g.need(loss1==loss2 and all(torch.equal(v,recovered.state_dict()[k]) for k,v in expected_weights.items()),'Resume updates differ')
        g.need(torch.equal(expected_rng['torch'],torch.get_rng_state()),'Resume RNG differs')
        checks['synthetic_optimizer_resume_bitwise_exact_and_gradients_finite']=True
        lrs=[train.rate(e) for e in range(1,13)]
        g.need(lrs[0]==.001 and all(v==.0001 for v in lrs[5:]),'Learning rate mismatch')
        checks['original_six_epoch_cosine_and_fixed_tail_retained']=True
        # Model has no target argument; future perturbation cannot enter its history tensor.
        history=x.clone();future=torch.randn(1,12,30,29);joined=torch.cat([history,future],dim=1)
        recovered.eval()
        with torch.no_grad():
            p1=recovered(joined[:,:288])['prediction']
            joined[:,288:]=99999
            p2=recovered(joined[:,:288])['prediction']
        g.need(torch.equal(p1,p2),'Future changes current history prediction')
        checks['synthetic_future_perturbation_invariance']=True
        sources={str(p):g.sha(p) for p in (g.HERE/'model.py',g.HERE/'train.py',g.HERE/'gate.py',g.HERE/'qa.py')}
        g.write(g.HERE/'QA.json',dict(status='passed',at=g.now(),checks=checks,sources=sources,
            real_training_started=False,scope='Synthetic formula/gradient/resume checks by separate implementation; no independent human reviewer claimed.'))
        print(__import__('json').dumps(dict(status='passed',checks=len(checks),trainable_parameters=50467)))
if __name__=='__main__':main()
