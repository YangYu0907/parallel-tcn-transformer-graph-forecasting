from pathlib import Path
import os,importlib.util,json,shutil,subprocess
from PIL import Image,ImageDraw
R=Path(__file__).resolve().parents[1]
SCRATCH=Path(r'C:\Users\于阳\CAISO_temporary_storage\manuscript_20261001_v7_superscript_render');SCRATCH.mkdir(parents=True,exist_ok=True)
DEP=Path(r'C:\Users\于阳\.cache\codex-runtimes\codex-primary-runtime\dependencies')
poppler=DEP/'native/poppler/Library/bin';os.environ['PATH']=str(poppler)+os.pathsep+os.environ.get('PATH','')
rp=Path(r'C:\Users\于阳\.codex\plugins\cache\openai-primary-runtime\documents\26.909.12148\skills\documents\render_docx.py')
spec=importlib.util.spec_from_file_location('skill_renderer',rp);renderer=importlib.util.module_from_spec(spec);spec.loader.exec_module(renderer)
orig=renderer.convert_from_path
def raster(*args,**kwargs):
 kwargs['thread_count']=1;kwargs['poppler_path']=str(poppler);return orig(*args,**kwargs)
renderer.convert_from_path=raster
def convert(doc_path,user_profile,convert_tmp_dir,stem,verbose=False):
 target=Path(convert_tmp_dir)/(stem+'.pdf')
 subprocess.run(['powershell.exe','-NoProfile','-File',str(R/'source/export_word.ps1'),'-InputDoc',str(Path(doc_path).resolve()),'-OutputPdf',str(target)],check=True,timeout=180)
 return str(target),'Isolated hidden Windows Word COM export; packaged render_docx.py raster pipeline.'
renderer.convert_to_pdf=convert
out={}
for name in ['Energy_manuscript']:
 folder=SCRATCH/name;folder.mkdir(exist_ok=True)
 pages=renderer.rasterize(str(R/(name+'.docx')),str(folder),144,False,True)
 shutil.copy2(folder/(name+'.pdf'),R/(name+'.pdf'))
 out[name]={'pages':len(pages),'png_paths':pages}
 for start in range(0,len(pages),4):
  sheet=Image.new('RGB',(1400,2020),'#dddddd')
  for i,p in enumerate(pages[start:start+4]):
   im=Image.open(p).convert('RGB');im.thumbnail((680,970));x=(i%2)*700;y=(i//2)*1010
   sheet.paste(im,(x+(700-im.width)//2,y+25));ImageDraw.Draw(sheet).text((x+10,y+5),f'{name} page{start+i+1}',fill='black')
  sheet.save(folder/f'contact_{start+1}.jpg',quality=85)
 print(name,len(pages),flush=True)
(R/'qa/superscript_render_execution.json').write_text(json.dumps({'renderer':str(rp),'pdf_export':'Hidden own Word COM process; originals read only','raster_threads':1,'documents':out},indent=2),encoding='utf-8')
