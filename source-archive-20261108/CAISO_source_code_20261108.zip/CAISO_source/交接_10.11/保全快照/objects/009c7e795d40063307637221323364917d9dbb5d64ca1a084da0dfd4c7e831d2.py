from support import *
import gc,math
import numpy as np,torch
from architecture import LocalHead,local_context
from entry import EventLibrary,cumulative_incidence

def onset_data():
 with np.load(R/'onset_data.npz') as z:return {k:z[k] for k in z.files}

def build_library(d):
 fit=d['role']==0;m=read(B/'phase_sampling_support_v3_20260923/dataset/ADDITIVE/manifest.json')
 raw=np.load(resolve(m['artifacts']['raw_prices.npy']['path']),mmap_mode='r')
 origin=d['origin'][fit];node=d['node'][fit]
 assert (origin+12<=210528).all()
 paths=np.array(raw[origin[:,None]+np.arange(12),node[:,None],0],dtype=np.float32);raw._mmap.close()
 return EventLibrary(d['CROSS'][fit],paths,np.where(d['first_hit'][fit]>0,d['first_hit'][fit]-1,12))

def risk_features(x,sc,neighbors):
 mm=module('routing_modelmath',B/'spike_transition_v12_20260930/modelmath.py')
 history=x[0,-72:,:,:4]*np.asarray(sc['price_scale'])+np.asarray(sc['price_center'])
 raw=mm.features(history,x[0,-1],sc)
 local=np.column_stack([raw[:,:75],np.eye(30,dtype='float32')])
 extra=raw[neighbors][:,:,[0,5,1,2]].reshape(30,20)
 return np.column_stack([local,extra]).astype('float32')

def benchmark(tick):
 if (N/'LATENCY.json').exists():return read(N/'LATENCY.json')
 from sklearn.ensemble import HistGradientBoostingClassifier
 from v7_runtime import FrozenV7
 import architecture,entry
 tick(stage='runtime_model_loading');start=time.perf_counter();v=FrozenV7();model_load=time.perf_counter()-start
 qa=dict(architecture=architecture.qa(v.full),entry=entry.qa(),frozen_V7_replay=v.replay())
 d=onset_data();lib=build_library(d);neighbors=d['neighbors'];del d;gc.collect()
 # Computational surrogate only: no market-fitting or candidate accuracy claim.
 rng=np.random.default_rng(7);z=rng.normal(size=(1024,126)).astype('float32');label=np.tile(np.arange(3),342)[:1024]
 surrogate=HistGradientBoostingClassifier(max_iter=80,max_leaf_nodes=7,min_samples_leaf=30,early_stopping=False,random_state=7).fit(z,label)
 head=LocalHead(20260813).eval()
 cache=np.load(c.T/'v7_confirmation_20260930/features.npy',mmap_mode='r');base=np.array(cache[0:1],copy=True);cache._mmap.close()
 routine=base.copy();routine[:,:,:,0]=0
 stress=base.copy();stress[:,-12:,:,0]=3*v.q[1][None,None,:]/v.scale[None,None,:]
 curves=np.tile(np.linspace(25000,27000,12)**1.00001,(30,1));targets=np.arange(12)*300+100000;publication=np.full((30,12),99000);vintage=np.ones((30,12),int)
 def call(fixture,force):
  xx=fixture.copy();out,ctx,observed=v.predict(xx,True)
  with torch.no_grad():local=head(ctx,observed).numpy()
  features=risk_features(xx,v.sc,neighbors)
  expanded=np.empty((360,126),np.float32);expanded[:,:125]=np.repeat(features,12,axis=0);expanded[:,125]=np.tile(np.arange(1,13)/12,30)
  hazard=surrogate.predict_proba(expanded).reshape(30,12,3);cif,_=cumulative_incidence(hazard)
  acceleration=entry.forecast_acceleration(curves,targets,publication,99999,vintage)
  retrieved=lib.query(features) if force else None
  assert out.shape==(1,30,12) and local.shape==out.shape and np.isfinite(acceleration).all()
  return out
 rows=[];raw={}
 for name,fixture,force in [('routine',routine,False),('all30_current_extreme_and_forced_new_alarm',stress,True)]:
  for _ in range(5):call(fixture,force)
  timings=[]
  for j in range(300):
   if j%10==0:tick(stage='latency',scenario=name,repeat=j,total=300)
   t=time.perf_counter_ns();call(fixture,force);timings.append((time.perf_counter_ns()-t)/1e6)
  raw[name]=np.asarray(timings)
  rows.append(dict(scenario=name,repeats=len(timings),median_ms=float(np.median(timings)),p95_ms=float(np.quantile(timings,.95)),p99_ms=float(np.quantile(timings,.99)),max_ms=float(max(timings)),observed_over_300000ms=sum(t>=300000 for t in timings)))
 save('latency_raw.npz',**raw);write('QA.json',dict(at=c.now(),status='passed',checks=qa))
 result=dict(at=c.now(),rows=rows,model_load_seconds=model_load,prototype=True,V7_replayed=True,
  scope='Resident actual FULL+DLinear+V7 functional/TAR/GB/hazard/amplitude models; snapshot copy, local head, causal feature extraction, exact all-history KNN included. Entry classifier and forward-curve fixture are synthetic cost surrogates, not source-qualified learned models.',
  limitations='Not final trained-system or worst-case guarantee. Incoming source/network/materialization and source freshness are not included; 300repeats give preliminary p99 only. Forced alarm on all30nodes stresses work even where entry and active-extreme branches would be mutually exclusive.',
  graph_skipping_enabled=False,knn_routine_skipped=True,source_admission_required=True)
 write('LATENCY.json',result);del v,lib,surrogate;gc.collect();return result

def metrics(p,y):
 e=np.asarray(p,float)-np.asarray(y,float)
 return dict(mae=float(abs(e).mean()),rmse=float(np.sqrt((e*e).mean())),near_mae=float(abs(e[:,:,:4]).mean()),h12_mae=float(abs(e[:,:,-1]).mean()))

def local_case(seed,tick):
 out=N/'local'/str(seed);out.mkdir(parents=True,exist_ok=True)
 if (out/'RESULT.json').exists():return read(out/'RESULT.json')
 from compiled_data import CompiledData
 data=CompiledData(B/'phase_sampling_support_v3_20260923/dataset/ADDITIVE/manifest.json');m=backbone('FULL',seed)
 for part in ['train','june_dense']:
  cp=out/(part+'.npz')
  if cp.exists():continue
  origins=data.origins[part];C=np.empty((len(origins),30,32),np.float32);O=np.empty((len(origins),30,2),np.float32);Y=np.empty((len(origins),30,12),np.float32)
  m.eval()
  with torch.no_grad():
   for j in range(0,len(origins),4):
    if j%64==0:tick(stage='local_context_cache',seed=seed,partition=part,done=j,total=len(origins))
    x,y=data.batch(part,np.arange(j,min(j+4,len(origins))));xx=torch.from_numpy(x);_,ctx=local_context(m,xx)
    C[j:j+4]=ctx.numpy();O[j:j+4]=m.observed_context(xx).numpy();Y[j:j+4]=y
  save(str(cp.relative_to(N)),context=C,observed=O,target=Y,origins=origins,scale=data.scale,center=data.center)
 del m;gc.collect()
 with np.load(out/'train.npz') as z:train={k:z[k] for k in z.files}
 with np.load(out/'june_dense.npz') as z:valid={k:z[k] for k in z.files}
 assert len(train['origins'])==4032
 head=LocalHead(seed);opt=torch.optim.AdamW(head.parameters(),lr=.001,weight_decay=.0001);rng=np.random.default_rng(seed)
 cp=out/'latest.pt';records=[];start_epoch=1;best=float('inf');best_epoch=None
 if cp.exists():
  obj=torch.load(cp,map_location='cpu',weights_only=False);head.load_state_dict(obj['model']);opt.load_state_dict(obj['optimizer']);rng.bit_generator.state=obj['rng'];records=obj['records'];start_epoch=obj['epoch']+1;best=obj['best'];best_epoch=obj['best_epoch']
 select=np.searchsorted(valid['origins'],data.origins['june']);assert np.array_equal(valid['origins'][select],data.origins['june'])
 tr=[torch.from_numpy(train[k]) for k in ['context','observed','target']];va=[torch.from_numpy(valid[k]) for k in ['context','observed']]
 for epoch in range(start_epoch,13):
  head.train();order=rng.permutation(len(train['origins']))
  for j in range(0,len(order),128):
   tick(stage='local_head_training',seed=seed,epoch=epoch,batch=j//128);ix=order[j:j+128]
   opt.zero_grad(set_to_none=True);loss=torch.nn.functional.huber_loss(head(tr[0][ix],tr[1][ix]),tr[2][ix],delta=.5);assert torch.isfinite(loss);loss.backward();torch.nn.utils.clip_grad_norm_(head.parameters(),1.);opt.step()
  head.eval()
  with torch.no_grad():pred=head(*[a[select] for a in va]).numpy()
  mae=float(np.mean(abs(pred-valid['target'][select])*data.scale[None,:,None]))
  if mae<best-1e-6:
   best=mae;best_epoch=epoch;torch.save(head.state_dict(),out/'best.pt')
  records.append(dict(epoch=epoch,June284_MAE=mae))
  tmp=cp.with_suffix('.tmp');torch.save(dict(model=head.state_dict(),optimizer=opt.state_dict(),rng=rng.bit_generator.state,epoch=epoch,records=records,best=best,best_epoch=best_epoch),tmp);os.replace(tmp,cp)
 head.load_state_dict(torch.load(out/'best.pt',map_location='cpu',weights_only=True));head.eval()
 with torch.no_grad():p=head(*va).numpy().astype(float)*data.scale[None,:,None]+data.center[None,:,None]
 y=valid['target'].astype(float)*data.scale[None,:,None]+data.center[None,:,None]
 f=read(B/'h1_final_evaluation_v1_20260927/FINAL_TEST_FREEZE.json');case=next(ca for ca in f['cases'] if ca.get('seed')==seed and ca.get('variant')=='SELF')
 reference=resolve(case['reference']);assert c.sha(reference)==case['reference_sha256']
 with np.load(reference) as z:
  ix=np.searchsorted(z['origins'],valid['origins']);assert np.array_equal(z['origins'][ix],valid['origins']);selfp=z['prediction'][ix]
 save(str((out/'predictions.npz').relative_to(N)),origins=valid['origins'],prediction=p,truth=y,SELF=selfp)
 row=dict(seed=seed,selected_epoch=best_epoch,records=records,local=metrics(p,y),SELF=metrics(selfp,y),scope='KnownJune3397development; selection onJune284; no claim of independent confirmation',new_backbone_updates=0)
 write(str((out/'RESULT.json').relative_to(N)),row);return row

def local_stage(tick):
 rows=[local_case(seed,tick) for seed in SEEDS]
 mean={a:{k:float(np.mean([r[a][k] for r in rows])) for k in rows[0][a]} for a in ['local','SELF']}
 passed=all(mean['local'][k]<=mean['SELF'][k] for k in mean['local']) and sum(r['local']['mae']<=r['SELF']['mae'] for r in rows)>=2
 result=dict(at=c.now(),rows=rows,mean=mean,screen_passed=passed,graph_skipping_enabled=False,V7_replaced=False)
 write('LOCAL_RESULT.json',result);return result

def expanded(X,pair,h):
 out=np.empty((len(pair),X.shape[1]+1),np.float32)
 for j in range(0,len(pair),4096):out[j:j+4096,:-1]=X[pair[j:j+4096]]
 out[:,-1]=(h+1)/12;return out

def entry_stage(tick):
 if (N/'ENTRY_RESULT.json').exists():return read(N/'ENTRY_RESULT.json')
 from sklearn.ensemble import HistGradientBoostingClassifier
 from scipy.special import softmax
 from scipy.optimize import minimize_scalar
 from sklearn.metrics import average_precision_score
 d=onset_data();fit=d['role']==0;cal=d['role']==1;ev=d['role']==2
 tau=np.where(d['first_hit']>0,d['first_hit']-1,12);kind=d['y'][:,-1].astype(int);hh=np.arange(12)[None];risk=hh<=tau[:,None]
 events=np.where(hh==tau[:,None],kind[:,None],0);outputs={};rows=[];support=[]
 for arm in ['LOCAL_HAZARD','CROSS_HAZARD','CROSS_ENDPOINT']:
  tick(stage='entry_prepare',arm=arm);X=d['LOCAL'] if arm.startswith('LOCAL') else d['CROSS'];hazard=arm.endswith('HAZARD');mask=fit[:,None]&(risk if hazard else np.ones_like(risk))
  pair,h=np.nonzero(mask);labels=events[pair,h] if hazard else np.where(tau[pair]<=h,kind[pair],0)
  assert set(np.unique(labels))=={0,1,2}
  xf=expanded(X,pair,h);path=N/'entry_models'/f'{arm}.pkl'
  model=load(path) if path.exists() else HistGradientBoostingClassifier(max_iter=20,max_leaf_nodes=7,min_samples_leaf=100,learning_rate=.05,l2_regularization=1,early_stopping=False,warm_start=True,random_state=20260813)
  for it in [20,40,60,80]:
   if getattr(model,'n_iter_',0)>=it:continue
   tick(stage='entry_training',arm=arm,iteration=it,rows=len(xf));model.set_params(max_iter=it);model.fit(xf,labels);dump(path,model)
  del xf,pair,h,labels;gc.collect()
  predictions=[]
  for subset in [cal,ev]:
   ids=np.flatnonzero(subset);pp=np.empty((len(ids),12,3))
   for j in range(0,len(ids),2048):
    tick(stage='entry_predict',arm=arm,done=j,total=len(ids));ii=ids[j:j+2048];pp[j:j+len(ii)]=model.predict_proba(expanded(X,np.repeat(ii,12),np.tile(np.arange(12),len(ii)))).reshape(-1,12,3)
   predictions.append(pp)
  pc,pe=predictions;cm=risk[cal] if hazard else np.ones_like(risk[cal]);yc=events[cal] if hazard else np.where(hh>=tau[cal,None],kind[cal,None],0)
  logits=np.log(np.maximum(pc[cm],1e-12));cy=yc[cm]
  def obj(t):
   p=softmax(logits/t,axis=-1);return float(-np.log(np.maximum(p[np.arange(len(cy)),cy],1e-12)).mean())
  temp=float(minimize_scalar(obj,bounds=(.5,2),method='bounded').x)
  pc=softmax(np.log(np.maximum(pc,1e-12))/temp,axis=-1);pe=softmax(np.log(np.maximum(pe,1e-12))/temp,axis=-1)
  cp=cumulative_incidence(pc)[0] if hazard else pc[:,:,1:];ep=cumulative_incidence(pe)[0] if hazard else pe[:,:,1:]
  dump(N/'entry_models'/f'{arm}_calibration.pkl',dict(temperature=temp,kind='hazard' if hazard else 'cumulative_endpoint'))
  outputs[arm]=ep
  for h in [1,4,12]:
   for side in [1,2]:
    truth=(tau[ev]<h)&(kind[ev]==side);ct=(tau[cal]<h)&(kind[cal]==side);prob=ep[:,h-1,side-1];cprob=cp[:,h-1,side-1]
    threshold=float(np.quantile(cprob[~ct],.99,method='higher'));alarm=prob>threshold;tp=int((alarm&truth).sum());fp=int((alarm&~truth).sum());p=np.clip(prob,1e-12,1-1e-12)
    rows.append(dict(arm=arm,horizon=h,side=side,temperature=temp,threshold=threshold,pairs=len(truth),events=int(truth.sum()),event_dates=len(np.unique(d['days'][ev][truth])),alerts=int(alarm.sum()),TP=tp,FP=fp,precision=tp/(tp+fp) if tp+fp else None,recall=tp/int(truth.sum()) if truth.any() else None,FPR=float(alarm[~truth].mean()),AP=float(average_precision_score(truth,prob)) if truth.any() else None,brier=float(((prob-truth)**2).mean()),logloss=float(-(truth*np.log(p)+(~truth)*np.log1p(-p)).mean())))
  del model,X,pc,pe;gc.collect()
 save('entry_predictions.npz',**outputs,origin=d['origin'][ev],node=d['node'][ev],days=d['days'][ev],tau=tau[ev],kind=kind[ev])
 selected={a:[r for r in rows if r['arm']==a and r['horizon']==12] for a in outputs}
 mean={a:{k:float(np.mean([r[k] for r in rr])) for k in ['brier','logloss','recall','FPR']} for a,rr in selected.items()}
 candidate=mean['CROSS_HAZARD'];passed=all(candidate[k]<mean[a][k] for a in ['LOCAL_HAZARD','CROSS_ENDPOINT'] for k in ['brier','logloss'])
 passed=passed and all(r['event_dates']>=5 and r['FPR']<=.02 for r in selected['CROSS_HAZARD']) and candidate['recall']>=mean['CROSS_ENDPOINT']['recall']
 passed=passed and all(selected['CROSS_HAZARD'][s]['brier']<=selected[a][s]['brier'] for a in ['LOCAL_HAZARD','CROSS_ENDPOINT'] for s in range(2))
 result=dict(at=c.now(),rows=rows,H12_mean=mean,screen_passed=bool(passed),new_point_predictions=False,forward_forecast_acceleration_used=False,scope='Previously inspected TRAIN chronological diagnostic; inherited event thresholds; not independent confirmation or onset-price improvement')
 write('ENTRY_RESULT.json',result);return result
