"""Operational record only; never imports a numerical runtime or changes models."""
from pathlib import Path
import json,os,uuid,datetime,hashlib
N=Path(__file__).resolve().parent;B=N.parents[1]
def read(p):return json.loads(Path(p).read_text(encoding='utf-8-sig'))
def sha(p):return hashlib.sha256(Path(p).read_bytes()).hexdigest()
def write(p,d):
 q=p.with_suffix('.'+uuid.uuid4().hex+'.tmp');q.write_text(json.dumps(d,ensure_ascii=False,indent=2),encoding='utf-8');os.replace(q,p)
def main():
 now=datetime.datetime.now(datetime.timezone.utc).isoformat();path=B/'HANDOFF.json';h=read(path)
 before=N/'HANDOFF_before_routing.json'
 if not before.exists():before.write_bytes(path.read_bytes())
 launch=read(N/'LAUNCH.json');status=read(N/'STATUS.json');progress=read(N/'PROGRESS.json') if (N/'PROGRESS.json').exists() else {}
 row=dict(at=now,directory=str(N),protocol=str(N/'PROTOCOL.json'),protocol_sha256=sha(N/'PROTOCOL.json'),
  launch=launch,status_path=str(N/'STATUS.json'),progress_path=str(N/'PROGRESS.json'),observed_status=status,observed_progress=progress,
  stage='Registered prototype latency,three independently supervised localheads,three matched first-entry models',
  source_scope='Same-vintage forward-curve proof not admitted; historical-only risk diagnostic. No augmented-source final comparison released.',
  limits='Two-hour development budget;single numericworker;5GiBlaunch4GiBruntime; no periodic wakeups',
  V7_replaced=False,new_test_targets_read=False,complete_research_experiment=False,
  next='Review separate saved-output audit and gates. Do not start joint fitting from in-sample errors or enable graph skipping without matched evidence. Sixteen existing methods include V7variants and controls; not16externalbaselines.')
 h['routing_entry_v1_20261004']=row;h['current_authorized_work']='Execute user-approved graph-bypass and first-entry feasibility checks; frozenV7 retained; no manuscript edits or new test access.'
 h['last_updated_at']=now;h['periodic_model_wakeups']=False
 write(path,h);write(N/'OPERATIONAL_HANDOFF.json',row);print(json.dumps(dict(updated=True,stage=progress.get('stage'),pid=launch['manager_pid'])))
if __name__=='__main__':main()
