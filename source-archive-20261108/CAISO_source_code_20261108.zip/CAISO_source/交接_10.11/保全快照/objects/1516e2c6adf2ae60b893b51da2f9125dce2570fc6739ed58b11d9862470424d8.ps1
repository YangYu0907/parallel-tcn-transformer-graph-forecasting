$ErrorActionPreference='Stop'
$branch='C:\Users\于阳\CAISO_feature_fusion_rev12\asof_retraining_branch_20260913'
$variant=Join-Path $branch 'phase_sampling_additive_v2_20260920'
$eventDir=Join-Path $branch 'event_driven_automation'
$python='D:\Documents\conda_envs\tcn_air\python.exe'
$mechanismEvent='user_authorized_restart_after_verified_dead_owners_20260923'
$samplingEvent='sampling_blocking_failure_c17a2cc2c20d7b5fa1a40132078fb0a8b307f1224b04584abc22cac17d0c3147'
$managerPath=Join-Path $branch 'mechanism_controls_20260920\manager.py'
$samplingPath=Join-Path $variant 'source\manager.py'
function Get-Sha256([string]$Path) {
 $algorithm=[Security.Cryptography.SHA256]::Create(); $stream=[IO.File]::OpenRead($Path)
 try { return [BitConverter]::ToString($algorithm.ComputeHash($stream)).Replace('-','').ToLowerInvariant() }
 finally { $stream.Dispose(); $algorithm.Dispose() }
}
$bridgePath=Join-Path $eventDir 'watch_manager_exit.ps1'
$samplingBridge=Join-Path $variant 'watch_manager_exit.ps1'
if ((Get-Sha256 $bridgePath) -ne '8def7cbe255470e609358d1e9a6cdc7521711e9004b806b5adc5f231afaaa9be' -or (Get-Sha256 $samplingBridge) -ne 'cb5f07c0116e76f4ef40747572c6e47e790b1c1b0d35b628dd18d527f7a37155') { throw 'Reviewed exit bridge changed' }
$all=@(Get-CimInstance Win32_Process)
$training=@($all | Where-Object {$_.Name -eq 'python.exe' -and $_.CommandLine -and ($_.CommandLine.Contains($managerPath) -or $_.CommandLine.Contains($samplingPath) -or $_.CommandLine.Contains((Join-Path $branch 'source\control_backbone_train.py')))})
if($training.Count -ne 0) { throw 'Related manager/trainer still alive; refusing duplicate' }
$watchState=Get-Content -LiteralPath (Join-Path $eventDir 'status.json') -Raw -Encoding UTF8 | ConvertFrom-Json
if(@($all | Where-Object {$_.ProcessId -eq $watchState.pid -and $_.CommandLine -and $_.CommandLine.Contains((Join-Path $eventDir 'watch.ps1'))}).Count -ne 1) { throw 'Shared event listener absent' }
foreach($queueLock in @((Join-Path $branch 'mechanism_controls_20260920\queue\QUEUE.lock'),(Join-Path $variant 'queue\QUEUE.lock'))) { if(Test-Path -LiteralPath $queueLock) { throw 'Queue ownership not released' } }
& $python (Join-Path $PSScriptRoot 'recovery_gate.py')
if($LASTEXITCODE -ne 0) { throw 'Recovery metadata/resources admission blocked' }
$tag=[guid]::NewGuid().ToString('N').Substring(0,12)
$launch=Join-Path $PSScriptRoot ('launch_'+$tag)
New-Item -ItemType Directory -Path $launch | Out-Null
function Attach-ExitBridge($Process,[string]$Script,[string]$Bridge,[string]$Status,[string]$Label) {
 $ticks=$Process.StartTime.ToUniversalTime().Ticks
 $arguments=@('-NoProfile','-ExecutionPolicy','Bypass','-File',('"'+$Bridge+'"'),'-ManagerProcessId',[string]$Process.Id,'-ManagerStartUtcTicks',[string]$ticks,'-ManagerScript',('"'+$Script+'"'),'-StatusPath',('"'+$Status+'"'))
 $monitor=Start-Process -FilePath 'C:\Windows\System32\WindowsPowerShell\v1.0\powershell.exe' -ArgumentList $arguments -WorkingDirectory $branch -WindowStyle Hidden -RedirectStandardOutput (Join-Path $launch ($Label+'.stdout.log')) -RedirectStandardError (Join-Path $launch ($Label+'.stderr.log')) -PassThru
 return [ordered]@{manager_pid=$Process.Id;manager_start_utc_ticks=$ticks;bridge_pid=$monitor.Id;bridge_script=$Bridge;status_path=$Status}
}
$manager=Start-Process -FilePath $python -ArgumentList @(('"'+$managerPath+'"'),'run') -WorkingDirectory $branch -WindowStyle Hidden -RedirectStandardOutput (Join-Path $launch 'mechanism.stdout.log') -RedirectStandardError (Join-Path $launch 'mechanism.stderr.log') -PassThru
$mechanismMonitor=Attach-ExitBridge $manager $managerPath $bridgePath (Join-Path $branch 'mechanism_controls_20260920\queue\status.json') 'mechanism_bridge'
$created=(([DateTimeOffset]$manager.StartTime.ToUniversalTime()).ToUnixTimeMilliseconds()/1000.0).ToString('F3',[Globalization.CultureInfo]::InvariantCulture)
$sampler=Start-Process -FilePath $python -ArgumentList @(('"'+$samplingPath+'"'),'run','--wait-for-pid',[string]$manager.Id,'--created',$created,'--resume-after-event',$samplingEvent) -WorkingDirectory $branch -WindowStyle Hidden -RedirectStandardOutput (Join-Path $launch 'sampling.stdout.log') -RedirectStandardError (Join-Path $launch 'sampling.stderr.log') -PassThru
$samplingMonitor=Attach-ExitBridge $sampler $samplingPath $samplingBridge (Join-Path $variant 'queue\status.json') 'sampling_bridge'
$record=[ordered]@{status='one_interruption_resume_and_sampling_rearm_launched';at=[DateTime]::UtcNow.ToString('o');mechanism=$mechanismMonitor;sampling=$samplingMonitor;listener_pid=$watchState.pid;resource_event=$mechanismEvent;dependent_event=$samplingEvent;directory=$launch;existing_sources_changed=$false;periodic_model_wakeup=$false;prior_checkpoint_updates=2752}
$record | ConvertTo-Json -Depth 8 | Set-Content -LiteralPath (Join-Path $launch 'launch.json') -Encoding UTF8
$record | ConvertTo-Json -Depth 8
