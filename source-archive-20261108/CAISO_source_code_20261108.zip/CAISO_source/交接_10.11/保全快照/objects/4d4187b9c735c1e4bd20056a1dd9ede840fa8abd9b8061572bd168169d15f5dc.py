import gcommon as c


def main():
    c.verify()
    with c.gate.exclusive('V21-G separate validation scoring and checkpoint replay'):
        np,torch,lim=c.gate.runtime(True)
        from model import attach
        em=c.euro_module();r=c.read(c.HERE/'RESULT.json');checks=0
        with np.load(c.ENERGY/'data/train_valid.npz',allow_pickle=False) as z:
            prices=z['prices'];raw=z['raw'];ids=z['valid'];std=z['std'];mean=z['mean']
        truth=np.stack([raw[o:o+24] for o in ids]);summary={}
        for row in r['rows']:
            c.check();case=row['case'];assert c.sha(row['prediction'])==row['prediction_sha256'];assert c.sha(row['checkpoint'])==row['checkpoint_sha256'];checks+=2
            with np.load(row['prediction'],allow_pickle=False) as z:pred=z['prediction'];origins=z['origins']
            assert np.array_equal(origins,ids);checks+=1
            err=pred-truth;m=dict(mae=float(abs(err).sum()/err.size),rmse=float((np.square(err).sum()/err.size)**.5))
            for k,v in m.items():assert abs(v-row['metrics'][k])<1e-10;checks+=1
            assert np.allclose(np.abs(err).mean((0,1)),row['metrics']['market_mae']);assert np.allclose(np.abs(err).mean((0,2)),row['metrics']['horizon_mae']);checks+=2
            model=em.build(case['mode'],case['seed']);model.load_state_dict(torch.load(row['checkpoint'],map_location='cpu',weights_only=False)['model'])
            if case['sparse']:attach(model)
            model.eval();sample=np.array([0,60,181,300,364])
            with torch.no_grad():replay=model(torch.from_numpy(np.stack([prices[ids[i]-168:ids[i]] for i in sample]))).numpy()*std+mean
            assert np.allclose(replay,pred[sample],rtol=1e-5,atol=1e-5);checks+=1
            expected=min(row['history'],key=lambda x:(round(x['mae'],6),x['epoch']))['epoch']
            # Actual selection uses strict1e-6 improvement; reproduce that rule.
            selected=row['history'][0]
            for q in row['history'][1:]:
                if q['mae']<selected['mae']-1e-6:selected=q
            assert row['selected_epoch']==selected['epoch'];checks+=1
            summary.setdefault(case['arm'],[]).append(row['metrics'])
        aggregate={arm:dict(mae=float(np.mean([x['mae'] for x in v])),rmse=float(np.mean([x['rmse'] for x in v])),h24_mae=float(np.mean([x['horizon_mae'][-1] for x in v]))) for arm,v in summary.items()}
        old=[c.read(c.ENERGY/'runs'/f'FULL_{s}_0.001/result.json') for s in (20260813,20260814,20260815)]
        aggregate['ORIGINAL_FULL']=dict(mae=float(np.mean([x['validation_mae'] for x in old])),rmse=float(np.mean([x['validation_rmse'] for x in old])),h24_mae=float(np.mean([x['validation_mae_by_horizon'][-1] for x in old])))
        full=aggregate['FULL_SPARSE'];comparison={arm:100*(v['mae']-full['mae'])/v['mae'] for arm,v in aggregate.items() if arm!='FULL_SPARSE'}
        wins=sum(summary['FULL_SPARSE'][i]['mae']<summary['FULL_CONT'][i]['mae'] for i in range(3))
        passed=all(v>0 for v in comparison.values()) and full['rmse']<=aggregate['ORIGINAL_FULL']['rmse'] and full['h24_mae']<=aggregate['ORIGINAL_FULL']['h24_mae'] and wins>=2
        decision=dict(at=c.now(),status='development_candidate_supported_pending_confirmation' if passed else 'candidate_not_promoted',passed=passed,aggregate=aggregate,mae_reduction_percent=comparison,seed_wins=wins,scope='2015Europevalidation only; no independent confirmation claim',V7_preserved=True,new_test_targets_read=False,model_promoted=False,complete_research_experiment=False)
        c.write(c.HERE/'DECISION.json',decision);c.verify()
        c.write(c.HERE/'AUDIT.json',dict(at=c.now(),status='passed',checks=checks,result_sha256=c.sha(c.HERE/'RESULT.json'),decision_sha256=c.sha(c.HERE/'DECISION.json'),scope='Separate scorer/replay process; same operator, not external-person review',V7_preserved=True,new_test_targets_read=False))
        print(decision,flush=True)

if __name__=='__main__':main()
