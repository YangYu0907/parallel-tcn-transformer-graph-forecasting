"""Final prediction adapter checked on previously evaluated June data only."""
import csv,json,sys,time
from pathlib import Path
from runtime_gate import HERE,c
from predictor import FrozenPredictor,cases

def main():
    with c.exclusive('Final H1 runtime June-only QA; no H1 predictions'):
        np,torch,limiter=c.runtime(torch_needed=True)
        p=c.read(c.BRANCH/'h1_source_inputs_v1_20260927/INPUT_AUDIT_FREEZE.json')
        s=c.read(c.HERE/'admission/JUNE_INPUT_REPLAY_SEAL.json')
        sys.path.insert(0,str(c.HERE/'admission'));from bounded_history import JuneArchiveReader
        times=np.load(s['paths']['timestamps_seconds.npy'],allow_pickle=False)
        publications=np.load(s['paths']['forecast_publications_seconds.npy'],allow_pickle=False)
        all_origins=np.load(s['paths']['june_origins.npy'],allow_pickle=False)
        ii=np.array([0,1,128,1000,1698,2000,3395,3396]);origins=all_origins[ii]
        scalers=c.read(s['paths']['scalers.json'])
        with Path(s['config']['node_panel']).open(encoding='utf-8-sig',newline='') as h:tac=[r['TAC_AREA_ID'] for r in csv.DictReader(h)]
        reader=JuneArchiveReader(s['config'],origins,s['archive_hashes'])
        try:x=np.stack([reader.history(int(o),publications[o-288:o],times[o-288:o],scalers,tac,s['caps']) for o in origins])
        finally:reader.close()
        base=c.BRANCH/'caiso_baselines_v2_20260927';records=[]
        for case in cases(p):
            c.guard();predictor=FrozenPredictor(case,p);start=time.monotonic()
            prediction=np.concatenate([predictor.predict(x[a:a+4]) for a in (0,4)])
            elapsed=time.monotonic()-start;predictor.verify_unchanged()
            ref=Path(case['reference']) if 'reference' in case else (base/'lear/june_dense_outputs.npz' if case['variant']=='LASSO_ARX_H' else base/'naive'/case['variant']/'june_dense_outputs.npz')
            with np.load(ref,allow_pickle=False) as z:
                c.need(np.array_equal(z['origins'][ii],origins),'QA reference origins');expected=z['prediction'][ii]
            delta=abs(prediction-expected);tol=1e-4+1e-6*abs(expected)
            c.need(np.all(delta<=tol),'Final prediction adapter differs from frozen June reference: '+case['id'])
            records.append(dict(id=case['id'],max_absolute=float(delta.max()),max_tolerance_fraction=float((delta/tol).max()),prediction_seconds=elapsed,
                trainable_parameters=sum(t.numel() for t in predictor.model.parameters()) if predictor.model is not None else None))
            del predictor
        sys.path.insert(0,str(c.HERE/'evaluation'));from paired_statistics import synthetic_checks
        statistics=synthetic_checks()
        # Exercise release gates while no release record exists, before any target reader.
        from runtime_gate import verify_release
        try:verify_release()
        except RuntimeError:release_denied=True
        else:raise AssertionError('Runtime QA unexpectedly has H1 release')
        from score import ScoreContract
        target=ScoreContract(272160,{272160})
        c.need(target.allows(272160,272172,'score_target') and not target.allows(272159,272172,'score_target') and not target.allows(272160,272173,'score_target'),'Scoring target bounds')
        bindings={str(q):c.sha(q) for q in HERE.glob('*.py')}
        c.write(HERE/'RUNTIME_QA.json',dict(status='passed',at=c.now(),sources=bindings,June_origins=origins.tolist(),cases=records,
            statistics=statistics,release_without_signature_denied=release_denied,score_target_bounds_verified=True,
            comparison_scope='Eight fixed June origins for the final shared predictor; supplemented by full3397-origin thirty-case replay',
            H1_predictions_computed=False,H1_scores_computed=False,fit_calls=0,gradient_steps=0))
        print('All33 final prediction adapters passed June QA; missing H1 release correctly denied')

if __name__=='__main__':main()
