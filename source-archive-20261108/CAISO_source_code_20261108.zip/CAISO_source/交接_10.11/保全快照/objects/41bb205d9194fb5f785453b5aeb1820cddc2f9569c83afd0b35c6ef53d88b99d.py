"""Disposable real-parent identity, formula, gradient and serialized-resume checks."""
import copy,io,json,gc,sys
import gate
def main():
 with gate.exclusive('branch_values_QA'):
  np,torch,lim=gate.runtime()
  from compiled_data import CompiledData
  from models.factory import build_backbone
  from adapter import ValueFusion
  from math_ops import step
  import train
  train.np=np;train.torch=torch
  from torch.nn import functional as F
  parentseal=gate.read(gate.PARENT/'EXECUTION_LOCK.json')
  for p,h in parentseal['bindings'].items():gate.need(gate.sha(gate.inside(p))==h,'Inherited binding changed')
  data=CompiledData(parentseal['dataset_manifest']);limits=gate.read(data.paths['context_limits.json'])['limits']
  all_origins=np.unique(np.concatenate([np.load(data.paths[f'epoch{i}_origins.npy'],allow_pickle=False) for i in range(1,7)]))
  gate.need(len(all_origins)==17102,'All-six-phase TRAIN support changed')
  rows=[];shuffle={}
  for c in gate.prepared_cases():
   gate.guard();p=gate.inside(c['parent']['selected_checkpoint']);saved=torch.load(p,map_location='cpu',weights_only=False)
   gate.need(saved['identity']==c['parent']['identity'] and saved['scope']==c['parent']['scope'],'Parent identity/scope')
   base=build_backbone(c['variant'],c['seed'],limits);base.load_state_dict(saved['state_dict'],strict=True);base.eval()
   student=ValueFusion(base,c['seed'],c['variant']);basefp=train.fp(student.base)
   gate.need(sum(x.numel() for x in student.parameters() if x.requires_grad)==2112,'Parameter budget')
   ref=c['parent']['dense_evaluation'];gate.need(gate.sha(gate.inside(ref['path']))==ref['sha256'],'Parent predictions changed')
   with np.load(gate.inside(ref['path']),allow_pickle=False) as zz:
    expected=zz['prediction'];origins=zz['origins']
   registered=np.searchsorted(origins,data.origins['june']);other=np.flatnonzero(origins%12!=0)[:12]
   probes=np.r_[registered[:24],other];diff=0.
   with torch.no_grad():
    for k in range(0,len(probes),4):
     ids=probes[k:k+4];x,y=data.batch('june_dense',ids,with_target=False);gate.need(y is None,'QA target restriction')
     pred=student(torch.from_numpy(x))['prediction'].numpy().astype(np.float64)*data.scale[None,:,None]+data.center[None,:,None]
     diff=max(diff,float(np.max(abs(pred-expected[ids]))))
   gate.need(diff==0,'Identity initialization differs from parent')
   # Fresh data/optimizer; no parent weights are written. Serialized continuation uses identical RNG/Adam states.
   data.set_epoch(1);rng=np.random.default_rng(c['seed']+920000);order=rng.permutation(4032)
   h=__import__('hashlib').sha256(order.tobytes()).hexdigest()
   if c['seed'] in shuffle:gate.need(h==shuffle[c['seed']],'Acrosscontrol shuffle mismatch')
   shuffle[c['seed']]=h
   x,y=data.batch('train',order[:4]);x=torch.from_numpy(x);y=torch.from_numpy(y);hourly=torch.zeros(4,dtype=torch.bool)
   opt=train.opt_for(student);step(student,opt,x,y,hourly)
   gate.need(train.fp(student.base)==basefp and all(p.grad is None for p in student.base.parameters()),'Frozen core changed')
   buffer=io.BytesIO();torch.save(dict(weights=student.state_dict(),optimizer=opt.state_dict(),rng=train.rng_get(rng)),buffer);buffer.seek(0)
   saved2=torch.load(buffer,weights_only=False);peer=copy.deepcopy(student);peer.load_state_dict(saved2['weights']);po=train.opt_for(peer);po.load_state_dict(copy.deepcopy(saved2['optimizer']))
   state=saved2['rng']
   train.rng_set(state,np.random.default_rng());step(student,opt,x,y,hourly)
   train.rng_set(state,np.random.default_rng());step(peer,po,x,y,hourly)
   gate.need(train.fp(student)==train.fp(peer),'Resume altered predictions/weights')
   for k,v in opt.state_dict()['state'].items():
    for n,t in v.items():gate.need(torch.equal(t,po.state_dict()['state'][k][n]),'Resume altered Adam')
   gate.need(train.fp(student.base)==basefp,'Parent modified by QA')
   # Distinct original forward + captured branch values, functional projection expression after nonzero updates.
   captured={};handle=base.tcn.register_forward_hook(lambda m,i,o:captured.update(t=o.detach()))
   with torch.no_grad():
    out=base(x);handle.remove();t=captured['t'];z=out['transformer_features'];w=out['branch_weights']
    a=student.adapter
    vt=t+F.linear(t,a.tcn.weight,a.tcn.bias);vz=z+F.linear(z,a.transformer.weight,a.transformer.bias)
    if c['variant']=='CONCAT':
     layer=base.concat_projection[0];fused=F.gelu(F.linear(torch.cat((vt,vz),-1),layer.weight,layer.bias)).unsqueeze(2).expand(-1,-1,12,-1)
    elif c['variant']=='EQUAL':fused=(.5*vt.unsqueeze(2)+.5*vz.unsqueeze(2)).expand(-1,-1,12,-1)
    else:fused=w[...,:1]*vt.unsqueeze(2)+w[...,1:]*vz.unsqueeze(2)
    explicit=base.head(fused+base.price_context(base.observed_context(x)).unsqueeze(2))
    modelpred=student(x)['prediction'];fd=float((explicit-modelpred).abs().max())
   gate.need(fd==0,'Nonzero value formula mismatch')
   gate.need(all(float(v['step'])==2 for v in opt.state_dict()['state'].values()),'QA optimizer count')
   rows.append(dict(case=c['id'],parent_sha256=gate.sha(p),identity_origins=36,identity_max_difference=diff,nonzero_formula_difference=fd,
    serialized_resume_exact=True,frozen_core_exact=True,new_parameters=2112,epoch1_shuffle_sha256=h))
   del student,peer,base,opt,po,saved,saved2;gc.collect()
   print(json.dumps(dict(case=c['id'],status='passed')),flush=True)
  # The selector is unchanged, includes parent epoch0 and retains ties.
  candidate=[5,5-5e-7,6,5,5.1,5.2,5.3];best=0
  for i,v in enumerate(candidate):
   if v<candidate[best]-1e-6:best=i
  gate.need(best==0,'Parent retention rule')
  gate.write(gate.HERE/'qa.json',dict(status='passed',at=gate.now(),cases=rows,all_six_phase_unique_origins=17102,
   checks=['all9parentidentity','all9nonzero_formula','frozen_core_no_grad','serialized_Adam_RNG_resume','matched_phase_shuffle','epoch0_selector_retention'],
   sources={gate.rel(p):gate.sha(p) for p in gate.HERE.glob('*.py')},formal_training_started=False,heldout_targets_read=False))
  print(json.dumps(dict(status='passed',cases=9,identity_origins=324)))
if __name__=='__main__':main()
