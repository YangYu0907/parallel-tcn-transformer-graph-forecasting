"""Independent audit of frozen TRAIN-origin coverage and June phase diagnostics. No training or heldout inputs."""
from pathlib import Path
from datetime import datetime, timezone
import argparse
import ctypes
import hashlib
import json
import os
import sys
import time
import uuid

HERE = Path(__file__).resolve().parent
ROOT = HERE.parent
LOCK = Path('D:/Desktop/数据科学_论文/研究优化_20260818/logs/NEURAL_RUN.lock')
OUTPUT = HERE / 'independent_phase_audit.json'
PINNED_RESULT_SHA = '335c554db811c89bbdbdfedf2b8d2f8e624756567a58f992bcb30847a560afd0'
PINNED_SEAL_SHA = 'c0aa68e9cb221607331b5532679df0ed4d9230bfb401c6b6fab2865b0e97bcc7'
PINNED_QUEUE_COMPLETION_SHA = '415d30653f4c33f4e1e43f74fbf283db8b1bbd9d7d324e0d447be57830e95682'
QUEUE_LOCK_SHA = '1a5335ff40f0d9082bcf9218d27839357da3207be5b6b4ad8d4214add8136db6'
QUEUE_PLAN_SHA = 'ea1b9da71a25b9624feb1328105aa250dee9257a8300b68e90cb4702e26b754b'
SEEDS = (20260813, 20260814)
VARIANTS = ('FULL', 'TCN', 'EQUAL', 'CONCAT')
THREAD_VARS = ('OMP_NUM_THREADS', 'MKL_NUM_THREADS', 'OPENBLAS_NUM_THREADS',
               'NUMEXPR_NUM_THREADS', 'BLIS_NUM_THREADS', 'VECLIB_MAXIMUM_THREADS')


def require(value, message):
    if not value:
        raise RuntimeError(message)


def now():
    return datetime.now(timezone.utc).isoformat()


def read(path):
    return json.loads(Path(path).read_text(encoding='utf-8-sig'))


def digest(path):
    value = hashlib.sha256()
    with Path(path).open('rb') as stream:
        for block in iter(lambda: stream.read(1024 * 1024), b''):
            value.update(block)
    return value.hexdigest()


def inside(value):
    value = Path(value)
    path = (ROOT / value if not value.is_absolute() else value).resolve()
    require(path.is_relative_to(ROOT), 'Input escapes the new branch')
    return path


def boundary():
    pause = read(ROOT.parent / 'RESEARCH_PAUSED.json')
    require(pause.get('status') == 'resumed_by_user' and
            not pause.get('stop_preparation_and_training'), 'Research paused')
    for folder in (ROOT, HERE):
        for name in ('STOP_REQUESTED', 'STOP_REQUESTED.json'):
            require(not (folder / name).exists(), 'Stop requested')


def resource_guard(minimum=4.0):
    class Performance(ctypes.Structure):
        _fields_ = [('cb', ctypes.c_ulong)] + [
            (name, ctypes.c_size_t) for name in
            ('CommitTotal', 'CommitLimit', 'CommitPeak', 'PhysicalTotal',
             'PhysicalAvailable', 'SystemCache', 'KernelTotal', 'KernelPaged',
             'KernelNonpaged', 'PageSize')] + [
            (name, ctypes.c_ulong) for name in ('HandleCount', 'ProcessCount', 'ThreadCount')]
    value = Performance()
    value.cb = ctypes.sizeof(value)
    require(ctypes.windll.psapi.GetPerformanceInfo(ctypes.byref(value), value.cb),
            'Cannot read physical/commit resources')
    result = dict(physical_GiB=value.PhysicalAvailable * value.PageSize / 2**30,
                  commit_GiB=(value.CommitLimit-value.CommitTotal) * value.PageSize / 2**30)
    require(min(result.values()) >= minimum, 'Insufficient physical/commit GiB: ' + repr(result))
    return result


def immutable_report(value):
    # A single, short path under this validation directory; no old result mutation.
    pending = HERE / ('audit_' + uuid.uuid4().hex + '.pending')
    with pending.open('xb') as stream:
        stream.write((json.dumps(value, ensure_ascii=False, indent=2, allow_nan=False)+'\n').encode('utf-8'))
        stream.flush()
        os.fsync(stream.fileno())
    pending.rename(OUTPUT)



def main():
    require(os.name == 'nt' and not OUTPUT.exists(), 'Windows immutable output only')
    boundary(); initial = resource_guard(4.0)
    protocol_path, result_path = HERE/'protocol.json', HERE/'result.json'
    execution_path = HERE/'execution_af5140940894.json'
    protocol, original, execution = read(protocol_path), read(result_path), read(execution_path)
    require(digest(result_path) == '4309cbc055c7f80ac2f2668dae26adf2a2e6a9ba1b5ae8a0024485fdabae4019', 'Wrong diagnostic result')
    require(execution['actual_exit_code'] == 0 and execution['stderr'] == '' and
            inside(execution['argv'][1]) == HERE/'diagnose.py', 'Diagnostic did not exit zero')
    require(protocol['source_sha256'] == original['source_sha256'] == execution['source_sha256'] == digest(HERE/'diagnose.py') and
            original['protocol_sha256'] == digest(protocol_path), 'Diagnostic source/protocol binding')
    require(json.loads(execution['stdout'])['result_sha256'] == digest(result_path), 'Actual diagnostic output differs')
    tracked = {str(p.relative_to(ROOT)):digest(p) for p in (protocol_path,result_path,execution_path,HERE/'diagnose.py',Path(__file__).resolve())}
    tracked.update(protocol['bindings'])
    for rel, value in tracked.items():require(digest(inside(rel)) == value, 'Initial source changed: '+rel)
    seal = read(ROOT/'validation_controls_20260920/VALIDATION_LOCK.json')
    tracked.update(seal['sources'])
    audit_path = ROOT/'validation_controls_20260920/independent_numeric_audit_reviewed.json'
    panel_audit = read(audit_path)
    require(panel_audit['status'] == 'passed_independent_controls_June284_numeric_audit' and
            panel_audit['result_sha256'] == digest(ROOT/'validation_controls_20260920/result.json') and
            panel_audit['validation_lock_sha256'] == digest(ROOT/'validation_controls_20260920/VALIDATION_LOCK.json'), 'Panel audit missing/stale')
    tracked[str(audit_path.relative_to(ROOT))] = digest(audit_path)
    manifest = read(inside(seal['dataset_manifest']))
    require(manifest['prefix_stop'] == manifest['june_target_stop_exclusive'] == 219168 and
            manifest['train_target_stop_exclusive'] == 210528 and manifest['node_count'] == 30 and
            manifest['Q3_target_values_read'] is False and manifest['test_2026_targets_read'] is False, 'Unsafe prefix')
    artifacts = manifest['artifacts']
    names = ['timestamps_seconds.npy','registered_train_origins.npy','train_origins.npy','unique_phase_origins.npy',
             'registered_june_origins.npy','june_origins.npy','target_scaled.npy','scalers.json']
    names += [f'epoch{i}_origins.npy' for i in range(1,7)]
    files = {}
    for name in names:
        row = artifacts[name]; p = inside(row['path'])
        require(p.is_relative_to(ROOT/'dataset/compiled_train_june') and digest(p) == row['sha256'], 'Unsafe/changed artifact: '+name)
        files[name] = p; tracked[row['path']] = row['sha256']
    require(original['extra_source_bindings'] == {artifacts[n]['path']:artifacts[n]['sha256'] for n in names
            if n not in ('registered_june_origins.npy','june_origins.npy','target_scaled.npy','scalers.json')}, 'Extra diagnostic inputs differ')
    for rel, value in tracked.items():require(digest(inside(rel)) == value, 'Bound input changed: '+rel)
    import psutil
    process = psutil.Process()
    owner = dict(token=uuid.uuid4().hex,pid=os.getpid(),created=process.create_time(),action='independent_phase_diagnostic_audit')
    with LOCK.open('x',encoding='utf-8') as f:json.dump(owner,f);f.flush();os.fsync(f.fileno())
    start = time.perf_counter(); failure = None
    report = dict(status='failed',at=now(),source_sha256=digest(__file__),lock_owner=owner,
                  training_started=False,optimizer_steps=0,model_forward_calls=0,model_selection_performed=False,
                  Q3_targets_read=False,H1_targets_read=False,test_2026_targets_read=False)
    try:
        boundary();resource_guard(4.0)
        for key in THREAD_VARS:os.environ[key]='1'
        os.environ['OMP_DYNAMIC']=os.environ['MKL_DYNAMIC']='FALSE'
        process.cpu_affinity([min(process.cpu_affinity())])
        import numpy as np
        import math
        require('torch' not in sys.modules and 'diagnose' not in sys.modules, 'Forbidden imports')
        def array(p):return np.load(p,allow_pickle=False)
        def valid_origins(values,low,high):
            require(values.ndim == 1 and values.dtype.kind in 'iu' and len(np.unique(values))==len(values) and
                    np.all(values>=low) and np.all(values+12<=high), 'Invalid origin population')
        def metrics(error):
            require(error.ndim==3 and error.shape[1:]==(30,12) and len(error)>0 and np.isfinite(error).all(), 'Invalid error array')
            # Separate node-axis sums, then correctly-rounded fsum across origins.
            # The diagnostic uses a single np.mean reduction instead.
            abs_by_origin_h=np.abs(error).sum(axis=1,dtype=np.float64)
            sse_by_origin=np.einsum('ijk,ijk->i',error,error,dtype=np.float64)
            horizon=[math.fsum(abs_by_origin_h[:,h])/(len(error)*30) for h in range(12)]
            return dict(mae=math.fsum(horizon)/12,rmse=math.sqrt(math.fsum(sse_by_origin)/(len(error)*360)),
                        near_h1_4_mae=math.fsum(horizon[:4])/4,h12_mae=horizon[11],mae_by_horizon=horizon)
        maxdiff=0.0
        def compare(actual,saved,label):
            nonlocal maxdiff
            diffs=[abs(actual[k]-saved[k]) for k in ('mae','rmse','near_h1_4_mae','h12_mae')]
            require(len(saved['mae_by_horizon'])==12,'Missing horizon metrics')
            diffs.extend(abs(a-b) for a,b in zip(actual['mae_by_horizon'],saved['mae_by_horizon']))
            require(all(math.isfinite(d) for d in diffs) and max(diffs)<=1e-10,'Metric mismatch: '+label)
            maxdiff=max(maxdiff,max(diffs))
        toy=np.tile(np.arange(1,13,dtype=np.float64)[None,None,:],(2,30,1))
        tm=metrics(toy);require(tm['mae']==6.5 and tm['near_h1_4_mae']==2.5 and tm['h12_mae']==12 and abs(tm['rmse']-math.sqrt(650/12))<1e-12,'Metric known-answer failed')
        times=array(files['timestamps_seconds.npy'])
        require(times.shape==(219168,) and times.dtype.kind in 'iu' and np.all(np.diff(times)==300), 'Time grid is not contiguous5minute')
        coverage={}; epochs=[]
        for name in ['registered_train_origins.npy','train_origins.npy','unique_phase_origins.npy']+[f'epoch{i}_origins.npy' for i in range(1,7)]:
            values=array(files[name]);valid_origins(values,4320,210528)
            counts=np.bincount(np.remainder(values,12),minlength=12)
            minutes=sorted({datetime.fromtimestamp(int(t),timezone.utc).minute for t in times[values]})
            coverage[name]=dict(count=len(values),residues={str(p):int(counts[p]) for p in range(12)},target_start_minutes=minutes)
            require(coverage[name]==original['training_origin_coverage'][name], 'Training coverage mismatch: '+name)
            if name.startswith('epoch'):epochs.append(values)
        unique=array(files['unique_phase_origins.npy'])
        require(np.array_equal(np.unique(np.concatenate(epochs)),unique), 'Epoch union differs from training cache source')
        trained_hourly=all(c['target_start_minutes']==[0] for n,c in coverage.items() if n!='train_origins.npy')
        eligible_all=coverage['train_origins.npy']['target_start_minutes']==list(range(0,60,5))
        dense=array(files['june_origins.npy']);registered=array(files['registered_june_origins.npy'])
        valid_origins(dense,210528,219168);valid_origins(registered,210528,219168)
        require(len(dense)==3397 and len(registered)==284 and np.all(np.diff(dense)>0), 'June population')
        phases={str(p):sorted({datetime.fromtimestamp(int(t),timezone.utc).minute for t in times[dense[dense%12==p]]}) for p in range(12)}
        require(phases==original['phase_target_start_minutes'] and all(phases[str(p)]==[5*p] for p in range(12)), 'Index/minute mapping')
        require(original['registered_phase_counts']=={str(p):int(np.count_nonzero(registered%12==p)) for p in range(12)}, 'Registered phase counts')
        # Independent complete-block construction: intersection of block IDs across12 residues.
        block_sets=[set(map(int,dense[dense%12==p]//12)) for p in range(12)]
        complete=sorted(set.intersection(*block_sets))
        block_grid=np.asarray(complete,dtype=np.int64)[:,None]*12+np.arange(12)[None,:]
        block_indices=np.searchsorted(dense,block_grid)
        require(np.array_equal(dense[block_indices],block_grid), 'Complete-block pairing failed')
        scalers=read(files['scalers.json'])
        center=np.asarray(scalers['price_center'],np.float64)[0,:,0]
        scale=np.asarray(scalers['price_scale'],np.float64)[0,:,0]
        target=np.load(files['target_scaled.npy'],mmap_mode='r',allow_pickle=False)
        try:
            require(target.shape==(219168,30) and target.dtype==np.float32,'Unsafe target')
            truth=np.asarray(target[dense[:,None]+np.arange(12)[None,:]],np.float64).transpose(0,2,1).copy()
        finally:target._mmap.close()
        truth=truth*scale[None,:,None]+center[None,:,None]
        reg_indices=np.searchsorted(dense,registered);require(np.array_equal(dense[reg_indices],registered),'Registered join')
        cases=[c for c in seal['cases'] if c['kind']=='primary']; expected={f'CONTROL_{v}_{s}' for s in (20260813,20260814) for v in ('FULL','TCN','EQUAL','CONCAT')}
        require(len(cases)==len(original['rows'])==8 and {c['id'] for c in cases}=={r['id'] for r in original['rows']}==expected,'Eight frozen primary case coverage')
        old={r['id']:r for r in original['rows']};verified=[]; training_caches={}
        for case in cases:
            boundary();resource_guard(4.0)
            origins=array(inside(case['origins']));valid_origins(origins,210528,219168)
            order=np.argsort(origins);require(np.array_equal(origins[order],dense),'Dense source actual-origin population')
            cached=np.load(inside(case['truth']),mmap_mode='r',allow_pickle=False)
            try:require(np.array_equal(cached[order],truth),'USD truth differs from independent scaled-target reconstruction')
            finally:cached._mmap.close()
            pred=np.load(inside(case['prediction']),mmap_mode='r',allow_pickle=False)
            try:
                require(pred.shape==(3397,30,12) and pred.dtype==np.float64,'Frozen prediction shape/dtype')
                error=np.array(pred[order])-truth
            finally:pred._mmap.close()
            # Verify actual retained downstream TRAIN origins against selected audit's cache pointer.
            selected=read(inside(case['selection'])); ca=read(inside(case['audit']))
            folder=ROOT/'stages/query'/f"{case['seed']}_{case['model']}"
            pointer_path=folder/'cache/train/commit.json';pointer=read(pointer_path)
            require(digest(pointer_path)==ca['cache_commits']['train'] and pointer['identity']==selected['identity'],'Selected training cache pointer mismatch')
            commit_path=inside(pointer['data_directory'])/'commit.json';commit=read(commit_path)
            require(digest(commit_path)==pointer['data_commit_sha256'],'TRAIN cache data commit changed')
            train_path=commit_path.parent/'origins.npy'
            require(digest(train_path)==commit['artifacts']['origins.npy'],'TRAIN cache origin hash')
            train_values=array(train_path);valid_origins(train_values,4320,210528)
            require(np.isin(train_values,unique).all() and np.all(train_values%12==0),'Downstream TRAIN origins include a different population')
            training_caches[case['id']]=dict(retained_origins=len(train_values),minute_set=sorted(set(map(int,(times[train_values]//60)%60))),subset_of_epoch_union=True)
            for p in (pointer_path,commit_path,train_path):tracked[str(p.relative_to(ROOT))]=digest(p)
            row=old[case['id']];dm=metrics(error);rm=metrics(error[reg_indices]);compare(dm,row['dense_metrics'],case['id']+'/dense');compare(rm,row['registered_metrics'],case['id']+'/registered')
            require(row['complete_12_origin_blocks']==len(complete) and len(row['phases'])==12 and {p['origin_index_mod12'] for p in row['phases']}==set(range(12)),'Incomplete phase report')
            phase_rows=[]
            for phase in range(12):
                source=next(p for p in row['phases'] if p['origin_index_mod12']==phase)
                idx=np.flatnonzero(dense%12==phase);paired=block_indices[:,phase]
                require(source['origins']==len(idx) and source['balanced_origins']==len(paired),'Phase population mismatch')
                pm=metrics(error[idx]);bm=metrics(error[paired]);compare(pm,source['metrics'],case['id']+f'/phase{phase}');compare(bm,source['complete_block_metrics'],case['id']+f'/pairedphase{phase}')
                phase_rows.append(dict(phase=phase,minute=5*phase,origins=len(idx),metrics=pm,complete_block_metrics=bm))
            verified.append(dict(id=case['id'],seed=case['seed'],model=case['model'],dense=dm,registered=rm,
                                 complete_blocks_all_phases=metrics(error[block_indices.ravel()]),phases=phase_rows))
        rankings={}
        keys=('mae','rmse','near_h1_4_mae','h12_mae')
        for seed in (20260813,20260814):
            rows=[r for r in verified if r['seed']==seed]
            rank=lambda getter:{k:[r['model'] for r in sorted(rows,key=lambda r:getter(r)[k])] for k in keys}
            rankings[str(seed)]=dict(registered=rank(lambda r:r['registered']),dense=rank(lambda r:r['dense']),
                 complete_blocks_all_phases=rank(lambda r:r['complete_blocks_all_phases']),
                 phases={str(p):rank(lambda r,p=p:r['phases'][p]['metrics']) for p in range(12)},
                 matched_block_phases={str(p):rank(lambda r,p=p:r['phases'][p]['complete_block_metrics']) for p in range(12)})
        for rel,value in tracked.items():require(digest(inside(rel))==value,'Input changed during audit: '+rel)
        require('torch' not in sys.modules and 'diagnose' not in sys.modules,'Unexpected imports')
        boundary()
        report.update(status='passed_independent_phase_diagnostic_audit',diagnostic_result_sha256=digest(result_path),
             diagnostic_execution_sha256=digest(execution_path),diagnostic_native_exit=0,source_bindings=tracked,
             training_origin_coverage=coverage,actual_downstream_training_cache_coverage=training_caches,
             actual_training_target_start_only_minute0=trained_hourly,available_eligible_TRAIN_has_all12_phases=eligible_all,
             phase_target_start_minutes=phases,complete_blocks=len(complete),origins_dense=len(dense),origins_registered=len(registered),
             all_four_metrics_and_12_horizons_verified=True,maximum_absolute_metric_difference=maxdiff,
             verified=verified,rankings=rankings,original_diagnostic_imported=False,Torch_imported=False,
             initial_resources=initial,final_resources=resource_guard(4.0),peak_working_set_bytes=process.memory_info().peak_wset,
             numeric_threads=1,cpu_affinity=process.cpu_affinity(),
             interpretation={'confirmed':'Actual backbone epoch and retained downstream training origins are on the hour; eligible TRAIN and dense June cover all12 five-minute phases.',
              'supported_hypothesis':'Limited start-phase coverage is a plausible, testable contributor to the registered-versus-dense ranking reversal. Balanced complete blocks reduce calendar-composition confounding.',
              'not_established':'Causal effect of training coverage, guaranteed improvement, or independent generalization. Phase0 is represented by fewer target alignments, but its12-step labels still contain all within-hour target times; selected checkpoints also differ across model variants.',
              'next_test_scope':'A prespecified TRAIN-only phase-balanced origin schedule with matched budgets and frozen comparison criteria; preserve all12 phase reporting and locked heldout boundaries.'})
    except BaseException as exc:
        failure=exc;report.update(error_type=type(exc).__name__,error=str(exc))
    finally:
        if LOCK.exists() and read(LOCK)==owner:LOCK.unlink();report['lock_released']=True
        else:
            failure=RuntimeError('Lock ownership changed; refusing removal');report.update(status='failed',error=str(failure),lock_released=False)
        report.update(elapsed_seconds=time.perf_counter()-start,finished_at=now());immutable_report(report)
    print(json.dumps(dict(status=report['status'],report=str(OUTPUT),report_sha256=digest(OUTPUT),lock_released=report['lock_released'])))
    if failure:raise failure

if __name__=='__main__':main()
