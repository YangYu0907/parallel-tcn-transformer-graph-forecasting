import numpy as np

def onset(z,missing,seconds):
    valid=(abs(z)>1)&~missing
    same=np.r_[False,valid[:-1]&(np.diff(seconds)==300)&(np.sign(z[1:])==np.sign(z[:-1]))]
    starts=np.where(valid&~same,np.arange(len(z)),-1)
    return np.where(valid,np.maximum.accumulate(starts),-1)

def task_weights(risk,pair_weight):
    base=np.repeat(1/np.maximum(risk.sum(1),1),12)[risk.ravel()]
    result=base*np.repeat(pair_weight,12)[risk.ravel()]
    return result*(base.sum()/result.sum())

def expand(x,duration):
    return np.column_stack([np.repeat(x,12,axis=0),np.tile((np.arange(12)+1)/12,len(x)),(np.repeat(duration,12)+np.tile(np.arange(12)+1,len(x)))/288]).astype(np.float32)

def risk_sets(c):
    first=np.where((c<2).any(1),np.argmax(c<2,axis=1),12);h=np.arange(12)[None,:]
    return h<=first[:,None],h==first[:,None],h>=first[:,None]

def temperature(p,t):
    v=np.log(np.maximum(p,1e-12))/t;v-=v.max(-1,keepdims=True);v=np.exp(v)
    return v/v.sum(-1,keepdims=True)

def destination(hazard,post):
    surv=np.cumprod(1-hazard,axis=1);out=(1-surv[...,None])*post;out[:,:,2]+=surv
    return out,surv

def mean_median(mu,quantiles,p,ratio,sign):
    a=mu[...,None]+quantiles[None,:,:];a[:,0]=np.clip(a[:,0],-ratio[:,None],ratio[:,None])
    for k in (1,2):
        sg=np.where(a[:,k]>=0,1.,-1.);sg=np.where(abs(a[:,k])<1e-12,sign[:,None],sg)
        a[:,k]=sg*np.clip(abs(a[:,k]),ratio[:,None] if k==1 else 1.,1. if k==1 else np.inf)
    w=np.broadcast_to(p[...,None]/quantiles.shape[1],a.shape).reshape(len(mu),-1);a=a.reshape(len(mu),-1)
    mean=(a*w).sum(1);ii=np.argsort(a,axis=1);sa=np.take_along_axis(a,ii,axis=1);sw=np.take_along_axis(w,ii,axis=1)
    return mean,sa[np.arange(len(a)),np.argmax(np.cumsum(sw,axis=1)>=.5,axis=1)]

def anchored(full,mean,median):
    u=mean-full;v=median-full;d=np.where(u*v>0,np.sign(u)*np.minimum(abs(u),abs(v)),0.)
    return full+.75*d

def qa():
    z=np.array([0,2,3,2,0,-2,-3,2,2.]);t=np.arange(len(z))*300
    assert np.array_equal(onset(z,np.zeros(len(z),bool),t),[-1,1,1,1,-1,5,5,7,7])
    m=np.zeros(len(z),bool);m[2]=True
    assert onset(z,m,t)[3]==3
    zz=z.copy();zz[6:]=999
    assert np.array_equal(onset(z,np.zeros(len(z),bool),t)[:6],onset(zz,np.zeros(len(z),bool),t)[:6])
    t[3:]+=300;assert onset(z,np.zeros(len(z),bool),t)[3]==3
    mask=np.ones((3,12),bool);w=task_weights(mask,np.array([1,1,.5]));assert abs(w.sum()-3)<1e-12
    assert np.allclose(anchored(np.array([5.,5.]),np.array([3.,3.]),np.array([2.,7.])),[3.5,5])
    p,s=destination(np.full((2,12),.1),np.full((2,12,3),1/3));assert np.allclose(p.sum(-1),1)
    return ['onset causal prefix invariant','missing/sign/timestamp breaks','fixed task total weight','FULL anchor and disagreement fallback','survival simplex']
