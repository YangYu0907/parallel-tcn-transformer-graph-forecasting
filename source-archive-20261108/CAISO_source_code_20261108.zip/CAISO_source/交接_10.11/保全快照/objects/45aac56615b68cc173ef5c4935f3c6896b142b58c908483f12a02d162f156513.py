import gcommon as c


def main():
    if (c.HERE/'SEAL.json').exists():raise RuntimeError('Already registered')
    c.check(True)
    ep=c.read(c.ENERGY/'PROTOCOL.json')['european']
    candidates=[]
    for seed in (20260813,20260814,20260815):
        for arm,mode,sparse in [('FULL_CONT','FULL',False),('FULL_SPARSE','FULL',True),('STATIC_CONT','STATIC',False),('STATIC_SPARSE','STATIC',True),('SELF_CONT','SELF',False)]:
            folder=c.ENERGY/'runs'/f'{mode}_{seed}_0.001'
            assert c.sha(folder/'best.pt')==c.read(folder/'result.json')['checkpoint_sha256']
            candidates.append(dict(id=f'{seed}_{arm}',seed=seed,arm=arm,mode=mode,sparse=sparse,parent=str(folder/'best.pt'),parent_sha256=c.sha(folder/'best.pt')))
    protocol=dict(at=c.now(),status='preregistered_before_candidate_training',id='V21-G-sparse-cross-neighbours',
        evidence=str(c.ROUND/'STRUCTURE_PROBE.json'),
        hypothesis='Europe3-market graph top_k2 retains both other markets. Dynamic cross mass is high in the inspected validation inputs. Test whether selecting cross-neighbours improves predictions while preserving the learned total self/cross weighting. High mass alone does not prove harm.',
        candidate='Replace conditional cross-neighbour Softmax allocation by sparsemax(log cross probabilities); preserve each row self mass exactly for the same underlying weights. Leave TCN, Transformer, adaptive feature attention and decoder unchanged.',
        distinction='Not scalar self/dynamic mixture, graph-prior blend, change to fusion Softmax, L1 penalty on normalized adjacency, or fixed neighbour threshold search. Dynamic support may retain one or both other markets.',
        cases=candidates,epochs=2,lr=0.0002,batch_size=ep['batch_size'],weight_decay=ep['weight_decay'],grad_clip=ep['grad_clip'],loss='Huber(delta0.5) in existing normalized space',
        restart='Load each own original selected checkpoint; fresh AdamW for every continued arm because selected checkpoints lack optimizer state. Identical per-seed sample order and RNG reset across matched arms. No reuse of unmatched continuation optimizer.',
        selection='Report epoch0,1,2; choose minimum original2015validation MAE with earliest tie. FULL_SPARSE epoch0 is already structurally modified; also retain unmodified original reference separately.',
        data='Original Europe2012-2014training/2015validation only; no Europe2016/2017 or new CAISO targets.',
        budget_seconds=1200,checkpoint_every_steps=8,no_grid=True,new_test_targets_read=False,
        acceptance='Exploratory gate only: mean FULL_SPARSE MAE below FULL_CONT,STATIC_CONT,STATIC_SPARSE,SELF_CONT and originalFULL; mean RMSE and H24MAE no worse than originalFULL; >=2seed MAE wins vsFULL_CONT. Report all market/horizon/seed directions. New independent confirmation and full-matrix retention are required before any model replacement.',
        fallback='V7CAISO and oldEurope weights/results/paper unchanged; failure closes this candidate without search.',
        artifacts=str(c.ART),resources='Single numericalworker; unchanged5GiBlaunch4GiBruntime; Cnumerical2GiBlaunch1GiBruntime disk; Fmetadata32MiB.',
        literature=[{'url':'https://proceedings.mlr.press/v48/martins16.html','use':'Sparsemax produces trainable exact-zero probability allocations. Source is ICML, not an Energy electricity-price result.'},
                    {'url':'https://arxiv.org/abs/2005.11650','use':'Sparse learned relations in multivariate time-series forecasting; our conditional cross-allocation is a new empirical hypothesis.'}])
    c.write(c.HERE/'PROTOCOL.json',protocol)
    paths=list(c.HERE.glob('*.py'))+[c.HERE/'PROTOCOL.json',c.ROUND/'STRUCTURE_PROBE.json',c.ROUND/'STRUCTURE_PROBE_AUDIT.json',c.ROUND/'RETAINED_BASELINE_HASHES.json',c.ROOT/'TASK_PARALLEL_DEVELOPMENT_REVISION_20261001.json',c.ENERGY/'data/train_valid.npz',c.ENERGY/'europe_model.py',c.ENERGY/'common.py']
    paths+=list((c.ROOT/'source/models').glob('*.py'))
    paths += [c.Path(x['parent']) for x in candidates]
    c.write(c.HERE/'SEAL.json',dict(at=c.now(),bindings={str(p):c.sha(p) for p in paths}))
    c.write(c.HERE/'status.json',dict(at=c.now(),status='registered',fits=0,new_test_targets_read=False))
    print('Registered one sparse cross-neighbour candidate with15matched continuation runs.')

if __name__=='__main__':main()
