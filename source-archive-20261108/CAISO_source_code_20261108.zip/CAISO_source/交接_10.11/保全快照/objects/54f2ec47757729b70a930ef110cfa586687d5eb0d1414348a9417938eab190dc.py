from revision_common import *
import numpy as np,csv,collections
def csvread(name):
 with (ROOT/name).open(encoding='utf-8-sig',newline='') as f:return list(csv.DictReader(f))
def csvout(name,rows):
 with (ROOT/name).open('w',encoding='utf-8-sig',newline='') as f:
  w=csv.DictWriter(f,fieldnames=list(rows[0]));w.writeheader();w.writerows(rows)
def main():
 with numeric('revision evidence consolidation and event diagnostics'):
  ref=read(ROOT/'V7_REFIT_RESULT.json');scores=collections.defaultdict(list)
  for seed in SEEDS:
   with np.load(ROOT/'v7_refit_predictions'/f'{seed}.npz') as z:
    for model in ['NO_DURATION_FEATURES','NO_TEMPERATURE','REPLAY']:
     err=z[model]-z['truth'];expected=[float(abs(err).mean()),float(np.sqrt(np.mean(err*err))),float(abs(err[:,:,:4]).mean()),float(abs(err[:,:,-1]).mean())]
     row=next(r for r in ref['rows'] if r['seed']==seed and r['model']==model and r['subset']=='overall')
     assert np.allclose(expected,[row[k] for k in ['mae','rmse','near_mae','h12_mae']],rtol=0,atol=1e-10)
     scores[model].append(expected)
  summary=read(ROOT/'V7_COMPONENT_DIAGNOSIS.json')['summary'];summary.update({m:dict(zip(['mae','rmse','near_mae','h12_mae'],np.mean(v,0).tolist())) for m,v in scores.items() if m!='REPLAY'})
  csvout('V7_ALL_COMPONENT_SUMMARY.csv',[dict(model=k,**v) for k,v in summary.items()])
  write(ROOT/'V7_REFIT_AUDIT.json',dict(at=now(),status='passed',seeds=3,overall_metrics_recomputed=True,reference_replay_exact=ref['original_replay_exact'],new_files_only=True,summary=summary))
  with np.load(T/'adaptive_experts_v4_20260929/panel.npz') as z:cut=z['cutoff'];raw_last=z['raw_last']
  with np.load(T/'spike_specialist_v7_20260930/predictions/20260813.npz') as z:ids=z['eval_indices']
  cut=cut[ids];events=[];tailrows=[]
  th=read(B/'dataset/compiled_train_june/build_16b2377c02a74effb6983991b6bed066/state_thresholds.json');center=np.array(th['center']);q99=np.array(th['thresholds'])[1]
  for seed in SEEDS:
   with np.load(ROOT/'component_predictions'/f'{seed}.npz') as z:d={k:z[k] for k in ['truth','states','FULL','CONTEXT']}
   for h in [0,11]:
    targets=cut+300*(h+1)
    for node in range(30):
     y=d['truth'][:,node,h];direction=np.where(y>center[node]+q99[node],1,np.where(y<center[node]-q99[node],-1,0));fragment=[]
     def finish():
      if not fragment:return
      ii=np.array(fragment);a=d['FULL'][ii,node,h]-y[ii];b=d['CONTEXT'][ii,node,h]-y[ii]
      events.append(dict(seed=seed,node=node,horizon=h+1,direction='upper' if direction[ii[0]]>0 else 'lower',first_target_utc=int(targets[ii[0]]),last_target_utc=int(targets[ii[-1]]),observed_slots=len(ii),FULL_MAE=float(abs(a).mean()),V7_MAE=float(abs(b).mean()),FULL_SSE=float((a*a).sum()),V7_SSE=float((b*b).sum()),boundary='sampled fragment; onset/end unobserved across panel gaps'))
     for i in range(len(y)):
      if direction[i] and (not fragment or (direction[i]==direction[fragment[-1]] and targets[i]-targets[fragment[-1]]==300)):fragment.append(i)
      else:
       finish();fragment=[i] if direction[i] else []
     finish()
   for s in range(6):
    mask=d['states']==s;a=(d['FULL']-d['truth'])[mask];b=(d['CONTEXT']-d['truth'])[mask]
    increases=np.maximum(b*b-a*a,0);top=np.sort(increases)[-10:].sum()
    tailrows.append(dict(seed=seed,state=s,cells=int(mask.sum()),origin_dates=len(np.unique((cut//86400)[mask.any((1,2))])),FULL_mae=float(abs(a).mean()),V7_mae=float(abs(b).mean()),FULL_rmse=float(np.sqrt((a*a).mean())),V7_rmse=float(np.sqrt((b*b).mean())),changed_cells=int(np.count_nonzero(a!=b)),top10_share_of_increased_SSE=float(top/increases.sum()) if increases.sum()>0 else 0))
  csvout('SPIKE_OBSERVED_FRAGMENTS.csv',events);csvout('V7_STATE_ATTRIBUTION.csv',tailrows)
  write(ROOT/'SPIKE_DIAGNOSTIC_SCOPE.json',dict(at=now(),status='completed',horizons=[1,12],thresholds='original TRAIN center plus or minus TRAIN absolute-deviation q99',events='Observed contiguous five-minute fragments only; gaps always split fragments. Neither nodes nor overlapping horizons count as independent episodes.',count_per_seed={str(h):sum(r['seed']==SEEDS[0] and r['horizon']==h for r in events) for h in [1,12]},new_signal='No new onset predictor fitted. V7 specialist is activated only after an extreme origin is observed; realized S2 remains on the routine correction path.',tables=['SPIKE_OBSERVED_FRAGMENTS.csv','V7_STATE_ATTRIBUTION.csv']))
  pr=csvread('PROBABILITY_RESULTS.csv');tails=[]
  for task in ['CAISO','Europe']:
   for state in sorted(set(r['value'] for r in pr if r['task']==task and r['partition']=='realized_state')):
    row=dict(task=task,state=state)
    for model in ['HIST_CAL','CQR_CAL']:
     rr=[r for r in pr if r['task']==task and r['partition']=='realized_state' and r['model']==model and r['value']==state]
     row['cells_per_seed']=int(rr[0]['cells'])
     for key in ['wis','coverage90','width90']:row[model+'_'+key]=float(np.mean([float(r[key]) for r in rr]))
    row['WIS_improvement_pct']=100*(1-row['CQR_CAL_wis']/row['HIST_CAL_wis']);tails.append(row)
  csvout('PROBABILITY_STATE_SUMMARY.csv',tails)
  graph=csvread('GRAPH_OBSERVABLE_REGIME_RESULTS.csv');gg=[]
  for state in ['low','mid','high']:
   for model in ['FULL','STATIC','SELF']:
    rr=[r for r in graph if r['history_volatility']==state and r['model']==model]
    gg.append(dict(regime=state,model=model,origins=int(rr[0]['origins']),MAE=float(np.mean([float(r['mae']) for r in rr])),RMSE=float(np.mean([float(r['rmse']) for r in rr]))))
  csvout('GRAPH_REGIME_SUMMARY.csv',gg)
  # Static publication-style figures generated from the exported data, no generated artwork.
  import matplotlib;matplotlib.use('Agg')
  import matplotlib.pyplot as plt
  plt.rcParams.update({'font.family':'DejaVu Sans','font.size':9,'axes.spines.top':False,'axes.spines.right':False,'pdf.fonttype':42,'svg.fonttype':'none','savefig.bbox':'tight'})
  figdir=ROOT/'figures';figdir.mkdir(exist_ok=True)
  def save(fig,name):
   for ext in ['png','pdf','svg']:fig.savefig(figdir/f'{name}.{ext}',dpi=300)
   plt.close(fig)
  r=read(ROOT/'PROBABILITY_RESULT.json')['summary'];fig,ax=plt.subplots(1,2,figsize=(7.3,2.7),layout='constrained')
  for axis,task in zip(ax,['CAISO','Europe']):
   for model,color in [('HIST_CAL','#777777'),('CQR_CAL','#2166ac')]:axis.plot([80,90],[r[task]['scores'][model][f'coverage{x}']*100 for x in [80,90]],'o-',label=model,color=color)
   axis.plot([80,90],[80,90],'--',color='#222222',lw=.8,label='Nominal');axis.set(title=task+' development',xlabel='Nominal interval (%)',ylabel='Empirical coverage (%)',xticks=[80,90],ylim=(72,94));axis.grid(alpha=.15)
  ax[0].legend(frameon=False,fontsize=7,loc='upper left');save(fig,'probability_coverage')
  models=[k for k in summary if k!='FULL'];fig,axes=plt.subplots(1,2,figsize=(7.3,4.0),sharey=True,layout='constrained')
  for ax,key in zip(axes,['mae','rmse']):
   vals=[100*(summary['CONTEXT'][key]-summary[k][key])/summary['CONTEXT'][key] for k in models]
   ax.scatter(vals,np.arange(len(models)),color='#2166ac',s=24);ax.axvline(0,color='#777777',lw=.8);ax.set_yticks(range(len(models)),models);ax.set_xlabel(f'{key.upper()} reduction versus retained V7 (%)');ax.grid(axis='x',alpha=.15)
  axes[0].invert_yaxis();save(fig,'v7_component_controls')
  fig,ax=plt.subplots(1,2,figsize=(7.3,2.8),layout='constrained');c=[r for r in tails if r['task']=='CAISO']
  ax[0].bar([f'S{x["state"]}' for x in c],[x['WIS_improvement_pct'] for x in c],color='#2166ac');ax[0].axhline(0,color='#777777',lw=.8);ax[0].set_ylabel('WIS reduction vs HIST_CAL (%)');ax[0].set_title('CAISO realized-state diagnostics')
  for model,color in [('HIST_CAL','#777777'),('CQR_CAL','#2166ac')]:ax[1].plot([f'S{x["state"]}' for x in c],[100*x[model+'_coverage90'] for x in c],'o-',label=model,color=color)
  ax[1].set(ylabel='90% interval coverage (%)',ylim=(0,100));ax[1].legend(frameon=False,fontsize=7);save(fig,'probability_state_diagnostics')
  fig,ax=plt.subplots(figsize=(7.3,2.6),layout='constrained')
  for m,mark,col in [('FULL','o','#2166ac'),('STATIC','s','#b35806'),('SELF','^','#666666')]:ax.plot(range(3),[next(x['MAE'] for x in gg if x['model']==m and x['regime']==s) for s in ['low','mid','high']],marker=mark,label=m,color=col)
  ax.set(xticks=[0,1,2],xticklabels=['Low (238 days)','Mid (82 days)','High (45 days)'],ylabel='MAE (EUR/MWh)',xlabel='Observable past-week volatility',title='Europe 2015 development');ax.legend(frameon=False,ncol=3);save(fig,'graph_regime_diagnostics')
  write(ROOT/'FIRST_BATCH_COMPLETE.json',dict(at=now(),protected_files=verify_protected(),probability_audit=read(ROOT/'PROBABILITY_INDEPENDENT_AUDIT.json')['status'],v7_refit_audit='passed',backbone_retraining=False,fresh_independent_test=False,all_processes_synchronous=True))
  print(json.dumps(dict(summary=summary,probability_states=tails,graph=gg),ensure_ascii=False))
if __name__=='__main__':main()
