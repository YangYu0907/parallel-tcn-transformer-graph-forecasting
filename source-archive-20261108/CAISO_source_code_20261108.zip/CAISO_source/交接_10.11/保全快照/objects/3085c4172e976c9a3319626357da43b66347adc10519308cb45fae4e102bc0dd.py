"""Resume the same mirror proof with SHA-verified original source indexes.
Original payload checks, source deadline, byte ceiling and fixed 32 cycles stay unchanged.
"""
import sys, os, json, time, hashlib, traceback
from pathlib import Path
from datetime import datetime
from concurrent.futures import ThreadPoolExecutor, wait, FIRST_COMPLETED
import manager as m
P=m.P; Z=m.Z; nt=m.nt; s=m.s
INDEX={}
def write(name,data):m.write('resume/'+name,data)
def validated_index(key,expected):
    row=INDEX[key];p=Path(row['path']);data=p.read_bytes()
    assert hashlib.sha256(data).hexdigest()==row['sha256'],'Index SHA changed'
    assert len(data)==expected['bytes'],'Index length changed'
    assert hashlib.md5(data).hexdigest()==expected['etag'].strip('"'),'Index identity changed'
    assert row['source']==expected or all(row['source'].get(k)==v for k,v in expected.items() if k!='minimum_qualified_cutoff')
    return data,str(p)
def verify():
    parent,original=m.verify();q=s.read(P/'resume/PROTOCOL.json')
    for path,h in q['bindings'].items():assert s.sha(path)==h,path
    assert s.read(P/'resume/QA.json')['passed']
    for key in ['choices','retain_cycles','maximum_bytes','maximum_requests','maximum_attempts','maximum_retained_raw_bytes','deadline_unix','parent_source_deadline_unix','remaining_production_cycles','io_threads']:
        assert q[key]==original[key],key
    return parent,q
def main():
    parent,q=verify();m.setup()
    INDEX.update(s.read(P/'resume/INDEX_REPLAY.json')['indices'])
    nt.m.retained_index=validated_index
    write('STATUS.json',dict(at=s.now(),pid=os.getpid(),event='awaiting_exit_monitor_binding'))
    start=time.monotonic()
    while not (P/'resume/START_READY.json').exists():
        if time.monotonic()-start>55:raise TimeoutError('Exit monitor not bound')
        time.sleep(.2)
    import psutil
    ready=s.read(P/'resume/START_READY.json')
    assert ready['manager_pid']==os.getpid() and psutil.pid_exists(ready['exit_monitor_pid'])
    with s.base.numeric('Same32cycle mirror proof resume; trusted original index cache repair; zero fits'):
        objects=s.read(nt.m.I/'AUDITED_OBJECT_INDEX.json')['objects']
        for c in q['choices']:
            from datetime import timezone
            dt=datetime.fromtimestamp(c['cycle'],timezone.utc)
            for lead in [3,4,5]:
                key=dt.strftime('hrrr.%Y%m%d/conus/hrrr.t%Hz.wrfsfcf')+f'{lead:02d}.grib2'
                for k in [key,key+'.idx']:objects[k]=dict(objects[k],minimum_qualified_cutoff=c['minimum_qualified_cutoff'])
        nt.COUNTS.update(q['inherited_counters'])
        nt.RAW_RESERVATIONS.update({str(f.resolve()):f.stat().st_size for f in Z.rglob('*.grib2')})
        rows=list(q['prior_rows']);completed={x['cycle'] for x in rows}
        for row in rows:
            record=s.read(P/'cycles'/f'{row["cycle"]}.json')
            assert s.sha(P/'cycles'/f'{row["cycle"]}.json')==row['mirror_record_sha256']
            old=s.read(Z/'cycles'/f'{row["cycle"]}.json')
            assert record['center_values']==old['center_values'] and record['patch_means']==old['patch_means'] and record['geometry']==old['geometry']
        geo=s.read(P/'cycles'/f'{rows[0]["cycle"]}.json')['geometry']
        iterator=iter([c for c in q['choices'] if c['cycle'] not in completed])
        pending={};pool=ThreadPoolExecutor(max_workers=4);beg=time.monotonic()
        write('STATUS.json',dict(at=s.now(),pid=os.getpid(),event='same_file_mirror_proof_resuming',model_fits=0))
        def costs():
            elapsed=q['prior_active_seconds']+time.monotonic()-beg
            remaining=q['parent_source_deadline_unix']-time.time()
            # Even with every unfinished source instantly completed, exceeding this
            # lower bound makes the preregistered all32 throughput gate impossible.
            lower=q['remaining_production_cycles']*elapsed/32*1.5
            return dict(at=s.now(),active_seconds=elapsed,remaining_source_budget_seconds=remaining,
                        best_possible_remaining_projection_seconds=lower,cost_still_feasible=lower<=remaining)
        try:
            def submit():
                c=next(iterator,None)
                if c is not None:pending[pool.submit(nt.fetch,c,objects,parent,q)]=c
            for _ in range(4):submit()
            while pending:
                nt.check(q);cost=costs()
                if not cost['cost_still_feasible']:
                    write('COST_STOP.json',dict(cost,verified_cycles=len(rows),required_cycles=32,model_fits=0))
                    raise TimeoutError('Even instantly completing all32 cannot satisfy original full-source cost gate; preserve checkpoint')
                done,_=wait(pending,timeout=1,return_when=FIRST_COMPLETED)
                for f in done:
                    c=pending.pop(f);d=f.result();cycle=c['cycle'];old=s.read(Z/'cycles'/f'{cycle}.json')
                    ref={(r['key'],tuple(r.get('range',[]))):r['sha256'] for r in old['receipts']}
                    removal=[];latest=0
                    for receipt in d['receipts']:
                        assert receipt['sha256']==ref[(receipt['key'],tuple(receipt.get('range',[])))],'Mirror payload differs from original'
                        file=(Z/receipt['local']).resolve()
                        assert file.is_relative_to((P/'work').resolve()) and s.sha(file)==receipt['sha256']
                        headers=receipt.get('native_response_headers',{})
                        if headers:latest=max(latest,m.parsedate_to_datetime(headers['last-modified']).timestamp())
                        if receipt.get('range') and cycle not in q['retain_cycles']:
                            removal.append(dict(path=str(file),sha256=receipt['sha256']))
                            receipt['temporary_source_fragment']=receipt.pop('local');receipt['local']=None
                    before=time.monotonic();record,geo=nt.m.decode(d,parent,geo)
                    assert record['center_values']==old['center_values'] and record['patch_means']==old['patch_means'] and record['geometry']==old['geometry']
                    digest=s.sha(P/'cycles'/f'{cycle}.json')
                    write(f'released/{cycle}.json',dict(at=s.now(),record_sha256=digest,verified_files=removal))
                    for item in removal:
                        path=Path(item['path']).resolve()
                        assert path.is_relative_to((P/'work').resolve()) and path.suffix=='.grib2' and s.sha(path)==item['sha256']
                        with nt.LOCK:path.unlink();nt.RAW_RESERVATIONS.pop(str(path),None)
                    rows.append(dict(cycle=cycle,fetch_seconds=d['fetch_seconds'],decode_seconds=time.monotonic()-before,
                      all_original_payload_sha_equal=True,all_528_weather_values_equal=True,mirror_latest_version_seconds=latest,mirror_record_sha256=digest))
                    write('PROGRESS.json',dict(at=s.now(),completed_cycles=len(rows),total_cycles=32,rows=rows,counters=dict(nt.COUNTS),model_fits=0,cost=costs()))
                    submit()
        except BaseException:
            nt.CANCEL.set()
            for f in pending:f.cancel()
            raise
        finally:pool.shutdown(wait=True,cancel_futures=True)
        cost=costs();assert len(rows)==32;s.base.verify_protected()
        result=dict(cost,cycles=32,rows=rows,byte_and_value_gate_passed=True,cost_gate_passed=cost['cost_still_feasible'],
          counters=dict(nt.COUNTS),model_fits=0,new_test_targets_read=False,V7_replaced=False,automatic_full_restart=False,
          scope='All32 fixed same sources. Includes active failed-transfer time; manual engineering pause excluded from throughput but full wallclock source deadline unchanged.')
        write('RESULT.json',result)
    eid=s.emit('needs_analysis',P/'resume/RESULT.json')
    write('STATUS.json',dict(at=s.now(),pid=os.getpid(),event='finite_mechanism_queue_completed',event_id=eid,model_fits=0))
if __name__=='__main__':
    try:main()
    except BaseException as e:
        nt.CANCEL.set()
        write('FAILURE.json',dict(at=s.now(),error=repr(e),traceback=traceback.format_exc(),network=dict(nt.COUNTS),model_fits=0,automatic_restart=False))
        eid=s.emit('blocking_failure',P/'resume/FAILURE.json')
        write('STATUS.json',dict(at=s.now(),pid=os.getpid(),event='step_stopped_or_failed',event_id=eid))

