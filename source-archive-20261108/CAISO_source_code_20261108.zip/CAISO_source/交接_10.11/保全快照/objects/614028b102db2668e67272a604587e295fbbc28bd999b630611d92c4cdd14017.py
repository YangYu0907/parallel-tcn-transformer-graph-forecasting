"""Register new-data component controls with the unchanged audited trainer.

This wrapper does not mutate the original trainer, protocol, lock, or running
process. Training functions and math QA are the original sealed objects.
"""
from pathlib import Path
import argparse
import json
import backbone_train as trainer

ROOT = Path(__file__).resolve().parents[1]
VARIANTS = ('EQUAL', 'CONCAT', 'GLOBAL', 'GTF', 'STATIC', 'SELF')
EXPECTED_ORIGINAL_LOCK = '10397482e6d0a47d83635a18bcf083cfcf181c75138474962d0234048c00bbc5'
original_lock = ROOT / 'BACKBONE_LOCK.json'
if trainer.sha(original_lock) != EXPECTED_ORIGINAL_LOCK:
    raise RuntimeError('The independently audited original trainer seal changed.')
trainer.bindings_check(trainer.read(original_lock)['sources'])

trainer.PROTOCOL = ROOT / 'CONTROL_BACKBONE_PROTOCOL.json'
trainer.LOCK = ROOT / 'CONTROL_BACKBONE_LOCK.json'
original_source_paths = trainer.source_paths


def control_source_paths():
    bindings = original_source_paths()
    bindings['source/control_backbone_train.py'] = trainer.sha(Path(__file__))
    bindings['BACKBONE_LOCK.json'] = EXPECTED_ORIGINAL_LOCK
    return bindings


trainer.source_paths = control_source_paths


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('action', choices=('check', 'seal', 'run'))
    parser.add_argument('--manifest', default='dataset/compiled_train_june/manifest.json')
    parser.add_argument('--variant', choices=VARIANTS, default='EQUAL')
    parser.add_argument('--seed', type=int, choices=(20260813, 20260814), default=20260813)
    parser.add_argument('--resume', action='store_true')
    args = parser.parse_args()
    if args.action == 'seal':
        result = trainer.seal()
    elif args.action == 'check':
        try:
            result = trainer.admission(args.manifest, args.variant, args.seed)
        except (OSError, ValueError, KeyError, RuntimeError) as exc:
            print(json.dumps({'status': 'blocked', 'reason': str(exc), 'numeric_imports': False,
                              'actual_market_values_read': False, 'training_started': False}))
            return 2
    else:
        result = trainer.train(args.manifest, args.variant, args.seed, args.resume)
    print(json.dumps(result, ensure_ascii=True))
    return 3 if result.get('status') == 'stopped_at_safe_boundary' else 0


if __name__ == '__main__':
    raise SystemExit(main())
