from common import *

def main():
    with gate.exclusive('V4 synthetic causality and functional-routing QA'):
        np,lim=gate.runtime(False)
        import worker
        worker.np=np
        checks=[]
        ex=np.array([[[10.,14.,6.,12.,8.]]]);mean=np.array([[2.]]);med=np.array([[1.]])
        w,c=correction_weights(ex,mean,med,np.array([[True]]))
        assert np.allclose((w*ex).sum(-1),11.) and w[...,0]>=.25;checks.append('convex functionals correction')
        w,c=correction_weights(ex,mean,-med,np.array([[True]]));assert w[...,0]==1;checks.append('conflicting mean median fallback')
        w,c=correction_weights(ex,100*mean,100*med,np.array([[True]]));assert w[...,0]==.25;checks.append('FULL anchor')
        # Estimated true functionals example: partial mixture can beat both L1 and L2 while expert alone loses.
        y=np.array([1.,1.]);full=np.zeros(2);expert=np.ones(2)*3
        assert abs(expert-y).mean()>abs(full-y).mean() and np.square(.3333333333333333*expert-y).mean()==0
        checks.append('partial combination risk identity')
        X=np.column_stack([np.arange(10.),np.ones(10)])
        beta=bounded_irls(X,np.arange(10.)*5,np.zeros(2),1)
        assert 0<=beta[0]<=1;checks.append('bounded reversion fit')
        # Real schemas/scalers with synthetic rows only, no target access.
        m=gate.read(B/'phase_sampling_support_v3_20260923/dataset/ADDITIVE/manifest.json');sc=gate.read(gate.resolve(m['artifacts']['scalers.json']['path']))
        last=np.zeros((2,30,29));reg=np.zeros((2,30),int)
        betas=np.zeros((12,3,11));betas[:,:,0]=1
        pred=worker.tar_predict(dict(betas=betas,unit=float(np.array(sc['price_scale'])[0,:,0].mean())),last,sc,reg)
        expected=np.median([np.array(sc['derived'][n]['center']) for n in ('lmp_lag_24h','lmp_lag_48h','lmp_lag_7d','lmp_lag_14d')],axis=0)
        assert np.allclose(pred,np.broadcast_to(expected[None,:,None],pred.shape));checks.append('raw lag scales and USD output')
        # Sequential feedback replay: later outcomes cannot affect earlier predictions.
        n=6;cut=np.arange(n)*86400+1000
        data=dict(cutoff=cut,available=cut[:,None]+300*(np.arange(12)[None,:]+1),truth=np.ones((n,30,12))*11,observable_regime=np.zeros((n,30),int))
        experts=np.broadcast_to(ex,(n,30,12,5)).copy();tr=np.arange(3);ev=np.arange(3,6);cal=tr.copy()
        conditional=np.ones_like(experts);functions=np.ones((n,30,12,2));prior=np.ones((30,12,5));temp=np.ones(12)
        kwargs=dict(experts=experts,tr=tr,ev=ev,cal=cal,conditional=conditional,functions=functions,prior=prior,temp=temp,unsupported=np.zeros((3,30),bool),pooled_allowed=np.ones((3,30),bool))
        a=worker.simulate(data,**kwargs);changed={**data,'truth':data['truth'].copy()};changed['truth'][4:]=999
        b=worker.simulate(changed,**kwargs)
        assert all(np.array_equal(a[0][k][:2],b[0][k][:2]) for k in ARMS);checks.append('future outcome mutation leaves current decisions unchanged')
        assert np.all(a[2][:,2]<=a[2][:,3]);checks.append('feedback published before use')
        # Quantile implementation exists with deterministic checkpointed warm-start.
        from sklearn.ensemble import HistGradientBoostingRegressor
        q=HistGradientBoostingRegressor(loss='quantile',quantile=.5,max_iter=2,min_samples_leaf=2,early_stopping=False,warm_start=True)
        q.fit(X,np.arange(10.));q.set_params(max_iter=3);q.fit(X,np.arange(10.));assert q.n_iter_==3
        checks.append('median learner API')
        write(HERE/'QA.json',dict(status='passed',at=gate.now(),checks=checks,real_target_values_read=False))
        files=[HERE/n for n in ('common.py','worker.py','audit.py','manager.py','qa.py','PROTOCOL.json','SOURCE_BINDINGS.json','QA.json')]
        for seed in SEEDS:files.append(V2/'models'/f'{seed}_GB_DELTA.pkl')
        files.extend([V2/'common.py',T/'gate.py'])
        write(HERE/'EXECUTION_SEAL.json',dict(at=gate.now(),bindings={str(q):gate.sha(q) for q in files}))
        print('QA passed; source and implementation hashes frozen')
if __name__=='__main__':main()
