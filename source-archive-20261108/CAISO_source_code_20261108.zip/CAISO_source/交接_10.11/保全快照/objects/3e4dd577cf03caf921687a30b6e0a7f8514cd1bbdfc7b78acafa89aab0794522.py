"""Training-only stable prior plus still input-dependent dynamic adjacency."""
import torch
from models.clip_model import ClipFusion
from models.model_feature_fusion_rev12 import GraphEncoder,FusionConfig

class PriorGraph(GraphEncoder):
    def __init__(self,prior,rho=.5):
        super().__init__(FusionConfig())
        value=torch.as_tensor(prior,dtype=torch.float32)
        if value.shape!=(30,30) or not torch.isfinite(value).all() or (value<0).any() or not torch.allclose(value.sum(-1),torch.ones(30),atol=1e-6):
            raise ValueError('Invalid training-only prior')
        self.register_buffer('prior_adjacency',value.clone())
        self.rho=float(rho)
    def dynamic_adjacency(self,projected):
        dynamic,context=super().dynamic_adjacency(projected)
        if self.rho==1.: return dynamic,context
        return self.rho*dynamic+(1.-self.rho)*self.prior_adjacency.unsqueeze(0),context

class PriorFusion(ClipFusion):
    def __init__(self,seed,limits,prior,rho=.5):
        super().__init__('FULL',seed,limits)
        self.graph=PriorGraph(prior,rho)
