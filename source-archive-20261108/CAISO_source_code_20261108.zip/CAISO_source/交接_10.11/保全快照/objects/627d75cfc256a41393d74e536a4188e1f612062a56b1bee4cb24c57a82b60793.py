"""Consolidate diagnosis evidence and persist the user's diagnosis-first constraint."""
from diagnose_fixed_predictions import B, HERE, gate, write
from pathlib import Path
import hashlib
import json
import os
import uuid
import zipfile


def atomic_at(path, obj):
    assert path.parent == B
    temp = path.with_name('.' + path.name + '.' + uuid.uuid4().hex + '.tmp')
    with temp.open('xb') as f:
        f.write(json.dumps(obj, indent=2, ensure_ascii=False, allow_nan=False).encode('utf-8'))
        f.flush(); os.fsync(f.fileno())
    os.replace(temp, path)


def main():
    protocol = gate.read(HERE / 'PROTOCOL.json')
    for path, digest in protocol['protected_files'].items():
        assert gate.sha(path) == digest, path
    stored = gate.read(HERE / 'FIXED_FORECAST_ACCOUNTING.json')
    trace = gate.read(HERE / 'STORED_DECISION_TRACE.json')
    assert stored['fits'] == trace['fits'] == 0
    probability_hashes = {}
    for path, digest in gate.read(HERE / 'TRACE_PROTOCOL.json')['raw_hashes'].items():
        assert gate.sha(path) == digest
        with zipfile.ZipFile(path) as z, z.open('CONTEXT_probabilities.npy') as f:
            probability_hashes[Path(path).stem] = hashlib.file_digest(f, 'sha256').hexdigest()
    equal = len(set(probability_hashes.values())) == 1
    sources = [
        'spike_specialist_v7_20260930/RESULT.json',
        'spike_specialist_v7_20260930/AUDIT.json',
        'spike_specialist_v7_20260930/worker.py',
        'v7_preservation_review_20260930/FIXED_OUTPUT_DIAGNOSIS.json',
        'v7_confirmation_20260930/RESULT.json',
        'v7_confirmation_20260930/AUDIT.json',
        'calibration_recurrence_v15_20260930/DECISION.json',
        'conditional_risk_v17_20260930/DECISION.json',
        'mechanism_repair_v18_20260930/EUROPE_FIXED_OUTPUT_ATTRIBUTION.json',
        'retention_diagnosis_v20_20260930/NEXT_DECISION.json',
        'multi_round_mechanism_v21_20261001/PRIOR_WORK_REVIEW.json',
        'multi_round_mechanism_v21_20261001/graph_pilot/DECISION.json',
        'multi_round_mechanism_v21_20261001/fusion_pilot/DECISION.json',
        'multi_round_mechanism_v21_20261001/conflict_pilot/OUTCOME_REVIEW.json',
        'multi_round_mechanism_v21_20261001/horizon_pilot/DECISION.json',
        'context_identifiability_v22_20261001/OUTCOME_REVIEW.json',
        'context_identifiability_v22_20261001/ATTRIBUTION.json',
    ]
    evidence = {str(B / rel): gate.sha(B / rel) for rel in sources}
    evidence.update({str(HERE / n): gate.sha(HERE / n) for n in ['PROTOCOL.json', 'TRACE_PROTOCOL.json', 'FIXED_FORECAST_ACCOUNTING.json', 'STORED_DECISION_TRACE.json']})
    findings = [
        {
            'problem': 'S2 onset error', 'certainty': 'Implementation and fixed-output accounting established; upstream predictability unknown',
            'observed': 'All976 S2 cells in each seed equal pre-specialist BASE exactly. The added V7 expert activates only at already-extreme origins.',
            'new_quantification': {'fraction_of_V7_S2_SSE_left_even_by_hindsight_best_FULL_V7_convex_combination': [r['states'][2]['interval_lower_bound_sse_fraction_of_V7'] for r in stored['seeds']]},
            'interpretation': 'Changing weights between this frozen pair has almost no S2 repair capacity. The bound does not cover a new onset expert or additional information.',
            'next_discriminator': 'Audit existing onset timing/recall evidence, actual prior-publication stress information, signed amplitude error and false-alarm cost on earlier-only records. V15 onset score improvement alone did not repair prices.',
            'not_justified': 'Another FULL/V7 fallback gate advertised as an onset solution.',
        },
        {
            'problem': 'S3 harmful reversions', 'certainty': 'Proximate forecast-decision failure established; root information/estimation cause unresolved',
            'observed': 'S3 MAE improves while RMSE worsens. All positive added S3 SSE comes from wrong-direction corrections, not crossing the truth too far in an initially correct direction.',
            'new_quantification': {'wrong_direction_harm_share': [r['states'][3]['wrong_direction_share_of_positive_added_sse'] for r in stored['seeds']],
                                   'dominant_origin_share': [r['states'][3]['largest_origin_share_of_positive_added_sse'] for r in stored['seeds']]},
            'trace': 'On harmful S3 cells, mean S3 probability is0.1713-0.1887; original forecast averages128-135, correction raises it to170-180 while truth averages67USD/MWh. This is a retrospective error-conditioned summary, not an inference rule.',
            'implementation': 'Estimated mixture mean and median agreeing on direction triggers a fixed0.75 movement toward the nearer functional. Probability-dependent functionals vary; the final0.75 fraction is not a calibrated probability of improvement.',
            'next_discriminator': 'Trace pre-origin recovery signals, conditional probability reliability and amplitude estimation separately across distinct past event dates. Do not use future S3 labels to route.',
            'not_justified': 'A blanket spike upweight/downweight or repeating V15/V17 without a distinct evidence-supported mechanism.',
        },
        {
            'problem': 'Rich-context generalization', 'certainty': 'Observed matched contrast; overfitting/shift are explanations consistent with it, not uniquely identified causes',
            'scope': 'V22:2024H2 earlier-only folds,21UTCdates/9week blocks; not the V7 698-origin panel and excludes S2',
            'observed': '153-feature CONTEXT fits all4 TRAIN folds better than46-feature PRICE; future Brier is0.842590 versus0.586854. Equal-date scoring and deleting one evaluation date do not reverse CONTEXT loss.',
            'next_discriminator': 'Separate information novelty from fitting variance and probability calibration. Current evidence cannot show that all context is useless or that no onset signal exists.',
            'not_justified': 'More context dimensions or deeper routers solely because existing probability scores are poor.',
        },
        {
            'problem': 'Graph and fusion comparisons', 'certainty': 'Performance directions/code facts established; unique architectural bottleneck not established',
            'scope': 'European2015 graph pilot, CAISO June3397 fusion pilot and V7 development are distinct populations and versions.',
            'observed': 'Graph already has history-dependent scores/top-k; Europe3markets/top_k2 retains both neighbours. Sparse pilot selected epoch0. Gated value-interaction pilot improved aggregate MAE0.2932% but remained behind CONCAT2.7108% and regressed H12/S3/S4.',
            'optimization': 'Gradient conflicts were measured, but matched SUM/PCGrad continuations all18selectedepoch0. Removing local gradient conflict was insufficient in this frozen-adapter setting.',
            'next_discriminator': 'Establish reproducible conditional incremental information on identical earlier-only panels; distinguish graph redundancy, estimation cost, fusion representation loss and training-budget effects. Existing data do not select one of these as the sole cause.',
            'not_justified': 'Claiming node count causes graph failure, renaming two-way softmax as sigmoid, or treating pooled ensemble gains as proof of dynamic graph contribution.',
        },
        {
            'problem': 'Statistical evidence and validation', 'certainty': 'Design limitations established',
            'observed': 'V7 S3/S5 occupy10/9UTCdates. Many overlapping node-horizon cells do not provide that many independent events. The three stored V7 CONTEXT probability arrays are byte-identical, while backbone forecasts differ by seed.',
            'interpretation': 'The three seeds describe pipeline/backbone variation; they are not three independently varying routing realizations or three independent time samples. Do not infer a failed model solely from non-significance.',
            'deployment_scope': 'The186-origin September V7_FROZEN evaluation uses frozen deployment of the latest calibration state; the698-origin development result uses expanding-fold evaluation. They must not be numerically pooled or described as identical online deployment.',
            'next_discriminator': 'Quantify effect uncertainty using actual event/date support and retain all comparison families. A new candidate still needs a newly admitted final panel; current earlier tests have been inspected.',
            'not_justified': 'Dropping Holm, adding seeds as pseudo-independent days, or reporting exploratory repeated-selection gains as fresh confirmation.',
        },
    ]
    policy = {
        'at': gate.now(), 'status': 'diagnosis_first_no_automatic_candidate_launch',
        'user_instruction': protocol['user_request'],
        'mandatory_core_unchanged': True, 'V7_and_manuscript_preserved': True,
        'allowed_now': ['existing-evidence review', 'fit-free error accounting', 'implementation and provenance checks', 'primary-literature review'],
        'new_training_authorized_by_this_step': False,
        'resume_criteria': [
            'Specify which concrete failure the candidate addresses on which fixed population.',
            'Separate measured facts, ruled-out explanations and unresolved hypotheses.',
            'Provide a discriminating check showing why the proposed change addresses the failure and differs from closed V15/V17/V21 routes.',
            'Bind a finite matched comparison and preservation criteria before fitting; retain V7 as fallback.',
            'Keep new final-test source admission and freeze separate; no viewed-test tuning.',
        ],
        'clarification': 'Historical training permissions do not by themselves trigger a next candidate while this diagnosis-first stage is active. This turn closes with no next model queued.',
        'periodic_wakeups': False, 'numeric_worker_active': False,
    }
    report = {'at': gate.now(), 'status': 'evidence_accounting_complete_upstream_causes_partly_unresolved',
              'findings': findings, 'evidence_hashes': evidence,
              'routing_probability_array_hashes': probability_hashes,
              'routing_probability_arrays_identical': equal,
              'literature': [
                  {'url': 'https://arxiv.org/abs/0912.0902', 'use': 'Absolute and squared-error objectives require distinct forecast functionals. Does not prove the present regressions are unavoidable.'},
                  {'url': 'https://www.janmagnus.nl/papers/JRM113a.pdf', 'doi': '10.1016/j.ijforecast.2015.12.005', 'use': 'Estimated combination weights add estimation uncertainty; more flexible weights are not automatically better. Author PDF inspected.'},
                  {'url': 'https://sites.stat.washington.edu/people/raftery/Research/PDF/Gneiting2007jasa.pdf', 'use': 'Probability scoring and calibration must be evaluated distinctly from point-price errors.'},
                  {'url': 'https://jmlr.org/papers/v11/cawley10a.html', 'use': 'Repeated finite-sample model selection can overfit selection criteria; reduce unsupported trial expansion.'},
                  {'url': 'https://arxiv.org/abs/2008.08004', 'use': 'EPF evaluation needs fair baselines, chronological coverage and appropriate significance testing.'},
              ],
              'fits': 0, 'new_test_targets_read': False, 'forecasts_modified': False,
              'protected_files_verified': len(protocol['protected_files']),
              'audit_scope': 'Separate algebra, compensated sums, saved intermediate replay and artifact hashes; same operator, no external-human audit.',
              'next_action': 'No next model queued. Finish discriminating evidence for unresolved mechanisms before proposing one targeted matched modification.',
              'complete_research_experiment': False}
    write('ROOT_CAUSE_REVIEW.json', report)
    write('DIAGNOSIS_FIRST_POLICY.json', policy)
    atomic_at(B / 'TASK_DIAGNOSIS_FIRST_REVISION_20261001.json', policy)
    h = gate.read(B / 'HANDOFF.json')
    if not (HERE / 'HANDOFF_before.json').exists(): write('HANDOFF_before.json', h)
    h.update(status='diagnosis_first_no_new_model_queued', research_training_active=False,
             complete_research_experiment=False, next_action=report['next_action'],
             root_cause_review_20261001={'at': gate.now(), 'review': str(HERE/'ROOT_CAUSE_REVIEW.json'),
                 'policy': str(B/'TASK_DIAGNOSIS_FIRST_REVISION_20261001.json'), 'fits': 0,
                 'new_test_targets_read': False, 'V7_preserved': True, 'numeric_worker_active': False})
    atomic_at(B/'HANDOFF.json', h)
    print(json.dumps({'status': report['status'], 'fits': 0, 'protected_files': len(protocol['protected_files']), 'next_model_queued': False}))


if __name__ == '__main__':
    main()
