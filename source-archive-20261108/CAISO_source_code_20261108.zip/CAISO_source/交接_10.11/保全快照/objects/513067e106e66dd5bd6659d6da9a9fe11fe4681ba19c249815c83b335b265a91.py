import common as c
def main():
    p=c.verify()
    with c.gate.exclusive('Independent SUM/PCGrad scoring and checkpoint replay'):
        np,torch,lim=c.gate.runtime(True)
        from compiled_data import CompiledData
        from model import Adapter,encode,decode
        data=CompiledData(c.read(c.F/'PROTOCOL.json')['dataset_manifest']);limits=c.read(data.paths['context_limits.json'])['limits']
        cases=[];checks=0
        for case in p['cases']:
            c.check();r=c.read(c.HERE/'runs'/case['run_id']/'result.json')
            for key in ('checkpoint','prediction'):assert c.sha(r[key])==r[key+'_sha256'];checks+=1
            with np.load(r['prediction'],allow_pickle=False) as z:pr=z['prediction'];truth=z['truth'];codes=z['codes'];origins=z['origins']
            assert np.array_equal(origins,data.origins['june_dense']);checks+=1
            reg=data.origins['june'];_,inv,count=np.unique(origins//12,return_inverse=True,return_counts=True)
            panels={'June3397':np.arange(len(origins)),'June284':np.flatnonzero(np.isin(origins,reg)),'balanced278':np.flatnonzero(count[inv]==12)}
            for panel,ix in panels.items():
                e=pr[ix]-truth[ix];m=r['metrics'][panel]
                for key,val in [('mae',np.abs(e).mean()),('rmse',np.sqrt((e**2).mean())),('near_h1_4_mae',np.abs(e[:,:,:4]).mean()),('h12_mae',np.abs(e[:,:,-1]).mean())]:assert abs(m[key]-val)<1e-9;checks+=1
                groups=[(m['by_horizon'][h],e[:,:,h]) for h in range(12)]+[(m['by_node'][n],e[:,n,:]) for n in range(30)]+[(m['by_state'][s],e[codes[ix]==s]) for s in range(6)]
                for reported,err in groups:
                    assert reported['count']==err.size;checks+=1
                    if err.size:assert abs(reported['mae']-np.abs(err).mean())<1e-9 and abs(reported['rmse']-np.sqrt((err**2).mean()))<1e-9;checks+=2
            selected=r['history'][0]
            for item in r['history'][1:]:
                if item['metrics']['June3397']['mae']<selected['metrics']['June3397']['mae']-1e-6:selected=item
            assert selected['epoch']==r['selected_epoch'];checks+=1
            base=c.fc.case_model(case,torch,limits);a=Adapter(case['seed']);a.load_state_dict(torch.load(r['checkpoint'],map_location='cpu',weights_only=False)['adapter'])
            with torch.no_grad():
                for i in (0,len(origins)//2,len(origins)-1):
                    x,y=data.batch('june_dense',[i]);v,_=encode(base,torch.from_numpy(x),case['variant']);pred=decode(base,case['variant'],v,a).numpy().astype(np.float64)*data.scale[None,:,None]+data.center[None,:,None]
                    assert np.allclose(pred[0],pr[i],rtol=1e-5,atol=1e-4);checks+=1
            cases.append(r)
        agg={}
        for arm in ('SUM','PCGRAD'):
            agg[arm]={}
            for variant in ('FULL','EQUAL','CONCAT'):
                subset=[r for r in cases if r['case']['arm']==arm and r['case']['variant']==variant];assert len(subset)==3
                ms=[r['metrics']['June3397'] for r in subset]
                a={k:float(np.mean([m[k] for m in ms])) for k in ('mae','rmse','near_h1_4_mae','h12_mae')}
                a['states']=[dict(state=s,count=ms[0]['by_state'][s]['count'],**{k:float(np.mean([m['by_state'][s][k] for m in ms])) if ms[0]['by_state'][s]['count'] else None for k in ('mae','rmse')}) for s in range(6)]
                agg[arm][variant]=a
        for seed in (20260813,20260814,20260815):
            for v in ('FULL','EQUAL','CONCAT'):
                pair=[r for r in cases if r['case']['seed']==seed and r['case']['variant']==v]
                assert pair[0]['normal']==pair[1]['normal'];checks+=1
                assert pair[0]['history'][0]['metrics']==pair[1]['history'][0]['metrics'];checks+=1
        original=c.read(c.F/'RESULT.json')['aggregate']['FULL']['parent_metrics'];new=agg['PCGRAD']['FULL'];summed=agg['SUM']['FULL']
        gain=100*(original['mae']-new['mae'])/original['mae']
        wins=0
        for r in cases:
            if r['case']['arm']=='PCGRAD' and r['case']['variant']=='FULL':wins+=r['metrics']['June3397']['mae']<c.read(r['case']['f_result'])['parent_metrics']['June3397']['mae']-1e-6
        cond=dict(beats_SUM=new['mae']<summed['mae'],beats_EQUAL=new['mae']<agg['PCGRAD']['EQUAL']['mae'],beats_CONCAT=new['mae']<agg['PCGRAD']['CONCAT']['mae'],half_percent_gain=gain>=.5,two_seed_wins=wins>=2,
            headline_retention=all(new[k]<=original[k]+1e-9 for k in ('rmse','near_h1_4_mae','h12_mae')),
            states_retained=all(s['count'] and all(s[k]<=o[k]+1e-9 for k in ('mae','rmse')) for s,o in zip(new['states'],original['states'])))
        c.fc.preserved();checks+=17
        c.write(c.HERE/'RESULT.json',dict(at=c.now(),scope='TRAIN/June3397development only;3seed error means, USD/MWh',aggregate=agg,original_FULL=original,cases=[dict(id=r['case']['run_id'],epoch=r['selected_epoch']) for r in cases],V7_preserved=True,new_test_targets_read=False))
        c.write(c.HERE/'DECISION.json',dict(at=c.now(),passed=all(cond.values()),conditions=cond,mae_gain_percent=gain,seed_wins=int(wins),model_promoted=False,V7_preserved=True,complete_research_experiment=False))
        c.write(c.HERE/'AUDIT.json',dict(at=c.now(),status='passed',checks=checks,result_sha256=c.sha(c.HERE/'RESULT.json'),decision_sha256=c.sha(c.HERE/'DECISION.json'),scope='Separate error formulas and raw-input checkpoint replay, same operator',V7_preserved=True,new_test_targets_read=False))
        print({'audit':'passed','checks':checks,'pilot_passed':all(cond.values())})
if __name__=='__main__':main()
