"""Observed recovery/result state and event deduplication, retaining past evidence."""
from pathlib import Path
import os, json, hashlib, psutil
from datetime import datetime,timezone
R=Path(__file__).resolve().parent;W=R.parent;Z=W.parent;B=Z.parent.parent
def read(p):return json.loads(p.read_text(encoding='utf-8-sig'))
def sha(p):
    h=hashlib.sha256()
    with Path(p).open('rb') as f:
        for a in iter(lambda:f.read(1024*1024),b''):h.update(a)
    return h.hexdigest()
def write(p,v):
    t=p.with_name('.r'+os.urandom(5).hex());t.write_text(json.dumps(v,ensure_ascii=False,indent=2,allow_nan=False),encoding='utf-8');os.replace(t,p)
def update(p,fn):
    raw=p.read_bytes();v=json.loads(raw.decode('utf-8-sig'));fn(v);assert p.read_bytes()==raw;write(p,v)
def main():
    launch=read(R/'LAUNCH.json');status=read(R/'STATUS.json');at=datetime.now(timezone.utc).isoformat()
    try:
        proc=psutil.Process(launch['manager_pid'])
        alive=abs((launch['manager_start_utc_ticks']-621355968000000000)/1e7-proc.create_time())<.01 and str(R/'manager.py') in proc.cmdline()
    except psutil.NoSuchProcess:alive=False
    done=(W/'RESULT.json').exists() and status['event']=='finite_mechanism_queue_completed'
    receipt=read(Path(launch['receipt']));assert receipt['manager_pid']==launch['manager_pid'] and receipt['watcher_pid']==launch['exit_monitor_pid']
    if alive and not done:assert psutil.pid_exists(launch['exit_monitor_pid'])
    listeners=[p.pid for p in psutil.process_iter(['cmdline']) if any(str(B/'event_driven_automation/watch.ps1').lower().replace('/','\\')==a.lower().replace('/','\\') for a in p.info['cmdline'] or [])]
    assert len(listeners)==1
    source=read(B/'event_driven_automation/inbox/wi_65d4c015b101cbe0c7d98577.json')
    assert sha(W/'FAILURE.json')==source['evidence_sha256']
    progress=read(R/'PROGRESS.json')
    review=dict(at=at,status='completed_registered_prefix_queue' if done else 'io_repaired_remaining_fits_running' if alive else 'inspect_stopped_recovery',source_event_id=source['event_id'],delivery_event_id='954866c0684ef2756922314097f2586ca497eb5c05bae2fd47d99ba31cc129d9',root_cause='263-character Windows temporary filename; unchanged model/data protocol',recovery_qa=str(R/'QA.json'),launch=launch,manager_alive=alive,event_listener_pid=listeners[0],progress=progress,original_failure_preserved_sha256=sha(W/'FAILURE.json'),original_protocol_preserved_sha256=sha(W/'PROTOCOL.json'),new_fits_remaining_at_resume=3,completed_model_cells_retained=3,V7_replaced=False,new_test_targets_read=False,periodic_model_wakeups=False,whole_research_completed=False)
    evidence=[R/'QA.json',R/'PROTOCOL.json',W/'FAILURE.json',W/'PROTOCOL.json']
    if done:
        result=read(W/'RESULT.json');audit=read(W/'AUDIT.json')
        assert audit['passed'] and result['audit_sha256']==sha(W/'AUDIT.json')
        review.update(result_event_id=status['event_id'],information_candidate_promising=result['information_candidate_promising'],new_model_fits=result['new_model_fits'],reused_models=result['reused_models'],independent_formula_replay=True,independent_person_review=False,protected_files_unchanged=audit['protected_files_unchanged'],next='Close grouped-weather candidate if failed. Preserve scoped rolling/coarse gains; no automatic V7 admission. Source-granularity and congestion evidence still required.')
        evidence += [W/'RESULT.json',W/'AUDIT.json']
        for path,h in read(Z/'PROTECTED_FILES.json').items():assert sha(path)==h
    review['evidence']={str(p):sha(p) for p in evidence}
    write(R/('FINAL_REVIEW.json' if done else 'RUNNING_REVIEW.json'),review)
    reviewpath=str(R/('FINAL_REVIEW.json' if done else 'RUNNING_REVIEW.json'))
    def hu(h):
        h.update(current_stage=review['status'],current_process=launch,manager_pid=launch['manager_pid'] if alive else None,event_listener_pid=listeners[0],numeric_diagnostic_active=alive and not done,training_active=alive and not done,research_training_active=alive and not done,latest_weather_extension=reviewpath,last_handled_event=review)
        h['weather_prefix_stability_20261009']=review
        e=h['mechanism_weather_extension_20261007']
        e.update(at=at,stage=review['status'],active_numeric_job=alive and not done,training_active=alive and not done,manager_pid=launch['manager_pid'] if alive else None,manager_start_utc_ticks=launch['manager_start_utc_ticks'],exit_monitor_pid=launch['exit_monitor_pid'],exit_monitor_receipt=launch['receipt'],active_script=str(R/'manager.py') if alive else None,latest_attempt=launch,latest_progress=progress,latest_progress_observed_at=at,latest_event_review=reviewpath,next_queue_status='Registered queue complete, candidate gate failed' if done and not result['information_candidate_promising'] else review['status'])
        ids=h.setdefault('handled_event_ids',[])
        for eid in [source['event_id'],review['delivery_event_id']]+([status['event_id']] if done else []):
            if eid not in ids:ids.append(eid)
    def lu(h):
        h.update(at=at,status=review['status'],current_launch=launch,latest_attempt=launch,latest_review=reviewpath,latest_progress_review=reviewpath,next_queue_status=review['status'],no_duplicate_restart=True)
        ids=h.setdefault('handled_event_ids',[])
        for eid in [source['event_id'],review['delivery_event_id']]+([status['event_id']] if done else []):
            if eid not in ids:ids.append(eid)
    update(B/'HANDOFF.json',hu);update(Z/'REVIEWED_SOURCE_EVENTS.json',lu)
    print(json.dumps(dict(status=review['status'],alive=alive,done=done,listener=listeners[0],review=reviewpath),ensure_ascii=False))
if __name__=='__main__':main()
