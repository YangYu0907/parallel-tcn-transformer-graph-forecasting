"""Post-result attribution only: no fit, selection, threshold change or price replay."""
import common as c

def main():
    p=c.verify();r=c.read(c.HERE/'RESULT.json');a=c.read(c.HERE/'AUDIT.json')
    assert a['status']=='passed' and a['result_sha256']==c.sha(c.HERE/'RESULT.json')
    with c.gate.exclusive('V23 fit-free attribution and closure'):
        np,lim=c.gate.runtime(False)
        with np.load(p['library'],allow_pickle=False) as z:d={k:z[k] for k in z.files}
        with np.load(r['output'],allow_pickle=False) as z:o={k:z[k] for k in z.files}
        folds=[]
        for f in r['folds']:
            with np.load(f['replay'],allow_pickle=False) as z:q={k:z[k] for k in z.files}
            parts={}
            for name in ('fit','cal','test'):
                ix=q[name+'_indices'];y=d['states'][ix]-3
                days,counts=np.unique(d['issued'][ix]//86400,return_counts=True)
                parts[name]=dict(pairs=len(ix),dates=len(days),largest_date_share=float(counts.max()/counts.sum()),h1_exit_rate=float((y[:,0]<2).mean()),destination_shares=np.bincount(y.ravel(),minlength=3).astype(float).__truediv__(y.size).tolist())
            h1={}
            for kind in ('LEGACY','NATURAL'):
                for sample in ('cal','test'):
                    raw=q[f'{kind}_hazard_{sample}_raw'][::12,1]
                    t=f['temperatures'][kind+'_hazard'][kind]['temperature']
                    cal=c.temperature(np.column_stack([1-raw,raw]),t,np)[:,1]
                    y=(d['states'][q[sample+'_indices'],0]<5).astype(int)
                    h1[kind+'_'+sample]=dict(temperature=t,raw_mean=float(raw.mean()),calibrated_mean=float(cal.mean()),actual=float(y.mean()),raw_brier=float(np.square(raw-y).mean()),calibrated_brier=float(np.square(cal-y).mean()))
            folds.append(dict(month=f['month'],support=parts,h1=h1))
        m=r['metrics'];base=m['LEGACY'];cand=m['NATURAL_SUPPORT']
        gains={k:100*(base[k]-cand[k])/base[k] for k in ('brier','logloss')}
        states=[]
        for old,new in zip(base['states'],cand['states']):
            states.append(dict(state=old['state'],brier_reduction_percent=100*(old['brier']-new['brier'])/old['brier'],logloss_reduction_percent=100*(old['logloss']-new['logloss'])/old['logloss']))
        temperature_boundary=sum(v['temperature']>1.999 for f in r['folds'] for k,vv in f['temperatures'].items() for objective,v in vv.items() if objective==k.split('_')[0])
        close=dict(at=c.now(),status='closed_failed_prespecified_probability_screen',V7_action='Retain unchanged; no integration, no new price result.',
          improvements_percent=gains,state_probability_changes=states,winning_months=[f['month'] for f in r['folds'] if f['metrics']['NATURAL_SUPPORT']['brier']<f['metrics']['LEGACY']['brier']],
          candidate_vs_prior_brier_increase_percent=100*(cand['brier']/m['PRIOR']['brier']-1),temperatures_at_upper_bound_out_of16=temperature_boundary,
          attribution=dict(training_objective_brier_gain_with_legacy_calibration=m['LEGACY']['brier']-m['NATURAL_LEGCAL']['brier'],calibration_objective_gain_given_natural_fit=m['NATURAL_LEGCAL']['brier']-m['NATURAL']['brier'],support_rule_brier_cost_given_natural_fit=m['NATURAL_SUPPORT']['brier']-m['NATURAL']['brier']),
          scope='2024H2 earlier-only observed-extreme development:1611origin-node pairs,19332cells,21dates,9calendar-week blocks. Not the 698-origin V7 price panel and not a new independent test.',
          facts=['Natural objective modestly improves pooled probability losses versus matched legacy reconstruction;95percent paired-week interval crosses zero.',
                 'Candidate improves September and December only; S4 probability losses worsen while S3 and S5 improve.',
                 'H1 probability Brier improves but AUC falls, separating calibration/magnitude from ranking.',
                 'Structural support correction is logically required for this first-step factorization but is numerically small and slightly worsens pooled Brier.',
                 'The same-fit-history simple per-horizon prior has substantially lower pooled loss. No evidence supports deploying this richer classifier.',
                 'All seventeen protected files remain unchanged; this experiment generated no new price forecasts.'],
          hypotheses=['Scarce, date-concentrated event samples and changing state proportions may impair transfer of the151-context classifier. This comparison does not uniquely separate feature instability, model capacity and regime shift.',
                      'Temperature saturation suggests scale-only calibration has insufficient flexibility, but relaxing bounds or adding an intercept after viewing these results would be a new experiment.'],
          next_decision='Close this probability-objective route as a standalone repair. Before any new fit, establish adequate temporally dispersed earlier event support and a fixed low-capacity price-only comparator; do not change V7 or tune against already inspected confirmation panels. No further fit queued.',
          protected_files_verified=c.preserved(),new_test_targets_read=False,additional_fits=0,complete_research_experiment=False,
          bindings={'result':c.sha(c.HERE/'RESULT.json'),'audit':c.sha(c.HERE/'AUDIT.json'),'script':c.sha(__file__)},fold_support=folds)
        c.write(c.HERE/'DECISION.json',close)
        print({k:close[k] for k in ['improvements_percent','state_probability_changes','winning_months','candidate_vs_prior_brier_increase_percent','temperatures_at_upper_bound_out_of16','attribution']})
        print('V23 closed. V7 retained. No additional fit queued.')

if __name__=='__main__':main()
