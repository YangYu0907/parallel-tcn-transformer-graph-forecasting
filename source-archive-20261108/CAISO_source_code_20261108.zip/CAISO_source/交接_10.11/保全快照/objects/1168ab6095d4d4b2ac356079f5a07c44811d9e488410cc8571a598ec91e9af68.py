"""Independent source/group/date checks without additional real-model fits."""
from pathlib import Path
import sys,json
import numpy as np
W=Path(__file__).resolve().parent;Z=W.parent;sys.path.insert(0,str(Z))
import support as s
from datetime import datetime,timezone
def stamp(d):return int(datetime.fromisoformat(d).replace(tzinfo=timezone.utc).timestamp())
from features import at_times
def main():
 p=s.read(W/'PROTOCOL.json');old=s.read(Z/'PROTOCOL.json');sp=s.read(Path(old['short_context_protocol']))
 checks=[]
 with s.base.numeric('Prefix weather chronology and feature QA, zero new fits'):
  s.guard(True)
  with np.load(W/'INDICES.npz') as a:v={k:a[k] for k in a.files}
  with np.load(Z/'ROWS.npz') as a:origin=a['origin'];cuts=a['cutoff'];cycles=a['cycle']
  with np.load(sp['publications']) as a:published=a['price_last_publication_seconds'];ts=a['timestamps_seconds']
  available=np.max(published[origin[:,None]+np.arange(12)],axis=1)[v['weather_row']]
  end=np.max(ts[origin[:,None]+np.arange(12)],axis=1)[v['weather_row']]
  for f in p['folds']:
   fit=v[f['name']+'_fit'];cal=v[f['name']+'_cal'];ev=v[f['name']+'_eval']
   assert available[fit].max()<=stamp(f['fit_freeze']) and end[fit].max()<stamp(f['fit_freeze'])
   assert available[cal].max()<=stamp(f['cal_freeze']) and end[cal].max()<stamp(f['cal_freeze'])
   assert v['time'][cal].min()>=stamp(f['cal_start'])
   assert v['time'][ev].min()>=stamp(f['eval_start']) and v['time'][ev].max()<stamp(f['eval_end'])
   assert not np.intersect1d(fit,cal,assume_unique=True).size and not np.intersect1d(cal,ev,assume_unique=True).size
   checks.append(f['name']+'_all_label_maturity_and_purge')
  fit1=v['Q1_2025_fit'];fit2=v['Q2_partial_2025_fit'];assert np.isin(fit1,fit2).all() and len(fit2)>len(fit1);checks.append('strict_expanding_fit_prefix')
  grouped=np.load(W/'weather_GROUPED.npy',mmap_mode='r')
  for ix in [0,len(cuts)//4,len(cuts)//2,3*len(cuts)//4,len(cuts)-1]:
   r=s.read(Z/'cycles'/f'{cycles[ix]}.json');x=at_times(np.asarray(r['center_values']),int(cycles[ix]),int(cuts[ix]))
   wind=np.linalg.norm(x[[4,5]][:,old['wind_anchor_indices']],axis=0)
   expected=np.hstack([x[0,:3].reshape(-1),np.sum(wind,axis=0)/6,np.sqrt(np.sum((wind-wind.mean(0))**2,axis=0)/6),
                      (x[6,9]+x[6,10])/2,(x[7,9]+x[7,10])/2,np.sum(x[0,:3]-x[1,:3],axis=0)/3]).astype(np.float32)
   assert expected.shape==(24,) and np.allclose(expected,grouped[ix],rtol=2e-7,atol=2e-7)
  checks.append('independent_group_feature_formula_5timestamps')
  # Counterexample: an earlier event with a late publication must not enter fitting.
  now=10000;event_end=np.array([9999,9999,10000]);release=np.array([9999,10001,9999])
  keep=(event_end<now)&(release<=now);assert keep.tolist()==[True,False,False];checks.append('late_release_and_boundary_rejected')
  q=s.read(Z/'fit4_1009/ENGINEERING_QA.json');assert q['passed'];checks.append('existing_stock_sklearn_bitexact_adapter_proof_reused')
  for file,digest in p['bindings'].items():assert s.sha(file)==digest,file
  for file,digest in s.read(Z/'PROTECTED_FILES.json').items():assert s.sha(file)==digest,file
  s.base.write(W/'QA.json',dict(at=s.now(),passed=True,checks=checks,new_model_fits=0,independent_person_review=False,bindings={str(a):s.sha(a) for a in [W/'PROTOCOL.json',Path(__file__)]}))
 print(json.dumps(dict(passed=True,checks=checks,resources=s.guard()),ensure_ascii=False))
if __name__=='__main__':main()
