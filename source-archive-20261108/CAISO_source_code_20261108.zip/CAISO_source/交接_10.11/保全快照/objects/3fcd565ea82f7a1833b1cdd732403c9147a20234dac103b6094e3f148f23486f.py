"""Matched fixed deployment; cached predictors only, no September targets or fitting."""
from pathlib import Path
import sys,json,os,time,hashlib,importlib.util,traceback
H=Path(__file__).resolve().parent;B=H.parent;O=B/'v7_confirmation_20260930';V=B/'mechanism_repair_v18_20260930';T=Path('C:/Users/于阳/CAISO_temporary_storage');A=T/H.name
sys.path.insert(0,str(B/'context_expert_v1_20260929'));import gate
def read(p):return json.loads(Path(p).read_text(encoding='utf-8-sig'))
def write(p,v):
 p=Path(p);assert p.resolve().is_relative_to(H) or p.resolve().is_relative_to(A);p.parent.mkdir(parents=True,exist_ok=True)
 t=p.with_suffix('.tmp');t.write_text(json.dumps(v,ensure_ascii=False,indent=2,allow_nan=False),encoding='utf-8');os.replace(t,p)
def verify(p):
 for path,h in {**p['bindings'],**p['protected']}.items():assert gate.sha(path)==h,path
def module(name,path):
 spec=importlib.util.spec_from_file_location(name,path);m=importlib.util.module_from_spec(spec);spec.loader.exec_module(m);return m
def main():
 p=read(H/'PROTOCOL.json');verify(p);start=time.monotonic();assert not (H/'PREDICTIONS_COMMITTED.json').exists()
 def pulse(**kw):
  gate.guard();assert time.monotonic()-start<p['budget_seconds'],'Finite inference budget'
  assert not any((H/n).exists() for n in ['STOP_REQUESTED','STOP_REQUESTED.json']),'User stop'
  if kw:write(H/'queue/status.json',dict(at=gate.now(),pid=os.getpid(),**kw))
 with gate.exclusive('V19 matched frozen deployment;zero fits'):
  np,lim=gate.runtime(False);w=module('v19_original_pipeline',O/'pipeline.py');w.np=np
  m=module('v19_registered_combiner',H/'combine_registered.py')
  for k in ['B','A4','A5','A7','V7','SEEDS','load','read','dense','legacy']:setattr(m,k,getattr(w,k))
  m.np=np;m.gate=gate;m.write=write;m.pulse=pulse
  def save(path,**arrays):
   path.parent.mkdir(parents=True,exist_ok=True);temp=path.with_suffix('.tmp')
   with temp.open('wb') as f:np.savez_compressed(f,**arrays)
   os.replace(temp,path)
  m.save=save
  m.functional_path=lambda seed,anchor,k: (T/'adaptive_experts_v4_20260929/models'/f'{seed}_fold3_functional{k}.pkl') if anchor=='FULL' else (T/V.name/'CAISO/models'/f'{seed}_{anchor}_fold3_functional{k}.pkl')
  m.fold_path=lambda seed,anchor: (T/'adaptive_experts_v4_20260929/folds'/f'{seed}_fold3.npz') if anchor=='FULL' else (T/V.name/'CAISO/folds'/f'{seed}_{anchor}_3.npz')
  def devanchor(seed,anchor):
   if anchor=='FULL':
    with np.load(T/'adaptive_experts_v4_20260929/experts'/f'{seed}.npz') as z:return z['experts'][...,0]
   with np.load(B/'h1_final_evaluation_v1_20260927/predictions'/f'{seed}_{anchor}'/'predictions.npz') as z:return z['prediction']
  m.development_anchor=devanchor
  op=read(O/'PROTOCOL.json');outputs={};original={}
  for seed in p['seeds']:
   with np.load(T/O.name/'predictions'/f'{seed}_all.npz') as z:
    assert np.array_equal(z['origins'],p['origins']);original[seed]=z['V7_FROZEN']
    for c in op['models']:
     if c['seed']==seed:outputs[(seed,c['variant'])]=z[c['variant']]
  x=np.load(T/O.name/'features.npy',mmap_mode='r');committed={};exact=[]
  try:
   for anchor in p['anchors']:
    pulse(stage='fixed_matched_prediction',anchor=anchor)
    m.HERE=H/anchor;m.ART=A/anchor;m.HERE.mkdir(exist_ok=True);m.ART.mkdir(exist_ok=True)
    receipt=m.HERE/'COMBINER_AUDIT.json'
    if receipt.exists():
     for path,expected in read(receipt)['forecast_files'].items():assert gate.sha(path)==expected,path
    else:m.combine(op,x,outputs,anchor)
    ar=read(receipt);assert ar['status']=='passed';committed.update(ar['forecast_files'])
    for seed in p['seeds']:
     with np.load(m.ART/'predictions'/f'{seed}_all.npz') as z:
      pred=z['V7_FROZEN'];assert pred.shape==(186,30,12) and np.isfinite(pred).all()
      if anchor=='FULL':
       assert np.array_equal(pred,original[seed]);exact.append({'seed':seed,'maximum_difference':float(abs(pred-original[seed]).max())})
     state=read(m.HERE/'deployment_state'/f'{seed}.json');assert not state['new_test_feedback'] and state['last_feedback_publication']<=min(p['origins'])-300
   verify(p);write(H/'PREDICTIONS_COMMITTED.json',dict(at=gate.now(),status='predictions_complete_before_new_matched_scores',files=committed,V7_exact_replay=exact,protocol_sha256=gate.sha(H/'PROTOCOL.json'),new_test_target_values_read=False,scope=p['scope']))
   pulse(stage='awaiting_separate_scoring');print('Matched deployment predictions committed; all three V7 seeds exactly unchanged.',flush=True)
  finally:x._mmap.close()
if __name__=='__main__':
 try:main()
 except BaseException as e:write(H/'queue/STOP.json',dict(at=gate.now(),error=repr(e),traceback=traceback.format_exc(),artifacts_preserved=True));raise
