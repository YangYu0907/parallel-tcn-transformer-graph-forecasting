import common as c

def main():
    p=c.verify();r=c.read(c.HERE/'RESULT.json');checks=[]
    assert r['seal_sha256']==c.sha(c.HERE/'SEAL.json')
    with c.gate.exclusive('V26 separate replay and scoring audit'):
        np,torch,lim=c.gate.runtime(True)
        from model import Reader,manual
        manifest=c.read(p['dataset_manifest']);limits=c.read(c.B/manifest['artifacts']['context_limits.json']['path'])['limits']
        rows=[];paired={'PARENT':[],'SUMMARY':[]}
        def core(e):
            return dict(count=int(e.size),mae=float(abs(e).mean()) if e.size else None,
                        rmse=float(np.sqrt((e*e).mean())) if e.size else None)
        def equal(a,b,name):
            assert a['count']==b['count'],name
            for k in ('mae','rmse'):
                assert (a[k] is None and b[k] is None) or np.isclose(a[k],b[k],rtol=1e-12,atol=1e-10),(name,k)
            checks.append(name)
        for caseitem in r['cases']:
            c.check();case=caseitem['case'];base=c.base_model(case,limits,torch)
            cache=c.old_cache(case,'june_dense',np)
            memory=np.load(c.ART/case['id']/'june_dense/memory.npy',mmap_mode='r')
            receipt=c.read(c.ART/case['id']/'june_dense/receipt.json')
            assert c.sha(c.ART/case['id']/'june_dense/memory.npy')==receipt['sha256']
            summary={};arrays={}
            for arm,record in caseitem['arms'].items():
                assert record['base_fingerprint']==c.fingerprint(base)
                best=record['history'][0]
                for history in record['history']:
                    for name in ('prediction','checkpoint'):assert c.sha(history[name])==history[name+'_sha256']
                    with np.load(history['prediction']) as z:
                        pred,truth,codes,origins,registered,times=[z[k].copy() for k in ('prediction','truth','codes','origins','registered','timestamps')]
                    assert pred.shape==(3397,30,12) and np.isfinite(pred).all()
                    ids_hour=np.searchsorted(origins,registered);assert np.array_equal(origins[ids_hour],registered)
                    groups,counts=np.unique(origins//12,return_counts=True)
                    panel=dict(June3397=np.arange(3397),June284=ids_hour,balanced278=np.flatnonzero(np.isin(origins//12,groups[counts==12])))
                    error=pred-truth
                    for name,ids in panel.items():
                        e=error[ids];sc=codes[ids];saved=history['metrics'][name]
                        equal(core(e),saved,f'{case["seed"]}/{arm}/{history["epoch"]}/{name}/headline')
                        assert np.isclose(abs(e[:,:,:4]).mean(),saved['near_h1_4_mae'])
                        assert np.isclose(abs(e[:,:,11]).mean(),saved['h12_mae'])
                        for j in range(12):equal(core(e[:,:,j]),saved['by_horizon'][j],f'{name}/h{j}')
                        for j in range(30):equal(core(e[:,j,:]),saved['by_node'][j],f'{name}/node{j}')
                        for j in range(6):equal(core(e[sc==j]),saved['by_state'][j],f'{name}/state{j}')
                        for j in range(12):equal(core(e[origins[ids]%12==j]),saved['by_phase'][j],f'{name}/phase{j}')
                    # Independent matrix algebra replay across the complete date span.
                    ids=np.linspace(0,3396,12,dtype=int)
                    f=c.features(cache,ids,torch,np)
                    mem=torch.from_numpy(np.array(memory[ids],copy=True)) if arm=='TOKEN' else torch.stack([f['t']]*8+[f['z']]*8,2)
                    reader=Reader(case['seed']);cp=torch.load(history['checkpoint'],map_location='cpu',weights_only=False)
                    assert cp['seal']==r['seal_sha256'];reader.load_state_dict(cp['reader'])
                    with torch.no_grad():
                        fused=f['w'][...,:1]*f['t'].unsqueeze(2)+f['w'][...,1:]*f['z'].unsqueeze(2)
                        replay=base.head(manual(reader,fused,mem,base.head.horizon_embedding)+f['price'].unsqueeze(2)).numpy().astype(np.float64)
                    sca=c.read(c.B/manifest['artifacts']['scalers.json']['path'])
                    scale=np.array(sca['price_scale'])[0,:,0];center=np.array(sca['price_center'])[0,:,0]
                    assert np.allclose(pred[ids],replay*scale[None,:,None]+center[None,:,None],rtol=1e-5,atol=1e-4)
                    checks.append(f'{case["seed"]}/{arm}/{history["epoch"]}/independent_replay')
                    if history['metrics']['June3397']['mae']<best['metrics']['June3397']['mae']-1e-6:best=history
                assert best['epoch']==record['selected_epoch'] and best==record['selected']
                summary[arm]=best['metrics']['June3397']
                with np.load(best['prediction']) as z:arrays[arm]=abs(z['prediction']-z['truth']).mean(axis=(1,2))
                if arm=='TOKEN':
                    with np.load(record['history'][0]['prediction']) as z:arrays['PARENT']=abs(z['prediction']-z['truth']).mean(axis=(1,2))
                    summary['PARENT']=record['history'][0]['metrics']['June3397']
            # Independent recomputation of the finite expansion decision.
            t,s,b=[summary[k] for k in ('TOKEN','SUMMARY','PARENT')]
            first=(1-t['mae']/b['mae']>=.005 and t['mae']<s['mae']-1e-6 and
                   max(t[k]-b[k] for k in ('rmse','near_h1_4_mae','h12_mae'))<=0)
            assert first==caseitem['first_seed_passed']
            rows.append(dict(seed=case['seed'],metrics=summary,first_seed_passed=first,
                 state_date_support=[dict(state=j,dates=int(len(np.unique(times[np.any(codes==j,axis=(1,2))]//86400)))) for j in range(6)]))
            for comparator in paired:paired[comparator].append(arrays[comparator]-arrays['TOKEN'])
            del memory,cache
        assert len(rows)==3 or (len(rows)==1 and not rows[0]['first_seed_passed'])
        names=('mae','rmse','near_h1_4_mae','h12_mae')
        means={arm:{k:float(np.mean([x['metrics'][arm][k] for x in rows])) for k in names} for arm in ('PARENT','SUMMARY','TOKEN')}
        states={arm:[dict(state=j,**{k:float(np.mean([x['metrics'][arm]['by_state'][j][k] for x in rows]))
             if all(x['metrics'][arm]['by_state'][j][k] is not None for x in rows) else None for k in ('mae','rmse')}) for j in range(6)] for arm in means}
        conditions=dict(all_three_seeds=len(rows)==3,
            overall_half_percent=means['TOKEN']['mae']<=.995*means['PARENT']['mae'],
            beats_summary=means['TOKEN']['mae']<means['SUMMARY']['mae']-1e-6,
            at_least_two_seeds=sum(x['metrics']['TOKEN']['mae']<x['metrics']['PARENT']['mae'] for x in rows)>=2,
            headline_retained=all(means['TOKEN'][k]<=means['PARENT'][k] for k in names[1:]),
            state_retained=all(states['TOKEN'][j][k] is not None and states['TOKEN'][j][k]<=states['PARENT'][j][k]
                               for j in range(6) for k in ('mae','rmse')))
        # Pair whole real calendar weeks; observations remain origin-weighted within blocks.
        blocks=times//(86400*7);unique=np.unique(blocks);rng=np.random.default_rng(20261001)
        draws=rng.integers(len(unique),size=(2000,len(unique)))
        inference=[]
        for comparator,parts in paired.items():
            diff=np.mean(parts,axis=0);sums=np.array([diff[blocks==b].sum() for b in unique]);counts=np.array([(blocks==b).sum() for b in unique])
            mean=float(diff.mean());boot=sums[draws].sum(1)/counts[draws].sum(1)
            pv=float((1+np.sum(abs(boot-mean)>=abs(mean)))/2001)
            inference.append(dict(comparator=comparator,mae_gain=mean,interval95=np.quantile(boot,[.025,.975]).tolist(),p=pv,calendar_week_blocks=len(unique)))
        order=np.argsort([x['p'] for x in inference]);last=0.
        for rank,i in enumerate(order):last=max(last,min(1.,(2-rank)*inference[i]['p']));inference[i]['holm_p']=last
        c.protected()
        decision=dict(at=c.now(),passed=all(conditions.values()),conditions=conditions,mean_metrics=means,state_metrics=states,
            seeds=rows,inference=inference,scope=p['scope'],reader_fits=r['reader_fits'],
            next_action='If screen passes, first audit fully matched fusion controls and V7 integration on development; otherwise close this fixed pilot without extra tuning. No paper/V7 replacement from this screen.',
            result_sha256=c.sha(c.HERE/'RESULT.json'),V7_preserved=True,new_test_targets_read=False)
        c.write(c.HERE/'DECISION.json',decision)
        c.write(c.HERE/'AUDIT.json',dict(at=c.now(),status='passed',checks=len(checks),check_names=checks,
            result_sha256=c.sha(c.HERE/'RESULT.json'),decision_sha256=c.sha(c.HERE/'DECISION.json'),screen_passed=decision['passed'],
            independence='Separate scoring and matrix-algebra replay process, same operator; not external human review.',protected_files_verified=17))
        print('V26 audit passed:',len(checks),'checks; screen=',decision['passed'])

if __name__=='__main__':main()
