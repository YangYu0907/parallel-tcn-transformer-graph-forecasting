import support as s
import math,json,os,uuid
def main():
 protocol=s.verify();result=s.read(s.N/'REPLAY_RESULT.json');prefix=s.read(s.N/'PREFIX_RESULT.json')
 repair=s.read(s.N/'PURGED_PREFIX_FOLDS.json');source=s.read(s.N/'SOURCE_RESULT.json')
 checks=[]
 s.guard(True)
 with s.base.numeric('output_gate_independent_scalar_check'):
  import numpy as np
  for row,observed in zip(protocol['cases'],result['models']):
   with np.load(row['evaluation'],allow_pickle=False) as z:err=(z['prediction']-z['truth']).ravel()
   mae=math.fsum(abs(float(x)) for x in err)/len(err)
   rmse=math.sqrt(math.fsum(float(x)*float(x) for x in err)/len(err))
   assert math.isclose(mae,observed['metrics']['mae'],abs_tol=1e-12)
   assert math.isclose(rmse,observed['metrics']['rmse'],abs_tol=1e-12)
   checks.append(dict(seed=row['seed'],variant=row['variant'],MAE=mae,RMSE=rmse))
 average={}
 for name in ['FULL','SELF','STATIC']:
  rr=[r['metrics'] for r in result['models'] if r['variant']==name]
  average[name]={k:sum(r[k] for r in rr)/3 for k in rr[0]}
 for name in ['FULL','STATIC']:
  rr=[r['fixed_half_metrics'] for r in result['fixed_combinations'] if r['graph']==name]
  average[name+'+SELF_50:50']={k:sum(r[k] for r in rr)/3 for k in rr[0]}
 audit=dict(at=s.now(),status='passed_for_bounded_admission_work',fixed_checkpoint_replays=9,
  independent_scalar_checks=checks,protected_files_unchanged=s.protected(),
  known_development_only=True,review_scope='Separate scalar/release verification by same operator, not external human review',
  no_new_fits=True,no_new_sealed_targets=True,V7_not_replaced=True,
  artifacts={p.name:s.sha(p) for p in s.N.iterdir() if p.suffix in ('.py','.json') and p.name!='AUDIT.json'})
 s.write('AUDIT.json',audit)
 s.write('DECISION.json',dict(at=s.now(),status='bounded_admission_complete_with_open_source_and_prefix_gates',
  actual_new_model_training=False,full_plan_complete=False,active_numeric_job=False,
  expert_reuse_feasible=True,strict_calibration_prefix_rebuild_required=True,new_forecast_feature_admitted=False,
  fresh_confirmation_admitted=False,development_metrics_average=average,
  next_actions=['Use purged prefix contract for any strict chronological reconstruction; preserve original V7 separately',
   'Complete actual forecast-vintage/value and full-panel availability evidence before physical-feature fitting',
   'Admit an unused confirmation period by metadata; July-August registered source gate yielded only already-tested August origins',
   'Only then register one bounded natural-frequency output-benefit gate with identical SELF and control budgets'],
  do_not_repeat=['New frozen-GRU local head','Unconditional half-weight replacement','Already-tested historical flexible ramp awards as if new future forecasts'],
  event_policy='Existing local filesystem watcher only; no periodic wakeups; no new manager or duplicate event'))
 lines=['输出层专家复用与前瞻来源准入：本轮执行记录',s.now(),'',
 '本轮已执行准入、源码核查、预测重放及输出接口验证；没有开始新候选训练，没有产生可替换论文的新版模型。V7及18项保护文件哈希复核一致。',
 '', '1. 可复用的专家',
 'FULL、SELF、STATIC各3种子的固定第12轮检查点全部找到；9个模型共108个抽样起点重放最大差异为0。完整June284缓存用独立标量求和重算MAE/RMSE，全部通过。训练目标截止2025-05-31，预处理拟合行位于TRAIN内。',
 '另核验了9份June选轮次的专家在2026 H1上的历史预测缓存及冻结绑定。June选轮次不适合June内部严格样本外选择，但时间上可用于后续H1开发预测。H1已经多次用于开发，不能称为新独立测试。',
 '', '2. 零拟合的补充诊断（只限June284；30节点、12步、3种子误差均值，USD/MWh）',
 '模型 | MAE | RMSE | 5–20分钟MAE | 60分钟MAE']
 for name,r in average.items():lines.append(f'{name} | {r["mae"]:.4f} | {r["rmse"]:.4f} | {r["near_h1_4_mae"]:.4f} | {r["h12_mae"]:.4f}')
 lines += ['这些不是June3397、698起点V7或独立测试结果，不用于选模型或更新论文表。固定等权组合没有稳定改善，新增SELF专家本身不等于成功；按真实结果事后挑专家的oracle只用于诊断互补空间，不能用于实时预测。',
 '', '3. 找到的严格时间前缀缺口及已生成的修复规则',
 '核验41项V7来源绑定、9个旧前缀训练收据及84699条反馈释放记录。旧评估窗口的训练/反馈可用性边界均通过。',
 '更严格地检查校准窗口首个预测时间时，3个前缀各有1个训练起点的最后标签晚300秒才可用。它不等于后续H1评估读取未来目标，但这些旧校准预测不能直接宣称严格逐时样本外。',
 '新建PURGED_PREFIX_FOLDS.json，仅从拟合集剔除这3个起点：254→253、488→487、760→759；校准及698个评估起点原样保留。剔除后训练标签至少早3300秒可用。原索引及V7未修改。依赖被剔除训练样本的模型尚未重新拟合，不能因生成新索引就宣布旧模型已修复。',
 'V7尖峰专家原TRAIN拟合与校准间隔检查通过；新门控仍需绑定每一行的完整V7输出，不能把V7残差直接搬到图/SELF混合预测上。',
 '', '4. 数据来源',
 '既有RTD/DAM完整前瞻曲线的发布版本与具体数值绑定仍未通过；已核验的历史灵活爬坡出清量已经试过，不是新的未来爬坡裕度信息。',
 '新抽查NOAA HRRR原始预报对象：2023-06-01、2025-06-01、2026-01-01的00UTC批次1小时预报均有归档元数据，列表和HEAD的ETag一致；对象时间比批次晚约52–54分钟。只读取2694字节列表和HEAD，没有下载气象字段或价格目标。',
 '它提供了可继续追溯的预报来源，不是已获准的新特征。还需全共同面板覆盖、字节身份/可用时间、节点映射及缺测规则。每个预测截止时间只能使用已实际可用的批次和预测时效。',
 '来源：https://registry.opendata.aws/noaa-hrrr-pds/ ；https://www.nco.ncep.noaa.gov/pmb/products/hrrr/',
 '', '5. 独立确认与下一关',
 '现有登记的July–August 2026来源筛查：1488个注册起点只有111个通过，全部在August且已经用于旧候选确认；H1和September也已经看过。欧洲2017的时间戳/版本语义仍未核准。本次没有读取任何新的封存测试目标。',
 '需要先完成严格前缀重建与信息准入，并核准新的确认数据，再登记一个有限的收益门控候选。门控按自然发生率学习，MAE收益与MSE风险分别处理；图+SELF、STATIC+SELF、单SELF、固定组合和完整V7都保留比较。',
 '', '6. 工程状态',
 '已实现独立输出层组合及完整V7零干预回退接口；位级一致性、有限值/权重范围、错误视野广播、未来标签及组件时间边界检查通过。这些仅验证代码性质，不保证非零干预时性能不下降。',
 '当前没有新的数值后台任务。原本地文件事件监听器继续保留；没有新增定时唤醒。后续新管理进程必须同时登记退出监听。研究整体尚未完成。']
 (s.N/'本轮执行结果.txt').write_text('\n'.join(lines)+'\n',encoding='utf-8')
 # Preserve prior handoff before an atomic small field update; no model/result files touched.
 hp=s.B/'HANDOFF.json';old=hp.read_bytes();handoff=json.loads(old.decode('utf-8-sig'))
 (s.N/'HANDOFF_before_admission.json').write_bytes(old)
 handoff['output_gate_admission_20261004']=dict(at=s.now(),directory=str(s.N),decision=str(s.N/'DECISION.json'),
  report=str(s.N/'本轮执行结果.txt'),status='admission_complete_pending_prefix_rebuild_and_source_confirmation',
  expert_replays=9,protected_unchanged=18,model_fits=0,active_numeric_job=False,gate_installed=False,
  source_feature_admission=False,new_confirmatory_panel_admitted=False)
 handoff['current_authorized_work']='User-approved output-level expert reuse / source-vintage / chronological benefit-gate plan. Admission and zero-fit replay complete; 3 calibration-prefix boundary rows isolated; strict dependent refits and new source/confirmation admission still required. No new numeric job queued; V7 unchanged.'
 assert hp.read_bytes()==old,'Concurrent HANDOFF edit; do not overwrite'
 tmp=hp.with_name('.handoff_'+uuid.uuid4().hex[:10]+'.tmp');tmp.write_text(json.dumps(handoff,ensure_ascii=False,indent=2),encoding='utf-8');os.replace(tmp,hp)
 print(json.dumps(dict(report=str(s.N/'本轮执行结果.txt'),protected=s.protected(),training=False,average=average),ensure_ascii=False))
if __name__=='__main__':main()
