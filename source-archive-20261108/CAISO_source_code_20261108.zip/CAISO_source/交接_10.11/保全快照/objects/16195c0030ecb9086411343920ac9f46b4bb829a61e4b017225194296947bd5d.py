from core import *
import numpy as np

def data(fold):
    root=HERE/f'fold{fold}'
    with np.load(root/'FULL_price_only/PREDICTIONS.npz') as z:d={k:z[k] for k in z.files}
    for family in ['iTransformer_price_only','specialist']:
        with np.load(root/family/'PREDICTIONS.npz') as z:
            assert np.array_equal(z['origins'],d['origins'])
            if family.startswith('iTransformer'):
                assert np.array_equal(z['truth'],d['truth']);d['other']=z['prediction']
            else:
                for k in ['quantiles','probabilities','prior','center','thresholds']:d[k]=z[k]
                d['spike']=z['prediction']
    d['full']=d.pop('prediction')
    d['scale']=np.array(read(HERE/f'fold{fold}_stats.json')['neural']['scale'])
    return d

def features(d):
    shape=d['full'][:,:,7:].shape;s=d['scale'][None,:,None]
    local=np.broadcast_to(d['context'][:,:,None,:],(*shape,31))
    q=d['quantiles'][:,:,7:]
    rest=np.stack([(d['other'][:,:,7:]-d['full'][:,:,7:])/s,
        (d['spike'][:,:,7:]-d['full'][:,:,7:])/s,(d['full'][:,:,7:]-d['last'][:,:,None])/s,
        (q[:,:,:,2]-q[:,:,:,0])/s,(q[:,:,:,4]-q[:,:,:,2])/s,
        np.broadcast_to(np.arange(8,13)/12,shape)],axis=-1)
    return np.concatenate([local,rest,d['probabilities'][:,:,7:]],axis=-1).reshape(-1,40).astype('float32')

def router(dim,experts):
    import torch
    return torch.nn.Sequential(torch.nn.Linear(dim,32),torch.nn.GELU(),torch.nn.Linear(32,experts))

def routing(model,X,lo,hi,variant):
    import torch
    # Distribution support is checked on history variables, not future state labels.
    support=((X[:,:31]>=lo[:31])&(X[:,:31]<=hi[:31])).all(1)
    with torch.no_grad():w=torch.softmax(model(torch.from_numpy(X)),dim=1).numpy()*.5
    w[:,0]+=.5;w[~support]=0;w[~support,0]=1
    return w,support

def predict(model,modelinfo,d,variant):
    X=features(d);c=np.array(modelinfo['center']);s=np.array(modelinfo['scale'])
    X=np.clip((X-c)/s,-6,6).astype('float32')
    if variant=='NO_RISK':X[:,-3:]=0
    w,supported=routing(model,X,np.array(modelinfo['lo']),np.array(modelinfo['hi']),variant)
    ex=np.stack([d['full'][:,:,7:],d['other'][:,:,7:]]+([] if variant=='NO_SPIKE' else [d['spike'][:,:,7:]]),axis=-1)
    out=d['full'].copy();out[:,:,7:]=np.sum(ex*w.reshape(*ex.shape),axis=-1)
    assert np.array_equal(out[:,:,:7],d['full'][:,:,:7])
    return out,w.reshape(*ex.shape),float(supported.mean())

def fit(variant,seed,d,tick):
    import torch
    from fair_inputs import save_pt
    directory=HERE/'routers'/f'{variant}_{seed}';directory.mkdir(parents=True,exist_ok=True)
    X=features(d);center=np.median(X,axis=0);scale=np.maximum(np.quantile(X,.75,axis=0)-np.quantile(X,.25,axis=0),1e-5)
    X=np.clip((X-center)/scale,-6,6).astype('float32')
    if variant=='NO_RISK':X[:,-3:]=0
    lo=X.min(0);hi=X.max(0)
    choices=[d['full'][:,:,7:],d['other'][:,:,7:]]+([] if variant=='NO_SPIKE' else [d['spike'][:,:,7:]])
    ex=np.stack(choices,axis=-1).reshape(-1,len(choices));yy=d['truth'][:,:,7:].ravel()
    unit=float(d['scale'].mean());ex=((ex-d['full'][:,:,7:].reshape(-1,1))/unit).astype('float32')
    yy=((yy-d['full'][:,:,7:].ravel())/unit).astype('float32')
    torch.manual_seed(seed);model=router(40,len(choices));opt=torch.optim.AdamW(model.parameters(),lr=.001,weight_decay=.001)
    rng=np.random.default_rng(seed);epoch=0
    latest=directory/'latest.pt';identity=dict(protocol=sha(HERE/'PROTOCOL.json'),variant=variant,seed=seed)
    if latest.exists():
        z=torch.load(latest,map_location='cpu',weights_only=False);assert z['identity']==identity
        model.load_state_dict(z['model']);opt.load_state_dict(z['optimizer']);rng.bit_generator.state=z['rng'];epoch=z['epoch']
    while epoch<20:
        order=rng.permutation(len(X));model.train()
        for j in range(0,len(order),2048):
            if j%32768==0:tick(variant=variant,seed=seed,epoch=epoch+1,row=j)
            ix=order[j:j+2048];w=torch.softmax(model(torch.from_numpy(X[ix])),dim=1)*.5
            # Expert zero is FULL, whose delta equals zero. Its remaining .5 weight is implicit.
            pred=(w*torch.from_numpy(ex[ix])).sum(1);err=pred-torch.from_numpy(yy[ix])
            loss=err.abs().mean()+.1*err.square().mean();assert torch.isfinite(loss)
            opt.zero_grad(set_to_none=True);loss.backward();torch.nn.utils.clip_grad_norm_(model.parameters(),1.);opt.step()
        epoch+=1
        save_pt(latest,dict(identity=identity,model=model.state_dict(),optimizer=opt.state_dict(),rng=rng.bit_generator.state,epoch=epoch))
    info=dict(at=now(),identity=identity,epochs=20,center=center.tolist(),scale=scale.tolist(),lo=lo.tolist(),hi=hi.tolist(),
        loss='abs(currency_error/TRAIN_mean_scale) + .1*squared(currency_error/TRAIN_mean_scale)',
        experts=len(choices),checkpoint_sha256=sha(latest),fit_dates=len(np.unique(d['days'])))
    write(directory/'FROZEN.json',info);return model,info

def intervals(cal,ev,pc,pe,method):
    # Nonnegative finite-sample empirical calibration. Temporal dependence remains explicit.
    levels=[.1,.2];out=[];params=[]
    for alpha,il,iu in [(.1,0,4),(.2,1,3)]:
        if method=='CQR':
            cl=pc+cal['quantiles'][...,il]-cal['quantiles'][...,2]
            cu=pc+cal['quantiles'][...,iu]-cal['quantiles'][...,2]
            el=pe+ev['quantiles'][...,il]-ev['quantiles'][...,2]
            eu=pe+ev['quantiles'][...,iu]-ev['quantiles'][...,2]
            score=np.maximum(cl-cal['truth'],cal['truth']-cu)
        else:
            el=pe.copy();eu=pe.copy();score=abs(pc-cal['truth'])
        a=[]
        for h in range(12):
            z=score[:,:,h].ravel();rank=min(len(z),int(np.ceil((len(z)+1)*(1-alpha))))-1
            a.append(max(0.,float(np.partition(z,rank)[rank])))
        lo=el-np.array(a)[None,None,:];hi=eu+np.array(a)[None,None,:]
        out.append(np.stack([lo,hi],axis=-1));params.append(dict(alpha=alpha,adjustments=a))
    return np.stack(out,axis=-2),params

def probability_scores(bounds,point,y):
    intervals=[];weighted=.5*abs(point-y)
    for i,alpha in enumerate([.1,.2]):
        lo=bounds[...,i,0];hi=bounds[...,i,1];width=hi-lo
        score=width+2/alpha*np.maximum(lo-y,0)+2/alpha*np.maximum(y-hi,0)
        weighted+=alpha/2*score
        intervals.append(dict(nominal=1-alpha,coverage=float(((y>=lo)&(y<=hi)).mean()),width=float(width.mean()),interval_score=float(score.mean())))
    return dict(wis=float((weighted/2.5).mean()),intervals=intervals)

def main():
    verify()
    with numeric('integrated adaptive routing matched ablations and probability scoring'):
        import torch
        from fair_inputs import runtime
        runtime();tick=timer('combine');fitdata,cal,ev=[data(i) for i in range(3)]
        # No evaluation labels are passed into fit or calibration functions.
        basecal={'FULL':cal['full'],'iTransformer':cal['other'],'SPIKE':cal['spike']}
        baseev={'FULL':ev['full'],'iTransformer':ev['other'],'SPIKE':ev['spike']}
        for label,a in [('FIXED25',.25),('FIXED50',.5)]:
            for d,out in [(cal,basecal),(ev,baseev)]:
                p=d['full'].copy();p[:,:,7:]+=a*(d['other'][:,:,7:]-d['full'][:,:,7:]);out[label]=p
        for d,out in [(cal,basecal),(ev,baseev)]:
            p=d['full'].copy();p[:,:,7:]=(2/3)*p[:,:,7:]+(d['other'][:,:,7:]+d['spike'][:,:,7:])/6;out['FIXED_THREE']=p
        details=[];outputs={k:baseev[k] for k in baseev};caloutputs={k:basecal[k] for k in basecal}
        for variant in ['COMPLETE','NO_SPIKE','NO_RISK']:
            for seed in SEEDS:
                model,info=fit(variant,seed,fitdata,tick)
                cp,_,cs=predict(model,info,cal,variant)
                qualification_cal=qualification(cp,cal['full'],cal['truth'],cal['states'],cal['days'])
                name=f'{variant}_{seed}'
                write(HERE/'routers'/name/'CALIBRATION.json',dict(at=now(),qualified=qualification_cal,support=cs))
                # After the fit and its calibration are committed, compute forward diagnostics.
                pp,w,es=predict(model,info,ev,variant)
                outputs[name]=pp;caloutputs[name]=cp;outputs[name+'_CHECKED']=pp if qualification_cal['passed'] else ev['full'].copy()
                save(HERE/'routers'/name/'FORWARD.npz',weights=w,prediction=pp,origins=ev['origins'])
                details.append(dict(model=name,seed=seed,variant=variant,calibration=qualification_cal,
                    forward=qualification(pp,ev['full'],ev['truth'],ev['states'],ev['days']),supported_fraction=es))
        rows=[dict(model=k,**metrics(p,ev['truth'])) for k,p in outputs.items()]
        states=[dict(model=k,states=state_metrics(p,ev['truth'],ev['states'],ev['days'])) for k,p in outputs.items()]
        prob=[];pout={}
        for name in ['FULL']+[f'COMPLETE_{s}' for s in SEEDS]:
            for method in ['EMPIRICAL','CQR']:
                bounds,params=intervals(cal,ev,caloutputs[name],outputs[name],method)
                assert np.isfinite(bounds).all() and (bounds[...,0]<=bounds[...,1]).all()
                key=name+'_'+method;pout[key]=bounds
                prob.append(dict(model=name,method=method,**probability_scores(bounds,outputs[name],ev['truth']),calibration=params))
        from sklearn.metrics import average_precision_score,log_loss
        c=ev['center'][None,:,None];th=ev['thresholds'][1][None,:,None]
        event=np.where(ev['truth']>c+th,1,np.where(ev['truth']<c-th,2,0))
        risk=[]
        for k in [1,2]:
            yy=event==k
            for name,pr in [('SPIKE',ev['probabilities'][...,k]),('PRIOR',np.full(yy.shape,ev['prior'][k]))]:
                risk.append(dict(model=name,event=k,brier=float(((pr-yy)**2).mean()),logloss=float(log_loss(yy.ravel(),pr.ravel(),labels=[False,True])),
                    pr_auc=float(average_precision_score(yy.ravel(),pr.ravel())),positive_cells=int(yy.sum()),dates=len(np.unique(ev['days'][yy.any((1,2))]))))
        save(HERE/'REPLAY.npz',origins=ev['origins'],days=ev['days'],truth=ev['truth'],states=ev['states'],**outputs)
        save(HERE/'PROBABILITY_REPLAY.npz',truth=ev['truth'],days=ev['days'],**pout)
        save(HERE/'CALIBRATION_REPLAY.npz',origins=cal['origins'],days=cal['days'],truth=cal['truth'],states=cal['states'],**caloutputs)
        rawpass=all(x['calibration']['passed'] and x['forward']['passed'] for x in details if x['variant']=='COMPLETE')
        avg=np.mean([metrics(outputs[f'COMPLETE_{s}'],ev['truth'])['mae'] for s in SEEDS])
        rawpass=bool(rawpass and all(avg<metrics(outputs[k],ev['truth'])['mae'] for k in ['FULL','FIXED25','FIXED50','FIXED_THREE']))
        write(HERE/'RESULT.json',dict(at=now(),status='integrated_development_complete_pending_arithmetic_audit',
            scope='Historical cross-fitting, one backbone seed, three router initializations; not three independent backbone replications or a new test.',
            rows=rows,states=states,router_details=details,probability=prob,risk=risk,screen_passed=rawpass,
            prediction_sha256=sha(HERE/'REPLAY.npz'),calibration_sha256=sha(HERE/'CALIBRATION_REPLAY.npz'),
            probability_sha256=sha(HERE/'PROBABILITY_REPLAY.npz'),V7_replaced=False,new_test_targets_read=False,
            whole_research_complete=False,point_preservation_scope='H1-H7 of newly matched FULL; V7 archive separately immutable.',
            protected=verify_protected()))
        tick(status='complete')

if __name__=='__main__':main()
