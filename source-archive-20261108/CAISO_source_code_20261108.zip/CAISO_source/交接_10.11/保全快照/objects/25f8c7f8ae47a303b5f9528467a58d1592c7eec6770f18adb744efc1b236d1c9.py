from trial import HERE,REC,old,correct,features_at,checked
import numpy as np,ast
def main():
    assert not (HERE/'PROTOCOL.json').exists(),'Registered already; do not overwrite'
    old.verify();checked(True)
    for p in HERE.glob('*.py'):ast.parse(p.read_text(encoding='utf-8'))
    # Actual feature extractor, synthetic future changed by orders of magnitude.
    rng=np.random.default_rng(20261004);raw=rng.normal(size=(400,30))
    stats=dict(center=[0.]*30,scale=[1.]*30,thresholds=[[1.]*30,[2.]*30])
    f,last=features_at(raw,np.array([300]),stats);changed=raw.copy();changed[300:]=1e6
    ff,ll=features_at(changed,np.array([300]),stats)
    assert np.array_equal(f,ff) and np.array_equal(last,ll)
    b=rng.normal(size=(3,30,12));rec=rng.normal(size=(3,30,5));ext=rng.normal(size=(3,30,5))
    eligible=rng.random((3,30))>.5;last=rng.normal(size=(3,30));p=rng.random((3,30,5))
    for arm in ['BASE','RECOVERY_ONLY','TWO_REGIME','PERSISTENCE_CONTROL','EQUAL_REGIME']:
        out=correct(b,rec,ext,p,last,eligible,arm)
        assert np.array_equal(out[:,:,:7],b[:,:,:7]) and np.array_equal(out[~eligible],b[~eligible])
    for prob,want in [(np.zeros_like(p),ext),(np.ones_like(p),rec)]:
        out=correct(b,rec,ext,prob,last,np.ones_like(eligible), 'TWO_REGIME')
        assert np.allclose(out[:,:,7:],.5*(b[:,:,7:]+want))
    old.write(HERE/'QA.json',dict(at=old.now(),syntax='passed',future_invariance='passed',
        unchanged_subsets='passed',probability_boundaries='passed',protected_files=18,no_market_fit=True))
    diag=HERE.parent/'spike_event_diagnosis_20261004'
    paths=list(HERE.glob('*.py'))+[HERE/'QA.json',REC/'PROTOCOL.json',REC/'RESULT.json',REC/'AUDIT.json']
    paths += [diag/n for n in ['RESULT.json','SUPPLEMENT.json','AUDIT.json']]
    for fold in [1,2]:
        paths += [REC/f'REPLAY_fold{fold}.npz']
        paths += [REC/f'fold{fold}'/n for n in ['PREDICTIONS.npz','recovery.pkl','transition.pkl','FROZEN.json']]
    protocol=dict(at=old.now(),status='registered_before_fit',authorization='User: start as soon as possible; prior literature/diagnosis scoped repair',
        budget_seconds=1800,new_fits=2,single_numerical_worker=True,launch_memory_GiB=5,runtime_memory_GiB=4,
        scope='Previously inspected historical TRAIN. Calibration Oct-Dec2024; historical forward Jan-May2025. No independent test claim.',
        candidate='Complete binary regime conditional mean with matched extreme-price head; frozen recovery probabilities/mean, base routers and neural backbones.',
        reasoning='Recovery-only segment cannot fix most S5; existing conditional extreme predictions have useful direction. Match new amplitude head to exact recovery labels/prefix statistics.',
        state_semantics='Endpoint extreme probability; S5 includes interrupted recurrence and opposite-sign changes. Not a survival-only task.',
        fit=dict(prefixes=[1,2],current_extreme=True,target_extreme=True,threshold='same prefix q99 as recovery',
            natural_frequency=True,horizons=[8,9,10,11,12],max_iter=80,max_leaf_nodes=7,min_samples_leaf=50,
            learning_rate=.05,l2_regularization=1,loss='squared_error',seed=20260813,minimum_cells=100,minimum_dates=5,
            fixed_checkpoint=True,hyperparameter_search=False,features='same 37 historical price features+30node indicators+horizon; training-prefix center/scales',
            output='center+q99*predicted ratio; no label-based projection/clipping'),
        formula='Eligible H8-H12: 0.5*BASE+0.5*(p_recovery*recovery_mean+(1-p_recovery)*extreme_mean)',
        controls=['BASE','RECOVERY_ONLY','PERSISTENCE_CONTROL','EQUAL_REGIME'],
        retention='Every router initialization, both folds: all headline/horizon/state errors <=BASE+1e-6; >=5 UTC dates per state. S3/S4 improvement direction must remain.',
        acceptance='Retention AND mean MAE/RMSE/H12 lower than RECOVERY_ONLY, PERSISTENCE_CONTROL and EQUAL_REGIME in both folds. Otherwise close candidate, no automatic retry.',
        statistics='Exploratory complete effect table; no new significance or independent validation claim.',
        probability='Matched existing CQR intervals recalibrated only fold1; report coverage,width,interval score. WIS-style point term not an identified median.',
        immutable_outputs='H1-H7 and all currently nonextreme origins/nodes, including S0-S2; all 18 V7/manuscript protected files',
        limits='Cannot improve sudden S2 while keeping it exactly unchanged. Pooled extreme conditional mean may average opposite signs. No claim of guaranteed all-metric dominance.',
        literature=[
            dict(url='https://doi.org/10.1016/j.ijforecast.2011.02.019',supports='Spike probability is distinct from magnitude; not evidence for this exact estimator.'),
            dict(url='https://doi.org/10.1016/j.ijforecast.2013.12.011',supports='Event timing and magnitude require explicit treatment.'),
            dict(url='https://doi.org/10.1198/jasa.2011.r10138',supports='Mean and median have different scoring targets; squared-error head need not improve MAE.')],
        bindings={str(p):old.sha(p) for p in paths},protected_files=18,V7_replaced=False,new_test_targets_read=False,
        independent_confirmation_required=True,periodic_model_wakeups=False)
    old.write(HERE/'PROTOCOL.json',protocol)
    print('QA passed; frozen before training; two heads only.')
if __name__=='__main__':main()
