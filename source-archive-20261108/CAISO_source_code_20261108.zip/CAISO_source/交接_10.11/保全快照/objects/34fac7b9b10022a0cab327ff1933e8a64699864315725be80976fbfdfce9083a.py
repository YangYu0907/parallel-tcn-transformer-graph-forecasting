"""Preserve the failed attempt; repair one logging key and reuse sealed arm."""
from pathlib import Path
import os,sys,json,ast,hashlib,shutil,time,types
R=Path(__file__).resolve().parent;F=R.parent;Z=F.parent
sys.path.insert(0,str(Z));import support as s
assert not (R/'PROTOCOL.json').exists()
parent=s.read(F/'PROTOCOL.json')
for p,h in parent['bindings'].items():assert s.sha(p)==h,p
history=s.read(F/'HISTORY_complete.json')
for p,h in history['bindings'].items():assert s.sha(p)==h,p
assert s.read(F/'HISTORY_fit.json')['completed_iterations']==80
text=(F/'fit_compare.py').read_text(encoding='utf-8')
assert text.count("arm_tick(stage='arm_complete',elapsed_seconds=")==1
text=text.replace("arm_tick(stage='arm_complete',elapsed_seconds=","arm_tick(stage='arm_complete',arm_elapsed_seconds=")
text=text.replace('W=Path(__file__).resolve().parent','W=Path(__file__).resolve().parent.parent')
(R/'fit_compare.py').write_text(text,encoding='utf-8')
manager=(F/'manager.py').read_text(encoding='utf-8').replace('sys.path.insert(0,str(W.parent))','sys.path.insert(0,str(W.parent.parent));sys.path.append(str(W.parent))')
(R/'manager.py').write_text(manager,encoding='utf-8')
launch=(F/'launch.ps1').read_text(encoding='utf-8-sig')
launch=launch.replace('$branch=Split-Path -Parent (Split-Path -Parent (Split-Path -Parent $trial))',"$branch='"+str(s.B)+"'")
(R/'launch.ps1').write_text(launch,encoding='utf-8-sig')
for name in ['SOURCE_REVIEW.json','ENGINEERING_QA.json']:shutil.copyfile(F/name,R/name)
for name in ['manager.py','fit_compare.py']:ast.parse((R/name).read_text(encoding='utf-8'))
tick=next(n for n in ast.walk(ast.parse(manager)) if isinstance(n,ast.FunctionDef) and n.name=='tick')
captured=[];ns=dict(guard=lambda:{},s=types.SimpleNamespace(now=lambda:'qa'),psutil=types.SimpleNamespace(Process=lambda:types.SimpleNamespace(memory_info=lambda:types.SimpleNamespace(rss=1,peak_wset=1))),os=os,time=time,start=time.monotonic(),write=lambda name,d:captured.append(d))
exec(compile(ast.Module(body=[tick],type_ignores=[]),'tick_fixture','exec'),ns)
for arm in ['HISTORY','COARSE','SPATIAL','MECHANISM']:
    ns['tick'](stage='arm_complete',arm=arm,completed_model_fits=1,arm_elapsed_seconds=47.5)
assert len(captured)==4 and all(x['arm_elapsed_seconds']==47.5 and 'elapsed_seconds' in x for x in captured)
report=dict(at=s.now(),passed=True,root_cause='Arm completion log duplicated elapsed_seconds owned by manager; training and checkpoint already succeeded',repair='Rename arm duration to arm_elapsed_seconds only',completed_HISTORY_iterations=80,completed_HISTORY_bindings_verified=len(history['bindings']),history_retrained=False,actual_completion_log_cases=4,old_attempt_preserved=True,source_audit_unchanged=True,resource_guards_unchanged=True,real_model_fits=0,new_test_targets_read=False)
(R/'RECOVERY_QA.json').write_text(json.dumps(report,indent=2),encoding='utf-8')
files=[R/n for n in ['manager.py','fit_compare.py','launch.ps1','SOURCE_REVIEW.json','ENGINEERING_QA.json','RECOVERY_QA.json']]
files += [F/n for n in ['PROTOCOL.json','FAILURE.json','HISTORY_complete.json','HISTORY_fit.json','disk_hgb.py']]
q=dict(at=s.now(),status='registered_logging_repair_before_resume',parent_protocol_sha256=s.sha(F/'PROTOCOL.json'),source_complete_sha256=s.sha(Z/'SOURCE_COMPLETE.json'),model_budget_total=4,resume_completed_arms=['HISTORY'],remaining_arms=['COARSE','SPATIAL','MECHANISM'],same_data_features_learner_and_scores=True,resource_launch_GiB=5,resource_runtime_GiB=4,periodic_model_wakeups=False,time_limit_stop_enabled=False,V7_replaced=False,new_test_targets_read=False,bindings={str(p):s.sha(p) for p in files})
(R/'PROTOCOL.json').write_text(json.dumps(q,indent=2,ensure_ascii=False),encoding='utf-8')
print(json.dumps(report))
