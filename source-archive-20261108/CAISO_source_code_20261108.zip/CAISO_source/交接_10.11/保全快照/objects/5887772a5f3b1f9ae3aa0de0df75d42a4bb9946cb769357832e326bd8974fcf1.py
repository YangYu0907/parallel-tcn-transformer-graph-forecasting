"""Register a finite, causal expanding-prefix weather stability comparison."""
import os,sys,json
from pathlib import Path
from datetime import datetime,timezone
W=Path(__file__).resolve().parent;Z=W.parent;sys.path.insert(0,str(Z))
import support as s
import numpy as np

def stamp(date):return int(datetime.fromisoformat(date).replace(tzinfo=timezone.utc).timestamp())
def write(n,v):s.base.write(W/n,v)
def main():
 assert not (W/'PROTOCOL.json').exists(),'Do not overwrite an existing registration'
 old=s.read(Z/'PROTOCOL.json');sp=s.read(Path(old['short_context_protocol']));F=Z/'fit4_1009';N=Z.parent/'short_context_support_trial_20261005'
 plan=dict(at=s.now(),status='fixed_calendar_plan_before_fold_support_or_new_fits',scope='Previously exposed compiled TRAIN development only. Rolling evaluation is not independent confirmation. No new held-out price files.',
  folds=[dict(name='Q1_2025',fit_freeze='2024-08-30',cal_start='2024-09-01',cal_freeze='2024-12-30',eval_start='2025-01-01',eval_end='2025-04-01'),
         dict(name='Q2_partial_2025',fit_freeze='2024-11-30',cal_start='2024-12-01',cal_freeze='2025-03-30',eval_start='2025-04-01',eval_end='2025-06-01')],
  arms=['HISTORY','COARSE','GROUPED'],max_new_model_fits=4,max_total_model_cells=6,
  reuse='First fold HISTORY/COARSE only if fit/cal indices, thresholds, learner, matrices and dependencies match completed original arms exactly; otherwise fail, do not silently retrain',
  labels='Frozen q90 eligibility and q99 first-entry thresholds fitted through2024-08-29. Same task in every fold. Threshold information freeze precedes all calibration/evaluation.',
  causal='No fitted feature scaler. Price histories use records published by issuance. Fit and calibration labels additionally require last publication of every horizon record <= respective prefix freeze; 60minute labels purged at boundaries. Fixed forecast adapters use issuance-available original versions.',
  learner=old['learner'],iterations=[20,40,60,80],
  grouped_weather=['Three load-region temperatures at t,t+30,t+60 (9)',
                   'Mean80m wind speed across six predeclared wind regions at three leads (3)',
                   'Spatial standard deviation of80m wind speed across those regions at three leads (3)',
                   'Mean shortwave radiation across two predeclared solar regions at three leads (3)',
                   'Mean cloud cover across those regions at three leads (3)',
                   'Mean temperature minus dewpoint across three load regions at three leads (3)'],
  features=dict(HISTORY=29,COARSE=56,GROUPED=53),
  grouping='24 weather features. Equal regional aggregation, no capacity weights, no claimed exact nodal exposure, no target-selected region/field, no fitted selector.',
  calibration='Own chronological CAL only: one positive multiclass temperature [.5,2]; class-negative99th percentile alarm with strict >; no threshold search or class weighting.',
  minimum_support=dict(fit_dates_and_clusters=20,cal_dates_and_clusters=5,eval_dates_and_clusters=5),
  support_rule='Both signs must pass every role/fold before numerical training. If any fails, record insufficient support and do not alter window/thresholds; retain all evaluation dates.',
  primary='Eight exploratory comparisons: GROUPED vs rolling COARSE and rolling COARSE vs original frozen COARSE; up/down Brier+binary logloss.2000 paired3-calendar-day bootstrap, Holm over8.',
  secondary='All five months, both folds, precision/recall/FPR,AP,TP,FP; rolling/frozen HISTORY descriptive controls; no choosing only favorable month.',
  gate='No automatic integration. Candidate evidence promising only if both-sign proper scores improve on HISTORY and COARSE in BOTH folds, precision/recall nonworse thanCOARSE,FPR<=.02, and four GROUPED-primary Holm p<.05. Otherwise close. Previous failed gate unchanged.',
  time_budget=None,eta_only='About1-2hours including coding and audit, not a stopping timer',
  resources='5GiB physical/commit launch;4GiB runtime;4GiB diskreserve;one worker/thread;shared lock;preserve user stop;exit monitor PID+creation bound before work',
  V7_replaced=False,new_test_targets_read=False,periodic_model_wakeups=False)
 if (W/'DESIGN_BEFORE_SUPPORT.json').exists():
  prior=s.read(W/'DESIGN_BEFORE_SUPPORT.json')
  assert {k:v for k,v in prior.items() if k!='at'}=={k:v for k,v in plan.items() if k!='at'}
  plan=prior
 else:write('DESIGN_BEFORE_SUPPORT.json',plan)
 with s.base.numeric('Prefix stability registration and event support metadata'):
  s.guard(True);s.verify()
  for filename,digest in s.read(N/'DATA_COMPLETE.json')['bindings'].items():assert s.sha(N/filename)==digest,filename
  source_review=s.read(F/'resume_1/SOURCE_REVIEW.json');assert source_review['passed'] and source_review['source_complete_sha256']==s.sha(Z/'SOURCE_COMPLETE.json')
  th=s.read(Path(old['thresholds']));assert stamp(th['fit_information_freeze'].replace('+00:00',''))<=stamp(plan['folds'][0]['fit_freeze'])
  with np.load(Z/'ROWS.npz') as a:rows=a['row'];where=a['weather_row'];origins=a['origin'];cutoff=a['cutoff'];phase=a['role']
  with np.load(sp['publications']) as p:
   ts=p['timestamps_seconds'];last=p['price_last_publication_seconds'];bound=p['price_event_bound'];amb=p['price_archive_versions_ambiguous'];valid=p['source_row_valid']
  # Use the exact existing eligible origin population; no additional target price arrays are opened.
  assert np.array_equal(ts[origins-1],cutoff)
  horizon=origins[:,None]+np.arange(12)[None,:]
  hist=origins[:,None]-np.arange(36,0,-1)[None,:]
  # source_row_valid additionally requires unused RTD/DAM inputs and14day history.
  # This3h price-only information contract uses price_event_bound instead.
  assert bound[hist].all() and (~amb[hist]).all()
  assert (last[hist]<=cutoff[:,None]).all()
  assert bound[horizon].all() and (~amb[horizon]).all()
  available=last[horizon].max(1);end=ts[horizon].max(1)
  tm=np.asarray(np.load(N/'times.npy',mmap_mode='r')[rows]);y=np.asarray(np.load(N/'labels.npy',mmap_mode='r')[rows]);node=np.asarray(np.load(N/'nodes.npy',mmap_mode='r')[rows]);role=np.asarray(np.load(N/'role.npy',mmap_mode='r')[rows])
  assert np.array_equal(tm,cutoff[where])
  maturity=available[where];endtime=end[where]
  indices={};support=[];passed=True;counts={}
  for fold in plan['folds']:
   ff=stamp(fold['fit_freeze']);cs=stamp(fold['cal_start']);cf=stamp(fold['cal_freeze']);es=stamp(fold['eval_start']);ee=stamp(fold['eval_end'])
   assert stamp(th['fit_information_freeze'].replace('+00:00',''))<=ff<cs<cf<es<ee
   fit=np.flatnonzero((tm<ff)&(endtime<ff)&(maturity<=ff))
   cal=np.flatnonzero((tm>=cs)&(tm<cf)&(endtime<cf)&(maturity<=cf))
   ev=np.flatnonzero((tm>=es)&(tm<ee)&(role==2))
   for part,ix,floor in [('fit',fit,20),('cal',cal,5),('eval',ev,5)]:
    indices[fold['name']+'_'+part]=ix
    for c in [1,2]:
     et=np.unique(tm[ix][y[ix]==c]);dates=len(np.unique(et//86400));clusters=int(np.sum(np.diff(et)>3600)+(1 if len(et) else 0))
     ok=dates>=floor and clusters>=floor;passed&=ok
     support.append(dict(fold=fold['name'],part=part,sign=c,pairs=int(np.sum(y[ix]==c)),UTC_dates=dates,clusters=clusters,minimum=floor,passed=ok))
   counts[fold['name']]=dict(fit=len(fit),cal=len(cal),eval=len(ev),fit_publication_max=int(maturity[fit].max()),cal_publication_max=int(maturity[cal].max()))
  assert np.array_equal(indices['Q1_2025_fit'],np.flatnonzero(role==0))
  assert np.array_equal(indices['Q1_2025_cal'],np.flatnonzero(role==1))
  assert np.array_equal(np.concatenate([indices[f['name']+'_eval'] for f in plan['folds']]),np.flatnonzero(role==2))
  s.base.npz_save(W/'INDICES.npz',row=rows,weather_row=where,y=y,time=tm,node=node,**indices)
  # Calculate deterministic grouped weather only from the already-admitted weather forecasts.
  from features import at_times
  source=s.read(Z/'SOURCE_COMPLETE.json');group=np.empty((len(cutoff),24),np.float32);record=None;previous=None
  with np.load(Z/'ROWS.npz') as a:cycles=a['cycle']
  for j,(cyc,t) in enumerate(zip(cycles,cutoff)):
   if int(cyc)!=previous:
    path=Z/'cycles'/f'{cyc}.json';assert s.sha(path)==source['hashes'][str(cyc)]
    record=s.read(path);previous=int(cyc);assert record['source_available_by']<=int(t)
   v=at_times(np.asarray(record['center_values'],float),int(cyc),int(t))
   ws=np.hypot(v[4,old['wind_anchor_indices']],v[5,old['wind_anchor_indices']])
   group[j]=np.concatenate([v[0,old['load_anchor_indices']].ravel(),ws.mean(0),ws.std(0),v[6,old['solar_anchor_indices']].mean(0),v[7,old['solar_anchor_indices']].mean(0),(v[0,old['load_anchor_indices']]-v[1,old['load_anchor_indices']]).mean(0)])
   if j%4096==0:s.guard()
  assert np.isfinite(group).all();np.save(W/'weather_GROUPED.npy',group,allow_pickle=False)
  write('SUPPORT.json',dict(at=s.now(),passed=bool(passed),rows=support,counts=counts,original_first_fold_indices_exact=True,all_original_eval_pairs_preserved=True,eval_pairs=int(sum(counts[k]['eval'] for k in counts)),grouped_features=24,groups_fixed_before_support=True))
  files=[W/'INDICES.npz',W/'weather_GROUPED.npy',W/'SUPPORT.json',W/'DESIGN_BEFORE_SUPPORT.json',Z/'PROTOCOL.json',Z/'SOURCE_COMPLETE.json',F/'ENGINEERING_QA.json',F/'resume_1/SOURCE_REVIEW.json',Path(old['thresholds']),Path(sp['publications']),N/'features.npy',N/'DATA_COMPLETE.json',Z/'weather_COARSE.npy',Z/'PREDICTIONS.npz',Z/'RESULT.json',Z/'PROTECTED_FILES.json']
  files+=list(W.glob('*.py'))+[W/'launch.ps1',F/'disk_hgb.py',Z/'features.py',Z/'support.py',Z/'compare.py',N/'manager.py']
  files+= [F/f'{a}_complete.json' for a in ['HISTORY','COARSE']]
  for arm in ['HISTORY','COARSE']:
   files+= [Path(p) for p in s.read(F/f'{arm}_complete.json')['bindings']]
  assert len(files)==len(set(files))
  protocol=dict(plan,at=s.now(),support_passed=bool(passed),bindings={str(p):s.sha(p) for p in files})
  write('PROTOCOL.json',protocol)
 print(json.dumps(dict(passed=bool(passed),counts=counts,support=support,max_new_fits=4),ensure_ascii=False))
if __name__=='__main__':main()
