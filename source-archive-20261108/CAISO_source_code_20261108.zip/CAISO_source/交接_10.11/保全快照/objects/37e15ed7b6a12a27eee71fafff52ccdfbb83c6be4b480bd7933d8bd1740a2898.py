"""Final release and append-only prediction-commit checks. No market reader."""
import os
from pathlib import Path
import sys
import uuid
HERE=Path(__file__).resolve().parent
sys.path.insert(0,str(HERE.parent/'energy_confirmation_v1_20260926'))
import common as c
FREEZE=HERE/'FINAL_TEST_FREEZE.json';RELEASE=HERE/'RESPONSIBLE_RELEASE.json'

def guard():
    c.guard()
    for name in ('STOP_REQUESTED','STOP_REQUESTED.json'):
        if (HERE/name).exists():raise InterruptedError('Final evaluation pause')

def verify_release():
    c.boundary()
    c.need(FREEZE.exists() and RELEASE.exists(),'Final freeze and actual responsible release required')
    f=c.read(FREEZE);r=c.read(RELEASE)
    c.need(f['status']=='frozen_before_H1_test_access','Invalid final freeze')
    c.need(r.get('status')=='signed_and_verified' and r.get('freeze_sha256')==c.sha(FREEZE),'Release does not bind this package')
    c.need(r.get('authorization_kind')=='explicit_responsible_user_approval' and bool(r.get('actual_user_message')) and r.get('human_signature_fabricated') is False,'Actual responsible authorization required')
    import importlib.metadata as im
    c.need(f['runtime']['python']==sys.version and Path(f['runtime']['executable']).resolve()==Path(sys.executable).resolve(),'Python runtime changed')
    for name,version in f['runtime']['packages'].items():c.need(im.version(name)==version,'Numerical runtime changed')
    for p,d in f['bindings'].items():c.need(c.sha(p)==d,'Frozen dependency changed: '+p)
    c.need(c.read(f['runtime_qa'])['status']=='passed','Final worker QA missing')
    return f

def save_npz(path,**arrays):
    import numpy as np
    path=Path(path);path.parent.mkdir(parents=True,exist_ok=True)
    c.need(not path.exists(),'Preserve committed artifact')
    temp=path.with_name('tmp_'+uuid.uuid4().hex)
    with temp.open('xb') as f:np.savez_compressed(f,**arrays);f.flush();os.fsync(f.fileno())
    temp.rename(path)

def commit_inventory(f):
    cp=HERE/'ALL_PREDICTIONS_COMMITTED.json';c.need(cp.exists(),'All predictions must precede target access')
    inventory=c.read(cp)
    c.need(inventory['freeze_sha256']==c.sha(FREEZE),'Prediction freeze mismatch')
    c.need(set(inventory['cases'])=={row['id'] for row in f['cases']},'Incomplete comparison panel')
    for key,row in inventory['cases'].items():
        c.need(c.sha(row['prediction_path'])==row['prediction_sha256'],'Committed prediction changed')
        receipt=c.read(row['receipt_path'])
        c.need(c.sha(row['receipt_path'])==row['receipt_sha256'] and receipt['fit_calls']==receipt['gradient_steps']==0,'Prediction receipt changed')
        c.need(receipt['case_id']==key and receipt['origins']==f['origins'] and receipt['freeze_sha256']==c.sha(FREEZE),'Prediction panel mismatch')
    return inventory
