"""Post-run review of fixed predictions and a predeclared TRAIN-only probe.

No optimizer, reselection, new test target, or prediction correction is executed.
"""
import sys
from pathlib import Path
import gate as g

OUT=g.HERE/'review_20260928'
EVENT_ID='791f530d2030dbcff21ebe3804bdb24483d00340faba653063eb51b9d654c888'

def main():
    g.need(not (OUT/'REVIEW.json').exists(),'Review already completed; retain it')
    g.verify()
    registration=dict(at=g.now(),event_id=EVENT_ID,source_sha256=g.sha(__file__),
        scope='Diagnostic only after the finite run; no new optimizer updates, selector or tests',
        computations=['Receipt/hash chain','Independent error aggregation','Paired phase0/offhour comparison within identical278complete hour blocks',
                      'Frozen per-node/horizon/state profiles','Attention diagnostics on16preselected TRAIN origins'],
        TRAIN_probe='Positions0,18,...,270 of existing fixed288-origin TRAIN diagnostic; all3seeds, FULL and CHANNEL',
        stopping_rule='One diagnostic pass; no automatic training or test release')
    if (OUT/'REGISTRATION.json').exists():
        g.need(g.read(OUT/'REGISTRATION.json')['source_sha256']==g.sha(__file__),'Diagnostic source changed')
    else:g.write(OUT/'REGISTRATION.json',registration)
    completion=g.read(g.HERE/'queue/completion.json');summary=g.read(g.HERE/'summary.json')
    g.need(g.sha(g.HERE/'queue/completion.json')=='06129c8b625d1f855cddff4439344ee796b9d141a02221cf8e4f210267cec2b1','Event identity mismatch')
    g.need(g.sha(g.HERE/'summary.json')==completion['summary_sha256'],'Summary changed')
    receipts=[]
    for p in sorted((g.HERE/'queue/steps').glob('*.json')):
        r=g.read(p)
        g.need(r['exit_code']==0 and r['seal_sha256']==g.sha(g.SEAL) and r['marker_sha256']==g.sha(r['marker']),'Queue receipt mismatch')
        receipts.append(p.name)
    g.need(len(receipts)==7,'Finite queue receipt count')
    protocol=g.read(g.HERE/'PROTOCOL.json')
    with g.exclusive('channel_postrun_finite_diagnostic'):
        np,torch,limiter=g.runtime()
        from compiled_data import CompiledData
        from models.factory import build_backbone
        from model import ChannelFusion
        data=CompiledData(str(g.MANIFEST))
        raw=[];checks=[];probes=[]
        def metrics(e):
            return dict(mae=float(np.abs(e).mean()),rmse=float(np.sqrt(np.square(e).mean())),
                        near=float(np.abs(e[:,:,:4]).mean()),h12=float(np.abs(e[:,:,11]).mean()))
        for seed in protocol['seeds']:
            g.guard();run=g.HERE/'runs'/str(seed);newmeta=g.read(run/'completion.json');audit=g.read(run/'audit.json')
            g.need(audit['status']=='passed' and audit['completion_sha256']==g.sha(run/'completion.json'),'Seed audit changed')
            g.need(audit['evaluation_sha256']==g.sha(newmeta['evaluation']),'Prediction identity changed')
            with np.load(newmeta['evaluation'],allow_pickle=False) as z:
                n={k:z[k].copy() for k in z.files}
            error=n['prediction']-n['truth'];origins=n['origins']
            hours,counts=np.unique(origins//12,return_counts=True)
            complete=hours[counts==12];mask=np.isin(origins//12,complete)
            phases=origins%12
            g.need(len(complete)==278 and int(mask.sum())==3336,'Complete-hour scope changed')
            for modelname in ('FULL','CONCAT','EQUAL'):
                c=next(c for c in protocol['immutable_controls'] if c['seed']==seed and c['variant']==modelname)
                with np.load(c['evaluation'],allow_pickle=False) as z:
                    g.need(np.array_equal(z['origins'],origins) and np.array_equal(z['truth'],n['truth']) and np.array_equal(z['codes'],n['codes']),'Comparator alignment')
                    olderror=z['prediction']-z['truth']
                scopes={'all3397':np.ones(len(origins),bool),'same278hours_phase0':mask&(phases==0),
                        'same278hours_phases1to11':mask&(phases!=0)}
                scopes.update({f'phase_{p}':mask&(phases==p) for p in range(12)})
                for name,ix in scopes.items():
                    nm=metrics(error[ix]);om=metrics(olderror[ix])
                    raw.append(dict(seed=seed,comparator=modelname,scope=name,origins=int(ix.sum()),new=nm,old=om))
                delta=np.abs(error)-np.abs(olderror)
                checks.append(dict(seed=seed,comparator=modelname,
                    node_MAE_delta=delta.mean((0,2)).tolist(),horizon_MAE_delta=delta.mean((0,1)).tolist(),
                    state_MAE_delta=[dict(state=s,count=int((n['codes']==s).sum()),
                        difference=float(delta[n['codes']==s].mean())) for s in range(6)]))
            # Fixed, descriptive TRAIN probe. Never read new held-out prices.
            diag=np.load(g.ROOT/'phase_sampling_support_v3_20260923/dataset/train_diagnostic_origins.npy',allow_pickle=False)
            probe=diag[np.arange(0,288,18)]
            g.need(len(probe)==16 and (probe+12<=210528).all() and np.isin(probe,data.origins['train_all']).all(),'TRAIN probe scope')
            data.origins['probe']=probe
            limits=g.read(data.paths['context_limits.json'])['limits']
            for label in ('FULL','CHANNEL'):
                if label=='FULL':
                    c=next(c for c in protocol['immutable_controls'] if c['seed']==seed and c['variant']=='FULL')
                    oldmeta=g.read(c['completion']);path=g.ROOT/oldmeta['selected_checkpoint']
                    g.need(g.sha(path)==g.read(path.with_suffix('.receipt.json'))['sha256'],'FULL selected weight identity')
                    model=build_backbone('FULL',seed,limits);value=torch.load(path,map_location='cpu',weights_only=False);model.load_state_dict(value['state_dict'])
                else:
                    cp=newmeta['selected_checkpoint'];g.need(g.sha(cp['path'])==cp['sha256'],'CHANNEL selected weight identity')
                    model=ChannelFusion(seed,limits);value=torch.load(cp['path'],map_location='cpu',weights_only=False);model.load_state_dict(value['model'])
                del value
                model.eval();weights=[];losses=[]
                with torch.no_grad():
                    for start in range(0,16,4):
                        g.guard();x,y=data.batch('probe',np.arange(start,start+4));out=model(torch.from_numpy(x))
                        w=out['branch_weights']
                        weights.append((w[...,0] if label=='FULL' else w[...,0,:]).numpy().copy())
                        losses.append(np.abs((out['prediction'].numpy().astype(np.float64)-y.astype(np.float64))*data.scale[None,:,None]).sum())
                w=np.concatenate(weights);clipped=np.clip(w.astype(np.float64),1e-12,1-1e-12)
                entry=dict(seed=seed,model=label,TRAIN_origins=16,origins=probe.tolist(),
                    tcn_weight_mean=float(w.mean()),tcn_weight_sd=float(w.std()),
                    fraction_weight_below_01_or_above_99=float(((w<.01)|(w>.99)).mean()),
                    binary_entropy_mean=float((-clipped*np.log(clipped)-(1-clipped)*np.log(1-clipped)).mean()),
                    probe_MAE=float(sum(losses)/(16*30*12)))
                if label=='CHANNEL':entry['within_unit_channel_weight_sd_mean']=float(w.std(-1).mean())
                probes.append(entry);del model
        means=[]
        for comparator in ('FULL','CONCAT','EQUAL'):
            for scope in sorted({r['scope'] for r in raw}):
                rows=[r for r in raw if r['comparator']==comparator and r['scope']==scope]
                nmean={k:float(np.mean([r['new'][k] for r in rows])) for k in ('mae','rmse','near','h12')}
                omean={k:float(np.mean([r['old'][k] for r in rows])) for k in nmean}
                means.append(dict(comparator=comparator,scope=scope,origins_per_seed=rows[0]['origins'],new=nmean,old=omean,
                    improvement_percent={k:100*(omean[k]-nmean[k])/omean[k] for k in nmean}))
        for c in summary['comparisons']:
            r=next(r for r in means if r['scope']=='all3397' and r['comparator']==c['comparator'])
            for metric in ('mae','rmse'):
                g.need(abs(r['new'][metric]-c['panels']['June3397']['channel_mean'][metric])<1e-12,'Independent aggregate differs')
                g.need(abs(r['old'][metric]-c['panels']['June3397']['control_mean'][metric])<1e-12,'Independent control aggregate differs')
        conclusions=dict(training_or_metric_bug_detected=False,
            arithmetic_scope='Hashes, separate arithmetic, existing prediction replay audits passed; no blanket proof that every implementation is error-free.',
            candidate_decision='Do not promote CHANNEL; retain original FULL and all results',
            causal_attribution='Phase differences and attention distributions are descriptive; source eligibility, price/state composition, training cadence and gating formulation may interact.',
            confirmation='New model has no independent temporal confirmation. Existing H1 and Europe2016 cannot be reused as untouched tests.',
            training_next='No automatic new training under completed finite protocol')
        g.write(OUT/'REVIEW.json',dict(status='passed_postrun_diagnostic',at=g.now(),event_id=EVENT_ID,
            registration_sha256=g.sha(OUT/'REGISTRATION.json'),summary_sha256=g.sha(g.HERE/'summary.json'),
            queue_receipts_verified=receipts,independent_numeric_aggregation_matches=True,
            phase_matched_means=means,seed_phase_rows=raw,node_horizon_state_differences=checks,
            TRAIN_attention_probe=probes,conclusions=conclusions,optimizer_updates=0,new_test_targets_read=False))
        print(__import__('json').dumps(dict(status='passed_postrun_diagnostic',
            phase_rows=[r for r in means if r['comparator'] in ('FULL','CONCAT') and r['scope'].startswith('same')],
            attention_probe=[{k:v for k,v in r.items() if k!='origins'} for r in probes]),ensure_ascii=False))
if __name__=='__main__':main()
