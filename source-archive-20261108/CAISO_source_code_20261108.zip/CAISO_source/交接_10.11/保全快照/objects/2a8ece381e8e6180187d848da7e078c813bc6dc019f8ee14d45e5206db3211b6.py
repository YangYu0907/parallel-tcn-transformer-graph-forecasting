"""Recompute observable-group diagnostics by slicing horizons and folds first."""
from pathlib import Path
from datetime import datetime, timezone
import hashlib, json, math, sys

H = Path(__file__).resolve().parent
B = H.parent
T = Path('C:/Users/于阳/CAISO_temporary_storage')
sys.path.insert(0, str(B / 'context_expert_v1_20260929'))
import gate

def read(p):
    return json.loads(p.read_text(encoding='utf-8-sig'))

def sha(p):
    with p.open('rb') as f:
        return hashlib.file_digest(f, 'sha256').hexdigest()

checks = 0
def equal(a, b):
    global checks
    if a is None or b is None:
        assert a is b, (a, b)
    else:
        assert math.isclose(float(a), float(b), rel_tol=1e-10, abs_tol=1e-7), (a, b)
    checks += 1

p = read(H / 'PROTOCOL.json')
reg = read(H / 'TEMPORAL_SUPPORT_REGISTRATION.json')
r = read(H / 'TEMPORAL_SUPPORT.json')
assert r['registration_sha256'] == sha(H / 'TEMPORAL_SUPPORT_REGISTRATION.json')
assert reg['script_sha256'] == sha(H / 'temporal_support.py')
for path, digest in (p['bindings'] | p['protected']).items():
    assert sha(Path(path)) == digest, path

folds = {f['id']: f['evaluation'] for f in read(B / 'adaptive_experts_v4_20260929/FOLDS.json')}
with gate.exclusive('V20 temporal support independent-formula audit'):
    np, limiter = gate.runtime(False)
    with np.load(T / 'adaptive_experts_v4_20260929/panel.npz') as z:
        truth, days, regime = (z[k] for k in ('truth', 'days', 'observable_regime'))
    for seed in (20260813, 20260814, 20260815):
        gate.guard()
        with np.load(T / f'mechanism_repair_v18_20260930/CAISO/predictions/{seed}_FULL.npz') as z:
            raw, corrected, ids = (z[k] for k in ('anchor', 'prediction', 'indices'))
        for row in (q for q in r['rows'] if q['seed'] == seed):
            origin_positions = [i for i, ix in enumerate(ids) if int(ix) in set(folds[row['fold']])]
            start = {'near': 0, 'middle': 4, 'far': 8}[row['horizons']]
            sl = slice(start, start + 4)
            ix = ids[origin_positions]
            b, c, y = raw[origin_positions, :, sl], corrected[origin_positions, :, sl], truth[ix, :, sl]
            history = regime[ix] == 2
            if row['history'] == 'inactive':
                history = ~history
            change = c > b if row['direction'] == 'up' else c < b
            mask = change & history[..., None]
            count = int(np.count_nonzero(mask))
            equal(count, row['cells'])
            used_dates = {str(days[ix[k]]) for k in range(len(ix)) if np.any(mask[k])}
            equal(len(used_dates), row['dates'])
            absolute = (np.abs(c - y) - np.abs(b - y))[mask]
            squared = (((c - y) - (b - y)) * ((c - y) + (b - y)))[mask]
            equal(math.fsum(absolute) / count if count else None, row['mean_added_AE'])
            equal(math.fsum(squared) / count if count else None, row['mean_added_SSE'])
            equal(sum(v < 0 for v in absolute) / count if count else None, row['beneficial_fraction'])

for q in r['summary']:
    rows = [x for x in r['rows'] if all(x[k] == q[k] for k in ('history', 'direction', 'horizons'))]
    stable = True
    for fr in q['folds']:
        z = [x for x in rows if x['fold'] == fr['fold']]
        equal(min(x['dates'] for x in z), fr['minimum_dates'])
        for metric in ('mean_added_AE', 'mean_added_SSE'):
            mean = math.fsum(x[metric] for x in z) / 3 if all(x['cells'] for x in z) else None
            equal(mean, fr[metric])
        stable = stable and fr['minimum_dates'] >= 3 and fr['mean_added_AE'] > 0 and fr['mean_added_SSE'] > 0
    equal(stable, q['descriptive_harm_repeats_with_minimum_support'])
equal(sum(q['descriptive_harm_repeats_with_minimum_support'] for q in r['summary']), r['repeated_group_count'])
for path, digest in p['protected'].items():
    assert sha(Path(path)) == digest, path
gate.write(H / 'TEMPORAL_SUPPORT_AUDIT.json', dict(
    at=datetime.now(timezone.utc).isoformat(), status='passed', checks=checks,
    result_sha256=sha(H / 'TEMPORAL_SUPPORT.json'), script_sha256=sha(Path(__file__)),
    independence='Separate process and slice-first aggregation; same operator, not an external reviewer.',
    fits=0, new_test_access=False, protected_unchanged=True))
print(json.dumps(dict(status='passed', checks=checks, repeated_groups=r['repeated_group_count'])))
