"""Preserve all directions; a graph gate is not promoted by a single favorable number."""
import json
import gate
def main():
    gate.verify_evaluation();path=gate.HERE/'result.json';result=gate.read(path)
    for name in ('numeric_audit.json','checkpoint_audit.json'):
        audit=gate.read(gate.HERE/name);gate.need(audit['status']=='passed' and audit['result_sha256']==gate.sha(path),'Missing audit')
        for p,d in audit.get('output_bindings',audit.get('bindings',{})).items():gate.need(gate.sha(gate.inside(p))==d,'Audited output changed')
    prior=gate.read(gate.COMMON/'result.json')['results']
    controls=gate.read(gate.ROOT/'additive_mechanism_controls_v2_20260924/result.json')['results']
    rows={x['id']:x for x in result['results']};refs={x['id']:x for x in prior+controls}
    comparisons=[];decisions=[]
    for c in result['results']:
        seed=c['seed'];reference_ids=['ADDITIVE_'+str(seed)+'_FULL','ADDITIVE_'+str(seed)+'_TCN',str(seed)+'_SELF',str(seed)+'_GLOBAL']
        if c['variant']=='GATE':reference_ids.append(str(seed)+'_MIX')
        for key in reference_ids:
            ref=rows[key] if key in rows else refs[key];panels={}
            for panel in ('June284','June3397','balanced278'):
                panels[panel]={m:dict(candidate=c['panels'][panel][m],reference=ref['panels'][panel][m],
                    reduction_percent=100*(1-c['panels'][panel][m]/ref['panels'][panel][m]))
                    for m in ('mae','rmse','near_h1_4_mae','h12_mae')}
            protect=all(v['candidate']<=v['reference']+1e-9 for p in ('June284','June3397') for v in panels[p].values())
            comparisons.append(dict(candidate=c['id'],reference=key,panels=panels,protects_eight_headline_metrics=protect))
            if key.endswith('_FULL') or key.endswith('_MIX'):
                decisions.append(dict(candidate=c['id'],reference=key,protects_eight_headline_metrics=protect,
                    improves_hourly_and_dense_mae=all(panels[p]['mae']['reduction_percent']>0 for p in ('June284','June3397'))))
    gate.write(gate.HERE/'summary.json',dict(status='four_graph_gate_runs_audited',at=gate.now(),
        comparisons=comparisons,decisions=decisions,all_positive_negative_directions_preserved=True,
        scope='Finite TRAIN/June graph-gating backbone pilot only; no H1 confirmation or standalone significance claim.',
        next='Resolve registered third seed and final model/refinement/source freeze; no automatic gate hyperparameter search.',
        heldout_targets_read=False,complete_research_experiment=False))
    print(json.dumps(dict(status='four_graph_gate_runs_audited',comparisons=len(comparisons))))
if __name__=='__main__':main()
