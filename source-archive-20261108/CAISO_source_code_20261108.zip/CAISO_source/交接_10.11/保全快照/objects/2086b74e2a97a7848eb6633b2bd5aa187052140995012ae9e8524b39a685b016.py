from runner import HERE,old,verify,checked
import os,sys,json,time,subprocess,traceback
def status(**d):old.write(HERE/'STATUS.json',dict(at=old.now(),pid=os.getpid(),**d))
def emit(event,path):
    eid='regularized_gate_'+event+'_'+old.sha(path);dest=old.B/'event_driven_automation/inbox'/(eid+'.json')
    if not dest.exists():old.write(dest,dict(schema='caiso_research_event_v1',event_id=eid,event=event,
        at=old.now(),evidence_path=str(path),evidence_sha256=old.sha(path)))
    return eid
def main():
    lock=HERE/'MANAGER.lock'
    with lock.open('x') as f:json.dump(dict(pid=os.getpid()),f)
    try:
        verify();checked(True);status(event='awaiting_exit_monitor_binding',worker_pid=None)
        deadline=time.monotonic()+45
        while not (HERE/'START_READY.json').exists():
            checked()
            if time.monotonic()>deadline:raise TimeoutError('Exit monitor not registered')
            time.sleep(.2)
        ready=old.read(HERE/'START_READY.json');assert ready['manager_pid']==os.getpid()
        import psutil
        assert psutil.pid_exists(ready['exit_monitor_pid'])
        for script,proof in [('runner.py','RESULT.json'),('audit.py','AUDIT.json')]:
            if (HERE/proof).exists():continue
            checked(True)
            with (HERE/'worker.log').open('a',encoding='utf-8') as log:
                child=subprocess.Popen([sys.executable,'-u',str(HERE/script)],cwd=HERE,stdout=log,stderr=subprocess.STDOUT)
                status(event='step_process_started',worker_pid=child.pid,step=script);code=child.wait()
            if code:checked();raise RuntimeError(script+' exit '+str(code)+'; no automatic retry')
        evidence=HERE/'AUDIT.json';eid=emit('audited_result_ready' if old.read(HERE/'RESULT.json')['screen_passed'] else 'needs_analysis',evidence)
        status(event='finite_sampling_queue_completed',event_id=eid,evidence_path=str(evidence),worker_pid=None)
    except InterruptedError as e:status(event='user_stop',classification='user_stop',worker_pid=None,error=str(e))
    except Exception as e:
        path=HERE/'FAILURE.json';old.write(path,dict(at=old.now(),error=repr(e),traceback=traceback.format_exc(),automatic_retry=False))
        eid=emit('blocking_failure',path);status(event='sampling_blocking_failure',event_id=eid,worker_pid=None,error=repr(e))
    finally:
        if old.read(lock).get('pid')==os.getpid():lock.unlink()
if __name__=='__main__':main()
