from common import *
import numpy as np
import model

def run(p,tick):
    with np.load(W/'INDICES.npz') as aa:a={k:aa[k] for k in aa.files}
    checks=[];rows=[];contrasts=[];pieces={};fits=[];all_gate=True
    def check(name,ok):checks.append(dict(name=name,passed=bool(ok)));assert ok,name
    rng=np.random.default_rng(20261011)
    for fold in p['folds']:
        name=fold['name'];cal,ev=[a[name+'_'+part] for part in ['cal','eval']];y=a['y'][ev];tm=a['time'][ev];probs={};metrics={}
        for arm in p['arms']:
            cell=E/name/arm;rec=read(cell/'DONE.json');check(name+arm+' artifact hashes',all(sha(k)==h for k,h in rec['bindings'].items()))
            cf=read(cell/'CAL_FROZEN.json');fit=read(cell/'FIT.json');fits.append(dict(fold=name,arm=arm,**fit))
            with np.load(cell/'PRED.npz') as q:cp=q['calibration'];ep=q['evaluation'];raw=q['eval_raw']
            check(name+arm+' simplex',np.all(ep>=0) and np.max(np.abs(ep.sum(1)-1))<1e-12)
            th=[float(np.quantile(cp[a['y'][cal]!=c,c],.99,method='higher')) for c in [1,2]];check(name+arm+' calibration',th==cf['thresholds'])
            sample=np.linspace(0,len(ev)-1,min(513,len(ev))).astype(int)
            with np.load(cell/'MODEL.npz') as m:beta=m['beta']
            replay=model.predict(a,ev[sample],arm,read(cell/'BASIS.json'),beta)
            check(name+arm+' replay',np.max(np.abs(replay-raw[sample]))<1e-12)
            key='SMOOTH_'+arm;probs[key]=ep;metrics[key]=model.metric(y,ep,th)
            with np.load(W/name/arm/'PREDICTIONS.npz') as q:
                check(name+arm+' baseline identity',np.array_equal(q['y'],y) and np.array_equal(q['time'],tm) and np.array_equal(q['node'],a['node'][ev]))
                bp=q['evaluation'];bc=q['calibration'];check(name+arm+' baseline calibration identity',np.array_equal(q['cal_y'],a['y'][cal]))
            bt=[float(np.quantile(bc[a['y'][cal]!=c,c],.99,method='higher')) for c in [1,2]]
            key='TREE_'+arm;probs[key]=bp;metrics[key]=model.metric(y,bp,bt)
            for period,mask in [('ALL',np.ones(len(ev),bool))]+[(str(v),(tm.astype('datetime64[s]').astype('datetime64[M]')==v)) for v in np.unique(tm.astype('datetime64[s]').astype('datetime64[M]'))]:
                for tag,q,t in [('SMOOTH_'+arm,ep,th),('TREE_'+arm,bp,bt)]:
                    mm=model.metric(y[mask],q[mask],t)
                    for sign in ['1','2']:rows.append(dict(fold=name,period=period,arm=tag,sign=sign,**mm[sign]))
        days,inv=np.unique(tm//86400,return_inverse=True);count=np.bincount(inv);draw=rng.integers(0,len(days),size=(2000,len(days)))
        for cand,base in p['comparisons']:
            for sign in [1,2]:
                truth=y==sign;q=np.clip(probs[cand][:,sign],1e-15,1-1e-15);r=np.clip(probs[base][:,sign],1e-15,1-1e-15)
                for score in ['brier','logloss']:
                    diff=(q-truth)**2-(r-truth)**2 if score=='brier' else -np.where(truth,np.log(q),np.log1p(-q))+np.where(truth,np.log(r),np.log1p(-r))
                    sums=np.bincount(inv,weights=diff);boot=sums[draw].sum(1)/count[draw].sum(1);observed=float(diff.mean())
                    centered=boot-observed;pvalue=float((1+np.sum(centered<=observed))/(len(boot)+1))
                    contrasts.append(dict(fold=name,candidate=cand,baseline=base,sign=sign,score=score,candidate_minus_baseline=observed,CI95=np.quantile(boot,[.025,.975]).tolist(),p_one_sided=pvalue,UTC_days=len(days)))
        for sign in ['1','2']:
            c=metrics['SMOOTH_COARSE'][sign]
            for baseline in ['SMOOTH_HISTORY','TREE_COARSE']:
                b=metrics[baseline][sign]
                all_gate &= c['brier']<b['brier'] and c['logloss']<b['logloss'] and all(c[k]>=b[k] for k in ['AP','precision','recall']) and c['FPR']<=.02
        pieces[name]=dict(y=y,time=tm,node=a['node'][ev],**probs);tick(stage='audit',fold=name)
    order=np.argsort([r['p_one_sided'] for r in contrasts]);adj=0
    for i,j in enumerate(order):adj=max(adj,min(1.,(len(order)-i)*contrasts[j]['p_one_sided']));contrasts[j]['p_Holm']=adj
    check('24 registered contrasts',len(contrasts)==24)
    all_gate &= all(f['success'] for f in fits)
    all_gate &= all(r['p_Holm']<.05 and r['candidate_minus_baseline']<0 for r in contrasts if r['candidate']=='SMOOTH_COARSE' and r['baseline']=='TREE_COARSE')
    protected=read(Z/'PROTECTED_FILES.json')
    for k,h in protected.items():check('protected '+Path(k).name,sha(k)==h)
    save(E/'PREDICTIONS.npz',**{name+'__'+k:v for name,d in pieces.items() for k,v in d.items()})
    write(E/'AUDIT.json',dict(at=now(),passed=True,checks=checks,protected_files=len(protected),independent_person_review=False,scope='Same-operator invariant/replay checks; not an independent person review; does not validate inference on unseen periods.'))
    result=dict(at=now(),status='completed',passed_promotion_gate=bool(all_gate),fits=fits,metrics=rows,contrasts=contrasts,new_fits=4,new_test_targets_read=False,V7_changed=False,point_price_integration=False,scope=p['scope'],teacher_spike_issue_resolved=False,whole_research_complete=False,audit_sha256=sha(E/'AUDIT.json'))
    write(E/'RESULT.json',result)
    lines=['平滑加性概率实验：4次新拟合，两个开发窗口，上涨/下跌均保留。','通过晋级条件：'+str(bool(all_gate)),'同一操作者程序核验；不是独立人员审核。重复使用开发数据，不是盲测。','V7与价格点预测未改变。']
    for row in rows:
        if row['period']=='ALL':lines.append(f"{row['fold']} {row['arm']} sign={row['sign']} Brier={row['brier']:.8f} LogLoss={row['logloss']:.8f} AP={row['AP']:.6f} P={row['precision']:.4%} R={row['recall']:.4%} TP={row['TP']} FP={row['FP']}")
    (E/'本轮结果.txt').write_text('\n'.join(lines),encoding='utf-8')
