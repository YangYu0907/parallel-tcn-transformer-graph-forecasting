"""Metadata-only review; never loads model/runtime or changes registered training."""
import json
import os
from pathlib import Path
import sys
import uuid

R = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(R))
import gate as g

outer = 'c7fae7c8641ce684e98f290b1305d6fb13cfc30cfb0489b2eaa3982decf90258'
inner = 'residual_attention_blocking_failure_23d1944639a6d3cb100ef8447f37e7405de1ccfbb1ac3f2963a6837ecf4d1fe6'
g.verify()
g.boundary()
import psutil
live = []
for proc in psutil.process_iter(['pid', 'name', 'cmdline', 'create_time']):
    try:
        info = proc.info
        command = ' '.join(info['cmdline'] or [])
        if info['name'].lower() in ('python.exe', 'pythonw.exe') and info['pid'] != os.getpid():
            live.append(info)
    except (psutil.AccessDenied, psutil.NoSuchProcess):
        continue
g.need(not live, 'Other Python process needs review before recovery')
g.need(not g.LOCK.exists() and not (R/'queue/QUEUE.lock').exists(), 'Owner lock remains')
ref = g.read(R/'runs/20260813_CONCAT_CONT/latest.json')
g.need(g.sha(ref['path']) == ref['sha256'], 'Checkpoint hash mismatch')
done = []
for name in ['20260813_RESIDUAL', '20260813_FULL_CONT']:
    receipt = g.read(R/'queue/steps'/f'{name}.json')
    g.need(receipt['exit_code'] == 0, 'Nonzero completed receipt')
    g.need(receipt['marker_sha256'] == g.sha(receipt['marker']), 'Completion changed')
    g.need(receipt['seal_sha256'] == g.sha(g.SEAL), 'Receipt source mismatch')
    value = g.read(receipt['marker'])
    epochs = []
    for row in value['epochs']:
        g.need(g.sha(row['checkpoint']['path']) == row['checkpoint']['sha256'], 'Epoch checkpoint changed')
        g.need(g.sha(row['evaluation']) == row['evaluation_sha256'], 'Epoch predictions changed')
        epochs.append(dict(epoch=row['epoch'], beta=row['beta'], dense={k:row['metrics']['June3397'][k] for k in ['mae','rmse','near_h1_4_mae','h12_mae']}))
    done.append(dict(case=name,status=value['status'],selected_epoch=value['selected_epoch'],optimizer_updates=value['optimizer_updates'],epochs=epochs))
resources = g.cg.resources()
record = dict(at=g.now(),event_id=inner,outer_event_id=outer,
    cause='Runtime physical-memory floor during CONCAT epoch1 evaluation; no source or optimizer error observed',
    failure_resources_GiB=dict(available_physical=3.8757591247558594,available_commit=4.4447479248046875),
    current_resources_GiB=resources,launch_floor_GiB=5,runtime_floor_GiB=4,
    launch_resources_satisfied=min(resources.values())>=5,live_numerical_processes=live,
    checkpoint=ref,checkpoint_hash_verified=True,completed_cases=done,
    separate_numeric_audit_completed=False,new_test_targets_read=False,
    source_seal_unchanged=g.sha(g.SEAL),all_original_results_preserved=True,
    interpretation='Seed13 selected development MAE nearly equal for RESIDUAL and FULL_CONT. Extra training has most of the observed gain; no repair-success conclusion. Remaining matched cases and separate audit are necessary.',
    recovery='Use unchanged launch.ps1 once resource gate passes. Manager verifies/skips two completed receipts; CONCAT resumes epoch1 evaluation at1008updates. Attach new OS exit monitor. No retry timer, source change or budget increase.')
out=R/'operator_records'/('RESOURCE_REVIEW_'+uuid.uuid4().hex+'.json')
g.write(out,record)
handoff=R.parent/'HANDOFF.json'
old=g.read(handoff)
g.write(R/'operator_records'/('HANDOFF.before_resource_review_'+uuid.uuid4().hex+'.json'),old)
work=old['current_authorized_work']
work.update(at=g.now(),status='residual_attention_resource_blocked_checkpoint_preserved',training_active=False,numeric_diagnostic_active=False,manager_pid=None,numerical_child_pid=None,exit_bridge_pid=None,resource_review=str(out),resume_checkpoint=ref,completed_fits_pending_audit=2,latest_verified_progress=ref)
old.update(status=work['status'],updated_at=g.now(),current_work_status='Residual continuation queue stopped by runtime memory protection; two cases complete pending separate numeric audit, third case saved at1008updates. Waiting for existing5GiB launch gate.',ongoing_numeric_process=None,periodic_model_wakeups=False)
old.setdefault('handled_event_ids',[])
for eid in [outer,inner]:
    if eid not in old['handled_event_ids']:old['handled_event_ids'].append(eid)
old['last_handled_event']=dict(event_id=inner,outer_event_id=outer,at=g.now(),record=str(out),notification='Single concise resource-block notification; no additional inbox event')
temp=handoff.with_name('HANDOFF.'+uuid.uuid4().hex+'.pending')
with temp.open('x',encoding='utf-8') as f:
    json.dump(old,f,ensure_ascii=False,indent=2,allow_nan=False);f.flush();os.fsync(f.fileno())
os.replace(temp,handoff)
print(json.dumps(dict(record=str(out),resources=resources,launch_resources_satisfied=record['launch_resources_satisfied'],completed_cases=len(done),checkpoint_step=ref['steps']),ensure_ascii=False))
