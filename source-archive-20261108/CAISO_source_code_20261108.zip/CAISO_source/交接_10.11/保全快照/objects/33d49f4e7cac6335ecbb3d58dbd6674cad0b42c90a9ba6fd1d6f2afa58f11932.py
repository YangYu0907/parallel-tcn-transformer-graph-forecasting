"""Separate saved-prediction scorer and evidence closeout, not external review."""
from pathlib import Path
import sys, json, os, math, shutil
P=Path(__file__).resolve().parent;R=P.parent
sys.path.insert(0,str(R));import common as c
import numpy as np

def put(path,value):
    path=Path(path);path.parent.mkdir(parents=True,exist_ok=True)
    tmp=path.with_suffix(path.suffix+'.tmp')
    tmp.write_text(json.dumps(value,ensure_ascii=False,indent=2,allow_nan=False),encoding='utf-8')
    os.replace(tmp,path)

def main():
    protocol=c.read(P/'PROTOCOL.json')
    for path,expected in protocol['bindings'].items():assert c.sha(path)==expected,path
    rows=[];audit_rows=[];origins=set();dates=set();support=[]
    source_hashes={}
    with c.numeric('Separate savedprediction audit; no training'):
        for f in sorted((P/'cases').glob('*.json')):
            c.guard();record=c.read(f);loc=Path(record['prediction_path'])
            assert c.sha(loc)==record['prediction_sha256']
            source_hashes[str(f)]=c.sha(f);source_hashes[str(loc)]=c.sha(loc)
            with np.load(loc,allow_pickle=False) as a:
                y=a['truth'];base=a['V7'];h=a['horizon'];st=a['states'];o=a['origins'];dd=a['days']
                origins.update(o.tolist());dates.update(dd.tolist())
                masks={'overall':np.ones(len(y),bool),'near':h<4,'h12':h==11}
                for j in range(6):masks[f'S{j}']=st==j
                for j in range(12):masks[f'H{j+1}']=h==j
                for arm in ['IDENTITY','GLOBAL','OBSERVABLE']:
                    pred=a[arm+'_point'];q=a[arm+'_q']
                    assert np.isfinite(pred).all() and np.isfinite(q).all() and (np.diff(q,axis=1)>0).all()
                    assert np.array_equal(pred[h<4],base[h<4])
                    for g,m in masks.items():
                        if not m.any():continue
                        error=pred[m]-y[m];ve=base[m]-y[m]
                        ae=float(np.mean(np.abs(error)));se=float(np.dot(error,error)/len(error))
                        rr=record['rows'][arm][g]['scores']
                        assert np.isclose(ae,rr['decision_ae'],rtol=0,atol=1e-9)
                        assert np.isclose(se,rr['decision_se'],rtol=0,atol=1e-6)
                        rows.append(dict(info=record['info'],seed=record['seed'],window=record['window'],arm=arm,group=g,
                            n=int(m.sum()),mae=ae,mse=se,V7_mae=float(abs(ve).mean()),V7_mse=float(np.dot(ve,ve)/len(ve))))
                    audit_rows.append(dict(case=record['key'],arm=arm,near_exact=True,metrics_recomputed=True,finite_ordered=True))
                assert record['rows']['IDENTITY']['overall']['origins']==len(np.unique(o))
                support.append(dict(case=record['key'],maps={k:{kk:vv for kk,vv in v.items() if kk not in ['inverse_levels','pit_cdf_at_grid']} for k,v in record['maps'].items()}))
    assert len(origins)==428 and len(dates)==28
    summary=c.read(P/'SUMMARY.json')['results'];different=[]
    for info in ['old','new']:
        for g in ['overall','near','h12']+[f'S{j}' for j in range(6)]+[f'H{j+1}' for j in range(12)]:
            for arm in ['IDENTITY','GLOBAL','OBSERVABLE']:
                vals=[]
                for seed in c.SEEDS:
                    rs=[r for r in rows if r['info']==info and r['group']==g and r['arm']==arm and r['seed']==seed]
                    n=sum(x['n'] for x in rs)
                    vals.append((sum(x['mae']*x['n'] for x in rs)/n,math.sqrt(sum(x['mse']*x['n'] for x in rs)/n)))
                target=summary[info][g][arm]['mean']
                assert np.allclose(np.mean(vals,axis=0),[target['decision_mae'],target['decision_rmse']],atol=1e-9)
        # Prespecified no-regression screen, using onepoint forbothmetrics.
        for g in summary[info]:
            primary=summary[info][g]['OBSERVABLE']['mean']
            identity=summary[info][g]['IDENTITY']['mean']
            for met in ['mae','rmse']:
                if primary['decision_'+met]>primary['V7_'+met]+1e-9:
                    different.append(dict(info=info,group=g,metric=met,versus='V7',delta=primary['decision_'+met]-primary['V7_'+met]))
                if primary['decision_'+met]>identity['decision_'+met]+1e-9:
                    different.append(dict(info=info,group=g,metric=met,versus='IDENTITY',delta=primary['decision_'+met]-identity['decision_'+met]))
    protected=c.verify_protected();assert protected==18
    audit=dict(at=c.now(),status='passed',scope='Separateimplementation audit bysameoperator,notexternalreview',
        cases=18,arms_scored=54,origins=428,UTC_dates=28,protected_files_unchanged=18,
        individual_prediction_metrics_and_seed_aggregation_verified=True,quantile_order_verified=True,
        near_bitwise_equal=True,new_test_targets_read=False,neural_fits=0,
        protocol_sha256=c.sha(P/'PROTOCOL.json'),bindings=source_hashes,checks=audit_rows)
    c.write(P/'AUDIT.json',audit)
    decision=dict(at=c.now(),status='candidate_not_promoted',reason='Prespecified point/probability retention criteria notmet;realizedregressionspersist',
        retained_model='V7',primary='OBSERVABLE',regressions=different,support=support,
        all_results_retained=True,training_active=False,no_new_test_target_access=True,
        next_data_requirement='Compatible frozenparent predictions and maturelabels spanning genuinely more abnormal episodes,including spikeonset/nononset/recovery;enlarged calibration cannot be made by moving present evaluationlabels backward.',
        knowledge_boundary='These findings identify estimated-risk/realized-risk mismatch and sparsecalibration support. They do not prove unavailable information,irreducibleforecast error,or guarantee a larger model/calibration set will fixspikes.',
        reopen_condition='Newtime-available information or compatible additional event data,then fixedmatchedprotocol;not a differentthreshold on thesame18cases.')
    c.write(P/'DECISION.json',decision)
    fair=c.read(R/'FAIR_COMPLETE.json');seal=c.read(R/'FAIR_INPUT_SEAL.json')
    ablation=c.read(c.FIRST/'V7_REFIT_AUDIT.json')
    teacher=dict(at=c.now(),issues=[
        dict(issue=1,name='动态图跨任务效果不一致',status='尚未消除',criterion='同信息、同预算FULL/STATIC/SELF的配对跨期比较；本轮下游校准不能充当图机制证据'),
        dict(issue=2,name='对比模型输入不一致',status='指定价格单信息对照已完成',criterion='FULL/iTransformer/DLinear共同价格输入面板；不可扩大为所有原表输入均已一致',evidence=str(R/'FAIR_INPUT_SEAL.json')),
        dict(issue=3,name='V7模块未拆开消融',status='已有12类配置及必要重训',criterion='区分重新拟合消融与冻结干预，不宣称每个模块都有正贡献',evidence=str(c.FIRST/'V7_REFIT_AUDIT.json')),
        dict(issue=4,name='尖峰幅度改善不足',status='尚未解决',criterion='突发/持续/回落分别检查点误差、事件检测、事件数；本轮没有达到保留标准'),
        dict(issue=5,name='缺概率预测',status='概率预测已实现；独立确认未完成',criterion='冻结的点不变概率候选仍保留；新增CDF校准未改善全部概率指标',evidence=str(R/'unified_distribution_20261004/point_anchored_candidate/FREEZE.json'))],
        protected_model='V7',new_test_target_access=False,
        checked_evidence={str(R/'FAIR_COMPLETE.json'):c.sha(R/'FAIR_COMPLETE.json'),str(R/'FAIR_INPUT_SEAL.json'):c.sha(R/'FAIR_INPUT_SEAL.json'),str(c.FIRST/'V7_REFIT_AUDIT.json'):c.sha(c.FIRST/'V7_REFIT_AUDIT.json')})
    c.write(P/'TEACHER_STATUS.json',teacher)
    old=c.read(R/'compatibility_execution_20261004/RESULT.json')
    result=c.read(P/'RESULT.json');s=summary['new']
    lines=['本轮实验与验收记录','日期：2026-10-04','',
        '执行范围：两个固定实验，均使用已查看的CAISO开发数据；428起点、28个UTC日期、30节点、12步、三个前向窗口、三个种子。不可同698起点的V7旧表直接比较。',
        '第一轮：18组解析风险相容性检验，零模型重训。第二轮：18组CDF校准实验，拟合42个经验校准映射，零神经网络重训。第二轮用原CDF、全局校准、可见情境校准三个完整对照，共54个输出比较。',
        '近端H1-H4点预测逐元素完全不变。V7模型、论文等18个受保护文件哈希不变。新独立测试目标未读取。',
        '', '同一428起点面板、新信息集、三个种子指标均值：',
        '范围 | 原V7 MAE/RMSE | 原CDF相容修正 MAE/RMSE | 可见情境CDF校准 MAE/RMSE']
    for g in ['overall','near','h12','low_volatility']+[f'S{j}' for j in range(6)]:
        orig=s[g]['IDENTITY']['mean'];v=s[g]['OBSERVABLE']['mean']
        lines.append(f"{g} | {orig['V7_mae']:.4f}/{orig['V7_rmse']:.4f} | {orig['decision_mae']:.4f}/{orig['decision_rmse']:.4f} | {v['decision_mae']:.4f}/{v['decision_rmse']:.4f}")
    lines+=['','概率结果（完整分布评分；该分布的中位数和相容点决策不是同一对象，二者分别保存）：']
    for arm in ['IDENTITY','GLOBAL','OBSERVABLE']:
        v=s['overall'][arm]['mean'];lines.append(f"{arm}: WIS={v['wis']:.6f}; 80%覆盖率={100*v['coverage80']:.3f}%; 90%覆盖率={100*v['coverage90']:.3f}%; 高价Brier={v['high_brier']:.6f}; 低价Brier={v['low_brier']:.6f}")
    lines+=['','验收：两个新增方案均不替换V7。原CDF相容修正虽改善总体/60分钟，仍有S1及S4回退；可见情境CDF校准虽改善S0/S3/S4，S2/S5及总体RMSE回退，WIS和覆盖也未全部改善。',
        '归因证据：约束预测分布中的绝对/平方风险同时不升，实际仍有回退，说明内部风险判定不等于后续真实收益。校准每窗仅5个UTC日期；异常可见状态经常只有1–3天，触发事先登记的数据不足回退。此证据支持优先解决事件支撑和分布可靠性，不证明唯一根因。',
        '理论：Kuleshov等ICML2018提出单调CDF再校准；Song等ICML2019指出整体分位数校准不等于条件分布校准。本轮日期等权、可见状态分组及5日/30起点门槛是待检验实现，不冒称论文最优或具时间相关数据下的覆盖保证。',
        'https://proceedings.mlr.press/v80/kuleshov18a.html','https://proceedings.mlr.press/v97/song19a.html','',
        '老师五项意见验收：']
    for issue in teacher['issues']:lines.append(f"{issue['issue']}. {issue['name']}：{issue['status']}。{issue['criterion']}。")
    lines+=['','后续边界：先核准与当前冻结父模型兼容的、包含更多独立异常事件的数据和预测库；不得直接合并旧父模型/不同归一化的22935起点库，不得把已评分日期改成未见测试。点值与概率路径分开管理，公平输入/消融证据复用，避免重复计算。',
        '当前数值进程已结束；本地事件监听保留；未创建定时唤醒。没有宣称已解决全部教师问题。',
        '完整逐种子/节点/预测期/月份/状态：'+str(P/'SUMMARY.json'),
        '独立公式与保存预测复算：'+str(P/'AUDIT.json')]
    (P/'REPORT.txt').write_text('\n'.join(lines)+'\n',encoding='utf-8-sig')
    O=c.A/'修补总复盘_20261004'
    shutil.copy2(P/'REPORT.txt',O/'本轮实验结果_20261004.txt')
    hpath=c.B/'HANDOFF.json';backup=P/'HANDOFF.before_execution_close.json'
    if not backup.exists():shutil.copy2(hpath,backup)
    handoff=c.read(hpath)
    handoff['current_work_status']='Finite compatibility and CDFcalibration experiments completed;V7 retained;teacherissues1/4 andindependentprobabilityconfirmation unresolved'
    handoff['last_updated_at']=c.now()
    handoff['research_training_active']=False
    handoff['numeric_diagnostic_active']=False
    handoff['teacher_execution_20261004']=dict(at=c.now(),human_request='我的要求始终是，老师提出的问题必须解决，现在开始实验',
        compatibility_result=str(R/'compatibility_execution_20261004/RESULT.json'),cdf_result=str(P/'RESULT.json'),
        audit=str(P/'AUDIT.json'),decision=str(P/'DECISION.json'),report=str(O/'本轮实验结果_20261004.txt'),
        teacher_status=str(P/'TEACHER_STATUS.json'),active_worker=False,new_test_targets_read=False,V7_replaced=False,
        source_admission_still_required_for_independent_confirmation=True,
        scheduling='No scheduledwakeups;existingfileeventwatcher retained;foregroundworkerscompleted,no newmanagerleft running')
    handoff['next_authorized_actions']=['Audit compatible additional event library and unresolved independent admission without reading sealedtargets',
        'Reuse completedfair-input andV7ablation evidence;no duplicate neuraltraining',
        'Onlylaunch a differentpoint candidate after newinformation/compatibleevent support isverified andfiniteprotocolisfixed']
    put(hpath,handoff)
    put(O/'EXECUTION_UPDATE_20261004.json',dict(at=c.now(),results=str(P/'RESULT.json'),audit=str(P/'AUDIT.json'),report=str(O/'本轮实验结果_20261004.txt'),
        teacher_status=str(P/'TEACHER_STATUS.json'),V7_replaced=False,active_worker=False,completed_experimental_cases=36,empirical_calibration_maps=42))
    assert c.verify_protected()==18
    print(json.dumps(dict(audit='passed',cases=18,outputs=54,origins=428,dates=28,report=str(O/'本轮实验结果_20261004.txt'),retained='V7'),ensure_ascii=False))

if __name__=='__main__':main()
