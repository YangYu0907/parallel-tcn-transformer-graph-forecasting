"""Record the user's expanded scope without fitting models or accessing targets."""
import hashlib
import json
import os
from datetime import datetime, timezone
from pathlib import Path

HERE = Path(__file__).resolve().parent
BASE = HERE.parent
NOW = datetime.now(timezone.utc).isoformat()


def read(path):
    return json.loads(Path(path).read_text(encoding='utf-8-sig'))


def sha(path):
    h = hashlib.sha256()
    with Path(path).open('rb') as f:
        for chunk in iter(lambda: f.read(1024 * 1024), b''):
            h.update(chunk)
    return h.hexdigest()


def save(path, obj):
    path = Path(path)
    tmp = path.with_name(path.name + '.tmp')
    tmp.write_text(json.dumps(obj, ensure_ascii=False, indent=2) + '\n', encoding='utf-8')
    os.replace(tmp, path)


handoff_path = BASE / 'HANDOFF.json'
original = handoff_path.read_bytes()
handoff = json.loads(original.decode('utf-8-sig'))
backup = HERE / 'HANDOFF_before_revision.json'
if backup.exists():
    raise SystemExit('Registration already started; inspect existing records before repeating.')
backup.write_bytes(original)

old_protocol = read(BASE / 'retention_diagnosis_v20_20260930/PROTOCOL.json')
protected = dict(old_protocol['protected'])
for path, expected in protected.items():
    if sha(path) != expected:
        raise RuntimeError('Protected file changed: ' + path)
paper = Path(handoff['focused_manuscript_20261001']['directory'])
for name in ('Energy_manuscript.docx', 'Energy_manuscript.pdf',
             'Energy_supplementary.docx', 'Energy_supplementary.pdf', 'DELIVERY_MANIFEST.json'):
    protected[str(paper / name)] = sha(paper / name)
save(HERE / 'RETAINED_BASELINE_HASHES.json', {
    'at': NOW, 'status': 'verified_existing_V7_hashes_and_snapshotted_current_manuscript',
    'files': protected, 'target_arrays_decoded': False,
    'scope': 'Integrity only; no model-performance or independent-person audit asserted.'})

references = [
    {'id': 'ASTGCN', 'url': 'https://ojs.aaai.org/index.php/AAAI/article/view/3881',
     'use': 'Spatial-temporal attention as a testable mechanism; traffic results do not establish price gains.'},
    {'id': 'MTGNN', 'url': 'https://arxiv.org/abs/2005.11650',
     'use': 'Learned sparse relations and retention of local information; does not prove current graph noise.'},
    {'id': 'TFT', 'url': 'https://arxiv.org/abs/1912.09363',
     'use': 'Gated feature processing and residual paths; no guarantee against CONCAT.'},
    {'id': 'GLU', 'url': 'https://proceedings.mlr.press/v70/dauphin17a.html',
     'use': 'Gated transformations; language-model evidence, not a price-forecasting result.'},
    {'id': 'combinations', 'url': 'https://arxiv.org/abs/2205.04216',
     'use': 'Conditional combination benefits must outweigh estimation error relative to simple alternatives.'},
    {'id': 'selection_bias', 'url': 'https://jmlr.org/papers/v11/cawley10a.html',
     'use': 'Separate repeated development selection from final independent evaluation.'}
]

prior_paths = [
    'branch_values_v1_20260925/PROTOCOL.json',
    'branch_values_v1_20260925/summary.json',
    'branch_fusion_diagnostic_20260925/PROTOCOL.json',
    'graph_gate_v1_20260924/PROTOCOL.json',
    'graph_prior_v1_20260929/PROTOCOL.json',
    'aff_joint_v1_20260929/model.py',
    'channel_attention_v1_20260927/model.py',
    'residual_attention_v1_20260928/model.py',
    'mechanism_repair_v18_20260930/DECISION.json',
    'retention_diagnosis_v20_20260930/NEXT_DECISION.json',
    'retention_diagnosis_v20_20260930/SOURCE_RECHECK.json',
    'source/models/model_feature_fusion_rev12.py',
    'energy_confirmation_v1_20260926/europe_model.py'
]
save(HERE / 'PRIOR_WORK_REVIEW.json', {
    'at': NOW, 'status': 'code_and_existing_records_reviewed_no_new_numeric_experiment',
    'bindings': {p: sha(BASE / p) for p in prior_paths},
    'avoid_duplicate_hypotheses': [
        'Linear branch-specific residual value projections were already trained in nine matched cases; not a new idea.',
        'Scalar self/dynamic graph mixing and context-dependent mixing were already tried.',
        'Channel attention, zero-initialized residual attention and joint-content logits were already tried.',
        'Earlier branch diagnostic reported near-unit norm ratios and no extreme softmax saturation; do not assert saturation as the cause.',
        'Any new GLU/value interaction needs a precise distinction from these trials and a diagnostic reason.'
    ],
    'code_facts': [
        'Existing dynamic adjacency already uses history-conditioned scores and top-k selection.',
        'Europe uses 3 markets and top_k=2, retaining both possible other markets before weighting.',
        'Full fusion uses horizon-dependent branch attention and weighted feature summation before the shared head.',
        'Softmax over two scores equals a sigmoid of their difference; an activation-only rename is not a new mechanism.'
    ],
    'causes_established': False, 'new_test_targets_read': False})

plan = {
    'at': NOW, 'status': 'multi_round_framework_registered_candidate_details_pending_diagnosis_and_admission',
    'user_instruction': '我们认为可以有更多次改进机会，我还是想把四个问题都试着解决一下',
    'change': 'Remove the one-remaining-candidate cap; reopen all four questions within separately registered finite batches.',
    'unchanged': ['V7 fallback and all existing evidence', 'TCN', 'Transformer', 'dynamic GNN',
                  'parallel branches', 'adaptive weighted feature attention',
                  'fresh-source admission before new fitting', 'freeze before final target access',
                  'no tuning on previously inspected tests', 'all result directions retained'],
    'first_batch': {
        'initial_model_candidates_max': 3, 'one_candidate_per_mechanism_route': True,
        'conditional_integration_candidates_max': 1,
        'conditional_integration_rule': 'Only combine components with positive standalone development evidence; explicitly measure interactions and unchanged V7 retention.',
        'next_batch_rule': 'May register another finite batch under this authorization only after identifying a supported error mechanism, a distinct remedy, and its cost/benefit. No automatic parameter grid or repeated identical trial.',
        'numeric_budgets': 'Exact epochs/updates, time cap, estimator, hyperparameters and data hashes must be sealed per route before fitting; this framework is not a launch authorization by itself.',
        'seeds': [20260813, 20260814, 20260815],
        'execution': 'Serial numerical worker; independent metadata/code preparation can proceed without fitting.'
    },
    'routes': [
        {'id': 'H', 'issue': 4, 'priority': 1,
         'hypothesis': 'Origin-available features can predict when retained far-horizon corrections have harmful direction.',
         'candidate': 'Chronologically calibrated correction-benefit gate, not another conditional price-risk model.',
         'formula': 'new = V7 - a(x,h)*(V7-anchor), 0<=a<=1',
         'exact_protection': 'Copy V7 outputs at H1-H8 and in the original causal low-volatility mask; only other H9-H12 outputs may change.',
         'controls': ['unchanged V7', 'same new procedure on corrected FULL, CONCAT and EQUAL'],
         'failure_risk': 'Reversion may remove helpful corrections; anchor improvement does not establish superiority over matched corrected controls.'},
        {'id': 'F', 'issue': 2, 'priority': 2,
         'diagnosis': 'Use original training/validation only to check per-horizon branch disagreement, feature interaction, gradients and generalization across dates. Do not diagnose using September target errors.',
         'candidate_family': 'One residual gated nonlinear feature interaction if supported, preserving original adaptive attention and avoiding direct concatenation as the FULL fusion rule.',
         'novelty_gate': 'Must differ materially from old linear value projections, channel/residual softmax and AFF joint-logit trials; no plain Softmax-to-sigmoid substitution.',
         'controls': ['matched attention, EQUAL and CONCAT', 'same added feature processing, data and training opportunity', 'old V7 end-to-end pipeline'],
         'protection': 'Preserve frozen reference and identity initialization; global output protection is not guaranteed after changing shared features.',
         'failure_risk': 'Extra capacity may increase selection variance or change useful branch features.'},
        {'id': 'G', 'issue': 1, 'priority': 3,
         'diagnosis': 'On allowed development inputs examine edge support stability across real chronological neighbors, self/cross message sizes, and interventions against fixed controls; descriptive correlation is not causation.',
         'candidate_family': 'Choose one diagnosed graph change: sparse edge selection, edge reliability, or temporal attention. Do not simultaneously change all three.',
         'novelty_gate': 'Existing top-k, self/dynamic convex gates and graph prior trials must be accounted for. L1 on nonnegative row-normalized adjacency is constant and is not an effective sparsity penalty.',
         'controls': ['matched dynamic, STATIC and SELF with common non-graph processing', 'end-to-end retained task reference'],
         'scope': 'CAISO and Europe evaluated separately; a CAISO improvement cannot resolve European graph comparisons.',
         'failure_risk': 'Removing edges may remove useful information; shared graph changes affect both temporal branches.'},
        {'id': 'S', 'issue': 3, 'priority': 'shared_confirmation',
         'method': 'Estimate dependence and precision from development-only date-block loss differences; predefine meaningful effect, target calendar coverage and fixed stopping rule before release.',
         'controls': 'Report all seeds and all preregistered contrasts; paired time-block inference and Holm family preserved.',
         'forbidden': 'No extra seeds counted as extra dates; no testing repeatedly until p<0.05; no test-based selection of successful model versions.',
         'claim': 'Failure to reject is not proof of equality; significance is not guaranteed by additional computation.'}
    ],
    'retention_and_promotion': {
        'baseline': 'Archive and checksum old V7; new experiments never overwrite its weights, predictions, results or paper.',
        'inventory': 'Seal the existing positive comparator/metric directions on the same development panel before fitting. Later tests have their own complete table; no cross-panel best-number mixing.',
        'gate': 'Mean MAE and RMSE must not regress against V7 and registered positive comparison directions must remain positive for promotion to replace V7; report all state/node/horizon directions.',
        'exact_vs_empirical': 'Only H-route protected outputs are mechanically identical. F/G and combined routes require empirical retention checks; gains on unseen data cannot be guaranteed.',
        'integration': 'Freeze one full pipeline; perform common full-vs-ablation and external-baseline comparisons with matched opportunities. Do not combine best metrics from different candidates.',
        'no_promotion': 'Candidates failing retention remain archived research evidence; V7 remains the delivery model.'
    },
    'data_gate': {
        'CAISO': 'No new untouched panel currently admitted; prior H1/August/September access remains recorded.',
        'Europe': '2017 historical version semantics and market-day/DST compatibility still unresolved.',
        'before_fit': 'Source/input/access audit must qualify an unused confirmation panel for the task; no targets decoded during metadata review.',
        'development': 'Use task-specific original training/validation or explicitly declared inspected development data; do not recycle September or Europe2016 as new selection sets.',
        'multiple_batches': 'Keep final test targets sealed throughout development batches; choose final model on development only, then score once. A subsequent revision after viewed test results requires a different untouched confirmation period.'
    },
    'operations': {'drive': 'F', 'single_numeric_worker': True, 'launch_available_GiB': 5,
                   'runtime_available_GiB': 4, 'checkpointing': True,
                   'event_only_notifications': True, 'periodic_model_wakeups': False,
                   'new_manager_requires_exit_listener': True},
    'literature': references,
    'new_fits': 0, 'new_test_targets_read': False, 'new_model_promoted': False,
    'complete_research_experiment': False
}
plan_path = HERE / 'ROUND_PLAN.json'
save(plan_path, plan)
amendment_path = BASE / 'TASK_MULTI_ROUND_REVISION_20261001.json'
save(amendment_path, {
    'at': NOW, 'status': 'active_user_authorized_scope_revision',
    'user_instruction': plan['user_instruction'], 'plan': str(plan_path),
    'plan_sha256': sha(plan_path),
    'supersedes': ['retention_diagnosis_v20_20260930/FINAL_OPPORTUNITY_SCOPE.json: one-candidate cap and exclusion of graph/fusion routes',
                   'HANDOFF.json: next_action and final_improvement_opportunity'],
    'preserves': plan['unchanged'], 'original_scope_file_unchanged': True,
    'new_fits': 0, 'new_test_targets_read': False})

handoff['final_improvement_opportunity'] = {
    'status': 'superseded_by_user_authorized_multi_round_scope',
    'old_scope': str(BASE / 'retention_diagnosis_v20_20260930/FINAL_OPPORTUNITY_SCOPE.json'),
    'superseded_by': str(amendment_path), 'previous_state_backup': str(backup)}
handoff['multi_round_mechanism_v21'] = {
    'at': NOW, 'directory': str(HERE), 'amendment': str(amendment_path),
    'plan': str(plan_path), 'prior_review': str(HERE / 'PRIOR_WORK_REVIEW.json'),
    'status': 'framework_and_prior_code_review_complete_pending_source_admission_and_route_preregistration',
    'V7_preserved': True, 'new_fits': 0, 'numerical_worker_active': False,
    'new_test_targets_read': False, 'periodic_wakeups': False}
handoff['next_action'] = (
    'User authorizes multiple finite improvement rounds across all four issues, replacing the one-candidate cap. '
    'Read TASK_MULTI_ROUND_REVISION_20261001.json and multi_round_mechanism_v21_20261001/ROUND_PLAN.json. '
    'Retain V7. First close task-specific fresh-source admission and complete development-only diagnosis; '
    'then register and run separate horizon-benefit, fusion and graph candidates with matched controls, '
    'combining only supported components. Do not repeat already-tried linear value projections or gate changes '
    'without a distinct supported hypothesis. No fit before admission, no viewed-test tuning, no periodic wakeups.')
handoff['next_actions'] = [
    'Qualify untouched CAISO and European confirmation sources independently without reading target values.',
    'Diagnose each route using allowed development scope and check against prior-work registry.',
    'Preregister bounded candidates and retention inventory; run one numerical worker only after gates pass.',
    'Integrate successful components and freeze before one final common-panel confirmation; retain V7 otherwise.'
]
if handoff_path.read_bytes() != original:
    raise RuntimeError('HANDOFF changed concurrently; refusing to overwrite.')
save(handoff_path, handoff)
unchanged = all(sha(path) == expected for path, expected in protected.items())
if not unchanged:
    raise RuntimeError('Protected artifact changed during registration.')
save(HERE / 'REGISTRATION_QA.json', {
    'at': NOW, 'status': 'passed', 'plan_parseable': read(plan_path)['new_fits'] == 0,
    'handoff_points_to_revision': read(handoff_path)['multi_round_mechanism_v21']['amendment'] == str(amendment_path),
    'protected_files_unchanged': len(protected), 'protected_hashes_all_match': unchanged,
    'new_fits': 0, 'new_test_targets_read': False,
    'audit_scope': 'Same-operator integrity and scope consistency checks, not independent model validation.',
    'event_watcher_left_unchanged': True})
print(json.dumps({'status': 'scope_updated_and_verified', 'plan': str(plan_path),
                  'protected_files': len(protected), 'new_fits': 0}, ensure_ascii=False))
