"""Target-free actual-parent replay, hourly invariance and raw-tensor formula."""
import json,sys
import gate
def main():
 with gate.exclusive('horizon_adapter_real_parent_QA'):
  np,torch,lim=gate.runtime()
  from compiled_data import CompiledData
  from models.factory import build_backbone
  from adapter import AdaptedFULL,fingerprint
  seal=gate.read(gate.PARENT/'ADAPTER_LOCK.json')
  # Verify inherited source/checkpoints without reading heldout target arrays.
  for p,d in seal['bindings'].items():gate.need(gate.sha(gate.inside(p))==d,'Parent binding changed')
  data=CompiledData(seal['dataset_manifest']);limits=gate.read(data.paths['context_limits.json'])['limits']
  dense=data.origins['june_dense'];registered=data.origins['june']
  probes=list(np.flatnonzero(np.isin(dense,registered))[:12])+list(np.flatnonzero(dense%12!=0)[:12])
  gate.need(len(probes)==len(set(probes))==24,'Probe population changed')
  rows=[]
  for c in seal['cases']:
   if c['arm']!='OFFHOUR':continue
   parent=c['parent'];path=gate.inside(parent['selected_checkpoint'])
   base=build_backbone('FULL',c['seed'],limits)
   base.load_state_dict(torch.load(path,map_location='cpu',weights_only=False)['state_dict']);base.eval()
   model=AdaptedFULL(base,c['seed'],'HORIZON').eval()
   receipt=gate.read(gate.inside(parent['dense_receipt']))
   gate.need(gate.sha(gate.inside(receipt['artifact']))==receipt['artifact_sha256'],'Dense reference changed')
   with np.load(gate.inside(receipt['artifact']),allow_pickle=False) as z:reference=z['prediction'][probes]
   base_fp=fingerprint(base);maxdiff=0.;protected=0.;changed=False;formula=0.;h12only=True
   with torch.inference_mode():
    for start in range(0,24,4):
     gate.guard();ix=np.array(probes[start:start+4]);origins=dense[ix]
     # Read only historical features; no data.batch target access in this QA.
     x,unused_target=data.batch('june_dense',ix,with_target=False)
     gate.need(unused_target is None,'Target-free QA')
     tx=torch.from_numpy(x);mask=torch.from_numpy((origins%12==0).copy())
     original=base(tx);initial=model(tx,mask)
     usd=initial['prediction'].numpy().astype(np.float64)*data.scale[None,:,None]+data.center[None,:,None]
     maxdiff=max(maxdiff,float(np.max(np.abs(usd-reference[start:start+4]))))
     assert torch.equal(initial['branch_weights'],original['branch_weights'])
     assert torch.equal(initial['dynamic_adjacency'],original['dynamic_adjacency'])
     model.adapter.blocks[11].up.bias.add_(.02)
     out=model(tx,mask)
     protected=max(protected,float((out['prediction'][mask]-original['prediction'][mask]).abs().max()) if mask.any() else 0.)
     if (~mask).any():changed=changed or not torch.equal(out['prediction'][~mask,:,11],original['prediction'][~mask,:,11])
     h12only=h12only and torch.equal(out['prediction'][:,:,:11],original['prediction'][:,:,:11])
     features=[]
     for h,block in enumerate(model.adapter.blocks):
      z=torch.nn.functional.linear(original['head_features'][:,:,h],block.down.weight,block.down.bias)
      delta=torch.nn.functional.linear(torch.nn.functional.gelu(z),block.up.weight,block.up.bias)
      features.append(original['head_features'][:,:,h]+delta)
     raw=base.head(torch.stack(features,dim=2))
     raw=torch.where(~mask[:,None,None],raw,original['prediction'])
     formula=max(formula,float((raw-out['prediction']).abs().max()))
     model.adapter.blocks[11].up.bias.zero_()
   gate.need(maxdiff==0 and protected==0 and changed and h12only and formula==0 and fingerprint(base)==base_fp,'Actual model probe failed')
   rows.append(dict(seed=c['seed'],zero_replay_difference=maxdiff,hourly_difference=protected,offhour_changed=changed,
    only_addressed_horizon_changed=h12only,raw_formula_difference=formula,probe_origins=24))
  sources={gate.rel(p):gate.sha(p) for p in gate.HERE.glob('*.py')}
  gate.write(gate.HERE/'real_model_qa.json',dict(status='passed',at=gate.now(),rows=rows,sources=sources,heldout_targets_read=False))
  print(json.dumps(dict(status='passed',cases=len(rows),probe_origins=24*len(rows))))
if __name__=='__main__':main()
