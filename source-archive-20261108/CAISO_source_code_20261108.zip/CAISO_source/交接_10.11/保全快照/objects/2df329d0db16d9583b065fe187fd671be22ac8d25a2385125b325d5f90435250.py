"""Close a finite diagnostic; never starts training or reads fresh targets."""
from pathlib import Path
import json
import os
import uuid
import psutil
import gate as g

OUT = g.HERE / 'outcome_review'
EVENT_ID = 'c64b2ba3752e877ecc8000097bbfe915ea3288691e56efccc7602290e47a2465'
INNER_ID = 'selection_alignment_audited_result_ready_c3121b03eaebc6ddd7c69d0b5498773395b89e0f58ebfc7e6fb15ac882498a1b'


def atomic_external(path, value):
    path = path.resolve()
    g.need(path == (g.ROOT / 'HANDOFF.json').resolve(), 'Unexpected shared write')
    temp = path.with_name('handoff_' + uuid.uuid4().hex + '.pending')
    with temp.open('x', encoding='utf-8', newline='\n') as f:
        json.dump(value, f, ensure_ascii=False, indent=2, allow_nan=False)
        f.flush()
        os.fsync(f.fileno())
    os.replace(temp, path)


def main():
    g.verify()
    event = g.ROOT / 'event_driven_automation/inbox' / (INNER_ID + '.json')
    completion = g.read(g.HERE / 'queue/completion.json')
    result = g.read(g.HERE / 'RESULT.json')
    audit = g.read(g.HERE / 'AUDIT.json')
    review = g.read(OUT / 'REVIEW.json')
    g.need(completion['result_sha256'] == g.sha(g.HERE / 'RESULT.json'), 'Result hash')
    g.need(completion['audit_sha256'] == g.sha(g.HERE / 'AUDIT.json'), 'Audit hash')
    g.need(audit['status'] == 'passed' and audit['checkpoints'] == 108 and audit['checks'] == 972, 'Audit incomplete')
    g.need(g.sha(g.HERE / 'queue/completion.json') == INNER_ID.rsplit('_', 1)[1], 'Event mismatch')
    g.need(not g.LOCK.exists(), 'Numerical worker lock exists')
    live = []
    for p in psutil.process_iter(['pid', 'create_time', 'name', 'cmdline']):
        try:
            cmd = ' '.join(p.info['cmdline'] or [])
            if p.pid != os.getpid() and (g.ROOT.name in cmd or 'CAISO' in cmd) and p.info['name'].lower() in ('python.exe', 'pythonw.exe'):
                live.append(p.info)
        except (psutil.NoSuchProcess, psutil.AccessDenied):
            continue
    g.need(not live, 'Unexpected numerical/research Python process')
    watcher = psutil.Process(23800)
    g.need('event_driven_automation' in ' '.join(watcher.cmdline()) and 'watch.ps1' in ' '.join(watcher.cmdline()), 'Wrong event watcher identity')
    process = dict(at=g.now(), numerical_processes=live, numerical_lock_exists=False,
                   watcher_pid=watcher.pid, watcher_created=watcher.create_time(),
                   watcher_command=watcher.cmdline(), completed_manager_pid=23600,
                   completed_worker_pid=14112, completed_exit_bridge_pid=7180)
    g.write(OUT / 'PROCESS_CHECK.json', process)
    paths = [event, g.HERE/'queue/completion.json', g.HERE/'RESULT.json', g.HERE/'AUDIT.json',
             g.HERE/'EXECUTION_SEAL.json', OUT/'REVIEW.json', OUT/'SCHEDULE_METADATA.json',
             OUT/'PROCESS_CHECK.json', g.ROOT/'channel_attention_v1_20260927/FUTURE_TEST_METADATA.json',
             g.ROOT/'channel_attention_v1_20260927/review_20260928/DECISION.json']
    previous = g.read(paths[-1])
    proposal = previous['next_matched_control_proposal']
    decision = dict(
        at=g.now(), status='finite_selection_diagnostic_closed_partial_development_gain',
        event_id=EVENT_ID, inner_event_id=INNER_ID,
        evidence={str(p):g.sha(p) for p in paths},
        scope='June3397 development origins x30 nodes x12 horizons; three seed metrics averaged, not an ensemble',
        findings={
            'selection_population_alignment_implemented': True,
            'original_hourly_H1_protocol_invalidated': False,
            'all_metrics': result['means'],
            'change_percent': review['original_to_aligned_change_percent'],
            'matched_full_improvement_percent': result['full_relative_improvement_percent'],
            'horizon_decomposition': review['comparisons'],
            'interpretation': 'The all-origin selection repair explains part of the dense MAE gap. Reselected development scores are optimistic for independent performance assessment; this is not a confirmed performance repair.',
            'short_horizon': 'FULL and CONCAT H1-4 mean MAE are almost equal after matched selection.',
            'remaining_gap': 'The signed FULL-minus-CONCAT MAE difference concentrates in H5-12; this is descriptive, not causal attribution.',
            'schedule_check': 'Every schedule contains2021 phase0 slots and182/183 per other phase. Broad phase frequencies barely vary across epochs; counts do not explain the epoch11 dip. Different sample identities/optimization could still matter.',
            'budget_endpoint': 'All FULL aligned selections are epoch12; nonmonotonic last-three-epoch scores do not establish undertraining or justify an automatic budget extension.'
        },
        actions=[
            'Retain the original frozen FULL and63-case study as the main evidence; do not retrofit checkpoint selection after viewing original tests.',
            'Archive both selector outcomes and all positive/negative metrics; CHANNEL remains not promoted.',
            'Close this zero-training diagnostic. No new architecture/loss/weighting/epoch search starts automatically.',
            'A future modification first needs an unused source-verifiable confirmation period. Existing H1 andEurope2016 cannot serve again as untouched confirmation.',
            'Keep the previously specified residual-gate proposal conditional. The current horizon diagnosis does not establish its effectiveness or a dynamic-graph remedy.'
        ],
        next_matched_control=proposal,
        unresolved={
            'new_period_admission': 'No joint post2016 period in local FR/DE/BE files; a new CAISO period is not yet established. This concerns new amendments, not the completed original independent tests.',
            'performance': 'Attention superiority over CONCAT on CAISO and stable dynamic-graph benefit remain unestablished.',
            'new_variant_guarantee': 'Zero-initialized residual correction preserves the initial function only; no gain or preservation after optimization can be guaranteed.'
        },
        literature=[
            dict(url='https://arxiv.org/abs/2008.08004', use='Forecast-task alignment, fair baselines and statistical evaluation.'),
            dict(url='https://jmlr.org/papers/v11/cawley10a.html', use='Finite validation can be overfit by model selection; require separate confirmation.'),
            dict(url='https://arxiv.org/abs/2003.04887', use='Zero-initialized residual gate principle only; no established EPF gain for the proposed adaptation.')
        ],
        audit_scope=audit['scope'], training_active=False, optimizer_updates=0,
        new_test_targets_read=False, original_tests_preserved=True,
        no_periodic_wakeups=True, complete_research_experiment=False)
    g.write(OUT/'DECISION.json', decision)
    handoff_path = g.ROOT/'HANDOFF.json'
    handoff = g.read(handoff_path)
    backup = OUT/'HANDOFF.before_event_closure.json'
    if not backup.exists():
        g.atomic(backup, lambda f: f.write(handoff_path.read_bytes()))
    current = handoff['current_authorized_work']
    current.update(at=g.now(), status='selection_alignment_diagnostic_complete_not_promoted_to_independent_claim',
                   manager_pid=None, numerical_child_pid=None, exit_bridge_pid=None, watcher_pid=23800,
                   training_active=False, numeric_diagnostic_active=False,
                   last_completed_manager_pid=23600, last_completed_child_pid=14112,
                   performance_fix_proven=False, new_independent_test_period_admitted=False,
                   result=str(g.HERE/'RESULT.json'), audit=str(g.HERE/'AUDIT.json'),
                   outcome_review=str(OUT/'REVIEW.json'), decision=str(OUT/'DECISION.json'),
                   decision_sha256=g.sha(OUT/'DECISION.json'),
                   next_actions=decision['actions'], pending_conditional_proposal=proposal,
                   blocker_for_new_confirmation=decision['unresolved']['new_period_admission'])
    current['confirmed_issue'] = 'All3397 development task used a June284 selector; fixed in this diagnostic. Original hourly H1 task is not invalidated.'
    handoff.update(updated_at=g.now(), status=current['status'], queue_pid=None,
                   event_listener_pid=23800, complete_research_experiment=False,
                   periodic_model_wakeups=False, latest_selection_alignment_review=str(OUT/'DECISION.json'))
    for key in ['event_driven_automation', 'event_automation']:
        state=handoff.get(key)
        if isinstance(state, dict):
            state.update(watcher_pid=23800, manager_pid=None, bridge_pid=None, exit_bridge_pid=None,
                         status='listener_active_no_numerical_worker', current_at=g.now())
    handled=handoff.setdefault('handled_event_ids', [])
    for eid in (EVENT_ID, INNER_ID):
        if eid not in handled: handled.append(eid)
    handoff['last_handled_event']=dict(event_id=INNER_ID, outer_event_id=EVENT_ID, at=g.now(),
                                      record=str(OUT/'DECISION.json'), notification='One concise final in current turn; no new inbox event')
    atomic_external(handoff_path, handoff)
    g.write(OUT/'EVENT_CLOSURE.json', dict(at=g.now(), event_id=EVENT_ID, inner_event_id=INNER_ID,
              decision=str(OUT/'DECISION.json'), decision_sha256=g.sha(OUT/'DECISION.json'),
              handoff_sha256=g.sha(handoff_path), duplicate_notification=False,
              notification_channel='current turn final only', training_started=False,
              event_listener_retained=True, complete_research_experiment=False))
    print(json.dumps(dict(status='closed', checks=audit['checks'], checkpoints=audit['checkpoints'],
                          decision=str(OUT/'DECISION.json'), training_active=False, watcher_pid=23800), ensure_ascii=True))


if __name__ == '__main__':
    main()
