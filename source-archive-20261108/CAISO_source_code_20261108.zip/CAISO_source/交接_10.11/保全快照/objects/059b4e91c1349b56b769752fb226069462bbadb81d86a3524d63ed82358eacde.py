import manager as m
p,q=m.verify()
assert q['source_only'] and q['max_model_fits']==0 and q['io_threads']==1
assert q['training_memory_launch_GiB']==5 and q['training_memory_runtime_GiB']==4
assert not m.s.base.LOCK.exists()
print(m.s.guard(True),flush=True)

