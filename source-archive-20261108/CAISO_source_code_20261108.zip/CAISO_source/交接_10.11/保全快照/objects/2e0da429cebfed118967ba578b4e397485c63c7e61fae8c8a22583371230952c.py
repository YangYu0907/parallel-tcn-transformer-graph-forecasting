"""New supplementary branch; closed TRAIN/June reader and unchanged shared guards."""
from pathlib import Path
from contextlib import contextmanager
from datetime import datetime, timezone
import os, sys, json, hashlib, uuid, shutil
HERE=Path(__file__).resolve().parent;ROOT=HERE.parent
sys.path.insert(1,str(ROOT/'source'))
import compile_gate as resource
LOCK=Path('D:/Desktop/数据科学_论文/研究优化_20260818/logs/NEURAL_RUN.lock')
def now():return datetime.now(timezone.utc).isoformat()
def read(p):return json.loads(Path(p).read_text(encoding='utf-8-sig'))
def sha(p):return resource.sha(p)
def need(v,msg):
    if not v:raise RuntimeError(msg)
def atomic(p,fn,replace=False):
    p=Path(p).resolve();need(p.is_relative_to(HERE),'Output escaped supplemental branch')
    p.parent.mkdir(parents=True,exist_ok=True);tmp=p.with_name('tmp_'+uuid.uuid4().hex)
    with tmp.open('xb') as f:fn(f);f.flush();os.fsync(f.fileno())
    if replace:os.replace(tmp,p)
    else:tmp.rename(p)
def write(p,v,replace=False):atomic(p,lambda f:f.write(json.dumps(v,ensure_ascii=False,indent=2,allow_nan=False).encode()),replace)
def boundary():
    pause=read(ROOT.parent/'RESEARCH_PAUSED.json')
    if pause.get('status')!='resumed_by_user' or pause.get('stop_preparation_and_training'):raise InterruptedError('User pause')
    for d in (ROOT,HERE,ROOT/'phase_sampling_support_v3_20260923'):
        for n in ('STOP_REQUESTED','STOP_REQUESTED.json'):
            if (d/n).exists():raise InterruptedError('User stop '+str(d/n))
def guard(start=False):
    boundary();r=resource.resources();need(min(r.values())>=(5 if start else 4),'Resource floor '+str(r))
    need(shutil.disk_usage(HERE).free/2**30>=(2 if start else 1),'Disk reserve');return r
@contextmanager
def exclusive(action):
    guard(True);import psutil
    owner=dict(pid=os.getpid(),created=psutil.Process().create_time(),token=uuid.uuid4().hex,action=action)
    with LOCK.open('x',encoding='utf-8') as f:json.dump(owner,f);f.flush();os.fsync(f.fileno())
    try:resource.bound_process();guard();yield
    finally:
        need(read(LOCK)==owner,'Shared owner changed');write(HERE/'lock_releases'/(owner['token']+'.json'),dict(owner=owner,at=now()));LOCK.unlink()
def runtime():
    resource.bound_process()
    import numpy as np
    from threadpoolctl import threadpool_limits,threadpool_info
    cap=threadpool_limits(1);need(all(x['num_threads']==1 for x in threadpool_info()),'Thread cap');guard();return np,cap
def sources():
    return {str(p.relative_to(ROOT)):sha(p) for p in sorted(list(HERE.glob('*.py'))+list(HERE.glob('*.ps1'))+[HERE/'PROTOCOL.json']+[ROOT/'source'/n for n in ('compile_gate.py','compiled_data.py','compile_math.py')])}
def verify(numeric=False):
    boundary();s=read(HERE/'PREPARATION_SEAL.json');need(s['sources']==sources(),'Preparation source changed')
    if numeric:
        qa=read(HERE/'numeric_qa.json');need(qa['status']=='passed' and qa['sources']==sources(),'Numeric QA missing/stale')
    return s
def data():
    from compiled_data import CompiledData
    p=read(HERE/'PROTOCOL.json');path=ROOT/p['dataset_manifest']
    need(sha(path)==p['dataset_manifest_sha256'],'Dataset manifest changed')
    return CompiledData(path)

def predecessor():
    folder=ROOT/'static_gtf_prefix_v1_20260926'
    need(not (folder/'queue/QUEUE.lock').exists(),'Predecessor queue still owns execution; wait for its genuine exit')
    cp=folder/'queue/completion.json';c=read(cp)
    need(c['status']=='six_STATIC_GTF_prefixes_and_saved_output_audits_completed','Predecessor incomplete')
    need(c['seal_sha256']==sha(folder/'EXECUTION_LOCK.json'),'Predecessor seal changed')
    need(len(c['receipts'])==12,'Predecessor receipt count')
    for name,digest in c['receipts'].items():
        q=folder/'queue/steps'/name;need(sha(q)==digest,'Predecessor step changed')
        r=read(q);need(r['exit_code']==0 and sha(ROOT/r['marker'])==r['marker_sha256'],'Predecessor marker changed')
    return c
if __name__=='__main__':
    need(sys.argv[1:]==['check'],'Use check');verify();predecessor();guard(True);need(not LOCK.exists(),'Numeric worker active')
    print(json.dumps(dict(status='ready',heldout_targets_read=False)))
