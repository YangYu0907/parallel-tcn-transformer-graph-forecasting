"""Target-free real parent replay and nonzero-adapter hour protection for all3seeds."""
import copy,json,gc
import gate
def main():
    with gate.exclusive('offhour_real_parent_QA'):
        np,torch,limiter=gate.runtime()
        from compiled_data import CompiledData
        from models.factory import build_backbone
        from adapter import AdaptedFULL,fingerprint
        data=CompiledData(gate.V/'dataset/ADDITIVE/manifest.json')
        limits=gate.read(data.paths['context_limits.json'])['limits']
        meta=gate.read(gate.COMMON/'EVALUATION_LOCK.json')['cases']+gate.read(gate.MP/'EVALUATION_LOCK.json')['cases']
        rows=gate.read(gate.COMMON/'result.json')['results']+gate.read(gate.MP/'result.json')['results']
        dense=data.origins['june_dense'];registered=data.origins['june']
        lookup={int(o):i for i,o in enumerate(dense)}
        probes=[lookup[int(o)] for o in registered[:12]]+[i for i,o in enumerate(dense) if int(o)%12!=0][:12]
        checks=[]
        for seed in (20260813,20260814,20260815):
            c=next(x for x in meta if x['variant']=='FULL' and x['policy']=='ADDITIVE' and x['seed']==seed)
            row=next(x for x in rows if x['id']==c['id']);rr=gate.read(gate.inside(row['dense_receipt']))
            gate.need(gate.sha(gate.inside(rr['artifact']))==rr['artifact_sha256'],'Parent dense hash')
            with np.load(gate.inside(rr['artifact']),allow_pickle=False) as z:expected=z['prediction']
            ck=gate.inside(c['selected_checkpoint']);receipt=gate.read(ck.with_suffix('.receipt.json'))
            gate.need(gate.sha(ck)==receipt['sha256'],'Parent checkpoint changed')
            saved=torch.load(ck,map_location='cpu',weights_only=False)
            base=build_backbone('FULL',seed,limits);base.load_state_dict(saved['state_dict'],strict=True);base.eval()
            models={arm:AdaptedFULL(copy.deepcopy(base),seed,arm).eval() for arm in ('GLOBAL','OFFHOUR')}
            gate.need(fingerprint(models['GLOBAL'])==fingerprint(models['OFFHOUR']),'Matched init')
            zero_diff=protected_diff=0.;changed=False
            for start in range(0,24,4):
                gate.guard();ids=np.array(probes[start:start+4]);x,y=data.batch('june_dense',ids,with_target=False)
                gate.need(y is None,'Target-free QA')
                xt=torch.from_numpy(x);mask=torch.from_numpy(dense[ids]%12==0)
                for arm,model in models.items():
                    with torch.inference_mode():out=model(xt,mask)
                    usd=out['prediction'].numpy().astype(np.float64)*data.scale[None,:,None]+data.center[None,:,None]
                    zero_diff=max(zero_diff,float(abs(usd-expected[ids]).max()))
                if start==0:
                    mutated=copy.deepcopy(models['OFFHOUR'])
                    with torch.no_grad():mutated.adapter.up.bias.fill_(.02)
                before=fingerprint(mutated.base)
                with torch.inference_mode():
                    out=mutated(xt,mask);original=mutated.base(xt)
                    delta=mutated.adapter(original['head_features'])
                    manual=mutated.base.head(delta)
                    manual=torch.where(~mask[:,None,None],manual,original['prediction'])
                gate.need(torch.equal(out['prediction'],manual),'Nonzero gated formula')
                gate.need(torch.equal(out['dynamic_adjacency'],original['dynamic_adjacency']) and torch.equal(out['branch_weights'],original['branch_weights']),'Required graph/fusion elements changed')
                gate.need(fingerprint(mutated.base)==before,'Frozen base changed')
                if bool(mask.any()):
                    protected_diff=max(protected_diff,float((out['prediction'][mask]-original['prediction'][mask]).abs().max()))
                if bool((~mask).any()):changed|=bool((out['prediction'][~mask]!=original['prediction'][~mask]).any())
            gate.need(zero_diff==0 and protected_diff==0 and changed,'Initial replay/hour protection/offhour access failed')
            checks.append(dict(seed=seed,origins=24,epoch_zero_USD_max_difference=zero_diff,nonzero_adapter_hourly_max_difference=protected_diff,offhour_changes_possible=changed))
            del models,mutated,base,saved;gc.collect()
        gate.write(gate.HERE/'real_model_qa.json',dict(status='passed',at=gate.now(),checks=checks,
            sources={gate.rel(p):gate.sha(p) for p in gate.HERE.glob('*.py')},
            actual_source_values_scope='Target-free TRAIN/June history only; frozen saved parent predictions for replay',
            optimizer_updates=0,parameters_manually_perturbed_for_gate_probe_only=True,heldout_targets_read=False))
        print(json.dumps(dict(status='passed',cases=3,probe_origins=72,all_hourly_protection_exact=True)))
if __name__=='__main__':main()
