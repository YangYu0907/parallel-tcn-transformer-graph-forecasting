"""Fixed, as-issued weather adapter. No fitted weights or future observations."""
import numpy as np

def at_times(values, cycle, cutoff):
    # Forecast fields at F03/F04/F05 bracket issuance through +60 minutes.
    age=(cutoff-cycle)/3600
    assert 3 <= age < 4, (cycle,cutoff,age)
    hours=age+np.array([0,.5,1.])
    assert hours.min()>=3 and hours.max()<=5
    left=np.floor(hours-3).astype(int); right=np.minimum(left+1,2)
    w=hours-3-left
    return values[...,left]*(1-w)+values[...,right]*w

def weather_features(record, cutoff, arm, protocol):
    assert record['source_available_by']<=cutoff
    v=at_times(np.asarray(record['center_values'],float),record['choice']['cycle'],cutoff)
    m=at_times(np.asarray(record['patch_means'],float),record['choice']['cycle'],cutoff)
    # Variable order TMP2,DPT2,U10,V10,U80,V80,DSWRF,TCDC.
    if arm=='COARSE':return v[[0,2,3],:3,:].ravel()
    if arm=='SPATIAL':return v[[0,2,3],:,:].ravel()
    assert arm=='MECHANISM'
    load=protocol['load_anchor_indices'];wind=protocol['wind_anchor_indices'];solar=protocol['solar_anchor_indices']
    ws80=np.sqrt(v[4]**2+v[5]**2); ws10=np.sqrt(v[2]**2+v[3]**2)
    # Direction is not treated as earth-relative: native GRIB vectors are retained.
    # Wind-speed magnitude is invariant to a horizontal grid-axis rotation.
    blocks=[v[[0,2,3],:,:].ravel(), (v[0,load]-v[1,load]).ravel(),
            ws80[wind].ravel(),(ws80[wind]-ws10[wind]).ravel(),
            v[6,solar].ravel(),v[7,solar].ravel(),
            np.diff(v[0,load],axis=-1).ravel(),np.diff(ws80[wind],axis=-1).ravel(),
            np.diff(v[6,solar],axis=-1).ravel(),
            m[6,solar].ravel()-v[6,solar].ravel(),m[0,load].ravel()-v[0,load].ravel()]
    result=np.concatenate(blocks);assert np.isfinite(result).all();return result

def calendar(cutoffs):
    c=np.asarray(cutoffs);hour=(c%86400)/86400;year=(c%(365.2425*86400))/(365.2425*86400)
    return np.stack([np.sin(2*np.pi*hour),np.cos(2*np.pi*hour),np.sin(2*np.pi*year),np.cos(2*np.pi*year)],axis=-1)

def first_event(price_future,center,threshold):
    d=price_future-center;hit=np.abs(d)>threshold
    j=hit.argmax(-1)
    value=np.take_along_axis(d,j[...,None],axis=-1)[...,0]
    return np.where(hit.any(-1),np.where(value>0,1,2),0)
