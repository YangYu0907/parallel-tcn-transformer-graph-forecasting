from pathlib import Path
import json,sys,hashlib,gc
HERE=Path(__file__).resolve().parent;ROOT=HERE.parent
sys.path.insert(0,str(ROOT/'budget_mechanisms_v1_20260925'))
import gate
def digest(p):return gate.sha(p)
def stats(np,a):
 a=np.asarray(a,dtype=np.float64)
 return dict(mean=float(a.mean()),p10=float(np.quantile(a,.1)),median=float(np.median(a)),p90=float(np.quantile(a,.9)))
def main():
 seal=gate.verify();lock=gate.read(HERE/'PROBE_LOCK.json')
 for p,h in lock['bindings'].items():gate.need(digest(ROOT/p)==h,'Probe source/binding changed')
 gate.need(not (HERE/'result.json').exists(),'Probe already completed')
 with gate.exclusive('train_branch_fusion_diagnostic'):
  np,torch,lim=gate.runtime()
  from compiled_data import CompiledData
  from models.factory import build_backbone
  data=CompiledData(seal['dataset_manifest'])
  origins=np.load(gate.inside(seal['train_diagnostic']),allow_pickle=False)
  gate.need(origins.shape==(288,) and (origins+12<=210528).all() and len(np.unique(origins))==288,'TRAIN probe bounds')
  data.origins['probe']=origins
  limits=gate.read(data.paths['context_limits.json'])['limits'];rows=[]
  for seed in (20260813,20260814,20260815):
   for variant in ('FULL','EQUAL','CONCAT'):
    parent=ROOT/('budget_extension_v1_20260925' if variant=='FULL' else 'budget_mechanisms_v1_20260925')/'runs'/f'{seed}_{variant}'
    r=gate.read(parent/'completion.json');a=gate.read(parent/'audit.json')
    gate.need(a['status']=='passed' and a['completion_sha256']==digest(parent/'completion.json'),'Audit missing')
    p=gate.inside(r['selected_checkpoint']);rr=gate.read(p.with_suffix('.receipt.json'));gate.need(digest(p)==rr['sha256'],'Selected weights changed')
    saved=torch.load(p,map_location='cpu',weights_only=False)
    model=build_backbone(variant,seed,limits);model.load_state_dict(saved['state_dict'],strict=True);model.eval();del saved
    before={k:v.detach().clone() for k,v in model.state_dict().items()};rng=torch.get_rng_state().clone()
    captured={};handle=model.tcn.register_forward_hook(lambda m,i,o:captured.update(tcn=o.detach()))
    norms=[];ratios=[];cosines=[];weights=[]
    with torch.no_grad():
     for start in range(0,288,4):
      gate.guard();x,y=data.batch('probe',np.arange(start,start+4),with_target=False);gate.need(y is None,'No probe targets')
      out=model(torch.from_numpy(x));u=captured['tcn'];v=out['transformer_features']
      un=u.double().norm(dim=-1);vn=v.double().norm(dim=-1)
      cos=(u.double()*v.double()).sum(-1)/(un*vn).clamp_min(1e-12)
      norms.append(torch.stack((un,vn),-1).numpy());ratios.append((un/vn.clamp_min(1e-12)).numpy());cosines.append(cos.numpy())
      weights.append(out['branch_weights'].numpy())
    handle.remove();gate.need(all(torch.equal(model.state_dict()[k],v) for k,v in before.items()) and torch.equal(rng,torch.get_rng_state()),'Probe mutated model/RNG')
    ns=np.concatenate(norms);ra=np.concatenate(ratios);co=np.concatenate(cosines);w=np.concatenate(weights).astype(np.float64)
    gate.need(np.isfinite(ns).all() and np.isfinite(w).all() and np.max(abs(w.sum(-1)-1))<1e-6,'Invalid features/weights')
    entropy=-(w*np.log(np.clip(w,1e-300,1))).sum(-1)/np.log(2)
    sat=((w[...,0]<.01)|(w[...,0]>.99))
    raw=HERE/'arrays'/f'{seed}_{variant}.npz'
    gate.atomic(raw,lambda f:np.savez(f,origins=origins,branch_norms=ns,norm_ratio=ra,cosine=co,weights=w))
    phases=[]
    for phase in range(12):
     ix=np.flatnonzero(origins%12==phase)
     phases.append(dict(phase=phase,origins=len(ix),tcn_norm=stats(np,ns[ix,:,0]),transformer_norm=stats(np,ns[ix,:,1]),
      norm_ratio=stats(np,ra[ix]),cosine=stats(np,co[ix]),mean_tcn_weight=float(w[ix,...,0].mean()),
      entropy=float(entropy[ix].mean()),saturation_fraction=float(sat[ix].mean())))
    rows.append(dict(case=f'{seed}_{variant}',checkpoint=gate.rel(p),checkpoint_sha256=digest(p),raw=gate.rel(raw),raw_sha256=digest(raw),
     tcn_norm=stats(np,ns[:,:,0]),transformer_norm=stats(np,ns[:,:,1]),norm_ratio=stats(np,ra),cosine=stats(np,co),
     mean_tcn_weight=float(w[...,0].mean()),normalized_entropy=float(entropy.mean()),saturation_fraction=float(sat.mean()),
     mean_tcn_weight_by_horizon=w[...,0].mean(axis=(0,1)).tolist(),by_phase=phases,
     weight_semantics='adaptive' if variant=='FULL' else 'diagnostic constant, not learned attention'))
    del model,before;gc.collect();print(json.dumps(dict(case=f'{seed}_{variant}',status='observed')),flush=True)
  gate.write(HERE/'result.json',dict(status='completed_pending_numeric_audit',at=gate.now(),protocol_sha256=digest(HERE/'PROTOCOL.json'),
   probe_lock_sha256=digest(HERE/'PROBE_LOCK.json'),rows=rows,train_origins=288,targets_read=False,heldout_targets_read=False,training_updates=0))
if __name__=='__main__':main()
