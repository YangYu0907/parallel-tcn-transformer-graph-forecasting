"""One fixed-epoch, chronological DEVELOPMENT gate pilot; no backbone updates."""
from pathlib import Path
import os, sys, json, uuid, time
HERE=Path(__file__).resolve().parent
sys.path.insert(0,str(HERE.parent))
from common import B,ROOT,read,sha,guard,numeric,verify_protected,now

def write(p,d):
    p=Path(p); p.parent.mkdir(parents=True,exist_ok=True)
    q=p.parent/('.w'+uuid.uuid4().hex[:10]+'.tmp')
    q.write_text(json.dumps(d,ensure_ascii=False,indent=2,allow_nan=False),encoding='utf-8');os.replace(q,p)

def save(p,**d):
    import numpy as np
    p=Path(p);p.parent.mkdir(parents=True,exist_ok=True)
    q=p.parent/('.n'+uuid.uuid4().hex[:10]+'.tmp')
    with q.open('wb') as f:np.savez_compressed(f,**d)
    os.replace(q,p)

def policy_check():
    p=read(HERE/'PROTOCOL.json')
    for file,digest in p['bindings'].items():assert sha(file)==digest,file
    assert sha(ROOT/'FAIR_INPUT_SEAL.json')==p['parent_seal_sha256']
    for file,digest in read(ROOT/'FAIR_INPUT_SEAL.json')['sources'].items():assert sha(file)==digest,file
    verify_protected();return p

def fit_risk(x,ya,ym):
    import numpy as np
    center=np.median(x,axis=0);scale=np.quantile(x,.75,axis=0)-np.quantile(x,.25,axis=0)
    scale=np.maximum(scale,1e-6)
    z=np.clip((x-center)/scale,-6,6);z=np.column_stack([np.ones(len(z)),z])
    penalty=np.eye(z.shape[1]);penalty[0,0]=0
    coef=np.linalg.solve(z.T@z/len(z)+penalty,z.T@np.column_stack([ya,ym])/len(z))
    return dict(center=center.tolist(),scale=scale.tolist(),coef=coef.tolist(),
                lower=x.min(0).tolist(),upper=x.max(0).tolist(),ridge_lambda=1.)

def estimate(model,x):
    import numpy as np
    z=np.clip((x-np.array(model['center']))/np.array(model['scale']),-6,6)
    return np.column_stack([np.ones(len(z)),z])@np.array(model['coef'])

def calibrate(model,x,ya,ym,days):
    import numpy as np
    discrepancy=estimate(model,x)-np.column_stack([ya,ym])
    means=np.stack([discrepancy[days==d].mean(0) for d in np.unique(days)])
    assert len(means)>=3
    # Fixed conservative bias allowance, NOT a coverage or safety guarantee.
    return np.maximum(0,means.mean(0)+2*means.std(0,ddof=1)/np.sqrt(len(means))).tolist()

def route(model,margin,x):
    import numpy as np
    risk=estimate(model,x);margin=np.array(margin)
    supported=((x>=np.array(model['lower']))&(x<=np.array(model['upper']))).all(1)
    g=np.clip(np.min((risk-margin)/(np.abs(risk)+margin+1e-8),axis=1),0,1)
    g[~supported]=0
    return .25*g,supported

def metrics(p,y):
    import numpy as np
    e=p-y
    return dict(mae=float(abs(e).mean()),rmse=float(np.sqrt((e*e).mean())),
                near_mae=float(abs(e[:,:,:4]).mean()),h12_mae=float(abs(e[:,:,-1]).mean()))

def run():
    p=policy_check()
    with numeric('one fixed-epoch conditional gate pilot; development only'):
        import numpy as np, torch
        from fair_inputs import PriceModel,runtime,MANIFEST
        from compiled_data import CompiledData
        runtime();start=time.monotonic()
        previous=read(HERE/'BUDGET.json')['seconds'] if (HERE/'BUDGET.json').exists() else 0
        def tick(stage,**kw):
            guard()
            for n in ['STOP_REQUESTED','STOP_REQUESTED.json']:
                if (HERE/n).exists():raise InterruptedError('Local stop')
            used=previous+time.monotonic()-start
            write(HERE/'BUDGET.json',dict(seconds=used,limit=p['budget_seconds']))
            write(HERE/'PROGRESS.json',dict(at=now(),pid=os.getpid(),stage=stage,seconds=used,**kw))
            if used>p['budget_seconds']:raise TimeoutError('Fixed diagnostic budget reached')
        d=CompiledData(MANIFEST);orig=d.origins['june_dense'];dates=d.times[orig-1]//86400
        days=np.unique(dates);assert len(orig)==3397 and len(days)==19
        assert d.times[d.manifest['train_target_stop_exclusive']-1]<d.times[orig.min()-1]
        role=np.where(dates<=days[9],0,np.where(dates<=days[13],1,2))
        # Last target timestamp must strictly precede next partition's first issue time.
        for k in [0,1]:
            end=d.times[orig+11];nextcut=d.times[orig[role==k+1].min()-1]
            role[(role==k)&(end>=nextcut)]=-1
        assert all(len(np.unique(dates[role==k]))>=n for k,n in [(0,8),(1,3),(2,5)])
        for k in [0,1]:assert d.times[orig[role==k]+11].max()<d.times[orig[role==k+1]-1].min()
        split=[dict(role=['fit','calibration','forward_development'][k],origins=int((role==k).sum()),
                    dates=int(len(np.unique(dates[role==k]))),first=str(np.datetime64(int(dates[role==k].min()),'D')),
                    last=str(np.datetime64(int(dates[role==k].max()),'D'))) for k in range(3)]
        write(HERE/'SPLIT.json',dict(partitions=split,purged=int((role<0).sum()),
            backbone_selection='fixed maximum-budget epoch12; no June-selected best.pt',
            already_inspected_period=True,independent_confirmation=False))
        models=[];limits=read(d.paths['context_limits.json'])['limits']
        for name in ['FULL_price_only','iTransformer_price_only']:
            c=torch.load(Path(p['checkpoints'][name]),map_location='cpu',weights_only=False)
            assert c['identity']['model']==name and c['identity']['seed']==20260813
            assert c['state']['steps']==12096 and c['state']['epoch']==13
            m=PriceModel(name,20260813,limits);m.load_state_dict(c['model'],strict=True);m.eval();models.append(m);del c
        tick('inference_prepared',total_origins=len(orig))
        records=[]
        for first in range(0,len(orig),128):
            path=HERE/'cache'/f'b{first:04d}.npz';stop=min(first+128,len(orig))
            if path.exists():
                with np.load(path) as z:block={k:z[k] for k in z.files}
                assert np.array_equal(block['origins'],orig[first:stop])
            else:
                ff=[];ii=[];yy=[];hh=[];last=[]
                for j in range(first,stop,4):
                    ix=np.arange(j,min(j+4,stop));x,y=d.batch('june_dense',ix)
                    if (j-first)%32==0:tick('inference',completed=j,total_origins=len(orig))
                    px=x[:,:,:,0].astype(float);rawlast=px[:,-1]*d.scale+d.center
                    hist=np.stack([px[:,-1]-px[:,-2],px[:,-1]-px[:,-12],px[:,-36:].std(1),
                                   px[:,-1]-px.mean(1),(rawlast-np.median(rawlast,axis=1)[:,None])/d.scale],axis=-1)
                    with torch.no_grad():
                        xx=torch.from_numpy(x)
                        for dest,m in zip([ff,ii],models):dest.append(m(xx).numpy().astype(float)*d.scale[None,:,None]+d.center[None,:,None])
                    yy.append(y.astype(float)*d.scale[None,:,None]+d.center[None,:,None]);hh.append(hist);last.append(rawlast)
                block=dict(origins=orig[first:stop],full=np.concatenate(ff),other=np.concatenate(ii),truth=np.concatenate(yy),history=np.concatenate(hh),last=np.concatenate(last))
                save(path,**block)
            records.append(block)
        del models
        full,other,y,hist,last=[np.concatenate([r[k] for r in records]) for k in ['full','other','truth','history','last']]
        del records
        # Exact replay against already saved fixed-epoch reference on June284.
        for name,arr in [('FULL_price_only',full),('iTransformer_price_only',other)]:
            with np.load(ROOT/'fair_runs'/f'20260813_{name}'/'epoch12_june.npz') as z:
                pos=np.searchsorted(orig,z['origins']);assert np.array_equal(orig[pos],z['origins'])
                assert np.allclose(arr[pos],z['prediction'],atol=1e-5,rtol=1e-6)
                assert np.array_equal(y[pos],z['truth'])
        th=read(d.paths['state_thresholds.json']);cent=np.asarray(th['center']);thr=np.asarray(th['thresholds'])
        states=(abs(y-cent[None,:,None])>thr[0][None,:,None]).astype(np.int8)
        states+=(abs(y-cent[None,:,None])>thr[1][None,:,None]).astype(np.int8)
        states+=3*(abs(last-cent)>thr[1])[:,:,None]
        fs=full[:,:,7:];is_=other[:,:,7:];diff=(is_-fs)/d.scale[None,:,None]
        X=np.concatenate([np.broadcast_to(hist[:,:,None,:],(*diff.shape,5)),
            np.stack([diff,abs(diff),(fs-last[:,:,None])/d.scale[None,:,None],
                      (is_-last[:,:,None])/d.scale[None,:,None],
                      np.broadcast_to(np.arange(8,13)/12,diff.shape)],axis=-1)],axis=-1).reshape(-1,10)
        rowrole=np.repeat(role,30*5);rowdays=np.repeat(dates,30*5)
        fixed=fs+.25*(is_-fs);s=float(d.scale.mean())
        ya=((abs(fs-y[:,:,7:])-abs(fixed-y[:,:,7:]))/s).ravel()
        ym=(((fs-y[:,:,7:])**2-(fixed-y[:,:,7:])**2)/(s*s)).ravel()
        tick('fit_one_two_output_ridge')
        fit=rowrole==0;cal=rowrole==1;ev=role==2
        model=fit_risk(X[fit],ya[fit],ym[fit]);margin=calibrate(model,X[cal],ya[cal],ym[cal],rowdays[cal])
        frozen=dict(at=now(),model=model,margin=margin,fit_dates=np.unique(rowdays[fit]).tolist(),cal_dates=np.unique(rowdays[cal]).tolist(),
                    training_targets='Only role0; role1 bias calibration; no role2 target access in fitting functions',scale=s)
        write(HERE/'GATE_FROZEN.json',frozen)
        # Scoring begins only after fitted coefficients and calibration are committed.
        alpha,supported=route(model,margin,X);alpha=alpha.reshape(len(orig),30,5)
        candidate=full.copy();candidate[:,:,7:]+=alpha*(other[:,:,7:]-full[:,:,7:])
        fixed25=full.copy();fixed25[:,:,7:]+=.25*(other[:,:,7:]-full[:,:,7:])
        fixed50=full.copy();fixed50[:,:,7:]+=.5*(other[:,:,7:]-full[:,:,7:])
        assert np.array_equal(candidate[:,:,:7],full[:,:,:7])
        out=dict(origins=orig,dates=dates,role=role,truth=y,states=states,full=full,other=other,
                 candidate=candidate,fixed25=fixed25,fixed50=fixed50,alpha=alpha,X=X,
                 scaled_gain_mae=ya,scaled_gain_mse=ym)
        save(HERE/'REPLAY.npz',**out)
        rows=[dict(model=k,**metrics(v[ev],y[ev])) for k,v in [('FULL_E12',full),('iTransformer_E12',other),('FIXED25_H8',fixed25),('FIXED50_H8',fixed50),('CONDITIONAL_H8',candidate)]]
        stat=[]
        for state in range(6):
            mask=states[ev]==state;count=int(mask.sum());daycount=int(len(np.unique(dates[ev][mask.any((1,2))])))
            r=dict(state=state,cells=count,dates=daycount)
            for k,v in [('parent',full),('candidate',candidate)]:
                e=(v[ev]-y[ev])[mask]
                r[k]=dict(mae=float(abs(e).mean()),rmse=float(np.sqrt((e*e).mean()))) if count else None
            stat.append(r)
        parent=rows[0];cand=rows[-1];fixedrow=rows[2]
        checks=dict(headline_nonworse=all(cand[k]<=parent[k]+1e-10 for k in ['mae','rmse','near_mae','h12_mae']),
                    beats_fixed25=cand['mae']<fixedrow['mae'],h12_beats_iTransformer=cand['h12_mae']<rows[1]['h12_mae'],
                    every_horizon_nonworse=bool(np.all(abs(candidate[ev]-y[ev]).mean((0,1))<=abs(full[ev]-y[ev]).mean((0,1))+1e-10)),
                    state_support=all(r['dates']>=5 for r in stat),
                    state_nonworse=all(r['parent'] is not None and all(r['candidate'][k]<=r['parent'][k]+1e-10 for k in ['mae','rmse']) for r in stat),
                    near_exact=bool(np.array_equal(candidate[:,:,:7],full[:,:,:7])))
        diagnostics=dict(active_fraction=float((alpha[ev]>0).mean()),mean_expert_weight=float(alpha[ev].mean()),
                         supported_fraction=float(supported.reshape(len(orig),30,5)[ev].mean()),
                         active_cells=int((alpha[ev]>0).sum()))
        write(HERE/'RESULT.json',dict(at=now(),status='one_seed_forward_development_completed',scope='Already inspected June; fixed epoch12 parents, not selected best and not V7',
             seed=20260813,partitions=split,rows=rows,states=stat,checks=checks,screen_passed=all(checks.values()),
             diagnostics=diagnostics,gate_sha256=sha(HERE/'GATE_FROZEN.json'),replay_sha256=sha(HERE/'REPLAY.npz'),
             new_test_targets_read=False,backbone_updates=0,V7_replaced=False,automatic_expansion=False))
        tick('numeric_complete');policy_check()
        print(json.dumps(dict(rows=rows,checks=checks,diagnostics=diagnostics)))

if __name__=='__main__':run()
