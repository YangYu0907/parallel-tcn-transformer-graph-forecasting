$ErrorActionPreference='Stop'
$experiment=$PSScriptRoot
$branch=Split-Path -Parent $experiment
$python='D:\Documents\conda_envs\tcn_air\python.exe'
$managerPath=Join-Path $experiment 'manager.py'
$bridgePath=Join-Path $experiment 'watch_manager_exit.ps1'
$watchPath=Join-Path $branch 'event_driven_automation\watch.ps1'
if(Test-Path -LiteralPath (Join-Path $experiment 'queue\QUEUE.lock')) { throw 'Existing queue ownership requires review' }
if(Test-Path -LiteralPath (Join-Path $experiment 'queue\completion.json')) { throw 'Finite queue already complete' }
$processes=@(Get-CimInstance Win32_Process)
if(@($processes | Where-Object { $_.Name -eq 'python.exe' -and $_.CommandLine -and $_.CommandLine.Contains($managerPath) }).Count) { throw 'Manager already running' }
& $python -c "import sys;sys.path.insert(0,r'$experiment');import gate;gate.verify();gate.need(not gate.LOCK.exists(),'Numerical lock exists');print(gate.guard(True))"
if($LASTEXITCODE -ne 0) { throw 'Source/resource gate failed' }
$watchers=@($processes | Where-Object { $_.CommandLine -and $_.CommandLine.Contains($watchPath) -and $_.Name -eq 'powershell.exe' })
if($watchers.Count -gt 1) { throw 'Duplicate event watchers' }
$logs=Join-Path $experiment ('launch_'+[guid]::NewGuid().ToString('N').Substring(0,10))
New-Item -ItemType Directory -Path $logs | Out-Null
if($watchers.Count -eq 0) {
 $watch=Start-Process -FilePath 'C:\Windows\System32\WindowsPowerShell\v1.0\powershell.exe' -ArgumentList @('-NoProfile','-ExecutionPolicy','Bypass','-File',('"'+$watchPath+'"')) -WorkingDirectory $branch -WindowStyle Hidden -RedirectStandardOutput (Join-Path $logs 'watch.stdout.log') -RedirectStandardError (Join-Path $logs 'watch.stderr.log') -PassThru
 # Bounded startup check; no recurring wakeups or retry loop.
 Start-Sleep -Seconds 2
 if($watch.HasExited) { throw 'Event listener failed; inspect watch logs' }
} else { $watch=Get-Process -Id $watchers[0].ProcessId }
$state=Get-Content -LiteralPath (Join-Path $branch 'event_driven_automation\status.json') -Raw -Encoding UTF8 | ConvertFrom-Json
if([int]$state.pid -ne $watch.Id) { throw 'Event listener startup not acknowledged' }
$manager=Start-Process -FilePath $python -ArgumentList @(('"'+$managerPath+'"')) -WorkingDirectory $experiment -WindowStyle Hidden -RedirectStandardOutput (Join-Path $logs 'manager.stdout.log') -RedirectStandardError (Join-Path $logs 'manager.stderr.log') -PassThru
$ticks=$manager.StartTime.ToUniversalTime().Ticks
$bridgeArgs=@('-NoProfile','-ExecutionPolicy','Bypass','-File',('"'+$bridgePath+'"'),'-ManagerProcessId',[string]$manager.Id,'-ManagerStartUtcTicks',[string]$ticks,'-ManagerScript',('"'+$managerPath+'"'),'-StatusPath',('"'+(Join-Path $experiment 'queue\status.json')+'"'))
$bridge=Start-Process -FilePath 'C:\Windows\System32\WindowsPowerShell\v1.0\powershell.exe' -ArgumentList $bridgeArgs -WorkingDirectory $branch -WindowStyle Hidden -RedirectStandardOutput (Join-Path $logs 'bridge.stdout.log') -RedirectStandardError (Join-Path $logs 'bridge.stderr.log') -PassThru
$record=[ordered]@{at=[DateTime]::UtcNow.ToString('o');manager_pid=$manager.Id;manager_start_utc_ticks=$ticks;bridge_pid=$bridge.Id;watcher_pid=$watch.Id;periodic_model_calls=$false;logs=$logs}
$record | ConvertTo-Json | Set-Content -LiteralPath (Join-Path $logs 'launch.json') -Encoding UTF8
$record | ConvertTo-Json
