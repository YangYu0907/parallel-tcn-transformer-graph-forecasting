import hashlib
import json
import os
import statistics
from pathlib import Path
from datetime import datetime, timezone, timedelta

A = Path(r'C:\Users\于阳\CAISO_V7_成功实验归档_20261002')
B = A / '研究资料/CAISO_feature_fusion_rev12/asof_retraining_branch_20260913'
R = B / 'reviewer_revision_v2_20261003'
FIRST = A / '老师意见修订_20261003'
OUT = Path(__file__).resolve().parent

def read(p):
    return json.loads(p.read_text(encoding='utf-8-sig'))

def sha(p):
    h = hashlib.sha256()
    with p.open('rb') as f:
        for chunk in iter(lambda: f.read(1048576), b''):
            h.update(chunk)
    return h.hexdigest()

def save(name, value):
    p = OUT / name
    assert p.parent == OUT
    tmp = p.with_suffix('.tmp')
    tmp.write_text(json.dumps(value, ensure_ascii=False, indent=2), encoding='utf-8')
    os.replace(tmp, p)

# Each row identifies a distinct trial or closely related family, not a fit count.
# Evidence is restricted to already inspected reports/decisions; no target arrays are opened.
spec = [
('01','采样相位与局部适配','audits/offhour_review_horizon_launch_20260925.json','已完成，局部收益但远期回退','整点/非整点保护、相位适配、OFFHOUR可保留指定输出，但H12仍回退；不同相位面板不能混选优值。','相同相位掩码、同父模型下再换门控宽度不足以构成新假设。'),
('02','分预测期适配','audits/horizon_review_budget_extension_launch_20260925.json','已完成，未全面通过','解绑预测期适配器并增加容量，三个种子只有一个通过全部八项保护；原模型已经有预测期编码。','不能再把增加horizon ID作为全新修复。'),
('03','训练预算与基线匹配','audits/budget_mechanisms_review_branch_values_launch_20260925.json','匹配比较已完成，方向有差异','延长预算并补齐对照后，FULL对CONCAT在整点与稠密面板上方向不同；训练更久不等于机制更强。','原权重额外训练必须配套同预算控制。'),
('04','相位损失加权','audits/phase_weighting_result_decision_20260926.json','已完成，未采用','固定相位加权未通过原筛选，保留未加权FULL。','不重新搜索同一面板上的相位权重。'),
('05','通道注意力','channel_attention_v1_20260927/review_20260928/DECISION.json','已完成，未采用','三种子June3397上主指标未超过FULL，局部H12方向不能替代总体比较。','不能用通道注意力名义重复同输入后期加权。'),
('06','选择面板对齐','selection_alignment_v1_20260928/outcome_review/DECISION.json','部分改善，未解决CONCAT差距','按共同稠密面板选点后FULL MAE改善，CONCAT差距仍存在；选择口径确有影响但非充分原因。','不能继续换评价面板来追逐优势。'),
('07','残差注意力','residual_attention_v1_20260928/outcome_review/DECISION.json','已完成，增量很小','相对匹配继续训练FULL，稠密MAE仅降低约0.01564%；相对原父模型的大部分收益也出现在继续训练对照。','禁止把额外优化收益全部归给新增门控。'),
('08','图先验与动态图混合','graph_prior_v1_20260929/outcome_review/DECISION.json','已完成，未采用','固定图先验并未转化为匹配预测收益；固定权重移除先验的结果也不能隔离联合训练的全部影响。','不重复同一标量图混合或固定rho搜索。'),
('09','联合内容融合AFF','aff_joint_v1_20260929/outcome_review/DECISION.json','已完成，部分改善','三种子优于FULL_CONT，但与CONCAT_CONT仍有约1.933%主指标差距；第二轮并未更好。','没有证据支持自动加轮次或单纯增融合容量。'),
('10','统一货币尺度Huber','common_unit_huber_v1_20260929/ADMISSION_DECISION.json','准入未通过，未训练','新CAISO独立期未准入，按协议停止；不能把这个方案记成效果失败，也不能说已有有效性证据。','只有准入条件改变，才可重新评估执行资格。'),
('11','自适应多专家V2','adaptive_experts_v2_20260929/CLOSURE.json','已完成，总体改善与状态回退并存','新增专家与路由改善总体MAE，但S3/S4回退；新增GB专家本身没有带来所有主指标收益。','专家数量增加不等于情境识别改善。'),
('12','双损失保护V3','adaptive_experts_v3_20260929/ATTRIBUTION.json','已完成，保护伴随收益缩小','保护规则可把S3/S4/S5退回FULL；这是未修改而不是这些状态学得更准；动态更新未胜固定校准。','已有基于已发布反馈的动态更新，不可将在线权重当作从未试过。'),
('13','TAR补专家V4','adaptive_experts_v4_20260929/INTERPRETATION.json','已完成，未通过状态保护','加入TAR未带来净总体收益，S3所有722个被改动的相关预测单元方向错误。','先验证专家的条件增量技能，不能只扩大事后可选范围。'),
('14','转移状态与功能量V5','adaptive_experts_v5_20260929/INTERPRETATION.json','已完成，概率与价格指标冲突','分类准确率提高但Brier/logloss更差；高置信度仍可严重出错；S3/S4少数错误修正放大平方损失。','更高准确率或softmax置信度不是修改价格的充分条件。'),
('15','支持与不回退保护V6','adaptive_experts_v6_20260930/INTERPRETATION.json','保护生效，但牺牲尖峰收益','S3/S4/S5回退FULL避免新损害，同时原S5改善变为零；局部正标量收缩不能满足所有经验约束。','零动作必须单独标记，不得记作成功修复。'),
('16','V7情境尖峰专家','spike_specialist_v7_20260930/INTERPRETATION.json','保留版本；未达严格全优','698起点旧开发面板上总体有收益；少数S3错误方向的大幅上调主导新增平方损失。最初严格筛选未过，后按用户决定保留并确认。','保留V7真实版本；不能只依据最初not_promoted字段遗漏后续保留决定。'),
('17','回落保护、事件均衡、自然概率V8-V10','risk_likelihood_v10_20260930/INTERPRETATION.json','已完成，持续尖峰与回落交换收益','V8校准、V9事件均衡、V10概率目标纠正均尝试过；V10总体RMSE变好而S3 RMSE显著变差。','不能把自然频率校准、事件均衡或hazard模型再次包装成新路线。'),
('18','选择专家V11与尖峰转移V12','selective_expert_v11_20260930/INTERPRETATION.json','已完成，校准稀疏和严重错例未解决','时间隔离的损失收益门控与转移模型未稳定识别危险回落；某些保护完全拒绝回退FULL。','不简单放宽不确定性阈值或新增一个同类专家。'),
('19','更早前缀专家库V14','chronological_expert_pilot_v14_20260930/INTERPRETATION.json','已建成；局部收益但S4/H12回退','已有22935起点/116日、单种子的更早模型预测库；前向评价15092起点/75日。不能再笼统说没有历史专家库。','只补确实缺失的版本、节点、事件或发行时间，不重建已有整库。'),
('20','校准与起始信息V15','calibration_recurrence_v15_20260930/DECISION.json','已完成，不能转化为全面价格收益','起始排序改善仅覆盖很小的S2平方误差；校准仍在S3/S4等处失败。','概率识别提升必须经过实际价格与误报警成本验证。'),
('21','新能源来源V16与条件风险V17','conditional_risk_v17_20260930/pilot/CLOSURE.json','来源部分推进；候选未采用','新能源条件风险未稳定守住S3，不能把来源可用等同于预测有效。','新来源必须同时证明时间可得与增量作用。'),
('22','完整融合控制V18','mechanism_repair_v18_20260930/INTERPRETATION.json','CAISO有匹配开发收益；欧洲路由未过','V7对同样接受修正的CONCAT/EQUAL具有开发期优势；欧洲情境门控未超过等权组合。','系统收益、融合机制与图机制结论分别记录。'),
('23','九月匹配部署V19与保护归因V20','matched_fusion_deployment_v19_20260930/INTERPRETATION.json','比较完成，差异证据有限','186起点/12日上V7总体稍好但匹配差异不显著；H12差距已存在于基础骨干。','后补对照属于已看结果上的扩展，不再称新的盲测。'),
('24','欧洲稀疏图V21-G','multi_round_mechanism_v21_20261001/graph_pilot/DECISION.json','已完成，未采用','2015欧洲验证中稀疏候选未优于匹配控制，三种子主指标无胜；原top-k已保留两个其他市场。','不能重复宣称首次加入稀疏图；也不能据此否定所有图模型。'),
('25','融合交互V21-F','multi_round_mechanism_v21_20261001/fusion_pilot/OUTCOME_REVIEW.json','已完成，部分改善与回退','总体MAE改善0.2932%，但H12/S3/S4回退且仍弱于匹配CONCAT；属冻结骨干的有限适配。','不外推为从头训练全新架构的结论。'),
('26','梯度冲突PCGrad','multi_round_mechanism_v21_20261001/conflict_pilot/OUTCOME_REVIEW.json','已完成，没有可采用的更新','SUM/PCGrad共18组都选回第0轮；局部梯度冲突存在，但移除冲突不足以修复。','不再次凭负梯度余弦重启同一PCGrad试验。'),
('27','信息可识别性V22','context_identifiability_v22_20261001/OUTCOME_REVIEW.json','富上下文前向表现更差','153特征训练优于46特征但前向Brier更差；改日期权重或删除一个日期并未反转。','更多输入或复杂路由并非默认方向；需先找跨期增量信息。'),
('28','概率契约V23、容量V24、先验V25','prior_anchor_v25_20261001/DECISION.json','修正了一部分问题，仍有状态冲突','自然目标、减特征/容量、历史先验收缩均做过；S3与S5之间的概率损失仍有取舍。','固定凸组合的解析边界只约束该专家集合，不能重扫同一标量。'),
('29','时间token与预测期读出V26-V27','horizon_value_v27_20261001/OUTCOME_REVIEW.json','单种子筛选未过','保留更多时间token及预测期特定读取后，近端改善但远期/S3/S4仍回退；未完成其余种子。','不能说三种子新模型已完成；不能把增加预测期编码当新设计。'),
('30','能量拥塞交互最后门控','final_component_gate_20261001/REPORT_CN.txt','已完成，未过识别关','2024四个月中交互候选均不及价格对照；后续价格修正未启动。','不以事后案例合理就直接采用成分交互路由。'),
('31','公平输入与远期组合','@R/FAIR_RESULTS_CN.txt','六组骨干已完成；固定组合未全面通过','FULL/iTransformer同288步价格输入，DLinear对齐；H12差距主要来自S0，直接多步输出无递归反馈；固定组合已有收益但状态回退。','此H12问题与V7尖峰问题分开；复用已完成公平对照。'),
('32','条件收益门控','@R/conditional_gate_20261003/REPORT_CN.txt','部分前向改善，未超过固定组合','一轮条件收益估计过于保守，平方收益预测与前向实际偏离；稀有状态仅一天。','不因保住输出就宣称学会尖峰。'),
('33','直接约束损失门控','@R/direct_gate_20261003/REPORT_CN.txt','数值问题已修复，校准仍未过','SLSQP边界退化经等价变换修复；候选前向有进步，但校准真实回退和事件缺失使实际策略回退原模型。','求解器修复不等于统计问题解决；不能采用未通过部署门槛的候选数值。'),
('34','整合模型与回落/持续补全','@R/integrated_regime_20261003/REPORT_CN.txt','完成较大整合训练，仍有状态回退','已做6个新骨干、27专家/分位数头和9路由；随后回落与双状态幅值补全改善S3/S4但伤害S5。','不能再笼统说尚未尝试整体设计或双状态专家。'),
('35','事件记忆与正则化概率','@R/event_memory_gate_20261004/REPORT_CN.txt','内层筛选失败，未扩展完整拟合','价格历史加跨节点事件记忆以及后续L2逻辑门控均试过；没有获得稳定条件优势。','不能把事件历史、跨节点同时尖峰、降容量当作全新建议。'),
('36','负荷输入与成分状态转换','@R/component_transition_20261004/REPORT_CN.txt','来源可追溯子集；候选未通过','RTD/DAM负荷、LMP成分、允许重新进入极端的二状态传播均做过；改善S3/S4却加重S5误判。','S5是未来端点极端，不必全程持续；概率指标不是价格误差。'),
('37','JohnsonSU与联合分布','@R/unified_distribution_20261004/REPORT_CN.txt','联合候选失败，已有固定点分布候选','JohnsonSU外推不稳；后续有界联合分布在CAISO仍前向恶化。固定点分位数诊断有收益并已冻结，不能再次当新模型重训。','先确认冻结概率候选；只在证实新增残差时序技能后讨论SPCI。'),
('38','弹性爬坡新信息四臂','@R/next_research_design_20261004/four_arm_03/CLOSEOUT_CN.txt','总体小幅改善，状态与概率未过','MAE/H12有改善，但S1/S4回退；分位数新增信息未优于旧信息；所有修正均未触及幅度上限。','放宽上限对这批预测不起作用；奖出量不能当物理备用裕度。'),
('39','直接极端事件分类','@R/next_research_design_20261004/event_probability_04/CLOSEOUT_CN.txt','18组完成，未超过原分位数风险','发生率1.83%而候选平均14.95%；AP远弱于分位数对照；仅温度校准不能补足区分能力。','不重启分类器/温度边界搜索；不能把首段3天高事件支持说成整个研究仅3天数据。'),
('40','V7分模块和重新拟合消融','@FIRST/V7_REFIT_AUDIT.json','已完成；不支持每个小模块均必要','12版本含去常规、均值/中位数、锚定、持续时间、温度等；去温度总体更好但S3/S4变差。','先使用已有消融，不能重复补做已完成模块；不按最优一列替换模型。'),
('41','LMP分量恒等式','component_event_diagnosis_20261001/RESIDUAL_SOURCE_REVIEW.json','历史前缀核验通过；2026六月部分残差未解释','旧开发记录有1620个相关目标单元分量残差，位于S0/S1；不能归为尖峰唯一原因或未经核验称GHG。','按确切来源解释差项，禁止强制把残差塞入能量分量。'),
('42','独立确认及工程故障','@FIRST/CONFIRMATION_ADMISSION_STATUS.json','旧确认已完成，新模型确认未准入','CAISO旧H1/九月及欧洲2016已被查看；欧洲2017联合期仍缺版本时间证据。内存/磁盘/路径/序列化/监听错误不是模型失效证据。','只恢复未完成的合法步骤；历史事件去重，不启动已完成训练。'),
]

def resolve(rel):
    if rel.startswith('@R/'):
        return R / rel[3:]
    if rel.startswith('@FIRST/'):
        return FIRST / rel[7:]
    return B / rel

records = []
extracts = {}
for ident, family, source, status, finding, repeat_rule in spec:
    p = resolve(source)
    assert p.is_file(), str(p)
    raw = p.read_text(encoding='utf-8-sig')
    content = json.loads(raw) if p.suffix.lower() == '.json' else raw
    extracts[ident] = content
    records.append(dict(id=ident, family=family, status=status, finding=finding,
                        avoid_repeat=repeat_rule, path=str(p), sha256=sha(p),
                        original_status=content.get('status') if isinstance(content,dict) else None))

# Supplement family-level primary evidence with exact subtrial decisions, audits,
# protocols and prior fit-free diagnostics. Never open model target arrays.
extras = [
'adaptive_experts_v3_20260929/RISK_CONFLICT_DIAGNOSIS.json',
'spike_transition_v12_20260930/INTERPRETATION.json',
'recovery_guard_v8_20260930/INTERPRETATION.json',
'episode_spike_v9_20260930/INTERPRETATION.json',
'conditional_risk_v17_20260930/pilot/FIXED_OUTPUT_DIAGNOSIS.json',
'retention_diagnosis_v20_20260930/NEXT_DECISION.json',
'multi_round_mechanism_v21_20261001/PRIOR_WORK_REVIEW.json',
'root_cause_review_20261001/ROOT_CAUSE_REVIEW.json',
'root_cause_review_20261001/detail_trace/INTERPRETATION.json',
'root_cause_review_20261001/deep_mechanism_trace/DEEP_REVIEW.json',
'probability_contract_v23_20261001/DECISION.json',
'support_capacity_v24_20261001/DECISION.json',
'temporal_memory_v26_20261001/OUTCOME_REVIEW.json',
'component_event_diagnosis_20261001/COMPONENT_IDENTITY_DIAGNOSIS.json',
'@R/FAIR_RECONCILED.json','@R/FAIR_COMPLETE.json',
'@R/recovery_transition_20261004/REPORT_CN.txt',
'@R/two_regime_completion_20261004/REPORT_CN.txt',
'@R/regularized_gate_20261004/REPORT_CN.txt',
'@R/load_gate_probe_20261004/REPORT_CN.txt',
'@R/component_diagnosis_20261004/REPORT_CN.txt',
'@R/unified_distribution_20261004/point_anchored_candidate/FREEZE.json',
'@R/next_research_design_20261004/four_arm_03/CAP_DIAGNOSIS.json',
'@R/next_research_design_20261004/event_probability_04/AUDIT.json',
'@FIRST/V7_REFIT_RESULT.json','@FIRST/PROBABILITY_INDEPENDENT_AUDIT.json',
'v7_confirmation_20260930/AUDIT.json',
]
extra_records = []
for rel in extras:
    p = resolve(rel)
    assert p.is_file(), str(p)
    raw = p.read_text(encoding='utf-8-sig')
    extracts[rel] = json.loads(raw) if p.suffix.lower()=='.json' else raw
    extra_records.append(dict(path=str(p), sha256=sha(p)))

# Simple arithmetic review of an existing ablation, not new prediction or fitting.
rows = read(FIRST/'V7_REFIT_RESULT.json')['rows']
ablation = []
for part in ['overall','S0','S1','S2','S3','S4','S5']:
    vals = {}
    for model in ['REPLAY','NO_TEMPERATURE','NO_DURATION_FEATURES']:
        subset = [x for x in rows if x['model']==model and x['subset']==part]
        assert len(subset)==3
        vals[model] = {k:statistics.mean(x[k] for x in subset) for k in ['mae','rmse']}
    ablation.append(dict(scope=part, means_of_three_seed_metrics=vals))

protected = read(R/'PROTECTED_FILES.json')
checks = []
for p, expected in protected.items():
    actual = sha(Path(p))
    checks.append(dict(path=p, expected=expected, actual=actual, passed=actual==expected))
assert all(x['passed'] for x in checks)
now = datetime.now(timezone(timedelta(hours=8))).isoformat()
save('修补路线登记.json',dict(at=now, scope='Retained documentary review; no retraining or raw-target access; family rows are not fit counts', trials=records))
save('证据原文摘录.json',extracts)
save('证据索引.json',dict(at=now, primary=records, supplementary=extra_records,
                         source_file_count=len({x['path'] for x in records+extra_records})))
save('已有消融复算.json',dict(at=now, scope='698-origin already inspected V7 development; seed-metric means', rows=ablation))
save('复盘核验.json',dict(at=now, protected_file_checks=checks, new_fits=0,new_predictions=0,
                       new_test_targets_read=False, manuscript_modified=False,
                       external_human_review=False, historical_audits_rerun=False,
                       scope='Source existence/hash checks, saved-report synthesis, existing ablation mean arithmetic; not full experimental reproduction'))
lines = ['修补路线登记（完整分组清单）','日期：'+now,
         '本清单按研究问题归并，条目数不等于实验/模型训练次数。所有来源在证据索引中附SHA256。',
         '未训练或因来源阻塞的方案与已训练失败方案分开；不同面板的绝对误差不串成版本排行榜。','']
for x in records:
    lines += [x['id']+' '+x['family'], '状态：'+x['status'], '发现：'+x['finding'],
              '重复检查：'+x['avoid_repeat'],'证据：'+x['path'],'SHA256：'+x['sha256'],'']
(OUT/'修补路线完整清单.txt').write_text('\n'.join(lines),encoding='utf-8')
print(json.dumps(dict(trial_families=len(records), evidence_files=len(records+extra_records), protected_files=len(checks), output=str(OUT)),ensure_ascii=False))
