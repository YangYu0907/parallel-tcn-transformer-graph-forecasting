$ErrorActionPreference='Stop'
$experiment=Split-Path -Parent (Split-Path -Parent $PSScriptRoot)
$branch=Split-Path -Parent $experiment
$python='D:\Documents\conda_envs\tcn_air\python.exe'
$scriptPath=Join-Path $PSScriptRoot 'main.py'
$bridgePath=Join-Path $experiment 'watch_manager_exit.ps1'
if(Test-Path -LiteralPath (Join-Path $PSScriptRoot 'completion.json')){throw 'Diagnostic already complete'}
$all=@(Get-CimInstance Win32_Process)
if(@($all|Where-Object {$_.Name -in @('python.exe','pythonw.exe')}).Count){throw 'Existing Python process needs review'}
& $python -c "import sys;sys.path.insert(0,r'$PSScriptRoot');import main;main.verify();main.g.need(not main.g.LOCK.exists(),'Numerical lock exists');print(main.g.guard(True))"
if($LASTEXITCODE -ne 0){throw 'Source/resource gate failed'}
$watchPath=Join-Path $branch 'event_driven_automation\watch.ps1'
$watchers=@($all|Where-Object {$_.Name -eq 'powershell.exe' -and $_.CommandLine -and $_.CommandLine.Contains($watchPath)})
if($watchers.Count -ne 1){throw 'Exactly one existing event listener required'}
$watchState=Get-Content -LiteralPath (Join-Path $branch 'event_driven_automation\status.json') -Raw -Encoding UTF8|ConvertFrom-Json
if([int]$watchState.pid -ne $watchers[0].ProcessId){throw 'Listener identity mismatch'}
$logs=Join-Path $PSScriptRoot ('launch_'+[guid]::NewGuid().ToString('N').Substring(0,10))
New-Item -ItemType Directory -Path $logs|Out-Null
$manager=Start-Process -FilePath $python -ArgumentList @(('"'+$scriptPath+'"')) -WorkingDirectory $PSScriptRoot -WindowStyle Hidden -RedirectStandardOutput (Join-Path $logs 'worker.stdout.log') -RedirectStandardError (Join-Path $logs 'worker.stderr.log') -PassThru
$ticks=$manager.StartTime.ToUniversalTime().Ticks
$bridgeArgs=@('-NoProfile','-ExecutionPolicy','Bypass','-File',('"'+$bridgePath+'"'),'-ManagerProcessId',[string]$manager.Id,'-ManagerStartUtcTicks',[string]$ticks,'-ManagerScript',('"'+$scriptPath+'"'),'-StatusPath',('"'+(Join-Path $PSScriptRoot 'status.json')+'"'))
$bridge=Start-Process -FilePath 'C:\Windows\System32\WindowsPowerShell\v1.0\powershell.exe' -ArgumentList $bridgeArgs -WorkingDirectory $branch -WindowStyle Hidden -RedirectStandardOutput (Join-Path $logs 'bridge.stdout.log') -RedirectStandardError (Join-Path $logs 'bridge.stderr.log') -PassThru
$record=[ordered]@{at=[DateTime]::UtcNow.ToString('o');worker_pid=$manager.Id;start_utc_ticks=$ticks;bridge_pid=$bridge.Id;watcher_pid=$watchers[0].ProcessId;logs=$logs;training_updates=0;periodic_model_calls=$false}
$record|ConvertTo-Json|Set-Content -LiteralPath (Join-Path $PSScriptRoot 'launch.json') -Encoding UTF8
$record|ConvertTo-Json
