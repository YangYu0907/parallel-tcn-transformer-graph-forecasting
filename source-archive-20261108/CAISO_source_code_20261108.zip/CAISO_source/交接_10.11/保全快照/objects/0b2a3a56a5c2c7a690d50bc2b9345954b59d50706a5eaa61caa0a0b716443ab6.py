from base import *
from features import *
import argparse
def temperature(p,t):
    z=np.log(np.maximum(p,1e-12))/t;z-=z.max(1,keepdims=True);z=np.exp(z);return z/z.sum(1,keepdims=True)
def fitted(path,X,y,kind,tick):
    from sklearn.ensemble import HistGradientBoostingRegressor,HistGradientBoostingClassifier
    ident=dict(protocol=sha(HERE/'PROTOCOL.json'),kind=kind,rows=len(y),cols=X.shape[1])
    if path.exists():
        obj=load(path);assert obj['identity']==ident;model=obj['model']
    else:
        cfg=dict(max_iter=20,max_leaf_nodes=7,min_samples_leaf=50,learning_rate=.05,l2_regularization=1.,
            early_stopping=False,warm_start=True,random_state=20260813)
        model=HistGradientBoostingClassifier(**cfg) if kind=='transition' else HistGradientBoostingRegressor(loss='squared_error',**cfg)
    for it in [20,40,60,80]:
        if getattr(model,'n_iter_',0)>=it:continue
        tick(head=kind,iteration=it);model.set_params(max_iter=it);model.fit(X,y)
        dump(path,dict(identity=ident,model=model))
    return model
def run(fold):
    verify();folder=HERE/f'fold{fold}';folder.mkdir(exist_ok=True)
    if (folder/'COMPLETE.json').exists():return
    with numeric('prefix recovery and transition heads '+str(fold)):
        from scipy.optimize import minimize_scalar
        from sklearn.metrics import log_loss
        tick=timer('fit');raw,times,_,_=parent.arrays()
        z=np.load(OLD/f'fold{fold}_origins.npz');st=read(OLD/f'fold{fold}_stats.json')['tree']
        X,y,rec,days,n=rows(raw,times,z['treefit'],st,tick)
        xc,yc,rc,dc,nc=rows(raw,times,z['treecal'],st,tick)
        classifier=fitted(folder/'transition.pkl',X,rec.astype(int),'transition',tick)
        assert classifier.classes_.tolist()==[0,1]
        recovery=fitted(folder/'recovery.pkl',X[rec],y[rec],'recovery',tick)
        cp=classifier.predict_proba(xc)
        opt=minimize_scalar(lambda t:log_loss(rc,temperature(cp,t),labels=[False,True]),bounds=(.5,2.),method='bounded')
        assert opt.success;temp=float(opt.x)
        write(folder/'FROZEN.json',dict(at=now(),temperature=temp,fit_rows=len(y),recovery_rows=int(rec.sum()),
            prefix_calibration_rows=len(yc),prefix_targets_latest=int(times[z['treecal'].max()+11]),
            model_hashes={p.name:sha(p) for p in folder.glob('*.pkl')},statistics_sha256=sha(OLD/f'fold{fold}_stats.json'),
            prediction='center + q99abs*clip(predicted absolute-price ratio,-1,1)',future_state_used_as_input=False))
        ev=z['evaluate'];pr=[];rr=[];gate=[];c=np.asarray(st['center']);q=np.asarray(st['thresholds'])[1]
        neural=read(OLD/f'fold{fold}_stats.json')['neural'];nc=np.asarray(neural['center']);nq=np.asarray(neural['thresholds'])[1]
        for j in range(0,len(ev),32):
            tick(fold=fold,inference=j,total=len(ev));oo=ev[j:j+32];f,last=features_at(raw,oo,st)
            nodes=np.tile(np.repeat(np.arange(30),5),len(oo));hh=np.tile(np.arange(8,13)/12,len(oo)*30)
            xx=np.column_stack([np.repeat(f.reshape(-1,37),5,axis=0),np.eye(30,dtype='float32')[nodes],hh]).astype('float32')
            prob=temperature(classifier.predict_proba(xx),temp)[:,1]
            pred=c[nodes]+q[nodes]*np.clip(recovery.predict(xx),-1,1)
            rr.append(pred.reshape(-1,30,5));pr.append(prob.reshape(-1,30,5))
            # Intersection preserves every original nonextreme state output exactly.
            gate.append((abs(last-c)>q)&(abs(last-nc)>nq))
        save(folder/'PREDICTIONS.npz',origins=ev,recovery=np.concatenate(rr),probability=np.concatenate(pr),eligible=np.concatenate(gate))
        verify();write(folder/'COMPLETE.json',dict(at=now(),fold=fold,status='prefix_heads_complete',
            frozen_sha256=sha(folder/'FROZEN.json'),predictions_sha256=sha(folder/'PREDICTIONS.npz'),new_test_targets_read=False))
        tick(status='complete',fold=fold)
if __name__=='__main__':
    p=argparse.ArgumentParser();p.add_argument('--fold',required=True,type=int);a=p.parse_args();run(a.fold)

