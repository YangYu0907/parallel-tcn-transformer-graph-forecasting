"""Loss-gradient, lambda-zero equivalence and exact saved-resume QA."""
import copy,io,json,random,sys,uuid
import gate
def main():
    with gate.exclusive('retention_math_QA'):
        np,torch,limiter=gate.runtime()
        import math_ops as m
        import train as runner
        runner.np=np;runner.torch=torch
        checks=[]
        def check(name,value=True):gate.need(value,name);checks.append(name)
        torch.manual_seed(716)
        p=torch.randn(4,3,2,dtype=torch.float64,requires_grad=True)
        y=torch.randn_like(p);t=torch.randn_like(p,requires_grad=True);mask=torch.tensor([True,False,True,False])
        total,sup,ret=m.objective(p,y,t,mask,1.)
        total.backward()
        expected=(torch.clamp(p.detach()-y,-.5,.5)+torch.clamp(p.detach()-t.detach(),-.5,.5)*mask[:,None,None])/p.numel()
        check('analytic_masked_huber_gradient',torch.allclose(p.grad,expected,rtol=0,atol=1e-15))
        check('teacher_gradient_detached',t.grad is None)
        losses=[]
        for idx in range(4):
            for n in range(3):
                for h in range(2):
                    def hub(z):
                        v=abs(float(z));return .5*v*v if v<=.5 else .5*(v-.25)
                    losses.append(hub(p[idx,n,h].detach()-y[idx,n,h])+int(mask[idx])*hub(p[idx,n,h].detach()-t[idx,n,h].detach()))
        check('scalar_loss_oracle',abs(float(total.detach())-sum(losses)/len(losses))<1e-14)
        zero,_,_=m.objective(p.detach(),y,t.detach(),torch.zeros(4,dtype=torch.bool),1.)
        check('zero_hour_mask_no_penalty',torch.equal(zero,torch.nn.functional.huber_loss(p.detach(),y,delta=.5)))
        try:m.objective(p,y,t,mask,.5);raise AssertionError('Unregistered lambda')
        except ValueError:check('unregistered_lambda_rejected')
        class Toy(torch.nn.Module):
            def __init__(self):super().__init__();self.dropout=torch.nn.Dropout(.1);self.fc=torch.nn.Linear(5,6)
            def forward(self,x):return {'prediction':self.fc(self.dropout(x)).reshape(-1,3,2)}
        teacher=Toy().eval().requires_grad_(False)
        a=Toy().train();b=copy.deepcopy(a).train()
        oa=runner.opt_for(a);ob=runner.opt_for(b)
        x=torch.randn(4,5);target=torch.randn(4,3,2)
        frozen={k:v.clone() for k,v in teacher.state_dict().items()}
        seed=torch.get_rng_state().clone()
        m.step(a,teacher,oa,x,target,mask,0.)
        torch.set_rng_state(seed);ob.zero_grad(set_to_none=True)
        loss=torch.nn.functional.huber_loss(b(x)['prediction'],target,delta=.5);loss.backward()
        torch.nn.utils.clip_grad_norm_(b.parameters(),1.);ob.step()
        check('lambda_zero_exact_original_update',all(torch.equal(v,b.state_dict()[k]) for k,v in a.state_dict().items()))
        check('teacher_frozen_after_step',all(torch.equal(v,teacher.state_dict()[k]) for k,v in frozen.items()))
        check('teacher_no_grad',all(v.grad is None for v in teacher.parameters()))
        # Test actual receipt/checkpoint and recovery functions, including RNG and optimizer.
        rng=np.random.default_rng(937);np.random.seed(937);random.seed(937)
        run=gate.HERE/'qa_artifacts'/uuid.uuid4().hex
        identity={'toy_resume':True}
        state=dict(phase='train',epoch=1,steps=1,offset=4,order=np.arange(12),epochs=[])
        runner.checkpoint(run,identity,a,oa,rng,state)
        offset=int(rng.integers(1,100));nx=torch.randn(4,5);ny=torch.randn(4,3,2)
        m.step(a,teacher,oa,nx,ny,mask,1.)
        expected={k:v.clone() for k,v in a.state_dict().items()}
        saved=runner.recover(run,identity)
        c=Toy();oc=runner.opt_for(c);c.load_state_dict(saved['state_dict']);oc.load_state_dict(saved['optimizer']);c.train(saved['model_training'])
        rr=np.random.default_rng(1);runner.rng_set(saved['rng'],rr)
        check('numpy_resume_identical',int(rr.integers(1,100))==offset)
        xx=torch.randn(4,5);yy=torch.randn(4,3,2)
        check('torch_resume_inputs_identical',torch.equal(nx,xx) and torch.equal(ny,yy))
        m.step(c,teacher,oc,xx,yy,mask,1.)
        check('retention_step_resume_bitwise',all(torch.equal(v,c.state_dict()[k]) for k,v in expected.items()))
        # Receipt committed before latest-pointer crash is recoverable.
        state.update(steps=2,offset=8)
        latest=gate.read(run/'latest.json')
        runner.checkpoint(run,identity,c,oc,rr,state)
        gate.write(run/'latest.json',latest,True)
        recovered=runner.recover(run,identity)
        check('unpointed_newer_checkpoint_recovered',recovered['progress']['steps']==2)
        # Array/mode shapes and named teacher-loss mask arithmetic.
        for penalty in (0.,1.):
            result,_,_=m.objective(p.detach(),y,t.detach(),mask,penalty)
            check('finite_loss_'+str(penalty),bool(torch.isfinite(result)))
        for path in gate.HERE.glob('*.py'):compile(path.read_text(encoding='utf-8'),str(path),'exec')
        check('all_sources_compile')
        report=dict(status='passed',at=gate.now(),checks=checks,
            sources={gate.rel(p):gate.sha(p) for p in sorted(gate.HERE.glob('*.py'))},
            real_price_or_feature_values_read=False,real_models_trained=False,heldout_targets_read=False)
        gate.write(gate.HERE/'synthetic_qa.json',report)
        print(json.dumps(dict(status='passed',checks=len(checks))))
if __name__=='__main__':main()

