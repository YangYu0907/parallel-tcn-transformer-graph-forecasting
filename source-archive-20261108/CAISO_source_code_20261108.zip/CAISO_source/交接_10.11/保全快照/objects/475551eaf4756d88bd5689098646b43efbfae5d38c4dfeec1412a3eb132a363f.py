from pathlib import Path
from datetime import datetime, timezone
import sys, json, hashlib, importlib.util, os
import psutil
B = Path(r'C:\Users\于阳\CAISO_feature_fusion_rev12\asof_retraining_branch_20260913')
OUT=B/'audits/interruption_recovery_20260923'
class BlockNumeric:
    def find_spec(self, fullname, path=None, target=None):
        if fullname.split('.')[0] in ('numpy','torch'):
            raise RuntimeError('Numeric import forbidden in metadata audit: '+fullname)
sys.meta_path.insert(0, BlockNumeric())
def read(p): return json.loads(Path(p).read_text(encoding='utf-8-sig'))
def sha(p):
    h=hashlib.sha256()
    with Path(p).open('rb') as f:
        for block in iter(lambda:f.read(1024*1024), b''): h.update(block)
    return h.hexdigest()
def process(pid, created=None):
    try:
        p=psutil.Process(pid)
        row={'pid':pid,'pid_exists':True,'created':p.create_time(),'command':p.cmdline(),'name':p.name()}
        if created is not None: row['same_owner_identity']=abs(p.create_time()-created)<0.001
        return row
    except psutil.NoSuchProcess: return {'pid':pid,'pid_exists':False,'same_owner_identity':False}
    except psutil.AccessDenied: return {'pid':pid,'pid_exists':True,'identity_read_denied':True}
spec=importlib.util.spec_from_file_location('independent_frozen_manager', B/'mechanism_controls_20260920/manager.py')
m=importlib.util.module_from_spec(spec); spec.loader.exec_module(m)
plan=m.verify()
seal_sha=sha(m.SEAL)
completed=[]
for step in plan['steps']:
    path=m.STATE/'steps'/(step['id']+'.json')
    if path.exists():
        receipt=read(path); marker=m.checked_marker(step)
        assert receipt['seal_sha256']==seal_sha
        assert receipt['step']==step and receipt['marker']==marker
        assert receipt.get('exit_code',0)==0
        completed.append({'step':step['id'],'receipt_sha256':sha(path),'marker':marker,'exit_code':receipt.get('exit_code')})
assert len(completed)==12
assert all('20260813_GLOBAL' in x['step'] for x in completed)
run=B/'runs/backbone/20260814_GLOBAL'
latest=read(run/'latest.json')
ckpt=B/latest['path']; receipt_path=ckpt.with_suffix('.receipt.json')
assert read(receipt_path)==latest
assert sha(ckpt)==latest['sha256']
assert latest['identity']==read(run/'run_start.json')['identity']
receipts=[]
for p in (run/'checkpoints').glob('*.receipt.json'):
    r=read(p); target=B/r['path']
    assert target.parent.resolve()==(run/'checkpoints').resolve()
    assert target.with_suffix('.receipt.json')==p
    assert r['status']=='committed' and sha(target)==r['sha256']
    assert r['identity']==latest['identity']
    receipts.append(r)
assert latest['steps']==max(r['steps'] for r in receipts)
assert latest['steps']==2752 and latest['epoch']==6 and latest['phase']=='train'
identity=latest['identity']
bindings={'dataset_manifest_sha256':B/identity['dataset_manifest'], 'dataset_audit_sha256':B/'dataset/compiled_train_june/audit.json','backbone_lock_sha256':B/'CONTROL_BACKBONE_LOCK.json','compiler_lock_sha256':B/'COMPILER_LOCK.json','model_qa_sha256':B/'audits/model_synthetic_qa.json','math_qa_sha256':B/'audits/backbone_math_qa.json','recipe_sha256':B/'recipe.json'}
for k,p in bindings.items(): assert sha(p)==identity[k],k
qa=read(B/'audits/backbone_math_qa.json'); assert qa['status']=='passed' and qa['resume_exact'] is True
for rel,digest in qa['sources'].items(): assert sha(B/rel)==digest,rel
finaldir=B/'stages/query/20260813_GLOBAL/runs/CONTROL'; audit=read(finaldir/'control_audit.json')
assert audit['status']=='passed' and audit['identity']['seed']==20260813 and audit['identity']['variant']=='GLOBAL'
for key,name in [('selection_sha256','selection.json'),('fit_completion_sha256','fit_completion.json'),('run_start_sha256','run_start.json')]: assert audit[key]==sha(finaldir/name)
assert audit['auditor_source_sha256']==sha(B/'source/audit_query_stage.py')
lockpaths=[B/'mechanism_controls_20260920/queue/QUEUE.lock',B/'phase_sampling_additive_v2_20260920/queue/QUEUE.lock',Path(r'D:\Desktop\数据科学_论文\研究优化_20260818\logs\NEURAL_RUN.lock')]
locks=[]
for p in lockpaths:
    row=read(p)
    locks.append({'path':str(p),'sha256':sha(p),'owner':row,'process':process(row['pid'],row['created'])})
oldprocesses=[process(pid) for pid in (18996,2960,17648,18392,8284,2368)]
relevant=[]
for p in psutil.process_iter(['pid','name','cmdline','create_time']):
    try:
        row=p.info
        if row['pid']==os.getpid(): continue
        if str(row['name']).lower() not in ('python.exe','pythonw.exe','powershell.exe','pwsh.exe'): continue
        command=' '.join(row['cmdline'] or [])
        if 'CAISO_feature_fusion_rev12' in command and not ('-Command' in command and 'independent_inspect.py' in command): relevant.append(row)
    except (psutil.NoSuchProcess,psutil.AccessDenied): pass
missing_markers={name:(run/name).exists() for name in ('completion.json','independent_audit.json','backbone_audit.json')}
row={'status':'passed_metadata_integrity_only','at':datetime.now(timezone.utc).isoformat(),'reviewer':'/root/interruption_audit_0923','frozen_manager_verify_passed':True,'manager_sha256':sha(m.__file__),'seal_sha256':seal_sha,'registered_mechanism_steps':len(plan['steps']),'completed_receipts':completed,'completed_receipt_count':len(completed),'GLOBAL_S1_final_audit':{'path':str(finaldir/'control_audit.json'),'sha256':sha(finaldir/'control_audit.json'),'selection_completion_start_source_hashes_matched':True,'stored_numeric_replay_passed':audit['selected_predictions_replayed'],'numeric_replay_reexecuted_by_this_review':False},'GLOBAL_S2_latest':latest,'GLOBAL_S2_checkpoint_file_bytes':ckpt.stat().st_size,'pointer_equals_durable_receipt':True,'all_durable_receipts_hash_checked':len(receipts),'checkpoint_identity_bound_to_current_run':True,'identity_metadata_hash_bindings_verified':list(bindings),'completion_marker_presence':missing_markers,'mechanism_queue_completion_exists':(m.STATE/'completion.json').exists(),'original_resume_math_QA_unchanged_and_resume_exact':True,'lock_evidence':locks,'previous_processes':oldprocesses,'other_relevant_processes':relevant,'numeric_imports':any(x in sys.modules for x in ('numpy','torch')),'checkpoints_deserialized':False,'target_arrays_read':False,'locks_changed':False,'training_started_by_this_audit':False,'scope':'File-byte integrity and metadata receipts only; actual optimizer/RNG/state acceptance remains the unchanged trainer resume admission and future completion auditor. No new numerical accuracy conclusion.'}
assert not row['numeric_imports']
assert not any(x['process'].get('same_owner_identity') for x in locks)
assert all(x['owner']['created'] < psutil.boot_time() for x in locks)
assert all('event_driven_automation' in ' '.join(x.get('cmdline') or []) and 'watch.ps1' in ' '.join(x.get('cmdline') or []) for x in relevant)
row['boot_time_epoch']=psutil.boot_time()
row['all_lock_owners_precede_current_boot']=True
row['no_live_training_or_manager_process']=True
row['status']='passed_for_stale_lock_recovery'
row['admission_scope']='Only preserve-and-quarantine the three exact old-owner locks after a fresh owner/hash recheck; resume with unchanged runner and resource checks. This does not certify tensor internals or permit bypassing guards.'
p=OUT/'independent_review.json'; temp=p.with_suffix('.tmp')
with temp.open('x',encoding='utf-8') as f: json.dump(row,f,ensure_ascii=False,indent=2);f.flush();os.fsync(f.fileno())
os.replace(temp,p)
print(json.dumps({'status':row['status'],'path':str(p),'sha256':sha(p),'completed_receipts':len(completed),'latest_steps':latest['steps'],'hashed_durable_receipts':len(receipts),'other_relevant_processes':relevant},ensure_ascii=False))

