"""Serialize the admitted compiler with other numerical work; no model runtime."""
from pathlib import Path
from datetime import datetime
import json,os,runpy,sys,time,uuid
import psutil
import compile_gate as gate

def main():
    decision=gate.preflight()
    if decision['errors']:raise RuntimeError(str(decision['errors']))
    path=Path(r'D:\Desktop\数据科学_论文\研究优化_20260818\logs\NEURAL_RUN.lock')
    owner=dict(token=uuid.uuid4().hex,pid=os.getpid(),created=psutil.Process().create_time(),
               action='asof_TRAIN_June_bounded_dataset_compilation',directory=str(gate.ROOT),
               at=datetime.now().astimezone().isoformat(),launcher_sha256=gate.sha(__file__))
    with path.open('x',encoding='utf-8') as stream:
        json.dump(owner,stream);stream.flush();os.fsync(stream.fileno())
    gate.write_new(gate.ROOT/'audits/compile_runs'/(owner['token']+'_started.json'),dict(owner=owner,decision=decision))
    print(json.dumps(dict(event='real_TRAIN_June_compiler_started',pid=os.getpid(),owner_token=owner['token'],at=owner['at'])),flush=True)
    try:
        sys.argv=[str(gate.ROOT/'source/compile_dataset.py')]
        runpy.run_path(sys.argv[0],run_name='__main__')
        gate.write_new(gate.ROOT/'audits/compile_runs'/(owner['token']+'_completed.json'),dict(status='completed',at=datetime.now().astimezone().isoformat(),dataset_manifest_sha256=gate.sha(gate.ROOT/'dataset/compiled_train_june/manifest.json')))
    except BaseException as exc:
        gate.write_new(gate.ROOT/'audits/compile_runs'/(owner['token']+'_failed.json'),dict(status='failed',at=datetime.now().astimezone().isoformat(),exception_type=type(exc).__name__,message=str(exc),uncommitted_artifacts_preserved=True))
        raise
    finally:
        if gate.read(path)!=owner:raise RuntimeError('Compiler global lock owner changed')
        gate.write_new(gate.ROOT/'audits/lock_releases'/(owner['token']+'.json'),dict(owner=owner,released_at=datetime.now().astimezone().isoformat()))
        path.unlink()
if __name__=='__main__':main()
