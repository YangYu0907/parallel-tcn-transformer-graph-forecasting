"""Metadata gates shared by isolated sampling compilation and auditing."""
from pathlib import Path
import importlib.util
import sys

HERE = Path(__file__).resolve().parents[1]
ROOT = HERE.parent
sys.path.insert(0, str(ROOT / 'source'))
import backbone_train as original

read, sha, write, inside = original.read, original.sha, original.write, original.inside
PARENT = ROOT / 'dataset/compiled_train_june/manifest.json'
POLICIES = ('REPEAT', 'ADDITIVE')
MECHANISM_SEAL = 'df22327685d4c06baf14cf85411dab81561bdcee5aa821734dfe4183adf45f17'


def source_review(path, required_paths):
    review = read(path)
    if review.get('status') != 'passed':
        raise RuntimeError('Independent source review has not passed: ' + str(path))
    bindings = review['sources']
    for target in required_paths:
        name = str(Path(target).resolve().relative_to(ROOT))
        if bindings.get(name) != sha(target):
            raise RuntimeError('Review does not bind current source: ' + name)
    for name, digest in bindings.items():
        if sha(inside(name)) != digest:
            raise RuntimeError('Independent review binding changed: ' + name)
    return sha(path)


def parent_admission():
    protocol = read(HERE / 'PROTOCOL.json')
    original.bindings_check(protocol['bindings'])
    design = read(HERE / 'independent_design_review.json')
    if (design.get('status') != 'design_only_not_training_ready' or
            design.get('protocol_sha256') != sha(HERE / 'PROTOCOL.json')):
        raise RuntimeError('Sampling design review is stale')
    original.bindings_check(design['source_bindings_sha256'])
    independent = read(HERE / 'independent_schedule_source_review.json')
    if (independent.get('status') != 'passed_source_and_synthetic_only' or
            independent.get('actual_exit_code') != 0):
        raise RuntimeError('Independent pure scheduler tests missing')
    for row in independent['bound_files'].values():
        if sha(inside(row['path'])) != row['sha256']:
            raise RuntimeError('Independent scheduler review changed')
    identity = original.admission(PARENT, 'FULL', 20260813)
    if original.stop_reason(HERE):
        raise RuntimeError('Research or sampling branch is paused')
    return identity


def require_mechanisms_complete():
    folder = ROOT / 'mechanism_controls_20260920'
    if sha(folder / 'SEAL.json') != MECHANISM_SEAL:
        raise RuntimeError('Prior mechanism seal changed')
    completion_path = folder / 'queue/completion.json'
    if not completion_path.exists():
        raise RuntimeError('Prior 96-step mechanisms still pending; no numerical work allowed')
    if (folder / 'queue/QUEUE.lock').exists():
        raise RuntimeError('Prior mechanism manager has not released ownership')
    seal = read(folder / 'SEAL.json')
    original.bindings_check(seal['sources'])
    spec = importlib.util.spec_from_file_location('prior_mechanism_sampling_gate', folder / 'manager.py')
    module = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(module)
    plan = module.verify()
    completion = read(completion_path)
    if (completion.get('status') != 'eight_mechanism_cases_TRAIN_June_independently_audited' or
            completion.get('seal_sha256') != MECHANISM_SEAL):
        raise RuntimeError('Prior mechanism completion is invalid')
    expected = {s['id'] + '.json' for s in plan['steps']}
    if set(completion['step_receipts']) != expected or len(expected) != 96:
        raise RuntimeError('Prior mechanism receipt set is incomplete')
    for step in plan['steps']:
        name = step['id'] + '.json'
        path = folder / 'queue/steps' / name
        receipt = read(path)
        if (sha(path) != completion['step_receipts'][name] or
                receipt['step'] != step or receipt['seal_sha256'] != MECHANISM_SEAL or
                receipt['marker'] != module.checked_marker(step)):
            raise RuntimeError('Prior mechanism receipt/marker changed: ' + name)
    return sha(completion_path)


def launch_guard():
    if original.stop_reason(HERE):
        raise RuntimeError('Research or sampling branch is paused')
    import compile_gate
    capacity = compile_gate.resources()
    if min(capacity['available_physical_GiB'], capacity['available_commit_GiB']) < 5:
        raise MemoryError('Sampling launch requires 5 GiB physical RAM and commit')
    if original.GLOBAL_LOCK.exists():
        raise RuntimeError('Another numerical worker owns NEURAL_RUN.lock')
    return capacity


def immutable_json(path, value):
    if Path(path).exists():
        if read(path) != value:
            raise RuntimeError('Immutable output differs: ' + str(path))
    else:
        write(path, value)


def diagnostic_panel(eligible, times, rule):
    """Hash-only fixed panel; values never passed to this function."""
    import hashlib
    if (rule.get('origins_per_phase') != 24 or rule.get('total_origins') != 288 or
            rule.get('target_stop_exclusive') != 210528 or
            rule.get('uses_model_rng') is not False or rule.get('uses_values_or_errors') is not False):
        raise ValueError('Fixed diagnostic rule changed')
    selected = []
    for phase in range(12):
        candidates = [int(o) for o in eligible if (int(times[int(o)]) // 300) % 12 == phase]
        if len(candidates) < 24:
            raise ValueError('Insufficient diagnostic phase support')
        candidates.sort(key=lambda o: hashlib.sha256((rule['salt'] + '|' + str(o)).encode()).digest())
        selected.extend(candidates[:24])
    return sorted(selected)
