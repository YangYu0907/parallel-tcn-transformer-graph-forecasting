from common import *

def main():
    with gate.exclusive('Freeze prefix experts and replay all downstream origins'):
        np,torch,lim=gate.runtime();start();sealcheck()
        neural=gate.read(HERE/'NEURAL_COMPLETE.json');sp=gate.read(HERE/'SPECIALIST_COMPLETE.json');selected=neural['selected']
        bindings={**sp['bindings'],selected['path']:selected['sha256'],str(HERE/'DATA.json'):gate.sha(HERE/'DATA.json')}
        for p,h in bindings.items():assert gate.sha(p)==h,p
        if not (HERE/'FINAL_FREEZE.json').exists():write(HERE/'FINAL_FREEZE.json',dict(at=gate.now(),status='both_prefix_expert_families_and_preprocessing_frozen',bindings=bindings,evaluation_origin_hash=gate.sha(Path(gate.read(HERE/'DATA.json')['directory'])/'evaluation.npy'),future_scores_used_for_selection=False))
        else:assert gate.read(HERE/'FINAL_FREEZE.json')['bindings']==bindings
        import train as tr;tr.np=np;tr.torch=torch
        from models.factory import build_backbone
        data=Data(np);model=build_backbone('FULL',SEED,gate.read(data.d/'context_limits.json')['limits']);cp=torch.load(selected['path'],map_location='cpu',weights_only=False);model.load_state_dict(cp['state_dict']);del cp;model.eval()
        if not (ART/'SELECTED_DENSE_VALIDATION.npz').exists():
            vp,vy=tr.evaluate(model,data,data.origins['valid'],'valid')
            save(ART/'SELECTED_DENSE_VALIDATION.npz',origins=data.origins['valid'],prediction=vp,truth=vy)
        origins=data.origins['evaluation'];n=len(origins);full=np.empty((n,30,12),np.float64)
        before=tr.fingerprint(model);r=torch.get_rng_state().clone()
        with torch.no_grad():
            for a in range(0,n,128):
                chunk=ART/f'full_chunks/{a:06d}.npz';oo=origins[a:a+128]
                if chunk.exists():
                    with np.load(chunk) as z:assert np.array_equal(z['origins'],oo);values=z['prediction']
                else:
                    values=np.empty((len(oo),30,12),float)
                    for k in range(0,len(oo),4):
                        x,_=data.batch(oo[k:k+4]);values[k:k+4]=model(torch.from_numpy(x))['prediction'].numpy().astype(float)*data.scale[None,:,None]+data.center[None,:,None]
                    save(chunk,origins=oo,prediction=values)
                full[a:a+len(oo)]=values;check(stage='downstream_FULL_replay',done=a+len(oo),total=n)
        assert before==tr.fingerprint(model) and torch.equal(r,torch.get_rng_state())
        import specialist as spm;spm.np=np
        context_path=ART/'specialist/evaluation_features.npz'
        if context_path.exists():
            with np.load(context_path) as z:d={k:z[k] for k in z.files}
        else:d=spm.features(data,origins);save(context_path,**d)
        forecast,prob=spm.predict(data,d,full);assert np.isfinite(forecast).all()
        # Store forecasts before scoring historical targets, including all non-extreme origins unchanged.
        save(ART/'PREDICTIONS.npz',origins=origins,FULL=full,SPIKE_ARM=forecast)
        from compile_math import group_codes
        truth=np.stack([data.raw[o:o+12,:,0].T for o in origins]).astype(float);last=np.asarray(data.raw[origins-1,:,0],float);states=group_codes(truth,last,data.center,np.array(data.th['thresholds']))
        oo=d['origin_index'];nn=d['node'];ready=np.load(data.d/'evaluation_label_available.npy');ready=np.maximum(ready,data.times[origins[:,None]+np.arange(12)]+300)
        save(ART/'EXPERT_ERROR_LIBRARY.npz',origins=origins[oo],node=nn,issued=data.times[origins[oo]-1],available=ready[oo],context=d['context'],X=d['X'],duration=d['duration'],FULL=full[oo,nn],SPECIALIST=forecast[oo,nn],truth=truth[oo,nn],states=states[oo,nn],probabilities=prob)
        metrics={};dates=data.times[origins-1]//86400
        def measure(error):return dict(mae=float(abs(error).mean()),rmse=float(np.sqrt((error**2).mean()))) if error.size else dict(mae=None,rmse=None)
        for name,p in [('FULL',full),('SPIKE_ARM',forecast)]:
            err=p-truth;metrics[name]=dict(overall=measure(err),near=measure(err[:,:,:4]),h12=measure(err[:,:,-1]),by_state=[dict(state=s,cells=int((states==s).sum()),issue_dates=len(np.unique(np.broadcast_to(dates[:,None,None],states.shape)[states==s])),**measure(err[states==s])) for s in range(6)],by_horizon=[measure(err[:,:,h]) for h in range(12)])
        support=[]
        for day in np.unique(dates[oo]):
            ix=dates[oo]==day;ss=states[oo[ix],nn[ix]];ferr=full[oo[ix],nn[ix]]-truth[oo[ix],nn[ix]];serr=forecast[oo[ix],nn[ix]]-truth[oo[ix],nn[ix]]
            support.append(dict(day=int(day),pairs=int(ix.sum()),states=[int((ss==s).sum()) for s in [3,4,5]],FULL_better_cells=int((abs(ferr)<abs(serr)-1e-10).sum()),SPECIALIST_better_cells=int((abs(serr)<abs(ferr)-1e-10).sum())))
        for p,h in bindings.items():assert gate.sha(p)==h,p
        write(HERE/'RESULT.json',dict(at=gate.now(),status='single_prefix_out_of_time_expert_library_scored_pending_audit',seed=SEED,origins=n,dates=len(np.unique(dates)),nodes=30,horizons=12,selected_epoch=selected['epoch'],metrics=metrics,extreme_pairs=len(oo),extreme_dates=len(np.unique(dates[oo])),support_by_day=support,fit_target_cutoff='2024-05-30',selection_freeze='2024-06-30T23:55Z',forecast_period='2024-H2',scope='Internal chronological cross-fit development pilot, not new independent confirmation; original main FULL/V7 results unchanged.',new_router_fitted=False,new_independent_test_targets_read=False,artifacts={str(p):gate.sha(p) for p in [ART/'PREDICTIONS.npz',ART/'EXPERT_ERROR_LIBRARY.npz',context_path]},freeze_sha256=gate.sha(HERE/'FINAL_FREEZE.json')))
        print('Chronological expert library scored',flush=True)
if __name__=='__main__':main()
