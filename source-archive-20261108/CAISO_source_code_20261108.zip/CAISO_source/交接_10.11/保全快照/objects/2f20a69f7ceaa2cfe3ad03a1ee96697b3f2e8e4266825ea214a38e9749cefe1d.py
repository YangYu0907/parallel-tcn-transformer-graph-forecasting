"""Finite native-transport pilot; original files and scientific protocol unchanged."""
import sys,os,time,json,hashlib,threading,subprocess,traceback,importlib.util
from pathlib import Path
from datetime import datetime,timezone
from email.utils import parsedate_to_datetime
from concurrent.futures import ThreadPoolExecutor,as_completed
N=Path(__file__).resolve().parent
sys.path.insert(0,str(N.parent))
import support as s
spec=importlib.util.spec_from_file_location('weather_decode',N.parent/'manager.py')
m=importlib.util.module_from_spec(spec);spec.loader.exec_module(m)
LOCK=threading.Lock();CANCEL=threading.Event();COUNTS={'reserved_bytes':0,'reserved_requests':0}

def write(name,data):s.write(N.name+'/'+name,data)
def check(q):
    s.guard()
    if (N/'STOP_REQUESTED.json').exists() or CANCEL.is_set():raise InterruptedError('Native transport stop')
    if time.time()>q['deadline_unix']:raise TimeoutError('Finite native transport pilot deadline')
def quote(v):return '"'+str(v).replace('\\','/').replace('"','\\"')+'"'

def batch(specs,q,folder,label):
    if not specs:return
    check(q);folder.mkdir(parents=True,exist_ok=True)
    with LOCK:
        COUNTS['reserved_bytes']+=sum(x['size'] for x in specs)
        COUNTS['reserved_requests']+=len(specs)
        assert COUNTS['reserved_bytes']<=q['maximum_bytes'] and COUNTS['reserved_requests']<=q['maximum_requests']
    text=[]
    for k,x in enumerate(specs):
        if k:text.append('next')
        text+=['silent','show-error','fail','max-time = 20','connect-timeout = 5',
            'max-filesize = '+str(x['size']),'url = '+quote(m.transport.URL+x['key']),
            'header = '+quote('If-Match: '+x['source']['etag']),
            'output = '+quote(x['path']),'dump-header = '+quote(str(x['path'])+'.headers')]
        if x.get('range'):text.append('range = '+quote(str(x['range'][0])+'-'+str(x['range'][1])))
    config=folder/(label+'.curl');config.write_text('\n'.join(text)+'\n',encoding='utf-8')
    with (folder/(label+'.stderr')).open('wb') as err:
        process=subprocess.Popen(['curl.exe','--fail-early','--config',str(config)],stdout=subprocess.DEVNULL,stderr=err)
        try:
            while process.poll() is None:
                check(q);time.sleep(.2)
            assert process.returncode==0,('curl batch failed',label,process.returncode)
        finally:
            if process.poll() is None:process.terminate();process.wait(timeout=5)
    for x in specs:
        raw=Path(str(x['path'])+'.headers').read_text(encoding='utf-8',errors='replace');headers={};status=None
        for line in raw.splitlines():
            if line.startswith('HTTP/'):status=int(line.split()[1]);headers={}
            elif ':' in line:
                k,v=line.split(':',1);headers[k.lower()]=v.strip()
        assert status==(206 if x.get('range') else 200)
        assert headers['etag']==x['source']['etag']
        assert parsedate_to_datetime(headers['last-modified']).timestamp()==x['source']['last_modified_seconds']
        assert int(headers['content-length'])==x['size']==x['path'].stat().st_size
        if x.get('range'):
            left,right=x['range'];assert headers['content-range']==f'bytes {left}-{right}/{x["source"]["bytes"]}'
        x['headers']=headers

def fetch(choice,objects,p,q):
    check(q);beg=time.monotonic();cycle=choice['cycle'];dt=datetime.fromtimestamp(cycle,timezone.utc)
    folder=N/'work'/str(cycle);folder.mkdir(parents=True,exist_ok=True);idx_specs=[];keys={};receipts=[];messages=[]
    for lead in [3,4,5]:
        key=dt.strftime('hrrr.%Y%m%d/conus/hrrr.t%Hz.wrfsfcf')+f'{lead:02d}.grib2';keys[lead]=key
        assert max(objects[key]['last_modified_seconds'],objects[key+'.idx']['last_modified_seconds'])<=choice['minimum_qualified_cutoff']
        out=folder/f'{lead}.idx';cached=s.N/'indices'/f'{cycle}_{lead}.idx'
        data=cached.read_bytes() if cached.exists() else m.retained_index(key,objects[key+'.idx'])[0]
        if data is not None:
            assert len(data)==objects[key+'.idx']['bytes'] and hashlib.md5(data).hexdigest()==objects[key+'.idx']['etag'].strip('"')
            out.write_bytes(data)
        else:idx_specs.append(dict(key=key+'.idx',path=out,source=objects[key+'.idx'],size=objects[key+'.idx']['bytes']))
    batch(idx_specs,q,folder,'indices');specs=[];parts_all={}
    for lead,key in keys.items():
        path=folder/f'{lead}.idx';data=path.read_bytes();idx=objects[key+'.idx']
        assert len(data)==idx['bytes'] and hashlib.md5(data).hexdigest()==idx['etag'].strip('"')
        receipts.append(dict(key=key+'.idx',local=str(path.relative_to(s.N)),sha256=s.sha(path),source=idx))
        lines=[line.split(':') for line in data.decode('ascii').splitlines() if line];parts=[]
        for vi,(var,level,*_) in enumerate(m.FIELDS):
            found=[i for i,line in enumerate(lines) if line[3:5]==[var,level]];assert len(found)==1
            j=found[0];left=int(lines[j][1]);right=int(lines[j+1][1])-1 if j+1<len(lines) else objects[key]['bytes']-1
            assert 0<right-left<8*1024**2
            parts.append(dict(vi=vi,left=left,right=right,lead=lead,key=key))
        groups=[]
        for part in sorted(parts,key=lambda x:x['left']):
            if groups and groups[-1][-1]['right']+1==part['left']:groups[-1].append(part)
            else:groups.append([part])
        for group in groups:
            left,right=group[0]['left'],group[-1]['right'];path=folder/f'{lead}_{left}.grib2'
            specs.append(dict(key=key,path=path,source=objects[key],size=right-left+1,range=[left,right],parts=group))
    batch(specs,q,folder,'fields')
    for x in specs:
        data=x['path'].read_bytes();left,right=x['range']
        receipts.append(dict(key=x['key'],range=x['range'],bytes=len(data),local=str(x['path'].relative_to(s.N)),sha256=hashlib.sha256(data).hexdigest(),source=x['source'],native_response_headers=x['headers']))
        for part in x['parts']:messages.append(dict(part,blob=data[part['left']-left:part['right']-left+1]))
    s.write('download_receipts/'+str(cycle)+'.json',dict(choice=choice,receipts=receipts,complete=True,transport='curl8.16batched'))
    return dict(choice=choice,receipts=receipts,messages=messages,audit_values=True,fetch_seconds=time.monotonic()-beg)

def main():
    p=s.verify();q=s.read(N/'PROTOCOL.json');assert s.sha(__file__)==q['script_sha256']
    assert s.sha(s.N/'PROTOCOL.json')==q['parent_protocol_sha256']
    write('STATUS.json',dict(at=s.now(),pid=os.getpid(),event='awaiting_exit_monitor_binding'))
    wait_start=time.monotonic()
    while not (N/'START_READY.json').exists():
        if time.monotonic()-wait_start>45:raise TimeoutError('Missing exit monitor')
        time.sleep(.2)
    import psutil
    ready=s.read(N/'START_READY.json');assert ready['manager_pid']==os.getpid() and psutil.pid_exists(ready['exit_monitor_pid'])
    objects=s.read(m.I/'AUDITED_OBJECT_INDEX.json')['objects'];rows=[];geo=None;beg=time.monotonic()
    with s.base.numeric('Eight-cycle native weather transport validation; no model fits'):
        check(q)
        existing=sum(f.stat().st_size for f in (s.N/'raw').glob('*.grib2'))
        assert existing+q['maximum_bytes']<=p['maximum_retained_raw_bytes']
        assert all(not (s.N/'cycles'/f'{c["cycle"]}.json').exists() for c in q['choices'])
        write('STATUS.json',dict(at=s.now(),pid=os.getpid(),event='native_transport_pilot_running',model_fits=0))
        with ThreadPoolExecutor(max_workers=4) as pool:
            futures=[pool.submit(fetch,c,objects,p,q) for c in q['choices']]
            try:
                for future in as_completed(futures):
                    d=future.result();t=time.monotonic();record,geo=m.decode(d,p,geo)
                    rows.append(dict(cycle=d['choice']['cycle'],fetch_seconds=d['fetch_seconds'],decode_seconds=time.monotonic()-t,cycle_sha256=s.sha(s.N/'cycles'/f'{d["choice"]["cycle"]}.json'),bytes=sum(x.get('bytes',0) for x in d['receipts'])))
                    write('PROGRESS.json',dict(at=s.now(),completed_cycles=len(rows),rows=rows,counters=dict(COUNTS),model_fits=0))
            except BaseException:
                CANCEL.set()
                for f in futures:f.cancel()
                raise
        s.base.verify_protected()
    elapsed=time.monotonic()-beg;total=s.read(s.N/'SELECTION.json')['cycles'];complete=len(list((s.N/'cycles').glob('*.json')))
    projected=(total-complete)*elapsed/len(rows)*q['projection_safety_factor'];remaining=q['parent_deadline_unix']-time.time()
    write('RESULT.json',dict(at=s.now(),rows=rows,elapsed_seconds=elapsed,counters=dict(COUNTS),remaining_source_seconds_with_margin=projected,remaining_parent_budget_seconds=remaining,model_reserve_seconds=q['model_reserve_seconds'],cost_gate_passed=projected+q['model_reserve_seconds']<=remaining,model_fits=0,new_test_targets_read=False,V7_replaced=False,automatic_extraction_resume=False,scope='Small source pilot throughput only; same source/decoder and all selected variables; no forecast accuracy inference'))
    eid=s.emit('needs_analysis',N/'RESULT.json');write('STATUS.json',dict(at=s.now(),pid=os.getpid(),event='finite_mechanism_queue_completed',event_id=eid,model_fits=0))

if __name__=='__main__':
    try:main()
    except BaseException as e:
        CANCEL.set();write('FAILURE.json',dict(at=s.now(),error=repr(e),traceback=traceback.format_exc(),counters=dict(COUNTS),automatic_retry=False,model_fits=0))
        eid=s.emit('blocking_failure',N/'FAILURE.json');write('STATUS.json',dict(at=s.now(),pid=os.getpid(),event='step_stopped_or_failed',event_id=eid))
