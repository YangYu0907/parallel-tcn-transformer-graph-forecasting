"""Synthetic equivalence tests; no research labels, no real model fits."""
import os
for k in ['OMP_NUM_THREADS','MKL_NUM_THREADS','OPENBLAS_NUM_THREADS','NUMEXPR_NUM_THREADS']:os.environ[k]='1'
from pathlib import Path
import sys,json,pickle,time
W=Path(__file__).resolve().parent;sys.path.insert(0,str(W.parent))
import support as s
import numpy as np
from sklearn.ensemble import HistGradientBoostingClassifier
from threadpoolctl import threadpool_limits
import disk_hgb
def main():
    records=[];rng=np.random.default_rng(1876);start=time.monotonic()
    with s.base.numeric('Synthetic disk-HGB equivalence QA; no research fitting'),threadpool_limits(1):
        for n in [4000,200101]:
            x=rng.normal(size=(n,29)).astype('float32');x[:,24]=rng.integers(0,30,size=n)
            y=(x[:,0]+.3*x[:,1]>1).astype(int)+(x[:,2]<-1).astype(int)
            path=W/f'qa_{n}.npy';mm=np.lib.format.open_memmap(path,mode='w+',dtype=np.float32,shape=x.shape,fortran_order=True);mm[:]=x;mm.flush();mm._mmap.close()
            p=dict(s.read(s.N/'PROTOCOL.json')['learner']);p['max_iter']=3
            a=HistGradientBoostingClassifier(**p);b=disk_hgb.DiskHGB(**p)
            disk_hgb.TICK=lambda **kw:s.guard()
            for trees in [3,5]:
                a.set_params(max_iter=trees);b.set_params(max_iter=trees)
                a.fit(x,y);mm=np.load(path,mmap_mode='r');b.fit(mm,y);mm._mmap.close()
                assert all(np.array_equal(u,v) for u,v in zip(a._bin_mapper.bin_thresholds_,b._bin_mapper.bin_thresholds_))
                pa=a.predict_proba(x[:1000]);pb=b.predict_proba(x[:1000]);assert np.array_equal(pa,pb)
                assert all(np.array_equal(ta.nodes,tb.nodes) for ra,rb in zip(a._predictors,b._predictors) for ta,tb in zip(ra,rb))
                restored=pickle.loads(pickle.dumps(b));assert np.array_equal(restored.predict_proba(x[:1000]),pa)
                records.append(dict(rows=n,trees=trees,max_prediction_difference=float(abs(pa-pb).max()),thresholds_and_tree_nodes_exact=True))
    result=dict(at=s.now(),passed=True,checks=records,seconds=time.monotonic()-start,real_model_fits=0,new_test_targets_read=False,scope='Exact stock-sklearn comparison including bin subsampling, categorical reorder, warm start and serialization; storage engineering only')
    (W/'ENGINEERING_QA.json').write_text(json.dumps(result,indent=2),encoding='utf-8');print(json.dumps(result))
if __name__=='__main__':main()
