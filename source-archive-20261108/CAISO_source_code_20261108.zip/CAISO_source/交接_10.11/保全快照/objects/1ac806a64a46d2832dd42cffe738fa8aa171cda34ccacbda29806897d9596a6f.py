from common import *
import psutil
def main():
    event=read(B/'event_driven_automation/inbox/wi_e761f50ca8a2adf6b32cd811.json')
    assert sha(event['evidence_path'])==event['evidence_sha256']
    repair=read(E/'REPAIR.json');assert event['event_id']==repair['failure_event_id']
    launch=read(E/'LAUNCH.json');proc=psutil.Process(launch['manager_pid'])
    assert abs(proc.create_time()-(launch['manager_start_utc_ticks']-621355968000000000)/1e7)<.01
    receipt=read(launch['receipt']);assert receipt['manager_pid']==proc.pid and receipt['watcher_pid']==launch['exit_monitor_pid']
    assert psutil.pid_exists(launch['exit_monitor_pid'])
    assert 'watch.ps1' in ' '.join(psutil.Process(15020).cmdline())
    protected=read(Z/'PROTECTED_FILES.json');assert all(sha(k)==v for k,v in protected.items())
    progress=read(E/'PROGRESS.json')
    record=dict(at=now(),delivery_event_id='8f68d9fc59138b4c4f9670b0a73eca15bf5c1761e9ae0c7c419f1717c3dd3148',payload_event_id=event['event_id'],status='delayed_notification_of_repaired_failure',evidence_hash_verified=True,new_training_started=False,active_manager=proc.pid,bound_exit_monitor=launch['exit_monitor_pid'],local_listener=15020,progress=progress,protected_verified=len(protected),new_results_audited=False,independent_person_review=False,periodic_model_wakeups=False)
    write(E/'EVENT_REVIEW.json',record)
    h=read(B/'HANDOFF.json');h['latest_smooth_failure_delivery']=record;h['smooth_risk_20261011']['latest_progress']=progress
    path=B/'HANDOFF.json';temp=path.with_name('.h'+os.urandom(4).hex());temp.write_text(json.dumps(h,ensure_ascii=False,indent=2),encoding='utf-8');os.replace(temp,path)
    print(json.dumps(record,ensure_ascii=False))
if __name__=='__main__':main()
