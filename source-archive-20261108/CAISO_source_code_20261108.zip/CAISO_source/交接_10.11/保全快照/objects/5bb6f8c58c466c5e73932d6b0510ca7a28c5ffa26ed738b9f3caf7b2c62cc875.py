"""Single information ablation: same HGB, old price features +/- six load fields."""
from pathlib import Path
import sys,os,time
HERE=Path(__file__).resolve().parent
R=HERE.parent
sys.path.insert(0,str(R/'event_memory_gate_20261004'))
import engine as previous
old=previous.old
import numpy as np
REVIEW=R/'load_source_review_20261004'
EM=R/'event_memory_gate_20261004'
NAMES=['RTD_GW','DAM_minus_RTD_GW','RTD_change_60min_GW','DAM_change_60min_GW','RTD_publication_age_capped','DAM_publication_age_capped']

def checked(launch=False):
    if any((HERE/p).exists() for p in ['STOP_REQUESTED','STOP_REQUESTED.json']):raise InterruptedError('Local stop')
    return previous.checked(launch)

def verify():
    previous.verify()
    p=old.read(HERE/'PROTOCOL.json')
    for name,h in p['bindings'].items():assert old.sha(name)==h,name
    return p

def tick(**d):
    checked();seconds=time.monotonic()-T0
    if seconds>1800:raise TimeoutError('Fixed 30-minute probe budget')
    old.write(HERE/'PROGRESS.json',dict(at=old.now(),pid=os.getpid(),seconds=seconds,**d))

def inputs():
    m=old.read(old.B/'phase_sampling_support_v3_20260923/dataset/ADDITIVE/manifest.json')
    result=[]
    for n in ['raw_external.npy','forecast_publications_seconds.npy','timestamps_seconds.npy']:
        p=old.B/m['artifacts'][n]['path'];assert old.sha(p)==m['artifacts'][n]['sha256']
        result.append(np.load(p,mmap_mode='r'))
    return (*result,np.asarray(m['age_caps_minutes']))

def load_features(ext,pub,times,caps,origins):
    o=np.asarray(origins,dtype=np.int64);cutoff=times[o-1]
    p=pub[o-1]
    if np.any(p<=0) or np.any(p>cutoff[:,None]):raise ValueError('Unpublished load feature')
    x=np.asarray(ext[o-1,:2],float);lag=np.asarray(ext[o-13,:2],float)
    if not (np.isfinite(x).all() and np.isfinite(lag).all()):raise ValueError('Missing load')
    age=np.clip((cutoff[:,None]-p)/60/caps,0,1)
    return np.column_stack([x[:,0]/1000,(x[:,1]-x[:,0])/1000,(x[:,0]-lag[:,0])/1000,(x[:,1]-lag[:,1])/1000,age]).astype('float32')

def fit(folder,X,y):
    from sklearn.ensemble import HistGradientBoostingClassifier
    folder.mkdir(parents=True);path=folder/'model.pkl'
    model=HistGradientBoostingClassifier(max_iter=20,max_leaf_nodes=7,min_samples_leaf=50,
        learning_rate=.05,l2_regularization=1,early_stopping=False,warm_start=True,random_state=20260813)
    for it in [20,40,60,80]:
        tick(stage='fit',arm=folder.name,iteration=it);model.set_params(max_iter=it);model.fit(X,y)
        old.dump(path,dict(model=model,protocol=old.sha(HERE/'PROTOCOL.json'),rows=len(y),columns=X.shape[1]))
    old.write(folder/'FROZEN.json',dict(at=old.now(),sha256=old.sha(path),iterations=80,columns=X.shape[1]))
    return model

def main():
    global T0
    T0=time.monotonic();verify();checked(True);previous.tick=tick
    with old.numeric('Fixed same-estimator price versus load-information probe'):
        raw,times,_,_=old.parent.arrays();ex,pub,tt,caps=inputs();assert np.array_equal(tt,times)
        rows=[]
        for fold in [1,2]:
            source=EM/f'probe{fold}';folder=HERE/f'probe{fold}';folder.mkdir()
            z=np.load(source/'ORIGINS.npz');st=old.read(source/'STATS.json')
            tr=previous.make_rows(raw,times,z['train'],st)
            with np.load(source/'REPLAY.npz') as f:ev={k:f[k] for k in f.files}
            tx=previous.control_X(tr['X']);vx=previous.control_X(ev['X'])
            te=load_features(ex,pub,tt,caps,tr['ids'][:,0]);ve=load_features(ex,pub,tt,caps,ev['ids'][:,0])
            models={};pred={};train_metrics={}
            for name in ['PRICE','PRICE_LOAD']:
                X=tx if name=='PRICE' else np.column_stack([tx,te]);V=vx if name=='PRICE' else np.column_stack([vx,ve])
                model=fit(folder/name,X,tr['y']);models[name]=model;pred[name]=model.predict_proba(V)[:,1]
                train_metrics[name]=previous.scores(model.predict_proba(X)[:,1],tr['y'],tr['days'])
            # Same algorithm/data must replay the earlier control exactly.
            delta=float(abs(pred['PRICE']-ev['control']).max());assert delta<1e-12
            scores={name:previous.scores(p,ev['y'],ev['days']) for name,p in pred.items()}
            passed=previous.score_pass(scores['PRICE_LOAD'],scores['PRICE'])
            old.save(folder/'REPLAY.npz',X=vx,extra=ve,y=ev['y'],days=ev['days'],ids=ev['ids'],**pred)
            row=dict(fold=fold,scores=scores,train_scores=train_metrics,passed=passed,old_control_replay_max_abs=delta)
            old.write(folder/'RESULT.json',row);rows.append(row)
        passed=all(r['passed'] for r in rows)
        old.write(HERE/'RESULT.json',dict(at=old.now(),stage='fixed_information_probe_complete',probes=rows,
            screen_passed=passed,new_fits=4,full_prefix_fits=0,numeric_seconds=time.monotonic()-T0,
            V7_replaced=False,new_test_targets_read=False,new_price_error_results=False,
            meaning='Exploratory incremental load information only; not matched architectural superiority or independent confirmation',
            next='If passed, separately freeze matched full-prefix information controls; if failed, close this input-only candidate. No automatic retries.'))
    assert old.parent.verify_protected()==18
    print('Four fixed fits completed. Probability screen passed:',passed)

if __name__=='__main__':main()
