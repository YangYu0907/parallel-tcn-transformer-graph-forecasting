"""Binary first-UP trial: all labels retained naturally, no DOWN learner."""
import gc,pickle,time
import numpy as np
from scipy.optimize import minimize_scalar
from sklearn.metrics import average_precision_score
from features import calendar
import disk_hgb
from common import *
N=Z.parent/'short_context_support_trial_20261005'
def temper(prob,t):
 z=np.log(np.clip(prob,1e-12,1))/t;z-=z.max(axis=1,keepdims=True);a=np.exp(z);return a/a.sum(axis=1,keepdims=True)
def metrics(y,q,on):
 pos=y==1;tp=int(np.sum(pos&on));fp=int(np.sum(~pos&on));q=np.clip(q,1e-12,1-1e-12)
 return dict(brier=float(np.mean((q-pos)**2)),logloss=float(np.mean(np.where(pos,-np.log(q),-np.log1p(-q)))),
  precision=tp/(tp+fp) if tp+fp else 0.,recall=tp/int(pos.sum()) if pos.any() else 0.,TP=tp,FP=fp,
  events=int(pos.sum()),FPR=fp/int((~pos).sum()),AP=float(average_precision_score(pos,q)) if pos.any() else None,
  down_cases=int(np.sum(y==2)),false_UP_on_DOWN=int(np.sum(on&(y==2))))
def model_save(path,model):
 tmp=path.with_name('.m'+os.urandom(4).hex())
 with tmp.open('wb') as f:pickle.dump(model,f,protocol=5)
 os.replace(tmp,path)
def run(p,tick):
 assert read(E/'SOURCE_AUDIT.json')['passed']
 with np.load(E/'INDICES.npz') as a:arr={k:a[k] for k in a.files}
 y=arr['y'];tm=arr['time'];node=arr['node'];results={};completed=0;epieces={arm:[] for arm in p['arms']};apieces={arm:[] for arm in p['arms']};idx=[]
 for fold in p['folds']:
  name=fold['name'];fit=arr[name+'_fit'];cal=arr[name+'_cal'];ev=arr[name+'_eval'];idx.append(ev);results[name]={}
  for arm in p['arms']:
   cell=E/name/arm;cell.mkdir(parents=True,exist_ok=True);marker=cell/'COMPLETE.json'
   def ct(**kw):tick(fold=name,arm=arm,completed_fits=completed,**kw)
   if marker.exists():
    rec=read(marker);assert all(sha(k)==h for k,h in rec['bindings'].items());results[name][arm]=rec['result']
    with np.load(cell/'PREDICTIONS.npz') as a:epieces[arm].append(a['evaluation']);apieces[arm].append(a['alarm'])
    completed+=1;continue
   started=time.monotonic()
   def design(ii):
    x=np.load(N/'features.npy',mmap_mode='r');hist=np.asarray(x[arr['row'][ii]],np.float32);x._mmap.close();pieces=[hist,calendar(tm[ii]).astype(np.float32)]
    if arm.startswith('COARSE'):
     x=np.load(Z/'weather_COARSE.npy',mmap_mode='r');pieces.append(np.asarray(x[arr['weather_row'][ii]],np.float32));x._mmap.close()
    if arm.endswith('_DAM'):
     x=np.load(E/'dam.npy',mmap_mode='r');pieces.append(np.asarray(x[ii],np.float32));x._mmap.close()
    a=np.concatenate(pieces,axis=1);assert a.shape[1]==p['features'][arm] and np.isfinite(a).all();return a
   target=cell/'design.npy';dm=cell/'DESIGN.json'
   if dm.exists():assert sha(target)==read(dm)['sha256']
   else:
    mm=np.lib.format.open_memmap(target,mode='w+',dtype=np.float32,shape=(len(fit),p['features'][arm]),fortran_order=True);mm._mmap.close()
    for begin in range(0,len(fit),8192):
     a=design(fit[begin:begin+8192]);mm=np.load(target,mmap_mode='r+');mm[begin:begin+len(a)]=a;mm.flush();mm._mmap.close();del a
     if begin%65536==0:ct(stage='binary_design',rows=begin,total=len(fit))
    write(dm,dict(at=now(),sha256=sha(target)))
   modelpath=cell/'model.pkl';fm=cell/'FIT.json'
   if modelpath.exists():
    assert fm.exists() and sha(modelpath)==read(fm)['sha256']
    with modelpath.open('rb') as f:model=pickle.load(f)
   else:model=disk_hgb.DiskHGB(**p['learner'])
   disk_hgb.TICK=ct
   for it in p['iterations']:
    if getattr(model,'n_iter_',0)>=it:continue
    ct(stage='binary_fit',iterations=it,fit_pairs=len(fit));mm=np.load(target,mmap_mode='r');model.set_params(max_iter=it);model.fit(mm,(y[fit]==1).astype(np.int8));mm._mmap.close()
    model_save(modelpath,model);write(fm,dict(at=now(),n_iter=it,sha256=sha(modelpath)))
   assert model.classes_.tolist()==[0,1] and model.n_iter_==80
   def predict(ii):
    out=np.empty((len(ii),2))
    for begin in range(0,len(ii),8192):
     sub=ii[begin:begin+8192];out[begin:begin+len(sub)]=model.predict_proba(design(sub))
     if begin%65536==0:ct(stage='binary_predict',rows=begin,total=len(ii))
    return out
   cp0=predict(cal);truth=y[cal]==1
   temperature=float(minimize_scalar(lambda t:float(-np.log(np.clip(temper(cp0,t)[np.arange(len(cal)),truth.astype(int)],1e-12,1)).mean()),bounds=(.5,2),method='bounded').x)
   cp=temper(cp0,temperature)[:,1];threshold=float(np.quantile(cp[~truth],.99,method='higher'))
   write(cell/'CAL_FROZEN.json',dict(at=now(),temperature=temperature,threshold=threshold,cal_freeze=fold['cal_freeze'],model_sha256=sha(modelpath),method='Binary NLL temperature;negative99th percentile;strict greater'))
   ep=temper(predict(ev),temperature)[:,1];on=ep>threshold
   result=dict(temperature=temperature,threshold=threshold,fit_pairs=len(fit),cal_pairs=len(cal),eval_pairs=len(ev),metrics=metrics(y[ev],ep,on))
   save(cell/'PREDICTIONS.npz',evaluation=ep,alarm=on,calibration=cp,calibration_raw=cp0,y=y[ev],time=tm[ev],node=node[ev],cal_y=y[cal],cal_time=tm[cal])
   write(marker,dict(at=now(),result=result,seconds=time.monotonic()-started,bindings={str(v):sha(v) for v in [modelpath,cell/'PREDICTIONS.npz',cell/'CAL_FROZEN.json']}))
   results[name][arm]=result;epieces[arm].append(ep);apieces[arm].append(on);completed+=1
   del model,cp0,cp;gc.collect();ct(stage='binary_cell_complete',cell_seconds=time.monotonic()-started)
 indices=np.concatenate(idx);assert np.all(np.diff(indices)>0)
 save(E/'PREDICTIONS.npz',y=y[indices],time=tm[indices],node=node[indices],**{a:np.concatenate(v) for a,v in epieces.items()},**{a+'_alarm':np.concatenate(v) for a,v in apieces.items()})
 write(E/'RESULT_PENDING_AUDIT.json',dict(at=now(),scope=p['scope'],fits=completed,results=results,V7_replaced=False,point_price_integration=False,new_test_targets_read=False,downward_problem_solved=False))
 assert completed==8

