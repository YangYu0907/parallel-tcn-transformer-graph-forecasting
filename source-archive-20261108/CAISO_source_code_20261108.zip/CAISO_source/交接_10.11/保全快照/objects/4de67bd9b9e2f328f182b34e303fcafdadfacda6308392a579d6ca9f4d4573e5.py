"""Resource-guarded exact replay with reusable forecasts and partial resume."""
import argparse, gc, hashlib, sys, time
import gate as g

def origin_hash(a): return hashlib.sha256(a.astype('<i8').tobytes()).hexdigest()
def arrays(path,**values): g.atomic(path,lambda f:np.savez(f,**values))
def metrics(error):
    return dict(mae=float(np.abs(error).mean()),rmse=float(np.sqrt(np.square(error).mean())),
                near_mae=float(np.abs(error[:,:,:4]).mean()),h12_mae=float(np.abs(error[:,:,11]).mean()))
def load_case(c,e,limits):
    if c['variant']=='CHANNEL':
        from model import ChannelFusion
        model=ChannelFusion(c['seed'],limits)
    else:
        from models.factory import build_backbone
        model=build_backbone(c['variant'],c['seed'],limits)
    g.need(g.sha(e['checkpoint'])==e['sha256'],'Checkpoint changed')
    saved=torch.load(e['checkpoint'],map_location='cpu',weights_only=False)
    model.load_state_dict(saved['model'] if c['variant']=='CHANNEL' else saved['state_dict'],strict=True)
    del saved
    model.eval()
    return model

def main(smoke=False):
    global np,torch
    g.verify();protocol=g.read(g.HERE/'PROTOCOL.json')
    with g.exclusive('selection_alignment_smoke' if smoke else 'selection_alignment_replay'):
        np,torch,limiter=g.runtime()
        sys.path.append(str(g.ROOT/'channel_attention_v1_20260927'))
        from compiled_data import CompiledData
        data=CompiledData(str(g.MANIFEST));limits=g.read(data.paths['context_limits.json'])['limits']
        origins=data.origins['june_dense'];hourly=np.searchsorted(origins,data.origins['june'])
        g.need(len(origins)==3397 and len(hourly)==284 and np.array_equal(origins[hourly],data.origins['june']),'Origin mismatch')
        g.need((origins>=210528).all() and (origins+12<=219168).all(),'Outside June development')
        order=np.r_[hourly,np.flatnonzero(~np.isin(np.arange(3397),hourly))]
        panel=dict(role='development',name='June3397',origins_sha256=origin_hash(origins),cells=3397*30*12)
        with np.load(protocol['cases'][0]['reference'],allow_pickle=False) as z:
            truth=z['truth'].copy();codes=z['codes'].copy()
        for c in protocol['cases']:
            with np.load(c['reference'],allow_pickle=False) as z:
                g.need(np.array_equal(z['origins'],origins) and np.array_equal(z['truth'],truth) and np.array_equal(z['codes'],codes),'Common panel mismatch')
        if smoke:
            checks=[];started=time.monotonic()
            for c in protocol['cases']:
                e=next(e for e in c['epochs'] if e['epoch']==c['selected_epoch'])
                model=load_case(c,e,limits)
                with np.load(c['reference'],allow_pickle=False) as z: reference=z['prediction'].copy()
                with torch.no_grad():
                    for start in (0,284):
                        g.guard();ix=order[start:start+4];x,y=data.batch('june_dense',ix)
                        raw=model(torch.from_numpy(x))['prediction'].numpy().astype(np.float64)*data.scale[None,:,None]+data.center[None,:,None]
                        g.need(np.array_equal(raw,reference[ix]),'Selected model exact replay mismatch')
                        g.need(np.array_equal(y.astype(np.float64)*data.scale[None,:,None]+data.center[None,:,None],truth[ix]),'Truth binding mismatch')
                checks.append(dict(case=c['id'],origins_replayed=8,exact=True))
                del model;gc.collect()
            c=protocol['cases'][0];model=load_case(c,c['epochs'][0],limits)
            started=time.monotonic()
            with torch.no_grad():
                for start in range(0,64,4):
                    g.guard();x,y=data.batch('june_dense',order[start:start+4]);model(torch.from_numpy(x))
            seconds=time.monotonic()-started
            g.write(g.HERE/'SMOKE_QA.json',dict(status='passed',at=g.now(),checks=checks,
                timed_origins=64,seconds=seconds,approximate_99_full_replays_hours=seconds/64*3397*99/3600,
                panel=panel,resource=g.guard(),optimizer_updates=0,new_test_targets_read=False))
            print('QA passed; 64-origin seconds:',seconds,flush=True);return
        g.need(g.read(g.HERE/'SMOKE_QA.json')['status']=='passed','Smoke not passed')
        if not (g.HERE/'PANEL.npz').exists():
            arrays(g.HERE/'PANEL.npz',origins=origins,truth=truth,codes=codes,scale=data.scale,center=data.center,hourly=hourly)
            g.write(g.HERE/'PANEL.json',dict(panel=panel,sha256=g.sha(g.HERE/'PANEL.npz')))
        else:g.need(g.sha(g.HERE/'PANEL.npz')==g.read(g.HERE/'PANEL.json')['sha256'],'Saved panel changed')
        finished=0;started=time.monotonic()
        for c in protocol['cases']:
            # Reverse epochs improves usefulness of early progress; final choice always sorts by epoch.
            for e in sorted(c['epochs'],key=lambda e:-e['epoch']):
                key=c['id']+f"_e{e['epoch']:02d}";root=g.HERE/'forecasts'/key;receipt=root.with_suffix('.json')
                if receipt.exists():
                    r=g.read(receipt);g.need(r['checkpoint_sha256']==e['sha256'] and r['panel']==panel and g.sha(r['forecast'])==r['forecast_sha256'],'Completed replay changed')
                    finished+=1;continue
                g.guard();epoch_started=time.monotonic()
                if e['epoch']==c['selected_epoch']:
                    with np.load(c['reference'],allow_pickle=False) as z: raw=z['prediction'].copy()
                    out=c['reference'];fmt='raw';elapsed=0.
                else:
                    model=load_case(c,e,limits)
                    pred=np.full((3397,30,12),np.nan,np.float32);offset=0
                    partial=root.with_suffix('.partial.npz');part_receipt=root.with_suffix('.partial.json')
                    if part_receipt.exists():
                        pr=g.read(part_receipt)
                        g.need(pr['checkpoint_sha256']==e['sha256'] and pr['seal_sha256']==g.sha(g.SEAL) and pr['panel']==panel and g.sha(partial)==pr['sha256'],'Partial replay changed')
                        with np.load(partial,allow_pickle=False) as z:pred=z['prediction_scaled'].copy()
                        offset=pr['offset'];g.need(offset%4==0 or offset==3397,'Invalid partial cursor')
                        g.need(np.isfinite(pred[order[:offset]]).all(),'Incomplete partial replay')
                    state={k:v.clone() for k,v in model.state_dict().items()};rng=torch.get_rng_state().clone()
                    try:
                        with torch.no_grad():
                            for start in range(offset,3397,4):
                                g.guard();ix=order[start:start+4];x,y=data.batch('june_dense',ix)
                                pred[ix]=model(torch.from_numpy(x))['prediction'].numpy()
                                target=y.astype(np.float64)*data.scale[None,:,None]+data.center[None,:,None]
                                g.need(np.array_equal(target,truth[ix]),'Input/target origin mismatch')
                                offset=min(start+4,3397)
                                if offset%256==0 or offset==3397:
                                    arrays(partial,prediction_scaled=pred)
                                    g.write(part_receipt,dict(offset=offset,panel=panel,checkpoint_sha256=e['sha256'],seal_sha256=g.sha(g.SEAL),sha256=g.sha(partial)))
                                    g.write(g.HERE/'progress.json',dict(at=g.now(),case=c['id'],epoch=e['epoch'],origins_completed=offset,checkpoints_completed=finished,checkpoints_total=108,elapsed_seconds=time.monotonic()-started))
                    except (MemoryError,InterruptedError):
                        arrays(partial,prediction_scaled=pred)
                        g.write(part_receipt,dict(offset=offset,panel=panel,checkpoint_sha256=e['sha256'],seal_sha256=g.sha(g.SEAL),sha256=g.sha(partial)))
                        raise
                    g.need(torch.equal(rng,torch.get_rng_state()),'Inference changed RNG')
                    g.need(all(torch.equal(v,state[k]) for k,v in model.state_dict().items()),'Inference changed weights')
                    g.need(np.isfinite(pred).all(),'Invalid prediction')
                    out=str(root.with_suffix('.npz'));arrays(out,prediction_scaled=pred)
                    fmt='scaled_float32';raw=pred.astype(np.float64)*data.scale[None,:,None]+data.center[None,:,None]
                    elapsed=time.monotonic()-epoch_started
                    del model,state,pred;gc.collect()
                error=raw-truth;m=metrics(error);hm=metrics(error[hourly])
                g.need(abs(hm['mae']-e['original_hourly_mae'])<1e-6,'Archived epoch June284 MAE did not replay')
                g.write(receipt,dict(at=g.now(),case=c['id'],variant=c['variant'],seed=c['seed'],epoch=e['epoch'],panel=panel,
                    mae=m['mae'],metrics=m,hourly=hm,checkpoint=e['checkpoint'],checkpoint_sha256=e['sha256'],
                    forecast=out,format=fmt,forecast_sha256=g.sha(out),seconds=elapsed,reused=e['epoch']==c['selected_epoch']))
                finished+=1
                print(key,'complete',finished,'/108',flush=True)
        g.verify()
        g.write(g.HERE/'REPLAY_COMPLETE.json',dict(status='complete_pending_numeric_audit',at=g.now(),checkpoints=finished,optimizer_updates=0,new_test_targets_read=False))

if __name__=='__main__':
    p=argparse.ArgumentParser();p.add_argument('--smoke',action='store_true');main(p.parse_args().smoke)
