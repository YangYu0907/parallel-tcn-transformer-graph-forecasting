"""Synthetic-only numerical QA; serialized with live training by the same lock."""
import gate

def main():
    gate.verify()
    with gate.exclusive('supplement_synthetic_numeric_QA'):
        np,cap=gate.runtime()
        from lear_math import fit_path,predict,design
        tests=[];rng=np.random.default_rng(20260926)
        x=np.array([[-1.,-1.],[-1.,1.],[1.,-1.],[1.,1.]])
        y=(2*x[:,0]-x[:,1])[:,None];ratios=[.1,.03,.01,.003,.001]
        fitted,retries=fit_path(x,y,ratios,gate.guard)
        for k,r in enumerate(ratios):
            gate.need(np.allclose(fitted['weights'][0,:,k],[2-2*r,-1+2*r],atol=1e-8),'Orthogonal soft-threshold oracle')
        tests.append('lasso_orthogonal_closed_form')
        x=rng.normal(size=(80,7));y=(x[:,0]*2-.7*x[:,3]+rng.normal(size=80)*.05)[:,None]
        fitted,retries=fit_path(x,y,ratios,gate.guard);pred=predict(x,fitted)
        z=(x-fitted['mean'])/fitted['sd']
        for k in range(5):
            w=fitted['weights'][0,:,k];grad=z.T@(pred[:,0,k]-y[:,0])/len(x);alpha=fitted['alphas'][0,k]
            active=np.abs(w)>1e-8
            gate.need(np.max(np.abs(grad[active]+alpha*np.sign(w[active])))<2e-5,'Active KKT')
            gate.need(not (~active).any() or np.max(np.abs(grad[~active]))<=alpha+2e-5,'Inactive KKT')
        tests.append('lasso_primal_KKT')
        features=np.arange(320*30*29,dtype=float).reshape(320,30,29)/1000
        times=np.arange(320,dtype=np.int64)*300+100000
        pub=np.stack((times-30,times-90),axis=1);orig=np.array([288,300]);n=4
        got=design(features,pub,times,[5,660],orig,n)
        expected=[]
        for o in orig:
            history=[features[t,n,0] for t in range(o-288,o)]
            last=list(features[o-1,n,1:]);last[18]=np.float32(.1);last[19]=np.float32(90/60/660)
            expected.append(history+last+[features[o-1,i,0] for i in range(30) if i!=n])
        gate.need(np.array_equal(got,expected),'Literal feature/dependency mapping');tests.append('literal_345features_age_node_order')
        # Future feature changes cannot affect already issued predictors.
        altered=features.copy();altered[300:]=-999
        gate.need(np.array_equal(design(altered,pub,times,[5,660],orig,n),got),'Future input leak');tests.append('future_rows_invariance')
        gate.write(gate.HERE/'numeric_qa.json',dict(status='passed',at=gate.now(),sources=gate.sources(),tests=tests,synthetic_only=True,market_values_read=False))
        print('Synthetic numerical QA passed')
if __name__=='__main__':main()
