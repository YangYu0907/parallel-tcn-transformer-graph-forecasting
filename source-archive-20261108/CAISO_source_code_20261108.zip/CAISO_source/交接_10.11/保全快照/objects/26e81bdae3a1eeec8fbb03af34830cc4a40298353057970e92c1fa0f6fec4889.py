from pathlib import Path
import sys
HERE=Path(__file__).resolve().parent;ROOT=HERE.parent
sys.path.insert(0,str(ROOT/'context_expert_v1_20260929'))
import gate


def main():
    with gate.exclusive('V21 separate array audit for structural diagnostics'):
        np,lim=gate.runtime(False);res=gate.read(HERE/'STRUCTURE_PROBE.json');p=gate.read(HERE/'STRUCTURE_PROBE_PROTOCOL.json');checks=0
        for path,h in p['bindings'].items():assert gate.sha(path)==h;checks+=1
        for row in res['rows']:
            gate.guard();assert gate.sha(row['arrays'])==row['sha256'];checks+=1
            with np.load(row['arrays'],allow_pickle=False) as z:
                a=z['adjacency'];times=z['timestamps'];w=z['weights'];cos=z['cosine'];ratio=z['weighted_norm_retention'];msg=z['cross_self_message_ratio']
            assert (a>=0).all() and np.allclose(a.sum(-1),1,atol=1e-6);checks+=1
            assert np.allclose(w.sum(-1),1,atol=1e-6) and (w>=0).all();checks+=1
            assert ((cos>=-1-1e-6)&(cos<=1+1e-6)).all();checks+=1
            assert ((ratio>=0)&(ratio<=1+1e-6)).all();checks+=1
            assert np.isfinite(msg).all();checks+=1
            diag=np.diagonal(a,axis1=-2,axis2=-1)
            quantities={'cross_mass_mean':float((1-diag).mean()),'branch_cosine_mean':float(cos.mean()),'weighted_norm_retention_mean':float(ratio.mean()),'cross_to_self_message_norm_mean':float(msg.mean()),'adjacency_temporal_std_mean':float(a.astype(np.float64).std(0).mean())}
            for k,v in quantities.items():
                tolerance=8*np.finfo(a.dtype).eps if k in ('adjacency_temporal_std_mean','cross_mass_mean') else 1e-9
                assert abs(v-row[k])<tolerance,(row['task'],row['seed'],row['mode'],k,v,row[k])
                checks+=1
            maxgap=3600 if row['task']=='CAISO_TRAIN' else 24
            ix=[i for i in range(1,len(times)) if 0<int(times[i])-int(times[i-1])<=maxgap]
            assert len(ix)==row['real_neighbor_pairs'];checks+=1
            if ix:
                actual=sum(float(np.abs(a[i]-a[i-1]).sum()/a.shape[-1]) for i in ix)/len(ix)
                assert abs(actual-row['adjacency_neighbor_l1_mean'])<1e-6;checks+=1
        for path,h in gate.read(HERE/'RETAINED_BASELINE_HASHES.json')['files'].items():assert gate.sha(path)==h;checks+=1
        gate.write(HERE/'STRUCTURE_PROBE_AUDIT.json',dict(at=gate.now(),status='passed',checks=checks,cases=len(res['rows']),result_sha256=gate.sha(HERE/'STRUCTURE_PROBE.json'),scope='Separate array recomputation by same operator; no external-person review; descriptive evidence only',numerical_note='Temporal adjacency std recomputed in float64; comparison to original float32 reduction uses8float32eps absolute tolerance. Constant STATIC arrays had float32 reduction roundoff; no model/result selection changes.',V7_preserved=True,new_test_targets_read=False))
        print('Structural array audit passed',checks)

if __name__=='__main__':main()
