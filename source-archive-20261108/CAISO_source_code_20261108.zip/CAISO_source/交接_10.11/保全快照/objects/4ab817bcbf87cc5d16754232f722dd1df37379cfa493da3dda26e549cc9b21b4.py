"""Fixed forecast-reuse controls; no fitting, threshold search, or new targets."""
from pathlib import Path
import sys
HERE=Path(__file__).resolve().parent
sys.path.insert(0,str(HERE.parent/'context_expert_v1_20260929'))
import gate

def main():
    out=HERE/'mechanisms';gate.need(not (out/'BUILD.json').exists(),'Control build already complete')
    with gate.exclusive('guarded_horizon_matched_mechanism_controls'):
        np,lim=gate.runtime(False);gate.verify()
        parent=gate.HERE/'support_guard_pilot';a=gate.read(parent/'AUDIT.json')
        gate.need(a['result_sha256']==gate.sha(parent/'RESULT.json'),'Parent result binding')
        pairs=['FULL','HORIZON_MIX','STATIC_GUARDED','EQUAL_GUARDED']
        gate.write(out/'PROTOCOL.json',dict(at=gate.now(),script_sha256=gate.sha(__file__),
            candidate='HORIZON_GUARDED',comparisons=pairs,
            purpose='Separate horizon-specific weights and the identical causal support guard',
            scope='Exploratory previously inspected June2646 origins,30nodes,12horizons,3seeds; no independent result claim',
            fixed_rule_sha256=gate.sha(parent/'PROTOCOL.json'),
            controls='Apply the identical saved fallback mask to existing learned STATIC_MIX and existing EQUAL_EXPERT forecasts',
            thresholds_changed=False,training_updates=0,new_test_targets_read=False,
            statistics=dict(unit='UTC date with allnodes,horizons,origins and averaged seed losses kept together',
                 stationary_bootstrap_mean_days=2,replicates=2000,seed=62429,
                 calendar_gaps='Continuations cross only adjacent actual UTCdates; restart after missing dates',
                 confidence='95% percentile interval of weighted relative MAE reduction',
                 p_values='One-sided centered bootstrap approximation; four-comparison Holm family; exploratory only')))
        bindings={}
        for seed in (20260813,20260814,20260815):
            with np.load(parent/f'{seed}.npz') as z:row={k:z[k] for k in z.files}
            mask=row['fallback_mask'][:,:,None]
            row['STATIC_GUARDED']=np.where(mask,row['FULL'],row['STATIC_MIX'])
            row['EQUAL_GUARDED']=np.where(mask,row['FULL'],row['EQUAL_EXPERT'])
            path=out/f'{seed}.npz';gate.atomic(path,lambda f:np.savez(f,**row));bindings[str(path)]=gate.sha(path)
            gate.guard()
        gate.write(out/'BUILD.json',dict(at=gate.now(),status='controls_materialized_pending_audit',bindings=bindings,
            protocol_sha256=gate.sha(out/'PROTOCOL.json'),training_updates=0,new_test_targets_read=False))
        print('Matched protected fixed/equal-weight controls materialized.')

if __name__=='__main__':main()
