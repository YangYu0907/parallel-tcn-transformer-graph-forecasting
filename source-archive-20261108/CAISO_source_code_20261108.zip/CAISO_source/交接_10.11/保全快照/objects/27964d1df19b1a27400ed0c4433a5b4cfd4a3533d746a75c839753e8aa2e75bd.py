"""Separate direct-target/loop-state reconstruction and scalar fsum audit."""
import json
import gate
def main():
    s=gate.verify();p=gate.HERE/'result.json';result=gate.read(p)
    gate.need(result['seal_sha256']==gate.sha(gate.SEAL),'Seal mismatch')
    with gate.exclusive('twenty_case_independent_numeric_audit'):
        np,limiter=gate.runtime();oracle=gate.load_module('scalar_oracle',gate.COMMON/'audit.py')
        m=gate.read(gate.inside(s['dataset_manifest']))
        def load(name):return np.load(gate.inside(m['artifacts'][name]['path']),allow_pickle=False,mmap_mode='r')
        target=load('target_scaled.npy');features=load('features.npy');dense=load('june_origins.npy');reg=load('registered_june_origins.npy')
        scalers=gate.read(gate.inside(m['artifacts']['scalers.json']['path']))
        center=np.asarray(scalers['price_center'],np.float64)[0,:,0];scale=np.asarray(scalers['price_scale'],np.float64)[0,:,0]
        thresholds=np.asarray(gate.read(gate.inside(m['artifacts']['state_thresholds.json']['path']))['thresholds'],np.float64)
        gate.need(target.shape==(219168,30) and (dense>=210528).all() and (dense+12<=219168).all(),'Independent prefix bound')
        truth=np.stack([target[int(o):int(o)+12].T.copy() for o in dense]).astype(np.float64)*scale[None,:,None]+center[None,:,None]
        last=np.array(features[dense-1,:,0],np.float64)*scale+center;state=np.empty(truth.shape,np.uint8)
        for i in range(len(dense)):
            if i%100==0:gate.guard()
            for n in range(30):
                active=abs(float(last[i,n])-float(center[n]))>thresholds[1,n]
                for h in range(12):
                    d=abs(float(truth[i,n,h])-float(center[n]));state[i,n,h]=3*int(active)+int(d>thresholds[0,n])+int(d>thresholds[1,n])
        ids,blocks=oracle.panels_oracle(dense,reg);gate.need(len(blocks)==278,'Independent balanced blocks')
        rows={r['id']:r for r in result['results']};gate.need(set(rows)=={c['id'] for c in s['cases']},'Wrong case set')
        audits=[];prior={r['id']:r for r in gate.read(gate.inside(s['prior_result']))['results']}
        for case in s['cases']:
            gate.guard();orig=np.load(gate.inside(case['origins']),allow_pickle=False);pred=np.load(gate.inside(case['prediction']),allow_pickle=False)
            gate.need(len(set(map(int,orig)))==len(orig),'Duplicate origin')
            expected={};row=rows[case['id']]
            for name,positions in ids.items():
                if case['kind']=='external' and name!='June284':continue
                desired=dense[positions];joined=[]
                for o in desired:
                    found=np.flatnonzero(orig==o);gate.need(len(found)==1,'Independent origin join');joined.append(int(found[0]))
                if name=='June284':gate.need(joined==row['registered_source_indices'],'Recorded join incorrect')
                expected[name]=oracle.oracle_breakdown(pred[joined]-truth[positions],state[positions],desired)
            oracle.compare(row['panels'],expected,case['id'])
            if case['id'] in prior:
                old=prior[case['id']]
                for key in ('mae','rmse','near_h1_4_mae','h12_mae'):
                    gate.need(abs(expected['June284'][key]-old['metrics'][key])<=1e-10,'Independent original12 regression')
                gate.need(row['registered_source_indices']==old['source_indices'] and row['prediction_sha256']==old['prediction_sha256'] and row['checkpoint_sha256']==old['checkpoint_sha256'],'Independent original12 bindings')
            audits.append(dict(id=case['id'],status='passed',panels=list(expected)));print(json.dumps(dict(event='case_audited',case=case['id'])),flush=True)
        gate.verify()
        gate.write(gate.HERE/'numeric_audit.json',dict(status='passed',at=gate.now(),result_sha256=gate.sha(p),seal_sha256=gate.sha(gate.SEAL),cases=audits,
            original_twelve_regression_passed=True,producer_reductions_imported=False,
            independence_scope='Separate scalar reductions, direct target/state reconstruction and distinct origin joins; same operator, no second-person review.',
            heldout_targets_read=False,complete_research_experiment=False))
if __name__=='__main__':main()
