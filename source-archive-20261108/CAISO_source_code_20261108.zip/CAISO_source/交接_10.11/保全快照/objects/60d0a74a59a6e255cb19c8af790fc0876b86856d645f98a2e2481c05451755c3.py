"""Register and seal one finite development-only amendment before optimization."""
import sys
from pathlib import Path
import gate as g


def register():
    g.boundary()
    g.need(not (g.HERE/'PROTOCOL.json').exists(), 'Already registered')
    old = g.read(g.ROOT/'selection_alignment_v1_20260928/PROTOCOL.json')
    parents = []
    for seed in [20260813,20260814,20260815]:
        for variant in ['FULL','CONCAT']:
            case=next(c for c in old['cases'] if c['seed']==seed and c['variant']==variant)
            e=next(e for e in case['epochs'] if e['epoch']==12)
            g.need(g.sha(e['checkpoint'])==e['sha256'], 'Changed parent')
            parents.append(dict(seed=seed,variant=variant,checkpoint=e['checkpoint'],sha256=e['sha256'],epoch=12))
    p=dict(at=g.now(),status='registered_before_training',
        authorization='User: 那你赶紧开始，设法解决问题',
        scope='Post-test exploratory amendment, TRAIN/June only; original63-case frozen study unchanged.',
        operational_revision={
            'previous_proposal':'Six continuations and a new-period feasibility condition before launch.',
            'change':'Nine continuations: add three CONCAT continuations to match added optimization. Run bounded development while new-source admission proceeds; independent confirmation remains gated.',
            'reason':'Separate architecture changes from two additional training epochs, and avoid idling development on unresolved source engineering.',
            'before_any_new_optimizer_update':True,
            'not_relaxed':['5GiB launch/4GiB runtime floors','single numerical worker','no test-target access before freeze/admission','no test-driven tuning']},
        hypothesis='Retain the trained scalar branch selection and permit a zero-initialized centered channel correction. Its effect on long-horizon errors is unproven.',
        formula='softmax_branch(original_scalar_logits + beta*centered_coordinate_scores), beta initially0; coordinate scores scaled bysqrt32; shared query/key and unchanged weighted feature sum.',
        core_preserved=['TCN','Transformer','dynamic GNN','parallel temporal branches','adaptive weighted feature fusion before head'],
        variants=['RESIDUAL','FULL_CONT','CONCAT_CONT'],seeds=[20260813,20260814,20260815],parents=parents,
        budget=dict(fits=9,epochs=2,slots_per_epoch=4032,batch_size=4,updates_per_fit=2016,
            parent_epochs=12,phase_schedules=[1,2],lr=.0001,weight_decay=.0001,
            optimizer='Fresh AdamW in every arm; beta .9/.999 eps1e-8; no inherited optimizer advantage',
            loss='Huber delta.5 on original TRAIN-standardized targets',gradient_clip=1.,threads=1,
            continuation_rng='seed+400000 torch; seed+400000 numpy generator; identical across arms',
            training='All originally trainable parameters plus beta for RESIDUAL; frozen original unused modules stay frozen'),
        parent_rule='All parents use epoch12, equal prior12096updates; immutable selected original models also retained. No parent selection using new results.',
        selection='Earliest June3397 raw MAE improvement >1e-6 among epoch0,1,2; exact panel hash/count/role enforced; epoch0 retained when continuation is harmful.',
        evaluation=dict(primary='June3397 mean of three seed MAEs, not an ensemble',
            supplementary=['June284','balanced3336','all horizons/nodes/phases/states'],
            promotion='Exploratory candidate only if mean MAE beats both matched continuations, beats FULL_CONT in at least2/3seeds, and no MAE/RMSE/near/H12 mean headline increase vs immutable parent FULL on dense or hourly panels beyond1e-8.',
            reporting='Every arm, seed, epoch and direction retained; no new independent-test claim.'),
        source_investigation='OPSD raw ENTSO-E2017 archive metadata; CAISO unused-period metadata feasibility. Price targets remain sealed. Full source/time/prior-access admission is still required.',
        test_access_permitted=False, new_test_targets_read=False,
        stopping_rule='Exactly9fits x2epochs; no graph/loss/temperature/learning-rate search or automatic extension. Failed candidate closes without replacement search.',
        literature=[dict(url='https://arxiv.org/abs/2003.04887',use='Zero-initialized residual gating principle; application to this attention is a hypothesis, not established EPF efficacy.'),
            dict(url='https://arxiv.org/abs/2008.08004',use='Fair baselines, aligned forecasting scope and evaluation.'),
            dict(url='https://jmlr.org/papers/v11/cawley10a.html',use='New independent confirmation needed after development selection.')],
        resource=dict(launch_GiB=5,runtime_GiB=4,numerical_workers=1,threads=1),
        complete_research_experiment=False)
    g.write(g.HERE/'PROTOCOL.json',p)
    print('Registered nine matched two-epoch continuations; no test access.')


def seal():
    g.need(not g.SEAL.exists(), 'Already sealed')
    q=g.read(g.HERE/'QA.json');g.need(q['status']=='passed','QA missing')
    bindings={}
    def bind(p):bindings[str(p)]=g.sha(p)
    for p in g.HERE.glob('*.py'):
        compile(p.read_text(encoding='utf-8'),str(p),'exec');bind(p)
    for p in (g.SOURCE/'models').glob('*.py'):bind(p)
    for name in ['compiled_data.py','compile_gate.py','compile_math.py']:bind(g.SOURCE/name)
    for name in ['PROTOCOL.json','QA.json','launch.ps1','watch_manager_exit.ps1','selection.py']:bind(g.HERE/name)
    bind(g.MANIFEST);bind(g.MANIFEST.parent/'audit.json')
    bind(g.ROOT/'common_sampling_evaluation_20260923/reductions.py')
    for p in g.read(g.HERE/'PROTOCOL.json')['parents']:bind(Path(p['checkpoint']))
    for p,h in q['source_hashes'].items():g.need(g.sha(p)==h,'QA implementation changed')
    g.write(g.SEAL,dict(status='sealed_development_only',at=g.now(),bindings=bindings,test_access_permitted=False))
    print('Sealed protocol, source, parents and QA.')


if __name__=='__main__':{'register':register,'seal':seal}[sys.argv[1]]()
