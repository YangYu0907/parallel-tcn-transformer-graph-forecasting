"""Resolve retention event and record the next independently sealed evaluation."""
from pathlib import Path
import json,sys,hashlib,datetime,os,uuid
b=Path(r"C:\Users\于阳\CAISO_feature_fusion_rev12\asof_retraining_branch_20260913")
sys.path.insert(0,str(b/"phase_retention_v1_20260924"));import gate
seal=gate.verify();ret=gate.HERE
event=gate.read(b/"event_driven_automation/inbox/retention_audited_result_ready_d659ae14e7d90b0154178e6856ce7560b31c27a53012d001a72b90e3ef2a492e.json")
comp=gate.read(ret/"queue/completion.json")
assert gate.sha(ret/"queue/completion.json")=="d659ae14e7d90b0154178e6856ce7560b31c27a53012d001a72b90e3ef2a492e"
assert comp["summary_sha256"]==gate.sha(ret/"summary.json")
for name,d in comp["receipts"].items():
    p=ret/"queue/steps"/name;r=gate.read(p)
    assert gate.sha(p)==d and r["exit_code"]==0 and gate.sha(gate.inside(r["marker"]))==r["marker_sha256"]
runs={}
for c in seal["cases"]:
    folder=ret/"runs"/c["id"];r=gate.read(folder/"completion.json");a=gate.read(folder/"audit.json")
    assert a["status"]=="passed" and a["completion_sha256"]==gate.sha(folder/"completion.json")
    for p,d in a["output_bindings"].items():assert gate.sha(gate.inside(p))==d
    runs[c["id"]]=r
metrics=("mae","rmse","near_h1_4_mae","h12_mae")
pairs=[]
for seed in (20260813,20260814):
    warm=runs[f"{seed}_WARM"];retain=runs[f"{seed}_RETAIN"]
    pairs.append(dict(seed=seed,panels={p:dict(warm={k:warm["panels"][p][k] for k in metrics},
        retain={k:retain["panels"][p][k] for k in metrics},
        reduction_percent={k:100*(warm["panels"][p][k]-retain["panels"][p][k])/warm["panels"][p][k] for k in metrics})
        for p in ("June284","June3397","balanced278")},
        selected_epochs=dict(WARM=warm["selected_epoch"],RETAIN=retain["selected_epoch"])))
proposal=dict(status="theory_grounded_candidate_not_yet_training_preregistered",
    motivation="Retain improves hourly MAE but worsens dense MAE in both seeds relative to matched WARM. Shared-parameter interference is a hypothesis, not established cause.",
    design="Freeze a common ADDITIVE FULL backbone in evaluation mode; add a zero-initialized residual adapter to fused representations; retain TCN, Transformer, dynamic GNN, parallel branches and adaptive attention.",
    next_matched_control="Two seeds, phase-gated versus always-active adapters, identical frozen backbone, parameter count, supervised Huber loss, batch order and update budget. Register exact architecture/budget/selection and QA before execution; no extra teacher loss in this contrast.",
    known_gate="Origin phase modulo12 is known at issuance; restrict gated adapter to hourly origins. No future prices or retrospectively labelled states enter gate.",
    benefits="Numerically verify unchanged off-hour predictions by construction; train few extra parameters and test hourly repair without moving backbone weights.",
    costs="Less joint adaptation, possible phase discontinuity, added parameters and no guaranteed hourly/tail benefit; adapter architecture derived for prices is an untested adaptation.",
    literature=[dict(url="https://arxiv.org/abs/1902.00751",claim="Houlsby et al. freeze base parameters and train small adapters for NLP; supplies mechanism rationale, not CAISO empirical evidence."),
                dict(url="https://arxiv.org/abs/1606.09282",claim="Li and Hoiem motivate functional retention in vision; current regression pilot demonstrates its own limits.")],
    sequencing="First finish already completed original20-model common comparison. Do not repeatedly tune against June without bounded registration; independent chronological confirmation remains required.")
h=b/"mechanism_common_evaluation_20260924"
import psutil
processes=[]
for p in psutil.process_iter(["pid","create_time","name","cmdline"]):
    try:
        args=" ".join(p.info["cmdline"] or [])
        if str(h) in args and any(n in args for n in ("manager.py","evaluate.py","audit.py","watch_manager_exit.ps1")):
            processes.append(p.info)
    except (psutil.NoSuchProcess,psutil.AccessDenied):pass
live=gate.read(h/"queue/status.json")
audit=dict(status="retention_four_runs_verified_common20_progressing",at=gate.now(),event_id=event["event_id"],
    outer_event_id="ba8f9d2fca396df8fce356cb460fbb4a789ee65ce54295f5f6d1b312e30469e0",
    completion_sha256=gate.sha(ret/"queue/completion.json"),summary_sha256=gate.sha(ret/"summary.json"),
    receipts_verified=len(comp["receipts"]),independent_algorithms_audited_cases=4,
    independence="Same operator executing distinct numerical algorithms; no second-person review claim.",
    comparisons=pairs,interpretation="Replicated hourly/dense tradeoff, not universal improvement. All four packages protect four headline metrics against original FULL on hourly+dense, but not all panel-best references. S2 WARM selected epoch0.",
    hypothesis="Shared-backbone functional retention can alter off-hour predictions via common parameters; to be tested with localized frozen-backbone adaptation.",
    next_candidate=proposal,
    next_evaluation=dict(directory=str(h),seal_sha256=gate.sha(h/"EVALUATION_LOCK.json"),case_count=20,
        no_model_training=True,numerical_process_snapshot=processes,observed_status=live,
        local_watcher_pid=14052,manager_pid=5632,exit_bridge_pid=16424,periodic_wakeup=False),
    heldout_targets_read=False,complete_research_experiment=False)
ap=b/"audits/retention_completion_20260924_common20_launch.json"
gate.write(ap,audit)
hp=b/"HANDOFF.json";handoff=gate.read(hp)
handoff["prior_status"]=handoff["status"]
handoff["status"]="retention4_audited_mixed_tradeoff_common20_evaluation_started"
handoff["at"]=gate.now();handoff["queue_pid"]=5632;handoff["live_status"]=str((h/"queue/status.json").relative_to(b))
handoff["observed_queue_state"]=live
handoff["retention_pilot"].update(status="four_runs_completed_and_numerically_audited",completion=str((ret/"queue/completion.json").relative_to(b)),
    completion_sha256=gate.sha(ret/"queue/completion.json"),summary_sha256=gate.sha(ret/"summary.json"),current_manager_pid=None,
    latest_resolution=str(ap.relative_to(b)),new_training_not_restarted=True)
handoff["retention_pilot"].pop("live_training_checkpoint",None)
handoff["mechanism_common_evaluation"]=audit["next_evaluation"]
handoff["latest_retention_interpretation"]=audit["interpretation"]
handoff["next_isolated_adapter_candidate"]=proposal
handoff["next_actions"]=[
    "Finish frozen original20 common-panel evaluation and separate numeric audit; keep original12 hashes/origin joins/metrics unchanged.",
    "Use all completed comparisons to bound a frozen-backbone residual adapter trial; exact registration and meaningful QA required before training.",
    "Fresh matched downstream refinements if a new backbone is promoted; never attach original adapters to a changed backbone.",
    "Resolve final seed/scope, freeze models and source admission, then independent chronological evaluation without test-driven tuning."]
handoff["handled_events"]=list(dict.fromkeys(handoff.get("handled_events",[])+[event["event_id"]]))
handoff["complete_research_experiment"]=False
handoff["paper_drafting_paused"]=True
handoff["automatic_continuation_paused"]=False
gate.write(b/"audits/handoff_before_retention_resolution_20260924.json",gate.read(hp))
gate.write(hp,handoff,True)
print(json.dumps(dict(status=audit["status"],pairs=pairs,live=live),ensure_ascii=True))
