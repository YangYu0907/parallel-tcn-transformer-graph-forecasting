"""Four fixed information fits after complete source admission, original guards."""
from pathlib import Path
import os,sys,time,json,traceback
for key in ['OMP_NUM_THREADS','MKL_NUM_THREADS','OPENBLAS_NUM_THREADS','NUMEXPR_NUM_THREADS']:os.environ[key]='1'
W=Path(__file__).resolve().parent;sys.path.insert(0,str(W.parent.parent));sys.path.append(str(W.parent))
import support as s
import psutil
def write(name,obj):s.base.write(W/name,obj)
def status(**kw):write('STATUS.json',dict(at=s.now(),pid=os.getpid(),**kw))
def verify():
    p=s.verify();q=s.read(W/'PROTOCOL.json')
    assert s.read(W/'SOURCE_REVIEW.json')['passed'] and s.read(W/'ENGINEERING_QA.json')['passed']
    for file,h in q['bindings'].items():assert s.sha(file)==h,file
    assert not (s.N/'RESULT.json').exists(),'Already completed: no duplicate fit'
    assert s.read(s.N/'SOURCE_COMPLETE.json')['cycles']==5286
    return p
def guard(launch=False):
    for folder in [W,s.N]:
        for name in ['STOP_REQUESTED','STOP_REQUESTED.json']:
            if (folder/name).exists():raise InterruptedError('User stop')
    return s.guard(launch)
def main():
    start=time.monotonic();lock=W/'MANAGER.lock'
    with lock.open('x',encoding='utf-8') as f:json.dump(dict(pid=os.getpid()),f)
    try:
        p=verify();guard(True);status(event='awaiting_exit_monitor_binding')
        while not (W/'START_READY.json').exists():
            if time.monotonic()-start>55:raise TimeoutError('Exit monitor missing')
            time.sleep(.2)
        ready=s.read(W/'START_READY.json')
        assert ready['manager_pid']==os.getpid() and psutil.pid_exists(ready['exit_monitor_pid'])
        def tick(**kw):
            resources=guard();info=psutil.Process().memory_info()
            write('PROGRESS.json',dict(at=s.now(),pid=os.getpid(),elapsed_seconds=time.monotonic()-start,resources=resources,rss_MiB=info.rss/2**20,peak_rss_MiB=info.peak_wset/2**20,**kw))
        status(event='step_process_started',stage='four_matched_weather_information_fits')
        with s.base.numeric('Four frozen weather-information arms, original5/4GiB guards'):
            import fit_compare
            fit_compare.run(p,tick)
            for path,h in s.read(s.N/'PROTECTED_FILES.json').items():assert s.sha(path)==h
        result=s.read(s.N/'RESULT.json')
        event='audited_result_ready' if result.get('information_gate_passed') else 'needs_analysis'
        eid=s.emit(event,s.N/'RESULT.json');status(event='finite_mechanism_queue_completed',event_id=eid,whole_research_completed=False,model_fits=result['model_fits'])
    except InterruptedError as error:status(event='user_stop_at_stage_boundary',classification='user_stop',error=str(error))
    except BaseException as error:
        write('FAILURE.json',dict(at=s.now(),error=repr(error),traceback=traceback.format_exc(),new_test_targets_read=False,V7_replaced=False))
        eid=s.emit('blocking_failure',W/'FAILURE.json');status(event='step_stopped_or_failed',event_id=eid,error=repr(error))
    finally:
        if lock.exists() and s.read(lock)['pid']==os.getpid():lock.unlink()
if __name__=='__main__':main()
