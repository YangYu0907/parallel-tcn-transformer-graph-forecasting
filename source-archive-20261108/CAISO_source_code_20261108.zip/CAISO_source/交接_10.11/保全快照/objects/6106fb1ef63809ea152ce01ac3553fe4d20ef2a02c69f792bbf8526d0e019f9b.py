import json,sys
from pathlib import Path
b=Path(r"C:\Users\于阳\CAISO_feature_fusion_rev12\asof_retraining_branch_20260913")
sys.path.insert(0,str(b/"phase_retention_v1_20260924"));import gate
s=gate.verify();p=gate.HERE/"queue/completion.json";c=gate.read(p)
assert gate.sha(p)=="d659ae14e7d90b0154178e6856ce7560b31c27a53012d001a72b90e3ef2a492e"
for name,d in c["receipts"].items():
 rp=gate.HERE/"queue/steps"/name;r=gate.read(rp)
 assert gate.sha(rp)==d and r["exit_code"]==0 and gate.sha(gate.inside(r["marker"]))==r["marker_sha256"]
rows=[]
for case in s["cases"]:
 p=gate.HERE/"runs"/case["id"];r=gate.read(p/"completion.json");a=gate.read(p/"audit.json")
 assert a["status"]=="passed" and a["completion_sha256"]==gate.sha(p/"completion.json")
 for source,d in a["output_bindings"].items():assert gate.sha(gate.inside(source))==d
 rows.append(dict(id=case["id"],selected=r["selected_epoch"],panels={name:{k:row[k] for k in ("mae","rmse","near_h1_4_mae","h12_mae")}for name,row in r["panels"].items()},
 states=r["panels"]["June3397"]["by_state"],curves=[dict(epoch=x["epoch"],june=x["june"],train_loss=x["train_supervised_mean"],retention_loss=x["train_retention_mean"])for x in r["epochs"]],
 train_diag=[dict(epoch=x["epoch"],mae=x["metrics"]["mae"],rmse=x["metrics"]["rmse"])for x in r["train_curves"]]))
print(json.dumps(dict(rows=rows,decisions=gate.read(gate.HERE/"summary.json")["decisions"]),ensure_ascii=True))
