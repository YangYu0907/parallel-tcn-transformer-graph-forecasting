"""Metadata and resource gates for matched fixed-budget continuation."""
from pathlib import Path
from contextlib import contextmanager
from datetime import datetime,timezone
import hashlib,json,os,sys,uuid
HERE=Path(__file__).resolve().parent;ROOT=HERE.parent
COMMON=ROOT/'common_sampling_evaluation_20260923'
V=ROOT/'phase_sampling_support_v3_20260923'
SEAL=HERE/'EXECUTION_LOCK.json'
LOCK=Path('D:/Desktop/数据科学_论文/研究优化_20260818/logs/NEURAL_RUN.lock')
sys.path.insert(1,str(ROOT/'source'))
import compile_gate as cg
def now():return datetime.now(timezone.utc).isoformat()
def read(p):return json.loads(Path(p).read_text(encoding='utf-8-sig'))
def need(x,m):
    if not x:raise RuntimeError(m)
def inside(p):
    p=Path(p);p=(ROOT/p if not p.is_absolute() else p).resolve()
    need(p.is_relative_to(ROOT),'Path outside branch');return p
def rel(p):return str(inside(p).relative_to(ROOT))
def sha(p):
    h=hashlib.sha256()
    with Path(p).open('rb') as f:
        for x in iter(lambda:f.read(1048576),b''):h.update(x)
    return h.hexdigest()
def atomic(p,writer,replace=False):
    p=inside(p);p.parent.mkdir(parents=True,exist_ok=True)
    t=p.with_name('t_'+uuid.uuid4().hex+'.pending')
    with t.open('xb') as f:writer(f);f.flush();os.fsync(f.fileno())
    if replace:os.replace(t,p)
    else:t.rename(p)
def write(p,v,replace=False):
    raw=json.dumps(v,ensure_ascii=False,allow_nan=False,indent=2).encode()
    atomic(p,lambda f:f.write(raw),replace)
def boundary():
    for folder in (ROOT,HERE,HERE/'queue',V,COMMON):
        for name in ('STOP_REQUESTED','STOP_REQUESTED.json'):
            if (folder/name).exists():raise InterruptedError('User stop '+str(folder/name))
    p=read(ROOT.parent/'RESEARCH_PAUSED.json')
    if p.get('status')!='resumed_by_user' or p.get('stop_preparation_and_training'):raise InterruptedError('Research paused')
def guard(launch=False):
    boundary();r=cg.resources();floor=5 if launch else 4
    if min(r.values())<floor:raise MemoryError(f'Continuation needs {floor}GiB physical+commit; actual {r}')
    return r
@contextmanager
def exclusive(action):
    guard(True)
    import psutil
    o=dict(pid=os.getpid(),created=psutil.Process().create_time(),token=uuid.uuid4().hex,action=action)
    with LOCK.open('x',encoding='utf-8') as f:json.dump(o,f);f.flush();os.fsync(f.fileno())
    try:cg.bound_process();guard();yield
    finally:
        need(read(LOCK)==o,'Lock owner changed');write(HERE/'lock_releases'/(o['token']+'.json'),dict(owner=o,at=now()));LOCK.unlink()
def runtime(torch_needed=True):
    cg.bound_process()
    import numpy as np
    from threadpoolctl import threadpool_limits,threadpool_info
    lim=threadpool_limits(1)
    need(all(x['num_threads']==1 for x in threadpool_info()),'Numerical thread limit')
    if torch_needed:
        import torch
        torch.set_num_threads(1);torch.set_num_interop_threads(1);torch.use_deterministic_algorithms(True)
        guard();return np,torch,lim
    guard();return np,lim

def load(name,path):
 import importlib.util
 spec=importlib.util.spec_from_file_location(name,path);m=importlib.util.module_from_spec(spec);spec.loader.exec_module(m);return m
PARENT=ROOT/'selector_scope_v1_20260925'
BUD=ROOT/'budget_extension_v1_20260925'
VARIANTS=('FULL',)
sys.path.append(str(COMMON))

def prepared_cases():
 return [c for c in read(BUD/'EXECUTION_LOCK.json')['cases'] if c['variant']=='FULL']
def verify():
 boundary();s=read(SEAL)
 need(s['status']=='sealed_three_seed_phase_weighting','Wrong seal')
 for p,h in s['bindings'].items():need(sha(inside(p))==h,'Sealed artifact changed '+p)
 need(s['cases']==prepared_cases(),'Case scope changed')
 return s

def seal():
 boundary();need(not SEAL.exists(),'Seal exists');bindings={}
 def bind(p,h=None):
  p=inside(p);actual=sha(p);need(h is None or actual==h,'Input changed '+str(p));bindings[rel(p)]=actual
  return read(p) if p.suffix=='.json' else actual
 old=bind(PARENT/'EXECUTION_LOCK.json','cbddaede487fcc2463ec19ca037c997788865566a63adc3d962652ae63f1c617')
 for p,h in old['bindings'].items():bind(p,h)
 done=bind(PARENT/'queue/completion.json','54cc506e11885b44a217b373f7c05620f4f2c13771a98f0c07d23b214a0317d1')
 bind(PARENT/'summary.json',done['summary_sha256'])
 for n,h in done['receipts'].items():
  r=bind(PARENT/'queue/steps'/n,h);need(r['exit_code']==0,'Prior exit');bind(r['marker'],r['marker_sha256'])
 for c in old['cases']:
  a=bind(PARENT/'cases'/c['id']/'audit.json');need(a['status']=='passed','Prior audit')
  for p,h in a['output_bindings'].items():bind(p,h)
 bind(ROOT/'audits/selector_scope_completion_verified_20260925.json')
 for p in HERE.glob('*.py'):compile(p.read_text(encoding='utf-8'),str(p),'exec');bind(p)
 for n in ('PROTOCOL.json','WEIGHTS.json','launch_reviewed.ps1','watch_manager_exit.ps1','synthetic_qa.json','parent_qa.json','source_review.json'):bind(HERE/n)
 for n in ('synthetic_qa.json','parent_qa.json'):
  q=read(HERE/n);need(q['status']=='passed','QA incomplete')
  for p,h in q['sources'].items():bind(p,h)
 rv=read(HERE/'source_review.json')
 need(rv['status']=='passed' and rv['synthetic_sha256']==sha(HERE/'synthetic_qa.json') and rv['parent_sha256']==sha(HERE/'parent_qa.json'),'Review missing')
 need(len(read(HERE/'parent_qa.json')['cases'])==3,'Three seed QA')
 parent=read(BUD/'EXECUTION_LOCK.json')
 write(SEAL,dict(status='sealed_three_seed_phase_weighting',at=now(),cases=prepared_cases(),bindings=bindings,
  dataset_manifest=parent['dataset_manifest'],train_diagnostic=parent['train_diagnostic'],
  unchanged_prefix_epochs=6,weighted_tail_epochs=6,selector_changed=False,heldout_targets_read=False,complete_research_experiment=False))
 print(json.dumps(dict(status='sealed_three_seed_phase_weighting',cases=3,bindings=len(bindings),sha256=sha(SEAL))))
if __name__=='__main__':
 if sys.argv[1]=='seal':seal()
 else:
  verify();need(not LOCK.exists(),'Another numerical worker active');print(json.dumps(dict(status='passed',resources=guard(True))))
