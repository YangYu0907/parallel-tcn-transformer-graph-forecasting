"""Sealed, single-worker June input replay. Never grants H1 admission.

Usage after the active numerical queue releases its shared lock:
  python june_replay.py seal
  python june_replay.py run
The source-level and model-prediction reviews remain separate requirements.
"""
import argparse
import csv
from pathlib import Path
import sys

HERE=Path(__file__).resolve().parent
sys.path.insert(0,str(HERE.parent))
import common as c
from bounded_history import JuneArchiveReader, file_sha

SEAL=HERE/'JUNE_INPUT_REPLAY_SEAL.json'
MANIFEST=c.BRANCH/'phase_sampling_support_v3_20260923/dataset/ADDITIVE/manifest.json'


def seal():
    c.boundary()
    c.need(not c.SHARED_LOCK.exists(),'Existing numerical worker retains priority')
    c.need(not SEAL.exists(),'Preserve existing replay seal')
    config=c.read(c.BRANCH/'compiler_config.json')
    source=c.read(config['source_publication_binding_audit'])
    m=c.read(MANIFEST);audit_path=MANIFEST.parent/'audit.json';audit=c.read(audit_path)
    c.need(audit['status']=='passed' and audit['dataset_manifest_sha256']==file_sha(MANIFEST),'TRAIN audit changed')
    c.need(m['source_publication_audit_sha256']==file_sha(config['source_publication_binding_audit']),'TRAIN source binding changed')
    qa=c.read(HERE/'BOUNDED_IO_QA.json')
    c.need(qa['status']=='passed' and qa['market_values_read'] is False,'Boundary QA missing')
    for p,d in qa['sources'].items():c.need(file_sha(p)==d,'Boundary QA source stale')
    bindings={}
    for p in [HERE/'bounded_history.py',HERE/'june_replay.py',HERE/'BOUNDED_IO_QA.json',
              c.HERE/'common.py',c.BRANCH/'source/compile_gate.py',c.BRANCH/'source/compile_math.py',
              c.BRANCH/'compiler_config.json',MANIFEST,audit_path,Path(config['node_panel']),
              Path(config['source_publication_binding_audit']),HERE/'SOURCE_CONTRACT_REVIEW.json']:
        bindings[str(p.resolve())]=file_sha(p)
    paths={}
    for name in ('scalers.json','timestamps_seconds.npy','forecast_publications_seconds.npy',
                 'june_origins.npy','features.npy'):
        row=m['artifacts'][name];p=(c.BRANCH/row['path']).resolve()
        c.need(file_sha(p)==row['sha256'],'Audited input changed: '+name)
        bindings[str(p)]=row['sha256'];paths[name]=str(p)
    archives={}
    for key in ('price_archive','external_archive'):
        p=Path(config[key]);stat=p.stat();expected=source['raw_file_identities'][str(p)]
        c.need(stat.st_size==expected['size_bytes'] and stat.st_mtime_ns==expected['mtime_ns'],'Original archive identity differs')
        digest=file_sha(p);archives[str(p.resolve())]=digest;bindings[str(p.resolve())]=digest
    c.write(SEAL,dict(status='sealed_June_input_replay_only',at=c.now(),bindings=bindings,
        paths=paths,archive_hashes=archives,config=config,nodes=m['nodes'],feature_names=m['feature_names'],
        caps=m['age_caps_minutes'],origins='All 3397 previously admitted June development origins',
        volatility_feature=22,exact_equality_other_28_features=True,
        volatility_absolute_tolerance=2e-5,volatility_relative_tolerance=1e-6,
        tolerance_basis='Float32 output of float64 rolling accumulation; declared before replay, not selected from H1 outcomes',
        numerical_difference_policy='Any excess fails; retain evidence and investigate implementation without H1 access',
        model_prediction_replay_required_separately=True,source_report_numeric_linkage_required_separately=True,
        H1_target_reader=False,H1_source_admitted=False))
    print('June input replay sealed; no values decoded')


def run():
    with c.exclusive('June-only bounded input replay'):
        s=c.read(SEAL)
        c.need(s['status']=='sealed_June_input_replay_only','Invalid replay seal')
        for p,d in s['bindings'].items():c.need(file_sha(p)==d,'Sealed replay dependency changed: '+p)
        np,limiter=c.runtime()
        from compile_math import age_at_origin,close
        paths=s['paths']
        origins=np.load(paths['june_origins.npy'],allow_pickle=False)
        c.need(origins.dtype==np.int64 and len(origins)==3397 and np.all(np.diff(origins)>0),'June panel changed')
        seconds=np.load(paths['timestamps_seconds.npy'],allow_pickle=False)
        pubs=np.load(paths['forecast_publications_seconds.npy'],allow_pickle=False)
        scalers=c.read(paths['scalers.json'])
        c.need(scalers['fit_stop']==210528 and scalers['old_fitted_state_reused'] is False,'TRAIN-fitted state contract changed')
        with Path(s['config']['node_panel']).open(encoding='utf-8-sig',newline='') as f:panel=list(csv.DictReader(f))
        c.need([r['PNODE_ID'] for r in panel]==s['nodes'],'Node order differs')
        tac=[r['TAC_AREA_ID'] for r in panel]
        # Timestamp members contain metadata only, including outside June.
        for key in ('price_archive','external_archive'):
            with np.load(s['config'][key],allow_pickle=False) as archive:
                times=archive['timestamps_ns'][:219168]
                c.need(np.array_equal(times,seconds*10**9),'Archive/compiled timestamp alignment failed')
        reader=JuneArchiveReader(s['config'],origins,s['archive_hashes'])
        reference=np.load(paths['features.npy'],mmap_mode='r',allow_pickle=False)
        maxima=np.zeros(29,np.float64);nonexact=np.zeros(29,np.int64);failed=[]
        worst_ratio=0.;done=0
        try:
            for ix,o0 in enumerate(origins):
                o=int(o0)
                if ix%32==0:c.guard()
                actual=reader.history(o,pubs[o-288:o],seconds[o-288:o],scalers,tac,s['caps'])
                expected=reference[o-288:o].copy()
                expected[:,:,19:21]=age_at_origin(pubs,seconds,o,s['caps'])[:,None,:]
                delta=np.abs(actual.astype(np.float64)-expected.astype(np.float64))
                maxima=np.maximum(maxima,delta.max(axis=(0,1)))
                nonexact+=(actual!=expected).sum(axis=(0,1))
                selected=[i for i in range(29) if i!=22]
                tolerance=s['volatility_absolute_tolerance']+s['volatility_relative_tolerance']*np.abs(expected[:,:,22])
                worst_ratio=max(worst_ratio,float((delta[:,:,22]/tolerance).max()))
                if not np.array_equal(actual[:,:,selected],expected[:,:,selected]) or np.any(delta[:,:,22]>tolerance):
                    failed.append(dict(origin=o,maximum_absolute_by_feature=delta.max(axis=(0,1)).tolist()))
                done+=1
                if done%128==0:
                    c.write(HERE/'june_replay_status.json',dict(status='running',at=c.now(),completed=done,total=len(origins)))
            for p,d in s['bindings'].items():c.need(file_sha(p)==d,'Input changed during replay: '+p)
            result=dict(status='passed_input_replay_only' if not failed else 'failed_input_replay',at=c.now(),
                seal_sha256=file_sha(SEAL),origins=done,nodes=30,history=288,features=29,
                max_absolute_by_feature=dict(zip(s['feature_names'],maxima.tolist())),
                unequal_float32_cells_by_feature=dict(zip(s['feature_names'],nonexact.tolist())),
                volatility_worst_tolerance_fraction=worst_ratio,failed_origins=failed,
                byte_receipts=reader.receipts(),fit_calls=0,gradient_steps=0,H1_targets_read=False,
                same_operator_separate_feature_implementation=True,
                H1_admitted=False,model_prediction_replay_completed=False,
                remaining=['Bound raw reports to H1 inputs','Replay selected model predictions','Complete actual source/model/panel release gates'])
            c.write(HERE/'JUNE_INPUT_REPLAY.json',result)
            c.write(HERE/'june_replay_status.json',dict(status=result['status'],at=c.now(),completed=done,total=len(origins)))
            c.need(not failed,'June replay failed; inspect preserved feature differences')
            print('All 3397 June inputs replayed; H1 remains sealed')
        finally:
            close(reference);reader.close();del limiter


if __name__=='__main__':
    parser=argparse.ArgumentParser();parser.add_argument('action',choices=['seal','run'])
    args=parser.parse_args();seal() if args.action=='seal' else run()
