from common import *
def main():
    with gate.exclusive('V6 synthetic QA only'):
        np,lim=gate.runtime(False);import worker as w;w.np=np
        p=np.array([[.1,.3,.6],[.7,.2,.1]])
        assert np.allclose(w.transform(p,np.eye(3),np.zeros(3)),p)
        rng=np.random.default_rng(82);probs=rng.dirichlet([1,2,3],120);labels=rng.integers(0,3,120)
        W,b=w.fit_map(probs,labels,np.ones(120)/12);assert np.isfinite(W).all();assert np.allclose(w.transform(probs,W,b).sum(1),1)
        days=np.repeat(np.arange(6),6);lab=np.tile(np.repeat(np.arange(3),2),6);f=np.ones(36);target=np.zeros(36);d=np.full(36,-1.5)
        a=w.guard_bound(days,lab,f,d,target,7*86400);assert np.isclose(a,1)
        assert w.guard_bound(days,lab,f,-d,target,7*86400)==0
        assert w.guard_bound(days[:12],lab[:12],f[:12],d[:12],target[:12],7*86400)==0
        d=np.full(36,-3.);a=w.guard_bound(days,lab,f,d,target,7*86400);assert np.isclose(a,2/3);assert np.mean(abs(f+a*d))<=1+1e-12
        for _ in range(30):
            f=rng.normal(size=36);t=rng.normal(size=36);d=rng.normal(size=36);a=w.guard_bound(days,lab,f,d,t,7*86400)
            for c in range(3):
                m=lab==c;weights=w.date_weights(days[m],7*86400);weights/=weights.sum()
                assert (weights*(abs(f[m]+a*d[m]-t[m])-abs(f[m]-t[m]))).sum()<1e-9
                assert (weights*((f[m]+a*d[m]-t[m])**2-(f[m]-t[m])**2)).sum()<1e-9
        # Full causal replay, with altered labels after a publication boundary.
        n=10;cut=np.arange(n)*86400+90000;obs=np.full((n,30),2);full=np.full((n,30,12,5),5.)
        full[...,1]=3.;full[...,2]=7.;full[...,3]=2.;full[...,4]=9.
        data=dict(origins=np.arange(n),cutoff=cut,available=cut[:,None]+np.arange(1,13)[None,:]*300,observable_regime=obs,states=rng.integers(3,6,(n,30,12)),truth=rng.normal(5,2,(n,30,12)),raw_last=np.full((n,30),6.))
        fold=dict(train=list(range(6)),evaluation=list(range(6,n)));rp=rng.dirichlet([2,1,2],(n,30,12));mus=np.ones_like(rp);qs=np.tile(np.linspace(-.3,.3,31),(3,1));prior=np.array([.4,.2,.4]);th=dict(thresholds=[np.ones(30).tolist(),(np.ones(30)*2).tolist()],center=np.zeros(30).tolist());base=np.full((4,30,12),5.);op=rp[6:];allowed=np.ones_like(base,bool)
        result,_=w.replay(data,fold,rp,mus,qs,prior,th,full,base,base,op,allowed)
        altered={k:v.copy() for k,v in data.items()};altered['truth'][8:]+=100;altered['states'][8:]=5
        result2,_=w.replay(altered,fold,rp,mus,qs,prior,th,full,base,base,op,allowed)
        for arm in ARMS:assert np.array_equal(result[arm][:3],result2[arm][:3]),arm
        for arm in ('FREQUENCY','CALIBRATED','GUARDED'):
            weights=result[arm+'_weights'];assert weights.min()>=0 and np.allclose(weights.sum(-1),1) and weights[...,0].min()>=.25
        checks=['identity calibration','finite converged multinomial calibration','guard analytic cases and random all-class empirical inequalities','sparse support fallback','actual replay future-label mutation invariance','simplex and FULL anchor']
        write(HERE/'QA.json',dict(at=gate.now(),status='passed',checks=checks,real_market_targets_read=False))
        files=[HERE/n for n in ('common.py','worker.py','manager.py','audit.py','qa.py','PROTOCOL.json','SOURCE_BINDINGS.json','QA.json')]
        write(HERE/'EXECUTION_SEAL.json',dict(at=gate.now(),bindings={str(p):gate.sha(p) for p in files}));print('V6 QA passed and code sealed')
if __name__=='__main__':main()
