"""Read-only component attribution and sample feasibility before choosing a model.

Uses only admitted TRAIN and previously inspected H1, no unopened period.
Observed future states/components are diagnostic labels, never routing inputs.
"""
from common import *
import csv, hashlib
np=None

class DiagnosticContract:
    def __init__(self,o,allowed):
        assert o in allowed;self.origin=o
    def allows(self,a,b,kind):return kind=='already_inspected_target_components' and (a,b)==(self.origin,self.origin+12)

def component_summary(now,future,mask,weights):
    delta=future-now[:,:,None,:]
    d=delta[mask];w=weights[mask];w=w/max(w.sum(),1e-30)
    dominant=np.argmax(abs(d[:,1:]),axis=1)
    return dict(cells=len(d),mean_abs_change_by_component=abs(d).mean(0).tolist(),
        dominant_energy_congestion_loss=np.bincount(dominant,minlength=3).tolist(),
        weighted_dominant_share=[float(w[dominant==k].sum()) for k in range(3)],
        signed_change_average=d.mean(0).tolist())

def main():
    global np
    with gate.exclusive('V12 component diagnosis and prior-sample feasibility; no model fit'):
        np,lim=gate.runtime(False);check(stage='source_verification')
        for p,h in gate.read(HERE/'DIAGNOSIS_SEAL.json')['bindings'].items():assert gate.sha(p)==h,p
        m=gate.read(B/'phase_sampling_support_v3_20260923/dataset/ADDITIVE/manifest.json')
        paths={k:gate.resolve(v['path']) for k,v in m['artifacts'].items()}
        sc=gate.read(paths['scalers.json']);th=gate.read(paths['state_thresholds.json']);q=np.array(th['thresholds']);center=np.array(th['center'])
        panel=readnp(A/'adaptive_experts_v4_20260929/panel.npz')
        ids=np.concatenate([f['evaluation'] for f in gate.read(B/'adaptive_experts_v4_20260929/FOLDS.json')]);origins=panel['origins']
        f=gate.read(B/'h1_final_evaluation_v1_20260927/FINAL_TEST_FREEZE.json');parent=gate.read(gate.resolve(f['input_freeze']))
        meta=readnp(gate.resolve(f['publication_routing']));meta['epoch']=int(meta['epoch'])
        sys.path.insert(0,str(B/'h1_feature_admission_v1_20260927'))
        from history import CandidateHistoryReader
        from bounded_history import BoundedMember
        expected={int(x['origin']):x['input_sha256'] for x in gate.read(gate.resolve(f['feature_receipts']))}
        with Path(parent['config']['node_panel']).open(encoding='utf-8-sig',newline='') as fd:tac=[r['TAC_AREA_ID'] for r in csv.DictReader(fd)]
        last=np.empty((len(origins),30,29),np.float32);raw=np.empty((len(origins),30,4),np.float32)
        history=np.empty((len(origins),72,30,4),np.float32)
        reader=CandidateHistoryReader(parent,meta)
        try:
            for j,o in enumerate(origins):
                parts=reader.parts(int(o));x=reader.history(int(o),sc,tac,parent['age_caps']);assert hashlib.sha256(x.tobytes()).hexdigest()==expected[int(o)]
                last[j]=x[-1];raw[j]=parts['recent'][-1];history[j]=parts['recent'][-72:]
                if j%100==0:check(stage='historical_component_replay',done=j,total=len(origins))
        finally:reader.close()
        target=np.empty((len(ids),30,12,4),np.float32);reader=BoundedMember(parent['config']['price_archive'],'values','<f4',(30,4))
        try:
            for j,o in enumerate(origins[ids]):
                payload=reader.read(int(o),int(o)+12,DiagnosticContract(int(o),set(origins[ids].tolist())),'already_inspected_target_components')
                target[j]=np.frombuffer(payload,'<f4').reshape(12,30,4).transpose(1,0,2)
                if j%100==0:check(stage='already_inspected_target_component_attribution',done=j)
            receipts=reader.receipts
        finally:reader.close()
        assert np.array_equal(target[:,:,:,0].astype(float),panel['truth'][ids])
        assert np.allclose(raw[:,:,0],panel['raw_last'],atol=1e-6,rtol=0)
        state=panel['states'][ids];truth=panel['truth'][ids];v7=[];full=[]
        for s in SEEDS:
            z=readnp(A/f'spike_specialist_v7_20260930/predictions/{s}.npz');assert np.array_equal(z['origins'],origins[ids]);v7.append(z['CONTEXT'])
            z=readnp(A/f'adaptive_experts_v4_20260929/experts/{s}.npz');full.append(z['experts'][ids,...,0])
        v7=np.stack(v7);full=np.stack(full);added=np.maximum((v7-truth)**2-(full-truth)**2,0).mean(0)
        summaries={str(k):component_summary(raw[ids],target,state==k,added if k==3 else np.mean((v7-truth)**2,0)) for k in (2,3,5)}
        masked=np.where(state==3,added,-np.inf);top=[]
        for flat in np.argsort(masked.ravel())[-20:][::-1]:
            j,n,h=np.unravel_index(flat,masked.shape);ix=ids[j]
            top.append(dict(origin=int(origins[ix]),cutoff=int(panel['cutoff'][ix]),node=int(n),horizon=int(h+1),current=raw[ix,n].tolist(),future=target[j,n,h].tolist(),
                recent_component_change_5m=(history[ix,-1,n]-history[ix,-2,n]).tolist(),recent_component_change_60m=(history[ix,-1,n]-history[ix,-13,n]).tolist(),
                full=full[:,j,n,h].tolist(),V7=v7[:,j,n,h].tolist(),positive_added_sse_mean=float(added[j,n,h])))
        # Inventory all admitted TRAIN origins; this inspects labels only inside old TRAIN.
        tr=np.load(paths['train_origins.npy'],mmap_mode='r');prices=np.load(paths['raw_prices.npy'],mmap_mode='r');seconds=np.load(paths['timestamps_seconds.npy'],mmap_mode='r')
        support=[]
        for year in (2023,2024,2025):
            lo=int(__import__('datetime').datetime(year,1,1,tzinfo=__import__('datetime').timezone.utc).timestamp());hi=int(__import__('datetime').datetime(year+1,1,1,tzinfo=__import__('datetime').timezone.utc).timestamp())
            use=tr[(seconds[tr-1]>=lo)&(seconds[tr-1]<hi)];counts=np.zeros(6,int);dates=[set() for _ in range(6)]
            for chunk in np.array_split(use,max(1,len(use)//500+1)):
                if not len(chunk):continue
                now=prices[chunk-1,:,0];y=prices[chunk[:,None]+np.arange(12)[None,:],:,0].transpose(0,2,1)
                cls=(abs(y-center[None,:,None])>q[0][None,:,None]).astype(int)+(abs(y-center[None,:,None])>q[1][None,:,None]).astype(int)
                states=cls+3*(abs(now-center)>q[1])[:,:,None]
                for k in range(6):
                    present=states==k;counts[k]+=present.sum();dates[k].update((seconds[chunk[present.any((1,2))]-1]//86400).tolist())
                check()
            support.append(dict(year=year,origins=len(use),cells_by_state=counts.tolist(),dates_by_state=[len(v) for v in dates]))
        sums_error=max(float(abs(target[:,:,:,0]-target[:,:,:,1:].sum(-1)).max()),float(abs(raw[:,:,0]-raw[:,:,1:].sum(-1)).max()))
        save(ART/'H1_diagnostic.npz',origins=origins,eval_indices=ids,last=last,raw_last=raw,history72=history,target_components=target)
        result=dict(at=gate.now(),status='component_diagnosis_complete',scope='Previously inspected H1 development only; TRAIN support inventory. No unopened target period.',
            component_order=['LMP','energy','congestion','loss'],identity_max_abs_residual=sums_error,state_components=summaries,top_S3_harmful=top,TRAIN_support=support,
            all_required_architecture_elements_unchanged=True,neural_updates=0,new_test_targets_read=False,
            diagnosis_limits='Accounting components identify the proximate price movement, not unobserved physical causation or prediction availability.',artifacts={str(ART/'H1_diagnostic.npz'):gate.sha(ART/'H1_diagnostic.npz')})
        write(HERE/'DIAGNOSIS.json',result);write(HERE/'DIAGNOSTIC_ACCESS_RECEIPTS.json',dict(receipts=receipts,purpose='Existing development target decomposition only; never model inputs'))
        check(stage='diagnosis_complete');print(json.dumps({k:v for k,v in result.items() if k not in ('top_S3_harmful','artifacts')},ensure_ascii=True),flush=True)
if __name__=='__main__':main()
