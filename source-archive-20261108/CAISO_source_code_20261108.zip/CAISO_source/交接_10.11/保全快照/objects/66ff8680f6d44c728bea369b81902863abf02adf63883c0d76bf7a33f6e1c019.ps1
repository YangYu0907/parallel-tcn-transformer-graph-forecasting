﻿$ErrorActionPreference='Stop'
$branch=Split-Path -Parent $PSScriptRoot
$managerPath=Join-Path $PSScriptRoot 'manager.py'
$eventDir=Join-Path $branch 'event_driven_automation'
$bridgePath=Join-Path $eventDir 'watch_manager_exit.ps1'
$bridgeReview=Get-Content -LiteralPath (Join-Path $eventDir 'independent_bridge_review.json') -Raw -Encoding UTF8 | ConvertFrom-Json
if ($bridgeReview.status -ne 'passed' -or $bridgeReview.source_sha256 -ne (Get-FileHash -LiteralPath $bridgePath -Algorithm SHA256).Hash.ToLower()) { throw 'Exit bridge independent review missing or changed' }
$queueReview=Get-Content -LiteralPath (Join-Path $PSScriptRoot 'INDEPENDENT_REVIEW.json') -Raw -Encoding UTF8 | ConvertFrom-Json
if ($queueReview.status -ne 'passed' -or $queueReview.seal_sha256 -ne (Get-FileHash -LiteralPath (Join-Path $PSScriptRoot 'SEAL.json') -Algorithm SHA256).Hash.ToLower()) { throw 'Mechanism review changed' }
$paused=Get-Content -LiteralPath (Join-Path (Split-Path -Parent $branch) 'RESEARCH_PAUSED.json') -Raw -Encoding UTF8 | ConvertFrom-Json
if ($paused.status -ne 'resumed_by_user' -or $paused.stop_preparation_and_training) { throw 'Research paused' }
if (Test-Path -LiteralPath 'D:\Desktop\数据科学_论文\研究优化_20260818\logs\NEURAL_RUN.lock') { throw 'Numerical lock occupied' }
if (Test-Path -LiteralPath (Join-Path $PSScriptRoot 'queue\QUEUE.lock')) { throw 'Manager lock exists' }
$all=@(Get-CimInstance Win32_Process)
$duplicate=@($all | Where-Object { $_.Name -eq 'python.exe' -and $_.CommandLine -and $_.CommandLine.Contains($managerPath) })
if ($duplicate.Count -ne 0) { throw 'Mechanism manager already running' }
$watchState=Get-Content -LiteralPath (Join-Path $eventDir 'status.json') -Raw -Encoding UTF8 | ConvertFrom-Json
$watch=@($all | Where-Object { $_.ProcessId -eq $watchState.pid -and $_.CommandLine -and $_.CommandLine.Contains((Join-Path $eventDir 'watch.ps1')) })
if ($watch.Count -ne 1) { throw 'Shared event inbox listener is not alive' }
$tag=[guid]::NewGuid().ToString('N').Substring(0,12)
$launchDir=Join-Path $PSScriptRoot ('launch_'+$tag)
New-Item -ItemType Directory -Path $launchDir | Out-Null
$python='D:\Documents\conda_envs\tcn_air\python.exe'
& $python $managerPath check
if ($LASTEXITCODE -ne 0) { throw 'Metadata admission failed' }
$manager=Start-Process -FilePath $python -ArgumentList @(('"'+$managerPath+'"'),'run') -WorkingDirectory $branch -WindowStyle Hidden -RedirectStandardOutput (Join-Path $launchDir 'manager.stdout.log') -RedirectStandardError (Join-Path $launchDir 'manager.stderr.log') -PassThru
$ticks=$manager.StartTime.ToUniversalTime().Ticks
$statusPath=Join-Path $PSScriptRoot 'queue\status.json'
$args=@('-NoProfile','-ExecutionPolicy','Bypass','-File',('"'+$bridgePath+'"'),'-ManagerProcessId',[string]$manager.Id,'-ManagerStartUtcTicks',[string]$ticks,'-ManagerScript',('"'+$managerPath+'"'),'-StatusPath',('"'+$statusPath+'"'))
$bridge=Start-Process -FilePath 'C:\Windows\System32\WindowsPowerShell\v1.0\powershell.exe' -ArgumentList $args -WorkingDirectory $branch -WindowStyle Hidden -RedirectStandardOutput (Join-Path $launchDir 'bridge.stdout.log') -RedirectStandardError (Join-Path $launchDir 'bridge.stderr.log') -PassThru
$record=[ordered]@{status='manager_and_OS_exit_bridge_launched';at=[DateTime]::UtcNow.ToString('o');manager_pid=$manager.Id;manager_start_utc_ticks=$ticks;bridge_pid=$bridge.Id;shared_event_watcher_pid=$watchState.pid;manager_script=$managerPath;bridge_script=$bridgePath;directory=$launchDir;periodic_model_wakeup=$false;training_source_changed=$false;seal_sha256=$queueReview.seal_sha256;bridge_sha256=$bridgeReview.source_sha256}
$record | ConvertTo-Json -Depth 6 | Set-Content -LiteralPath (Join-Path $launchDir 'launch.json') -Encoding UTF8
$record | ConvertTo-Json -Depth 6