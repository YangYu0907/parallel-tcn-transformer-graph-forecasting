"""Independent support-mask reconstruction and complete paired error reduction."""
import gate


def run():
    folder=gate.HERE/'support_guard_pilot'
    with gate.exclusive('context_support_guard_arithmetic_audit'):
        np,lim=gate.runtime(False)
        build=gate.read(folder/'BUILD.json')
        for path,digest in build['bindings'].items():gate.need(gate.sha(path)==digest,'Guard prediction identity')
        p=gate.read(gate.HERE/'PROTOCOL.json');fs=gate.read(gate.HERE/'FOLDS.json')
        m=gate.read(p['dataset_manifest']);paths={k:gate.resolve(v['path']) for k,v in m['artifacts'].items()}
        sc=gate.read(paths['scalers.json']);center=np.asarray(sc['price_center'])[0,:,0];scale=np.asarray(sc['price_scale'])[0,:,0]
        q=np.asarray(gate.read(paths['state_thresholds.json'])['thresholds'])[1]
        feat=np.load(paths['features.npy'],mmap_mode='r');reports=[];checks=[]
        metrics=('mae','rmse','near_mae','h12_mae','low_volatility_mae')
        names=('FULL','FULL_SELECTED','CONTEXT_MIX','HORIZON_MIX','CONTEXT_GUARDED','HORIZON_GUARDED')
        for seed in p['seeds']:
            with np.load(gate.HERE/'cache'/f'{seed}_FULL.npz') as z:origins=z['origins']
            with np.load(folder/f'{seed}.npz') as z:row={k:z[k] for k in z.files}
            expected=[]
            for fold in fs:
                t=feat[origins[np.array(fold['train'])]-1];e=feat[origins[np.array(fold['evaluation'])]-1]
                supported=np.ones(e.shape[:2],dtype=bool)
                for field in (0,21,22):supported&=(e[:,:,field]>=t[:,:,field].min(0))&(e[:,:,field]<=t[:,:,field].max(0))
                raw=e[:,:,0].astype(np.float64)*scale+center
                expected.append((~supported)|(np.abs(raw-center)>q))
            mask=np.concatenate(expected)
            gate.need(np.array_equal(mask,row['fallback_mask']),'Independent guard reconstruction')
            for source,target in [('CONTEXT_MIX','CONTEXT_GUARDED'),('HORIZON_MIX','HORIZON_GUARDED')]:
                expected=row[source].copy();expected[mask]=row['FULL'][mask]
                gate.need(np.array_equal(expected,row[target]),'Independent guarded forecast reconstruction')
                checks.append(f'{seed}_{target}')
            def stat(e):
                if e.size==0:return dict(count=0,mae=None,rmse=None)
                return dict(count=int(e.size),mae=float(np.sum(np.abs(e))/e.size),rmse=float(np.sqrt(np.sum(e*e)/e.size)))
            for name in names:
                e=row[name]-row['truth'];s=stat(e)
                s.update(near_mae=stat(e[:,:,:4])['mae'],h12_mae=stat(e[:,:,11])['mae'],
                    low_volatility_mae=stat(e[row['low_volatility']])['mae'],
                    states=[stat(e[row['codes']==i]) for i in range(6)],
                    horizons=[stat(e[:,:,i]) for i in range(12)],nodes=[stat(e[:,i,:]) for i in range(30)])
                reports.append(dict(seed=seed,model=name,**s))
            gate.guard()
        means={name:{k:float(np.mean([r[k] for r in reports if r['model']==name])) for k in metrics} for name in names}
        state_means={name:[{k:float(np.mean([r['states'][i][k] for r in reports if r['model']==name])) for k in ('mae','rmse')} for i in range(6)] for name in names}
        outcomes={}
        for candidate in ('CONTEXT_GUARDED','HORIZON_GUARDED'):
            outcomes[candidate]=dict(improvement_percent={k:100*(1-means[candidate][k]/means['FULL'][k]) for k in metrics},
                main_metrics_all_nonworsening=all(means[candidate][k]<=means['FULL'][k]+1e-9 for k in metrics),
                original_selected_protected=all(means[candidate][k]<=means['FULL_SELECTED'][k]+1e-9 for k in metrics),
                all_states_nonworsening=all(state_means[candidate][i][k]<=state_means['FULL'][i][k]+1e-9 for i in range(6) for k in ('mae','rmse')),
                improving_seeds=sum(r['mae']<next(b['mae'] for b in reports if b['model']=='FULL' and b['seed']==r['seed']) for r in reports if r['model']==candidate))
        result=dict(at=gate.now(),status='exploratory_support_guard_scored',means=means,per_seed=reports,
            state_means=state_means,outcomes=outcomes,coverage=build['coverage'],
            context_beats_guarded_horizon=means['CONTEXT_GUARDED']['mae']<means['HORIZON_GUARDED']['mae'],
            new_fit_updates=0,new_test_targets_read=False,independent_confirmation=False,
            paper_results_replaced=False,selection_scope='Post-diagnosis rule on already inspected June development windows')
        gate.write(folder/'RESULT.json',result)
        gate.write(folder/'AUDIT.json',dict(at=gate.now(),status='passed',checks=checks,
            result_sha256=gate.sha(folder/'RESULT.json'),build_sha256=gate.sha(folder/'BUILD.json'),
            scoring_script_sha256=gate.sha(__file__),coverage_kept='All2646 origins,30nodes,12horizons,3seeds',
            scope='Independent NumPy mask/prediction reconstruction and reductions; not external human review'))
        print(__import__('json').dumps(dict(means=means,outcomes=outcomes,states=state_means,coverage=build['coverage'])),flush=True)

if __name__=='__main__':run()
