from common import *

def main():
    with gate.exclusive('V12 finite event-model TRAIN and admitted development features'):
        np,lim=gate.runtime(False);verify();start_budget()
        import modelmath as mm
        for p,h in gate.read(HERE/'SOURCE_BINDINGS.json')['bindings'].items():assert gate.sha(p)==h,p
        m=gate.read(B/'phase_sampling_support_v3_20260923/dataset/ADDITIVE/manifest.json');paths={k:gate.resolve(v['path']) for k,v in m['artifacts'].items()}
        sc=gate.read(paths['scalers.json']);th=gate.read(paths['state_thresholds.json']);q=np.array(th['thresholds']);center=np.array(th['center'])
        tr=np.load(paths['train_origins.npy'],mmap_mode='r');prices=np.load(paths['raw_prices.npy'],mmap_mode='r');ft=np.load(paths['features.npy'],mmap_mode='r');secs=np.load(paths['timestamps_seconds.npy'],mmap_mode='r')
        last=prices[tr-1,:,0];ex=abs(last-center)>q[1]
        allowed=ex | ((tr%12==0)[:,None])
        rr,nn=np.nonzero(allowed);oo=tr[rr];X=np.empty((len(rr),90),np.float32)
        # Only the rows already admitted by the original TRAIN contract are used.
        for k,o in enumerate(np.unique(oo)):
            ids=np.flatnonzero(oo==o);allx=mm.features(np.asarray(prices[o-72:o]),np.asarray(ft[o-1]),sc)
            assert allx.shape==(30,90);X[ids]=allx[nn[ids]]
            if k%200==0:check(stage='TRAIN_fast_components',origins_processed=k,pairs=len(rr))
        hh=((oo.astype(np.int64)*1103515245 ^ nn.astype(np.int64)*2654435761 ^ 12345)%2147483647)%12
        y=np.asarray(prices[oo+hh,nn,0],float);now=last[rr,nn].astype(float);days=secs[oo-1]//86400
        dates=np.unique(days);split=int(dates[int(len(dates)*.8)])
        fit=(secs[oo+hh]<split*86400-2*86400);cal=days>=split
        event=(abs(y-center[nn])>q[1,nn]);reg=ex[rr,nn];rows=[]
        for mode in (0,1):
            for subset,keep in [('fit',fit),('calibration',cal)]:
                s=keep&(reg==mode)
                rec=dict(mode=mode,subset=subset,pairs=int(s.sum()),dates=len(np.unique(days[s])),events=int(event[s].sum()),nonevents=int((~event[s]).sum()),event_dates=len(np.unique(days[s&event])),nonevent_dates=len(np.unique(days[s&~event])))
                assert rec['events']>=20 and rec['nonevents']>=20 and rec['event_dates']>=3 and rec['nonevent_dates']>=3,'Insufficient event-model support; do not loosen gate'
                rows.append(rec)
        assert set(oo[fit]).isdisjoint(oo[cal]);assert secs[oo[fit]+hh[fit]].max()<secs[oo[cal]-1].min()
        save(ART/'TRAIN.npz',X=X,horizon=hh.astype(np.int8),target_delta=(y-now)/100.,event=event,current_extreme=reg,fit=fit,cal=cal,days=days,origins=oo,nodes=nn,raw_now=now,truth=y)
        h=readnp(ART/'H1_diagnostic.npz');ix=h['eval_indices'];xh=np.empty((len(ix),30,90),np.float32)
        for k,j in enumerate(ix):
            xh[k]=mm.features(h['history72'][j],h['last'][j],sc)
            if k%100==0:check(stage='H1_inputs_only',done=k)
        # Targets from the forensic file are deliberately not passed to features.
        raw=h['raw_last'][ix,:,0];rg=abs(raw-center)>q[1]
        save(ART/'H1_INPUTS.npz',X=xh,raw_now=raw,current_extreme=rg,eval_indices=ix,origins=h['origins'][ix],center=center)
        adm=dict(at=gate.now(),status='passed_event_models_only',TRAIN_pairs=len(rr),feature_count=90,fit_calibration_support=rows,calibration_start_UTC_day=split,purge_days=2,
            training_supervision='Actual future prices and event labels inside old TRAIN; no in-sample FULL/V7 errors used for routing supervision.',
            model_scope='Conditional event and price models; this does not create an out-of-time FULL error library.',
            sampling='All admitted current-extreme pairs; non-extreme pairs only at admitted clock-hour origins. Separate conditional models. One deterministic balanced horizon per TRAIN pair; every H1 horizon evaluated.',
            scaling='Fixed currency100USD and load10000MW; original fixed TRAIN state definitions and admitted calendar/load inputs reused. Calibration only probability temperature.',
            H1='Previously inspected698 origins development only; no H1 labels used by fitting or calibration.',new_test_targets_read=False,
            artifacts={str(p):gate.sha(p) for p in [ART/'TRAIN.npz',ART/'H1_INPUTS.npz']})
        write(HERE/'DATA_ADMISSION.json',adm);check(stage='data_admission_complete');print(json.dumps(adm),flush=True)
if __name__=='__main__':main()
