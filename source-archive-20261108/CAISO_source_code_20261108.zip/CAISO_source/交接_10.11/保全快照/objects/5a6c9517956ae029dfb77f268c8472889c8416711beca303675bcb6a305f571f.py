from runner import *
import ast

def main():
    previous.verify();checked(True)
    assert not (HERE/'PROTOCOL.json').exists()
    for p in HERE.glob('*.py'):ast.parse(p.read_text(encoding='utf-8'))
    # Known-unit toy data; no market labels accessed in registration.
    times=np.arange(60,dtype='int64')*300+100000
    ext=np.column_stack([np.arange(60)*1000.,np.arange(60)*2000.])
    pub=np.column_stack([times-120,times-1800]);caps=np.array([5.,660.]);o=np.array([30,31])
    x=load_features(ext,pub,times,caps,o)
    assert np.array_equal(x[:,:4],np.array([[29,29,12,24],[30,30,12,24]],dtype='float32'))
    assert np.allclose(x[:,4:],[[.4,30/660],[.4,30/660]])
    changed=ext.copy();changed[31:]=1e8
    assert np.array_equal(load_features(changed,pub,times,caps,o),x)
    pp=pub.copy();pp[29,0]=times[29]+1;blocked=False
    try:load_features(ext,pp,times,caps,o)
    except ValueError:blocked=True
    assert blocked
    review=old.read(REVIEW/'RESULT.json');assert review['status']=='historical_TRAIN_source_reuse_checks_passed_not_model_release'
    old.write(HERE/'QA.json',dict(at=old.now(),status='passed',units_and_60min_index=True,origin_age=True,future_input_invariance=True,future_publication_rejected=True))
    paths=list(HERE.glob('*.py'))+[HERE/'QA.json',REVIEW/'review.py',REVIEW/'RESULT.json',REVIEW/'BINDING_REVIEW.json',EM/'PROTOCOL.json',EM/'RESULT.json',EM/'AUDIT.json']
    for fold in [1,2]:paths += [EM/f'probe{fold}'/n for n in ['ORIGINS.npz','STATS.json','REPLAY.npz','SUPPORT.json']]
    m=old.read(old.B/'phase_sampling_support_v3_20260923/dataset/ADDITIVE/manifest.json')
    for n in ['raw_external.npy','raw_external_missing.npy','forecast_publications_seconds.npy','timestamps_seconds.npy']:paths.append(old.B/m['artifacts'][n]['path'])
    old.write(HERE/'PROTOCOL.json',dict(at=old.now(),status='registered_before_fit',
        authorization='User authorized continued training and event-driven evidence-based bounded improvements; prior failed candidates remain closed',
        hypothesis='Available historical system-load forecasts may add information to the price-only recovery probability gate; empirical effect unknown',
        comparison='PRICE versus PRICE_LOAD, identical HGB specification and labels. Information ablation, not evidence that FULL architecture beats equal-information baselines.',
        new_features=NAMES,history='Only o-1 and o-13; o-1 publication cutoff, previously admitted TRAIN histories; no future-target load query; MW divided by fixed1000, age clipped by existing5/660min caps',
        settings=dict(iterations=80,learning_rate=.05,leaves=7,min_leaf=50,l2=1,seed=20260813,early_stopping=False),
        design='Exact same two chronological price-gate probes: 75%dates fitting,24h purge,25%dates evaluation; partially overlapping windows, no new independent test',
        acceptance='Strictly lower cell-mean and date-mean Brier and logloss in BOTH folds, >=5dates each class; original control inference must replay within1e-12',
        budget=dict(fits=4,max_seconds=1800,conditional_fits_this_registration=0),
        next='No automatic expansion: only after source/probability review may separately freeze full-prefix matched-input comparisons; no replacement of V7 or manuscript',
        preserves='All backbones, amplitude heads, point forecasts,18V7/manuscript files; no change of neural elements',
        literature=[dict(doi='10.1016/j.energy.2022.123417',url='https://research-repository.griffith.edu.au/bitstreams/f003c844-829c-4db6-8257-47538355a229/download',
            basis='Author manuscript abstract includes historical prices, reserve capacity, load, VRE and interconnector flows for extreme occurrence prediction',
            boundary='Australian day-ahead occurrence, not a guarantee for CAISO conditional recovery or this six-feature HGB'),
            dict(url='https://arxiv.org/abs/2008.08004',basis='Fair EPF benchmarking and chronological evaluation; augmented information must be disclosed and matched')],
        primary_data_scope='Already inspected historical TRAIN only',protected_files=18,new_test_targets_read=False,
        V7_replaced=False,no_automatic_retry=True,periodic_model_wakeups=False,single_numerical_worker=True,
        launch_memory_GiB=5,runtime_memory_GiB=4,bindings={str(p):old.sha(p) for p in paths}))
    print('Fixed information probe registered; four QA checks passed.')

if __name__=='__main__':main()
