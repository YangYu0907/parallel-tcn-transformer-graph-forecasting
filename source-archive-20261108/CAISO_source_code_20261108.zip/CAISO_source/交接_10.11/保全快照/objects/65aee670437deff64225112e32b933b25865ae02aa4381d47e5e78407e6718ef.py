from model import *
import ast

def qa():
    torch.set_num_threads(1);torch.manual_seed(1)
    net=JointQuantiles(8,np.ones((12,12))*.2,np.ones(12))
    x=torch.randn(17,8);h=torch.arange(17)%12;allow=(h>=4).float();q=net(x,h,allow)
    checks=0
    assert (torch.diff(q,dim=1)>0).all();checks+=1
    assert torch.equal(q[:,MID],torch.zeros(17));checks+=1
    z=torch.linspace(-4,4,17);p=cdf_torch(q,z).detach().numpy()
    assert np.allclose(p,cdf_numpy(q.detach().numpy(),z.numpy()),atol=1e-7);checks+=1
    for j,t in enumerate(Q):
        assert np.allclose(cdf_numpy(q.detach().numpy(),q[:,j].detach().numpy()),t,atol=1e-7);checks+=1
    qd=q.detach().double().requires_grad_();zz=z.double()+.017
    assert torch.autograd.gradcheck(lambda v:cdf_torch(v,zz),qd,eps=1e-6,atol=1e-4);checks+=1
    objective(q,z,z-1,z+1,'JOINT').backward()
    assert all(v.grad is not None and torch.isfinite(v.grad).all() for v in net.parameters());checks+=1
    # Extreme inputs remain finite under bounded output increments and center.
    q2=net(torch.full((17,8),1e5),h,allow).detach().numpy()
    assert np.isfinite(q2).all() and (np.diff(q2)>0).all();checks+=1
    assert np.array_equal(q2[h.numpy()<4,MID],np.zeros(int((h<4).sum())));checks+=1
    test=np.tile(np.arange(-6,7,dtype=float),(16,1));target=np.linspace(-10,10,16)
    dd=dict(h=np.zeros(16,int),cal=np.arange(16)<8,residual=target)
    cal,_=calibrate(test,dd);assert np.array_equal(cal[:,MID],test[:,MID]) and (np.diff(cal)>0).all();checks+=1
    # Symmetric exponential-tailed quantile distribution has mean zero.
    assert np.allclose(mean_numpy(test),0);checks+=1
    # Previously bound feature functions use supplied past history, never targets.
    point=np.zeros((2,30,12));last=np.zeros((2,30,29));experts=np.zeros((2,30,12,5))
    xx=legacy.ca_features(last,point,experts,np.zeros(30),np.ones(30))
    assert xx.shape[0]==point.size and np.isfinite(xx).all();checks+=1
    write(HERE/'QA.json',dict(at=old.now(),status='passed',checks=checks,gradient_check=True,monotone_cdf=True,
        distribution_tail_model='piecewise linear quantile interior and fixed exponential tails; a modeling choice, not market law'))

def prepare_one(task,seed):
    d=legacy.load_data(task,seed);shape=d['y'].shape;n,l,nh=shape
    fit,cal,ev=[z.ravel() for z in d['masks']];days=np.repeat(d['cutoff']//86400,l*nh)
    horizon=np.tile(np.arange(nh),n*l);node=np.tile(np.repeat(np.arange(l),nh),n)
    med=np.median(d['X'][fit],axis=0);iq=np.quantile(d['X'][fit],[.25,.75],axis=0)
    spread=np.maximum(iq[1]-iq[0],1e-3);unclipped=(d['X']-med)/spread
    X=np.clip(unclipped,-6,6).astype('float32')
    assert np.isfinite(X).all();residual=d['residual'].ravel().astype('float32')
    gaps=[];cap=[]
    for h in range(nh):
        rr=residual[fit&(horizon==h)];qq=np.quantile(rr,Q)
        gaps.append(np.maximum(np.diff(qq),1e-4));cap.append(max(.05,float(np.quantile(abs(rr),.99))))
    truth=d['y'].ravel();point=d['point'].ravel();scale=d['scale'][node]
    # All new signed-event thresholds fit on first-stage labels only; old states kept separately.
    limits=np.array([np.quantile(truth[fit&(node==i)],[.01,.99]) for i in range(l)])
    low=limits[node,0];high=limits[node,1]
    allow=(horizon>=4).astype('float32') if task=='CAISO' else np.ones(len(truth),'float32')
    parts=[]
    for role,mask in [('fit',fit),('calibration',cal),('forward_development',ev)]:
        st=[]
        for s in np.unique(d['state']):
            sm=mask&(d['state'].ravel()==s);st.append(dict(state=int(s),cells=int(sm.sum()),dates=len(np.unique(days[sm]))))
        parts.append(dict(role=role,cells=int(mask.sum()),dates=len(np.unique(days[mask])),states=st,
            first_UTC=str(np.array(d['cutoff'][np.any(mask.reshape(shape),(1,2))].min()).astype('datetime64[s]')),
            last_UTC=str(np.array(d['cutoff'][np.any(mask.reshape(shape),(1,2))].max()).astype('datetime64[s]')),
            clipped_feature_values=int((abs(unclipped[mask])>6).sum())))
    assert days[fit].min()<=days[fit].max()<=days[cal].min() and days[cal].max()<=days[ev].min()
    # Labels in later blocks cannot change fit normalization/thresholds.
    yy=truth.copy();yy[~fit]=1e9
    assert np.array_equal(limits,np.array([np.quantile(yy[fit&(node==i)],[.01,.99]) for i in range(l)]))
    path=HERE/'data'/f'{task}_{seed}.npz'
    save(path,X=X,truth=truth,point=point,scale=scale,residual=residual,fit=fit,cal=cal,evaluate=ev,
        h=horizon,node=node,days=days,origin=np.repeat(d['origin'],l*nh),state=d['state'].ravel(),
        observable=d['observable'].ravel(),threshold_lo=low,threshold_hi=high,
        risk_lo=((low-point)/scale).astype('float32'),risk_hi=((high-point)/scale).astype('float32'),
        allow=allow,gaps=np.array(gaps),cap=np.array(cap),feature_center=med,feature_scale=spread,shape=np.array(shape))
    return dict(task=task,seed=seed,parts=parts,features=d['features'],rows=len(truth),columns=X.shape[1],
        path=str(path),sha256=sha(path),near_preservation='CAISOH1-H4exact;Europe all horizons eligible',
        threshold_definition='per-location1%/99% of first fit-block prices, frozen. Different from original price-deviation states, which remain intact.',
        threshold_values=limits.tolist())

def main():
    checked(True);assert not (HERE/'PROTOCOL.json').exists();assert old.verify_protected()==18
    for f in HERE.glob('*.py'):ast.parse(f.read_text(encoding='utf-8'))
    binding=read(old.FIRST/'PROBABILITY_SOURCE_BINDINGS.json')
    for p,h in binding.items():assert sha(p)==h,p
    with old.numeric('Unified distribution preparation and synthetic verification'):
        qa();rows=[]
        for task in TASKS:
            for seed in SEEDS:checked();rows.append(prepare_one(task,seed))
    write(HERE/'ADMISSION.json',dict(at=old.now(),status='known_development_reuse_passed',rows=rows,
        prepared={x['path']:x['sha256'] for x in rows},source_hashes=len(binding),new_independent_test=False,
        scope='Same already inspected698H1 origins split245/259/194;Europe2015 split fit/cal/forward. Original independent evaluations not repeated.',
        inherited_contract='Bound retrospective V7 source/audit caches; not new real-time publisher certification'))
    sources=list(HERE.glob('*.py'))+[HERE/'QA.json',HERE/'ADMISSION.json',old.FIRST/'PROBABILITY_SOURCE_BINDINGS.json',
        old.FIRST/'PROBABILITY_RESULT.json',old.FIRST/'PROBABILITY_INDEPENDENT_AUDIT.json',
        old.B/'spike_specialist_v7_20260930/AUDIT.json',old.B/'spike_specialist_v7_20260930/PROTOCOL.json',
        old.B/'spike_specialist_v7_20260930/DATA_ADMISSION.json',old.FIRST/'CONFIRMATION_ADMISSION_STATUS.json']
    sources += [Path(legacy.__file__),R/'common.py',old.FIRST/'revision_common.py',R/'integrated_regime_20261003/core.py']
    sources += [Path(x) for x in binding]
    write(HERE/'PROTOCOL.json',dict(at=old.now(),status='registered_before_any_new_fit',
        authorization='User explicitly requests start of coherent finite full-system trial',
        primary='JOINT_CAL;no posthoc promotion of another arm',tasks=TASKS,seeds=SEEDS,
        arms=ARMS,neural_fits=18,independent_quantile_fits=78,
        architecture='Frozen V7(CAISO)/FULL(Europe);32-32SiLU shared residual network;13ordered quantiles. Center bounded by fit-onlyq99abs residual;positive increments ratio bounded[.25,4] around fit-only empirical spacings;piecewise-linear quantile interior and exponentialtails. Risk probabilities derive from sameCDF.',
        originality='Literature-inspired bounded implementation, not I(S)QF or DDNN replication. No new graph construction or universal mechanism superiority claim.',
        levels=Q.tolist(),neural_settings=dict(epochs=40,batch=1024,lr=.001,weight_decay=.0001,gradient_clip=1.,selection='fixedfinalepoch'),
        loss='mean13pinball+medianabsoluteerror+sumof2signedendpointBriers,natural frequencies,no rare-event weights. NO_RISK removesBrier;FIXED_POINTforcesallmedian corrections0.',
        controls='INDEPENDENT:13HGBquantile heads,60iterations,7leaves,minleaf100,lr.05,l2=1,identicalX/splits. Samefitq99 median cap and near-output protection;sort and preserve relative quantile widths. HIST:fit-only horizon residual shape anchored to incumbent median;same calibration.',
        protection='CAISOH1-H4point forecasts bitwise V7. Other horizons must pass full empirical retention screen; no guarantee. Europe original point baseline retained separately.',
        calibration='Same heldout chronological block for all5arms;CQR80/90expansion extended monotonically to allquantiles,median unchanged. No finite-sample coverage claim under dependence.',
        inference='No future-defined states used as inputs or routers. Event probability is endpoint exceedance, not first-passage or trajectory probability. Mean is supplementary and not substituted for primary median.',
        scope='Known development only; no fresh confirmatory targets or backbone fitting. Three retained backbone seeds and three matching head seeds; no independent-date multiplication.',
        acceptance='JOINT_CAL overallMAE strictly lower than incumbent,RMSE and everyhorizon/state MAE/RMSE nonworse averagedover3seeds;atleast2seedsoverallMAEimprove;eachstate>=5dates elseinsufficient. WIS lowerthanHIST_CAL andINDEPENDENT_CAL;80/90coverage absoluteerror nonworse thanHIST_CAL andwidth/WIS disclosed. BothsignedBrier/logloss nonworse thanHIST_CAL;eventsupport>=5dates. Cal andforward checks separate, both required. No fallback promotion if failed.',
        statistics='Exploratory paired calendar7dayblocks,actual gaps,seed-mean cellloss;2000bootstrap;JOINT_CALvsHIST_CAL/INDEPENDENT_CAL/NO_RISK_CAL/FIXED_POINT_CAL forMAE,RMSE,H12MAE,WIS asone16comparisonHolmfamily per task.',
        budget_seconds=86400,hyperparameter_search=False,automatic_retries=False,
        failure_policy='Preserveallresults;completefinitecomparisonunlessresource/code/stopbarrier;no automaticexpansion. No real-data correctness error may be silently repaired after outcome access.',
        literature=[dict(url='https://proceedings.mlr.press/v151/park22a.html',scope='noncrossing quantile representation'),dict(url='https://proceedings.mlr.press/v89/gasthaus19a.html',scope='spline quantile distribution'),dict(url='https://arxiv.org/abs/2207.02832',scope='distributional EPF motivation'),dict(url='https://arxiv.org/abs/1905.03222',scope='CQR,dependence limitation retained'),dict(url='https://arxiv.org/abs/0912.0902',scope='declared median and mean functionals')],
        launch_memory_GiB=5,runtime_memory_GiB=4,single_numerical_worker=True,
        bindings={str(p):sha(p) for p in sources},V7_replaced=False,new_test_targets_read=False,periodic_model_wakeups=False))
    print('Registered unified finite batch:18neural+78scalarquantile fits;6prepared seeds/tasks.')
if __name__=='__main__':main()
