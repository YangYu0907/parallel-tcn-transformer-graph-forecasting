"""Separate implementation: raw CSV, release binding and feature reconstruction.
Same operator, separate audit program; not an independent human review.
"""
from resolve_source import *
from collections import defaultdict
import math
def stamp(s):return int(datetime.fromisoformat(s.replace('Z','+00:00')).timestamp())
def query_stamp(s):return int(datetime.strptime(s,'%Y%m%dT%H:%M-0000').replace(tzinfo=timezone.utc).timestamp())
def csvrows(p):
 with zipfile.ZipFile(p) as z:
  for name in z.namelist():
   assert z.getinfo(name).file_size<=150000000
   with z.open(name) as raw:
    if name.lower().endswith('.csv'):
     yield from csv.DictReader(io.TextIOWrapper(raw,encoding='utf-8-sig'))
    else:
     b=raw.read().decode('utf-8','replace');assert '<ERR_CODE>1000</ERR_CODE>' in b or 'No data returned' in b
def main():
 reg=c.read(H/'ACQUISITION_PROTOCOL.json');result=c.read(H/'ADMISSION_RESULT.json');checks=[]
 def ck(ok,label):
  if not ok:raise AssertionError(label)
  checks.append(label)
 ck(c.sha(H/'FEATURE_CONTRACT.json')==reg['contract_sha256'],'contract_frozen')
 receipts=c.read(H/'RECEIPTS.json');ck(len(receipts)==len(reg['jobs'])==68,'all68requests_complete')
 ck([x['id'] for x in receipts]==[x['id'] for x in reg['jobs']],'exact_registered_queue')
 revisions=[x for x in receipts if x['kind']=='revision']
 spans=[(query_stamp(x['params']['startdatetime']),query_stamp(x['params']['enddatetime'])) for x in revisions]
 ck(all(spans[i][1]==spans[i+1][0] for i in range(len(spans)-1)),'later_revision_history_contiguous')
 ck(spans[0][0]<=min(reg['cutoff'])-3600,'revision_history_starts_before_inputs')
 ck(spans[-1][1]>max(stamp(r['at']) for r in receipts),'revision_history_covers_raw_retrieval')
 ck(min(stamp(r['at']) for r in revisions)>max(stamp(r['at']) for r in receipts if r['kind']=='award'),'revisions_retrieved_after_awards')
 pubs={};awards={};dup=0
 for i,(r,job) in enumerate(zip(receipts,reg['jobs'])):
  c.guard();ck(r['params']==job['params'],r['id']+':params')
  ck(c.sha(r['body'])==r['sha256'],r['id']+':raw_hash')
  ck(c.sha(r['ledger'])==r['ledger_sha256'],r['id']+':ledger_hash')
  n=0;selected=[]
  for row in csvrows(r['body']):
   n+=1
   if r['kind']=='award':
    assert row['MARKET_RUN_ID']=='RTD' and row['DATA_ITEM']=='AGGR_FLEX_RAMP_MW'
    pair=(row['BAA_GRP'],row['PRODUCT'])
    if pair not in [('FRU_PASS_GRP','UP'),('FRD_PASS_GRP','DOWN')]:continue
    a,b=stamp(row['INTERVALSTARTTIME_GMT']),stamp(row['INTERVALENDTIME_GMT'])
    assert b-a==300
    try:v=float(row['MW'])
    except ValueError:continue
    if not math.isfinite(v):continue
    key=(pair[1],a,b)
    if key in awards:ck(awards[key]['value']==v,'identical_overlap_'+str(key));dup+=1
    awards[key]=dict(value=v,source=r['body'],sha=r['sha256'])
   else:
    assert row['MARKET_RUN_ID']=='RTD'
    if r['kind']=='revision':assert row['ATLPUBVERSION']=='Revised'
    if row['REPORT_NAME']!='ENE_AGGR_FLEX_RAMP':continue
    selected.append(row)
    if row['STATUS']!='Push Completed' or row['OASIS_REC_STAT']!='V':continue
    pid=row['PUBLICATION_ID']
    if pid in pubs:assert row==pubs[pid]
    pubs[pid]=row
  ck(n==r['rows'],r['id']+':rows')
  ck(selected==c.read(r['ledger']),r['id']+':ledger_exact_raw')
  c.write(H/'AUDIT_PROGRESS.json',dict(at=c.now(),raw_files=i+1,total=len(receipts)))
 new=defaultdict(list);rev=[]
 for p in pubs.values():
  q=(stamp(p['INTERVAL_START_GMT']),stamp(p['INTERVAL_END_GMT']),stamp(p['PUBLICATION_DATE_GMT']),p['PUBLICATION_ID'])
  if p['ATLPUBVERSION']=='New':new[q[:2]].append(q)
  elif p['ATLPUBVERSION']=='Revised':rev.append(q)
  else:raise AssertionError('unknown version')
 eligible={'UP':[],'DOWN':[]}
 for (direction,a,b),row in awards.items():
  initial=new.get((a,b),[])
  if len(initial)!=1:continue
  changing=[p for p in rev if p[0]<b and p[1]>a]
  pub=max(initial+changing,key=lambda p:p[2])
  eligible[direction].append(dict(start=a,end=b,pub=pub,value=row['value'],source=row['source'],sha=row['sha']))
 for direction in eligible:eligible[direction].sort(key=lambda r:r['end'],reverse=True)
 traces=c.read(H/'ORIGIN_SOURCE_TRACE.json')['rows'];ck(len(traces)==len(reg['origins']),'trace_count')
 features=[]
 for ii,tr in enumerate(traces):
  assert tr['origin']==reg['origins'][ii] and tr['cutoff']==reg['cutoff'][ii]
  values={};cut=tr['cutoff']
  for dr in ['UP','DOWN']:
   selected=[]
   for label,deadline in [('current',cut),('lag30',cut-1800)]:
    expected=next((r for r in eligible[dr] if 0<=deadline-r['end']<=1800 and r['pub'][2]<deadline),None)
    claimed=tr['choices'][dr][label]
    assert (expected is None)==(claimed is None)
    if expected is not None:
     assert expected['value']==claimed['value'] and expected['start']==claimed['start'] and expected['end']==claimed['end']
     assert expected['pub'][3]==claimed['publication']['id'] and expected['pub'][2]==claimed['publication']['published']
     assert c.sha(claimed['source'])==claimed['source_sha256']==expected['sha']
    selected.append(expected)
   current,lag=selected;ok=current is not None and lag is not None
   assert ok==tr['choices'][dr]['usable']
   values[dr]=[current['value'],current['value']-lag['value'],(cut-current['end'])/60,0] if ok else [0,0,60,1]
  u,d=values['UP'],values['DOWN'];features.append([u[0],d[0],u[1],d[1],u[2],d[2],u[3],d[3]])
  checks.append('origin_'+str(tr['origin'])+':both_directions_two_times_raw_reconstruction')
 with c.numeric('Separate new source coverage/feature audit'):
  import numpy as np
  with np.load(H/'FEATURES.npz') as z:
   ck(np.array_equal(z['X'],np.asarray(features)),'all8features_exact')
   ck(np.array_equal(z['origins'],reg['origins']) and np.array_equal(z['cutoff'],reg['cutoff']),'all_origins_preserved')
   ok=(z['X'][:,6:]==0).all(1)
  windows=c.read(H/'WINDOWS.json');indices=np.asarray(windows['original_panel_indices']);wc=[]
  for w in windows['windows']:
   for part in ['fit','calibration','evaluation']:
    ix=indices[w[part]];wc.append(dict(window=w['id'],part=part,origins=len(ix),usable=int(ok[ix].sum()),fraction=float(ok[ix].mean())))
  coverage_pass=all(x['fraction']>=.9 for x in wc) and bool(result['admission_passed'])
  ck(c.verify_protected()==18,'all18protected_files_unchanged')
 audit=dict(at=c.now(),status='passed' if coverage_pass else 'valid_reconstruction_insufficient_coverage',
    admission_passed=coverage_pass,implementation_checks=len(checks),checks=checks,new_window_coverage=wc,
    source_families=1,features=8,raw_files=len(receipts),new_fits=0,new_test_targets_read=False,
    independent_human_review=False,review_type='Separate raw-data reconstruction program by same operator',
    limitation=result['scope'],bindings={str(H/n):c.sha(H/n) for n in ['FEATURE_CONTRACT.json','ACQUISITION_PROTOCOL.json','RECEIPTS.json','FEATURES.npz','WINDOWS.json','ORIGIN_SOURCE_TRACE.json','ADMISSION_RESULT.json','audit_source.py']})
 c.write(H/'SOURCE_AUDIT.json',audit)
 print(json.dumps({k:audit[k] for k in ['status','admission_passed','implementation_checks','new_window_coverage']},ensure_ascii=False))
if __name__=='__main__':main()
