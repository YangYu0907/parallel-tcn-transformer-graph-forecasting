from diagnose import *

def main():
    verify();r=old.read(HERE/'RESULT.json');a=old.read(HERE/'AUDIT.json');g=old.read(HERE/'GROUP_AUDIT.json')
    assert a['result_sha256']==g['result_sha256']==old.sha(HERE/'RESULT.json')
    assert old.parent.verify_protected()==18
    lines=['尖峰分量与门控错误归因：完整历史诊断',
        '本轮没有训练新模型，没有改变V7、论文、冻结预测或任何既有结果。原负荷门控事件已去重。',
        '', '主要事实',
        '同一负荷门控在两个内层时间窗口都改善了S3/S4概率误差，但增大S5概率误差。',
        'S3/S4是当前极端、未来端点回到非极端；S5是未来端点仍极端。S5并不必然表示全段持续极端。',
        '加负荷后，S5样本上的平均回落概率从约0.46升至0.52-0.54；这些样本的回落标签实际为0。',
        '因此前述总体失利有可核对的组内来源：更多回落判断帮助了真正回落的组，却伤害了端点仍极端的组。',
        '这不是证明所有外生信息无效，也不是确认唯一物理原因。',
        '', '一、原负荷试验的分组概率结果：Brier越小越好']
    for panel in r['load_probe_groups']:
        lines.append(f"内层窗口{panel['fold']}：与load_gate_probe相同样本、相同拟合前缀阈值。")
        for row in panel['groups']:
            change=100*(row['load_brier']/row['price_brier']-1)
            lines.append(f"S{row['state']}：{row['cells']}单元/{row['dates']}UTC日期；价格门控{row['price_brier']:.6f} -> 负荷门控{row['load_brier']:.6f}；相对误差变化{change:+.2f}%；回落概率均值{row['mean_price_recovery_probability']:.4f} -> {row['mean_load_recovery_probability']:.4f}；平方概率误差总和变化{row['total_brier_difference']:+.6f}。")
    lines += ['', '二、LMP分量变化的完整分组：与上述内层窗口分开报告',
        '下面来自已经检查的历史TRAIN前推面板，使用各自此前冻结的状态阈值；不是V7独立测试结果。',
        '分量绝对变化占比 = 全部选定单元的|目标分量-起点分量|之和 / 能量、拥塞、损耗三项绝对变化总和。',
        '它是价格变化的会计分解，不是模型RMSE贡献、因果贡献、事件占比或可预测性。未来分量只用于事后解释。',
        '相关预测单元不能算独立事件；完整机器结果另有起点、日期、起点-节点及目标-节点计数。']
    for panel in r['full_forward_panels']:
        lines.append(f"前推窗口{panel['fold']}：{panel['first_cutoff']}至{panel['last_target']} UTC；{panel['origins']}起点/{panel['dates']}日期；LMP三分量恒等式最大误差{panel['identity_max_abs_USD']:.9f} USD/MWh。")
        for row in panel['rows']:
            if not row['cells']:
                lines.append(f"{row['horizons']} S{row['state']}：无样本。")
                continue
            shares='/'.join(f'{100*v:.2f}%' for v in row['abs_change_share'])
            lines.append(f"{row['horizons']} S{row['state']}：{row['cells']}单元/{row['dates']}日期；能量/拥塞/损耗绝对变化占比={shares}；匹配BASE MAE={row['base_MAE']:.6f}，路由初始化平均RMSE={row['base_RMSE_mean_router']:.6f}。")
    lines += ['', '三、解释与待验证假设',
        'H8-H12的新尖峰S2中，2024Q4拥塞绝对变化占60.83%；2025年1-5月则能量占69.11%。',
        '2025年1-5月的S3回落主要伴随能量分量变化（74.53%），S5端点仍极端的组则主要伴随拥塞分量变化（88.54%）。',
        '这些变化构成差别为“总价混合了不同结构、单一系统负荷信号未能稳定分辨”的假设提供方向，但没有检验历史分量是否足够提前区分。',
        '不能把2025年的比例推广到全部时期：2024Q4的S5能量和拥塞占比为55.65%和42.15%。',
        '最近几轮只作用于当前已极端的H8-H12；S2新尖峰不在其作用范围，因此不能把这些门控试验说成已经解决新尖峰。',
        '仍需区分分布变化、有限事件样本、可用信号不足及模型拟合不稳，不宣称任何一项已被证明为唯一原因。',
        '', '四、下一项有限对照建议（未启动、未作为已完成注册）',
        '先检验预测时点可用的历史能量/拥塞分量对情景门控的增量价值，暂不同时改变网络、损失、阈值和修正幅度。',
        '对照应包括原价格门控、已完成的负荷门控和唯一的新分量门控；重用结果前必须核准相同父模型、样本、拟合随机性和预算。',
        '分量门控只能用截止时刻以前的水平、变化与空间分布，不能用未来状态或目标分量路由；全部输入增加须披露。',
        '先检验两个既有时间窗口的总体及日期等权概率误差，同时守住S3/S4改善并检查S5；失败关闭，不按某个好子组选择模型。',
        '即使概率筛选通过，仍需固定完整前缀推理、匹配价格误差与各状态保留检查、新独立时间确认，才能更新论文；不能把信息增益当成架构优越性。',
        '潜在收益：有机会区分能量共同变化和局部拥塞变化；成本：增加输入、匹配重评与确认。没有保证全指标正向的理论。',
        '', '五、原始来源与阅读范围',
        'CAISO Day-Ahead Market Overview，官方历史培训材料：能量+拥塞+损耗=LMP，支持会计恒等式，不为预测性能背书。',
        'https://www.caiso.com/documents/presentation-existing-day-ahead-market-overview.pdf',
        'Godin F, Ibrahim Z. An analysis of electricity congestion price patterns in North America. Energy Economics2021;102:105506. DOI10.1016/j.eneco.2021.105506。已核验出版社摘要和引言；论文先分析拥塞分量，再讨论随机模型。不是本研究CAISO结果的独立证据，也不在此声称已核验当前期刊分区。',
        'https://www.sciencedirect.com/science/article/pii/S0140988321003893',
        '', '六、核验',
        f"另行循环公式复算{a['checks']}项、标量状态/概率核算{g['checks']}项通过；由同一操作者运行独立计算实现，未声称外部人工审核。",
        '18个V7/论文保护文件哈希不变；无新测试目标访问；没有后台训练进程；保留本地文件事件监听，不恢复定时唤醒。']
    (HERE/'REPORT_CN.txt').write_text('\n'.join(lines)+'\n',encoding='utf-8')
    old.write(HERE/'NEXT_DESIGN.json',dict(at=old.now(),status='proposal_only_not_registered_or_started',
        question='Does strictly historical LMP component information improve the failed recovery-versus-extreme probability discrimination?',
        candidate='One component-informed gate; preserve all point heads and required backbone elements',
        controls=['original PRICE gate','previous PRICE_LOAD gate'],
        prohibited='No future-state routing, target component predictors, hyperparameter grid, silent unmatched-input superiority or automatic V7 replacement',
        needed_before_fit=['freeze exact historical feature formulas and source lineage','freeze same-algorithm comparison and all retention criteria','guarded launch and identity-bound exit monitor'],
        benefits='Potential new signal for distinguishing energy and congestion behavior',costs='Input expansion, matched benchmarking and fresh confirmation',model_fits=0))
    old.write(HERE/'CLOSEOUT.json',dict(at=old.now(),status='descriptive_component_diagnosis_complete',
        result_sha256=old.sha(HERE/'RESULT.json'),audit_sha256=old.sha(HERE/'AUDIT.json'),group_audit_sha256=old.sha(HERE/'GROUP_AUDIT.json'),
        report_sha256=old.sha(HERE/'REPORT_CN.txt'),new_fits=0,protected_files=18,new_test_targets_read=False,V7_replaced=False,
        new_background_manager=False,new_event_emitted=False,reason_no_event='Foreground result reported directly; avoid creating redundant wakeup for already handled evidence'))
    event=B/'event_driven_automation/inbox/load_gate_probe_needs_analysis_c04cf96d0dadb0eda8282c31037d3a61985e7ef9fd1eb62b4f00e4faea5efb3e.json'
    ev=old.read(event);assert old.sha(ev['evidence_path'])==ev['evidence_sha256']
    old.write(R/'load_gate_probe_20261004/DELIVERY_REVIEW_18450005.json',dict(at=old.now(),
        delivery_id='184500059532a17aaf4610c9c95edaee341e51f62fdca93ce51e8070d3eb2e10',event_id=ev['event_id'],
        status='verified_and_deduplicated',already_reported=True,repeated_fits=0,continuation='Read-only component diagnosis',
        continuation_report=str(HERE/'REPORT_CN.txt')))
    hand=old.read(B/'HANDOFF.json');hand['last_action_at']=old.now();hand['latest_status']='component_diagnosis_complete_no_new_training'
    hand['component_diagnosis_20261004']=dict(directory=str(HERE),stage='descriptive_audits_passed',
        result_sha256=old.sha(HERE/'RESULT.json'),audit_sha256=old.sha(HERE/'AUDIT.json'),group_audit_sha256=old.sha(HERE/'GROUP_AUDIT.json'),
        report=str(HERE/'REPORT_CN.txt'),checks=a['checks']+g['checks'],model_fits=0,V7_replaced=False,new_test_targets_read=False,
        next_design=str(HERE/'NEXT_DESIGN.json'),next_training_started=False)
    hand['next_actions']=[
        'Do not repeat the load-gate or regularized-gate fits/notifications. RetainedV7/18protected files unchanged.',
        'Read component_diagnosis_20261004 report: load gate helped S3/S4 but worsened S5 in both inner probes. LMP component accounting differs by period; not a causal or predictability finding.',
        'If proceeding, preregister one history-only component-information gate and exact matched controls/retention tests before fitting. NEXT_DESIGN is a proposal, not a launched experiment.',
        'Recent recovery gates do not address S2 onset. Keep onset and recovery tasks distinct; independently confirm any candidate before manuscript promotion.',
        'Keep local event listener and process-identity exit monitoring for future managers. No scheduled model wakeups. Full research remains unfinished.'
    ]
    old.write(B/'HANDOFF.json',hand)
    print('Diagnostic report saved; event deduplicated; no new fits or wakeup.')

if __name__=='__main__':main()
