"""Native transport extended only by durable quota accounting; scientific source/decoder unchanged."""
import sys,os,time,json,hashlib,threading,subprocess,traceback,importlib.util,re
from pathlib import Path
from datetime import datetime,timezone
from email.utils import parsedate_to_datetime
from concurrent.futures import ThreadPoolExecutor,as_completed
N=Path(__file__).resolve().parent
sys.path.append(str(N.parent))
import source_support as s
spec=importlib.util.spec_from_file_location('weather_decode',N/'decoder.py')
m=importlib.util.module_from_spec(spec);spec.loader.exec_module(m)
LOCK=threading.Lock();CANCEL=threading.Event();COUNTS={'reserved_bytes':0,'reserved_requests':0};RAW_RESERVATIONS={}
AWS='https://noaa-hrrr-bdp-pds.s3.amazonaws.com/'
MIRROR='https://storage.googleapis.com/high-resolution-rapid-refresh/'

def write(name,data):s.write(N.name+'/'+name,data)
def check(q):
    s.guard()
    for folder in [N,s.N]:
        if (folder/'STOP_REQUESTED.json').exists() or (folder/'STOP_REQUESTED').exists():raise InterruptedError('Explicit native transport stop')
    if CANCEL.is_set():raise InterruptedError('Native transport cancelled')
def quote(v):return '"'+str(v).replace('\\','/').replace('"','\\"')+'"'

def single_part_identity(x):
    return re.fullmatch(r'"[0-9a-fA-F]{32}"', x['source']['etag']) is not None

def endpoint_for(x, attempt):
    # Cross-provider MD5 equivalence is unavailable for opaque/multipart ETags.
    # Such objects are fetched only from the frozen original S3 key.
    return AWS if x['key'].endswith('.idx') or attempt > 0 or not single_part_identity(x) else MIRROR

def request_identity(x, url):
    return dict(url=url, key=x['key'], if_match=x['source']['etag'],
                range=x.get('range'), bytes=x['size'])

def retry_delay(q, attempt=0, transient=False):
    schedule=q.get('transient_retry_backoff_seconds',[])
    if transient and schedule:
        assert all(0 <= float(x) <= 300 for x in schedule), 'Bounded network backoff'
        return float(schedule[min(attempt,len(schedule)-1)])
    delay=float(q.get('retry_backoff_seconds',0))
    assert 0 <= delay <= 5, 'Bounded validation retry delay'
    return delay

def retry_wait(q, attempt=0, transient=False):
    delay=retry_delay(q,attempt,transient)
    until=time.monotonic()+delay
    while time.monotonic()<until:
        check(q)
        time.sleep(min(.2,max(0,until-time.monotonic())))
    check(q)

def complete_part(x):
    x.pop('request_provenance', None)
    hp=Path(str(x['path'])+'.headers')
    if not x['path'].exists() or not hp.exists() or x['path'].stat().st_size!=x['size']:return False
    headers={};status=None
    for line in hp.read_text(encoding='utf-8',errors='replace').splitlines():
        if line.startswith('HTTP/'):status=int(line.split()[1]);headers={}
        elif ':' in line:
            k,v=line.split(':',1);headers[k.lower()]=v.strip()
    if status!=(206 if x.get('range') else 200):return False
    assert headers['etag']==x['source']['etag']
    if x.get('range'):
        provenance_path=Path(str(x['path'])+'.request.json')
        if provenance_path.exists():
            request=json.loads(provenance_path.read_text(encoding='utf-8'))
            assert request['url'] in [AWS+x['key'], MIRROR+x['key']]
            assert request==request_identity(x,request['url']), 'Request identity mismatch'
            x['request_provenance']=request
            x['retrieval_url']=request['url']
        if not single_part_identity(x):
            assert x.get('request_provenance')==request_identity(x,AWS+x['key']), 'Opaque ETag requires original-source request evidence'
            assert parsedate_to_datetime(headers['last-modified']).timestamp()==x['source']['last_modified_seconds'], 'Original source timestamp mismatch'
        elif x.get('retrieval_url')==AWS+x['key']:
            assert parsedate_to_datetime(headers['last-modified']).timestamp()==x['source']['last_modified_seconds']
        assert parsedate_to_datetime(headers['last-modified']).timestamp()<=x['source']['minimum_qualified_cutoff']
    else:
        assert parsedate_to_datetime(headers['last-modified']).timestamp()==x['source']['last_modified_seconds']
    assert int(headers['content-length'])==x['size']
    if x.get('range'):
        left,right=x['range'];assert headers['content-range']==f'bytes {left}-{right}/{x["source"]["bytes"]}'
    x['headers']=headers;return True

def valid_or_rejected(x):
    try:return complete_part(x)
    except (AssertionError,KeyError,ValueError,TypeError) as error:
        # A rejected mirror object is never used. Only the registered original
        # source may be attempted next with the identical identity constraints.
        x['rejected_validation']=repr(error)
        return False

def transient_failure(returncode, specs):
    if returncode in [5,6,7,18,28,35,52,55,56]:
        return True
    if returncode != 22:
        return False
    statuses=[]
    for x in specs:
        hp=Path(str(x['path'])+'.headers')
        if hp.exists():
            statuses.extend(int(line.split()[1]) for line in hp.read_text(encoding='utf-8',errors='replace').splitlines() if line.startswith('HTTP/'))
    # Never turn authentication, missing-source, or version errors into network retries.
    errors=[status for status in statuses if status >= 400]
    return bool(errors) and all(status in [408,429,500,502,503,504,522,524] for status in errors)

def batch(specs,q,folder,label,attempt=0):
    if not specs:return
    specs=[x for x in specs if not valid_or_rejected(x)]
    if not specs:return
    check(q);folder.mkdir(parents=True,exist_ok=True)
    reserve(specs,q)
    text=[]
    for k,x in enumerate(specs):
        if k:text.append('next')
        endpoint=endpoint_for(x,attempt)
        x['retrieval_url']=endpoint+x['key']
        request=request_identity(x,x['retrieval_url'])
        Path(str(x['path'])+'.request.json').write_text(json.dumps(request),encoding='utf-8')
        connect=int(q.get('connect_timeout_seconds',10))
        assert 1 <= connect <= 30, 'Bounded connection timeout'
        text+=['silent','show-error','fail','max-time = 240','connect-timeout = '+str(connect),'speed-limit = 1024','speed-time = 30',
            'max-filesize = '+str(x['size']),'url = '+quote(x['retrieval_url']),
            'header = '+quote('If-Match: '+x['source']['etag']),
            'output = '+quote(x['path']),'dump-header = '+quote(str(x['path'])+'.headers')]
        if x.get('range'):text.append('range = '+quote(str(x['range'][0])+'-'+str(x['range'][1])))
    tag=label if attempt==0 else label+'_r'+str(attempt)
    config=folder/(tag+'.curl');config.write_text('\n'.join(text)+'\n',encoding='utf-8')
    with (folder/(tag+'.stderr')).open('wb') as err:
        process=subprocess.Popen(['curl.exe','--fail-early','--config',str(config)],stdout=subprocess.DEVNULL,stderr=err)
        try:
            while process.poll() is None:
                check(q);time.sleep(.2)
            returncode=process.returncode
        finally:
            if process.poll() is None:process.terminate();process.wait(timeout=5)
    missing=[x for x in specs if not valid_or_rejected(x)]
    if missing:
        assert returncode in [0,5,6,7,18,22,28,35,52,55,56],('Unsupported curl failure',returncode)
        transient=transient_failure(returncode,missing)
        limit=int(q.get('maximum_transient_attempts',q['maximum_attempts'])) if transient else int(q['maximum_attempts'])
        assert 1 <= limit <= 32, 'Finite transient attempt cap'
        if attempt+1>=limit:
            rejected=[dict(key=x['key'],range=x.get('range'),reason=x.get('rejected_validation','incomplete transfer')) for x in missing]
            write('transport_failure/'+folder.name+'_'+tag+'.json',dict(at=s.now(),returncode=returncode,rejected=rejected,attempts=attempt+1,transient=transient))
            raise RuntimeError(('Bounded transfer attempts exhausted',tag,returncode,rejected))
        write('transport_fallback/'+folder.name+'_'+tag+'.json',dict(at=s.now(),returncode=returncode,attempts=attempt+1,maximum_attempts=limit,
              transient=transient,backoff_seconds=retry_delay(q,attempt,transient),
              rejected=[dict(key=x['key'],range=x.get('range'),reason=x.get('rejected_validation','incomplete transfer')) for x in missing],
              next_source='Original AWS with identical key/version; validated successful parts reused; no model wakeup'))
        retry_wait(q,attempt,transient)
        batch(missing,q,folder,label,attempt+1)

def fetch(choice,objects,p,q):
    check(q);beg=time.monotonic();cycle=choice['cycle'];dt=datetime.fromtimestamp(cycle,timezone.utc)
    folder=N/'work'/str(cycle);folder.mkdir(parents=True,exist_ok=True);idx_specs=[];keys={};receipts=[];messages=[]
    for lead in [3,4,5]:
        key=dt.strftime('hrrr.%Y%m%d/conus/hrrr.t%Hz.wrfsfcf')+f'{lead:02d}.grib2';keys[lead]=key
        assert max(objects[key]['last_modified_seconds'],objects[key+'.idx']['last_modified_seconds'])<=choice['minimum_qualified_cutoff']
        out=folder/f'{lead}.idx';cached=s.N/'indices'/f'{cycle}_{lead}.idx'
        data=cached.read_bytes() if cached.exists() else m.retained_index(key,objects[key+'.idx'])[0]
        if data is None:
            for oldpath in [out,s.N/'native_full_run_20261007/work'/str(cycle)/f'{lead}.idx']:
                if oldpath.exists():
                    candidate=oldpath.read_bytes();meta=objects[key+'.idx']
                    if len(candidate)==meta['bytes'] and hashlib.md5(candidate).hexdigest()==meta['etag'].strip('"'):
                        data=candidate;break
        if data is not None:
            assert len(data)==objects[key+'.idx']['bytes'] and hashlib.md5(data).hexdigest()==objects[key+'.idx']['etag'].strip('"')
            out.write_bytes(data)
        else:idx_specs.append(dict(key=key+'.idx',path=out,source=objects[key+'.idx'],size=objects[key+'.idx']['bytes']))
    batch(idx_specs,q,folder,'indices');specs=[];parts_all={}
    for lead,key in keys.items():
        path=folder/f'{lead}.idx';data=path.read_bytes();idx=objects[key+'.idx']
        assert len(data)==idx['bytes'] and hashlib.md5(data).hexdigest()==idx['etag'].strip('"')
        receipts.append(dict(key=key+'.idx',local=str(path.relative_to(s.N)),sha256=s.sha(path),source=idx))
        lines=[line.split(':') for line in data.decode('ascii').splitlines() if line];parts=[]
        for vi,(var,level,*_) in enumerate(m.FIELDS):
            found=[i for i,line in enumerate(lines) if line[3:5]==[var,level]];assert len(found)==1
            j=found[0];left=int(lines[j][1]);right=int(lines[j+1][1])-1 if j+1<len(lines) else objects[key]['bytes']-1
            assert 0<right-left<8*1024**2
            parts.append(dict(vi=vi,left=left,right=right,lead=lead,key=key))
        groups=[]
        for part in sorted(parts,key=lambda x:x['left']):
            if groups and groups[-1][-1]['right']+1==part['left']:groups[-1].append(part)
            else:groups.append([part])
        for group in groups:
            left,right=group[0]['left'],group[-1]['right'];path=folder/f'{lead}_{left}.grib2'
            specs.append(dict(key=key,path=path,source=objects[key],size=right-left+1,range=[left,right],parts=group))
    batch(specs,q,folder,'fields')
    for x in specs:
        left,right=x['range'];size=x['path'].stat().st_size
        receipts.append(dict(key=x['key'],range=x['range'],bytes=size,local=str(x['path'].relative_to(s.N)),sha256=s.sha(x['path']),source=x['source'],native_response_headers=x['headers'],retrieval_url=x.get('retrieval_url'),request_provenance=x.get('request_provenance'),rejected_mirror_validation=x.get('rejected_validation')))
        for part in x['parts']:messages.append(dict(part,file=str(x['path']),offset=part['left']-left))
    s.write('download_receipts/'+str(cycle)+'.json',dict(choice=choice,receipts=receipts,complete=True,transport='curl8.16batched'))
    return dict(choice=choice,receipts=receipts,messages=messages,audit_values=True,fetch_seconds=time.monotonic()-beg)

def reserve(specs,q):
    # Reserve before launch and persist before network I/O; retry accounting is conservative.
    with LOCK:
        reserved=dict(COUNTS)
        reserved['reserved_bytes']+=sum(x['size'] for x in specs)
        reserved['reserved_requests']+=len(specs)
        assert reserved['reserved_bytes']<=q['maximum_bytes'],'Cumulative download quota'
        assert reserved['reserved_requests']<=q['maximum_requests'],'Finite request quota'
        raw=dict(RAW_RESERVATIONS)
        for x in specs:
            path=x['path'].resolve()
            assert path.is_relative_to((N/'work').resolve()),'Out-of-work transport target'
            if path.suffix=='.grib2':raw[str(path)]=max(raw.get(str(path),0),x['size'])
        assert sum(raw.values())<=q['maximum_retained_raw_bytes'],'Retained/staged raw quota'
        write('TRANSFER_COUNTERS.json',dict(at=s.now(),counters=reserved,raw_reserved_bytes=sum(raw.values()),accounting='Conservative maximum bytes of each issued batch; not actual measured traffic'))
        COUNTS.update(reserved);RAW_RESERVATIONS.clear();RAW_RESERVATIONS.update(raw)
