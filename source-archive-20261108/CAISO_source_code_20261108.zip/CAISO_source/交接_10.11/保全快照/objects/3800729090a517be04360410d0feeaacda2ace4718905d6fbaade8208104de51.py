import common as c
import pickle

def main():
    protocol=c.verify();r=c.read(c.HERE/'RESULT.json');checks=[]
    def check(condition,name):
        assert condition,name
        checks.append(name)
    with c.gate.exclusive('V23 separate probability replay and scoring audit'):
        np,lim=c.gate.runtime(False)
        from scipy.optimize import minimize_scalar
        from sklearn.metrics import roc_auc_score
        check(c.sha(r['output'])==r['output_sha256'],'output_hash')
        check(c.sha(c.HERE/'PROTOCOL.json')==r['protocol_sha256'],'protocol_hash')
        with np.load(protocol['library'],allow_pickle=False) as z:d={k:z[k] for k in z.files}
        with np.load(r['output'],allow_pickle=False) as z:out={k:z[k] for k in z.files}
        ids=out['indices'];yy=d['states'].astype(int)-3
        check(np.array_equal(out['truth_class'],yy[ids]),'labels_match_source')
        check(np.array_equal(out['issued'],d['issued'][ids]),'times_match_source')
        check(len(np.unique(ids))==len(ids),'no_duplicate_library_rows')
        def temper(p,t):
            a=np.log(np.clip(p,1e-12,None))/t;a-=a.max(axis=1)[:,None];a=np.exp(a)
            return a/a.sum(axis=1)[:,None]
        def construct(h,post,support):
            post=post.copy();survival=np.empty_like(h);survival[:,0]=1-h[:,0]
            for j in range(1,12):survival[:,j]=survival[:,j-1]*(1-h[:,j])
            if support:
                denom=post[:,0,0]+post[:,0,1]
                post[:,0,0]/=denom;post[:,0,1]/=denom;post[:,0,2]=0
            p=post*(1-survival)[:,:,None];p[:,:,2]+=survival
            return p
        for fold in r['folds']:
            c.check();fi=fold['id'];aa,bb=protocol['folds'][fi];start,end=c.stamp(aa),c.stamp(bb)
            outer=(d['issued']+3600<start-172800)&(np.max(d['available'],axis=1)<start)
            days=np.unique(d['issued'][outer]//86400);cut=int(days[-max(5,int(np.ceil(.2*len(days))))]*86400)
            fit=np.flatnonzero((d['issued']+3600<cut-172800)&(d['available'].max(axis=1)<cut))
            cal=np.flatnonzero(outer&(d['issued']>=cut));test=np.flatnonzero((d['issued']>=start)&(d['issued']<end))
            check(cut==fold['cal_start'],f'fold{fi}_calibration_boundary')
            check(c.sha(fold['replay'])==fold['replay_sha256'],f'fold{fi}_replay_hash')
            with np.load(fold['replay'],allow_pickle=False) as z:replay={k:z[k] for k in z.files}
            for name,index in [('fit',fit),('cal',cal),('test',test)]:
                check(np.array_equal(index,replay[name+'_indices']),f'fold{fi}_{name}_membership')
            check(np.array_equal(ids[out['fold']==fi],test),f'fold{fi}_output_membership')
            h=np.tile(np.arange(1,13),len(test));xx=np.column_stack([np.repeat(d['context'][test],12,axis=0),h/12,(np.repeat(d['duration'][test],12)+h)/288]).astype(np.float32)
            ycal=yy[cal];first=np.full(len(cal),12,int)
            for j in range(len(cal)):
                seen=np.flatnonzero(ycal[j]!=2)
                if len(seen):first[j]=seen[0]
            horizon=np.arange(12)[None,:]
            masks={'hazard':horizon<=first[:,None],'postexit':horizon>=first[:,None]}
            labels={'hazard':(horizon==first[:,None]).astype(int),'postexit':ycal}
            probabilities={};calibrated={}
            for kind in ('LEGACY','NATURAL'):
                probabilities[kind]={};calibrated[kind]={}
                for task in ('hazard','postexit'):
                    model_info=fold['models'][kind+'_'+task];check(c.sha(model_info['path'])==model_info['sha256'],f'fold{fi}_{kind}_{task}_model_hash')
                    with open(model_info['path'],'rb') as f:m=pickle.load(f)['model']
                    check(m.n_iter_==80,f'fold{fi}_{kind}_{task}_budget')
                    raw=replay[f'{kind}_{task}_test_raw'];cp=replay[f'{kind}_{task}_cal_raw']
                    # Re-run every saved test prediction. No fit performed by audit.
                    check(np.allclose(m.predict_proba(xx),raw,atol=1e-13,rtol=1e-12),f'fold{fi}_{kind}_{task}_inference_replay')
                    probabilities[kind][task]=raw;calibrated[kind][task]={}
                    mask=masks[task];target=labels[task][mask];rr,hh=np.nonzero(mask)
                    for objective in ('LEGACY','NATURAL'):
                        w=np.ones(len(rr)) if objective=='NATURAL' else 1/np.maximum(mask.sum(axis=1),1)[rr]
                        w/=w.sum()
                        def nll(t):return float(np.dot(w,-np.log(np.clip(temper(cp[mask.ravel()],t)[np.arange(len(target)),target],1e-12,None))))
                        opt=minimize_scalar(nll,bounds=(.5,2),method='bounded');saved=fold['temperatures'][kind+'_'+task][objective]
                        check(abs(float(opt.x)-saved['temperature'])<1e-7,f'fold{fi}_{kind}_{task}_{objective}_temperature')
                        check(abs(nll(1)-saved['raw_nll'])<1e-10 and abs(nll(opt.x)-saved['calibrated_nll'])<1e-10,f'fold{fi}_{kind}_{task}_{objective}_calibration_objective')
                        calibrated[kind][task][objective]=temper(raw,saved['temperature'])
                raw_h=probabilities[kind]['hazard'][:,1].reshape(-1,12);raw_post=probabilities[kind]['postexit'].reshape(-1,12,3)
                check(np.allclose(construct(raw_h,raw_post,False),out[kind+'_RAW'][out['fold']==fi]),f'fold{fi}_{kind}_raw_composition')
                for objective in ('LEGACY','NATURAL'):
                    haz=calibrated[kind]['hazard'][objective][:,1].reshape(-1,12);post=calibrated[kind]['postexit'][objective].reshape(-1,12,3)
                    arm=kind if objective==kind else ('LEGACY_NATCAL' if kind=='LEGACY' else 'NATURAL_LEGCAL')
                    check(np.allclose(construct(haz,post,False),out[arm][out['fold']==fi]),f'fold{fi}_{arm}_composition')
                    if objective==kind:
                        check(np.allclose(construct(haz,post,True),out[kind+'_SUPPORT'][out['fold']==fi]),f'fold{fi}_{kind}_support_composition')
                        check(np.allclose(out[kind+'_SUPPORT'][out['fold']==fi,0,2],1-haz[:,0]),f'fold{fi}_{kind}_impossible_reentry_zero')
            prior=np.empty((12,3))
            for h in range(12):
                counts=np.array([(yy[fit,h]==k).sum()+.5 for k in range(3)]);prior[h]=counts/counts.sum()
            check(np.allclose(out['PRIOR'][out['fold']==fi],prior),f'fold{fi}_prior')
        metrics={};losses={};target=out['truth_class'];hot=np.eye(3)[target]
        for arm in protocol['primary_arms']+protocol['diagnostic_arms']:
            p=out[arm]
            check(np.isfinite(p).all() and np.all(p>=0) and np.allclose(p.sum(-1),1),arm+'_valid_probability')
            b=np.sum((p-hot)**2,axis=2);ll=-np.log(np.maximum(p[np.arange(len(p))[:,None],np.arange(12)[None,:],target],1e-12))
            metrics[arm]=dict(brier=float(b.mean()),logloss=float(ll.mean()));losses[arm]=b
            check(all(abs(metrics[arm][k]-r['metrics'][arm][k])<1e-11 for k in metrics[arm]),arm+'_aggregate_scores')
            for fold in r['folds']:
                sel=out['fold']==fold['id'];fm=fold['metrics'][arm]
                check(abs(b[sel].mean()-fm['brier'])<1e-11 and abs(ll[sel].mean()-fm['logloss'])<1e-11,arm+'_month'+str(fold['id']))
            for i in range(12):check(abs(b[:,i].mean()-r['metrics'][arm]['horizons'][i]['brier'])<1e-11,arm+'_horizon'+str(i+1))
            for k in range(3):
                sel=target==k;item=r['metrics'][arm]['states'][k]
                check(int(sel.sum())==item['cells'] and abs(b[sel].mean()-item['brier'])<1e-11,arm+'_state'+str(k+3))
        block=out['issued']//604800;unique=np.unique(block);counts=np.array([(block==g).sum()*12 for g in unique]);draws=np.random.default_rng(20260813).integers(len(unique),size=(2000,len(unique)))
        for item in r['inference']['comparisons']:
            delta=losses[item['comparator']]-losses['NATURAL_SUPPORT'];sums=np.array([delta[block==g].sum() for g in unique]);gain=float(delta.mean());boot=sums[draws].sum(axis=1)/counts[draws].sum(axis=1)
            check(np.allclose(np.quantile(boot,[.025,.975]),item['interval95'],atol=1e-12),item['comparator']+'_block_interval')
            check(abs(float((1+(abs(boot-gain)>=abs(gain)).sum())/2001)-item['p'])<1e-12,item['comparator']+'_centered_p')
        hm={}
        for arm in ('LEGACY','NATURAL'):
            h=out[arm+'_hazard'][:,0];hy=(target[:,0]!=2).astype(int);hm[arm]=float(roc_auc_score(hy,h))
            check(abs(hm[arm]-r['h1_hazard'][arm]['auc'])<1e-12,arm+'_h1_auc')
        cand=metrics['NATURAL_SUPPORT'];base=metrics['LEGACY'];prior=metrics['PRIOR']
        conditions=dict(brier_vs_legacy=cand['brier']<base['brier'],logloss_vs_legacy=cand['logloss']<base['logloss'],brier_vs_prior=cand['brier']<prior['brier'],logloss_vs_prior=cand['logloss']<prior['logloss'],at_least_three_months=sum(losses['NATURAL_SUPPORT'][out['fold']==i].mean()<losses['LEGACY'][out['fold']==i].mean() for i in range(4))>=3,h1_auc_preserved=hm['NATURAL']>=hm['LEGACY'],state_date_support=all(len(np.unique(np.broadcast_to((out['issued']//86400)[:,None],target.shape)[target==k]))>=5 for k in range(3)),brier_interval_positive=r['inference']['comparisons'][0]['interval95'][0]>0)
        check(conditions==r['screen']['conditions'] and bool(all(conditions.values()))==r['screen']['passed'],'screen_independently_recomputed')
        c.verify();retained=c.preserved()
        c.write(c.HERE/'AUDIT.json',dict(at=c.now(),status='passed',checks=len(checks),check_names=checks,result_sha256=c.sha(c.HERE/'RESULT.json'),output_sha256=c.sha(r['output']),protected_files_verified=retained,new_test_targets_read=False,price_predictions_changed=False,model_fits=0,independence='Separate script and process, same operator; not external human review',screen=r['screen']))
        print('V23 audit passed: '+str(len(checks))+' checks.',flush=True)

if __name__=='__main__':main()
