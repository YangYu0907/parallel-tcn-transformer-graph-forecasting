"""Rerun the sealed scorer with value-preserving NumPy scalar JSON conversion.

No training, scoring formula, prediction, protocol, or original seal is changed.
The export adapter and its checks are separately bound in RECOVERY_AUDIT.json.
"""
import json
import os
from pathlib import Path
import gate


def main():
    gate.guard(True)
    gate.cg.bound_process()
    import numpy as np
    import audit

    base_write = gate.write
    converted = []

    def native(value, path='$', record=False):
        if isinstance(value, np.generic):
            item = value.item()
            if not isinstance(item, (bool, int, float, str)):
                raise TypeError('Unsupported NumPy scalar: ' + type(value).__name__)
            if record:
                converted.append(dict(path=path, source_type=type(value).__name__,
                                      destination_type=type(item).__name__))
            return item
        if isinstance(value, dict):
            return {k: native(v, path + '/' + str(k), record) for k, v in value.items()}
        if isinstance(value, (list, tuple)):
            return [native(v, path + '/' + str(i), record) for i, v in enumerate(value)]
        return value

    checks = []
    value = dict(flag=np.bool_(True), count=np.int64(3), score=np.float32(1.25),
                 nested=[np.bool_(False), np.float64(-2.5)], ordinary='unchanged')
    expected = dict(flag=True, count=3, score=1.25, nested=[False, -2.5], ordinary='unchanged')
    converted_value = native(value)
    checks.append(converted_value == expected)
    checks.append(json.loads(json.dumps(converted_value, allow_nan=False)) == expected)
    checks.append(type(converted_value['flag']) is bool)
    checks.append(type(converted_value['count']) is int)
    for val in (np.float64(np.nan), np.float64(np.inf), object(), np.array([1, 2])):
        try:
            json.dumps(native(val), allow_nan=False)
        except (ValueError, TypeError):
            checks.append(True)
        else:
            checks.append(False)
    gate.need(all(checks), 'Export adapter QA failed')
    before = {name: gate.sha(gate.HERE / name)
              for name in ('SEAL.json', 'PROTOCOL.json', 'FIT_COMPLETE.json', 'audit.py')}
    plan = dict(at=gate.now(), cause='JSON export rejected NumPy boolean/integer scalar types',
                changes='Only convert NumPy scalar values to their equal Python scalar values at JSON output',
                unchanged_bindings=before, recovery_script_sha256=gate.sha(Path(__file__)),
                checks_passed=len(checks), new_training_updates=0,
                scoring_formulas_changed=False, new_test_targets_read=False)
    base_write(gate.HERE / 'RECOVERY_PLAN.json', plan)
    base_write(gate.HERE / 'queue/recovery_status.json',
               dict(event='audit_export_recovery_started', at=gate.now(), pid=os.getpid()))
    h = gate.read(gate.ROOT / 'HANDOFF.json')
    h.update(status='context_expert_audit_export_recovery', current_stage='audit_export_recovery',
             current_plan_complete=False, training_active=False, current_process=os.getpid())
    base_write(gate.ROOT / 'HANDOFF.json', h)

    def scalar_write(path, value):
        return base_write(path, native(value, record=True))

    gate.write = scalar_write
    try:
        audit.main()
    finally:
        gate.write = base_write

    for name, digest in before.items():
        gate.need(gate.sha(gate.HERE / name) == digest, 'Recovery changed sealed artifact: ' + name)
    result = gate.read(gate.HERE / 'RESULT.json')
    verification = gate.read(gate.HERE / 'AUDIT.json')
    gate.need(verification['status'] == 'passed' and verification['checked_fits'] == 27,
              'Incomplete independent arithmetic audit')
    gate.need(verification['result_sha256'] == gate.sha(gate.HERE / 'RESULT.json'), 'Result binding')
    recovery = dict(status='passed', at=gate.now(), recovery_plan_sha256=gate.sha(gate.HERE/'RECOVERY_PLAN.json'),
                    recovery_script_sha256=gate.sha(Path(__file__)), unchanged_bindings=before,
                    scalar_conversions=converted, checks_passed=len(checks), new_training_updates=0,
                    audit_sha256=gate.sha(gate.HERE/'AUDIT.json'),
                    result_sha256=gate.sha(gate.HERE/'RESULT.json'), new_test_targets_read=False)
    base_write(gate.HERE / 'RECOVERY_AUDIT.json', recovery)
    completion = dict(status='finite_development_complete_and_arithmetic_audited', at=gate.now(), fits=27,
                      result=str(gate.HERE/'RESULT.json'), result_sha256=gate.sha(gate.HERE/'RESULT.json'),
                      audit=str(gate.HERE/'AUDIT.json'), audit_sha256=gate.sha(gate.HERE/'AUDIT.json'),
                      recovery_audit=str(gate.HERE/'RECOVERY_AUDIT.json'),
                      recovery_audit_sha256=gate.sha(gate.HERE/'RECOVERY_AUDIT.json'),
                      candidate_passes_development_gate=result['candidate_passes_development_gate'],
                      complete_research_experiment=False, independent_confirmation_completed=False,
                      notification_delivery='Foreground recovery turn; no duplicate inbox event')
    base_write(gate.HERE / 'queue/completion.json', completion)
    base_write(gate.HERE / 'queue/status.json',
               dict(event='finite_sampling_queue_completed', at=gate.now(), pid=os.getpid(),
                    recovered_from='83fbe550b3f13beae1314cc6047fc1907f514bc2149dedac21fa3c2dcfeb31a2',
                    notification_delivery='foreground_recovery_turn'))
    h = gate.read(gate.ROOT / 'HANDOFF.json')
    status = 'context_expert_development_audited_' + ('passed_gate' if result['candidate_passes_development_gate'] else 'not_promoted')
    h.update(at=gate.now(), status=status, current_stage=status, current_plan_complete=True,
             training_active=False, current_process=None)
    h['context_expert_trial'].update(status=status, manager_pid=None, training_active=False,
        result=str(gate.HERE/'RESULT.json'), audit=str(gate.HERE/'AUDIT.json'),
        recovery_audit=str(gate.HERE/'RECOVERY_AUDIT.json'), completion=str(gate.HERE/'queue/completion.json'),
        candidate_passes_development_gate=result['candidate_passes_development_gate'])
    base_write(gate.ROOT / 'HANDOFF.json', h)
    print(json.dumps(dict(recovery='passed', checked_fits=27,
        candidate_passes=result['candidate_passes_development_gate']), ensure_ascii=False), flush=True)


if __name__ == '__main__':
    main()
