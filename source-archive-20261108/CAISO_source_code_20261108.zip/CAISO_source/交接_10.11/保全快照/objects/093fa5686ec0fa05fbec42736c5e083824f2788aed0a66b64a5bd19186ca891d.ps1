﻿$ErrorActionPreference='Stop'
$h=Split-Path -Parent $PSScriptRoot
$b=Split-Path -Parent $h
$python='D:\Documents\conda_envs\tcn_air\python.exe'
$managerPath=Join-Path $h 'manager.py'
$bridgePath=Join-Path $h 'watch_manager_exit.ps1'
if (Test-Path -LiteralPath (Join-Path $h 'queue\QUEUE.lock')) { throw 'Queue already owned; inspect before recovery' }
if (Test-Path -LiteralPath (Join-Path $h 'queue\completion.json')) { throw 'Finite queue already complete' }
$processes=@(Get-CimInstance Win32_Process)
if (@($processes | Where-Object {$_.Name -eq 'python.exe' -and $_.CommandLine -and $_.CommandLine.Contains($managerPath)}).Count -gt 0) { throw 'Manager already running' }
$watchState=Get-Content -LiteralPath (Join-Path $b 'event_driven_automation\status.json') -Raw -Encoding UTF8 | ConvertFrom-Json
if (@($processes | Where-Object {$_.ProcessId -eq $watchState.pid -and $_.CommandLine -and $_.CommandLine.Contains((Join-Path $b 'event_driven_automation\watch.ps1'))}).Count -ne 1) { throw 'Shared event watcher absent' }
& $python (Join-Path $h 'gate.py') check
if ($LASTEXITCODE -ne 0) { throw 'Control source/resource admission failed' }
$logs=Join-Path $h ('launch_'+[guid]::NewGuid().ToString('N').Substring(0,10))
New-Item -ItemType Directory -Path $logs | Out-Null
$manager=Start-Process -FilePath $python -ArgumentList @(('"'+$managerPath+'"'),'--resume-after-event','static_gtf_tail_blocking_failure_f6fefdd5210734fe18f58695d0b1ea4f0ab00885f0330cb0cb3bcca3cf0439f4') -WorkingDirectory $b -WindowStyle Hidden -RedirectStandardOutput (Join-Path $logs 'manager.stdout.log') -RedirectStandardError (Join-Path $logs 'manager.stderr.log') -PassThru
$ticks=$manager.StartTime.ToUniversalTime().Ticks
$status=Join-Path $h 'queue\status.json'
$bridgeArgs=@('-NoProfile','-ExecutionPolicy','Bypass','-File',('"'+$bridgePath+'"'),'-ManagerProcessId',[string]$manager.Id,'-ManagerStartUtcTicks',[string]$ticks,'-ManagerScript',('"'+$managerPath+'"'),'-StatusPath',('"'+$status+'"'))
$bridge=Start-Process -FilePath 'C:\Windows\System32\WindowsPowerShell\v1.0\powershell.exe' -ArgumentList $bridgeArgs -WorkingDirectory $b -WindowStyle Hidden -RedirectStandardOutput (Join-Path $logs 'bridge.stdout.log') -RedirectStandardError (Join-Path $logs 'bridge.stderr.log') -PassThru
$record=[ordered]@{manager_pid=$manager.Id;manager_start_utc_ticks=$ticks;bridge_pid=$bridge.Id;watcher_pid=$watchState.pid;at=[DateTime]::UtcNow.ToString('o');timer=$false;logs=$logs;heldout_targets_read=$false}
$record | ConvertTo-Json -Depth 8 | Set-Content -LiteralPath (Join-Path $logs 'launch.json') -Encoding UTF8
$record | ConvertTo-Json -Depth 8
