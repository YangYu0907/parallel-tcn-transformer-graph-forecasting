"""Separate replay and scoring implementation; same operator, not external review."""
import common as c


def main():
    protocol=c.verify()
    result=c.read(c.HERE/'RESULT.json')
    checks=[]
    def ck(value,name):
        assert bool(value),name
        checks.append(name)
    with c.gate.exclusive('V25 independent-code coefficient/source/scoring audit'):
        np,lim=c.gate.runtime(False)
        from sklearn.metrics import roc_auc_score
        ck(c.sha(result['output'])==result['output_sha256'],'output binding')
        with np.load(result['output'],allow_pickle=False) as z:
            out={k:z[k] for k in z.files}
        with np.load(protocol['library'],allow_pickle=False) as z:
            data={k:z[k] for k in z.files}
        parent=c.read(c.V24/'RESULT.json')
        with np.load(parent['output'],allow_pickle=False) as z:
            parent_output={k:z[k] for k in z.files}
        ck(np.array_equal(out['truth_class'],data['states'][out['indices']]-3),'outcome join')
        ck(np.array_equal(out['issued'],data['issued'][out['indices']]),'issue join')
        ck(np.array_equal(out['indices'],parent_output['indices']),'common evaluation origins')
        for name in ('PRICE_SMALL','PRIOR','RICH_LARGE','FROZEN_V14'):
            ck(np.array_equal(out[name],parent_output[name]),'unchanged control '+name)
        def temperature(q,t):
            z=np.log(np.maximum(q,1e-12))/t
            z-=z.max(axis=1,keepdims=True)
            z=np.exp(z)
            return z/z.sum(axis=1,keepdims=True)
        def composed(hazard,dest):
            destination=dest.copy()
            destination[:,0,2]=0
            destination[:,0,:2]/=destination[:,0,:2].sum(axis=-1,keepdims=True)
            answer=np.empty_like(destination)
            survival=np.ones(len(hazard))
            for h in range(12):
                survival*=1-hazard[:,h]
                answer[:,h,:]=destination[:,h,:]*(1-survival[:,None])
                answer[:,h,2]+=survival
            return answer
        cal_support=[]
        for row,(aa,bb) in zip(result['folds'],protocol['folds']):
            c.check()
            i=row['id']
            ck(c.sha(row['calibration_artifact'])==row['calibration_sha256'],'calibration artifact '+str(i))
            with np.load(row['calibration_artifact'],allow_pickle=False) as z:
                cal={k:z[k] for k in z.files}
            with np.load(parent['folds'][i]['replay'],allow_pickle=False) as z:
                source={k:z[k] for k in z.files}
            for name in ('fit','cal','test'):
                ck(np.array_equal(cal[name+'_indices'],source[name+'_indices']),f'fold{i} {name} membership')
            fit,validation,test=[cal[n+'_indices'] for n in ('fit','cal','test')]
            issued=data['issued'];available=data['available'].max(1)
            days=np.unique(issued[((issued+3600)<c.old.stamp(aa)-172800)&(available<c.old.stamp(aa))]//86400)
            cutoff=int(days[-max(5,int(np.ceil(.2*len(days))))]*86400)
            ck(np.array_equal(fit,np.flatnonzero((issued+3600<cutoff-172800)&(available<cutoff))),f'fold{i} fit purge and publication')
            outer=(issued+3600<c.old.stamp(aa)-172800)&(available<c.old.stamp(aa))
            ck(np.array_equal(validation,np.flatnonzero(outer&(issued>=cutoff))),f'fold{i} calibration chronology')
            ck(np.array_equal(test,np.flatnonzero((issued>=c.old.stamp(aa))&(issued<c.old.stamp(bb)))),f'fold{i} evaluation chronology')
            yy=data['states'][fit].astype(int)-3
            reference=np.stack([np.stack([(yy[:,h]==s).sum()+.5 for s in range(3)]) for h in range(12)])
            reference/=reference.sum(axis=1,keepdims=True)
            ck(np.allclose(reference,cal['prior'],atol=1e-14),f'fold{i} prior fit only')
            for arm in ('PRICE_SMALL','RICH_LARGE'):
                hp=temperature(source[arm+'_hazard_cal_raw'],parent['folds'][i]['temperatures'][arm+'_hazard'])[:,1].reshape(-1,12)
                dp=temperature(source[arm+'_postexit_cal_raw'],parent['folds'][i]['temperatures'][arm+'_postexit']).reshape(-1,12,3)
                expected=composed(hp,dp)
                ck(np.allclose(expected,cal[arm],atol=1e-12),f'fold{i} {arm} calibration replay')
                ck(np.allclose(expected[:,0,2],1-hp[:,0]),f'fold{i} {arm} h1 support')
            target=data['states'][validation].astype(int)-3
            hot=np.eye(3)[target]
            displacement=cal['PRICE_SMALL']-reference
            initial_error=reference-hot
            def derivative(a,mask=slice(None)):
                return float(2*np.sum((initial_error[mask]+a*displacement[mask])*displacement[mask]))
            # An independent derivative root check, not the production ratio.
            def root(mask=slice(None)):
                if derivative(0.,mask)>=0:
                    return 0.
                if derivative(1.,mask)<=0:
                    return 1.
                lo,hi=0.,1.
                for _ in range(55):
                    middle=(lo+hi)/2
                    if derivative(middle,mask)>0:
                        hi=middle
                    else:
                        lo=middle
                return (lo+hi)/2
            weight=root()
            ck(abs(weight-row['lambda_value'])<1e-11,f'fold{i} Brier optimum')
            expected=(1-weight)*reference+weight*cal['PRICE_SMALL']
            ck(np.allclose(expected,cal['ANCHORED'],atol=1e-12),f'fold{i} calibration pooling')
            selected=out['fold']==i
            forecast=(1-weight)*reference+weight*out['PRICE_SMALL'][selected]
            ck(np.allclose(forecast,out['ANCHORED'][selected],atol=1e-12),f'fold{i} forward pooling')
            # No evaluation label is an argument to the fitted coefficient or pooling.
            mutated=data['states'].copy()
            mutated[test]=3+(mutated[test]-2)%3
            ck(np.array_equal(mutated[fit],data['states'][fit]) and np.array_equal(mutated[validation],data['states'][validation]),f'fold{i} future mutation leaves calibration unchanged')
            ck(np.allclose(0*out['PRICE_SMALL'][selected]+reference,out['PRIOR'][selected]),f'fold{i} zero-weight identity')
            ck(np.array_equal(1*out['PRICE_SMALL'][selected],out['PRICE_SMALL'][selected]),f'fold{i} unit-weight identity')
            caldays=issued[validation]//86400
            for item in row['leave_one_cal_date_out']:
                ck(abs(root(caldays!=item['excluded_UTC_day'])-item['lambda_value'])<1e-10,f'fold{i} leave day '+str(item['excluded_UTC_day']))
            counts=[len(np.unique(np.broadcast_to(caldays[:,None],target.shape)[target==k])) for k in range(3)]
            ck(counts==row['cal_state_dates'],f'fold{i} state date support')
            cal_support.append(len(np.unique(caldays))>=5 and min(counts)>=2)
            constraints=row['cal_state_nonregression_feasibility']
            lower,upper=0.,1.
            for item in constraints['states']:
                k=item['state']-3;mask=target==k
                a=float(np.square(displacement[mask]).sum()/mask.sum())
                b=float(2*np.sum(displacement[mask]*initial_error[mask])/mask.sum())
                cc=float((np.square(initial_error[mask]).sum()-np.square(cal['RICH_LARGE'][mask]-hot[mask]).sum())/mask.sum())
                ck(np.allclose([a,b,cc],item['quadratic'],atol=1e-12),f'fold{i} state{k+3} quadratic')
                interval=item['interval']
                if interval is None:
                    roots=np.roots([a,b,cc]) if a>1e-15 else []
                    vertex=float(np.clip(-b/(2*a),0,1)) if a>1e-15 else (0. if b>=0 else 1.)
                    ck(a*vertex*vertex+b*vertex+cc>=-1e-10,f'fold{i} state{k+3} infeasible')
                    upper=-1.
                else:
                    ck(all(a*t*t+b*t+cc<=1e-10 for t in interval),f'fold{i} state{k+3} interval ends')
                    lower,upper=max(lower,interval[0]),min(upper,interval[1])
            expected_interval=[lower,upper] if lower<=upper else None
            ck(expected_interval==constraints['interval'],f'fold{i} joint feasibility')
        y=out['truth_class'];days=out['issued']//86400;hot=np.eye(3)[y]
        losses={};summary={};h1={}
        for arm in protocol['arms']:
            prob=out[arm]
            ck(np.isfinite(prob).all() and (prob>=0).all() and np.allclose(prob.sum(-1),1),arm+' valid probabilities')
            b=np.zeros(y.shape)
            for k in range(3):
                b+=(prob[:,:,k]-(y==k))**2
            ll=-np.log(np.clip(prob[np.arange(len(y))[:,None],np.arange(12)[None,:],y],1e-12,None))
            losses[arm]=b
            summary[arm]=dict(brier=float(b.mean()),logloss=float(ll.mean()))
            for field in ('brier','logloss'):
                ck(abs(summary[arm][field]-result['metrics'][arm][field])<1e-12,arm+' '+field)
            for k in range(3):
                record=result['metrics'][arm]['states'][k]
                ck(abs(b[y==k].mean()-record['brier'])<1e-12 and abs(ll[y==k].mean()-record['logloss'])<1e-12,arm+' state'+str(k+3))
            for h in range(12):
                record=result['metrics'][arm]['horizons'][h]
                ck(abs(b[:,h].mean()-record['brier'])<1e-12 and abs(ll[:,h].mean()-record['logloss'])<1e-12,arm+' h'+str(h+1))
            for fold in result['folds']:
                mask=out['fold']==fold['id']
                ck(abs(b[mask].mean()-fold['metrics'][arm]['brier'])<1e-12,arm+' month'+str(fold['id']))
            h1[arm]=float(roc_auc_score(y[:,0]<2,1-prob[:,0,2]))
            ck(abs(h1[arm]-result['h1_exit_auc'][arm])<1e-10,arm+' h1 AUC')
        group=out['issued']//604800;ids=np.unique(group)
        count=np.array([12*np.count_nonzero(group==g) for g in ids])
        draws=np.random.default_rng(20260813).integers(len(ids),size=(2000,len(ids)))
        comps=result['inference']['comparisons']
        for item in comps:
            diff=losses[item['comparator']]-losses['ANCHORED']
            total=np.array([diff[group==g].sum() for g in ids])
            boot=total[draws].sum(1)/count[draws].sum(1);gain=float(diff.mean())
            ck(abs(gain-item['gain'])<1e-12 and np.allclose(np.quantile(boot,[.025,.975]),item['interval95'],atol=1e-12),item['comparator']+' calendar block interval')
            ck(abs((1+(np.abs(boot-gain)>=abs(gain)).sum())/2001-item['p'])<1e-12,item['comparator']+' p')
        running=0.
        for rank,j in enumerate(sorted(range(len(comps)),key=lambda k:comps[k]['p'])):
            running=max(running,min(1.,(len(comps)-rank)*comps[j]['p']))
            ck(abs(running-comps[j]['holm_p'])<1e-12,'Holm '+str(j))
        ca,ba,pr=summary['ANCHORED'],summary['RICH_LARGE'],summary['PRIOR']
        conditions=dict(brier_vs_rich=ca['brier']<ba['brier'],logloss_vs_rich=ca['logloss']<ba['logloss'],
            brier_vs_prior=ca['brier']<pr['brier'],logloss_vs_prior=ca['logloss']<pr['logloss'],
            three_months=sum(losses['ANCHORED'][out['fold']==i].mean()<losses['RICH_LARGE'][out['fold']==i].mean() for i in range(4))>=3,
            h1_auc_preserved=h1['ANCHORED']>=h1['RICH_LARGE'],
            all_states_preserved=all(losses['ANCHORED'][y==k].mean()<=losses['RICH_LARGE'][y==k].mean() for k in range(3)),
            state_date_support=all(len(np.unique(np.broadcast_to(days[:,None],y.shape)[y==k]))>=5 for k in range(3)),
            calibration_support=all(cal_support),interval_positive=comps[0]['interval95'][0]>0)
        ck(conditions==result['screen']['conditions'],'registered conditions recomputed')
        ck(bool(all(conditions.values()))==result['screen']['passed'],'registered decision recomputed')
        c.verify();retained=c.protected()
        c.write(c.HERE/'AUDIT.json',dict(at=c.now(),status='passed',checks=len(checks),check_names=checks,
            result_sha256=c.sha(c.HERE/'RESULT.json'),output_sha256=c.sha(result['output']),
            protected_files_verified=retained,screen=result['screen'],additional_fits=0,
            independence='Separate replay/scoring implementation and process, same operator; not external human review.',
            new_test_targets_read=False,price_predictions_changed=False))
        print('V25 audit passed: '+str(len(checks))+' checks.',flush=True)


if __name__=='__main__':
    main()
