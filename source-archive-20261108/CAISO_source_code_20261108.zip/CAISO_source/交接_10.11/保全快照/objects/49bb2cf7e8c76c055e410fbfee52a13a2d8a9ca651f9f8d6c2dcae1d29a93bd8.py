"""Adapter around the unchanged V3 training loop; only diagnostic identity/output routing extends."""
import argparse,sys
import gate
base=gate.load('sealed_v3_training',gate.V/'source/train.py')
original_admission=base.admission;original_directory=base.run_directory;original_stop=base.stop_reason
# Bind the sealed sampling preflight explicitly; ROOT/source has another module of the same name.
preflight=gate.load('explicit_sampling_preflight',gate.V/'source/preflight.py')
sys.modules['preflight']=preflight
gate.need(gate.inside(preflight.__file__)==gate.V/'source/preflight.py','Wrong preflight module')
def run_directory(policy,variant,seed):
    if variant=='FULL':return original_directory(policy,variant,seed) # existing metadata admission only
    gate.need(policy=='ADDITIVE' and variant in ('GLOBAL','SELF') and seed in (20260813,20260814),'Unregistered diagnostic')
    return gate.HERE/'runs'/f'{seed}_{variant}'
def admission(manifest,variant,seed):
    s=gate.verify();gate.need(any(c['seed']==seed and c['variant']==variant for c in s['cases']),'Unregistered control')
    gate.need(gate.inside(manifest)==gate.inside(s['dataset_manifest']),'Changed ADDITIVE dataset')
    identity=original_admission(manifest,'FULL',seed) # retain every inherited data/math/resource gate
    identity.update(variant=variant,mechanism_execution_lock_sha256=gate.sha(gate.SEAL),
        mechanism_protocol_sha256=gate.sha(gate.HERE/'PROTOCOL.json'),
        diagnostic_scope='same_ADDITIVE_schedule_GLOBAL_SELF_backbone_controls')
    return identity
def stop_reason(run):
    try:gate.boundary()
    except InterruptedError as exc:return str(exc)
    return original_stop(run)
def install():
    base.admission=admission;base.run_directory=run_directory;base.stop_reason=stop_reason;base.atomic=gate.atomic
    return base
def main(args):
    install();gate.resources_api.bound_process()
    if args.action=='train':
        result=base.train(base.policy_manifest('ADDITIVE'),args.variant,args.seed,args.resume)
        print(__import__('json').dumps(result));return 3 if result['status']=='stopped_at_safe_boundary' else 0
    gate.verify();import preflight
    preflight.require_mechanisms_complete();preflight.launch_guard()
    admission(base.policy_manifest('ADDITIVE'),args.variant,args.seed)
    # Reuse the separate saved-output/selection oracle with the explicit extended identity.
    sys.modules['train']=base
    oracle=gate.load('sealed_v3_saved_output_audit',gate.V/'source/audit_result.py')
    with base.exclusive('additive_mechanism_saved_output_audit'):
        np,limiter=gate.runtime(False);oracle.np=np
        print(__import__('json').dumps(oracle.audit(args.seed,args.variant,'ADDITIVE')))
    return 0
if __name__=='__main__':
    p=argparse.ArgumentParser();p.add_argument('action',choices=('train','audit'));p.add_argument('--variant',choices=('GLOBAL','SELF'),required=True)
    p.add_argument('--seed',type=int,choices=(20260813,20260814),required=True);p.add_argument('--resume',action='store_true')
    raise SystemExit(main(p.parse_args()))
