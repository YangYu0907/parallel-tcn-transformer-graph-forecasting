"""Trace the preserved V7 probability -> functional -> correction chain, without fitting."""
from diagnose_fixed_predictions import B, HERE, gate, write
from pathlib import Path
import sys
import math


def register():
    assert not (HERE / 'TRACE_PROTOCOL.json').exists()
    p = gate.read(HERE / 'PROTOCOL.json')
    raw = {k: v for k, v in p['protected_files'].items() if k.endswith('.npz')}
    write('TRACE_PROTOCOL.json', {
        'at': gate.now(), 'scope': p['scope'],
        'purpose': 'Explain wrong-direction S3 corrections and distinguish posterior ranking from decision magnitude using saved intermediate values.',
        'analyses': ['all S3', 'harmful S3', 'helpful S3', 'largest added-harm origin within S3'],
        'posthoc': True, 'fits': 0, 'raw_hashes': raw, 'code_sha256': gate.sha(__file__),
        'prohibited': ['new scoring threshold', 'new forecast', 'tuning', 'causal claim from conditional-on-error subsets'],
    })


def run():
    p = gate.read(HERE / 'TRACE_PROTOCOL.json')
    assert gate.sha(__file__) == p['code_sha256']
    result = []
    with gate.exclusive('Trace preserved V7 decisions without fitting'):
        np, limiter = gate.runtime(False)
        for path, digest in p['raw_hashes'].items():
            gate.guard()
            assert gate.sha(path) == digest
            seed = int(Path(path).stem)
            audited = Path(path).parent.parent / 'audited' / Path(path).name
            assert gate.sha(audited) == gate.read(HERE / 'PROTOCOL.json')['input_hashes'][str(audited)]
            with np.load(audited, allow_pickle=False) as z:
                f, y, v, states, origins = (z[k] for k in ['FULL', 'truth', 'CONTEXT', 'states', 'origins'])
            with np.load(path, allow_pickle=False) as z:
                prob, mean, median, weights = (z['CONTEXT_' + k] for k in ['probabilities', 'mean', 'median', 'weights'])
                assert np.array_equal(z['origins'], origins)
            e, d = f - y, v - f
            harm = (v - y) ** 2 - e ** 2
            m3 = states == 3
            # Reconstruct the specialist on its observed-extreme domain.
            reconstructed = (np.stack([f, mean, median], -1) * weights).sum(-1)
            assert np.allclose(reconstructed[states >= 3], v[states >= 3], atol=1e-9, rtol=1e-12)
            oi = int(np.argmax(np.maximum(np.where(m3, harm, 0.), 0.).sum((1, 2))))
            origin_mask = np.zeros(len(origins), bool)
            origin_mask[oi] = True
            masks = {'all_S3': m3, 'harmful_S3': m3 & (harm > 0), 'helpful_S3': m3 & (harm < 0),
                     'largest_harm_origin_S3': m3 & origin_mask[:, None, None]}
            groups = {}
            for name, m in masks.items():
                pp = prob[m]
                ah = np.maximum(harm[m], 0.)
                groups[name] = {
                    'cells': int(m.sum()), 'origin_count': int(m.any((1, 2)).sum()),
                    'nodes': int(m.any((0, 2)).sum()),
                    'mean_prob_S3_S4_S5': pp.mean(0).tolist(),
                    'S3_is_top_probability_fraction': float((pp.argmax(-1) == 0).mean()),
                    'S3_probability_at_least_half_fraction': float((pp[:, 0] >= .5).mean()),
                    'mean_FULL_prediction': float(f[m].mean()), 'mean_V7_prediction': float(v[m].mean()),
                    'mean_truth': float(y[m].mean()), 'mean_signed_correction': float(d[m].mean()),
                    'mean_predicted_functional_mean': float(mean[m].mean()),
                    'mean_predicted_functional_median': float(median[m].mean()),
                    'mean_weight_FULL_mean_median': weights[m].mean(0).tolist(),
                    'mean_p_weighted_by_positive_added_sse': (ah[:, None] * pp).sum(0).tolist() if not ah.sum() else ((ah[:, None] * pp).sum(0) / ah.sum()).tolist(),
                    'harm_mass': float(ah.sum()),
                }
            result.append({'seed': seed, 'largest_harm_origin_index': int(origins[oi]), 'groups': groups})
        write('STORED_DECISION_TRACE.json', {
            'at': gate.now(), 'scope': p['scope'], 'seeds': result,
            'fits': 0, 'new_test_targets_read': False, 'forecasts_modified': False,
            'replay': 'Saved intermediate values reconstruct saved specialist forecasts for all observed-extreme cells.',
            'interpretation': 'Error-conditioned retrospective description. It does not show that the state was predictable at issuance or identify a deployable threshold.',
        })
        print({'status': 'stored_decision_trace_complete', 'fits': 0, 'seeds': len(result)})


if __name__ == '__main__':
    {'register': register, 'run': run}[sys.argv[1]]()
