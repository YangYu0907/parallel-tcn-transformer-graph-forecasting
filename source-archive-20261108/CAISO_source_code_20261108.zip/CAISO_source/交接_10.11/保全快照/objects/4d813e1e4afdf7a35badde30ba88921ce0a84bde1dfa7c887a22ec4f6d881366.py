"""Metadata and resource gates for matched fixed-budget continuation."""
from pathlib import Path
from contextlib import contextmanager
from datetime import datetime,timezone
import hashlib,json,os,sys,uuid
HERE=Path(__file__).resolve().parent;ROOT=HERE.parent
COMMON=ROOT/'common_sampling_evaluation_20260923'
V=ROOT/'phase_sampling_support_v3_20260923'
SEAL=HERE/'EXECUTION_LOCK.json'
LOCK=Path('D:/Desktop/数据科学_论文/研究优化_20260818/logs/NEURAL_RUN.lock')
sys.path.insert(1,str(ROOT/'source'))
import compile_gate as cg
def now():return datetime.now(timezone.utc).isoformat()
def read(p):return json.loads(Path(p).read_text(encoding='utf-8-sig'))
def need(x,m):
    if not x:raise RuntimeError(m)
def inside(p):
    p=Path(p);p=(ROOT/p if not p.is_absolute() else p).resolve()
    need(p.is_relative_to(ROOT),'Path outside branch');return p
def rel(p):return str(inside(p).relative_to(ROOT))
def sha(p):
    h=hashlib.sha256()
    with Path(p).open('rb') as f:
        for x in iter(lambda:f.read(1048576),b''):h.update(x)
    return h.hexdigest()
def atomic(p,writer,replace=False):
    p=inside(p);p.parent.mkdir(parents=True,exist_ok=True)
    t=p.with_name('t_'+uuid.uuid4().hex+'.pending')
    with t.open('xb') as f:writer(f);f.flush();os.fsync(f.fileno())
    if replace:os.replace(t,p)
    else:t.rename(p)
def write(p,v,replace=False):
    raw=json.dumps(v,ensure_ascii=False,allow_nan=False,indent=2).encode()
    atomic(p,lambda f:f.write(raw),replace)
def boundary():
    for folder in (ROOT,HERE,HERE/'queue',V,COMMON):
        for name in ('STOP_REQUESTED','STOP_REQUESTED.json'):
            if (folder/name).exists():raise InterruptedError('User stop '+str(folder/name))
    p=read(ROOT.parent/'RESEARCH_PAUSED.json')
    if p.get('status')!='resumed_by_user' or p.get('stop_preparation_and_training'):raise InterruptedError('Research paused')
def guard(launch=False):
    boundary();r=cg.resources();floor=5 if launch else 4
    if min(r.values())<floor:raise MemoryError(f'Continuation needs {floor}GiB physical+commit; actual {r}')
    return r
@contextmanager
def exclusive(action):
    guard(True)
    import psutil
    o=dict(pid=os.getpid(),created=psutil.Process().create_time(),token=uuid.uuid4().hex,action=action)
    with LOCK.open('x',encoding='utf-8') as f:json.dump(o,f);f.flush();os.fsync(f.fileno())
    try:cg.bound_process();guard();yield
    finally:
        need(read(LOCK)==o,'Lock owner changed');write(HERE/'lock_releases'/(o['token']+'.json'),dict(owner=o,at=now()));LOCK.unlink()
def runtime(torch_needed=True):
    cg.bound_process()
    import numpy as np
    from threadpoolctl import threadpool_limits,threadpool_info
    lim=threadpool_limits(1)
    need(all(x['num_threads']==1 for x in threadpool_info()),'Numerical thread limit')
    if torch_needed:
        import torch
        torch.set_num_threads(1);torch.set_num_interop_threads(1);torch.use_deterministic_algorithms(True)
        guard();return np,torch,lim
    guard();return np,lim

def load(name,path):
 import importlib.util
 spec=importlib.util.spec_from_file_location(name,path);m=importlib.util.module_from_spec(spec);spec.loader.exec_module(m);return m
PARENT=ROOT/'horizon_adapter_v1_20260925'
EX=ROOT/'matched_external_evaluation_v2_20260925'
VENDOR=ROOT.parent/'external_baselines_20260913/vendor/manifest.json'
VARIANTS=('FULL','TCN','DLinear','iTransformer-H')
def prepared_cases():
 data={};rows={}
 for name in ('common_sampling_evaluation_20260923','matched_panel_v1_20260924','matched_external_evaluation_v2_20260925'):
  for c in read(ROOT/name/'EVALUATION_LOCK.json')['cases']:
   if c['policy']=='ADDITIVE' and c['variant'] in VARIANTS:data[(c['seed'],c['variant'])]=c
  for r in read(ROOT/name/'result.json')['results']:
   if r['policy']=='ADDITIVE' and r['variant'] in VARIANTS:rows[(r['seed'],r['variant'])]=r
 need(set(data)==set(rows)=={(seed,v) for seed in (20260813,20260814,20260815) for v in VARIANTS},'Twelve matched parents required')
 cases=[]
 for seed in (20260813,20260814,20260815):
  for v in VARIANTS:
   c=data[(seed,v)];row=rows[(seed,v)];last=c['epochs'][-1]
   need(last['epoch']==6 and len(c['epochs'])==6,'Full parent prefix missing')
   cases.append(dict(id=f'{seed}_{v}',seed=seed,variant=v,parent=c,terminal_checkpoint=last['checkpoint'],
    terminal_sha256=last['checkpoint_sha256'],parent_panels=row['panels'],parent_train_curve=row['train_curve'],
    parent_dense_receipt=row['dense_receipt']))
 return cases
def verify():
 boundary();s=read(SEAL)
 need(s['status']=='sealed_twelve_case_budget_extension','Unsealed budget')
 need([(c['seed'],c['variant']) for c in s['cases']]==[(seed,v) for seed in (20260813,20260814,20260815) for v in VARIANTS],'Case panel changed')
 for p,d in s['bindings'].items():need(sha(inside(p))==d,'Bound input/source changed '+p)
 need(sha(VENDOR)==s['vendor_manifest_sha256'],'Official vendor manifest changed')
 return s
def seal():
 boundary();need(not SEAL.exists(),'Seal already exists');bindings={}
 def bind(p,expected=None):
  p=inside(p);d=sha(p);need(expected is None or d==expected,'Input changed '+str(p));bindings[rel(p)]=d
  return read(p) if p.suffix=='.json' else d
 old=bind(PARENT/'ADAPTER_LOCK.json','856fcd2aead19a932c634b915ce15c5167c9e0a20619ee3b9146737cbe4f3287')
 for p,d in old['bindings'].items():bind(p,d)
 done=bind(PARENT/'queue/completion.json','de7f521bd207fad72aba35157cb339cc130a7b223b5d7c9c0a452e85aa33f485')
 bind(PARENT/'summary.json',done['summary_sha256'])
 for name,d in done['receipts'].items():
  r=bind(PARENT/'queue/steps'/name,d);need(r['exit_code']==0,'Parent exit');bind(r['marker'],r['marker_sha256'])
 for c in old['cases']:
  a=bind(PARENT/'runs'/c['id']/'audit.json');need(a['status']=='passed','Horizon audit')
  for p,d in a['output_bindings'].items():bind(p,d)
 for name in ('horizon_adapter_completion_verified_20260925.json','budget_extension_curve_review_20260925.json'):bind(ROOT/'audits'/name)
 for folder in ('common_sampling_evaluation_20260923','matched_panel_v1_20260924','matched_external_evaluation_v2_20260925'):
  bind(ROOT/folder/'EVALUATION_LOCK.json');bind(ROOT/folder/'result.json')
 cases=prepared_cases()
 for c in cases:
  bind(c['terminal_checkpoint'],c['terminal_sha256'])
  for e in c['parent']['epochs']:
   bind(e['checkpoint'],e['checkpoint_sha256']);bind(inside(e['checkpoint']).with_suffix('.receipt.json'))
  bind(inside(c['terminal_checkpoint']).parents[1]/'backbone_completion.json')
  rr=bind(c['parent_dense_receipt']);bind(rr['artifact'],rr['artifact_sha256'])
 for p in sorted(HERE.glob('*.py')):compile(p.read_text(encoding='utf-8'),str(p),'exec');bind(p)
 for n in ('PROTOCOL.json','launch_reviewed.ps1','watch_manager_exit.ps1','synthetic_qa.json','parent_qa.json','source_review.json'):bind(HERE/n)
 for n in ('synthetic_qa.json','parent_qa.json'):
  q=read(HERE/n);need(q['status']=='passed','Missing QA')
  for p,d in q['sources'].items():bind(p,d)
 q=read(HERE/'source_review.json')
 need(q['status']=='passed' and q['synthetic_sha256']==sha(HERE/'synthetic_qa.json') and q['parent_sha256']==sha(HERE/'parent_qa.json'),'Missing review')
 for p,d in q['sources'].items():bind(p,d)
 previous=read(COMMON/'EVALUATION_LOCK.json')
 write(SEAL,dict(status='sealed_twelve_case_budget_extension',at=now(),cases=cases,bindings=bindings,
  dataset_manifest=rel(V/'dataset/ADDITIVE/manifest.json'),train_diagnostic=previous['train_diagnostic'],
  vendor_manifest_sha256=sha(VENDOR),heldout_targets_read=False,complete_research_experiment=False))
 print(json.dumps(dict(status='sealed_twelve_case_budget_extension',cases=12,bindings=len(bindings),sha256=sha(SEAL))))
if __name__=='__main__':
 if sys.argv[1]=='seal':seal()
 else:
  s=verify();need(not LOCK.exists(),'Numerical worker active');print(json.dumps(dict(status='passed',cases=12,resources=guard(True))))
