"""Mechanism-informed weather supplement; bounded I/O, one numerical owner."""
import os,sys,time,json,hashlib,traceback,importlib.util,threading,gc
from datetime import datetime,timezone
from concurrent.futures import ThreadPoolExecutor,wait,FIRST_COMPLETED
import support as s
import numpy as np
import requests

R=s.N.parent;Y=R/'forecast_compact_extraction_20261005';I=R/'forecast_source_inventory_20261005'
P=R/'forecast_value_proof_20261005'
sys.path.insert(0,str(P/'vendor'))
import eccodes as ec
spec=importlib.util.spec_from_file_location('registered_transport',Y/'manager.py')
transport=importlib.util.module_from_spec(spec);spec.loader.exec_module(transport)
FIELDS=[('TMP','2 m above ground',0,0,103,2),('DPT','2 m above ground',0,6,103,2),
        ('UGRD','10 m above ground',2,2,103,10),('VGRD','10 m above ground',2,3,103,10),
        ('UGRD','80 m above ground',2,2,103,80),('VGRD','80 m above ground',2,3,103,80),
        ('DSWRF','surface',4,7,1,None),('TCDC','entire atmosphere',6,1,10,None)]
RETAINED_BYTES=0

class ExtractionBudgetInfeasible(Exception):
    pass

def efficiency_check(p,start,completed,total):
    if completed<p['throughput_gate']['minimum_cycles']:return
    elapsed=p['prior_extraction_seconds']+time.monotonic()-start
    remaining=p['deadline_unix']-time.time()
    projected=(total-completed)*elapsed/completed
    reserve=p['throughput_gate']['model_reserve_seconds']
    report=dict(at=s.now(),completed_cycles=completed,total_cycles=total,
        measured_elapsed_seconds=elapsed,projected_remaining_source_seconds=projected,
        remaining_budget_seconds=remaining,model_reserve_seconds=reserve,
        passed=projected+reserve<=remaining,
        estimate_scope='Small source-only pilot, includes real elapsed overhead; throughput projection is uncertain, not an accuracy result',
        model_fits=0,V7_replaced=False,new_test_targets_read=False,network=dict(transport.COUNTS))
    s.write('EFFICIENCY_RESULT.json',report)
    if not report['passed']:raise ExtractionBudgetInfeasible('Measured source throughput cannot fit registered deadline; retain checkpoint, no incomplete-panel fit')

def emit(kind,path):
    h=s.sha(path);eid='mw_'+h[:32];dest=s.B/'event_driven_automation/inbox'/(eid+'.json')
    if not dest.exists():transport.atomic(dest,json.dumps(dict(schema='caiso_research_event_v1',event_id=eid,event=kind,evidence_path=str(path),evidence_sha256=h,at=s.now()),ensure_ascii=False).encode('utf-8'))
    return eid

def tick(p,start,**kw):
    s.guard()
    if datetime.now(timezone.utc).timestamp()>p['deadline_unix']:raise TimeoutError('Registered extension deadline reached')
    s.write('PROGRESS.json',dict(at=s.now(),pid=os.getpid(),elapsed_seconds=time.monotonic()-start,network=dict(transport.COUNTS),**kw))

def retained_index(key,expected):
    stamp=key.split('/')[0].split('.')[1]+'_'+key.split('/')[2][6:9]
    lead=key.split('wrfsfcf')[1][:2]
    path=Y/'raw'/stamp/('F'+lead+'.idx')
    if path.exists():
        data=path.read_bytes()
        if len(data)==expected['bytes'] and hashlib.md5(data).hexdigest()==expected['etag'].strip('"'):return data,str(path)
    return None,None

def fetch(choice,objects,p,start,retain):
    global RETAINED_BYTES
    dt=datetime.fromtimestamp(choice['cycle'],timezone.utc);session=requests.Session();messages=[];receipts=[]
    try:
        for lead in [3,4,5]:
            transport.check(p,start)
            key=dt.strftime('hrrr.%Y%m%d/conus/hrrr.t%Hz.wrfsfcf')+f'{lead:02d}.grib2'
            src,idx=objects[key],objects[key+'.idx']
            assert max(src['last_modified_seconds'],idx['last_modified_seconds'])<=choice['minimum_qualified_cutoff']
            blob,old=retained_index(key,idx)
            if blob is None:
                response=transport.request(session,transport.URL+key+'.idx',p,start,headers={'If-Match':idx['etag']},timeout=(10,30))
                transport.response_check(response,idx);blob=response.content;response.close()
            assert len(blob)==idx['bytes'] and hashlib.md5(blob).hexdigest()==idx['etag'].strip('"')
            rel=f'indices/{choice["cycle"]}_{lead}.idx';transport.atomic(s.N/rel,blob)
            receipts.append(dict(key=key+'.idx',sha256=hashlib.sha256(blob).hexdigest(),local=rel,reused_from=old,source=idx))
            lines=[line.split(':') for line in blob.decode('ascii').splitlines() if line]
            parts=[]
            for vi,(var,level,*_) in enumerate(FIELDS):
                found=[j for j,line in enumerate(lines) if line[3:5]==[var,level]];assert len(found)==1,(key,var,level)
                j=found[0];left=int(lines[j][1]);right=int(lines[j+1][1])-1 if j+1<len(lines) else src['bytes']-1
                assert 0<right-left<8*1024**2
                parts.append(dict(vi=vi,left=left,right=right))
            groups=[]
            for part in sorted(parts,key=lambda x:x['left']):
                if groups and groups[-1][-1]['right']+1==part['left']:groups[-1].append(part)
                else:groups.append([part])
            for group in groups:
                left,right=group[0]['left'],group[-1]['right']
                response=transport.request(session,transport.URL+key,p,start,headers={'Range':f'bytes={left}-{right}','If-Match':src['etag']},timeout=(10,30))
                transport.response_check(response,src)
                assert response.headers['Content-Range']==f'bytes {left}-{right}/{src["bytes"]}'
                data=response.content;response.close();assert len(data)==right-left+1
                rel=f'raw/{choice["cycle"]}_{lead}_{left}.grib2'
                if retain:
                    with transport.COUNT_LOCK:
                        RETAINED_BYTES+=len(data)
                        assert RETAINED_BYTES<=p['maximum_retained_raw_bytes']
                    transport.atomic(s.N/rel,data)
                receipts.append(dict(key=key,range=[left,right],bytes=len(data),local=rel if retain else None,sha256=hashlib.sha256(data).hexdigest(),source=src))
                for part in group:
                    part=dict(part,blob=data[part['left']-left:part['right']-left+1],lead=lead,key=key)
                    messages.append(part)
        s.write('download_receipts/'+str(choice['cycle'])+'.json',dict(choice=choice,receipts=receipts,complete=True))
        return dict(choice=choice,messages=messages,receipts=receipts)
    finally:session.close()

def grid_hash(blob):
    assert blob[:4]==b'GRIB' and blob[-4:]==b'7777' and int.from_bytes(blob[8:16],'big')==len(blob)
    pos=16
    while pos<len(blob)-4:
        size=int.from_bytes(blob[pos:pos+4],'big');assert size>=5
        if blob[pos+4]==3:return hashlib.sha256(blob[pos:pos+size]).hexdigest()
        pos+=size
    raise AssertionError('Missing grid section')

def geometry(handle,p):
    out=[]
    for name,lat,lon in p['anchors']:
        near=min(ec.codes_grib_find_nearest(handle,lat,lon%360),key=lambda x:x['distance'])
        index=int(near['index']);x=index%1799;y=index//1799
        patch=[(y+dy)*1799+x+dx for dy in [-1,0,1] for dx in [-1,0,1]]
        assert 0<x<1798 and 0<y<1058 and near['distance']<3
        out.append(dict(name=name,index=index,indices=patch,latitude=near['lat'],longitude=near['lon'],distance_km=near['distance']))
    old=s.read(P/'RESULT.json')['geometry']
    assert [x['index'] for x in out[:3]]==[x['index'] for x in old]
    return out

def decode(download,p,geo=None):
    choice=download['choice'];values=np.zeros((8,len(p['anchors']),3));means=values.copy();rows=[]
    reference=datetime.fromtimestamp(choice['cycle'],timezone.utc)
    assert len(download['messages'])==24
    for item in download['messages']:
        s.guard();blob=item['blob'];vi=item['vi'];lead=item['lead'];field=FIELDS[vi]
        assert grid_hash(blob)==p['grid_sha256']
        h=ec.codes_new_from_message(blob)
        try:
            assert ec.codes_get(h,'dataDate')==int(reference.strftime('%Y%m%d'))
            assert ec.codes_get(h,'dataTime')==reference.hour*100
            assert ec.codes_get(h,'stepType')=='instant' and ec.codes_get(h,'forecastTime')==lead
            assert ec.codes_get(h,'discipline')==0
            assert ec.codes_get(h,'parameterCategory')==field[2]
            number=ec.codes_get(h,'parameterNumber')
            assert number==field[3] or (vi==6 and number==192 and ec.codes_get(h,'centre')=='kwbc')
            assert ec.codes_get_long(h,'typeOfFirstFixedSurface')==field[4]
            if field[5] is not None:assert ec.codes_get(h,'level')==field[5]
            assert ec.codes_get(h,'units')==(['K','K']+['m s**-1']*4+['W m**-2','%'])[vi]
            assert (ec.codes_get(h,'Nx'),ec.codes_get(h,'Ny'))==(1799,1059)
            if geo is None:geo=geometry(h,p)
            raw=ec.codes_get_values(h);vals=raw[[g['index'] for g in geo]];patch=raw[[g['indices'] for g in geo]];del raw
            assert np.isfinite(patch).all()
            if vi<2:assert np.all((patch>170)&(patch<345))
            elif vi<6:assert np.max(np.abs(patch))<150
            elif vi==6:assert patch.min()>=-1 and patch.max()<2000
            else:assert patch.min()>=-.1 and patch.max()<=100.1
            # A separate indexed-access API replays every retained pilot value.
            if download.get('audit_values'):
                replay=np.array(ec.codes_get_double_elements(h,'values',[g['index'] for g in geo]))
                assert np.array_equal(replay,vals)
            values[vi,:,lead-3]=vals;means[vi,:,lead-3]=patch.mean(1)
            rows.append(dict(vi=vi,lead=lead,key=item['key'],range=[item['left'],item['right']],sha256=hashlib.sha256(blob).hexdigest(),units=ec.codes_get(h,'units')))
        finally:ec.codes_release(h)
    available=max(x['source']['last_modified_seconds'] for x in download['receipts'])
    record=dict(at=s.now(),choice=choice,center_values=values.tolist(),patch_means=means.tolist(),geometry=geo,rows=rows,receipts=download['receipts'],source_available_by=available,value_replay_passed=bool(download.get('audit_values')),scope='Fixed regional proxies; no turbine-output, nodal net-load, causal or electrical-topology equivalence asserted')
    s.write('cycles/'+str(choice['cycle'])+'.json',record)
    return record,geo

def run(p,start):
    assert ec.codes_get_api_version()=='2.49.0'
    selected=s.read(s.N/'SELECTION.json');choices=selected['pilot']+selected['remaining'];objects=s.read(I/'AUDITED_OBJECT_INDEX.json')['objects']
    resume=s.read(s.N/'RESUME_MANIFEST.json')
    geo=None;completed=0;pilot_done=False;outstanding=[]
    for choice in choices:
        path=s.N/'cycles'/f'{choice["cycle"]}.json'
        if str(path) not in resume['cycle_hashes']:
            assert not path.exists(), 'Unregistered completed cycle; inspect before resuming'
            outstanding.append(choice);continue
        assert s.sha(path)==resume['cycle_hashes'][str(path)]
        record=s.read(path);assert record['choice']==choice and len(record['rows'])==24
        assert record['source_available_by']<=choice['minimum_qualified_cutoff']
        for receipt in record['receipts']:
            if receipt.get('local'):assert s.sha(s.N/receipt['local'])==receipt['sha256']
        if geo is None:geo=record['geometry']
        else:assert geo==record['geometry']
        completed+=1
    assert completed==len(resume['cycle_hashes'])
    global RETAINED_BYTES
    RETAINED_BYTES=sum(f.stat().st_size for f in (s.N/'raw').glob('*.grib2'))
    assert RETAINED_BYTES<=p['maximum_retained_raw_bytes']
    tick(p,start,stage='verified_resume',completed_cycles=completed,total_cycles=len(choices),model_fits=0)
    efficiency_check(p,start,completed,len(choices))
    iterator=iter(outstanding);pending={};pool=ThreadPoolExecutor(max_workers=4)
    try:
        def submit():
            choice=next(iterator,None)
            if choice is not None:pending[pool.submit(fetch,choice,objects,p,start,choice['cycle'] in selected['pilot_cycle_ids'])]=choice
        for _ in range(4):submit()
        while pending:
            done,_=wait(pending,timeout=1,return_when=FIRST_COMPLETED)
            s.guard()
            if time.monotonic()-start>p['maximum_seconds']:raise TimeoutError('Extension bounded budget reached')
            for future in done:
                choice=pending.pop(future);download=future.result();download['audit_values']=choice['cycle'] in selected['pilot_cycle_ids']
                record,geo=decode(download,p,geo);completed+=1;del record,download;gc.collect()
                tick(p,start,stage='enriched_source_extraction',completed_cycles=completed,total_cycles=len(choices),model_fits=0)
                efficiency_check(p,start,completed,len(choices))
                if not pilot_done and all((s.N/'cycles'/f'{c}.json').exists() for c in selected['pilot_cycle_ids']):
                    pilot_done=True;s.write('PILOT_RESULT.json',dict(at=s.now(),cycles=len(selected['pilot_cycle_ids']),fields=8,anchors=len(geo),grid_points_per_anchor=9,leads=[3,4,5],value_replay=True,review_scope='Separate indexed access in same operator/process, not independent-person audit',seconds=time.monotonic()-start,network=dict(transport.COUNTS),V7_replaced=False,new_test_targets_read=False,accuracy_result=False))
                    emit('major_milestone',s.N/'PILOT_RESULT.json')
                submit()
    except BaseException:
        transport.CANCEL.set()
        for future in pending:future.cancel()
        raise
    finally:pool.shutdown(wait=True,cancel_futures=True)
    assert completed==len(choices)
    overlap_checks=0;raw_checks=0
    for c in choices:
        tick(p,start,stage='source_replay',done=overlap_checks,total_cycles=completed)
        new=s.read(s.N/'cycles'/f'{c["cycle"]}.json')
        prior=Y/'cycles'/f'{c["cycle"]}.json'
        if prior.exists():
            old=s.read(prior)
            assert np.array_equal(np.asarray(new['center_values'])[[0,2,3],:3,:],np.asarray(old['values']))
            overlap_checks+=27
        for receipt in new['receipts']:
            if receipt.get('local'):
                assert s.sha(s.N/receipt['local'])==receipt['sha256'];raw_checks+=1
    s.write('SOURCE_COMPLETE.json',dict(at=s.now(),cycles=completed,old_point_value_checks=overlap_checks,retained_raw_hash_checks=raw_checks,hashes={str(c['cycle']):s.sha(s.N/'cycles'/f'{c["cycle"]}.json') for c in choices},model_fits=0))
    import compare
    compare.run(p,lambda **kw:tick(p,start,**kw))

def main():
    lock=s.N/'MANAGER.lock';start=time.monotonic()
    with lock.open('x') as f:json.dump(dict(pid=os.getpid()),f)
    try:
        p=s.verify();s.guard(True)
        assert s.read(s.N/'SUPPORT_PREFLIGHT.json')['passed'], 'Insufficient pre-extraction event support'
        transport.COUNTS.update(p['inherited_counters'])
        s.write('STATUS.json',dict(at=s.now(),pid=os.getpid(),event='awaiting_exit_monitor_binding'))
        while not (s.N/'START_READY.json').exists():
            if time.monotonic()-start>55:raise TimeoutError('Missing exit monitor')
            time.sleep(.2)
        import psutil
        ready=s.read(s.N/'START_READY.json');assert ready['manager_pid']==os.getpid() and psutil.pid_exists(ready['exit_monitor_pid'])
        s.write('STATUS.json',dict(at=s.now(),pid=os.getpid(),event='step_process_started',stage='mechanism_weather_extension'))
        p=dict(p,maximum_seconds=min(p['maximum_seconds'],p['deadline_unix']-time.time()))
        with s.base.numeric('One mechanism-weather information trial; four matched HGB fits only after complete data and support checks'):
            run(p,start)
            s.base.verify_protected()
        evidence=s.N/'RESULT.json';eid=emit('needs_analysis',evidence)
        s.write('STATUS.json',dict(at=s.now(),pid=os.getpid(),event='finite_mechanism_queue_completed',event_id=eid))
    except ExtractionBudgetInfeasible as e:
        eid=emit('needs_analysis',s.N/'EFFICIENCY_RESULT.json')
        s.write('STATUS.json',dict(at=s.now(),pid=os.getpid(),event='source_pilot_cost_gate_closed',event_id=eid,error=str(e),model_fits=0))
    except InterruptedError as e:
        s.write('INTERRUPT_COUNTERS.json',dict(at=s.now(),network=dict(transport.COUNTS),elapsed_seconds=time.monotonic()-start))
        s.write('STATUS.json',dict(at=s.now(),pid=os.getpid(),event='controlled_stop_or_user_pause',classification='guard_stop',error=str(e)))
    except BaseException as e:
        s.write('FAILURE.json',dict(at=s.now(),error=repr(e),traceback=traceback.format_exc(),automatic_retry=False,V7_replaced=False,new_test_targets_read=False,network=dict(transport.COUNTS)))
        eid=emit('blocking_failure',s.N/'FAILURE.json');s.write('STATUS.json',dict(at=s.now(),pid=os.getpid(),event='step_stopped_or_failed',event_id=eid,error=repr(e)))
    finally:
        if lock.exists() and s.read(lock)['pid']==os.getpid():lock.unlink()

if __name__=='__main__':main()
