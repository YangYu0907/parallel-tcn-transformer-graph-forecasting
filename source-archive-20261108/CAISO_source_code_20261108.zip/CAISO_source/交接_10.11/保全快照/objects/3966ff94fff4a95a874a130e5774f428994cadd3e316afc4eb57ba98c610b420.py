import numpy as np
from common import *
def prepare(tick=lambda **kw:None):
 p=read(D/'PROTOCOL.json')
 with np.load(W/'INDICES.npz') as a:arr={k:a[k] for k in a.files}
 nodes=read(B/'dataset/compiled_train_june/manifest.json')['nodes'];assert len(nodes)==30
 lookup={};dates=[]
 for job in p['day_jobs']:
  rec=read(D/'days'/(job['id']+'.json'))
  if not rec['admitted']:continue
  dates.append(rec['date']);start=int(rec['start_utc']);end=int(rec['end_utc'])
  mat=np.full((int((end-start)//3600),30),np.nan)
  for r in rec['rows']:mat[(int(r['start'])-start)//3600,nodes.index(r['node'])]=float(r['MCC'])
  assert np.isfinite(mat).all()
  for j,row in enumerate(mat):lookup[start+j*3600]=(row,float(rec['available_by']))
 times,inv=np.unique(arr['time'],return_inverse=True);cube=np.zeros((len(times),30,9),np.float32);valid=np.zeros(len(times),bool)
 for j,t in enumerate(times):
  selected=[lookup.get(int((t+h)//3600*3600)) for h in [0,1800,3600]]
  if any(v is None or v[1]>t for v in selected):continue
  values=np.column_stack([v[0] for v in selected]);cube[j,:,:3]=values
  cube[j,:,3:6]=values-values.mean(axis=0);cube[j,:,6:9]=values.std(axis=0);valid[j]=True
  if j%8192==0:tick(stage='source_asof_join',cutoffs=j,total=len(times))
 retained=valid[inv];features=cube[inv,arr['node']];del cube
 path=E/'dam.npy';tmp=E/'.damtmp.npy';np.save(tmp,features);os.replace(tmp,path)
 arr['source_valid']=retained
 support=[];counts={}
 for fold in p['model_plan']['folds']:
  name=fold['name'];counts[name]={}
  for part,floor in [('fit',20),('cal',5),('eval',5)]:
   key=name+'_'+part;old=arr[key];ix=old[retained[old]];arr[key]=ix
   counts[name][part]=dict(original=len(old),retained=len(ix))
   assert len(ix) and np.all(np.diff(ix)>0)
   for c in [1,2]:
    et=np.unique(arr['time'][ix][arr['y'][ix]==c]);days=len(np.unique(et//86400))
    clusters=int(np.count_nonzero(np.diff(et)>3600)+bool(len(et)))
    support.append(dict(fold=name,part=part,sign=c,pairs=int(np.count_nonzero(arr['y'][ix]==c)),UTC_dates=days,clusters=clusters,minimum=floor,passed=days>=floor and clusters>=floor))
  assert arr['time'][arr[name+'_fit']].max()+3600<arr['time'][arr[name+'_cal']].min()
  assert arr['time'][arr[name+'_cal']].max()+3600<arr['time'][arr[name+'_eval']].min()
 save(E/'INDICES.npz',**arr)
 result=dict(at=now(),counts=counts,rows=support,retained_pairs=int(retained.sum()),original_pairs=len(retained),candidate_source_days=len(dates),
  all_original_evaluation_retained=all(v['eval']['original']==v['eval']['retained'] for v in counts.values()),
  original_bilateral_passed=all(r['passed'] for r in support),up_passed=all(r['passed'] for r in support if r['sign']==1),
  source_audit_still_required=True,support_floor_is_not_power_guarantee=True,event_clusters='Deduplicated cutoffs across nodes, gap>3600 seconds; UTC event dates; not independent cells',
  bindings={str(path):sha(path),str(E/'INDICES.npz'):sha(E/'INDICES.npz')})
 write(E/'SUPPORT.json',result)
 assert not result['original_bilateral_passed'] and result['up_passed']
 write(E/'BILATERAL_CLOSED.json',dict(at=now(),original_protocol_sha256=sha(D/'PROTOCOL.json'),
  status='closed_before_fit_due_insufficient_downward_training_support',fits=0,rule_changed=False,support_sha256=sha(E/'SUPPORT.json'),
  reason='Q1 DOWN6 dates6 clusters;Q2 DOWN10 dates12 clusters, both below20. New separate binary UP trial cannot establish DOWN benefit.'))
 return result

