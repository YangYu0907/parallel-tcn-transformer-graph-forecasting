"""Execute isolated TRAIN/June compilation only after corrected source admission.

No model import, training, old fitted state, Q3 target decoding, or 2026 reader.
Incomplete builds are preserved and cannot be mistaken for completed datasets.
"""
import argparse
import csv
from datetime import datetime
import json
import math
from pathlib import Path
import shutil
import sys
import time
import uuid
import compile_gate as gate

def execute():
    decision = gate.preflight()
    if decision['status'] != 'metadata_admitted_for_compilation_only':
        raise RuntimeError('Compiler admission blocked: ' + '; '.join(decision['errors']))
    config = gate.read(gate.ROOT/'compiler_config.json')
    capacity = gate.resources()
    if capacity['available_physical_GiB'] < 1.5 or capacity['available_commit_GiB'] < 2:
        raise MemoryError('NumPy compiler needs 1.5 GiB physical and 2 GiB commit headroom')
    if shutil.disk_usage(gate.ROOT).free < 3*2**30:
        raise OSError('Compiler needs 3 GiB free disk')
    gate.bound_process()
    import numpy as np
    import compile_math as cm
    if 'torch' in sys.modules:
        raise RuntimeError('Compiler must not import Torch')
    started = time.perf_counter()
    source_manifest = gate.read(config['eligibility_manifest'])
    source_folder = Path(config['eligibility_manifest']).parent
    stop, train_stop = config['prefix_stop'], config['train_stop']
    folder = gate.inside(config['output']) / ('build_'+uuid.uuid4().hex)
    folder.mkdir(parents=True, exist_ok=False)
    gate.write_new(folder/'STARTED.json', dict(decision=decision, resources=capacity,
        compiler_lock_sha256=gate.sha(gate.ROOT/'COMPILER_LOCK.json'),
        training_allowed=False, test_2026_targets_read=False))
    def save(name, array):
        with (folder/name).open('xb') as stream:
            np.save(stream, array, allow_pickle=False)
    def meta(name, value):
        gate.write_new(folder/name, value)
    def load_eligible(name, maximum, minimum=0):
        path = source_folder/name
        if gate.sha(path) != source_manifest['artifacts'][name]:
            raise RuntimeError('Eligibility artifact changed: '+name)
        values = np.load(path, allow_pickle=False)
        cm.validate_indices(values, maximum, name, minimum)
        save(name, values)
        return values
    fit_rows = load_eligible('training_scaler_rows.npy', train_stop)
    label_rows = load_eligible('training_label_rows.npy', train_stop)
    train = load_eligible('train_origins.npy', train_stop-11, 4320)
    anchors = load_eligible('registered_train_origins.npy', train_stop-11, 4320)
    june = load_eligible('june_origins.npy', stop-11, train_stop)
    june_hourly = load_eligible('registered_june_origins.npy', stop-11, train_stop)
    if not np.isin(june_hourly, june).all():
        raise RuntimeError('June hourly qualification mismatch')
    epochs, phases, shiftable = cm.phase_schedule(anchors, train, train_stop)
    unique = np.unique(epochs)
    for ep in range(6):
        save(f'epoch{ep+1}_origins.npy', epochs[ep])
        save(f'epoch{ep+1}_phases.npy', phases[ep])
    save('unique_phase_origins.npy', unique)
    save('phase_shiftable.npy', shiftable)
    publication_path = source_folder/'publication_arrays.npz'
    if gate.sha(publication_path) != source_manifest['artifacts']['publication_arrays.npz']:
        raise RuntimeError('Publication arrays changed')
    with np.load(publication_path, allow_pickle=False) as pub:
        timestamps = pub['timestamps_seconds'][:stop].copy()
        publications = np.stack([pub[k+'_last_publication_seconds'][:stop]
                                 for k in ('rtd', 'dam_load')], axis=1)
        source_valid = pub['source_row_valid'][:stop].copy()
    if timestamps.dtype != np.int64 or len(timestamps) != stop or not np.all(np.diff(timestamps)==300):
        raise RuntimeError('Publication timestamp grid changed')
    if timestamps[train_stop] != 1748736000 or timestamps[-1] != 1751327700:
        raise RuntimeError('TRAIN/June exact calendar boundaries changed')
    save('timestamps_seconds.npy', timestamps)
    save('timestamps_ns.npy', timestamps*10**9)
    save('forecast_publications_seconds.npy', publications)
    raw_receipts = []
    for field, member, tail, name, dtype in (
        ('price_archive','values',(30,4),'raw_prices.npy',np.float32),
        ('price_archive','timestamps_ns',(),'raw_price_times.npy',np.int64),
        ('external_archive','values',(4,),'raw_external.npy',np.float32),
        ('external_archive','missing',(4,),'raw_external_missing.npy',np.bool_),
        ('external_archive','timestamps_ns',(),'raw_external_times.npy',np.int64)):
        raw_receipts.append(dict(archive=config[field], **cm.prefix(
            config[field], member, stop, tail, folder/name, dtype)))
    prices = np.load(folder/'raw_prices.npy', mmap_mode='r', allow_pickle=False)
    external = np.load(folder/'raw_external.npy', mmap_mode='r', allow_pickle=False)
    missing = np.load(folder/'raw_external_missing.npy', mmap_mode='r', allow_pickle=False)
    for name in ('raw_price_times.npy','raw_external_times.npy'):
        raw_times = np.load(folder/name, mmap_mode='r', allow_pickle=False)
        if not np.array_equal(raw_times, timestamps*10**9):
            raise RuntimeError('Raw publication grid mismatch')
        cm.close(raw_times)
    with np.load(config['price_archive'], allow_pickle=False) as raw:
        nodes = raw['nodes'].astype(str).tolist()
        if raw['components'].astype(str).tolist() != cm.COMPONENTS or len(nodes)!=30:
            raise RuntimeError('Raw price component/node schema changed')
    with np.load(config['external_archive'], allow_pickle=False) as raw:
        if raw['features'].astype(str).tolist()[:2] != cm.EXTERNAL:
            raise RuntimeError('Raw external schema changed')
        caps = raw['age_cap_minutes'].astype(np.float64).reshape(-1)[:2]
    with Path(config['node_panel']).open(encoding='utf-8-sig',newline='') as stream:
        panel = list(csv.DictReader(stream))
    if [p['PNODE_ID'] for p in panel] != nodes:
        raise RuntimeError('Node panel order mismatch')
    tac = np.array([p['TAC_AREA_ID'] for p in panel])
    for a in range(0, stop, 4096):
        b = min(a+4096,stop)
        if not np.isfinite(prices[a:b]).all():
            raise RuntimeError('Raw price missingness; no silent interpolation allowed')
        mask = missing[a:b,:2]
        values = external[a:b,:2]
        if np.isfinite(values[mask]).any() or not np.isfinite(values[~mask]).all():
            raise RuntimeError('Raw external missingness mismatch')
    if missing[fit_rows,:2].any():
        raise RuntimeError('Admitted training scaler rows include missing forecasts')
    pc, ps = np.empty((30,4),np.float32), np.empty((30,4),np.float32)
    for node in range(30):
        for channel in range(4):
            pc[node,channel],ps[node,channel] = cm.fit(prices[:,node,channel],fit_rows)
    ec, es = np.empty(2,np.float32), np.empty(2,np.float32)
    for channel in range(2):
        ec[channel],es[channel] = cm.fit(external[:,channel],fit_rows)
    # Derived raw arrays are written incrementally. No full feature tensor lives in RAM.
    derived_path = folder/'raw_derived.npy'
    target = np.lib.format.open_memmap(derived_path,mode='w+',dtype=np.float32,shape=(stop,30,8))
    target.flush(); cm.close(target)
    derived_stats = {}
    for field in range(8):
        raw = np.empty((stop,30),np.float32)
        if field == 2:
            for area in np.unique(tac):
                ids = np.flatnonzero(tac==area)
                area_values = np.asarray(prices[:,ids,2],np.float32)
                raw[:,ids] = area_values-np.median(area_values,axis=1)[:,None]
                del area_values
        else:
            for node in range(30):
                series = prices[:,node,0]
                if field==0: raw[:,node] = series-cm.shift(series,12)
                elif field==1: raw[:,node] = cm.rolling_std(series,36)
                elif field==3: raw[:,node] = external[:,1]-external[:,0]
                else: raw[:,node] = cm.shift(series,(288,576,2016,4032)[field-4])
        center, scale = np.empty(30,np.float32), np.empty(30,np.float32)
        for node in range(30):
            center[node],scale[node] = cm.fit(raw[:,node],fit_rows)
        derived_stats[cm.NAMES[21+field]] = dict(center=center.tolist(),scale=scale.tolist())
        for a in range(0, stop, 2048):
            b=min(a+2048,stop)
            destination=np.load(derived_path,mmap_mode='r+',allow_pickle=False)
            destination[a:b,:,field]=raw[a:b]
            destination.flush(); cm.close(destination)
        del raw
        gate.check_working_set()
    scalers = dict(price_center=[pc.tolist()],price_scale=[ps.tolist()],
                   external_center=[ec.tolist()],external_scale=[es.tolist()],
                   derived=derived_stats,fit_rows_sha256=gate.sha(folder/'training_scaler_rows.npy'),
                   fit_count=len(fit_rows),fit_stop=train_stop,old_fitted_state_reused=False)
    meta('scalers.json',scalers)
    for name, shape in (('features.npy',(stop,30,29)),('target_scaled.npy',(stop,30))):
        target=np.lib.format.open_memmap(folder/name,mode='w+',dtype=np.float32,shape=shape)
        target.flush(); cm.close(target)
    for a in range(0,stop,1024):
        b=min(a+1024,stop)
        x=np.zeros((b-a,30,29),np.float32)
        x[:,:,:4]=(prices[a:b]-pc)/ps
        x[:,:,8:15]=cm.calendar(timestamps[a:b])[:,None,:]
        x[:,:,15:17]=np.where(missing[a:b,:2],0,(external[a:b,:2]-ec)/es)[:,None,:]
        x[:,:,17:19]=missing[a:b,:2,None].transpose(0,2,1)
        # Deliberate sentinel: only the origin-aware reader can materialize ages.
        x[:,:,19:21]=np.nan
        raw=np.load(derived_path,mmap_mode='r',allow_pickle=False)
        for field in range(8):
            stats=derived_stats[cm.NAMES[21+field]]
            norm=(raw[a:b,:,field]-np.array(stats['center'],np.float32))/np.array(stats['scale'],np.float32)
            x[:,:,21+field]=np.nan_to_num(norm,nan=0,posinf=0,neginf=0)
        cm.close(raw)
        destination=np.load(folder/'features.npy',mmap_mode='r+',allow_pickle=False)
        destination[a:b]=x; destination.flush(); cm.close(destination)
        destination=np.load(folder/'target_scaled.npy',mmap_mode='r+',allow_pickle=False)
        destination[a:b]=(prices[a:b,:,0]-pc[:,0])/ps[:,0]
        destination.flush(); cm.close(destination)
        gate.check_working_set()
    # Every stored usable input receives actual o-1 publication ages at batching.
    for origins in (unique,june):
        for origin in origins:
            if not source_valid[origin-288:origin].all():
                raise RuntimeError('Source validity disagrees with admitted origin')
            cm.age_at_origin(publications,timestamps,int(origin),caps)
    thresholds=np.empty((2,30),np.float64)
    for node in range(30):
        thresholds[:,node]=np.quantile(np.abs(np.asarray(prices[label_rows,node,0],np.float64)-pc[node,0]),[.9,.99])
    context=np.empty((len(anchors),30,2),np.float32)
    for index,origin in enumerate(anchors):
        history=(prices[origin-12:origin,:,0]-pc[:,0])/ps[:,0]
        context[index,:,0]=history[-1]
        context[index,:,1]=history[-1]-history.mean(axis=0,dtype=np.float32)
    limits=np.quantile(np.abs(context.astype(np.float64)),.99,axis=0,method='linear').astype(np.float32)
    if not np.isfinite(limits).all() or np.any(limits<=0):
        raise RuntimeError('Invalid fresh context bounds')
    meta('context_limits.json',dict(limits=limits.tolist(),quantile=.99,
        fit_origins_sha256=gate.sha(folder/'registered_train_origins.npy'),
        fit_count=len(anchors),float32_history_mean_backend='NumPy; model QA must verify tolerance'))
    meta('state_thresholds.json',dict(thresholds=thresholds.tolist(),center=pc[:,0].tolist(),
        quantiles=[.9,.99],fit_rows_sha256=gate.sha(folder/'training_label_rows.npy'),
        definition='Absolute raw price deviation from fresh TRAIN-history median',strict_comparison=True))
    support={str(year):[0]*6 for year in (2023,2024,2025)}
    metric_support={str(year):{metric:[0]*6 for metric in ('mae','mse','near','h12')} for year in (2023,2024,2025)}
    for a in range(0,len(unique),64):
        origins=unique[a:a+64]
        truth=np.stack([prices[o:o+12,:,0].T for o in origins]).astype(np.float64)
        last=np.asarray(prices[origins-1,:,0],np.float64)
        codes=cm.group_codes(truth,last,pc[:,0],thresholds)
        years=(timestamps[origins].astype('datetime64[s]').astype('datetime64[Y]').astype(int)+1970)
        for year in support:
            chosen=codes[years==int(year)]
            support[year]=(np.array(support[year])+np.bincount(chosen.reshape(-1),minlength=6)).tolist()
            for metric,subset in (('mae',chosen),('mse',chosen),('near',chosen[:,:,:4]),('h12',chosen[:,:,-1:])):
                metric_support[year][metric]=(np.array(metric_support[year][metric])+np.bincount(subset.reshape(-1),minlength=6)).tolist()
    zero_tasks=[f'{year}/group{group}/{metric}' for year in support for group in (3,4,5) for metric in ('mae','mse','near','h12') if metric_support[year][metric][group]==0]
    meta('risk_support.json',dict(counts_by_year_and_state=support,counts_by_year_metric_and_state=metric_support,
        zero_support_year_state_tasks=zero_tasks,all_36_original_tasks_supported=not zero_tasks,
        origins_sha256=gate.sha(folder/'unique_phase_origins.npy')))
    cm.close(prices); cm.close(external); cm.close(missing)
    phase=dict(dataset_revision=source_manifest['dataset_version'],epochs=[dict(epoch=i+1,
        origins_path=str((folder/f'epoch{i+1}_origins.npy').relative_to(gate.ROOT)),count=len(anchors),
        sha256=gate.sha(folder/f'epoch{i+1}_origins.npy'),updates=math.ceil(len(anchors)/4),
        max_target_end_exclusive=int(epochs[i].max()+12)) for i in range(6)],
        every_shifted_origin_eligible=True,shared_across_variants_and_seeds=True,
        June_hourly_origins=len(june_hourly),June_dense_origins=len(june),
        origin_selection_uses_Q3_errors=False,shiftable_count=int(shiftable.sum()),
        fallback_count=int((~shiftable).sum()),unique_origins=len(unique))
    meta('phase_manifest.json',phase)
    meta('raw_prefix_receipts.json',raw_receipts)
    # Detect producer or proof revision during a long compilation before committing.
    if gate.sha(config['eligibility_manifest']) != decision['eligibility_manifest_sha256']:
        raise RuntimeError('Eligibility manifest changed during compilation')
    if gate.sha(config['source_publication_binding_audit']) != decision['source_audit_sha256']:
        raise RuntimeError('Source audit changed during compilation')
    final_admission=gate.preflight()
    if final_admission['status']!='metadata_admitted_for_compilation_only':
        raise RuntimeError('Source identities or admission changed during compilation: '+str(final_admission['errors']))
    artifacts={p.name:dict(path=str(p.relative_to(gate.ROOT)),sha256=gate.sha(p))
               for p in sorted(folder.iterdir()) if p.is_file()}
    manifest=dict(status='compiled_pending_independent_dataset_and_model_QA',
        dataset_revision=source_manifest['dataset_version'],eligibility_manifest_sha256=decision['eligibility_manifest_sha256'],
        source_publication_audit_sha256=decision['source_audit_sha256'],
        compiler_lock_sha256=gate.sha(gate.ROOT/'COMPILER_LOCK.json'),
        prefix_stop=stop,train_target_stop_exclusive=train_stop,june_target_stop_exclusive=stop,
        cutoff='timestamps_ns[o-1]',node_count=30,feature_count=29,nodes=nodes,feature_names=cm.NAMES,
        age_caps_minutes=caps.tolist(),age_cache_is_sentinel=True,
        requires_origin_aware_age_overlay=True,old_fitted_state_reused=False,
        test_2026_targets_read=False,Q3_target_values_read=False,training_started=False,
        downstream_query_covariates_compiled=False,downstream_exogenous_normalizer_fitted=False,
        original_risk_tasks_supported=not zero_tasks,training_allowed=False,
        artifacts=artifacts,elapsed_seconds=time.perf_counter()-started,
        resources=gate.check_working_set(),numeric_threads=1,logical_CPUs=1,
        remaining=['Independent numeric dataset audit','Common-initialization/control QA',
                   'FiLM hidden-feature normalizer and runner','Six-stream QUERY source audit/compiler and runner',
                   'Backbone train/June selection runner','External baseline routing','Q3 freeze then extension'])
    gate.write_new(gate.inside(config['output'])/'manifest.json',manifest)
    return dict(status=manifest['status'],manifest=str(gate.inside(config['output'])/'manifest.json'),
                training_allowed=False,zero_risk_support_tasks=zero_tasks)

if __name__=='__main__':
    parser=argparse.ArgumentParser()
    parser.add_argument('--check-only',action='store_true')
    args=parser.parse_args()
    if args.check_only:
        result=gate.preflight()
        print(json.dumps(result,ensure_ascii=True))
        raise SystemExit(2 if result['errors'] else 0)
    print(json.dumps(execute(),ensure_ascii=True))
