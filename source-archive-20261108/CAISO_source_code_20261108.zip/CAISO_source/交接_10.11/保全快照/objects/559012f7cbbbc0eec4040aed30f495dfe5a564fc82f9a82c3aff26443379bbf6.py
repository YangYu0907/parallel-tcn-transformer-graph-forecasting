from revision_common import *
import zipfile,xml.etree.ElementTree as ET
def main():
 n=verify_protected()
 assert read(ROOT/'FIRST_BATCH_COMPLETE.json')['probability_audit']=='passed'
 assert not LOCK.exists(),'Unexpected active numerical worker; do not overwrite completion state'
 evidence={str(p.relative_to(ROOT)):sha(p) for p in ROOT.iterdir() if p.suffix.lower() in ['.py','.json','.csv','.docx','.pdf','.txt'] and p.name not in ['DELIVERY_CHECK.json','STATUS.json']}
 write(ROOT/'DELIVERY_CHECK.json',dict(at=now(),status='first_batch_verified',protected_files=n,document_pages_visually_reviewed=5,render='Packaged render_docx.py was attempted and failed because LibreOffice is absent; native Word export plus Poppler rendering completed and all pages visually inspected.',superscript_body_citations=True,original_teacher_and_paper_unchanged=True,all_local_training_workers_exited=True,source_and_result_hashes=evidence,implementation_repair='Resolved relative state-threshold path against project branch before any component fit; preserved source artifacts and registered design.',remaining=['matched price-only backbone training','new independent source admission and frozen confirmation','graph and spike-onset improvements not established'],new_scheduled_wakeups=False))
 progress(stage='first_batch_completed_and_verified',running_numerical_worker=False,V7_preserved=True,probability_development_completed=True,V7_ablations_completed=True,new_independent_confirmation=False,next_work='Matched information controls and source admission; no new background job started')
 print('Verified first batch; preserved files: '+str(n))
if __name__=='__main__':main()
