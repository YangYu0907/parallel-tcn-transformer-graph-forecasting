"""Separate calendar-based support replay; no fits or uninspected target access."""
import sys
from pathlib import Path
from datetime import datetime, timedelta, timezone
HERE=Path(__file__).resolve().parent
BASE=HERE.parent
sys.path.insert(0,str(BASE/'context_expert_v1_20260929'))
import gate


def main():
    result_path=HERE/'HORIZON_FEASIBILITY_v2.json'
    result=gate.read(result_path)
    protocol=gate.read(HERE/'HORIZON_DIAGNOSTIC_PROTOCOL_v2.json')
    assert result['protocol_sha256']==gate.sha(HERE/'HORIZON_DIAGNOSTIC_PROTOCOL_v2.json')
    for p,h in protocol['bindings'].items(): assert gate.sha(p)==h,p
    with gate.exclusive('V21 separate datetime-based support replay'):
        np,limiter=gate.runtime(False)
        panel=next(p for p in protocol['bindings'] if p.endswith('panel.npz'))
        with np.load(panel,allow_pickle=False) as z:
            cutoff=z['cutoff'];available=z['available'];days=z['days']
        folds=gate.read(BASE/'adaptive_experts_v4_20260929/FOLDS.json')
        utc=lambda x:datetime.fromtimestamp(int(x),timezone.utc)
        checks=0
        for row in result['rows']:
            p=next(p for p in protocol['bindings'] if p.endswith(f"{row['seed']}_{row['anchor']}.npz"))
            with np.load(p,allow_pickle=False) as z:
                ids=z['indices']
                mask=(z['prediction']!=z['anchor']).any(axis=(1,2))
            for f,reported in zip(folds,row['chronological_support']):
                boundary=min(utc(cutoff[i]) for i in f['evaluation'])
                prior=[int(i) for i in ids if
                    utc(cutoff[i])+timedelta(seconds=4200)<boundary-timedelta(days=2)
                    and max(utc(x) for x in available[i])<boundary]
                civil_dates=sorted({(utc(cutoff[i])+timedelta(minutes=5)).date() for i in prior})
                last=set(civil_dates[-6:])
                fit=[i for i in prior if (utc(cutoff[i])+timedelta(minutes=5)).date() not in last]
                cal=[i for i in prior if (utc(cutoff[i])+timedelta(minutes=5)).date() in last]
                assert reported['cutoff_utc']==boundary.isoformat()
                assert reported['earlier_compatible_origins']==len(prior)
                assert reported['fit_dates']==len({utc(cutoff[i]+300).date() for i in fit})
                assert reported['calibration_dates']==len({utc(cutoff[i]+300).date() for i in cal})
                assert len(set(fit)&set(cal))==0
                checks+=5
            assert 0<=row['protected_fraction']<=1
            assert 0<=row['max_possible_mae_reduction_percent']<=100
            assert row['NON_DEPLOYABLE_oracle_lower_bound']['mae']<=row['baseline']['mae']
            checks+=3
        protected=gate.read(HERE/'RETAINED_BASELINE_HASHES.json')['files']
        for p,h in protected.items(): assert gate.sha(p)==h,p
        gate.write(HERE/'HORIZON_FEASIBILITY_AUDIT.json',dict(
            at=gate.now(),status='passed',checks=checks,result_sha256=gate.sha(result_path),
            scope='Calendar date/set replay independently coded by same operator; not external-person review or fitted-model validation',
            protected_files_unchanged=len(protected),new_fits=0,new_test_targets_read=False,
            original_diagnostic_superseded='HORIZON_FEASIBILITY.json has invalid timestamp-support fields; use v2 only'))
        print(f'Calendar/support audit passed: {checks} checks; no new fits')


if __name__=='__main__':main()
