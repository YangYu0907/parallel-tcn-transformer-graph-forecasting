"""Post-hoc decomposition only; no model selection or prediction modification."""
from common import *

def main():
    with gate.exclusive('V7 frozen recovery-error decomposition'):
        np, lim = gate.runtime(False)
        verify()
        assert gate.read(HERE/'AUDIT.json')['result_sha256'] == gate.sha(HERE/'RESULT.json')
        rows = []
        for seed in SEEDS:
            with np.load(ART/'audited'/f'{seed}.npz') as z:
                y, full, pred, states = (z[k] for k in ('truth','FULL','CONTEXT','states'))
                m = states == 3
                e, d = (full-y)[m], (pred-full)[m]
                ae = abs(e+d)-abs(e)
                se = (e+d)**2-e**2
                wrong = d*e > 0
                positive = np.sort(se[se>0])[::-1]
                k = max(1, int(np.ceil(len(positive)*.1)))
                rows.append(dict(seed=seed, cells=int(m.sum()),
                    active=int((abs(d)>1e-9).sum()),
                    wrong_direction=int(wrong.sum()),
                    harmful_MSE_cells=int((se>0).sum()),
                    helpful_MSE_cells=int((se<0).sum()),
                    net_MSE_change=float(se.mean()),
                    positive_SSE=float(se[se>0].sum()), negative_SSE=float(se[se<0].sum()),
                    top_tenth_of_harmful_cells=k,
                    top_tenth_share_of_added_SSE=float(positive[:k].sum()/positive.sum()),
                    wrong_direction_mean_abs_correction=float(abs(d[wrong]).mean()),
                    helpful_mean_abs_correction=float(abs(d[se<0]).mean()),
                    mean_absolute_error_change=float(ae.mean())))
        write(HERE/'RECOVERY_TAIL_DIAGNOSIS.json', dict(at=gate.now(),
            status='posthoc_frozen_diagnostic_only', rows=rows,
            unit='dependent origin-node-horizon cells, not independent episodes',
            predictions_modified=False, new_test_targets_read=False))
        print(json.dumps(rows))

if __name__ == '__main__':
    main()
