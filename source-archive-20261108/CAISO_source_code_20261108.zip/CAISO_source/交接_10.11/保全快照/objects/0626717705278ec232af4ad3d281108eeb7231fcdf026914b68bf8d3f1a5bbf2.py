from common import *

def main():
    with gate.exclusive('V11 single selective relative-error router'):
        np,lim=gate.runtime(False);verify();start_budget();import modelmath as mm
        for p,h in gate.read(HERE/'DATA_ADMISSION.json')['artifacts'].items():assert gate.sha(p)==h
        folds=gate.read(B/'adaptive_experts_v4_20260929/FOLDS.json');ids=np.concatenate([f['evaluation'] for f in folds])
        with np.load(A4/'panel.npz') as z:cutoff=z['cutoff'];oreg=z['observable_regime'];origins=z['origins']
        dense_index={int(o):j for j,o in enumerate(ids)}
        for seed in SEEDS:
            with np.load(ART/f'matrix/{seed}.npz') as z:d={k:z[k] for k in z.files}
            with np.load(ART.parent/f'risk_likelihood_v10_20260930/predictions/{seed}.npz') as z:
                base=z['V7'];full=z['FULL'];v10=z['LIKELIHOOD'];assert np.array_equal(z['eval_indices'],ids)
            out={a:base.copy() for a in ARMS};out['FULL']=full;out['V10']=v10
            choices=np.ones(base.shape,np.int8);mask=np.broadcast_to((oreg[ids]==2)[:,:,None],base.shape)
            out['FIXED_HALF'][mask]=.5*(base[mask]+full[mask]);logs=[]
            # Supervision is constructed only from time-eligible rows inside each fold.
            for f in folds:
                tick(stage='one_relative_loss_router',seed=seed,fold=f['id'])
                first=float(cutoff[f['evaluation']].min());eligible=mm.eligible(d['issued'],d['available'],first)
                dates=np.unique(d['days'][eligible]);em=np.isin(d['origin_index'],f['evaluation']);ei=np.flatnonzero(em)
                artifact=ART/f'fits/{seed}_{f["id"]}.pkl'
                rr=np.array([dense_index[int(o)] for o in d['origin_index'][ei]]);nn=d['node'][ei];hh=d['horizon'][ei]
                if len(dates)<5:
                    logs.append(dict(fold=f['id'],status='abstained_insufficient_dates',dates=len(dates)));continue
                cal=eligible&np.isin(d['days'],dates[-2:]);fit=eligible&~cal
                # Never give the learner evaluation labels, even though historical
                # source arrays are present for later scoring.
                chosen=np.flatnonzero(eligible);x=d['X'][chosen];y=mm.losses(d['experts'][chosen],d['truth'][chosen],float(d['scale']))
                fm=fit[chosen];cm=cal[chosen];dd=d['days'][chosen]
                if artifact.exists():obj=load(artifact)
                else:
                    guard=mm.train_guard(x,y,dd,fm,cm)
                    globaldiff=y.mean(0);globalchoice=int(mm.choices(globaldiff[None,:])[0])
                    obj=dict(protocol_sha256=gate.sha(HERE/'PROTOCOL.json'),guard=guard,globalchoice=globalchoice,fit_rows=chosen[fm],calibration_rows=chosen[cm],evaluation_rows=ei,cutoff=first)
                    dump(artifact,obj)
                assert obj['protocol_sha256']==gate.sha(HERE/'PROTOCOL.json')
                bounds=mm.upper(obj['guard'],d['X'][ei]);pick=mm.choices(bounds)
                out['SELECTIVE'][rr,nn,hh]=d['experts'][ei,pick];choices[rr,nn,hh]=pick
                out['PAST_GLOBAL'][rr,nn,hh]=d['experts'][ei,obj['globalchoice']]
                save(ART/f'fits/{seed}_{f["id"]}_routing.npz',evaluation_rows=ei,upper=bounds,choice=pick)
                logs.append(dict(fold=f['id'],fit_rows=int(fit.sum()),calibration_rows=int(cal.sum()),fit_dates=len(dates)-2,calibration_dates=2,evaluation_rows=len(ei),choices=np.bincount(pick,minlength=3).tolist(),globalchoice=obj['globalchoice'],latest_fit_release=float(d['available'][fit].max()),latest_calibration_release=float(d['available'][cal].max()),first_evaluation=first))
            path=ART/f'predictions/{seed}.npz';save(path,origins=origins[ids],eval_indices=ids,choice=choices,mask=mask,**out)
            write(HERE/f'receipts/{seed}.json',dict(at=gate.now(),sha256=gate.sha(path),folds=logs));print(str(seed)+' finite router completed',flush=True)
        write(HERE/'FIT_COMPLETE.json',dict(at=gate.now(),status='nine_chronological_router_fits_complete',new_test_targets_read=False,neural_updates=0,artifacts={str(p):gate.sha(p) for p in (ART/'predictions').glob('*.npz')}))
if __name__=='__main__':main()
