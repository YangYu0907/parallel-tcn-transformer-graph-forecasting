from pathlib import Path
from zipfile import ZipFile
from datetime import datetime, timezone
import json, hashlib, shutil, sys
from lxml import etree as E
from PIL import Image
from docx import Document
sys.stdout.reconfigure(encoding='utf-8')
R=Path(__file__).resolve().parents[1]
O=R.parent/'manuscript_20261001_v7_focused'
ns={'w':'http://schemas.openxmlformats.org/wordprocessingml/2006/main',
    'a':'http://schemas.openxmlformats.org/drawingml/2006/main',
    'r':'http://schemas.openxmlformats.org/officeDocument/2006/relationships',
    'wp':'http://schemas.openxmlformats.org/drawingml/2006/wordprocessingDrawing',
    'm':'http://schemas.openxmlformats.org/officeDocument/2006/math'}
def sha(p): return hashlib.sha256(p.read_bytes()).hexdigest()
for folder in ['figures','evidence']:
 for p in (O/folder).rglob('*'):
  if p.is_file():
   dest=R/folder/p.relative_to(O/folder)
   dest.parent.mkdir(parents=True,exist_ok=True)
   if not dest.exists(): shutil.copy2(p,dest)
for name in ['Energy_supplementary.docx','Energy_supplementary.pdf',
             'Reference_verification_list.csv','Reference_verification_list.html','references.bib']:
 shutil.copy2(O/name,R/name)
mapping=[('rId97','image26.png','Fig01_research_framework',
          'Integrated research workflow: qualified data, graph and parallel temporal backbone, CAISO context correction, and separate evaluation panels.'),
         ('rId21','image12.png','Fig02_final_admission',
          'CAISO source admission flow, six monthly coverage calendars, and observed publication-cutoff-target timeline.'),
         ('rId22','image13.png','Fig03_parallel_architecture',
          'Dynamic graph encoding, parallel causal TCN and Transformer branches, context-and-horizon attention, shared direct multi-horizon prediction head.')]
with ZipFile(O/'Energy_manuscript.docx') as src:
 before=E.fromstring(src.read('word/document.xml'))
 root=E.fromstring(src.read('word/document.xml'))
 changed={}
 dims=[]
 for rid,media,stem,alt in mapping:
  path=R/'figures'/(stem+'_en.png')
  changed['word/media/'+media]=path.read_bytes()
  blips=root.xpath('.//a:blip[@r:embed="'+rid+'"]',namespaces=ns)
  assert len(blips)==1,(rid,len(blips))
  inline=blips[0].xpath('ancestor::wp:inline',namespaces=ns)[0]
  ext=inline.find('wp:extent',namespaces=ns)
  cx=int(ext.get('cx'))
  with Image.open(path) as im: width,height=im.size
  cy=round(cx*height/width)
  ext.set('cy',str(cy))
  for e in inline.xpath('.//a:xfrm/a:ext',namespaces=ns):
   e.set('cx',str(cx));e.set('cy',str(cy))
  inline.find('wp:docPr',namespaces=ns).set('descr',alt)
  dims.append({'figure':stem,'source':str(path),'pixels':[width,height],
               'word_width_in':cx/914400,'word_height_in':cy/914400,'sha256':sha(path)})
 changed['word/document.xml']=E.tostring(root,xml_declaration=True,encoding='UTF-8',standalone=True)
 with ZipFile(R/'Energy_manuscript.docx','w') as dst:
  for info in src.infolist(): dst.writestr(info,changed.get(info.filename,src.read(info.filename)))
checks=[]
def check(name,ok):
 assert ok,name
 checks.append(name)
with ZipFile(O/'Energy_manuscript.docx') as src,ZipFile(R/'Energy_manuscript.docx') as dst:
 check('zip_entries_unchanged',src.namelist()==dst.namelist())
 diff=[n for n in src.namelist() if src.read(n)!=dst.read(n)]
 check('only_three_image_entries_and_document_xml_changed',set(diff)==set(changed))
after=root
for xp,name in [('.//w:t/text()','all_manuscript_text'),('.//m:oMath','10_editable_equations'),
                ('.//w:tbl','all_7_tables'),('.//w:bookmarkStart','bookmarks'),
                ('.//w:fldSimple','cross_reference_fields'),('.//w:instrText','field_instructions')]:
 def data(rt):
  values=rt.xpath(xp,namespaces=ns)
  return [E.tostring(v) if isinstance(v,E._Element) else v for v in values]
 check(name+'_unchanged',data(before)==data(after))
check('14_figures_retained',len(Document(R/'Energy_manuscript.docx').inline_shapes)==14)
check('10_native_equations',len(root.xpath('.//m:oMath',namespaces=ns))==10)
for n in ['Energy_supplementary.docx','Energy_supplementary.pdf','references.bib',
          'Reference_verification_list.csv','Reference_verification_list.html']:
 check('unchanged:'+n,sha(O/n)==sha(R/n))
for p in (O/'evidence').rglob('*'):
 if p.is_file():check('evidence:'+str(p.relative_to(O)),sha(p)==sha(R/p.relative_to(O)))
for p in (O/'figures').iterdir():
 if p.is_file() and not p.name.startswith(('Fig01_','Fig02_','Fig03_')):
  check('unchanged_figure:'+p.name,sha(p)==sha(R/'figures'/p.name))
out={'at':datetime.now(timezone.utc).isoformat(),'status':'passed','checks':len(checks),
     'check_names':checks,'old_version':str(O),'original_docx_sha256':sha(O/'Energy_manuscript.docx'),
     'changed_zip_entries':diff,'replacement_figures':dims,'new_experimental_results':False,
     'text_tables_references_equations_and_results_unchanged':True,'render_qa_pending':True}
(R/'qa/CONTENT_QA.json').write_text(json.dumps(out,ensure_ascii=False,indent=2),encoding='utf-8')
print(json.dumps({'checks':len(checks),'figure_dimensions':dims},ensure_ascii=False))
