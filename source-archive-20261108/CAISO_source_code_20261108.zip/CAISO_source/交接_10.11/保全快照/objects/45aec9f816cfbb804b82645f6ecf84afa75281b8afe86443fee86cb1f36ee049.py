"""Separate numeric and timestamp recomputation of the development adapter."""
from pathlib import Path
import sys
HERE = Path(__file__).resolve().parent
sys.path.insert(0, str(HERE.parent / 'context_expert_v1_20260929'))
import gate


def main():
    with gate.exclusive('V17 independent-code input recomputation, same operator'):
        np, limiter = gate.runtime(False)
        result = gate.read(HERE/'INPUT_RESULT.json')
        for p, h in result['bindings'].items():
            assert gate.sha(p) == h, p
        for p, h in result['artifacts'].items():
            assert gate.sha(p) == h, p
        paths = {Path(p).name: p for p in result['artifacts']}
        contract = gate.read(HERE/'INPUT_CONTRACT.json')
        normal = gate.read(HERE/'NORMALIZER.json')
        with np.load(paths['source_hours.npz']) as z:
            hours, mw, pub, fit_ix = [z[k] for k in ('hour','raw_MW','publication','train_hour_indices')]
        assert np.isfinite(mw).all() and np.all(np.diff(hours) > 0)
        lookup = {int(h):i for i,h in enumerate(hours)}
        # Recompute from the actual raw development zip rows, not the adapter cache.
        reader = gate.load('v17_independent_csv', HERE.parent/'stress_source_feasibility_v16_20260930/audit_renewable.py')
        q = gate.read(HERE.parent/'stress_source_feasibility_v16_20260930/renewable_queue/completion.json')
        fields = [tuple(f.split('|')) for f in contract['fields']]
        compared = 0
        for path in q['source_receipt_bindings']:
            receipt = gate.read(path)
            if not receipt['job']['id'].startswith('development_'):
                continue
            assert gate.sha(receipt['body']) == receipt['sha256']
            for row in reader.rows(receipt['body']):
                pair = (row['TRADING_HUB'],row['RENEWABLE_TYPE'])
                hour = reader.stamp(row['INTERVALSTARTTIME_GMT'])
                if pair in fields and hour in lookup:
                    assert float(row['MW']) == mw[lookup[hour],fields.index(pair)]
                    compared += 1
        data = gate.read(HERE.parent/'chronological_expert_pilot_v14_20260930/DATA.json')
        times = np.load(data['timestamps'],mmap_mode='r')
        checks = {}; train_used = set()
        for split in ('train','valid','evaluation'):
            gate.guard()
            with np.load(paths[split+'_renewables.npz']) as z:
                origins, cutoff, target_hours, publication, raw, scaled = [z[k] for k in
                    ('origins','cutoff','hour','publication','raw_MW','features')]
            assert np.array_equal(origins,np.load(Path(data['directory'])/(split+'.npy')))
            assert np.array_equal(cutoff, times[origins-1])
            ix = np.empty(target_hours.shape,dtype=np.int64)
            for j,o in enumerate(origins):
                for h in range(12):
                    t = int(times[int(o)+h]); source_hour = (t//3600)*3600
                    assert target_hours[j,h] == source_hour
                    ix[j,h] = lookup[source_hour]
                    assert publication[j,h] == pub[ix[j,h]] <= int(cutoff[j])
            assert np.array_equal(raw,mw[ix])
            assert np.allclose(scaled*np.array(normal['scale'])+normal['mean'],raw,atol=1e-9)
            if split=='train':
                train_used.update(ix.ravel().tolist())
            checks[split] = dict(origins=len(origins),all_12_horizons_5_fields_exact=True)
        assert sorted(train_used) == sorted(fit_ix.tolist())
        # A separate two-pass computation verifies TRAIN-only normalization.
        mean = np.sum(mw[sorted(train_used)],axis=0)/len(train_used)
        sd = np.sqrt(np.sum((mw[sorted(train_used)]-mean)**2,axis=0)/len(train_used))
        assert np.allclose(mean,normal['mean']) and np.allclose(sd,normal['scale'])
        # Cutoff equality accepted; a one-second-later revision rejected. UTC
        # arithmetic also keeps the two repeated local DST hours distinct.
        assert 100 <= 100 and not 101 <= 100
        assert len({1730610000//3600,1730613600//3600}) == 2
        gate.write(HERE/'INPUT_AUDIT.json',dict(at=gate.now(),status='passed',
            audit_type='Separate code recomputation by same operator, not external certification',
            bindings={str(HERE/'INPUT_RESULT.json'):gate.sha(HERE/'INPUT_RESULT.json'),
                      str(HERE/'INPUT_CONTRACT.json'):gate.sha(HERE/'INPUT_CONTRACT.json')},
            raw_forecast_field_rows_replayed=compared,checks=checks,
            TRAIN_normalization_recomputed=True,UTC_hour_alignment_verified=True,
            all_registered_development_origins_retained=True,new_test_values_read=False,
            price_targets_read=False,research_model_fitted=False,
            fresh_confirmation_admitted=False))
        print('V17 input audit passed: '+str(compared)+' raw MW rows replayed.')


if __name__ == '__main__':
    main()
