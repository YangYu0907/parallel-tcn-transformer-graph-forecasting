"""Frozen 20-case descriptive evaluation, admitted TRAIN/June prefix only."""
from pathlib import Path
from contextlib import contextmanager
from datetime import datetime, timezone
import hashlib, importlib.util, json, os, sys, uuid
HERE=Path(__file__).resolve().parent
ROOT=HERE.parent
OLD=ROOT/'validation_controls_20260920'
COMMON=ROOT/'common_sampling_evaluation_20260923'
SEAL=HERE/'EVALUATION_LOCK.json'
sys.path.insert(0,str(ROOT/'source'))
import compile_gate as resource_api
LOCK=Path('D:/Desktop/数据科学_论文/研究优化_20260818/logs/NEURAL_RUN.lock')
def now():return datetime.now(timezone.utc).isoformat()
def need(ok,msg):
    if not ok:raise RuntimeError(msg)
def read(p):return json.loads(Path(p).read_text(encoding='utf-8-sig'))
def inside(p):
    p=Path(p);p=(ROOT/p if not p.is_absolute() else p).resolve()
    need(p.is_relative_to(ROOT),'Path escapes branch');return p
def rel(p):return str(inside(p).relative_to(ROOT))
def sha(p):
    h=hashlib.sha256()
    with Path(p).open('rb') as f:
        for b in iter(lambda:f.read(1024*1024),b''):h.update(b)
    return h.hexdigest()
def write(p,v,replace=False):
    p=inside(p);p.parent.mkdir(parents=True,exist_ok=True)
    t=p.with_name(p.name+'.'+uuid.uuid4().hex+'.pending')
    with t.open('xb') as f:f.write(json.dumps(v,ensure_ascii=False,indent=2,allow_nan=False).encode('utf-8'));f.flush();os.fsync(f.fileno())
    if replace:os.replace(t,p)
    else:t.rename(p)
def load_module(name,p):
    spec=importlib.util.spec_from_file_location(name,p);m=importlib.util.module_from_spec(spec);spec.loader.exec_module(m);return m
def boundary():
    for folder in (ROOT,HERE,HERE/'queue'):
        for name in ('STOP_REQUESTED','STOP_REQUESTED.json'):
            if (folder/name).exists():raise InterruptedError('User stop: '+str(folder/name))
    p=read(ROOT.parent/'RESEARCH_PAUSED.json')
    if p.get('status')!='resumed_by_user' or p.get('stop_preparation_and_training'):raise InterruptedError('User paused')
def guard(launch=False):
    boundary();r=resource_api.resources();floor=5 if launch else 4
    if min(r.values())<floor:raise MemoryError(f'Requires {floor} GiB physical/commit: {r}')
    return r
@contextmanager
def exclusive(action):
    guard(True)
    import psutil
    owner=dict(pid=os.getpid(),created=psutil.Process().create_time(),token=uuid.uuid4().hex,action=action,at=now())
    with LOCK.open('x',encoding='utf-8') as f:json.dump(owner,f);f.flush();os.fsync(f.fileno())
    try:
        resource_api.bound_process();guard();yield
    finally:
        need(read(LOCK)==owner,'Lock owner changed');write(HERE/'lock_releases'/(owner['token']+'.json'),dict(owner=owner,at=now()));LOCK.unlink()
def runtime():
    resource_api.bound_process()
    import numpy as np
    from threadpoolctl import threadpool_limits,threadpool_info
    limiter=threadpool_limits(1);need(all(x['num_threads']==1 for x in threadpool_info()),'Thread limit')
    guard();return np,limiter
def verify():
    boundary();s=read(SEAL);need(s['status']=='sealed_twenty_case_evaluation','Seal status')
    for p,d in s['bindings'].items():need(sha(inside(p))==d,'Bound input changed: '+p)
    need(len(s['cases'])==20 and len({x['id'] for x in s['cases']})==20,'Case count');return s
def seal():
    boundary();need(not SEAL.exists(),'Seal already exists')
    sys.path.insert(0,str(OLD));old=load_module('prior_controls',OLD/'controls_summary.py');b=old.Binder()
    prior=b.json(OLD/'VALIDATION_LOCK.json')
    for p,d in prior['sources'].items():b.file(p,d)
    pr=b.json(OLD/'result.json','335c554db811c89bbdbdfedf2b8d2f8e624756567a58f992bcb30847a560afd0')
    pa=b.json(OLD/'independent_numeric_audit_reviewed.json','4782bf1ab4ea34978619e9d50150cff20586e73b769b555237663cdcb8b62ab2')
    need(pa['status']=='passed_independent_controls_June284_numeric_audit' and pa['result_sha256']==sha(OLD/'result.json') and pa['validation_lock_sha256']==sha(OLD/'VALIDATION_LOCK.json') and pa['original_execution_exit_code']==0,'Prior numeric audit')
    mech=ROOT/'mechanism_controls_20260920'
    mc=b.json(mech/'queue/completion.json','5f48f5b23527d23c5d2cb39a49a14a5b7c8cfb490273956abbbca77c5b70a2fa')
    b.file(mech/'SEAL.json',mc['seal_sha256'])
    need(len(mc['step_receipts'])==96,'Mechanism queue incomplete')
    for name,d in mc['step_receipts'].items():
        receipt=b.json(mech/'queue/steps'/name,d);need(receipt['exit_code']==0,'Mechanism actual exit')
        marker=b.json(receipt['marker']['path'],receipt['marker']['sha256'])
        need(marker['status']==receipt['step']['expected_status'],'Mechanism receipt marker')
    mpath=ROOT/'dataset/compiled_train_june/manifest.json'
    m=b.json(mpath,'f84ae6c3b3bcb9c8f0cf80dc34c6e102631c74aa0d012fd0263ba2beefe6c725')
    ap=mpath.parent/'audit.json';a=b.json(ap,'a38fd20f98fcd37ff90d5ba2fe5b547234534599d70683fa6acc26b5a6039aec')
    need(a['status']=='passed' and a['dataset_manifest_sha256']==sha(mpath),'Data audit')
    need(m['prefix_stop']==219168 and m['train_target_stop_exclusive']==210528 and not m['Q3_target_values_read'] and not m['test_2026_targets_read'],'Data cutoff')
    for row in m['artifacts'].values():b.file(row['path'],row['sha256'])
    cases=prior['cases']+[old.primary_case(b,seed,variant,sha(mpath),sha(ap)) for seed in (20260813,20260814) for variant in ('GLOBAL','GTF','STATIC','SELF')]
    need(len(cases)==20,'20 cases required')
    for p in sorted(HERE.glob('*.py')):b.file(p)
    for p in (HERE/'PROTOCOL.json',HERE/'watch_manager_exit.ps1',COMMON/'reductions.py',COMMON/'audit.py',ROOT/'source/compile_gate.py'):b.file(p)
    qa=b.json(HERE/'synthetic_qa.json');need(qa['status']=='passed','QA missing')
    for p,d in qa['sources'].items():b.file(p,d)
    write(SEAL,dict(status='sealed_twenty_case_evaluation',at=now(),cases=cases,bindings=b.files,
        dataset_manifest=rel(mpath),prior_result=rel(OLD/'result.json'),nodes=m['nodes'],
        original_twelve_preserved=True,model_selection_changed=False,heldout_targets_read=False))
    print(json.dumps(dict(status='sealed',cases=len(cases),bindings=len(b.files),sha256=sha(SEAL))))
if __name__=='__main__':
    if sys.argv[1]=='seal':seal()
    else:print(json.dumps(dict(status='passed',cases=len(verify()['cases']),resources=guard(True))))
