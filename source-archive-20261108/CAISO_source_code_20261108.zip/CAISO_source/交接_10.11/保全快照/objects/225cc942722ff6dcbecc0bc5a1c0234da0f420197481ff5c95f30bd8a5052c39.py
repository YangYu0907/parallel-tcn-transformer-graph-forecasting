"""Independent arithmetic and sampled head inference; same operator, not external review."""
from base import *
import numpy as np
def main():
    verify()
    with numeric('recovery separate arithmetic and inference audit'):
        from features import features_at
        from fit import temperature
        tick=timer('audit');r=read(HERE/'RESULT.json');checks=0
        for n,h in r['replays'].items():assert sha(HERE/n)==h;checks+=1
        ds={}
        for fold in [1,2]:
            with np.load(HERE/f'REPLAY_fold{fold}.npz') as z:ds[fold]={k:z[k] for k in z.files}
        for row in r['rows']:
            d=ds[row['fold']];err=d[row['model']]-d['truth']
            assert np.allclose([abs(err).sum()/err.size,np.sqrt(np.dot(err.ravel(),err.ravel())/err.size)],
                [row['mae'],row['rmse']],rtol=1e-11);checks+=2
            for s in row['states']:
                m=d['states']==s['state'];ee=err[m]
                assert np.allclose([np.sum(abs(ee))/len(ee),np.sqrt(np.dot(ee,ee)/len(ee))],[s['mae'],s['rmse']],rtol=1e-11);checks+=2
        for row in r['details']:
            d=ds[row['fold']];name=row['model'];seed=name.rsplit('_',1)[1];base=d['BASE_'+seed];p=d[name]
            assert np.array_equal(p[:,:,:7],base[:,:,:7]);checks+=1
            assert np.array_equal(p[d['states']<3],base[d['states']<3]);checks+=1
            assert parent.qualification(p,base,d['truth'],d['states'],d['days'])['passed']==row['preservation_vs_BASE']['passed'];checks+=1
        raw,times,_,_=parent.arrays()
        for fold in [1,2]:
            tick(fold=fold);folder=HERE/f'fold{fold}';fr=read(folder/'FROZEN.json')
            for n,h in fr['model_hashes'].items():assert sha(folder/n)==h;checks+=1
            with np.load(folder/'PREDICTIONS.npz') as z:
                ids=np.array([0,len(z['origins'])//2,len(z['origins'])-1]);oo=z['origins'][ids]
                st=read(OLD/f'fold{fold}_stats.json')['neural'];f,last=features_at(raw,oo,st)
                node=np.tile(np.repeat(np.arange(30),5),len(oo));hh=np.tile(np.arange(8,13)/12,len(oo)*30)
                X=np.column_stack([np.repeat(f.reshape(-1,37),5,0),np.eye(30)[node],hh]).astype('float32')
                rec=load(folder/'recovery.pkl')['model'];cls=load(folder/'transition.pkl')['model']
                c=np.array(st['center']);q=np.array(st['thresholds'])[1]
                pp=(c[node]+q[node]*np.clip(rec.predict(X),-1,1)).reshape(-1,30,5)
                pr=temperature(cls.predict_proba(X),fr['temperature'])[:,1].reshape(-1,30,5)
                assert np.allclose(pp,z['recovery'][ids],atol=1e-9) and np.allclose(pr,z['probability'][ids],atol=1e-9);checks+=2
                assert np.array_equal(abs(last-c)>q,z['eligible'][ids]);checks+=1
        with np.load(HERE/'PROBABILITY_REPLAY.npz') as z:
            y=z['truth']
            for row in r['probability']:
                p=ds[2][row['model']];weighted=.5*abs(p-y);bounds=z[row['model']]
                for i,alpha in enumerate([.1,.2]):
                    l=bounds[...,i,0];u=bounds[...,i,1]
                    score=u-l+2/alpha*np.maximum(l-y,0)+2/alpha*np.maximum(y-u,0)
                    weighted+=alpha/2*score
                    assert np.allclose([((l<=y)&(y<=u)).mean(),(u-l).mean(),score.mean()],
                        [row['intervals'][i][k] for k in ['coverage','width','interval_score']]);checks+=3
                assert abs(weighted.mean()/2.5-row['wis'])<1e-10;checks+=1
        d=ds[2];y=d['truth'];days=d['days'];block=days//7;uniq=np.unique(block)
        loss=lambda name:abs(d[name]-y).mean((1,2))
        avg=lambda arm:np.mean([loss(f'{arm}_{seed}') for seed in SEEDS],axis=0)
        candidate=avg('TRANSITION');controls={'BASE_COMPLETE':avg('BASE'),'HEAD_ONLY':avg('HEAD_ONLY'),'FULL':loss('FULL')}
        counts=np.array([(block==b).sum() for b in uniq]);rng=np.random.default_rng(20261004);draw=rng.integers(0,len(uniq),(2000,len(uniq)));stats=[]
        for name,values in controls.items():
            delta=values-candidate;sums=np.array([delta[block==b].sum() for b in uniq]);boot=sums[draw].sum(1)/counts[draw].sum(1)
            p=(1+np.sum(abs(boot-delta.mean())>=abs(delta.mean())))/(len(boot)+1)
            stats.append(dict(control=name,mae_difference=float(delta.mean()),ci95=np.quantile(boot,[.025,.975]).tolist(),p=float(p)))
        prior=0.
        for j,k in enumerate(np.argsort([v['p'] for v in stats])):
            prior=max(prior,min(1.,(len(stats)-j)*stats[k]['p']));stats[k]['holm_p']=prior
        write(HERE/'STATISTICS.json',dict(at=now(),status='exploratory_only',dates=len(np.unique(days)),calendar_blocks=len(uniq),
            method='Paired seven-calendar-day bins, gaps retained,2000replicates,losses averaged over old router seeds,three-control Holm family',rows=stats))
        verify()
        write(HERE/'AUDIT.json',dict(at=now(),status='separate_arithmetic_and_inference_replay_passed',checks=checks,
            result_sha256=sha(HERE/'RESULT.json'),statistics_sha256=sha(HERE/'STATISTICS.json'),
            screen_passed=r['screen_passed'],protected_files=18,V7_replaced=False,new_test_targets_read=False,external_human_review=False))
        tick(status='complete')
if __name__=='__main__':main()

