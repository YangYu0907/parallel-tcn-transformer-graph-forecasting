"""Separate numerical and provenance review of existing-weight diagnostics."""
from pathlib import Path
import sys, math, statistics, csv, platform
from collections import defaultdict
P=Path(__file__).resolve().parent; B=P.parent; D=B/'h1_final_evaluation_v1_20260927'
sys.path.insert(0,str(D))
from runtime_gate import c,verify_release,commit_inventory

def main():
    f=verify_release();commit_inventory(f)
    sys.path.insert(0,str(c.HERE/'evaluation'))
    from guarded_io import verify_freeze
    ef=verify_freeze();r=c.read(P/'DIAGNOSTICS.json');protocol=c.read(P/'DIAGNOSTIC_PROTOCOL.json')
    c.need(c.sha(P/'DIAGNOSTICS.json')=='e6c700eeaa27cc5b27cb870d82ba0eb4b929198c86a7a0959fb94a5c3e377f42','Event result changed')
    c.need(r['protocol_sha256']==c.sha(P/'DIAGNOSTIC_PROTOCOL.json'),'Protocol identity')
    c.need(protocol['worker_sha256']==c.sha(P/'diagnostics.py'),'Worker identity')
    for path,digest in protocol['bindings'].items():c.need(c.sha(path)==digest,'Bound source changed')
    c.need(not(P/'DIAGNOSTIC_AUDIT.json').exists(),'Audit already committed')
    with c.exclusive('Finite diagnostic artifact review and descriptive table extraction'):
        np,limiter=c.runtime()
        expected={('CAISO',x['id']) for x in f['cases']}|{('EUROPE',x['id']) for x in ef['neural_cases']+ef['deterministic_cases']}
        c.need(len(r['costs'])==63 and {(x['task'],x['case']) for x in r['costs']}==expected,'Timing population')
        c.need(len(r['diagnostics'])==6 and r['fits']==r['optimizer_steps']==0,'Diagnostic population or mutation')
        checks=0
        def same(a,b,tol=1e-11):
            nonlocal checks
            c.need(math.isclose(float(a),float(b),rel_tol=tol,abs_tol=tol),'Arithmetic mismatch '+str((a,b)));checks+=1
        for cost in r['costs']:
            case=c.read(P/'cases'/f"{cost['task']}_{cost['case']}.json")
            c.need(case['cost']==cost and case['weights_unchanged'],'Case receipt inconsistent')
            c.need(case['protocol_sha256']==r['protocol_sha256'],'Case receipt protocol')
            for batch in ('batch1','batch4'):
                row=cost[batch];a=sorted(row['raw_nanoseconds'])
                c.need(len(a)==20 and row['repeats']==20 and row['warmups']==3 and min(a)>0,'Timing measurement')
                same(statistics.median(a)/1e6,row['median_ms'])
                # Independent linear-interpolation implementation of NumPy quantiles.
                for q,key in ((.25,'p25_ms'),(.75,'p75_ms')):
                    at=(len(a)-1)*q;lo=int(at);fraction=at-lo
                    same((a[lo]*(1-fraction)+a[lo+1]*fraction)/1e6,row[key])
            if cost['stored_parameters'] is not None:
                c.need(0<cost['trainable_parameters']<=cost['stored_parameters'],'Parameter accounting')
        seal=c.read(c.HERE/'admission/JUNE_INPUT_REPLAY_SEAL.json')
        co=np.load(seal['paths']['june_origins.npy'],allow_pickle=False)
        with np.load(c.HERE/'data/train_valid.npz',allow_pickle=False) as z:eo=z['valid'].copy()
        profiles=[];horizon=[];changes=[]
        for row in r['diagnostics']:
            c.guard();c.need(c.sha(row['path'])==row['sha256'],'Raw diagnostic identity')
            task=row['task'];n,nn,nh=(3397,30,12) if task=='CAISO' else (365,3,24)
            with np.load(row['path'],allow_pickle=False) as z:
                origins=z['origins'];w=z['branch_weights'].astype('float64');a=z['dynamic_adjacency'].astype('float64')
            c.need(np.array_equal(origins,co if task=='CAISO' else eo),'Diagnostic origins')
            c.need(w.shape==(n,nn,nh,2) and a.shape==(n,nn,nn),'Diagnostic array dimensions')
            c.need(np.isfinite(w).all() and np.isfinite(a).all(),'Finite values')
            c.need(w.min()>=0 and w.max()<=1 and a.min()>=0 and a.max()<=1,'Probability bounds')
            c.need(np.max(abs(w.sum(-1)-1))<2e-6 and np.max(abs(a.sum(-1)-1))<2e-6,'Row normalization')
            wt=w[...,0]
            same(wt.mean(),row['tcn_weight_mean'],2e-6)
            for h in range(nh):
                same(wt[:,:,h].mean(),row['tcn_weight_by_horizon'][h],5e-6)
                horizon.append(dict(task=task,case=row['case'],horizon=h+1,tcn_weight=float(wt[:,:,h].mean())))
            for node in range(nn):same(wt[:,node,:].mean(),row['tcn_weight_by_node'][node],5e-6)
            extreme=float(np.mean((wt<.05)|(wt>.95)));same(extreme,row['extreme_weight_fraction'])
            delta=np.mean(abs(a[1:]-a[:-1]),axis=(1,2))
            same(delta.mean(),row['consecutive_observed_graph_change_mean'],2e-7)
            spacing=1 if task=='CAISO' else 24;mask=np.diff(origins)==spacing
            for i,v in enumerate(delta):changes.append(dict(task=task,case=row['case'],origin_left=int(origins[i]),origin_right=int(origins[i+1]),index_gap=int(origins[i+1]-origins[i]),regular_spacing=bool(mask[i]),mean_absolute_adjacency_change=float(v)))
            profiles.append(dict(task=task,case=row['case'],origins=n,tcn_weight_mean=float(wt.mean()),
                tcn_weight_q05=float(np.quantile(wt,.05)),tcn_weight_q95=float(np.quantile(wt,.95)),
                tcn_weight_min=float(wt.min()),tcn_weight_max=float(wt.max()),
                temporal_weight_sd_mean=float(wt.std(axis=0).mean()),extreme_weight_fraction=extreme,
                adjacent_regular_pairs=int(mask.sum()),adjacent_gap_pairs=int((~mask).sum()),
                regular_graph_change_median=float(np.median(delta[mask])),
                regular_graph_change_q25=float(np.quantile(delta[mask],.25)),regular_graph_change_q75=float(np.quantile(delta[mask],.75)),
                reference_max_abs_difference=row['max_reference_difference']))
            c.need(row['max_reference_difference']<1e-4,'Replay tolerance')
        out=P/'figure_data';out.mkdir(exist_ok=True)
        def table(name,rows):
            path=out/name
            with path.open('x',encoding='utf-8-sig',newline='') as h:
                writer=csv.DictWriter(h,fieldnames=list(rows[0]));writer.writeheader();writer.writerows(rows)
            return dict(path=str(path),sha256=c.sha(path),rows=len(rows))
        tables=[]
        tables.append(table('Fig09_fusion_horizon.csv',horizon));tables.append(table('Fig09_graph_changes.csv',changes));tables.append(table('Table_S_diagnostic_profiles.csv',profiles))
        groups=defaultdict(list);timings=[]
        for row in r['costs']:
            groups[(row['task'],row['model'])].append(row)
            for batch in ('batch1','batch4'):
                for i,ns in enumerate(row[batch]['raw_nanoseconds']):timings.append(dict(task=row['task'],model=row['model'],case=row['case'],batch=int(batch[-1]),repeat=i+1,latency_ms=ns/1e6))
        summaries=[]
        for (task,name),rows in groups.items():
            lat=[x['batch1']['median_ms'] for x in rows];batch4=[x['batch4']['median_ms'] for x in rows]
            summaries.append(dict(task=task,model=name,cases=len(rows),stored_parameters=rows[0]['stored_parameters'],trainable_parameters=rows[0]['trainable_parameters'],
                batch1_median_of_case_medians_ms=statistics.median(lat),batch1_case_min_ms=min(lat),batch1_case_max_ms=max(lat),
                batch4_median_of_case_medians_ms=statistics.median(batch4),
                training_seconds_mean=(statistics.mean(x['training_elapsed_seconds_recorded'] for x in rows) if 'training_elapsed_seconds_recorded' in rows[0] else None)))
        tables.append(table('Fig10_cost_summary.csv',summaries));tables.append(table('Table_S_latency_repeats.csv',timings))
        c.write(P/'DIAGNOSTIC_AUDIT.json',dict(status='passed_separate_numerical_and_provenance_review',at=c.now(),arithmetic_equalities=checks,
            audited_timing_cases=63,audited_diagnostic_arrays=6,raw_timing_observations=len(timings),
            source_result_sha256=c.sha(P/'DIAGNOSTICS.json'),source_code_sha256=c.sha(__file__),
            source_protocol_sha256=c.sha(P/'DIAGNOSTIC_PROTOCOL.json'),profiles=profiles,cost_summary=summaries,tables=tables,
            review_scope='Separate float64 reductions and stdlib timing quantile algorithm, exact source/case/panel/hash verification. Same operator, not independent human review. Runtime unchanged-state assertions verified through source and case receipts; audit does not replay every model again.',
            graph_scope='CAISO graph changes restricted to consecutive 5-minute observed origins; Europe consecutive daily validation origins. All irregular gaps retained separately in tables. No cross-task magnitude attribution.',
            latency_scope='Measured historical-input inference on one CPU thread; excludes source loading and model loading. Timing repeats and seeds are not independent significance replicates; system load was not randomized.',
            parameter_scope='Stored and requires_grad counts; not measured active FLOPs. Statistical models have null neural-parameter fields.',
            interpretation='Weights describe learned behavior; seed-dependent branch allocation and graph variation do not establish causal importance or improved error.',
            models_changed=False,new_fits=0,test_targets_read_by_audit=False,complete_research_experiment=False))
        print('passed',checks,'equalities;',len(timings),'timing observations; tables saved')
if __name__=='__main__': main()
