"""Isolated original constructor and temporal arithmetic; no filesystem access."""
import torch
from torch import nn
from .model_feature_fusion_rev12 import FeatureFusionModel,FusionConfig

class PatchFusion(nn.Module):
    def __init__(self,variant,seed):
        super().__init__()
        if variant not in ('TCN','FULL','PATCH'): raise ValueError(variant)
        self.variant,self.seed=variant,seed
        with torch.random.fork_rng(devices=[]):
            torch.manual_seed(seed)
            original=FeatureFusionModel(FusionConfig(variant='TCN' if variant=='TCN' else 'FULL'))
        self.graph,self.tcn,self.head=original.graph,original.tcn,original.head
        if variant!='TCN':
            self.transformer=original.transformer.token_encoder
            self.attention=original.attention
        if variant=='PATCH':
            with torch.random.fork_rng(devices=[]):
                torch.manual_seed(seed+100000)
                self.patch=nn.Conv1d(32,32,kernel_size=12,stride=12)

    def forward(self,x):
        encoded,adj,context=self.graph(x)
        t=self.tcn(encoded)
        if self.variant=='TCN':
            fused=t.unsqueeze(2).expand(-1,-1,12,-1)
            a=t.new_zeros((*t.shape[:2],12,2)); a[...,0]=1
            z=torch.zeros_like(t)
        else:
            b,steps,n,d=encoded.shape
            if self.variant=='PATCH':
                seq=encoded.permute(0,2,3,1).reshape(b*n,d,steps)
                tokens=self.patch(seq).transpose(1,2)
            else:
                low=FeatureFusionModel.low_frequency_history(encoded)
                seq=low.permute(0,2,3,1).reshape(b*n,d,-1)
                tokens=torch.nn.functional.avg_pool1d(seq,6,6,ceil_mode=True).transpose(1,2)
            z=self.transformer(tokens).reshape(b,n,d)
            a=self.attention(t,z,context)
            fused=a[...,0:1]*t.unsqueeze(2)+a[...,1:2]*z.unsqueeze(2)
        return dict(prediction=self.head(fused),branch_weights=a,fused_features=fused,
            dynamic_adjacency=adj,transformer_features=z)
