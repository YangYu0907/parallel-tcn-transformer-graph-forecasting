"""Frozen chronological price access and commit-before-score enforcement."""
from pathlib import Path
from datetime import datetime,timedelta
import csv,sys
sys.path.insert(0,str(Path(__file__).resolve().parents[1]))
import common as c
EVAL=Path(__file__).resolve().parent

def dates(start,end):
    out=[];d=datetime.fromisoformat(start);last=datetime.fromisoformat(end)
    while d<=last:out.append(d);d+=timedelta(days=1)
    return out

def verify_freeze(require_release=True):
    f=c.read(EVAL/'EUROPE_TEST_FREEZE.json')
    c.need(f['status']=='frozen_before_test_access','Freeze status')
    for path,digest in f['bindings'].items():c.need(c.sha(path)==digest,'Frozen artifact changed: '+path)
    c.verify_seal()
    if require_release:
        r=c.read(EVAL/'EUROPE_TEST_RELEASE.json');review=c.read(EVAL/'PRE_RELEASE_REVIEW.json')
        c.need(r['status']=='released_after_review_under_user_approved_plan','No reviewed release')
        c.need(r['freeze_sha256']==c.sha(EVAL/'EUROPE_TEST_FREEZE.json'),'Release binds another freeze')
        c.need(r['review_sha256']==c.sha(EVAL/'PRE_RELEASE_REVIEW.json'),'Review changed')
        c.need(review['status']=='passed' and review['freeze_sha256']==r['freeze_sha256'],'Review incomplete')
    return f

class PriceArchive:
    """Keeps raw cells as text; every float conversion has a role and date guard.

    Day-ahead prices of delivery day d-1 cleared on d-2, so their full profile is
    available for forecasting delivery day d at the registered d-1 issue time.
    This is the published archival benchmark, not a vintage reconstruction.
    """
    def __init__(self,receipts):
        self.columns=[];self.accesses=[]
        for receipt in receipts:
            p=Path(receipt['path']);c.need(c.sha(p)==receipt['sha256'],'Raw source hash')
            with p.open(encoding='utf-8-sig',newline='') as f:
                rows=csv.reader(f);header=next(rows);c.need(header==receipt['header'],'Source schema changed')
                col={}
                for row in rows:
                    t=datetime.fromisoformat(row[0]);c.need(t not in col,'Duplicate source slot');col[t]=row[1]
            self.columns.append(col)
        self.markets=[r['market'] for r in receipts]
    def history(self,day,np):
        day=datetime.fromisoformat(day) if isinstance(day,str) else day
        c.need(day.hour==0 and day.minute==0,'Delivery-day boundary')
        times=[day+timedelta(hours=h) for h in range(-168,0)]
        c.need(all(t<day for t in times),'Future information guard')
        values=np.asarray([[float(col[t]) for col in self.columns] for t in times],dtype=np.float64)
        c.need(values.shape==(168,3) and np.isfinite(values).all(),'Incomplete/nonfinite history')
        self.accesses.append(dict(role='input_history',delivery_day=day.date().isoformat(),first=times[0].isoformat(),last=times[-1].isoformat(),numeric_cells=values.size))
        return values
    def targets(self,days,np,commit):
        f=verify_freeze();verify_commit(commit,f)
        c.need([d.date().isoformat() for d in days]==f['delivery_days'],'Scoring population changed')
        values=np.asarray([[[float(col[d+timedelta(hours=h)]) for col in self.columns] for h in range(24)] for d in days],dtype=np.float64)
        c.need(np.isfinite(values).all() and values.shape==(366,24,3),'Invalid test targets; do not change mask silently')
        self.accesses.append(dict(role='scoring_targets_after_all_predictions_committed',days=366,numeric_cells=values.size))
        return values

def verify_commit(commit,freeze):
    c.need(commit['status']=='all_predictions_committed_before_scoring','Prediction commit incomplete')
    c.need(commit['freeze_sha256']==c.sha(EVAL/'EUROPE_TEST_FREEZE.json'),'Commit freeze mismatch')
    wanted={r['id'] for r in freeze['neural_cases']}|{r['id'] for r in freeze['deterministic_cases']}
    c.need(set(commit['predictions'])==wanted,'Missing or extra case in prediction commit')
    for name,r in commit['predictions'].items():c.need(c.sha(r['path'])==r['sha256'],'Committed predictions changed: '+name)
    c.need(commit['target_scores_computed'] is False,'Premature score marker')
