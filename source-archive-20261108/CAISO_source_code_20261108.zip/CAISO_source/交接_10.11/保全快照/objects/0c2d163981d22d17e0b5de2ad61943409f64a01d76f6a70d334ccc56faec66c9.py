"""European task adapter, preserving the inherited feature-fusion building blocks."""
import ast, importlib.util, math
from types import SimpleNamespace
import torch
from torch import nn
from torch.nn import functional as F
import common as c
from models.model_feature_fusion_rev12 import FusionConfig, GraphEncoder, FeatureAttention, SharedHead
from models.model_dynamic_dual_stream_v4 import TCNBranch, TokenEncoder

class Graph(GraphEncoder):
    def dynamic_adjacency(self,projected):
        if self.mode!='SELF':return super().dynamic_adjacency(projected)
        b,t,n,d=projected.shape
        _,s=self.context_gru(projected.permute(0,2,1,3).reshape(b*n,t,d))
        ctx=s[-1].reshape(b,n,d)+self.node_embedding
        return torch.eye(n,device=projected.device,dtype=projected.dtype).expand(b,n,n),ctx

class JointFusion(nn.Module):
    def __init__(self,mode):
        super().__init__();self.mode=mode
        config=FusionConfig(num_nodes=3,input_dim=1,hidden_dim=32,horizon=24,graph_top_k=2,dropout=.1,variant=mode)
        self.graph=Graph(config);self.graph.mode=mode
        self.tcn=TCNBranch(32,(1,2,4,8),3,.1)
        self.transformer=TokenEncoder(32,4,1,64,.1)
        self.attention=FeatureAttention(32,24);self.head=SharedHead(32,24,.1)
        self.concat=nn.Sequential(nn.Linear(64,32),nn.GELU())
        for mod in ([self.tcn] if mode=='GTF' else [])+([self.transformer] if mode=='TCN' else [])+([self.attention] if mode in ('TCN','GTF','EQUAL','CONCAT') else [])+([self.concat] if mode!='CONCAT' else []):mod.requires_grad_(False)
        if mode=='SELF':
            self.graph.query.requires_grad_(False);self.graph.key.requires_grad_(False)
    def forward(self,x,details=False):
        c.need(x.ndim==3 and x.shape[1:]==(168,3),'Expected 168 historical slots x 3 markets')
        e,adj,ctx=self.graph(x.unsqueeze(-1));b,t,n,d=e.shape
        local=torch.zeros_like(ctx) if self.mode=='GTF' else self.tcn(e)
        # One 6-hour pooling step: physical resolution is declared for this task.
        tokens=F.avg_pool1d(e.permute(0,2,3,1).reshape(b*n,d,t),6,6).transpose(1,2)
        distant=torch.zeros_like(ctx) if self.mode=='TCN' else self.transformer(tokens).reshape(b,n,d)
        if self.mode in ('FULL','STATIC','SELF'):weights=self.attention(local,distant,ctx)
        else:
            weights=x.new_full((b,n,24,2),.5)
            if self.mode=='TCN':weights[...,0]=1;weights[...,1]=0
            if self.mode=='GTF':weights[...,0]=0;weights[...,1]=1
        fused=weights[...,:1]*local.unsqueeze(2)+weights[...,1:]*distant.unsqueeze(2)
        if self.mode=='CONCAT':fused=self.concat(torch.cat((local,distant),-1)).unsqueeze(2).expand(-1,-1,24,-1)
        pred=self.head(fused).transpose(1,2)
        if details:return dict(prediction=pred,weights=weights,adjacency=adj,local=local,distant=distant,fused=fused)
        return pred

def external(name):
    p=c.BRANCH/'external/preparation_20260913/source/official_models.py'
    spec=importlib.util.spec_from_file_location('europe_pinned_external_factory',p)
    module=importlib.util.module_from_spec(spec);spec.loader.exec_module(module);module.vendor_receipt()
    import numpy as np
    scope=dict(torch=torch,nn=nn,F=F,np=np,math=math,sqrt=math.sqrt,__name__='europe_pinned_external')
    for rel,names in module.SELECTIONS[name]:
        path=module.VENDOR/name/rel;tree=ast.parse(path.read_text(encoding='utf-8'))
        classes=[n for n in tree.body if isinstance(n,ast.ClassDef) and n.name in names]
        c.need([n.name for n in classes]==names,'External class ordering changed')
        if name=='iTransformer' and rel=='model/iTransformer.py':classes=module._normalization_graph_safe(classes)
        exec(compile(ast.fix_missing_locations(ast.Module(body=classes,type_ignores=[])),str(path),'exec'),scope)
    cfg=dict(seq_len=168,pred_len=24,individual=False,enc_in=3,output_attention=False,use_norm=True,
      embed='timeF',freq='h',class_strategy='projection',factor=1,dropout=.1,activation='gelu',d_model=32,n_heads=4,e_layers=1,d_ff=64)
    core=scope['Model'](SimpleNamespace(**cfg))
    class Task(nn.Module):
        def __init__(self):super().__init__();self.core=core
        def forward(self,x):return self.core(x) if name=='DLinear' else self.core(x,None,None,None)
    return Task()

def build(name,seed):
    torch.manual_seed(seed)
    return external(name) if name in ('DLinear','iTransformer') else JointFusion(name)
