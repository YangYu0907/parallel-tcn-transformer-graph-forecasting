"""Read-only checkpoint and source-lineage audit; no decoding or model fitting."""
from pathlib import Path
from datetime import datetime, timezone
from email.utils import parsedate_to_datetime
import hashlib, json, math, os, uuid

Y = Path(__file__).resolve().parent
R = Y.parent
def read(p): return json.loads(Path(p).read_text(encoding="utf-8-sig"))
def sha(p):
    h = hashlib.sha256()
    with Path(p).open("rb") as f:
        for block in iter(lambda: f.read(1048576), b""): h.update(block)
    return h.hexdigest()
def write(name, data):
    p = Y / name
    q = p.with_name("." + uuid.uuid4().hex + ".tmp")
    q.write_text(json.dumps(data, ensure_ascii=False, indent=2, allow_nan=False), encoding="utf-8")
    os.replace(q, p)

def main():
    protocol = read(Y/"PROTOCOL.json")
    for path, expected in protocol["bindings"].items():
        assert sha(path) == expected, path
    protected = read(Y/"PROTECTED_FILES.json")
    for path, expected in protected.items():
        assert sha(path) == expected, path
    choices = {c["cycle"]: c for c in read(Y/"SELECTION.json")["cycles"]}
    objects = read(R/"forecast_source_inventory_20261005/AUDITED_OBJECT_INDEX.json")["objects"]
    geometry = read(R/"forecast_value_proof_20261005/RESULT.json")["geometry"]
    grid = read(R/"historical_weather_admission_20261005/GRIB_BYTE_PROOF.json")["rows"][0]["grid_sha256"]
    manifest = {}
    retained, raw_bytes, values = 0, 0, 0
    for path in sorted((Y/"cycles").glob("*.json")):
        rec = read(path)
        cycle = int(path.stem)
        assert rec["choice"] == choices[cycle]
        assert rec["geometry"] == geometry and rec["decoder_version"] == "2.49.0"
        assert len(rec["rows"]) == 9 and len(rec["receipts"]) == 9
        assert len(rec["values"]) == 3 and all(len(v) == 3 for v in rec["values"])
        receipts = rec["receipts"]
        for receipt in receipts:
            src = objects[receipt["key"]]
            headers = {k.lower(): v for k, v in receipt["headers"].items()}
            assert headers["etag"] == src["etag"]
            assert parsedate_to_datetime(headers["last-modified"]).timestamp() == src["last_modified_seconds"]
            assert src["last_modified_seconds"] <= choices[cycle]["minimum_qualified_cutoff"]
            if receipt.get("retained", True):
                local = Y/receipt["local"]
                assert sha(local) == receipt["sha256"], str(local)
                retained += 1
                raw_bytes += local.stat().st_size
                if receipt["kind"] == "index":
                    blob = local.read_bytes()
                    assert len(blob) == src["bytes"]
                    assert hashlib.md5(blob).hexdigest() == src["etag"].strip('"')
        seen = set()
        for row in rec["rows"]:
            key = (row["variable"], row["lead"])
            assert key not in seen
            seen.add(key)
            vi = ["TMP", "UGRD", "VGRD"].index(row["variable"])
            li = [3, 4, 5].index(row["lead"])
            assert row["reference"] == choices[cycle]["cycle_utc"]
            assert row["lead_hours"] == row["lead"] and row["grid_sha256"] == grid
            assert (row["category"], row["parameter"], row["surface_type"], row["height"]) == [(0, 0, 103, 2),(2, 2, 103, 10),(2, 3, 103, 10)][vi]
            assert row["bytes"] == row["range"][1] - row["range"][0] + 1
            assert len(row["message_sha256"]) == 64
            assert len(row["values"]) == 3
            for pi, val in enumerate(row["values"]):
                assert math.isfinite(val) and val == rec["values"][vi][pi][li]
                assert (180 < val < 340) if vi == 0 else (abs(val) < 100)
                values += 1
            bundle = [r for r in receipts if r["kind"] == "GRIB_range" and r["key"] == row["key"] and r["range"][0] <= row["range"][0] <= row["range"][1] <= r["range"][1]]
            assert len(bundle) == 1
        manifest[str(path)] = sha(path)
    assert len(manifest) >= read(Y/"PROGRESS.json")["completed_cycles"]
    write("RECOVERY_CHECKPOINT_MANIFEST.json", manifest)
    result = dict(at=datetime.now(timezone.utc).isoformat(), passed=True,
        type="Same-agent separate saved-checkpoint/source-lineage audit; not independent raw-value replay or external review",
        checkpoints=len(manifest), values_structurally_verified=values,
        retained_files_rehashed=retained, retained_bytes_rehashed=raw_bytes,
        protected_files_unchanged=len(protected), model_fits=0, new_test_targets_read=False,
        manifest_sha256=sha(Y/"RECOVERY_CHECKPOINT_MANIFEST.json"),
        caveat="Nonretained GRIB bytes require separate final sampled source replay; this audit checks saved values against their per-message rows and receipts.")
    write("RECOVERY_CHECKPOINT_AUDIT.json", result)
    print(json.dumps(result, ensure_ascii=False))

if __name__ == "__main__": main()

