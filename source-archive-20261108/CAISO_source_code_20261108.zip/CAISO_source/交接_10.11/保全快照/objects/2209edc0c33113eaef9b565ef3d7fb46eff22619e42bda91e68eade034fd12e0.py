"""Keep registered event definitions; count support on weather-qualified TRAIN."""
import numpy as np
import support as s

H=s.N.parent/'historical_weather_admission_20261005'

def main():
    p=s.read(s.N/'SOURCE_EVENT_CENSUS_PROTOCOL.json')
    for path,h in p['bindings'].items():assert s.sha(path)==h,path
    with s.base.numeric('Source-qualified TRAIN event support census; zero fits'):
        with np.load(s.N/'SOURCE_METADATA_QUALIFICATION.npz') as z:
            keep=z['qualified'];o=z['origin'][keep];roles=z['role'][keep];cut=z['cutoff'][keep]
        old=s.read(H/'SHORT_CONTEXT_PROTOCOL.json')
        q=s.read(H/'PUBLICATION_CORRECTED_THRESHOLDS.json');center=np.array(q['center']);threshold=np.array(q['thresholds'])
        prices=np.load(old['raw_prices'],mmap_mode='r')
        counts={r:dict(origins=0,pairs=0) for r in range(3)}
        events={(r,c):[] for r in range(3) for c in [1,2]}
        for start in range(0,len(o),256):
            s.guard();oo=o[start:start+256];rr=roles[start:start+256];tt=cut[start:start+256]
            last=np.asarray(prices[oo-1,:,0],float)
            future=np.asarray(prices[oo[:,None]+np.arange(12),:,0],float).transpose(0,2,1)
            normal=(abs(last-center)<=threshold[0])&np.isfinite(last)&np.isfinite(future).all(2)
            residual=future-center[None,:,None];cross=abs(residual)>threshold[1][None,:,None]
            first=cross.argmax(2);hit=cross.any(2)
            cls=np.where(hit,np.where(np.take_along_axis(residual,first[:,:,None],axis=2)[:,:,0]>0,1,2),0)
            for role in range(3):
                mask=normal&(rr==role)[:,None]
                counts[role]['origins']+=int(mask.any(1).sum());counts[role]['pairs']+=int(mask.sum())
                for sign in [1,2]:
                    row,node=np.where(mask&(cls==sign))
                    events[(role,sign)].extend((tt[row]+300*(first[row,node]+1)).tolist())
        rows=[]
        for role in range(3):
            row=dict(role=role,**counts[role])
            for code,name in [(1,'up'),(2,'down')]:
                ts=np.unique(events[(role,code)])
                row[name]=dict(pairs=len(events[(role,code)]),UTC_event_dates=int(len(np.unique(ts//86400))),event_clusters_1h=int(1+(np.diff(ts)>3600).sum()) if len(ts) else 0)
            rows.append(row)
        passed=all(row[name][metric]>=p['minimum_event_dates'][str(row['role'])] for row in rows for name in ['up','down'] for metric in ['UTC_event_dates','event_clusters_1h'])
        result=dict(at=s.now(),passed=passed,rows=rows,definition='Existing frozen prefix q90 current-normal and first q99 crossing within12steps; no state threshold retuning',scope='Already-inspected TRAIN development, no independent new test',support_floor_is_not_statistical_power=True,model_fits=0,V7_replaced=False,protected_files_unchanged=s.base.verify_protected())
        s.write('SOURCE_EVENT_SUPPORT.json',result);print(__import__('json').dumps(result,ensure_ascii=False))

if __name__=='__main__':main()
