"""Close the fixed trial, retain all directions and record the bounded next hypothesis."""
from common import *

assert not gate.LOCK.exists() and not (HERE/'queue/manager.lock').exists()
r=gate.read(HERE/'RESULT.json');a=gate.read(HERE/'AUDIT.json');d=gate.read(HERE/'DECISION.json')
assert a['status']=='passed' and a['result_sha256']==gate.sha(HERE/'RESULT.json')
assert d['status']=='fixed_candidate_failed_development_not_promoted'
for q,digest in gate.read(HERE/'EXECUTION_SEAL.json')['bindings'].items():
    assert gate.sha(q)==digest,q
recovery=gate.read(HERE/'STORAGE_RECOVERY.json')
recovery.pop('deleted_files',None)
recovery.update(lost_data_files=0,verified_duplicate_copies_removed=21,
    resumed_and_completed=True,final_audit=str(HERE/'AUDIT.json'),temporary_storage=str(HERE/'TEMPORARY_STORAGE.json'))
gate.write(HERE/'STORAGE_RECOVERY.json',recovery)
analysis=dict(at=gate.now(),status='fixed_trial_closed_after_complete_audit',
    result=str(HERE/'RESULT.json'),result_sha256=gate.sha(HERE/'RESULT.json'),
    diagnosis=str(HERE/'DIAGNOSTIC.json'),
    factual_findings=[
      'All three seeds improve overall, near and H12 MAE relative to unchanged terminal FULL.',
      'JOINT4 overall mean MAE 4.4686556854 vs FULL 4.6656367559; mean RMSE 12.8256485937 vs12.8101821330.',
      'JOINT4 S3/S4 MAE75.9376584/48.9474270 vs FULL57.2279241/17.6438652; each state spans only3 UTC dates.',
      'JOINT3 MAE4.4638410678 is lower than JOINT4; the new GB expert helps near MAE1.24148% vs JOINT3 but worsens other main metrics.',
      'Mean FULL routing weights in S3/S4 are approximately0.80-0.83; other experts retain positive weight under softmax.',
      'New September source status remains metadata feasibility only162 origins11 days; numerical targets unopened.'
    ],
    explanation='The controller reacts to context and released feedback, yet blended alternatives still raise error in high-history return states. Rare-event competence estimation and delayed recognition remain unverified causes; correlation is not a universal causal claim.',
    next_finite_hypothesis=dict(
      name='Support-aware sparse routing with explicit unchanged-FULL fallback',
      motivation='Permit exact zero weight for unsupported experts and complete fallback when a past-only estimate cannot support gain.',
      evidence='Sparsemax establishes sparse probability outputs; ADE motivates estimating conditional expert loss. Neither guarantees nondegradation or successful EPF routing.',
      sources=['https://proceedings.mlr.press/v48/martins16.html','https://doi.org/10.1007/s10994-018-05774-y'],
      implementation_status='Not implemented or trained; requires its own fixed registration and matching dense-gate comparison before any scoring.',
      benefits='Can remove harmful expert contributions and preserve original core model in uncertain cases.',
      costs='May forgo useful switching gains; sparse selection can be unstable; additional calibration cannot use future price states.',
      controls='Keep all expert predictions fixed; compare current dense gate against one sparse/fallback gate using identical prior-fold data and forward folds.',
      independent_confirmation='Full September admission and a new sealed model/routing protocol required; no test-driven changes.'),
    automatic_more_training=False,new_test_targets_read=False,paper_main_model_replaced=False,
    all_results_preserved=True,complete_research_experiment=False)
gate.write(HERE/'CLOSURE.json',analysis)
eventids=[]
for q in [HERE/'queue/recovery_disk_full_1/status.json',HERE/'queue/status.json']:
    row=gate.read(q)
    if row.get('event_id'):eventids.append(row['event_id'])
gate.write(HERE/'EVENT_HANDLING.json',dict(at=gate.now(),event_ids=eventids,
    status='handled_in_current_user_requested_turn',result_notification='Included in this turn final response',
    duplicate_notification_needed=False,unexpected_result_analysed=True,
    resolved_blocker='Storage: verified21 frozen cache files in user-authorized temporary C storage; original paths preserved',
    disposition='No training running; fixed candidate closed; retain original FULL; no new test opened'))
h=gate.read(B/'HANDOFF.json')
h.update(at=gate.now(),status='adaptive_v2_completed_not_promoted',training_active=False,current_process=None,
    complete_research_experiment=False)
h['adaptive_experts_v2'].update(closure=str(HERE/'CLOSURE.json'),event_handling=str(HERE/'EVENT_HANDLING.json'),
    temporary_storage=str(HERE/'TEMPORARY_STORAGE.json'),status='fixed_configuration_closed',all_three_seeds_completed=True,
    numerical_audit_passed=True,new_test_targets_read=False,automatic_extra_training=False)
gate.write(B/'HANDOFF.json',h)
print('Closed: three seeds, nine comparison arms, causal/audit checks passed; acceptance failed; no test opening or model replacement.')
