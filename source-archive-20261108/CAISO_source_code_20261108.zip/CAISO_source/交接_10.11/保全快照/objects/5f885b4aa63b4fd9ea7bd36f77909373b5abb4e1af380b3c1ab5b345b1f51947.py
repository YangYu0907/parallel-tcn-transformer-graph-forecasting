"""Finite Wolfe MNP on all task gradients; residual and positive-dot certificates."""
import numpy as np

def gamma(n):
    value=n*(np.finfo(np.float64).eps/2)
    if value>=1: raise RuntimeError('Floating-point error bound scope')
    return value/(1-value)

def evidence(raw,scaled,weights,direction,success,settings):
    if not np.isfinite(direction).all() or not np.isfinite(weights).all(): raise RuntimeError('Nonfinite MNP solution')
    n=len(direction); norm=float(direction@direction); dots=scaled@direction; raw_dot=raw@direction
    # Conservative sequential product-plus-sum bound, with an extra factor 8 for evaluation.
    bounds=8*gamma(2*n+4)*(abs(scaled)@abs(direction)+norm)
    raw_bounds=8*gamma(2*n+4)*(abs(raw)@abs(direction))
    if not np.isfinite(bounds).all() or not np.isfinite(dots).all() or not np.isfinite(raw_dot).all(): raise RuntimeError('Nonfinite direction evidence')
    gap=float(np.max(norm-dots+bounds)); active=weights>0
    residual=float(np.max(abs(dots[active]-norm)+bounds[active]))
    tolerance=settings['mnp_certificate_rtol']*norm
    feasible=bool(weights.min()>=0 and abs(weights.sum()-1)<=1e-12)
    certificate=bool(success and feasible and norm>0 and gap<=tolerance and residual<=tolerance)
    strict=bool(certificate and (dots>bounds).all() and (raw_dot>raw_bounds).all())
    return dict(weights=weights.tolist(),direction=direction.tolist(),direction_norm_squared=norm,normalized_gradient_dot_direction=dots.tolist(),raw_loss_directional_change=(-raw_dot).tolist(),dot_roundoff_bounds=bounds.tolist(),raw_dot_roundoff_bounds=raw_bounds.tolist(),duality_gap_upper=gap,active_kkt_error_upper=residual,certificate_tolerance=tolerance,certificate_passed=certificate,strict_common_descent=strict)

def cone(gradient,scales,settings):
    raw=np.asarray(gradient,np.float64); scales=np.asarray(scales,np.float64)
    if raw.ndim!=2 or scales.shape!=(len(raw),) or not np.isfinite(raw).all() or not np.isfinite(scales).all() or (scales<=0).any(): raise RuntimeError('Invalid MNP inputs')
    g=raw/scales[:,None]
    if not np.isfinite(g).all(): raise RuntimeError('Nonfinite normalized gradient')
    row_norms=np.linalg.norm(g,axis=1); factor=float(row_norms.max())
    if not np.isfinite(factor): raise RuntimeError('MNP scale overflow')
    weights=np.zeros(len(g)); weights[int(np.argmin(row_norms))]=1.
    trace=[]; major=minor=0; reason='all_zero' if factor==0 else 'major_budget'
    if factor>0:
        points=g/factor; active=[int(np.argmin(row_norms))]
        for major in range(settings['mnp_max_major']):
            x=weights@points; norm=float(x@x); dots=points@x; j=int(np.argmin(dots))
            error=8*gamma(2*len(x)+4)*float((abs(points)@abs(x)+norm).max()); tolerance=max(settings['mnp_gap_rtol']*norm,error); gap=norm-float(dots[j])
            trace.append(dict(major=major,minor=minor,active=active.copy(),gap=gap,norm_squared=norm,tolerance=tolerance,enter=j))
            if gap<=tolerance: reason='gap_reached'; break
            if j in active: reason='active_precision_stop'; break
            active.append(j)
            while minor<settings['mnp_max_minor']:
                minor+=1; anchor=points[active[0]]; difference=(points[active[1:]]-anchor).T
                coefficients=np.linalg.lstsq(difference,-anchor,rcond=settings['mnp_lstsq_rcond'])[0]; affine=np.r_[1-coefficients.sum(),coefficients]
                if not np.isfinite(affine).all(): raise RuntimeError('Nonfinite affine minimizer')
                if (affine>0).all(): weights[:]=0.; weights[active]=affine; break
                current=weights[active]; bad=np.flatnonzero(affine<=0); denominator=current[bad]-affine[bad]
                ratios=np.divide(current[bad],denominator,out=np.full(len(bad),np.inf),where=denominator>0)
                ix=int(np.argmin(ratios)); theta=float(ratios[ix])
                if not np.isfinite(theta) or theta<0 or theta>1: raise RuntimeError('Invalid corral boundary')
                updated=current+theta*(affine-current); updated[bad[ix]]=0.
                if updated.min()<-1e-12: raise RuntimeError('Negative corral weight')
                updated=np.maximum(updated,0); keep=updated>0
                if not keep.any(): raise RuntimeError('Empty corral')
                active=[v for v,k in zip(active,keep) if k]; weights[:]=0.; weights[active]=updated[keep]; weights/=weights.sum()
                if len(active)==1: break
            else: reason='minor_budget'; break
        else: major=settings['mnp_max_major']
    direction=weights@g; success=reason=='gap_reached'
    row=evidence(raw,g,weights,direction,success,settings)
    row.update(solver='Wolfe_MNP_direct_affine_lstsq',solver_success=success,solver_message=reason,major_iterations=int(major),minor_iterations=int(minor),trace=trace,certificate_rule='relative_norm_residual_and_positive_raw_dot',all_tasks_used=True)
    return row
