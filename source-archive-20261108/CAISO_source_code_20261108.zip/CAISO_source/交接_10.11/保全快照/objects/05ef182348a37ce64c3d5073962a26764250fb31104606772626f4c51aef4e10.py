"""Finite publication evidence assembly from already-audited frozen score summaries."""
from pathlib import Path
import sys,csv,json,math
P=Path(__file__).resolve().parent;B=P.parent
sys.path.insert(0,str(B/'energy_confirmation_v1_20260926'))
import common as c

def main():
    files={'CAISO':B/'h1_final_evaluation_v1_20260927/TEST_RESULTS.json','EUROPE':c.HERE/'evaluation/TEST_RESULTS.json'}
    data={k:c.read(p) for k,p in files.items()}
    for task,path in files.items():
        audit=c.read(path.parent/'TEST_AUDIT.json');c.need(audit['status']=='passed','Test audit absent')
        c.need(audit['result_sha256']==c.sha(path),'Test result identity')
    with c.exclusive('Assemble frozen-test result tables and figures; no training or target reread'):
        np,limiter=c.runtime()
        import matplotlib
        matplotlib.use('Agg')
        import matplotlib.pyplot as plt
        from matplotlib.colors import TwoSlopeNorm
        from matplotlib.ticker import FuncFormatter,NullFormatter
        sys.path.insert(0,str(P));from render_diagnostics import save
        out=P/'result_figures';out.mkdir(exist_ok=True);tab=P/'result_tables';tab.mkdir(exist_ok=True)
        order={'CAISO':['FULL','TCN','GTF','EQUAL','CONCAT','GLOBAL','STATIC','SELF','DLinear','iTransformer-H','LASSO_ARX_H','PERSISTENCE','DAILY_SEASONAL'],
               'EUROPE':['FULL','TCN','GTF','EQUAL','CONCAT','STATIC','SELF','DLinear','iTransformer','LASSO_AR','PreviousDay','PreviousWeek']}
        labels={'PERSISTENCE':'Persistence','DAILY_SEASONAL':'Daily seasonal','LASSO_ARX_H':'LASSO-ARX-H','LASSO_AR':'LASSO-AR','PreviousDay':'Previous day','PreviousWeek':'Previous week'}
        def label(n):return labels.get(n,n)
        mainrows={task:{r['model']:r for r in d['main_results']} for task,d in data.items()}
        comps={task:{r['comparator']:r for r in d['comparisons']} for task,d in data.items()}
        def score(task,model,metric='MAE'):
            name=metric if task=='CAISO' else {'MAE':'mae','RMSE_mean_seed':'rmse_mean_seed','MAE_seed_sd':'mae_seed_sd'}[metric]
            return mainrows[task][model].get(name,0.)
        def profile(task,model,axis):
            if task=='CAISO':return data[task]['profiles'][model][axis]
            return data[task]['details'][model][{'horizons':'mae_by_horizon','nodes':'mae_by_market','months':'mae_by_month','states':'price_states'}[axis]]
        def values(task,model,axis):
            x=profile(task,model,axis)
            if isinstance(x,dict):return {k:(v['MAE'] if isinstance(v,dict) else v) for k,v in x.items()}
            return np.array([v['MAE'] if isinstance(v,dict) else v for v in x])
        tables=[]
        def table(name,rows):
            fields=list(dict.fromkeys(k for row in rows for k in row));path=tab/name
            with path.open('w',encoding='utf-8-sig',newline='') as h:
                writer=csv.DictWriter(h,fieldnames=fields);writer.writeheader();writer.writerows(rows)
            tables.append(dict(path=str(path),sha256=c.sha(path),rows=len(rows)))
        for task,d in data.items():table('Table_'+('4_CAISO_H1' if task=='CAISO' else '5_Europe_2016')+'.csv',d['main_results'])
        compare=[];profiles=[]
        for task,d in data.items():
            for r in d['comparisons']:
                compare.append(dict(task=task,comparator=r['comparator'],full_MAE=r['full_mae'],comparator_MAE=r['comparator_mae'],MAE_improvement_percent=r['improvement_percent'],CI95_low=r['improvement_ci95'][0],CI95_high=r['improvement_ci95'][1],holm_p=r['holm_p_value'],classification=r['classification'],RMSE_improvement_percent=100*(score(task,r['comparator'],'RMSE_mean_seed')-score(task,'FULL','RMSE_mean_seed'))/score(task,r['comparator'],'RMSE_mean_seed'),scope=d['scope']))
            for model in order[task]:
                for axis in ('horizons','nodes','months'):
                    val=values(task,model,axis)
                    for k,v in (val.items() if isinstance(val,dict) else enumerate(val,1)):profiles.append(dict(task=task,model=model,axis=axis,key=k,MAE=v))
        table('Table_6_all_comparisons.csv',compare);table('Table_S_all_profiles.csv',profiles)
        # Store every price-state result, including unfavorable and rare states.
        states=[]
        for task in data:
            for model in order[task]:
                for row in profile(task,model,'states'):states.append(dict(task=task,model=model,**row))
        table('Table_S_all_price_states.csv',states)
        counts=[dict(task='CAISO',**r) for r in data['CAISO']['states']]+[dict(task='EUROPE',**r) for r in data['EUROPE']['state_counts']]
        table('Table_S_state_counts_events.csv',counts)
        figs=[];qa=[];colors={'FULL':'#0F4D92','TCN':'#42949E','GTF':'#9A4D8E','DLinear':'#B64342','iTransformer-H':'#9A4D8E','iTransformer':'#9A4D8E','LASSO_ARX_H':'#65724D','LASSO_AR':'#65724D'}
        for lang in ('en','zh'):
            zh=lang=='zh'
            plt.rcParams.update({'font.family':['SimHei','Arial'] if zh else ['Arial','DejaVu Sans'],'font.size':13,'axes.titlesize':14,'axes.labelsize':13,'axes.spines.top':False,'axes.spines.right':False,'axes.linewidth':1.1,'svg.fonttype':'none','pdf.fonttype':42,'axes.unicode_minus':False,'legend.frameon':False})
            fig,axs=plt.subplots(2,2,figsize=(13,11));fig.subplots_adjust(left=.16,right=.98,bottom=.075,top=.94,wspace=.40,hspace=.32)
            for ri,task in enumerate(data):
                left,right=axs[ri];names=order[task];unit='USD/MWh' if task=='CAISO' else 'EUR/MWh'
                for i,name in enumerate(names):
                    left.errorbar(score(task,name),i,xerr=score(task,name,'MAE_seed_sd'),fmt='o',color='#0F4D92' if name=='FULL' else '#606B73',capsize=3,ms=5)
                left.set_yticks(range(len(names)),[label(n) for n in names]);left.set_ylim(len(names)-.4,-.7);left.set_xlim(left=0);left.set_xlabel('MAE ('+unit+')')
                cn=names[1:]
                for i,name in enumerate(cn):
                    r=comps[task][name];point=r['improvement_percent'];lo,hi=r['improvement_ci95'];sig=r['holm_p_value']<.05
                    color='#0F4D92' if point>0 else '#B64342'
                    right.plot([lo,hi],[i,i],color=color,lw=1.3);right.plot(point,i,'o',mfc=color if sig else 'white',mec=color,ms=5)
                right.axvline(0,color='#777777',ls=':',lw=1);right.set_yticks(range(len(cn)),[label(n) for n in cn]);right.set_ylim(len(cn)-.4,-.7)
                right.set_xlabel('FULL的MAE改善率（%）' if zh else 'MAE improvement by FULL (%)')
                prefix='CAISO H1' if task=='CAISO' else ('欧洲2016' if zh else 'Europe 2016')
                left.set_title(f'({chr(97+2*ri)}) {prefix}: '+('总体误差' if zh else 'overall error'),loc='left',pad=12)
                right.set_title(f'({chr(98+2*ri)}) {prefix}: '+('配对比较' if zh else 'paired comparisons'),loc='left',pad=12)
                for ax in (left,right):ax.grid(axis='x',color='#EEEEEE');ax.set_axisbelow(True)
            save(fig,out/f'Fig04_independent_test_{lang}',plt,figs,qa)
            fig,axs=plt.subplots(2,2,figsize=(12.6,8.8));fig.subplots_adjust(left=.085,right=.98,bottom=.085,top=.93,wspace=.24,hspace=.4)
            for col,task in enumerate(data):
                unit='USD/MWh' if task=='CAISO' else 'EUR/MWh';nh=12 if task=='CAISO' else 24
                for ri,names in enumerate([['FULL','TCN','GTF'],['FULL','DLinear','iTransformer-H' if task=='CAISO' else 'iTransformer','LASSO_ARX_H' if task=='CAISO' else 'LASSO_AR']]):
                    ax=axs[ri,col]
                    for j,name in enumerate(names):ax.plot(range(1,nh+1),values(task,name,'horizons'),label=label(name),color=colors[name],ls=['-','--','-.',':'][j],lw=2)
                    ax.set_xlim(1,nh);ax.set_xticks([1,4,8,12] if nh==12 else [1,6,12,18,24]);ax.set_ylim(bottom=0);ax.set_ylabel('MAE ('+unit+')')
                    ax.set_xlabel(('预测步（每步5分钟）' if zh else 'Forecast step (5 min)') if task=='CAISO' else ('交付小时' if zh else 'Delivery hour'))
                    ax.legend(ncol=2,fontsize=10,loc='lower right');ax.grid(axis='y',color='#EEEEEE')
                    title=('时间分支' if zh else 'temporal branches') if ri==0 else ('外部基线' if zh else 'external baselines')
                    ax.set_title(f'({chr(97+ri*2+col)}) '+('CAISO' if task=='CAISO' else ('欧洲' if zh else 'Europe'))+': '+title,loc='left',pad=12)
            save(fig,out/f'Fig05_horizon_errors_{lang}',plt,figs,qa)
            fig,axs=plt.subplots(1,2,figsize=(11,6.5));fig.subplots_adjust(left=.14,right=.91,bottom=.13,top=.89,wspace=.6)
            names=['TCN','GTF','EQUAL','CONCAT','GLOBAL','STATIC','SELF'];mats=[]
            for task in data:
                mat=np.array([[comps[task][n]['improvement_percent'],100*(score(task,n,'RMSE_mean_seed')-score(task,'FULL','RMSE_mean_seed'))/score(task,n,'RMSE_mean_seed')] if n in comps[task] else [np.nan,np.nan] for n in names]);mats.append(mat)
            mx=max(np.nanmax(abs(m)) for m in mats);norm=TwoSlopeNorm(vmin=-mx,vcenter=0,vmax=mx)
            for i,(task,ax,mat) in enumerate(zip(data,axs,mats)):
                im=ax.imshow(mat,cmap='RdBu',norm=norm,aspect='auto');ax.set_xticks([0,1],['MAE','RMSE']);ax.set_yticks(range(7),names)
                for yi in range(7):
                    for xi in range(2):
                        v=mat[yi,xi];s='n/a' if np.isnan(v) else f'{v:+.2f}'
                        ax.text(xi,yi,s,ha='center',va='center',fontsize=12,color='white' if np.isfinite(v) and abs(v)>.65*mx else '#222222')
                ax.set_title(f'({chr(97+i)}) '+('CAISO H1' if task=='CAISO' else ('欧洲2016' if zh else 'Europe 2016')),loc='left',pad=14)
            cb=fig.colorbar(im,ax=axs,shrink=.85,pad=.04);cb.set_label('误差改善率（%，正值更优）' if zh else 'Error reduction by FULL (%, positive = better)')
            save(fig,out/f'Fig06_component_effects_{lang}',plt,figs,qa)
            # Every node/market and every comparator is retained.
            node_names=c.read(B/'h1_final_evaluation_v1_20260927/FINAL_TEST_FREEZE.json')['nodes']
            fig,axs=plt.subplots(2,1,figsize=(13,13),gridspec_kw={'height_ratios':[5,1.2]});fig.subplots_adjust(left=.22,right=.93,bottom=.09,top=.96,hspace=.55)
            for ri,(task,ax) in enumerate(zip(data,axs)):
                names=order[task][1:];mat=np.array([values(task,n,'nodes')-values(task,'FULL','nodes') for n in names]).T
                mx=float(np.max(abs(mat)));im=ax.imshow(mat,cmap='RdBu',norm=TwoSlopeNorm(vmin=-mx,vcenter=0,vmax=mx),aspect='auto')
                ax.set_xticks(range(len(names)),[label(n) for n in names],rotation=45,ha='right',fontsize=10)
                ax.set_yticks(range(len(mat)),node_names if task=='CAISO' else ['FR','DE','BE'],fontsize=9 if task=='CAISO' else 12)
                ax.set_title(f'({chr(97+ri)}) '+('CAISO：全部30节点' if zh and task=='CAISO' else 'CAISO: all 30 nodes' if task=='CAISO' else '欧洲：三个市场' if zh else 'Europe: all three markets'),loc='left',pad=12)
                cb=fig.colorbar(im,ax=ax,pad=.025,fraction=.035);cb.set_label(('对照 − FULL的MAE' if zh else 'Comparator − FULL MAE')+(' (USD/MWh)' if task=='CAISO' else ' (EUR/MWh)'))
            save(fig,out/f'Fig07_node_market_effects_{lang}',plt,figs,qa)
            fig,axs=plt.subplots(1,2,figsize=(13,6.8));fig.subplots_adjust(left=.085,right=.89,bottom=.24,top=.91,wspace=.65)
            for task,ax in zip(data,axs):
                names=order[task][1:];months=[f'2026-{i:02d}' for i in range(1,7)] if task=='CAISO' else [f'{i:02d}' for i in range(1,13)]
                full=values(task,'FULL','months');mat=np.array([[values(task,n,'months').get(m,np.nan)-full.get(m,np.nan) for n in names] for m in months])
                mx=float(np.nanmax(abs(mat)));cmap=plt.get_cmap('RdBu').copy();cmap.set_bad('#E2E2E2')
                im=ax.imshow(mat,cmap=cmap,norm=TwoSlopeNorm(vmin=-mx,vcenter=0,vmax=mx),aspect='auto');ax.set_xticks(range(len(names)),[label(n) for n in names],rotation=60,ha='right',fontsize=9)
                ax.set_yticks(range(len(months)),months);ax.set_title('CAISO H1' if task=='CAISO' else ('欧洲2016' if zh else 'Europe 2016'),loc='left')
                fig.colorbar(im,ax=ax,pad=.025,fraction=.035).set_label('MAE差值' if zh else 'MAE difference')
            save(fig,out/f'FigS01_month_effects_{lang}',plt,figs,qa)
            fig,axs=plt.subplots(2,2,figsize=(12.6,8.8));fig.subplots_adjust(left=.09,right=.98,bottom=.10,top=.90,wspace=.28,hspace=.45)
            for col,task in enumerate(data):
                names=['FULL','TCN','DLinear','LASSO_ARX_H' if task=='CAISO' else 'LASSO_AR'];ax=axs[0,col];bot=axs[1,col]
                for j,name in enumerate(names):
                    ss=profile(task,name,'states');yy=[r['MAE'] if task=='CAISO' else r['mae'] for r in ss];xx=np.arange(len(yy))+(j-1.5)*.13
                    ax.plot(xx,yy,ls='',marker=['o','s','^','D'][j],ms=6,color=colors[name],label=label(name))
                ax.set_yscale('log');ax.yaxis.set_major_formatter(FuncFormatter(lambda v,pos:f'{v:g}'));ax.yaxis.set_minor_formatter(NullFormatter());ax.set_ylabel('MAE ('+('USD/MWh' if task=='CAISO' else 'EUR/MWh')+')')
                ticks=['S'+str(k) for k in range(6)] if task=='CAISO' else (['低于q01','q01–q99','高于q99'] if zh else ['Below q01','q01–q99','Above q99'])
                ax.set_xticks(range(len(ticks)),ticks);ax.legend(ncol=2,fontsize=10,loc='upper left',bbox_to_anchor=(0,1.26))
                if task=='CAISO':cells=[r['prediction_cells'] for r in data[task]['states']];events=[r['contiguous_node_state_events'] for r in data[task]['states']]
                else:
                    keys=['below_train_q01','train_q01_to_q99','above_train_q99'];cells=[sum(r['target_slots'] for r in data[task]['state_counts'] if r['state']==k) for k in keys];events=[sum(r['runs_on_normalized_benchmark_clock'] for r in data[task]['state_counts'] if r['state']==k) for k in keys]
                bot.plot(np.arange(len(ticks))-.07,cells,'o',color='#0F4D92',label='预测单元' if zh else 'Forecast cells');bot.plot(np.arange(len(ticks))+.07,events,'s',color='#B64342',label='连续事件' if zh else 'Contiguous events')
                for i,val in enumerate(cells):bot.annotate(f'{val:,}',(i-.07,val),xytext=(0,7),textcoords='offset points',ha='center',fontsize=9)
                bot.set_yscale('log');bot.yaxis.set_major_formatter(FuncFormatter(lambda v,pos:f'{v:g}'));bot.yaxis.set_minor_formatter(NullFormatter());bot.set_ylim(top=max(cells)*3)
                bot.set_xticks(range(len(ticks)),ticks);bot.set_ylabel('数量（对数轴）' if zh else 'Count (log scale)');bot.legend(ncol=2,fontsize=10,loc='upper left',bbox_to_anchor=(0,1.22))
                for axis in (ax,bot):axis.grid(axis='y',color='#eeeeee');axis.set_axisbelow(True)
                ax.set_title(f'({chr(97+col)}) '+('CAISO H1' if task=='CAISO' else ('欧洲2016' if zh else 'Europe 2016')),loc='right',pad=6)
                bot.set_title(f'({chr(99+col)}) '+('样本覆盖' if zh else 'Sample coverage'),loc='right',pad=6)
            save(fig,out/f'Fig08_price_states_{lang}',plt,figs,qa)
        c.write(out/'RESULT_FIGURE_MANIFEST.json',dict(status='rendered_pending_visual_review',at=c.now(),source_sha256=c.sha(__file__),frozen_results={str(p):c.sha(p) for p in files.values()},figures=figs,tables=tables,text_bounds_checks=qa,
            primary_statistics='Use the original unadjusted percentile95 intervals and frozen Holm-adjusted p-values; do not treat interval exclusion alone as adjusted significance. All secondary profiles descriptive.',
            scope='CAISO qualified1002 origins/56 dates, 2026H1; Europe archival366days2016. Price units and tasks kept separate.',
            fits=0,test_targets_read=False,complete_research_experiment=False))
        print('Built main tables4–6 and twelve bilingual result figures (36 exports)')
if __name__=='__main__':main()
