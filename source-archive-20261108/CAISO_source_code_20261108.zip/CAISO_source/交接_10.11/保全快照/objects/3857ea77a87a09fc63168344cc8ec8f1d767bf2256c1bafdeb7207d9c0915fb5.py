"""One bounded graph-prior investigation; immutable existing evidence is read only."""
from pathlib import Path
import hashlib, json
HERE=Path(__file__).resolve().parent
ROOT=HERE.parent
OLD=ROOT/'residual_attention_v1_20260928'
def read(p): return json.loads(p.read_text(encoding='utf-8-sig'))
def sha(p): return hashlib.sha256(p.read_bytes()).hexdigest()
def write(p,v):
    with p.open('x',encoding='utf-8') as f: json.dump(v,f,ensure_ascii=False,indent=2,allow_nan=False)
def main():
    old=read(OLD/'PROTOCOL.json')
    parents=[p for p in old['parents'] if p['variant']=='FULL']
    controls=[]
    for p in parents:
        s=p['seed']; folder=OLD/'runs'/f'{s}_FULL_CONT'
        r=read(folder/'completion.json'); a=read(folder/'audit.json')
        assert a['status']=='passed' and a['completion_sha256']==sha(folder/'completion.json')
        controls.append(dict(seed=s,directory=str(folder),completion_sha256=sha(folder/'completion.json'),audit_sha256=sha(folder/'audit.json')))
    for name in ('gate.py','selection.py','watch_manager_exit.ps1','launch.ps1'):
        text=(OLD/name).read_text(encoding='utf-8-sig')
        if name=='gate.py': text=text.replace("'residual_attention_'", "'graph_prior_'")
        (HERE/name).write_text(text,encoding='utf-8-sig' if name.endswith('.ps1') else 'utf-8')
    common=(OLD/'common.py').read_text(encoding='utf-8')
    start=common.index('def model('); end=common.index('\n\ndef optimizer',start)
    common=common[:start]+'''def model(seed,variant,limits):
    from models.factory import build_backbone
    from model import PriorFusion
    p=parent(seed,variant);g.need(g.sha(p['checkpoint'])==p['sha256'],'Parent changed')
    saved=torch.load(p['checkpoint'],map_location='cpu',weights_only=False)
    state=saved['state_dict'];del saved
    if variant=='PRIOR':
        record=g.read(g.HERE/'diagnostic/RESULT.json')
        item=next(r for r in record['seeds'] if r['seed']==seed)
        g.need(g.sha(item['prior_path'])==item['prior_sha256'],'Prior changed')
        prior=np.load(item['prior_path'],allow_pickle=False)
        m=PriorFusion(seed,limits,prior)
        state=dict(state);state['graph.prior_adjacency']=torch.as_tensor(prior,dtype=torch.float32)
    else:
        g.need(variant=='FULL_CONT','Unregistered model')
        m=build_backbone('FULL',seed,limits)
    m.load_state_dict(state,strict=True)
    return m
'''+common[end:]
    (HERE/'common.py').write_text(common,encoding='utf-8')
    protocol=dict(status='registered_before_diagnostic_or_training',authorization='User: 你做着试试看',
        scope='Post-test exploratory TRAIN/June amendment; original63frozen cases unchanged; no new test access.',
        hypothesis='A training-only stable cross-node prior can stabilize input-conditioned graph propagation. Instability is a hypothesis, not an established cause.',
        formula='Aeff = 0.5*A_train_prior + 0.5*A_dynamic; all parallel TCN/Transformer, feature-attention, head and loss unchanged.',
        prior='Each seed: mean original FULL epoch12 adjacency on512 unique TRAIN origins distributed over the available chronology; retain5 largest cross-node entries per row plus self, then row-normalize. Frozen throughout continuation.',
        diagnostic=dict(fit_origins=512,probe_origins=192,source='train_all only, targets end<=210528',
            stability='Chronological halves of the fit sample estimate graph drift. Compare row-L1 distance between half means with mean individual-graph distance to full mean.',
            proceed_rule='At least2/3seeds: mean row-L1 variability>0.02; half-mean drift<individual variability; sparse prior neighbor mass>0.1. Finite shapes, probabilities, nonzero dynamic influence required for every seed.',
            gate_scope='Engineering screen for a nonconstant graph with a reproducible average; not proof of predictive superiority. TRAIN probe errors reported for FULL/PRIOR and never used to choose rho or prior.',
            thresholds='0.02,0.1 and rho0.5 are fixed design choices, not literature-derived optimal thresholds.'),
        variants=['PRIOR','FULL_CONT'],seeds=old['seeds'],parents=parents,reused_controls=controls,
        budget=dict(old['budget'],fits_maximum=6,new_fits_planned=3,reused_control_fits=3),
        control_reuse='Require identical parent/data/model/optimizer/RNG/budget/selection/runtime and exact initial-prediction replay plus saved-array audit; if any mismatch, stop for review without quietly reusing or extending.',
        selection=old['selection'],
        evaluation=dict(primary='June3397 mean of seed MAEs; no ensemble',supplementary=['June284','balanced3336','all nodes/horizons/phases/states'],
            promotion='Mean dense MAE improves versus FULL_CONT; at least2/3seed wins; dense/hourly MAE,RMSE,near,H12 means no worse than original epoch12 FULL beyond1e-8. STATIC/SELF results remain required before a graph-superiority claim; this pilot is not that claim.',
            retention='All seed/epoch/model directions retained; no grid or automatic continuation.'),
        stopping_rule='If diagnostic gate fails, no training. Otherwise exactly3 new2epoch continuations and separate numeric audit. Failure closes this family; next candidate needs a separate decision.',
        source_confirmation='Europe2017 metadata feasible but not admitted; no unused CAISO period admitted. New-period confirmation still required for a changed-model generalization claim.',
        risks=['Stable prior may lag regime change','Union of prior and dynamic supports can increase edge density; diagnose/report this, do not attribute every change solely to temporal stability','Two-epoch continuation tests a bounded refinement, not exhaustive convergence'],
        resource=dict(launch_GiB=5,runtime_GiB=4,single_numerical_worker=True,threads=1),
        literature=[dict(url='https://arxiv.org/html/1906.00121v1',basis='Multiple graph supports in propagation; traffic evidence, not EPF proof'),
                    dict(url='https://papers.nips.cc/paper/2020/file/e05c7ba4e087beea9410929698dc41a6-Paper.pdf',basis='Combining initial and learned graph structure; our temporal prior is an adaptation'),
                    dict(url='https://jmlr.org/papers/v11/cawley10a.html',basis='Limit repeated development selection and require fresh confirmation')],
        all_core_elements_preserved=True,test_access_permitted=False,original63_cases_unchanged=True,periodic_model_wakeups=False)
    protocol['budget']['fits']=6
    protocol['budget']['training']='All original trainable parameters; no added trainable parameters; fixed prior buffer only.'
    write(HERE/'PROTOCOL.json',protocol)
    bindings={p:val for p,val in read(OLD/'EXECUTION_SEAL.json')['bindings'].items() if Path(p).is_relative_to(ROOT/'source') or Path(p).is_relative_to(ROOT/'common_sampling_evaluation_20260923')}
    bindings[str(ROOT/'phase_sampling_support_v3_20260923/dataset/ADDITIVE/manifest.json')]=sha(ROOT/'phase_sampling_support_v3_20260923/dataset/ADDITIVE/manifest.json')
    for p in parents: bindings[p['checkpoint']]=p['sha256']
    for item in controls:
        folder=Path(item['directory'])
        for name in ('completion.json','audit.json','run_start.json'):
            bindings[str(folder/name)]=sha(folder/name)
    for name in ('PROTOCOL.json','gate.py','common.py','selection.py','model.py','diagnose.py','prepare.py'):
        bindings[str(HERE/name)]=sha(HERE/name)
    write(HERE/'EXECUTION_SEAL.json',dict(status='sealed_development_only',stage='diagnostic',bindings=bindings,test_access_permitted=False))
    print('Diagnostic registered and sealed; no optimizer updates')
if __name__=='__main__': main()
