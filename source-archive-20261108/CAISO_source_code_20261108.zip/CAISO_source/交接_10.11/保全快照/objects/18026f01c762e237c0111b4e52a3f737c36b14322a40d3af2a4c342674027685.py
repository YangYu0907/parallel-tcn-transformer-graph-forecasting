"""Independent, bounded NumPy verification of the frozen twelve-case controls June284 summary.

Uses no registered_summary or controls_summary functions, model code, Q3 data, or 2026 data.
Output is a new immutable audit, never an update to an experiment result.
"""
from pathlib import Path
from datetime import datetime, timezone
import argparse
import ctypes
import hashlib
import json
import os
import sys
import time
import uuid

HERE = Path(__file__).resolve().parent
ROOT = HERE.parent
LOCK = Path('D:/Desktop/数据科学_论文/研究优化_20260818/logs/NEURAL_RUN.lock')
OUTPUT = HERE / 'independent_numeric_audit_reviewed.json'
PINNED_RESULT_SHA = '335c554db811c89bbdbdfedf2b8d2f8e624756567a58f992bcb30847a560afd0'
PINNED_SEAL_SHA = 'c0aa68e9cb221607331b5532679df0ed4d9230bfb401c6b6fab2865b0e97bcc7'
PINNED_QUEUE_COMPLETION_SHA = '415d30653f4c33f4e1e43f74fbf283db8b1bbd9d7d324e0d447be57830e95682'
QUEUE_LOCK_SHA = '1a5335ff40f0d9082bcf9218d27839357da3207be5b6b4ad8d4214add8136db6'
QUEUE_PLAN_SHA = 'ea1b9da71a25b9624feb1328105aa250dee9257a8300b68e90cb4702e26b754b'
SEEDS = (20260813, 20260814)
VARIANTS = ('FULL', 'TCN', 'EQUAL', 'CONCAT')
THREAD_VARS = ('OMP_NUM_THREADS', 'MKL_NUM_THREADS', 'OPENBLAS_NUM_THREADS',
               'NUMEXPR_NUM_THREADS', 'BLIS_NUM_THREADS', 'VECLIB_MAXIMUM_THREADS')


def require(value, message):
    if not value:
        raise RuntimeError(message)


def now():
    return datetime.now(timezone.utc).isoformat()


def read(path):
    return json.loads(Path(path).read_text(encoding='utf-8-sig'))


def digest(path):
    value = hashlib.sha256()
    with Path(path).open('rb') as stream:
        for block in iter(lambda: stream.read(1024 * 1024), b''):
            value.update(block)
    return value.hexdigest()


def inside(value):
    value = Path(value)
    path = (ROOT / value if not value.is_absolute() else value).resolve()
    require(path.is_relative_to(ROOT), 'Input escapes the new branch')
    return path


def boundary():
    pause = read(ROOT.parent / 'RESEARCH_PAUSED.json')
    require(pause.get('status') == 'resumed_by_user' and
            not pause.get('stop_preparation_and_training'), 'Research paused')
    for folder in (ROOT, HERE):
        for name in ('STOP_REQUESTED', 'STOP_REQUESTED.json'):
            require(not (folder / name).exists(), 'Stop requested')


def resource_guard(minimum=4.0):
    class Performance(ctypes.Structure):
        _fields_ = [('cb', ctypes.c_ulong)] + [
            (name, ctypes.c_size_t) for name in
            ('CommitTotal', 'CommitLimit', 'CommitPeak', 'PhysicalTotal',
             'PhysicalAvailable', 'SystemCache', 'KernelTotal', 'KernelPaged',
             'KernelNonpaged', 'PageSize')] + [
            (name, ctypes.c_ulong) for name in ('HandleCount', 'ProcessCount', 'ThreadCount')]
    value = Performance()
    value.cb = ctypes.sizeof(value)
    require(ctypes.windll.psapi.GetPerformanceInfo(ctypes.byref(value), value.cb),
            'Cannot read physical/commit resources')
    result = dict(physical_GiB=value.PhysicalAvailable * value.PageSize / 2**30,
                  commit_GiB=(value.CommitLimit-value.CommitTotal) * value.PageSize / 2**30)
    require(min(result.values()) >= minimum, 'Insufficient physical/commit GiB: ' + repr(result))
    return result


def immutable_report(value):
    # A single, short path under this validation directory; no old result mutation.
    pending = HERE / ('audit_' + uuid.uuid4().hex + '.pending')
    with pending.open('xb') as stream:
        stream.write((json.dumps(value, ensure_ascii=False, indent=2, allow_nan=False)+'\n').encode('utf-8'))
        stream.flush()
        os.fsync(stream.fileno())
    pending.rename(OUTPUT)



def case_ids(variants):
    return {f'CONTROL_{v}_{seed}' for v in variants for seed in SEEDS} | {
        f'{v}_{seed}' for v in ('DLinear', 'iTransformer-X') for seed in SEEDS}


def sealed_binding(seal, path, expected, tracked):
    path = inside(path)
    keys = [key for key in seal['sources'] if inside(key) == path]
    require(len(keys) == 1, 'Missing/duplicate sealed binding: ' + str(path))
    actual = digest(path)
    require(actual == expected == seal['sources'][keys[0]], 'Binding differs: ' + str(path))
    tracked[str(path.relative_to(ROOT))] = actual
    return path


def queue_chain(seal, tracked):
    binding = seal['queue_completion_binding']
    require(binding['completion_sha256'] == PINNED_QUEUE_COMPLETION_SHA, 'Queue completion differs from actual authorized completion')
    require(not (ROOT / 'post_backbone_queue_io_v2/QUEUE.lock').exists(), 'Queue manager lock still exists')
    terminal = ROOT / 'post_backbone_queue_io_v2/status.json'
    sealed_binding(seal, terminal, digest(terminal), tracked)
    state = read(terminal)
    require(state['event'] == 'finite_post_backbone_completed' and state['completion_sha256'] == PINNED_QUEUE_COMPLETION_SHA, 'Queue lacks matching terminal event')
    require(binding['required_tasks'] == 118, 'Queue task count differs')
    lock_path = inside(binding['source_lock'])
    completion_path = inside(binding['completion'])
    require(lock_path == ROOT / 'POST_BACKBONE_LOCK_io_v2.json' and
            completion_path == ROOT / 'post_backbone_queue_io_v2/completion.json', 'Wrong queue binding path')
    require(binding['source_lock_sha256'] == QUEUE_LOCK_SHA, 'Unregistered queue source lock')
    sealed_binding(seal, lock_path, QUEUE_LOCK_SHA, tracked)
    sealed_binding(seal, completion_path, binding['completion_sha256'], tracked)
    plan_path = ROOT / 'POST_BACKBONE_PLAN_io_v2.json'
    sealed_binding(seal, plan_path, QUEUE_PLAN_SHA, tracked)
    completion, lock, plan = read(completion_path), read(lock_path), read(plan_path)
    require(completion['status'] == 'registered_internal_and_external_TRAIN_June_stages_independently_audited'
            and completion['post_backbone_lock_sha256'] == QUEUE_LOCK_SHA
            and completion['Q3_evaluated'] is False and completion['H1_evaluated'] is False,
            'Queue is not completely audited TRAIN/June only')
    require(lock['status'] == 'sealed_finite_post_backbone_queue' and lock['plan_sha256'] == QUEUE_PLAN_SHA,
            'Queue lock/plan mismatch')
    steps = plan['steps']
    require(len(steps) == 118 and len({step['id'] for step in steps}) == 118, 'Queue needs exactly 118 unique steps')
    expected_receipts = {step['id'] + '.json' for step in steps}
    require(set(completion['step_receipts']) == expected_receipts, 'Queue receipt coverage differs')
    # Verify the exact registered code set without importing the queue/training code.
    for rel, expected in lock['sources'].items():
        path = inside(rel)
        require(digest(path) == expected, 'Queue-locked source changed: ' + rel)
        tracked[str(path.relative_to(ROOT))] = expected
    counted = {'completed': 0, 'accepted_existing_success_marker': 0}
    for step in steps:
        path = ROOT / 'post_backbone_queue_io_v2/steps' / (step['id'] + '.json')
        sealed_binding(seal, path, completion['step_receipts'][path.name], tracked)
        receipt = read(path)
        require(receipt['step'] == step and receipt['post_backbone_lock_sha256'] == QUEUE_LOCK_SHA,
                'Queue step identity differs: ' + step['id'])
        status = receipt['status']
        require(status in counted, 'Queue step not successful: ' + step['id'])
        if status == 'completed':
            require(type(receipt['exit_code']) is int and receipt['exit_code'] == 0,
                    'Queue child did not exit zero: ' + step['id'])
        counted[status] += 1
        marker = receipt['marker']
        marker_path = inside(marker['path'])
        require(marker_path == inside(step['success_marker']) and marker['status'] == step['expected_status'],
                'Queue marker identity differs: ' + step['id'])
        sealed_binding(seal, marker_path, marker['sha256'], tracked)
        row = read(marker_path)
        require(row['status'] == step['expected_status'], 'Queue marker status differs: ' + step['id'])
        require(row.get('Q3_targets_read', False) is False and row.get('test_2026_targets_read', False) is False
                and row.get('H1_targets_read', False) is False, 'Queue marker crossed target boundary')
    return dict(steps=118, status=completion['status'], completion_sha256=digest(completion_path),
                source_lock_sha256=QUEUE_LOCK_SHA, plan_sha256=QUEUE_PLAN_SHA,
                receipt_status_counts=counted, all_current_markers_and_sources_verified=True)


def prior_eight(seal, result, tracked):
    binding = seal['prior_registered_binding']
    old_dir = ROOT / 'validation_registered_20260919'
    filenames = dict(result='result.json', validation_lock='VALIDATION_LOCK.json',
                     numeric_audit='independent_numeric_audit_20260920_v2.json',
                     execution='run_execution_1b859862cbb5.json',
                     numeric_audit_execution='independent_numeric_audit_execution_4762a940d8cb.json')
    paths = {}
    for key, name in filenames.items():
        path = inside(binding[key])
        require(path == old_dir / name, 'Wrong old-eight provenance path: ' + key)
        paths[key] = sealed_binding(seal, path, binding[key + '_sha256'], tracked)
    old, old_seal, audit = read(paths['result']), read(paths['validation_lock']), read(paths['numeric_audit'])
    execution, audit_execution = read(paths['execution']), read(paths['numeric_audit_execution'])
    require(digest(paths['result']) == '3595a92dbd5c74bd81e9620a5ef6a4053c93ec5c167f6a40f57f71c32bb2581b'
            and digest(paths['validation_lock']) == '47d8f3a5b636182dce41e52ec823164f851662e7dc5e6270449e7594ac866013'
            and digest(paths['numeric_audit']) == '326920db577cba6a1674426ba57f7daaef205ebe66a000ced0c4eac89dbfcc41',
            'Previously accepted eight-case baseline changed')
    require(old['status'] == 'passed_registered_June284_summary'
            and old_seal['status'] == 'sealed_registered_June284_only'
            and audit['status'] == 'passed_independent_registered_June284_numeric_audit'
            and audit['case_count'] == 8 and audit['lock_released'] is True,
            'Old eight-case result lacks successful independent audit')
    require(type(execution['exit_code']) is int and execution['exit_code'] == 0
            and execution['result_sha256'] == digest(paths['result'])
            and execution['validation_lock_sha256'] == digest(paths['validation_lock'])
            and execution['source_sha256'] == old['source_sha256'] == old_seal['source_code_sha256']
            == digest(old_dir / 'registered_summary.py'), 'Old scorer execution binding failed')
    require(type(audit_execution['exit_code']) is int and audit_execution['exit_code'] == 0
            and audit_execution['report_sha256'] == digest(paths['numeric_audit'])
            and audit_execution['auditor_source_sha256'] == audit['independent_auditor_source_sha256']
            == digest(old_dir / 'independent_numeric_audit_20260920_v2.py'), 'Old independent audit native exit binding failed')
    require(audit['result_sha256'] == digest(paths['result']) and
            audit['validation_lock_sha256'] == digest(paths['validation_lock']) and
            audit['original_execution_sha256'] == digest(paths['execution']), 'Old audit target binding differs')
    for name in ('registered_summary.py', 'independent_numeric_audit_20260920_v2.py'):
        path = old_dir / name
        tracked[str(path.relative_to(ROOT))] = digest(path)
    expected = case_ids(('FULL', 'TCN'))
    require(len(old['results']) == len(old_seal['cases']) == 8 and
            {row['id'] for row in old['results']} == {row['id'] for row in old_seal['cases']} == expected,
            'Old eight-case set differs')
    require(len(result['results']) == 12 and len({row['id'] for row in result['results']}) == 12,
            'New result has missing or duplicate cases')
    new_rows = {row['id']: row for row in result['results']}
    for row in old['results']:
        require(row['id'] in new_rows, 'An old case is missing')
        # Exact equality of every original row field, including all four metrics,
        # twelve horizon MAEs, mapping, prediction/selection/audit hashes and units.
        for field, value in row.items():
            require(new_rows[row['id']].get(field) == value, 'Old case changed: ' + row['id'] + '/' + field)
    for field in ('registered_origins', 'canonical_truth_float64_sha256', 'node_order'):
        require(result[field] == old[field], 'Common old/new population or truth changed: ' + field)
    return dict(case_count=8, all_original_row_fields_exactly_equal=True,
                result_sha256=digest(paths['result']), numeric_audit_sha256=digest(paths['numeric_audit']),
                scorer_exit_code=0, independent_auditor_exit_code=0)


def runner_execution(execution, execution_path, seal, result):
    require(execution.get('status') == 'actual_native_execution_recorded' and
            execution.get('action') == 'run' and type(execution['exit_code']) is int and
            execution['exit_code'] == 0, 'Producer needs actual successful external run receipt')
    command = execution['command']
    require(isinstance(command, list) and len(command) == 3 and
            inside(command[1]) == HERE / 'controls_summary.py' and command[2] == 'run',
            'External receipt command is not this producer run')
    require(datetime.fromisoformat(execution['end']) >= datetime.fromisoformat(execution['start']),
            'External receipt timestamps reversed')
    require(execution['result_sha256'] == digest(HERE / 'result.json') == PINNED_RESULT_SHA and
            execution['VALIDATION_LOCK_sha256'] == digest(HERE / 'VALIDATION_LOCK.json') == PINNED_SEAL_SHA and
            execution['source_sha256'] == seal['source_code_sha256'] == result['source_sha256'] ==
            digest(HERE / 'controls_summary.py'), 'Actual producer receipt/file binding failed')
    require(execution.get('training_started') is False, 'Producer receipt unexpectedly started training')
    require(execution_path.is_relative_to(HERE) and execution_path not in
            (HERE / 'result.json', HERE / 'VALIDATION_LOCK.json', OUTPUT), 'Wrong receipt location')
    for stream in ('stdout', 'stderr'):
        path = inside(execution[stream])
        require(path.is_relative_to(HERE) and digest(path) == execution[stream + '_sha256'],
                'Actual execution log changed: ' + stream)
    require(inside(execution['stderr']).stat().st_size == 0, 'Producer stderr is not empty')


def selected_provenance(seal, tracked):
    """Check current selected checkpoints/predictions against their independent audit.

    No model is loaded and no alternative checkpoint is inspected or selected.
    """
    checked = []
    for case in seal['cases']:
        selected = read(inside(case['selection']))
        audit = read(inside(case['audit']))
        require(audit['status'] == 'passed' and audit['selection_sha256'] == digest(inside(case['selection'])),
                'Final selected model lacks matching independent audit: ' + case['id'])
        cp = sealed_binding(seal, selected['checkpoint'], case['checkpoint_sha256'], tracked)
        require(selected['checkpoint_sha256'] == case['checkpoint_sha256'], 'Wrong selected checkpoint')
        if case['kind'] == 'primary':
            identity = selected['identity']
            require(identity['seed'] == case['seed'] and identity['variant'] == case['model'] and
                    audit['identity'] == identity and selected['stage'] == 'CONTROL' and
                    selected['step'] == audit['selected_step'] == case['selected_step'] and
                    audit['selected_predictions_replayed'] is True, 'Primary selection identity/audit mismatch')
            require(cp.is_relative_to(inside(case['selection']).parent / 'checkpoints'), 'Primary checkpoint directory')
            require(selected['inner_prediction'] == case['prediction'] and
                    selected['inner_prediction_sha256'] == seal['sources'][case['prediction']], 'Selected prediction differs')
            evaluation = inside(selected['selected_evaluation_directory'])
            ec = read(sealed_binding(seal, evaluation / 'commit.json', selected['selected_evaluation_commit_sha256'], tracked))
            require(ec['status'] == 'committed' and ec['identity'] == identity and
                    ec['artifacts']['inner_prediction.npy'] == selected['inner_prediction_sha256'] and
                    inside(case['prediction']) == evaluation / 'inner_prediction.npy', 'Selected evaluation commit differs')
            er = read(sealed_binding(seal, evaluation / 'record.json', ec['artifacts']['record.json'], tracked))
            require(er['checkpoint_sha256'] == case['checkpoint_sha256'] and er['step'] == case['selected_step'],
                    'Prediction evaluated a different checkpoint')
            completion = inside(case['selection']).parent / 'fit_completion.json'
            cr = read(sealed_binding(seal, completion, audit['fit_completion_sha256'], tracked))
            require(cr['selection_sha256'] == audit['selection_sha256'] and cr['identity'] == identity,
                    'Selected CONTROL completion differs')
        else:
            require(case['kind'] == 'external' and selected['model'] == audit['model'] == case['model'] and
                    selected['seed'] == audit['seed'] == case['seed'] and
                    selected['selected_epoch'] == audit['selected_epoch'] == case['selected_epoch'] and
                    audit['selected_checkpoint_sha256'] == case['checkpoint_sha256'], 'External selected identity differs')
            frozen = read(sealed_binding(seal, inside(case['prediction']).parent / 'result.json',
                                        audit['frozen_june_result_sha256'], tracked))
            require(frozen['status'] == 'frozen_June_predictions_verified' and
                    frozen['selected_sha256'] == audit['selection_sha256'] and frozen['optimizer_steps'] == 0 and
                    frozen['prediction_sha256'] == seal['sources'][case['prediction']] and
                    frozen['origins_sha256'] == seal['sources'][case['origins']], 'External frozen provenance differs')
        for metadata in (selected, audit):
            require(metadata.get('Q3_targets_read', False) is False and
                    metadata.get('H1_targets_read', False) is False and
                    metadata.get('test_2026_targets_read', False) is False, 'Selected provenance crossed target boundary')
        checked.append(case['id'])
    require(len(checked) == 12 and set(checked) == case_ids(VARIANTS), 'Selected provenance not complete')
    return checked


def synthetic_qa():
    # Exercise admission/rejection without importing NumPy or touching real arrays.
    import bisect
    import math
    tested = []
    require(len(case_ids(VARIANTS)) == 12 and len(case_ids(('FULL', 'TCN'))) == 8, 'Case matrix')
    tested.append('fixed12_cases_and_prior8')
    def join(source, target):
        require(len(set(source)) == len(source) and len(set(target)) == len(target), 'Duplicate origins')
        ordered = sorted(enumerate(source), key=lambda row: row[1])
        keys = [row[1] for row in ordered]
        result = []
        for value in target:
            position = bisect.bisect_left(keys, value)
            require(position < len(keys) and keys[position] == value, 'Missing origin')
            result.append(ordered[position][0])
        return result
    require(join([40, 10, 30, 20], [30, 10, 40]) == [2, 1, 0], 'Actual origin join')
    tested.append('shuffled_subset_preserves_requested_origin_order')
    for source, target in [([1, 1], [1]), ([1, 2], [1, 1]), ([1, 2], [3])]:
        try: join(source, target)
        except RuntimeError: pass
        else: raise RuntimeError('Bad synthetic join accepted')
    tested.extend(['duplicate_source_rejected', 'duplicate_registered_rejected', 'missing_origin_rejected'])
    # Node- and channel-specific scalers detect wrong-channel/flattened normalization.
    centers = [[[10, 100, 1000, 10000], [20, 200, 2000, 20000]]]
    scales = [[[2, 3, 4, 5], [7, 8, 9, 10]]]
    raw = [[1, -2], [3, 4]]
    truth = [[raw[h][n] * scales[0][n][0] + centers[0][n][0] for h in range(2)] for n in range(2)]
    require(truth == [[12, 16], [6, 48]], 'Channel-zero USD reconstruction')
    tested.append('target_channel0_nodewise_USD')
    errors = [[(-1 if (n+h) % 2 else 1) * (h+1) for h in range(12)] for n in range(3)]
    flat = [x for row in errors for x in row]
    require(sum(abs(x) for x in flat)/len(flat) == 6.5 and
            sum(abs(row[h]) for row in errors for h in range(4))/12 == 2.5 and
            sum(abs(row[11]) for row in errors)/3 == 12 and
            abs(math.sqrt(sum(x*x for x in flat)/len(flat))-math.sqrt(650/12)) < 1e-12, 'Metric definitions')
    tested.append('four_metrics_and12_horizon_definition')
    require('numpy' not in sys.modules and 'torch' not in sys.modules, 'Numerical library imported during synthetic QA')
    return tested


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--synthetic-qa', action='store_true')
    parser.add_argument('--metadata-only', action='store_true')
    parser.add_argument('--execution-receipt', help='Real external scorer exit receipt inside this validation directory')
    args = parser.parse_args()
    if args.synthetic_qa:
        print(json.dumps(dict(status='passed', tests=synthetic_qa(), source_sha256=digest(__file__), numpy_imported=False, Torch_imported=False, real_arrays_read=0)))
        return
    require(args.execution_receipt, '--execution-receipt is required')
    EXECUTION = inside(args.execution_receipt)
    require(os.name == 'nt', 'This audit is registered for Windows')
    require(not OUTPUT.exists(), 'Audit already exists; no overwrite')
    boundary()
    # Pure metadata gate runs before numerical import and before lock acquisition.
    pre_seal = read(HERE / 'VALIDATION_LOCK.json')
    pre_result = read(HERE / 'result.json')
    require(pre_seal['status'] == 'sealed_controls_June284_only' and
            pre_result['status'] == 'computed_controls_June284_pending_independent_numeric_audit', 'Wrong controls input status')
    tracked = {}
    queue_review = queue_chain(pre_seal, tracked)
    baseline_review = prior_eight(pre_seal, pre_result, tracked)
    runner_execution(read(EXECUTION), EXECUTION, pre_seal, pre_result)
    selected_review = selected_provenance(pre_seal, tracked)
    # Independent auditor is bound by its own real execution receipt, never retroactively by the producer seal.
    tracked[str(Path(__file__).resolve().relative_to(ROOT))] = digest(__file__)
    for stream in ('stdout', 'stderr'):
        p = inside(read(EXECUTION)[stream])
        tracked[str(p.relative_to(ROOT))] = digest(p)
    if args.metadata_only:
        require('numpy' not in sys.modules and 'torch' not in sys.modules, 'Numerical import in metadata preparation')
        print(json.dumps(dict(status='passed_metadata_preparation_only', queue=queue_review, prior_eight=baseline_review, selected_cases=selected_review, source_sha256=digest(__file__), numerical_audit_executed=False)))
        return
    initial_resources = resource_guard(4.0)
    import psutil
    process = psutil.Process()
    owner = dict(token=uuid.uuid4().hex, pid=os.getpid(), created=process.create_time(),
                 action='independent_numeric_controls_June284_audit',
                 directory=str(HERE), at=now())
    # Never remove a pre-existing or another worker's lock.
    with LOCK.open('x', encoding='utf-8') as stream:
        json.dump(owner, stream, ensure_ascii=False)
        stream.flush()
        os.fsync(stream.fileno())
    started = time.perf_counter()
    report = dict(status='failed', at=now(), independent_auditor_source_sha256=digest(__file__),
                  lock_owner=owner, Q3_targets_read=False, H1_targets_read=False, test_2026_targets_read=False,
                  model_forward_calls=0, optimizer_steps=0, model_selection_performed=False)
    error = None
    try:
        boundary()
        resource_guard()
        for key in THREAD_VARS:
            os.environ[key] = '1'
        os.environ['OMP_DYNAMIC'] = os.environ['MKL_DYNAMIC'] = 'FALSE'
        process.cpu_affinity([min(process.cpu_affinity())])
        import numpy as np
        require(len(process.cpu_affinity()) == 1, 'Single CPU affinity failed')
        require('torch' not in sys.modules and 'registered_summary' not in sys.modules and 'controls_summary' not in sys.modules,
                'Forbidden model or original scorer import')
        seal_path = HERE / 'VALIDATION_LOCK.json'
        result_path = HERE / 'result.json'
        seal, result, execution = read(seal_path), read(result_path), read(EXECUTION)
        fixed_hashes = {**tracked, **{str(p.relative_to(ROOT)): digest(p) for p in (seal_path, result_path, EXECUTION)}}
        require(seal == pre_seal and result == pre_result, 'Inputs changed since metadata admission')
        runner_execution(execution, EXECUTION, seal, result)
        require(execution['exit_code'] == 0 and execution['result_sha256'] == digest(result_path),
                'Original successful execution/result binding failed')
        require(seal['status'] == 'sealed_controls_June284_only' and
                result['status'] == 'computed_controls_June284_pending_independent_numeric_audit', 'Unexpected input status')
        require(result['validation_lock_sha256'] == execution['VALIDATION_LOCK_sha256'] == digest(seal_path),
                'Validation lock binding failed')
        require(result['source_sha256'] == execution['source_sha256'] == seal['source_code_sha256'] ==
                digest(HERE/'controls_summary.py'), 'Original source binding failed')
        require(result['model_selection_performed'] is False and result['optimizer_steps'] == 0 and
                result['model_forward_calls'] == 0 and result['Q3_targets_read'] is False and
                result['H1_targets_read'] is False and result['Torch_imported'] is False,
                'Original result is not frozen June-only scoring')
        for rel, expected in seal['sources'].items():
            require(digest(inside(rel)) == expected, 'Sealed source changed: ' + rel)
        manifest = read(inside(seal['dataset_manifest']))
        require(manifest['prefix_stop'] == manifest['june_target_stop_exclusive'] == 219168 and
                manifest['train_target_stop_exclusive'] == 210528 and manifest['node_count'] == 30,
                'Unsafe dataset bounds')
        require(manifest['Q3_target_values_read'] is False and manifest['test_2026_targets_read'] is False,
                'Unexpected dataset target scope')
        require(set(seal['dataset_artifacts']) == {'registered_june_origins.npy', 'june_origins.npy', 'target_scaled.npy', 'scalers.json'}, 'Unexpected dataset artifact set')
        files = {key: inside(rel) for key, rel in seal['dataset_artifacts'].items()}
        for key, path in files.items():
            require(path.is_relative_to(ROOT / 'dataset/compiled_train_june'), 'Dataset path outside safe prefix')
            require(path == inside(manifest['artifacts'][key]['path']) and
                    digest(path) == manifest['artifacts'][key]['sha256'], 'Dataset artifact binding failed')
        registered = np.load(files['registered_june_origins.npy'], allow_pickle=False)
        dense = np.load(files['june_origins.npy'], allow_pickle=False)
        require(registered.shape == (284,) and registered.dtype.kind in 'iu' and
                len(np.unique(registered)) == 284 and np.all(np.diff(registered) > 0), 'Registered origins invalid')
        require(np.array_equal(registered, np.asarray(result['registered_origins'])) and
                np.all(registered >= 210528) and np.all(registered + 12 <= 219168), 'Registered target bounds/order')
        require(dense.shape == (3397,) and dense.dtype.kind in 'iu' and len(np.unique(dense)) == 3397
                and np.all(dense >= 210528) and np.all(dense + 12 <= 219168), 'Dense origins invalid')
        scalers = read(files['scalers.json'])
        price_centers = np.asarray(scalers['price_center'], dtype=np.float64)
        price_scales = np.asarray(scalers['price_scale'], dtype=np.float64)
        require(price_centers.shape == price_scales.shape == (1, 30, 4), 'Price-block scaler layout differs')
        # Channel 0 is the target LMP; the other price-block channels are not the target.
        center = price_centers[0, :, 0]
        scale = price_scales[0, :, 0]
        require(np.isfinite(center).all() and np.isfinite(scale).all() and np.all(scale > 0), 'Invalid scaler')
        # Independent vectorized [origin,horizon,node] construction, then axis transpose.
        target = np.load(files['target_scaled.npy'], mmap_mode='r', allow_pickle=False)
        try:
            require(target.shape == (219168, 30) and target.dtype == np.float32, 'Unsafe target array')
            rows = registered[:, None] + np.arange(12, dtype=np.int64)[None, :]
            truth = np.asarray(target[rows], dtype=np.float64).transpose(0, 2, 1).copy()
        finally:
            target._mmap.close()
        truth *= scale[None, :, None]
        truth += center[None, :, None]
        require(np.isfinite(truth).all() and truth.shape == (284, 30, 12), 'Invalid reconstructed truth')
        truth_sha = hashlib.sha256(truth.tobytes(order='C')).hexdigest()
        require(truth_sha == result['canonical_truth_float64_sha256'], 'Canonical truth differs')
        require(result['node_order'] == seal['nodes'] == manifest['nodes'], 'Node order differs')
        expected_ids = case_ids(VARIANTS)
        require(len(seal['cases']) == len(result['results']) == 12 and
                {c['id'] for c in seal['cases']} == {r['id'] for r in result['results']} == expected_ids,
                'Twelve-case completeness failed')
        saved_rows = {r['id']: r for r in result['results']}
        verified = []
        for case in seal['cases']:
            boundary()
            resource_guard()
            saved = saved_rows[case['id']]
            require(case['kind'] in ('primary', 'external'), 'Unknown case kind')
            expected_kind = 'primary' if case['id'].startswith('CONTROL_') else 'external'
            require(case['kind'] == expected_kind and case['seed'] in SEEDS, 'Case kind/seed mismatch')
            expected_id = ('CONTROL_' if expected_kind == 'primary' else '') + str(case['model']) + '_' + str(case['seed'])
            require(case['id'] == expected_id, 'Case identifier/model mismatch')
            origins = np.load(inside(case['origins']), allow_pickle=False)
            require(origins.dtype.kind in 'iu' and origins.ndim == 1 and
                    len(np.unique(origins)) == len(origins), 'Source origins invalid')
            # Sorted-search join is independent from original dictionary lookup.
            ordering = np.argsort(origins, kind='stable')
            sorted_origins = origins[ordering]
            positions = np.searchsorted(sorted_origins, registered)
            require(np.all(positions < len(origins)) and
                    np.array_equal(sorted_origins[positions], registered), 'Actual-origin join failed')
            indices = ordering[positions]
            require(indices.tolist() == saved['source_indices'] and
                    np.array_equal(origins[indices], registered), 'Recorded origin mapping differs')
            expected_population = 'dense_June3397' if case['kind'] == 'primary' else 'registered_June284'
            require(case['source_selection_population'] == saved['source_selection_population'] == expected_population,
                    'Selection population changed')
            require(np.array_equal(sorted_origins, np.sort(dense if case['kind'] == 'primary' else registered)),
                    'Source origin population differs')
            require(case['input_prediction_units'] == 'USD/MWh', 'Prediction units changed')
            require(saved['join'] == 'unique_actual_origin_to_registered_order' and saved['truth_matches_canonical'] is True and
                    saved['mapping_is_identity_prefix'] == np.array_equal(indices, np.arange(284)), 'Mapping declaration differs')
            if case['kind'] == 'primary':
                cached = np.load(inside(case['truth']), mmap_mode='r', allow_pickle=False)
                try:
                    require(cached.shape == (3397, 30, 12) and cached.dtype == np.float64 and np.array_equal(cached[indices], truth), 'Primary truth differs after join')
                finally:
                    cached._mmap.close()
            source = np.load(inside(case['prediction']), mmap_mode='r', allow_pickle=False)
            try:
                require(source.dtype == np.float64 and list(source.shape) == case['source_prediction_shape'] ==
                        ([3397, 30, 12] if case['kind'] == 'primary' else [284, 30, 12]), 'Prediction shape/dtype mismatch')
                pred = np.array(source[indices], dtype=np.float64)
            finally:
                source._mmap.close()
            require(np.isfinite(pred).all() and pred.shape == truth.shape, 'Prediction not finite/complete')
            err = pred - truth
            absolute = np.abs(err)
            metrics = dict(mae=float(np.mean(absolute, dtype=np.float64)),
                           rmse=float(np.sqrt(np.mean(np.square(err), dtype=np.float64))),
                           near_h1_4_mae=float(np.mean(absolute[:, :, :4], dtype=np.float64)),
                           h12_mae=float(np.mean(absolute[:, :, 11], dtype=np.float64)))
            horizon = np.mean(absolute, axis=(0, 1), dtype=np.float64)
            require(all(isinstance(saved['metrics'][key], (int, float)) and np.isfinite(saved['metrics'][key]) for key in metrics),
                    'Saved metrics not finite scalars')
            saved_horizon = np.asarray(saved['metrics']['mae_by_horizon'], dtype=np.float64)
            require(saved_horizon.shape == (12,) and np.isfinite(saved_horizon).all(), 'Saved horizon metrics invalid')
            differences = {key: abs(value-saved['metrics'][key]) for key, value in metrics.items()}
            differences['all12_horizon_max'] = float(np.max(np.abs(horizon-saved_horizon)))
            require(max(differences.values()) <= 1e-10, 'Independent metric mismatch: ' + case['id'])
            require(saved['origins'] == 284 and saved['nodes'] == 30 and saved['horizons'] == 12 and
                    saved['forecast_cells'] == 102240 and saved['units'] == 'USD/MWh', 'Metric population/units mismatch')
            for field in ('seed', 'model', 'kind', 'checkpoint_sha256', 'selection', 'audit'):
                require(saved[field] == case[field], 'Case metadata mismatch: ' + field)
            for field, source_key in [('prediction_sha256', 'prediction'), ('selection_sha256', 'selection'),
                                      ('audit_sha256', 'audit')]:
                require(saved[field] == seal['sources'][case[source_key]] == digest(inside(case[source_key])),
                        'Case result binding failed: ' + field)
            if case['kind'] == 'external':
                require(max(abs(metrics[k]-case['reference_metrics'][k]) for k in metrics) <= 1e-10,
                        'External frozen metric mismatch')
            verified.append(dict(id=case['id'], metrics=metrics, mae_by_horizon=horizon.tolist(), maximum_abs_difference=max(differences.values()),
                                 metric_abs_differences=differences, actual_origin_mapping_verified=True,
                                 canonical_truth_verified=True, source_selection_population=expected_population))
        for rel, expected in {**seal['sources'], **fixed_hashes}.items():
            require(digest(inside(rel)) == expected, 'Input changed during independent audit: ' + rel)
        require('torch' not in sys.modules and 'registered_summary' not in sys.modules and 'controls_summary' not in sys.modules, 'Forbidden module imported')
        boundary()
        report.update(status='passed_independent_controls_June284_numeric_audit',
                      validation_lock_sha256=digest(seal_path), result_sha256=digest(result_path),
                      original_execution_sha256=digest(EXECUTION), sealed_inputs_checked=len(seal['sources']),
                      original_execution_exit_code=execution['exit_code'], canonical_truth_float64_sha256=truth_sha,
                      cases=verified, case_count=len(verified), all_four_metrics_and_12_horizons_verified=True,
                      queue_completion_verified=queue_review, prior_eight_verified=baseline_review,
                      selected_checkpoint_and_prediction_chain_verified=selected_review,
                      actual_native_exit='Not self-certified; caller must bind an external zero-exit receipt to this final report and auditor SHA.',
                      registered_origins=284, nodes=30, horizons=12, cells_per_case=102240,
                      tolerance_absolute=1e-10, selection_populations_kept_distinct=True,
                      original_scorer_imported=False, Torch_imported=False, numpy=np.__version__,
                      numeric_threads=1, cpu_affinity=process.cpu_affinity(),
                      initial_resources=initial_resources, final_resources=resource_guard(),
                      peak_working_set_bytes=process.memory_info().peak_wset,
                      limitations=result['limitations'])
    except BaseException as exc:
        error = exc
        report.update(error_type=type(exc).__name__, error=str(exc))
    finally:
        if not LOCK.exists() or read(LOCK) != owner:
            error = RuntimeError('Global numerical lock ownership changed; refusing deletion')
            report.update(status='failed', error_type=type(error).__name__, error=str(error), lock_released=False)
        else:
            LOCK.unlink()
            report['lock_released'] = True
        report.update(elapsed_seconds=time.perf_counter()-started, finished_at=now())
        immutable_report(report)
    print(json.dumps(dict(status=report['status'], report=str(OUTPUT), report_sha256=digest(OUTPUT),
                          lock_released=report['lock_released'], elapsed_seconds=report['elapsed_seconds'])))
    if error is not None:
        raise error


if __name__ == '__main__':
    main()
