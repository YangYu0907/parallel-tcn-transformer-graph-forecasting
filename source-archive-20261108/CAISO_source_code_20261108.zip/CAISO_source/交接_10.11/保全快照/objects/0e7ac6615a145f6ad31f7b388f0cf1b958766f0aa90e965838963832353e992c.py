"""Fit-free, explicitly non-deployable headroom/support check on inspected H1.

The oracle uses previously inspected labels solely to establish whether the
restricted correction path has any headroom. It is never a model or a result
that can replace V7. No September or European test arrays are opened.
"""
from pathlib import Path
from datetime import datetime, timezone
import json
import sys
import time

HERE = Path(__file__).resolve().parent
BASE = HERE.parent
TEMP = Path('C:/Users/于阳/CAISO_temporary_storage')
sys.path.insert(0, str(BASE / 'context_expert_v1_20260929'))
import gate


def now():
    return datetime.now(timezone.utc).isoformat()


def main():
    protocol_path = HERE / 'HORIZON_DIAGNOSTIC_PROTOCOL.json'
    result_path = HERE / 'HORIZON_FEASIBILITY.json'
    if result_path.exists():
        raise RuntimeError('Completed diagnostic exists; do not rerun silently')
    v20 = gate.read(BASE / 'retention_diagnosis_v20_20260930/PROTOCOL.json')
    p_panel = TEMP / 'adaptive_experts_v4_20260929/panel.npz'
    p_folds = BASE / 'adaptive_experts_v4_20260929/FOLDS.json'
    p_results = BASE / 'mechanism_repair_v18_20260930/CAISO_MATCHED_RESULTS.json'
    records = gate.read(p_results)['rows']
    paths = [p_panel, p_folds, p_results, Path(__file__), HERE / 'horizon_route.py']
    for row in records:
        paths.append(TEMP / 'mechanism_repair_v18_20260930/CAISO/predictions' /
                     f"{row['seed']}_{row['anchor']}.npz")
    for p in paths[:-2]:
        if str(p) in v20['bindings'] and gate.sha(p) != v20['bindings'][str(p)]:
            raise RuntimeError('Old diagnostic binding changed: ' + str(p))
    protocol = dict(at=now(), status='registered_before_array_read',
        scope='Previously inspected H1 development: 698 origins,42 UTC dates,30nodes,12horizons,3seeds,3matched corrected anchors',
        purpose='Restricted-path oracle headroom and chronological feedback availability; no model fit',
        oracle='For mutable cells only, clip(y, min(anchor,retained), max(anchor,retained)). Uses truth; unattainable performance bound, not a deployable prediction or acceptance result.',
        support='Existing3fold cutoffs,2UTCday purge,final-label availability strictly before cutoff; reserve latest6 eligible dates for calibration; at least10 earlier fit dates required for proposed feasibility check.',
        metadata_only_support_thresholds=True, no_new_source_admission_asserted=True,
        fits=0, new_test_targets_read=False, budget_seconds=120,
        bindings={str(p):gate.sha(p) for p in paths})
    if protocol_path.exists():
        previous=gate.read(protocol_path)
        if previous['bindings'] != protocol['bindings']:
            raise RuntimeError('Registered diagnostic changed; require repair record')
    else:
        gate.write(protocol_path, protocol)
    protected = gate.read(HERE / 'RETAINED_BASELINE_HASHES.json')['files']
    for p, h in protected.items():
        if gate.sha(p) != h:
            raise RuntimeError('Protected artifact changed: ' + p)
    with gate.exclusive('V21 fit-free horizon headroom and prior-date support'):
        start = time.monotonic()
        np, limiter = gate.runtime(False)
        from horizon_route import apply_reversion, mutable_region
        # Nontrivial operator invariants, including signed-zero preservation.
        r = np.arange(72, dtype=float).reshape(2,3,12)
        r[0,0,0] = -0.0
        a = r + np.array([-4.,5.])[:,None,None]
        low = np.array([[True,False,False],[False,True,False]])
        mask = mutable_region(r,a,low)
        z = apply_reversion(r,a,np.full_like(r,.5),low)
        assert z[~mask].tobytes()==r[~mask].tobytes()
        assert np.allclose(z[mask], (r[mask]+a[mask])/2)
        assert apply_reversion(r,a,np.zeros_like(r),low).tobytes()==r.tobytes()
        z1=apply_reversion(r,a,np.ones_like(r),low)
        assert z1[mask].tobytes()==a[mask].tobytes()
        rejection_checks=0
        for bad in (np.full_like(r,-.1),np.full_like(r,1.1),np.full_like(r,np.nan)):
            try: apply_reversion(r,a,bad,low)
            except ValueError: rejection_checks+=1
        assert rejection_checks==3
        with np.load(p_panel,allow_pickle=False) as z:
            data={k:z[k] for k in ('origins','truth','days','available','low_volatility')}
        folds=gate.read(p_folds)
        output=[]
        for rec in records:
            gate.guard()
            if time.monotonic()-start>120: raise TimeoutError('Fixed diagnostic budget')
            p=TEMP/'mechanism_repair_v18_20260930/CAISO/predictions'/f"{rec['seed']}_{rec['anchor']}.npz"
            assert gate.sha(p)==rec['prediction_sha256']==protocol['bindings'][str(p)]
            with np.load(p,allow_pickle=False) as z:
                retained=z['prediction'];anchor=z['anchor'];ids=z['indices'];orig=z['origins']
            assert np.array_equal(orig,data['origins'][ids])
            y=data['truth'][ids];low=data['low_volatility'][ids]
            mask=mutable_region(retained,anchor,low)
            oracle=retained.copy()
            oracle[mask]=np.clip(y[mask],np.minimum(anchor[mask],retained[mask]),np.maximum(anchor[mask],retained[mask]))
            weights=np.zeros_like(retained)
            np.divide(retained-oracle,retained-anchor,out=weights,where=mask)
            weights=np.clip(weights,0,1)
            reconstructed=apply_reversion(retained,anchor,weights,low)
            assert np.allclose(reconstructed,oracle,rtol=0,atol=1e-10)
            assert reconstructed[~mask].tobytes()==retained[~mask].tobytes()
            # Independently scalar-check the closest point on each allowed segment.
            eligible=np.argwhere(mask)
            for index in eligible[::max(1,len(eligible)//50)]:
                q=tuple(index);lo=min(float(anchor[q]),float(retained[q]));hi=max(float(anchor[q]),float(retained[q]))
                assert abs(float(oracle[q])-max(lo,min(hi,float(y[q]))))<1e-10
            e=retained-y;o=oracle-y
            assert np.all(abs(o)<=abs(e)+1e-10)
            metrics=lambda err:dict(mae=float(abs(err).mean()),rmse=float(np.sqrt(np.square(err).mean())),h12_mae=float(abs(err[...,11]).mean()))
            m=metrics(e);bound=metrics(o)
            assert abs(m['mae']-rec['corrected']['mae'])<1e-10
            availability=data['available'][ids].max(axis=1)
            days=data['days'][ids]
            support=[]
            for f in folds:
                evalmask=np.isin(ids,f['evaluation'])
                cutoff=int(orig[evalmask].min())
                old=(orig+3900<cutoff-2*86400)&(availability<cutoff)
                dates=np.unique(days[old]);caldates=dates[-6:]
                cal=old&np.isin(days,caldates);fit=old&~np.isin(days,caldates)
                fit_dates=int(len(np.unique(days[fit])));cal_dates=int(len(np.unique(days[cal])))
                active_date=lambda sel:int(len(np.unique(days[sel & mask.any(axis=(1,2))])))
                support.append(dict(fold=f['id'],cutoff_utc=datetime.fromtimestamp(cutoff,timezone.utc).isoformat(),
                    earlier_compatible_origins=int(old.sum()),fit_dates=fit_dates,calibration_dates=cal_dates,
                    fit_mutable_dates=active_date(fit),calibration_mutable_dates=active_date(cal),
                    fit_mutable_cells=int(mask[fit].sum()),calibration_mutable_cells=int(mask[cal].sum()),
                    evaluation_origins=int(evalmask.sum()),metadata_support_at_least10fit6cal=fit_dates>=10 and cal_dates>=6))
            output.append(dict(seed=rec['seed'],anchor=rec['anchor'],baseline=m,
                NON_DEPLOYABLE_oracle_lower_bound=bound,
                max_possible_mae_reduction_percent=100*(m['mae']-bound['mae'])/m['mae'],
                mutable_cells=int(mask.sum()),total_cells=int(mask.size),
                protected_fraction=float((~mask).mean()),chronological_support=support))
        for p,h in protected.items(): assert gate.sha(p)==h,p
        result=dict(at=now(),status='fit_free_headroom_and_support_checks_complete',
            protocol_sha256=gate.sha(protocol_path),rows=output,
            numerical_checks='Direct metric replay, scalar closest-point checks, all-cell non-worsening oracle bound, byte-exact protected outputs, invalid-weight rejection',
            interpretation='Oracle is not learnable performance evidence; support counts cannot replace causal replay or calibration. No fitted candidate and no new model accuracy result.',
            independent_person_audit=False,new_fits=0,new_test_targets_read=False,
            protected_files_unchanged=len(protected),seconds=time.monotonic()-start)
        gate.write(result_path,result)
        print(json.dumps(dict(status=result['status'],cases=len(output),new_fits=0,seconds=result['seconds'])))


if __name__=='__main__':
    main()
