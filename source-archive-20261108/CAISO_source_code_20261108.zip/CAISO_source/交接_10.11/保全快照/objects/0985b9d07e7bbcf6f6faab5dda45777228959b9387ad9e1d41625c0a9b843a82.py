from pathlib import Path
import json,csv,re
from docx import Document
from docx.shared import Inches,Pt,RGBColor
from docx.oxml import OxmlElement
from docx.oxml.ns import qn
from docx.enum.text import WD_ALIGN_PARAGRAPH
from docx.enum.table import WD_TABLE_ALIGNMENT,WD_CELL_VERTICAL_ALIGNMENT
R=Path(__file__).resolve().parent
def read(p):return json.loads((R/p).read_text(encoding='utf-8-sig'))
doc=Document();sec=doc.sections[0];sec.page_width=Inches(8.5);sec.page_height=Inches(11)
sec.top_margin=sec.bottom_margin=Inches(.7);sec.left_margin=sec.right_margin=Inches(.75)
for name in ['Normal','Title','Heading 1','Heading 2','Caption']:
 s=doc.styles[name];s.font.name='Times New Roman';s._element.get_or_add_rPr().rFonts.set(qn('w:eastAsia'),'宋体');s.font.color.rgb=RGBColor(0,0,0)
 s.font.size=Pt(11 if name=='Normal' else 19 if name=='Title' else 13 if name=='Heading 1' else 10)
 s.paragraph_format.space_after=Pt(6);s.paragraph_format.line_spacing=1.16
doc.styles['Normal'].paragraph_format.widow_control=True
for style in doc.styles:
 for border in list(style._element.iter(qn('w:pBdr'))):border.getparent().remove(border)
def p(text,style=None):
 para=doc.add_paragraph(style=style)
 if text.startswith('['):para.add_run(text)
 else:
  for part in re.split(r'(\[\d+\])',text):
   run=para.add_run(part)
   if re.fullmatch(r'\[\d+\]',part):run.font.superscript=True
 return para
def h(text):return doc.add_heading(text,level=1)
def page(title):doc.add_page_break();h(title)
def table(headers,rows,widths):
 t=doc.add_table(rows=1,cols=len(headers));t.alignment=WD_TABLE_ALIGNMENT.CENTER;t.autofit=False
 for i,x in enumerate(headers):t.rows[0].cells[i].text=x
 rep=OxmlElement('w:tblHeader');t.rows[0]._tr.get_or_add_trPr().append(rep)
 for row in rows:
  cells=t.add_row().cells
  for c,v in zip(cells,row):c.text=str(v)
 for j,row in enumerate(t.rows):
  for i,c in enumerate(row.cells):
   c.width=Inches(widths[i]);c.vertical_alignment=WD_CELL_VERTICAL_ALIGNMENT.CENTER
   props=c._tc.get_or_add_tcPr();borders=OxmlElement('w:tcBorders')
   for side in ['top','left','bottom','right']:
    el=OxmlElement('w:'+side);el.set(qn('w:val'),'single');el.set(qn('w:sz'),'4');el.set(qn('w:color'),'D9D9D9');borders.append(el)
   props.append(borders);m=OxmlElement('w:tcMar')
   for side in ['top','bottom','left','right']:
    el=OxmlElement('w:'+side);el.set(qn('w:w'),'70');el.set(qn('w:type'),'dxa');m.append(el)
   props.append(m)
   if j==0:
    shade=OxmlElement('w:shd');shade.set(qn('w:fill'),'E8EEF4');props.append(shade)
   for para in c.paragraphs:
    para.paragraph_format.space_after=Pt(2);para.paragraph_format.line_spacing=1.02
    for run in para.runs:run.font.size=Pt(9);run.bold=j==0
 p('')
 return t
def fig(name,width,caption):
 doc.add_picture(str(R/'figures'/name),width=Inches(width));doc.paragraphs[-1].alignment=WD_ALIGN_PARAGRAPH.CENTER;p(caption,'Caption')
foot=sec.footer.paragraphs[0];foot.alignment=WD_ALIGN_PARAGRAPH.CENTER
foot.add_run('CAISO与欧洲电价预测研究修订  |  ')
fld=OxmlElement('w:fldSimple');fld.set(qn('w:instr'),'PAGE');foot._p.append(fld)
p('老师意见修订第一批实验结果','Title');p('2026年10月3日  供研究讨论与论文修订使用')
p('本轮已完成输入信息核验、V7组件对照、尖峰片段分析，以及保留原点预测的概率区间试验。新增概率模型在两个开发任务的综合区间评分上取得改善；V7模型、原论文和历史结果均完整保留。本报告汇总实际完成的结果，并区分仍需补齐的匹配训练与独立确认。')
table(['老师关注的问题','本轮完成内容','当前判断'],[
 ['动态图收益不稳定','按预测前历史波动划分欧洲开发样本，完整比较FULL、STATIC和SELF','收益随情境和指标变化，尚未建立普遍优势'],
 ['外部基线输入不同','逐字段核验29维输入，重建iTransformer输入后与FULL逐值一致','iTransformer可比；DLinear和LASSO仍需独立的信息匹配组'],
 ['V7缺少组件消融','汇总12种模型或控制；新增4个输出干预和2个针对性组件对照','模块作用已量化，不能宣称所有模块对所有指标均有益'],
 ['尖峰分析不足','拆分状态、价格符号及连续观测片段，核对V7触发条件','突发尖峰与已观测尖峰必须分别处理'],
 ['缺少概率预测','30个固定分位数模型，3种子×2任务×5分位数，4种区间方案','开发阶段通过WIS筛选，尚待独立确认']],[1.35,2.8,2.85])
h('本轮采用的文献路径')
p('公平比较沿用Lago等的电价预测评估框架[1]。概率预测参考Marcjasz等对电价条件分布的建模方向[2]，并结合条件分位数校准[3]和时间序列残差预测思想[4]。本次实现采用固定的梯度提升分位数模型，并未复现文献中的全部神经网络或在线SPCI算法。')
p('尖峰诊断区分“是否发生”和“发生后的演化”，参考Christensen等的条件风险思路[5]。不同预测功能与评分目标需分别评价，依据Gneiting的点预测理论[6]。上述论文提供方法依据，不保证本任务的改进幅度。')
page('概率预测开发结果')
prob=read('PROBABILITY_RESULT.json')['summary'];rows=[]
for task in ['CAISO','Europe']:
 for model in ['HIST','HIST_CAL','CQR_RAW','CQR_CAL']:
  r=prob[task]['scores'][model];rows.append([task,model,f'{r["wis"]:.4f}',f'{100*r["coverage80"]:.2f}%',f'{100*r["coverage90"]:.2f}%',f'{r["width90"]:.2f}'])
p('CAISO采用既有开发序列的前245个起点拟合、随后259个起点校准、最后194个起点评价；最后一段覆盖16个UTC日期。两处边界按真实反馈可用时间剔除尚未成熟的标签，共排除120个节点—预测期单元。欧洲采用2015年1—6月拟合、7—9月校准、10—12月92天评价，并在前两段边界各清除一个交付日。欧洲骨干曾使用2015年作验证，因此这里是开发分析。')
table(['任务','方案','WIS ↓','80%覆盖率','90%覆盖率','90%宽度'],rows,[.65,1.2,.8,1.05,1.05,1.05])
p('HIST为按节点和预测期估计的历史残差分位数；HIST_CAL接受同样的校准预算；CQR_RAW为条件残差分位数；CQR_CAL为校准后的候选。WIS同时衡量区间宽度与漏覆盖损失，越低越好；CAISO单位为USD/MWh，欧洲为EUR/MWh，不合并误差。')
fig('probability_coverage.png',6.8,'图R1  两个开发任务的区间覆盖率，均为三个种子的平均值。')
p('相对于HIST_CAL，候选在CAISO和欧洲的WIS分别下降8.70%和1.41%，两项任务的三个种子方向一致。CAISO区间更宽但漏覆盖损失减少；欧洲总体区间宽度接近。CAISO的80%区间覆盖率仍为77.92%。这些结果不构成新的独立测试或显著性结论。')
p('概率层与点预测层分离：全部已交付的V7点预测逐项完全一致，欧洲FULL点预测也未改变。分布的中位数作为单独输出保存，不冒充原V7点预测。')
page('V7组件作用与取舍')
ss=read('V7_REFIT_AUDIT.json')['summary'];rows=[]
for name,r in ss.items():rows.append([name,*[f'{r[k]:.4f}' for k in ['mae','rmse','near_mae','h12_mae']]])
p('下表全部使用同一698起点、42个UTC日期、30节点、12步的既有开发面板，报告三个种子的指标均值。近端指5—20分钟，H12指60分钟；单位为USD/MWh。')
table(['模型或控制','MAE','RMSE','近端MAE','H12 MAE'],rows,[2.5,1.02,1.02,1.02,1.02])
p('CONTEXT为保留的V7；BASE移除新增极端专家；DURATION移除额外压力轨迹但保留持续时间与原有价格特征；CONTEXT_FIXED使用固定目的状态概率；CONTEXT_HULL使用原专家凸组合约束。NO_ROUTINE取消常规情境修正。MEAN_ONLY、MEDIAN_ONLY和NO_ANCHOR分别检查条件均值、条件中位数及0.75锚定系数。')
p('NO_DURATION_FEATURES从相同训练集重新拟合，移除显式持续时间、占用比例和峰值时距等汇总量，保留其他价格与上下文信息；无法据此声称消除了所有可间接推断持续时间的信息。NO_TEMPERATURE仅移除后处理温度校准，树模型保持一致。')
p('温度校准移除后总体MAE降至7.5439、RMSE降至40.7690，但S3恢复期和S4仍有回退，因此未替换V7。这一发现支持进一步检查“校准所优化的分类对数损失”和最终点预测评分之间的关系，而不支持继续任意增加模块。')
p('上述输出干预、重新拟合和既有匹配对照在表中按各自定义解释，不作为完全正交的因果贡献。原V7完整推理路径已逐值重放一致。')
page('尖峰与动态图诊断')
fig('probability_state_diagnostics.png',6.8,'图R2  按实现后的价格状态分组的概率预测诊断。该分组用于评价，不进入预测输入，也不享有逐组90%覆盖保证。')
p('CAISO六种实现后状态的WIS均优于HIST_CAL；S3下降约34.45%，S2和S5分别下降约3.84%和5.36%。但S2、S5的90%区间覆盖率分别只有7.01%和16.34%。按未来结果筛选的极端组不能直接用标称覆盖率判定理论失效，但这些数据明确说明本轮区间尚不能可靠包住已发生的极端幅度。')
p('已输出H1和H12的145、166个连续极端观测片段（每种子）。样本中存在日期与时刻断档，因此它们只是观测片段，不能当成145、166个独立完整事件。V7专家只在起点已极端时触发，S2突发尖峰仍由常规路径预测。')
fig('graph_regime_diagnostics.png',6.8,'图R3  使用训练期确定的过去一周价格波动三分位阈值划分欧洲2015开发起点。所有图方案均保留。')
p('高波动组FULL的MAE略低于STATIC、SELF，但RMSE仍未更优；中等波动组SELF更低。三个市场之间的图是统计关联，不是已知物理拓扑；k=2保留全部非自身候选边。因此不能把本次发现解释成“稀疏化已解决图问题”，也不能把节点数单独认定为原因。')
page('后续工作和论文落点')
table(['顺序','具体工作','完成条件'],[
 ['1','整理公平信息表，分开历史价格组与完整信息组；价格组补FULL、iTransformer和LASSO匹配训练，DLinear仅在设置完全一致时复用','相同起点、历史跨度、价格可用版本、预算和统计评价；不能只在测试时将输入置零'],
 ['2','保留本轮12项V7组件表和尖峰片段表；将概率模型作为不改变点预测的新增风险输出','完整保留逐种子、逐节点、逐预测期与逐状态文件'],
 ['3','补齐新独立确认面板的来源与发布时间准入，再冻结概率层与公平比较方案','现有H1、九月及欧洲2016结果不能重新充当未见测试；欧洲2017尚未完成准入'],
 ['4','针对S2先检查预测前可用信号是否提供额外识别能力；只有通过该检查才登记单一发生风险模型','必须优于训练基率/历史状态对照，并有足够独立日期；不按已实现状态路由'],
 ['5','动态图新增复杂度仅作为有独立证据后的候选，例如受约束的静态加动态残差','STATIC与SELF匹配消融保留；验证整体与局部代价，不能宣称下限天然有保证']],[.45,3.65,2.9])
p('论文中可将公平输入说明放入实验设置，将V7拆解放入组件分析，将概率结果放入独立的小节。新开发结果以对应的开发范围明确标识，不替换已冻结独立测试表；独立确认完成后再决定是否纳入主结果。老师修订稿中的“five-to-six-minute”应核对并恢复为“five-to-sixty-minute”，与实际12步任务一致。')
p('本轮完成了30个分位数拟合和6个持续时间消融分类器拟合，均为固定设置；没有搜索学习率、阈值或网络深度。独立评分代码复算1,068条概率结果，最大数值差约3.64×10⁻¹²；18个保护文件哈希检查一致。未启动新的骨干训练、未读取新测试目标、未恢复定时唤醒。')
h('主要参考文献')
refs=[
 '[1] Lago J, et al. Applied Energy 2021;293:116983. https://doi.org/10.1016/j.apenergy.2021.116983',
 '[2] Marcjasz G, et al. Distributional neural networks for electricity price forecasting. Energy Economics 2023;125:106843. https://doi.org/10.1016/j.eneco.2023.106843',
 '[3] Romano Y, Patterson E, Candès EJ. Conformalized Quantile Regression. NeurIPS 2019. https://proceedings.neurips.cc/paper/2019/file/5103c3584b063c431bd1268e9b5e76fb-Paper.pdf',
 '[4] Xu C, Xie Y. Sequential Predictive Conformal Inference for Time Series. ICML 2023;202:38707–38727. https://proceedings.mlr.press/v202/xu23r.html',
 '[5] Christensen TM, Hurn AS, Lindsay KA. Forecasting spikes in electricity prices. International Journal of Forecasting 2012;28:400–411. https://doi.org/10.1016/j.ijforecast.2011.02.019',
 '[6] Gneiting T. Making and evaluating point forecasts. JASA 2011;106:746–762. https://doi.org/10.1198/jasa.2011.r10138']
for text in refs:
 pp=p(text);pp.paragraph_format.line_spacing=1.0;pp.paragraph_format.space_after=Pt(4)
 for run in pp.runs:run.font.size=Pt(9)
out=R/'老师意见修订第一批结果.docx';doc.save(out)
(R/'老师意见修订第一批结果.txt').write_text('\n\n'.join(x.text for x in doc.paragraphs)+'\n\n全部表格见同目录CSV及Word报告。',encoding='utf-8')
print(out)
