"""Original QUERY/CONTROL numerical formulas, isolated from all old data and paths."""
import numpy as np
import torch

TASKS=tuple((year,group,metric) for year in (2023,2024,2025) for group in (3,4,5) for metric in ('mae','mse','near','h12'))

def require(ok, message):
    if not bool(ok):
        raise RuntimeError(message)


def tensors(cache, sl):
    return (torch.tensor(np.array(cache['z'][sl]), dtype=torch.float32), torch.tensor(np.array(cache['mask'][sl])),
            torch.tensor(np.array(cache['age'][sl]), dtype=torch.float32), torch.tensor(np.array(cache['cov'][sl]), dtype=torch.float32))


def predict(model, cache):
    pred, pos = np.array(cache['baseline'], copy=True), 0
    scale = np.asarray(cache['metadata']['scale'])[None, :, None]
    center = np.asarray(cache['metadata']['center'])[None, :, None]
    with torch.inference_mode():
        for size in cache['sizes']:
            size = int(size)
            sl = slice(pos, pos+size)
            if cache['mask'][sl].any():
                pred[sl] = model(*tensors(cache, sl)).numpy().astype(np.float64)*scale+center
            pos += size
    require(pos == len(pred), 'Original prediction batch coverage')
    ordinary = np.broadcast_to(~cache['mask'][:, :, None], pred.shape)
    require(np.array_equal(pred[ordinary], cache['baseline'][ordinary]), 'Ordinary prediction changed')
    return pred


def masks(cache):
    for year, group, metric in TASKS:
        mask = (np.asarray(cache['codes']) == group) & (cache['years'] == year)[:, None, None]
        if metric == 'near':
            mask[:, :, 4:] = False
        if metric == 'h12':
            mask[:, :, :11] = False
        weights = mask*cache['multiplicity'][:, None, None]
        count = weights.sum(dtype=np.float64)
        require(count > 0, 'Empty TRAIN risk task')
        yield metric, weights, count


def losses(pred, cache):
    error = pred-cache['truth']
    return np.array([float(((error**2 if metric == 'mse' else abs(error))*weights).sum()/count)
                     for metric, weights, count in masks(cache)])


def metric(pred, truth):
    error = pred-truth
    horizon = abs(error).mean((0, 1))
    return dict(mae=float(abs(error).mean()), rmse=float(np.sqrt((error**2).mean())),
                h12_mae=float(horizon[-1]), near_h1_4_mae=float(horizon[:4].mean()), mae_by_horizon=horizon.tolist())


def update_q(q, risk, initial):
    value = np.log(q)+.1*np.asarray(risk)/np.asarray(initial)
    value -= value.max()
    value = np.exp(value)
    value /= value.sum()
    require(np.isfinite(value).all() and (value > 0).all(), 'Invalid DRO weights')
    return value


def backward(model, cache, q, initial, anchor):
    params = list(model.adapter.parameters())
    model.zero_grad(set_to_none=True)
    tasks = list(masks(cache))
    scale = torch.tensor(cache['metadata']['scale'], dtype=torch.float64)[None, :, None]
    center = torch.tensor(cache['metadata']['center'], dtype=torch.float64)[None, :, None]
    values = np.zeros(36)
    for index in range(0, len(cache['z']), 32):
        sl = slice(index, index+32)
        pred = model(*tensors(cache, sl)).double()*scale+center
        error = pred-torch.tensor(np.array(cache['truth'][sl]), dtype=torch.float64)
        loss = pred.sum()*0
        for k, (name, weights, count) in enumerate(tasks):
            term = ((error.square() if name == 'mse' else error.abs())*torch.tensor(weights[sl], dtype=torch.float64)).sum()/count
            values[k] += float(term.detach())
            loss = loss+term*(q[k]/initial[k])
        loss.backward()
    reg = .001*sum((param-start).square().sum() for param, start in zip(params, anchor))
    reg.backward()
    require(all(param.grad is not None and torch.isfinite(param.grad).all() for param in params), 'Nonfinite/missing QUERY gradient')
    return values, float(reg.detach()), np.concatenate([param.grad.numpy().ravel() for param in params])
