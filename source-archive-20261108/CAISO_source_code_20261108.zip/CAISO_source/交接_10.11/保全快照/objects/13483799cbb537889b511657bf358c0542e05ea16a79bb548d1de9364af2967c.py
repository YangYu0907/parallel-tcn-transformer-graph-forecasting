from pathlib import Path
import sys, os, json, pickle, uuid, time, shutil
HERE=Path(__file__).resolve().parent; B=HERE.parent
T=B/'context_expert_v1_20260929'; V7=B/'spike_specialist_v7_20260930'
sys.path.insert(1,str(T));import gate
ART=Path('C:/Users/于阳/CAISO_temporary_storage/risk_likelihood_v10_20260930')
A7=ART.parent/'spike_specialist_v7_20260930';A5=ART.parent/'adaptive_experts_v5_20260929';A4=ART.parent/'adaptive_experts_v4_20260929'
SEEDS=[20260813,20260814,20260815];ARMS=['V7','HAZARD_ONLY','POST_ONLY','LIKELIHOOD']
_start=None;_used=0.
def atomic(path,writer):
    path=Path(path);assert any(path.resolve().is_relative_to(r.resolve()) for r in (HERE,ART))
    path.parent.mkdir(parents=True,exist_ok=True)
    if shutil.disk_usage(path.parent).free<32*1024**2:raise OSError('Disk safety floor32MiB')
    tmp=path.with_name('.'+path.name+'.'+uuid.uuid4().hex+'.tmp')
    with tmp.open('xb') as f:writer(f);f.flush();os.fsync(f.fileno())
    for attempt in range(7):
        try:os.replace(tmp,path);break
        except OSError as exc:
            if getattr(exc,'winerror',None) not in (5,32,33) or attempt==6:raise
            time.sleep(.1*2**attempt)
def write(path,obj):atomic(path,lambda f:f.write(json.dumps(obj,ensure_ascii=False,indent=2,allow_nan=False).encode('utf-8')))
def save(path,**kw):
    import numpy as np
    atomic(path,lambda f:np.savez(f,**kw))
def dump(path,obj):atomic(path,lambda f:pickle.dump(obj,f,protocol=5))
def load(path):
    with Path(path).open('rb') as f:return pickle.load(f)
def status(**kw):write(HERE/'queue/status.json',dict(at=gate.now(),pid=os.getpid(),**kw))
def tick(**kw):
    for d in (HERE,HERE/'queue'):
        for n in ('STOP_REQUESTED','STOP_REQUESTED.json'):
            if (d/n).exists():raise InterruptedError('User stop '+str(d/n))
    gate.guard()
    if _start is not None:
        used=_used+time.monotonic()-_start;write(HERE/'queue/budget.json',dict(used_seconds=used,maximum_seconds=3600,at=gate.now()))
        if used>=3600:raise TimeoutError('Fixed one-hour numerical budget')
    if kw:status(event='step_process_started',**kw)
def start_budget():
    global _start,_used
    _used=gate.read(HERE/'queue/budget.json')['used_seconds'] if (HERE/'queue/budget.json').exists() else 0.;_start=time.monotonic()
def verify():
    for p,h in gate.read(HERE/'EXECUTION_SEAL.json')['bindings'].items():assert gate.sha(p)==h,p
    assert gate.read(HERE/'QA.json')['status']=='passed';tick()

