"""Register a no-total-time-budget continuation without changing scientific scope."""
import json, hashlib, os, ast
from pathlib import Path
from datetime import datetime,timezone
import manager as m
U=m.W;Z=m.s.N;P=Z/'mirror_proof_20261007';S=P/'resume3';W=Z/'native_full_run_20261007'
read=m.s.read;sha=m.s.sha
def write(name,data):m.write(name,data)
def main():
    parent=m.s.verify()
    policy=read(Z/'USER_TIME_POLICY_20261008.json')
    assert policy['time_budget'] is None and policy['time_limit_stop_enabled'] is False
    result=read(S/'RESULT.json')
    assert result['cycles']==32 and result['byte_and_value_gate_passed']
    choices=read(P/'PROTOCOL.json')['choices'];assert {r['cycle'] for r in result['rows']}=={c['cycle'] for c in choices}
    fields=0;receipts=0;headers=0
    for row in result['rows']:
        cycle=row['cycle'];path=P/'cycles'/f'{cycle}.json';r=read(path);old=read(Z/'cycles'/path.name)
        assert sha(path)==row['mirror_record_sha256']
        assert r['choice']==old['choice']
        for key in ['center_values','patch_means','geometry']:assert r[key]==old[key]
        refs={(x['key'],tuple(x.get('range',[]))):x['sha256'] for x in old['receipts']}
        manifests=[S/'released'/path.name,P/'resume2/released'/path.name,P/'released'/path.name]
        release=read(next(f for f in manifests if f.exists()))
        assert release['record_sha256']==sha(path)
        releases={str(Path(x['path']).resolve()):x['sha256'] for x in release['verified_files']}
        for receipt in r['receipts']:
            assert receipt['sha256']==refs[(receipt['key'],tuple(receipt.get('range',[])))]
            if receipt.get('local'):assert sha(Z/receipt['local'])==receipt['sha256']
            else:assert releases[str((Z/receipt['temporary_source_fragment']).resolve())]==receipt['sha256']
            if receipt.get('native_response_headers'):
                h=receipt['native_response_headers'];meta=receipt['source']
                assert h['etag']==meta['etag']
                assert m.nt.parsedate_to_datetime(h['last-modified']).timestamp()<=r['choice']['minimum_qualified_cutoff']
                left,right=receipt['range'];assert h['content-range']==f'bytes {left}-{right}/{meta["bytes"]}'
                headers+=1
            receipts+=1
        fields+=528
    write('MIRROR_REVIEW.json',dict(at=m.s.now(),passed=True,cycles=32,weather_values=fields,receipt_sha_checks=receipts,
        mirror_header_checks=headers,result_sha256=sha(S/'RESULT.json'),
        scope='Separate-script exact payload/hash/header/value replay, not independent-person review or model-accuracy evidence',
        active_source_seconds=result['active_seconds'],projected_remaining_hours=result['projected_remaining_hours'],time_limit_stop_enabled=False))
    cp=read(W/'CHECKPOINT.json')['cycle_hashes'];assert len(cp)==85
    actual=list((Z/'cycles').glob('*.json'));assert len(actual)==85
    hashes={};choicesall=read(Z/'SELECTION.json');allmap={c['cycle']:c for c in choicesall['pilot']+choicesall['remaining']}
    retained=released=0
    for f in actual:
        cycle=int(f.stem);assert sha(f)==cp[str(cycle)];r=read(f)
        assert r['choice']==allmap[cycle] and len(r['rows'])==24
        assert r['source_available_by']<=r['choice']['minimum_qualified_cutoff']
        for x in r['receipts']:
            if x.get('local'):assert sha(Z/x['local'])==x['sha256'];retained+=1
            elif x.get('temporary_source_fragment'):
                raw=(Z/x['temporary_source_fragment']).resolve()
                manifest=raw.parent.parent.parent/'released_payloads'/f.name
                assert manifest.resolve().is_relative_to(Z.resolve())
                proof=read(manifest)
                assert proof['cycle_sha256']==sha(f) and any(a['sha256']==x['sha256'] for a in proof['files'])
                released+=1
        hashes[str(f)]=sha(f)
    write('RESUME_MANIFEST.json',dict(at=m.s.now(),cycle_hashes=hashes,protected_source_checkpoint=sha(W/'CHECKPOINT.json')))
    write('RESUME_AUDIT.json',dict(at=m.s.now(),passed=True,cycles=85,retained_hashes_checked=retained,released_manifest_checks=released,
        model_fits=0,new_test_targets_read=False,scope='Source/checkpoint recovery only'))
    q=dict(read(W/'PROTOCOL.json'))
    q.update(at=m.s.now(),status='registered_explicit_user_no_total_time_budget',authorization=policy,
        time_budget=None,time_limit_stop_enabled=False,deadline_unix=None,total_deadline_unix=None,
        resume_cycles=85,inherited_counters=result['counters'],
        timing='ETA advisory only; continue finite5286source panel irrespective of projected elapsed hours',
        source_cost_gate='No time-based stop. Periodic local ETA file, no scheduled model wakeups.',
        source_transport='Original AWS indexes; primary NOAA-listed GCP payloads with exact original object checksum/cutoff; at most1original AWS fallback with unchanged identity;2attempts total',
        mirror_proof=str(U/'MIRROR_REVIEW.json'),
        raw_retention='Original85records untouched; release only exact newly-created nonpilot fragments after durable decoding+hash verification',
        automatic_full_restart=False)
    q['bindings']={}
    bind=[U/'manager.py',U/'native_transport.py',U/'qa.py',U/'launch.ps1',U/'register.py',
          U/'QA.json',U/'MIRROR_REVIEW.json',U/'RESUME_MANIFEST.json',U/'RESUME_AUDIT.json',
          Z/'PROTOCOL.json',Z/'USER_TIME_POLICY_20261008.json',Z/'support.py',
          W/'CHECKPOINT.json',S/'RESULT.json']
    for f in bind:q['bindings'][str(f)]=sha(f)
    write('PROTOCOL.json',q)
    for f in [U/'manager.py',U/'native_transport.py']:ast.parse(f.read_text(encoding='utf-8-sig'))
    m.verify();m.s.guard(True)
    raw_bytes=sum(f.stat().st_size for f in Z.rglob('*.grib2'))
    assert raw_bytes<q['maximum_retained_raw_bytes']
    print(json.dumps(dict(registered=True,source_cycles=85,mirror_cycles=32,time_budget=None,
        mirror_projected_remaining_hours=result['projected_remaining_hours'],raw_retained_GiB=raw_bytes/1024**3)))
if __name__=='__main__':main()

