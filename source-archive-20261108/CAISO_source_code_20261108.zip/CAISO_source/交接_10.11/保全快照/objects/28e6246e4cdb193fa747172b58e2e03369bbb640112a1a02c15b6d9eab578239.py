"""One audited runtime-pressure resume, preserving original launch/runtime guards."""
import argparse
import hashlib
import json
import os
import sys
import tempfile
from datetime import datetime, timezone
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
TARGET = "control_backbone_20260814_CONCAT"
HERE = Path(__file__).resolve().parent
PROTOCOL = HERE / "RUNTIME_PRESSURE_CORRECTION.json"
ATTEMPT = HERE / "controlled_resume_attempt.json"

def read(path):
    return json.loads(Path(path).read_text(encoding="utf-8-sig"))

def sha(path):
    h = hashlib.sha256()
    with Path(path).open("rb") as stream:
        for block in iter(lambda: stream.read(65536), b""):
            h.update(block)
    return h.hexdigest()

def matches(command):
    command = [str(x) for x in command]
    def value(flag):
        return command[command.index(flag)+1] if flag in command else None
    return (len(command) >= 3 and Path(command[1]).name == "control_backbone_train.py"
            and command[2] == "run" and value("--seed") == "20260814"
            and value("--variant") == "CONCAT")

def reserve_once(path, payload):
    with Path(path).open("x", encoding="utf-8") as stream:
        json.dump(payload, stream, ensure_ascii=False, indent=2)
        stream.flush()
        os.fsync(stream.fileno())

def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("action", choices=("run", "self-test"))
    parser.add_argument("--queue-source")
    args = parser.parse_args()
    if args.action == "self-test":
        cmd = ["python", str(ROOT/"source/control_backbone_train.py"), "run",
               "--seed", "20260814", "--variant", "CONCAT", "--resume"]
        assert matches(cmd)
        assert not matches([s.replace("20260814", "20260813") for s in cmd])
        assert not matches([s.replace("CONCAT", "EQUAL") for s in cmd])
        assert not matches(["python", "other.py", "run"])
        with tempfile.TemporaryDirectory(dir=HERE) as directory:
            p = Path(directory)/"once.json"
            reserve_once(p, {"trial": 1})
            try:
                reserve_once(p, {"trial": 2})
                raise AssertionError("Duplicate attempt was accepted")
            except FileExistsError:
                pass
            assert read(p) == {"trial": 1}
        print(json.dumps({"status":"passed","checks":6,"model_calls":0,"training_started":False}))
        return 0

    expected = ROOT/"source/post_backbone_queue.py"
    if not args.queue_source or Path(args.queue_source).resolve() != expected.resolve():
        raise RuntimeError("Exact original sealed queue source is required")
    protocol = read(PROTOCOL)
    if protocol["status"] != "reviewed_single_runtime_pressure_resume":
        raise RuntimeError("Reviewed correction protocol required")
    for file, digest in protocol["bound_evidence"].items():
        if sha(ROOT/file) != digest:
            raise RuntimeError("Runtime-pressure evidence changed: "+file)
    stop = read(ROOT/protocol["stop_record"])
    if (stop["status"] != "stopped_at_safe_boundary" or stop["unsaved_updates"] != 0
            or stop["optimizer_steps"] != 2624
            or stop["reason"] != "Backbone requires at least 4 GiB available physical RAM and commit"):
        raise RuntimeError("This correction is restricted to the verified runtime guard")
    sys.path.insert(0, str(ROOT/"source"))
    import post_backbone_queue as original
    import compile_gate
    original_popen = original.subprocess.Popen
    original_event = original.event

    def single_attempt(command, *popen_args, **popen_kwargs):
        if matches(command):
            if "--resume" not in command:
                raise RuntimeError("Only checkpoint resume is authorized")
            latest = read(ROOT/"runs/backbone/20260814_CONCAT/latest.json")
            if latest["steps"] != 2624 or latest["sha256"] != stop["checkpoint"]["sha256"]:
                raise RuntimeError("Unexpected resume cursor")
            if sha(ROOT/latest["path"]) != latest["sha256"]:
                raise RuntimeError("Checkpoint content hash changed")
            capacity = compile_gate.resources()
            if min(capacity["available_physical_GiB"], capacity["available_commit_GiB"]) < 5:
                raise RuntimeError("Original 5 GiB launch guard not met at dispatch")
            reserve_once(ATTEMPT, {"status":"single_resume_reserved","at":datetime.now(timezone.utc).isoformat(),
                         "manager_pid":os.getpid(),"command":[str(x) for x in command],
                         "from_steps":2624,"launch_resources":capacity,
                         "original_runtime_guard_GiB":4,"no_automatic_second_attempt":True})
        return original_popen(command, *popen_args, **popen_kwargs)

    def event(name, **values):
        if name == "known_resource_guard_waiting_with_state_preserved" and values.get("step") == TARGET:
            original_event("step_stopped_or_failed", step=TARGET,
                           classification="controlled_runtime_guard_no_second_attempt",
                           exit_code=values.get("exit_code"), no_automatic_failure_retry=True,
                           retained_stop_evidence=values, correction_protocol=str(PROTOCOL))
            raise RuntimeError("Controlled resume reached its resource guard; state saved, no second automatic attempt")
        return original_event(name, **values)

    original.subprocess.Popen = single_attempt
    original.event = event
    print(json.dumps({"event":"audited_runtime_pressure_correction",
                      "launch_guard_GiB":5,"runtime_guard_GiB":4,
                      "attempt_limit":1,"training_sources_changed":False,
                      "source_sha256":sha(__file__)}), flush=True)
    return original.run()

if __name__ == "__main__":
    sys.exit(main())