"""Synthetic-only independent assertions; no market source or Torch imports."""
import ast
import io
import json
from pathlib import Path
import tempfile
import zipfile
import compile_gate as gate
gate.bound_process()
import numpy as np
import compile_math as cm

def execute():
    checks=[]
    def check(condition,name):
        if not condition: raise AssertionError(name)
        checks.append(name)
    def rejects(call,name):
        try: call()
        except (ValueError,RuntimeError): checks.append(name); return
        raise AssertionError(name)
    with tempfile.TemporaryDirectory(prefix='asof_compiler_synthetic_') as directory:
        folder=Path(directory)
        raw=np.arange(100*3*2,dtype=np.float32).reshape(100,3,2)
        raw[75:]=999999  # Explicit inaccessible tail sentinel.
        np.savez_compressed(folder/'synthetic.npz',values=raw)
        receipt=cm.prefix(folder/'synthetic.npz','values',50,(3,2),folder/'prefix.npy',np.float32,maximum_stop=60)
        got=np.load(folder/'prefix.npy',allow_pickle=False)
        check(np.array_equal(got,raw[:50]),'Bounded prefix equals exact requested rows')
        check(receipt['payload_bytes_requested']==50*3*2*4 and not receipt['data_after_requested_prefix_requested'],
              'Logical raw byte count excludes sentinel tail')
        rejects(lambda:cm.prefix(folder/'synthetic.npz','values',61,(3,2),folder/'bad.npy',np.float32,60),
                'Raw prefix ceiling fails closed')
        rejects(lambda:cm.prefix(folder/'synthetic.npz','values',50,(2,3),folder/'bad.npy',np.float32,60),
                'Unexpected member shape fails closed')
        fortran=np.asfortranarray(raw)
        np.savez(folder/'fortran.npz',values=fortran)
        rejects(lambda:cm.prefix(folder/'fortran.npz','values',50,(3,2),folder/'f.npy',np.float32,60),
                'Fortran array cannot be mistaken for contiguous row prefix')
    values=np.array([1,2,4,7,1e8],np.float32)
    center,scale=cm.fit(values,np.arange(4,dtype=np.int64))
    check(center==3 and scale==3,'Scaler uses only declared TRAIN rows with linear IQR')
    rejects(lambda:cm.fit(np.array([1,np.nan]),np.array([0,1])), 'Nonfinite statistic support rejected')
    source=np.arange(100,dtype=np.float32)**2
    rolling=cm.rolling_std(source,7)
    expected=np.array([np.std(source[i-6:i+1].astype(np.float64)) for i in range(6,100)],np.float32)
    check(np.allclose(rolling[6:],expected,rtol=1e-6,atol=1e-5),'Rolling volatility matches direct windows')
    check(np.isnan(rolling[:6]).all(),'No backfilling initial rolling window')
    anchors=np.array([4320,4356,4392],np.int64)
    qualified=np.arange(4320,4440,dtype=np.int64)
    rows,phases,eligible=cm.phase_schedule(anchors,qualified,4500)
    check(eligible.tolist()==[True,True,False] and rows.shape==(6,3),'Original three-phase anchor rule retained')
    qualified=qualified[qualified!=4332]
    rows,phases,eligible=cm.phase_schedule(anchors,qualified,4500)
    check(not eligible[0] and np.all(rows[:,0]==4320) and np.isin(rows,qualified).all(),
          'Unavailable shifted origin falls back to qualified anchor')
    times=np.arange(10,dtype=np.int64)*300+10000
    publications=np.stack([times-600,times-900],axis=1)
    age=cm.age_at_origin(publications,times,8,[60,60],history=4)
    expected=(times[7]-publications[4:8])/3600
    check(np.array_equal(age,expected.astype(np.float32)),'Forecast age uses actual origin o-1 cutoff')
    bad=publications.copy(); bad[7,0]=times[7]+1
    rejects(lambda:cm.age_at_origin(bad,times,8,[60,60],4),'Future publication rejected')
    bad[7,0]=0
    rejects(lambda:cm.age_at_origin(bad,times,8,[60,60],4),'Unknown publication rejected')
    check(np.all(cm.age_at_origin(np.ones_like(publications),times,8,[1,1],4)==1),'Age caps preserve declared clipping')
    # Exercise the actual batch adapter on isolated synthetic tensors; no manifest admission is bypassed for real data.
    from compiled_data import CompiledData
    with tempfile.TemporaryDirectory(prefix='asof_batch_synthetic_') as directory:
        folder=Path(directory)
        fake=np.ones((310,30,29),np.float32); fake[:,:,19:21]=np.nan
        target=np.arange(310*30,dtype=np.float32).reshape(310,30)
        np.save(folder/'features.npy',fake,allow_pickle=False)
        np.save(folder/'target_scaled.npy',target,allow_pickle=False)
        fixture=object.__new__(CompiledData)
        fixture.paths={'features.npy':folder/'features.npy','target_scaled.npy':folder/'target_scaled.npy'}
        fixture.times=np.arange(310,dtype=np.int64)*300+100000
        fixture.publications=np.stack([fixture.times-600,fixture.times-900],axis=1)
        fixture.caps=np.array([120.,1440.]); fixture.origins={'train':np.array([288,294])}
        bx,by=fixture.batch('train',slice(None))
        check(bx.shape==(2,288,30,29) and by.shape==(2,30,12), 'Actual adapter preserves B,T,N,F and B,N,H shapes')
        check(np.isfinite(bx).all(), 'Actual adapter replaces every age sentinel')
        check(np.array_equal(bx[0,:,:,19:21],np.broadcast_to(cm.age_at_origin(fixture.publications,fixture.times,288,fixture.caps)[:,None,:],(288,30,2))), 'Actual adapter age broadcast matches independent origin formula')
        check(np.array_equal(by[1],target[294:306].T), 'Actual adapter target routing is exact')
        check(fixture.batch('train',slice(0,1),False)[1] is None, 'Input-only batch never materializes targets')
        rejects(lambda:fixture.batch('q3',slice(None)), 'TRAIN/June adapter rejects Q3 partition')
        fixture.publications[287,0]=fixture.times[287]+1
        rejects(lambda:fixture.batch('train',slice(0,1)), 'Actual adapter rejects future forecast publication')
    # Both sides of LA daylight saving transition map to the expected local hours.
    stamps=np.array([1710064500,1710065100],np.int64)  # 2024-03-10 09:55 and 10:05 UTC
    cal=cm.calendar(stamps)
    check(np.allclose(cal[:,0],np.sin(2*np.pi*np.array([115,185])/1440).astype(np.float32)),
          'Calendar respects local daylight-saving jump')
    truth=np.array([[[1.,2.,3.]],[[1.,2.,3.]]])
    codes=cm.group_codes(truth,np.array([[2.],[3.]]),np.array([0.]),np.array([[1.],[2.]]))
    check(codes.tolist()==[[[0,1,2]],[[3,4,5]]],'Six state codes retain strict threshold boundaries')
    manifest=dict(publication_collection_complete=True,missing_queries=[],
        status='metadata_qualification_built_pending_source_binding_review',
        issuance_cutoff_rule='timestamps[origin - 1]',research_target_end_exclusive='2025-10-01T00:00:00+00:00')
    audit=dict(status='passed',eligibility_manifest_sha256='a'*64,
        source_value_binding_verified=True,missingness_chain_verified=True,
        complete_publication_coverage_verified=True,asof_information_set_verified=True,
        xml_error_detection_verified=True,unresolved_error_windows=[],
        bound_evidence_metadata_sha256={'synthetic.json':'b'*64},raw_file_identities={'synthetic':{}},
        evidence_basis='complete_publication_no_later_revision_and_source_content_proof')
    check(not gate.validate_evidence(manifest,audit,'a'*64),'Complete synthetic metadata proof admitted for compilation only')
    for key,value in (('status','pending'),('xml_error_detection_verified',False),
                      ('unresolved_error_windows',['1004']),('eligibility_manifest_sha256','c'*64),
                      ('source_value_binding_verified',False)):
        changed=dict(audit,**{key:value})
        check(bool(gate.validate_evidence(manifest,changed,'a'*64)),'Reject missing/stale source proof: '+key)
    changed=dict(manifest,publication_collection_complete=False)
    check(bool(gate.validate_evidence(changed,audit,'a'*64)),'Incomplete publication collection rejected')
    for name in ('compile_gate.py','compile_math.py','compile_dataset.py','compiled_data.py'):
        tree=ast.parse((gate.ROOT/'source'/name).read_text(encoding='utf-8'))
        imports=[item.name for node in ast.walk(tree) for item in
                 (node.names if isinstance(node,(ast.Import,ast.ImportFrom)) else [])]
        check(not any(i=='torch' or i.startswith('forward_') for i in imports),'No Torch/old pipeline import: '+name)
    check('torch' not in __import__('sys').modules,'No Torch imported during numeric QA')
    return dict(status='passed',checks=checks,check_count=len(checks),synthetic_only=True,
                actual_market_data_read=False,actual_data_compiled=False,training_started=False,
                test_2026_targets_read=False,resources=gate.check_working_set(),
                compiler_sources={p.name:gate.sha(p) for p in (gate.ROOT/'source').glob('compile*.py')})

if __name__=='__main__':
    result=execute()
    path=gate.ROOT/'audits'/'compiler_synthetic_qa.json'
    gate.write_new(path,result)
    print(json.dumps(result,ensure_ascii=True))
