"""Save the retention contract and evidence-led next decision; no new fit."""
from preserve_and_diagnose import *
from statistics import mean

p = read(HERE/'PRESERVATION.json')
manifest = read(p['backup_manifest'])
assert sha(p['backup_manifest']) == p['backup_manifest_sha256']
for f in manifest['files']:
    assert sha(f['original']) == f['sha256'], f['original']
    assert sha(f['backup']) == f['sha256'], f['backup']
source = read(V7/'RESULT.json')
assert sha(V7/'RESULT.json') == p['result_sha256']
diag = read(HERE/'FIXED_OUTPUT_DIAGNOSIS.json')
criteria=[]
def add(scope,metric,full,v7):
    criteria.append(dict(scope=scope,metric=metric,FULL=full,V7=v7,
        old_improvement_pct=100*(full-v7)/full,
        existing_direction='positive' if v7<full else ('tie' if v7==full else 'negative'),
        candidate_requirement=('remain_strictly_below_original_FULL' if v7<full else 'improve_vs_V7_with_final_goal_below_FULL')))
for metric in ['mae','rmse','near_mae','h12_mae','low_volatility_mae']:
    add('overall',metric,source['summary']['FULL'][metric],source['summary']['CONTEXT'][metric])
for state in range(6):
    for metric in ['mae','rmse']:
        add('S'+str(state),metric,source['summary']['FULL']['states'][str(state)][metric],source['summary']['CONTEXT']['states'][str(state)][metric])
for kind,ids in [('horizons',['H'+str(h+1) for h in range(12)]),('nodes',[x['node'] for x in diag['node_details']])]:
    for j,label in enumerate(ids):
        for metric in ['mae','rmse']:
            add(label,metric,*[mean(x[kind][j][metric] for x in source['seed_results'] if x['arm']==arm) for arm in ['FULL','CONTEXT']])
guard=dict(at=datetime.now(timezone.utc).isoformat(),status='baseline_contract_saved_not_candidate_pass',
    baseline_result_sha256=p['result_sha256'],baseline_diagnostic_sha256=sha(HERE/'FIXED_OUTPUT_DIAGNOSIS.json'),
    seeds=SEEDS,panel='same698origins42UTCdates30nodes12horizons_development_only',
    exact_input_bindings=diag['input_hashes'],criteria=criteria,
    numerical_comparison_tolerance='Numerical ties are preservation only, not a claimed positive improvement.',
    first_stage='Observed-extreme origins only, determined by unchanged TRAIN threshold. S0/S1/S2 and low-volatility path bitwise identical to V7; never route on future state.',
    aggregate_requirement='Candidate aggregate MAE/RMSE, near-MAE and H12-MAE no worse than V7; low-volatility unchanged in first stage.',
    state_requirement='S3 RMSE improves vsV7; S3 MAE stays belowFULL; S4/S5 MAE/RMSE stay belowFULL; final full-positive acceptance needs S3RMSE belowFULL.',
    node_requirement='All30nodeMAE remain belowFULL;13previouslypositive nodeRMSE remain belowFULL;17regressed nodeRMSE improve towardFULL. No offsetting one node regression with another node gain for this gate.',
    horizon_requirement='All12horizonMAE/RMSE remain belowFULL.',
    inference='Use calendar/event blocks, allseeds and all directions; development gate is not independent confirmation.',
    deploy_requirement='Separate pre-registered untouched data admission plus model/input/panel freeze and one confirmation. No score-conditioned fallback selection after seeing test labels.',
    protected_mean_metric_count=sum(c['existing_direction']=='positive' for c in criteria),
    negative_mean_metric_count=sum(c['existing_direction']=='negative' for c in criteria),
    all_original_artifacts_rehashed=True)
write(HERE/'RETENTION_GATES.json',guard)

sources=[
 dict(title='Making and Evaluating Point Forecasts',authors='Gneiting',year=2011,
      url='https://arxiv.org/abs/0912.0902',journal='Journal of the American Statistical Association',
      basis='Match point functional to scoring objective. Mean/median agreement is not proof of improved realized absolute and squared errors.',access='author abstract'),
 dict(title='FFORMA: Feature-based forecast model averaging',authors='Montero-Manso et al.',year=2020,
      url='https://robjhyndman.com/publications/fforma/',doi='10.1016/j.ijforecast.2019.02.011',journal='International Journal of Forecasting',
      basis='Features determine forecast-combination weights through forecasting loss. Does not guarantee every situation is correctly routed; our signed risk guard is an adaptation.',access='author page and linked manuscript/source excerpts'),
 dict(title='Forecasting spikes in electricity prices',authors='Christensen, Hurn and Lindsay',year=2012,
      url='https://www.sciencedirect.com/science/article/pii/S0169207011000550',doi='10.1016/j.ijforecast.2011.02.019',journal='International Journal of Forecasting',
      basis='Separate discrete-time occurrence hazard for spike arrivals; occurrence probability does not alone give timing across all horizons or amplitude.',access='publisher abstract/introduction excerpt'),
 dict(title='Forecasting the occurrence of extreme electricity prices using a multivariate logistic regression model',year=2022,
      url='https://www.sciencedirect.com/science/article/pii/S0360544222003206',doi='10.1016/j.energy.2022.123417',journal='Energy',
      basis='Load, reserve capacity, renewable proportion and interconnector flow motivate ex-ante supply/stress information. Five CAISO renewable forecasts are not reserves and need independent local verification.',access='publisher indexed abstract'),
 dict(title='A probabilistic forecast methodology for volatile electricity prices in the Australian National Electricity Market',authors='Cornell, Dinh and Pourmousavi',year=2024,
      url='https://doi.org/10.1016/j.ijforecast.2023.12.003',journal='International Journal of Forecasting',
      basis='Uses point and quantile combinations, distinct positive/negative spike treatment and chronological postprocessing. Its spike filtering scope cannot be borrowed to remove our extreme evaluation cases.',access='publisher methodology sections3/6 excerpts'),
 dict(title='Multivariate probabilistic CRPS learning with an application to day-ahead electricity prices',authors='Berrisch and Ziel',year=2024,
      url='https://arxiv.org/abs/2303.10019',doi='10.1016/j.ijforecast.2024.01.005',journal='International Journal of Forecasting',
      basis='Online weights across horizons/quantiles are defensible, but CRPS improvement and asymptotic theory do not imply all-node MAE/RMSE dominance. Not selected as another immediate trial.',access='author abstract and publisher abstract')]
decision=dict(at=guard['at'],status='V7_preserved_diagnosis_complete_no_training_started',
    user_request='Preserve V7, assess remaining weaknesses using theory, retain existing positive results.',
    preservation=str(HERE/'PRESERVATION.json'),diagnosis=str(HERE/'FIXED_OUTPUT_DIAGNOSIS.json'),gates=str(HERE/'RETENTION_GATES.json'),
    facts=dict(node_regressions=diag['summary'],
        S3_top_origin_added_sse_share=[next(s for s in x['state_diagnostics'] if s['state']==3)['top_origin_added_sse_share'] for x in diag['seed_details']],
        S5_five_node_failure='All addedS5SSE at the five S5-dominant regressed nodes is underprediction caused by a downward correction. This is a decomposition, not physical causality.',
        S2_domain='The V7 spike specialist only acts at already-extreme origins. Its nonextreme path is exactlyV6; its added hazard cannot itself solveS2onset.',
        prior_attempts='V11 loss-router lacked event support; V14 created earlier-only predictions; V15 global probability calibration improved persistence while harming recovery/intermediate states. Do not repeat those unchanged.'),
    algebra=dict(identity='(FULL-y+d)^2-(FULL-y)^2 = 2*(FULL-y)*d + d^2',
        observed='S3 aggregate cross term is negative in all3seeds, but correction-square term dominates. Some corrections have wrong sign and much larger magnitude.',
        caution='The fitted mean/median are uncertain. Never choose realized-error-dependent shrinkage or future-state oracle routing.'),
    recommendation=dict(priority='Information and conditional decision quality before adding another backbone or global calibration knob.',
        step1='Complete existing five-field renewable publication/unit/revision contract and new-period access/admission first. Preserve full28369 training origins; do not drop earlier data for ZP26Wind.',
        step2='First repair observed-extreme corrections only. Compare a fixed old-feature conditional loss gate against the same gate plus5admitted renewable fields, between frozen V7 and FULL predictions. Both directions of wrong correction must be scored. Same chronological loss library, same algorithm/budget, no threshold grid.',
        motivation='V7overraises some reversions and overlowers some continuing spikes. A signed, horizon-conditional expected-loss decision with shrinkage toward the existing baseline can address both, if new information distinguishes them.',
        prerequisites='Sufficient earlier-only FULL/V7 error examples across independent recovery/continuation dates, representative calibration, and fresh confirmation access. Existing sparse H1 meta-fits are not sufficient.',
        output='V7 + g(x,h)*(FULL-V7), with g in[0,1], g=0 outside observed-extreme domains or without validated support. Freeze the rule from earlier development; no retrospective node/date whitelist. Both underlying paths retain original required modules.',
        tradeoff='Routing back toFULL can reduce V7S5 gains. The retained-direction gates decide promotion; conservatism may leave someS3errors unchanged.',
        step3='Only after the observed-extreme repair passes, evaluate a separate horizon-specific signed-onset expert forS2 using admitted ex-ante inputs. Use raw targets; report false-alarm harm toS0/S1, event precision/recall, timing and magnitude separately.',
        no_guarantee='Existing results can be preserved exactly as artifacts and outside a frozen activation domain. Generalization gains on every cell/state/node cannot be mathematically guaranteed.',
        not_done='No candidate fit, new accuracy result, fresh target read, paper replacement or new monitoring schedule this turn.'),
    literature=sources,training_active=False,periodic_wakeups=False,core_elements_unchanged=True,
    evidence_roles='Posthoc698H1 diagnosis is exploratory and cannot select rules then be called independent confirmation. V14/V15 different2024panels are explanatory evidence, not numerical replacements for V7.',
    completion_of_this_request='Preservation and theory-grounded gap assessment complete; finite next comparison is conditional on source/event-support admission.')
write(HERE/'NEXT_DECISION.json',decision)
h=read(B/'HANDOFF.json')
write(HERE/'HANDOFF_before_review.json',h)
h['v7_preservation_review']=dict(at=guard['at'],status=decision['status'],preservation=decision['preservation'],diagnosis=decision['diagnosis'],gates=decision['gates'],decision=str(HERE/'NEXT_DECISION.json'),original_V7_unchanged=True,training_started=False)
h['next_actions']=[decision['recommendation']['step1'],decision['recommendation']['step2'],decision['recommendation']['step3']]
write(B/'HANDOFF.json',h)
print(json.dumps(dict(preservation_files_rechecked=len(manifest['files']),protected_mean_metrics=guard['protected_mean_metric_count'],remaining_negative_mean_metrics=guard['negative_mean_metric_count'],decision=str(HERE/'NEXT_DECISION.json'),new_training_runs=0),ensure_ascii=False))
