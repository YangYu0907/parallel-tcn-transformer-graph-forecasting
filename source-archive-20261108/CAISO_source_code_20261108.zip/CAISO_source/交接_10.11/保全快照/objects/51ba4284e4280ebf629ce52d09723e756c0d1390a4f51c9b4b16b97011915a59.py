from pathlib import Path
import sys,json,gc
N=Path(__file__).resolve().parents[2]
sys.path.insert(0,str(N))
import gate
gate.verify_evaluation()
assert Path(gate.__file__).resolve()==N/'gate.py'
# Reproduce the exact added import search path; no copied or edited model code.
sys.path.append(str(gate.ORIGINAL))
with gate.exclusive('checkpoint_import_recovery_QA'):
    np,torch,limiter=gate.runtime(True)
    import model_adapter,official_models
    from compiled_data import CompiledData
    assert Path(model_adapter.__file__).resolve()==gate.ORIGINAL/'model_adapter.py'
    assert Path(official_models.__file__).resolve()==gate.EXT/'source/official_models.py'
    sealed=gate.parent.verify()
    for path in (Path(model_adapter.__file__),Path(official_models.__file__)):
        assert gate.sha(path)==sealed['bindings'][gate.rel(path)]
    data=CompiledData(gate.parent.verify_evaluation()['dataset_manifest'])
    evaluation=gate.parent.verify_evaluation()
    result=gate.read(N/'result.json');rows={x['id']:x for x in result['results']}
    checks=[]
    for c in evaluation['cases']:
        gate.guard();ck=gate.inside(c['selected_checkpoint'])
        saved=torch.load(ck,map_location='cpu',weights_only=False)
        m=model_adapter.build_model(c['variant'],c['seed']);m.load_state_dict(saved['state_dict'],strict=True);m.eval()
        rec=gate.read(gate.inside(rows[c['id']]['dense_receipt']))
        assert gate.sha(gate.inside(rec['artifact']))==rec['artifact_sha256']
        with np.load(gate.inside(rec['artifact']),allow_pickle=False) as z:expected=z['prediction'][:4]
        x,_=data.batch('june_dense',slice(0,4),with_target=False)
        with torch.inference_mode():out=model_adapter.explicit_forward(m,torch.from_numpy(x),c['variant'])
        usd=out.numpy().astype(np.float64)*data.scale[None,:,None]+data.center[None,:,None]
        difference=float(np.max(np.abs(usd-expected)))
        assert difference<=1e-9,(c['id'],difference)
        checks.append(dict(case=c['id'],maximum_difference=difference,origins=4))
        del m,saved;gc.collect()
    report=dict(status='passed',at=gate.now(),checks=checks,formal_optimizer_steps=0,heldout_targets_read=False,
        bound_imports={gate.rel(Path(m.__file__)):gate.sha(m.__file__) for m in (model_adapter,official_models)},
        evaluator_sha256=gate.sha(N/'evaluate.py'),audit_sha256=gate.sha(N/'checkpoint_audit.py'),
        recovery_source_sha256=gate.sha(Path(__file__)),execution_lock_sha256=gate.sha(gate.SEAL),
        review_scope='Actual fresh-process import and six-model pinned-formula probes; same operator.')
    gate.write(Path(__file__).parent/'qa.json',report)
    print(json.dumps(report))
