import sys,json,importlib.util
from pathlib import Path
b=Path(r'C:\Users\于阳\CAISO_feature_fusion_rev12\asof_retraining_branch_20260913')
sys.path.insert(0,str(b/'source'))
import backbone_train as bt, compile_gate
assert bt.read(Path(__file__).parent/'independent_review.json')['status']=='passed_for_stale_lock_recovery'
assert bt.stop_reason(b) is None
assert not bt.GLOBAL_LOCK.exists()
capacity=compile_gate.resources()
assert min(capacity['available_physical_GiB'],capacity['available_commit_GiB'])>=5, capacity
for name,path in [('recovery_mechanism',b/'mechanism_controls_20260920/manager.py'),('recovery_sampling',b/'phase_sampling_additive_v2_20260920/source/manager.py')]:
 spec=importlib.util.spec_from_file_location(name,path); mod=importlib.util.module_from_spec(spec); spec.loader.exec_module(mod); mod.verify()
 if name=='recovery_mechanism':mod.recovery_gate(None)
latest=bt.read(b/'runs/backbone/20260814_GLOBAL/latest.json')
assert latest['sha256']=='beec4fea1425b10f41d18a8f586e0ee3a49aa60d20b8ffcbec7a47384d12257d'
assert bt.sha(bt.inside(latest['path']))==latest['sha256']
assert bt.read(bt.inside(latest['path']).with_suffix('.receipt.json'))==latest
print(json.dumps(dict(status='controlled_resume_admitted',resources=capacity,checkpoint_steps=latest['steps'])))
