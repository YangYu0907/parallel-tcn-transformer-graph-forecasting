"""Frozen as-issued weather history experiment; no new price targets."""
from pathlib import Path
import os,sys,json,time,uuid
E=Path(__file__).resolve().parent;W=E.parent;Z=W.parent;B=Z.parent.parent
for k in ['OMP_NUM_THREADS','MKL_NUM_THREADS','OPENBLAS_NUM_THREADS','NUMEXPR_NUM_THREADS']:os.environ[k]='1'
sys.path.insert(0,str(Z));sys.path.insert(0,str(Z/'fit4_1009'))
import support as s
read=s.read;sha=s.sha;now=s.now
def write(p,d):
 p=Path(p);assert p.resolve().is_relative_to(E.resolve());p.parent.mkdir(parents=True,exist_ok=True)
 tmp=p.with_name('.j'+uuid.uuid4().hex[:8]);tmp.write_text(json.dumps(d,ensure_ascii=False,indent=2,allow_nan=False),encoding='utf-8')
 for i in range(20):
  try:os.replace(tmp,p);return
  except PermissionError:
   if i==19:raise
   time.sleep(.1)
def save(p,**d):
 import numpy as np
 p=Path(p);assert p.resolve().is_relative_to(E.resolve());p.parent.mkdir(parents=True,exist_ok=True)
 tmp=p.with_name('.n'+uuid.uuid4().hex[:8])
 with tmp.open('wb') as f:np.savez_compressed(f,**d)
 os.replace(tmp,p)
def guard(launch=False):
 for parent in [E,W,Z]:
  for name in ['STOP_REQUESTED','STOP_REQUESTED.json']:
   if (parent/name).exists():raise InterruptedError('User stop '+str(parent/name))
 return s.guard(launch)
def verify():
 p=read(E/'PROTOCOL.json')
 for path,h in p['bindings'].items():assert sha(path)==h,path
 assert read(E/'QA.json')['passed']
 for path,h in read(Z/'PROTECTED_FILES.json').items():assert sha(path)==h,path
 assert not (E/'RESULT.json').exists(),'Completed queue cannot be relaunched'
 return p

