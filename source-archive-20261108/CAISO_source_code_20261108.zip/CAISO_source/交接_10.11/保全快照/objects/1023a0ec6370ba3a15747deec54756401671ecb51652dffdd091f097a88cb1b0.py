"""Separate formula checks for the fixed-output attribution; no model fitting."""
from pathlib import Path
import json,sys,hashlib,os
from datetime import datetime,timezone
H=Path(__file__).resolve().parent;O=H/'gate_attribution'
sys.path.insert(0,str(H.parent/'context_expert_v1_20260929'));import gate
r=json.loads((O/'RESULT.json').read_text(encoding='utf-8'))
reg=json.loads((O/'REGISTRATION.json').read_text(encoding='utf-8'))
p=Path(reg['input']);assert hashlib.sha256(p.read_bytes()).hexdigest()==reg['input_sha256']==r['input_sha256']
with gate.exclusive('V18 fixed-output attribution separate audit; zero fits'):
 np,limiter=gate.runtime(False);gate.guard()
 from scipy.stats import rankdata
 z=np.load(p,allow_pickle=False);y=z['truth'];w=z['context_weights']
 prior=.5*z['FULL']+.25*z['STATIC']+.25*z['SELF']
 context=z['CONTEXT_GATE'];equal=z['EQUAL_MIX']
 ep=np.abs(prior-y);ec=np.abs(context-y);ee=np.abs(equal-y)
 actual=[float((ec-ee).mean()),float((ep-ee).mean()),float((ec-ep).mean())]
 expected=[r[k] for k in ['context_minus_equal_MAE','zero_logit_prior_minus_equal_MAE','context_minus_zero_logit_prior_MAE']]
 assert np.allclose(actual,expected,atol=1e-12,rtol=0)
 assert np.max(np.abs(context-(w[None,:,None,:,0]*z['FULL']+w[None,:,None,:,1]*z['STATIC']+w[None,:,None,:,2]*z['SELF'])))<1e-10
 checks=4;records=[]
 for i,(lo,hi) in enumerate([(0,90),(90,180),(180,268)],1):
  for k,m in enumerate(['STATIC','SELF'],1):
   x=np.log(w[lo:hi,:,k]/(w[lo:hi,:,0]-.25)).ravel()
   benefit=(np.abs(z['FULL'][:,lo:hi]-y[lo:hi])-np.abs(z[m][:,lo:hi]-y[lo:hi])).mean((0,2)).ravel()
   alternative_x=x.copy();alternative_benefit=benefit.copy()
   # Ranks are discontinuous at ties: retain the registered aggregation order.
   recovered=(w[lo:hi]-np.array([.25,0,0]))/.75
   x=np.log(recovered[:,:,k]/recovered[:,:,0]).ravel()
   stacked=np.stack([z['FULL'],z['STATIC'],z['SELF']],axis=-1)
   loss=np.abs(stacked-y[None,...,None]).mean((0,2))
   benefit=(loss[lo:hi,:,0]-loss[lo:hi,:,k]).ravel()
   assert np.allclose(x,alternative_x,atol=1e-12,rtol=0)
   assert np.allclose(benefit,alternative_benefit,atol=1e-12,rtol=0)
   rx=rankdata(x);ry=rankdata(benefit);rx-=rx.mean();ry-=ry.mean()
   rho=float((rx@ry)/np.sqrt((rx@rx)*(ry@ry)))
   old=next(a for a in r['score_realization_alignment'] if a['fold']==i and a['model']==m)
   assert abs(rho-old['rank_correlation'])<1e-10
   arx=rankdata(alternative_x);ary=rankdata(alternative_benefit);arx-=arx.mean();ary-=ary.mean()
   alternative_rho=float((arx@ary)/np.sqrt((arx@arx)*(ary@ary)))
   records.append({'fold':i,'model':m,'rho':rho,'algebraically_equivalent_aggregation_rho':alternative_rho,'max_benefit_roundoff':float(np.max(np.abs(benefit-alternative_benefit))),'rho_difference':float(rho-alternative_rho)});checks+=3
 audit={'at':datetime.now(timezone.utc).isoformat(),'status':'passed','separate_process_same_operator':True,'scalar_and_identity_checks':checks,'attribution_result_sha256':hashlib.sha256((O/'RESULT.json').read_bytes()).hexdigest(),'input_sha256':r['input_sha256'],'fits':0,'test_target_values_read':False,'no_model_promotion':True,'rank_checks':records,'numerical_note':'The first audit compared ranks after changing the order of subtraction and averaging and failed at strict 1e-10 rank-correlation tolerance. Equivalent losses agree within 1e-12; near-zero ties alter ranks. The separate rank formula now uses the registered aggregation order and retains the alternative values. Both give weak score alignment; no causal or significance inference is made.'}
 tmp=O/'AUDIT.tmp';tmp.write_text(json.dumps(audit,ensure_ascii=False,indent=2),encoding='utf-8');os.replace(tmp,O/'AUDIT.json')
 print(json.dumps(audit,ensure_ascii=False))
