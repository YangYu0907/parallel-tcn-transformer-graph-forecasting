"""No-fit signed-error decomposition after the frozen comparison is complete."""
from pilot import *
def main():
 assert c.read(P/'AUDIT.json')['status']=='passed';records=[]
 for seed in c.SEEDS:
  data={}
  for arm in ['A','B','D']:
   with np.load(P/'evaluated'/f'{arm}_{seed}.npz') as z:data[arm]={k:z[k] for k in z.files}
  aa=data['A'];parts=[('overall',np.ones(len(aa['truth']),bool))]
  parts += [(f'window{w}',aa['window']==w) for w in [1,2,3]]
  parts += [(f'H{h+1}',aa['h']==h) for h in range(12)]
  parts += [(f'S{s}',aa['state']==s) for s in range(6)]
  for candidate,control in [('D','A'),('D','B'),('B','A')]:
   e=data[control]['point']-aa['truth'];delta=data[candidate]['point']-data[control]['point']
   alignment=2*e*delta;magnitude=delta**2;se_change=(e+delta)**2-e**2;ae_change=abs(e+delta)-abs(e)
   assert np.allclose(alignment+magnitude,se_change,atol=1e-8,rtol=1e-10)
   for part,m in parts:
    if not m.any():continue
    r=dict(seed=seed,candidate=candidate,control=control,part=part,cells=int(m.sum()),issue_dates=len(np.unique(aa['days'][m])),
      baseline_bias=float(e[m].mean()),candidate_bias=float((e+delta)[m].mean()),mean_correction=float(delta[m].mean()),
      mean_absolute_correction=float(abs(delta[m]).mean()),alignment_term=float(alignment[m].mean()),magnitude_term=float(magnitude[m].mean()),
      MSE_change=float(se_change[m].mean()),MAE_change=float(ae_change[m].mean()),
      changed_fraction=float((abs(delta[m])>1e-10).mean()),MAE_help_fraction=float((ae_change[m]<-1e-10).mean()),MAE_harm_fraction=float((ae_change[m]>1e-10).mean()))
    records.append(r)
 totals=[]
 for candidate,control in [('D','A'),('D','B'),('B','A')]:
  for part in sorted({r['part'] for r in records}):
   rr=[r for r in records if r['candidate']==candidate and r['control']==control and r['part']==part]
   if len(rr)!=3:continue
   totals.append(dict(candidate=candidate,control=control,part=part,cells=rr[0]['cells'],issue_dates=rr[0]['issue_dates'],
    **{k:float(np.mean([r[k] for r in rr])) for k in rr[0] if k not in ['seed','candidate','control','part','cells','issue_dates']}))
 write('ERROR_DECOMPOSITION.json',dict(at=c.now(),type='Post-result descriptive algebra; not causal market attribution or model selection',
   identity='MSE(candidate)-MSE(control)=mean(2*control_error*correction)+mean(correction^2)',
   interpretation='Negative alignment means corrections oppose errors on average; positive magnitude is added variance. Neither alone proves information causality. D-B is the registered retrained information comparison.',
   records=records,seed_mean=totals,new_fits=0,new_test_targets_read=False,V7_replaced=False))
if __name__=='__main__':
 with c.numeric('Completed pilot no-fit error decomposition'):main()
