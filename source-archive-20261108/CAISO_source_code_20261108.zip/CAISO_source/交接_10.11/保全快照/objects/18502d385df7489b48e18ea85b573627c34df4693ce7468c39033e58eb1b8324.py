from pathlib import Path
import json,hashlib,sys,os,math
from datetime import datetime,timezone
from zoneinfo import ZoneInfo
ROOT=Path(__file__).resolve().parent.parent
HERE=Path(__file__).resolve().parent
sys.path.insert(0,str(ROOT/'phase_weighting_v1_20260925'))
import gate as g
SEEDS=(20260813,20260814,20260815)
FAMILIES=('FULL','TCN','EQUAL','CONCAT','GLOBAL','SELF','DLinear','iTransformer-H')
METRICS=('mae','rmse','near_h1_4_mae','h12_mae')

def prepare():
    g.need(not (HERE/'PROTOCOL.json').exists(),'Protocol exists')
    cases=[]
    for family in FAMILIES:
        stage='budget_extension_v1_20260925' if family in ('FULL','TCN','DLinear','iTransformer-H') else 'budget_mechanisms_v1_20260925'
        for seed in SEEDS:
            folder=ROOT/stage/'runs'/f'{seed}_{family}'
            r=g.read(folder/'completion.json');a=g.read(folder/'audit.json')
            g.need(a['status']=='passed' and a['completion_sha256']==g.sha(folder/'completion.json'),'Stale result audit')
            g.need(r['optimizer_steps']==12096,'Budget differs')
            cases.append(dict(family=family,seed=seed,selected_epoch=r['selected_epoch'],folder=g.rel(folder),completion_sha256=g.sha(folder/'completion.json'),audit_sha256=g.sha(folder/'audit.json'),evaluation=r['dense_evaluation']))
    manifest=ROOT/g.read(ROOT/'budget_extension_v1_20260925/EXECUTION_LOCK.json')['dataset_manifest']
    p=dict(status='locked_before_new_uncertainty_computation_after_observed_development_point_estimates',at=g.now(),scope='Existing TRAIN/June only; no new predictions, fitting, reselection or heldout access',cases=cases,dataset_manifest=g.rel(manifest),dataset_manifest_sha256=g.sha(manifest),source_sha256=g.sha(__file__),panels=['June3397','June284','balanced278'],metrics=list(METRICS),statistic='Arithmetic mean of per-seed errors; no ensemble prediction',bootstrap=dict(replicates=2000,random_seed=20260926,unit='America/Los_Angeles local origin calendar day',method='Paired nonparametric day-cluster resampling; same sampled days for every model and seed; original origin counts retained within sampled days',interval='Marginal percentile 95% interval of relative reduction, 100*(comparator-FULL)/comparator',limitations=['June repeatedly used in model selection; intervals are exploratory conditional estimates, not independent confirmation','Only observed eligible days represented; no claims about excluded market days','Within-day dependence retained; cross-day dependence and adaptive selection not fully accounted for','No 1.2-million-independent-sample claim; three seeds kept together, no multiplication of effective sample size','No significance label or hypothesis p-value supplied by this analysis']),resource=dict(start_GiB=5,runtime_GiB=4,one_numeric_worker=True,threads=1),complete_research_experiment=False)
    g.write(HERE/'PROTOCOL.json',p)
    print(json.dumps(dict(status='protocol_locked',cases=len(cases),sha256=g.sha(HERE/'PROTOCOL.json'))))

def run():
    p=g.read(HERE/'PROTOCOL.json');g.need(p['source_sha256']==g.sha(__file__),'Source changed after protocol')
    with g.exclusive('24 frozen case evidence closure: June only, no training'):
        np,lim=g.runtime(False)
        manifest=ROOT/p['dataset_manifest'];g.need(g.sha(manifest)==p['dataset_manifest_sha256'],'Manifest changed')
        m=g.read(manifest)
        def artifact(name):
            row=m['artifacts'][name];path=ROOT/row['path'];g.need(g.sha(path)==row['sha256'],'Metadata artifact changed');return np.load(path,allow_pickle=False)
        times=artifact('timestamps_seconds.npy');registered=artifact('registered_june_origins.npy')
        stats={};means={};all_metrics={};reference=None;dates=None;masks=None;day_index=None
        for case in p['cases']:
            g.guard();folder=ROOT/case['folder'];r=g.read(folder/'completion.json');a=g.read(folder/'audit.json')
            g.need(g.sha(folder/'completion.json')==case['completion_sha256'] and g.sha(folder/'audit.json')==case['audit_sha256'],'Result changed')
            path=ROOT/case['evaluation']['path'];g.need(g.sha(path)==case['evaluation']['sha256'],'Predictions changed')
            with np.load(path,allow_pickle=False) as z:
                origins=z['origins'].copy();truth=z['truth'].copy();pred=z['prediction'].copy();codes=z['codes'].copy()
            g.need(pred.shape==(3397,30,12) and np.isfinite(pred).all() and np.isfinite(truth).all(),'Shape/nonfinite')
            if reference is None:
                reference=(origins.copy(),truth.copy(),codes.copy())
                day_labels=[datetime.fromtimestamp(int(times[o]),timezone.utc).astimezone(ZoneInfo('America/Los_Angeles')).date().isoformat() for o in origins]
                dates=sorted(set(day_labels));day_index=np.array([dates.index(x) for x in day_labels])
                hour=times[origins]//3600;u,counts=np.unique(hour,return_counts=True)
                masks={'June3397':np.ones(len(origins),bool),'June284':np.isin(origins,registered),'balanced278':np.isin(hour,u[counts==12])}
                g.need([int(x.sum()) for x in masks.values()]==[3397,284,3336],'Panel origins differ')
                g.need(np.array_equal(origins,np.sort(origins)),'Origins not ordered')
            else:
                g.need(all(np.array_equal(x,y) for x,y in zip(reference,(origins,truth,codes))),'Unmatched targets/origins/states')
            err=pred-truth;ae=np.abs(err);sq=err*err
            for panel,mask in masks.items():
                v=ae[mask];q=sq[mask]
                metrics=[float(v.mean()),float(np.sqrt(q.mean())),float(v[:,:,:4].mean()),float(v[:,:,-1].mean())]
                for key,val in zip(METRICS,metrics):g.need(abs(val-r['panels'][panel][key])<1e-9,f'Metric disagreement {case} {panel} {key}')
                means.setdefault(panel,{}).setdefault(case['family'],[]).append(metrics)
                origin_losses=np.column_stack((ae.mean((1,2)),sq.mean((1,2)),ae[:,:,:4].mean((1,2)),ae[:,:,-1].mean(1)))
                daily=np.stack([np.bincount(day_index[mask],weights=origin_losses[mask,k],minlength=len(dates)) for k in range(4)],axis=1)
                stats.setdefault(panel,{}).setdefault(case['family'],[]).append(daily)
            # Preserve all existing node/horizon/phase/state rows, including adverse directions.
            all_metrics[f"{case['seed']}_{case['family']}"]=r['panels']
            print(json.dumps(dict(case=f"{case['seed']}_{case['family']}",verified=True)),flush=True)
            del pred,truth,codes,err,ae,sq
        g.guard();rng=np.random.default_rng(p['bootstrap']['random_seed']);D=len(dates)
        weights=rng.multinomial(D,np.full(D,1/D),size=2000)
        # Small algebraic QA: duplicated within-day cells leave cluster resampling identical.
        test_counts=np.array([2.,3.]);test_sums=np.array([4.,9.]);test_w=np.array([[1.,1.],[2.,0.],[0.,2.]])
        g.need(np.array_equal((test_w@test_sums)/(test_w@test_counts),(test_w@(test_sums*2))/(test_w@(test_counts*2))),'Cluster duplication invariance')
        results={};table=[]
        for panel,mask in masks.items():
            g.guard();counts=np.bincount(day_index[mask],minlength=D);den=weights@counts;g.need((den>0).all(),'Empty resampled panel')
            boot={};mean={}
            for family in FAMILIES:
                daily=np.stack(stats[panel][family]);samples=np.einsum('bd,sdk->bsk',weights,daily)/den[:,None,None]
                samples[:,:,1]=np.sqrt(samples[:,:,1]);boot[family]=samples.mean(axis=1)
                mean[family]=np.mean(means[panel][family],axis=0)
                g.need(np.max(np.abs(np.stack(means[panel][family]).mean(0)-mean[family]))<1e-12,'Seed reduction')
            rows=[]
            for family in FAMILIES[1:]:
                for k,key in enumerate(METRICS):
                    delta=100*(mean[family][k]-mean['FULL'][k])/mean[family][k]
                    dist=100*(boot[family][:,k]-boot['FULL'][:,k])/boot[family][:,k]
                    ci=np.quantile(dist,[.025,.975]).tolist()
                    per_seed=100*(np.array(means[panel][family])[:,k]-np.array(means[panel]['FULL'])[:,k])/np.array(means[panel][family])[:,k]
                    row=dict(comparator=family,metric=key,full=float(mean['FULL'][k]),comparator_value=float(mean[family][k]),reduction_percent=float(delta),exploratory_day_cluster_95pct_interval=ci,per_seed_reduction_percent=per_seed.tolist(),positive_seeds=int((per_seed>0).sum()))
                    rows.append(row);table.append(dict(panel=panel,**row))
            results[panel]=dict(origins=int(mask.sum()),cells=int(mask.sum())*360,local_calendar_days_with_origins=int((counts>0).sum()),day_origin_counts=dict(zip(dates,counts.tolist())),means={f:dict(zip(METRICS,mean[f].tolist())) for f in FAMILIES},contrasts=rows)
        result=dict(status='recomputed_24_frozen_cases_with_exploratory_day_cluster_intervals',at=g.now(),protocol_sha256=g.sha(HERE/'PROTOCOL.json'),source_sha256=g.sha(__file__),parent_audits='All 24 hash-bound passed receipts; independent implementation by same operator, not second-person certification',metric_reproduction_tolerance=1e-9,uncertainty_scope=p['bootstrap'],panels=results,heldout_targets_read=False,training_updates=0,selection_changed=False,complete_research_experiment=False)
        g.write(HERE/'all_case_metrics.json',all_metrics)
        g.write(HERE/'summary.json',result)
        g.write(HERE/'qa.json',dict(status='passed',actual_cases=24,actual_panels=3,metric_equalities=288,shared_truth_origins_states=True,within_day_duplication_invariance=True,source_sha256=g.sha(__file__),summary_sha256=g.sha(HERE/'summary.json'),not_second_person_audit=True))
        lines=['# 已有实验结果与范围','', '24 个已训练并审核的模型；三种子、30 节点、12 步。以下为反复使用过的 June 开发期结果，不是独立跨期检验。误差单位 USD/MWh；百分比正数表示 FULL 改善。','','|面板|对照|指标|FULL|对照值|改善 %|日块探索性 95% 区间 %|改善种子|','|---|---|---|---:|---:|---:|---|---:|']
        for row in table:
            lo,hi=row['exploratory_day_cluster_95pct_interval'];lines.append(f"|{row['panel']}|{row['comparator']}|{row['metric']}|{row['full']:.6f}|{row['comparator_value']:.6f}|{row['reduction_percent']:.3f}|[{lo:.3f}, {hi:.3f}]|{row['positive_seeds']}/3|")
        lines+=['','全部节点、步长、价格状态和时钟相位结果保留在 all_case_metrics.json。日块区间保留日内相关性，不能消除反复开发集选择的偏差，也未充分解决跨日相关性；这里不使用“已通过独立显著性检验”措辞。','强基线信息集：DLinear 为价格历史基线，iTransformer-H 为历史多变量基线。固定预算排名不等于所有算法最优调参后的 SOTA 排名。','数据版本核验、最终模型与信息集冻结、独立跨期预测和正式统计检验仍需完成。']
        g.atomic(HERE/'RESULTS.md',lambda f:f.write('\n'.join(lines).encode('utf-8')))
        print(json.dumps(dict(status='completed',summary=str(HERE/'summary.json'),days=D,heldout_targets_read=False,training_updates=0)),flush=True)

if __name__=='__main__':
    if sys.argv[1]=='prepare':prepare()
    elif sys.argv[1]=='run':run()

