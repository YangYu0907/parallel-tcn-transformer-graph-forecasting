"""Bounded streaming HRRR extraction; network workers, one numeric decoder."""
from datetime import datetime, timezone
from email.utils import parsedate_to_datetime
from concurrent.futures import ThreadPoolExecutor, wait, FIRST_COMPLETED
import os, sys, time, json, hashlib, threading, uuid, traceback, importlib.util
import requests
import support as s

I=s.N.parent/'forecast_source_inventory_20261005'
P=s.N.parent/'forecast_value_proof_20261005'
H=s.N.parent/'historical_weather_admission_20261005'
sys.path.insert(0,str(P/'vendor'))
import eccodes as ec
import numpy as np
spec=importlib.util.spec_from_file_location('original_grib_identity',H/'verify_grib_ranges.py')
identity_module=importlib.util.module_from_spec(spec);spec.loader.exec_module(identity_module)
URL='https://noaa-hrrr-bdp-pds.s3.amazonaws.com/'
CANCEL=threading.Event();COUNT_LOCK=threading.Lock();COUNTS={'network_bytes':0,'http_requests':0}


def atomic(path,blob):
    path.parent.mkdir(parents=True,exist_ok=True)
    q=path.with_name('.'+uuid.uuid4().hex+'.tmp');q.write_bytes(blob);os.replace(q,path)

def check(p,start):
    if CANCEL.is_set():raise InterruptedError('Pilot cancelled after a prior failure')
    s.guard()
    if time.monotonic()-start>p['maximum_seconds']:raise TimeoutError('Finite extraction pilot budget reached')

def response_check(response,expected):
    assert response.headers['ETag']==expected['etag']
    assert parsedate_to_datetime(response.headers['Last-Modified']).timestamp()==expected['last_modified_seconds']

def account(p,n):
    with COUNT_LOCK:
        COUNTS['network_bytes']+=n;COUNTS['http_requests']+=1
        assert COUNTS['network_bytes']<=p['maximum_download_bytes']

def fetch_cycle(choice,objects,p,start):
    check(p,start);began=time.monotonic();session=requests.Session();messages=[];receipts=[];byte_count=0
    dt=datetime.fromtimestamp(choice['cycle'],timezone.utc);stamp=dt.strftime('%Y%m%d_%Hz')
    try:
        for lead in p['required_leads']:
            check(p,start)
            key=dt.strftime('hrrr.%Y%m%d/conus/hrrr.t%Hz.wrfsfcf')+f'{lead:02d}.grib2'
            source,index=objects[key],objects[key+'.idx']
            assert max(source['last_modified_seconds'],index['last_modified_seconds'])<=choice['minimum_qualified_cutoff']
            response=session.get(URL+key+'.idx',headers={'If-Match':index['etag']},timeout=(10,30))
            response.raise_for_status();response_check(response,index);blob=response.content
            assert len(blob)==index['bytes']
            assert hashlib.md5(blob).hexdigest()==index['etag'].strip('"')
            account(p,len(blob));byte_count+=len(blob)
            index_rel=f'raw/{stamp}/F{lead:02d}.idx';atomic(s.N/index_rel,blob)
            receipts.append(dict(key=key+'.idx',kind='index',headers=dict(response.headers),local=index_rel,sha256=hashlib.sha256(blob).hexdigest()))
            lines=[line.split(':') for line in blob.decode('ascii').splitlines() if line.strip()]
            selected=[]
            for variable,level in [('TMP','2 m above ground'),('UGRD','10 m above ground'),('VGRD','10 m above ground')]:
                match=[j for j,line in enumerate(lines) if line[3]==variable and line[4]==level]
                assert len(match)==1;idx=match[0]
                left=int(lines[idx][1]);right=int(lines[idx+1][1])-1
                assert 0<right-left<8*1024**2
                selected.append(dict(variable=variable,left=left,right=right))
            # Merge only adjacent selected messages, with no unrelated field download.
            groups=[]
            for part in sorted(selected,key=lambda z:z['left']):
                if groups and groups[-1][-1]['right']+1==part['left']:groups[-1].append(part)
                else:groups.append([part])
            for parts in groups:
                check(p,start);left,right=parts[0]['left'],parts[-1]['right']
                with session.get(URL+key,headers={'Range':f'bytes={left}-{right}','If-Match':source['etag']},stream=True,timeout=(10,30)) as response:
                    assert response.status_code==206
                    response_check(response,source)
                    assert response.headers['Content-Range']==f'bytes {left}-{right}/{source["bytes"]}'
                    assert int(response.headers['Content-Length'])==right-left+1
                    data=response.content;headers=dict(response.headers)
                assert len(data)==right-left+1
                account(p,len(data));byte_count+=len(data)
                rel=f'raw/{stamp}/F{lead:02d}_'+('_'.join(v['variable'] for v in parts))+'.grib2'
                atomic(s.N/rel,data)
                receipts.append(dict(key=key,kind='GRIB_range',range=[left,right],headers=headers,local=rel,sha256=hashlib.sha256(data).hexdigest(),bytes=len(data)))
                for part in parts:
                    sub=data[part['left']-left:part['right']-left+1]
                    messages.append(dict(variable=part['variable'],lead=lead,blob=sub,range=[part['left'],part['right']],key=key,local_bundle=rel))
        return dict(choice=choice,messages=messages,receipts=receipts,network_bytes=byte_count,fetch_seconds=time.monotonic()-began)
    finally:session.close()

def decode_cycle(download,p,geometry,grid_hash):
    begun=time.monotonic();choice=download['choice'];values=np.empty((3,3,3),dtype=np.float64);rows=[]
    reference=datetime.fromtimestamp(choice['cycle'],timezone.utc).isoformat()
    assert len(download['messages'])==9
    for item in download['messages']:
        s.guard();vi=['TMP','UGRD','VGRD'].index(item['variable']);li=p['required_leads'].index(item['lead'])
        info=identity_module.identity(item['blob'])
        assert info['reference']==reference and info['lead_hours']==item['lead'] and info['discipline']==0
        assert (info['category'],info['parameter'],info['surface_type'],info['height'])==[(0,0,103,2),(2,2,103,10),(2,3,103,10)][vi]
        assert info['grid_sha256']==grid_hash,'Changed grid requires separate qualification'
        handle=ec.codes_new_from_message(item['blob'])
        try:
            nx,ny=ec.codes_get(handle,'Nx'),ec.codes_get(handle,'Ny')
            assert (nx,ny)==(1799,1059)
            raw=ec.codes_get_values(handle)
            assert raw.size==nx*ny
            vals=np.asarray([raw[g['index']] for g in geometry]);del raw
            assert np.isfinite(vals).all()
            if vi==0:assert ((vals>180)&(vals<340)).all()
            else:assert (abs(vals)<100).all()
            values[vi,:,li]=vals
            rows.append(dict(variable=item['variable'],lead=item['lead'],range=item['range'],key=item['key'],local_bundle=item['local_bundle'],values=vals.tolist(),units=str(ec.codes_get(handle,'units')),**info))
        finally:ec.codes_release(handle)
    result=dict(at=s.now(),choice=choice,values=values.tolist(),geometry=geometry,rows=rows,receipts=download['receipts'],network_bytes=download['network_bytes'],fetch_seconds=download['fetch_seconds'],decode_seconds=time.monotonic()-begun,decoder_version=ec.codes_get_api_version(),scope='Regional operational forecasts, not nodal net-load or congestion predictions',model_fits=0)
    s.write('cycles/'+str(choice['cycle'])+'.json',result)
    return result

def emit(kind,evidence):
    h=s.sha(evidence);eid='fs_'+h[:32];path=s.B/'event_driven_automation/inbox'/(eid+'.json')
    if not path.exists():atomic(path,json.dumps(dict(schema='caiso_research_event_v1',event_id=eid,event=kind,evidence_path=str(evidence),evidence_sha256=h,at=s.now()),ensure_ascii=False).encode('utf-8'))
    return eid

def run(p,start):
    assert ec.codes_get_api_version()=='2.49.0'
    choices=s.read(s.N/'SELECTION.json')['cycles']
    objects=s.read(I/'AUDITED_OBJECT_INDEX.json')['objects']
    geometry=s.read(P/'RESULT.json')['geometry']
    grid=s.read(H/'GRIB_BYTE_PROOF.json')['rows'][0]['grid_sha256']
    remaining=iter(choices);results=[]
    pool=ThreadPoolExecutor(max_workers=p['io_threads']);pending={}
    try:
        for _ in range(p['io_threads']):
            choice=next(remaining,None)
            if choice is not None:pending[pool.submit(fetch_cycle,choice,objects,p,start)]=choice
        while pending:
            done,_=wait(pending,timeout=1,return_when=FIRST_COMPLETED);check(p,start)
            for future in done:
                choice=pending.pop(future);download=future.result()
                result=decode_cycle(download,p,geometry,grid);results.append(result);del download
                elapsed=time.monotonic()-start
                s.write('PROGRESS.json',dict(at=s.now(),pid=os.getpid(),completed_cycles=len(results),total_cycles=len(choices),elapsed_seconds=elapsed,**COUNTS,model_fits=0))
                choice=next(remaining,None)
                if choice is not None:pending[pool.submit(fetch_cycle,choice,objects,p,start)]=choice
    except BaseException:
        CANCEL.set()
        for f in pending:f.cancel()
        raise
    finally:pool.shutdown(wait=True,cancel_futures=True)
    # Verify saved-byte lineage before declaring the extraction pilot complete.
    raw_bytes=0;raw_hashes=0
    for result in results:
        for receipt in result['receipts']:
            path=s.N/receipt['local'];assert s.sha(path)==receipt['sha256']
            raw_bytes+=path.stat().st_size;raw_hashes+=1
    assert raw_bytes<=p['maximum_raw_storage_bytes']
    assert len(results)==24 and len(results)*27==p['expected_values']
    elapsed=time.monotonic()-start;whole=s.read(s.N/'SELECTION.json')['full_qualified_cycles']
    report=dict(at=s.now(),stage='fixed_monthly_extraction_pilot_completed',cycles=len(results),decoded_messages=len(results)*9,extracted_values=len(results)*27,raw_files_rehashed=raw_hashes,retained_raw_bytes=raw_bytes,seconds=elapsed,network=COUNTS,median_cycle_fetch_seconds=float(np.median([r['fetch_seconds'] for r in results])),median_cycle_decode_seconds=float(np.median([r['decode_seconds'] for r in results])),full_qualified_cycles=whole,extrapolated_full_hours=elapsed/len(results)*whole/3600,extrapolated_full_network_GiB=COUNTS['network_bytes']/len(results)*whole/1024**3,estimate_is_not_runtime_guarantee=True,full_extraction_started=False,independent_audit_pending=True,model_fits=0,new_test_targets_read=False,V7_replaced=False,protected_files_unchanged=s.base.verify_protected(),next='Separate pilot audit and bounded compact-storage extraction decision; no automatic model fitting or bulk archive persistence')
    s.write('RESULT.json',report)

def main():
    lock=s.N/'MANAGER.lock'
    with lock.open('x') as f:json.dump(dict(pid=os.getpid()),f)
    start=time.monotonic()
    try:
        p=s.verify();s.guard(True)
        s.write('STATUS.json',dict(at=s.now(),pid=os.getpid(),event='awaiting_exit_monitor_binding'))
        while not (s.N/'START_READY.json').exists():
            if time.monotonic()-start>55:raise TimeoutError('Exit monitor binding missing; no extraction started')
            time.sleep(.2)
        import psutil
        ready=s.read(s.N/'START_READY.json');assert ready['manager_pid']==os.getpid() and psutil.pid_exists(ready['exit_monitor_pid'])
        s.write('STATUS.json',dict(at=s.now(),pid=os.getpid(),event='step_process_started',stage='fixed_streaming_pilot',model_fits=0))
        with s.base.numeric('Fixed24cycle forecast streaming pilot; zero model fits'):run(p,start)
        eid=emit('needs_analysis',s.N/'RESULT.json')
        s.write('STATUS.json',dict(at=s.now(),pid=os.getpid(),event='finite_mechanism_queue_completed',event_id=eid,model_fits=0))
    except InterruptedError as exc:s.write('STATUS.json',dict(at=s.now(),pid=os.getpid(),event='user_stop_before_launch',classification='user_stop',error=str(exc)))
    except BaseException as exc:
        s.write('FAILURE.json',dict(at=s.now(),error=repr(exc),traceback=traceback.format_exc(),automatic_retry=False,model_fits=0));eid=emit('blocking_failure',s.N/'FAILURE.json')
        s.write('STATUS.json',dict(at=s.now(),pid=os.getpid(),event='step_stopped_or_failed',event_id=eid,error=repr(exc)))
    finally:
        if lock.exists() and s.read(lock)['pid']==os.getpid():lock.unlink()

if __name__=='__main__':main()
