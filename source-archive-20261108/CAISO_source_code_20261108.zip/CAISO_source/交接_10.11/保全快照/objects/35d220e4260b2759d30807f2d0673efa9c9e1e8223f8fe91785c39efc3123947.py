"""Single bounded, versioned development experiment. No new test reader."""
from pathlib import Path
import sys, os, json, pickle, uuid, time, shutil
HERE=Path(__file__).resolve().parent; B=HERE.parent
T=B/'context_expert_v1_20260929'; V2=B/'adaptive_experts_v2_20260929'
H1=B/'h1_final_evaluation_v1_20260927'
ART=Path('C:/Users/于阳/CAISO_temporary_storage/spike_specialist_v7_20260930')
sys.path.insert(1,str(T));import gate
FIELDS=[0,21,22,23,24,15,16,25,26,27,28,8,9,10,11,12,13]
ARMS=['BASE','PREVIOUS','DURATION','CONTEXT_HULL','CONTEXT','CONTEXT_FIXED'];SEEDS=[20260813,20260814,20260815]
_start=None;_used=0.

def atomic(path,writer):
    path=Path(path)
    assert any(path.resolve().is_relative_to(r.resolve()) for r in (HERE,ART))
    path.parent.mkdir(parents=True,exist_ok=True)
    if shutil.disk_usage(path.parent).free<32*1024**2:raise OSError('Disk safety floor 32MiB')
    tmp=path.with_name('.'+path.name+'.'+uuid.uuid4().hex+'.tmp')
    with tmp.open('xb') as f:writer(f);f.flush();os.fsync(f.fileno())
    # Windows scanners may briefly hold an existing checkpoint without delete sharing.
    # Retry only the atomic rename; preserve both files on sustained failure.
    for attempt in range(7):
        try:
            os.replace(tmp,path)
            break
        except OSError as exc:
            if getattr(exc,'winerror',None) not in (5,32,33) or attempt==6:raise
            time.sleep(.1*2**attempt)
def write(path,obj):atomic(path,lambda f:f.write(json.dumps(obj,ensure_ascii=False,indent=2,allow_nan=False).encode('utf-8')))
def save(path,**kw):
    import numpy as np
    atomic(path,lambda f:np.savez(f,**kw))
def dump(path,obj):atomic(path,lambda f:pickle.dump(obj,f,protocol=5))
def load(path):
    with Path(path).open('rb') as f:return pickle.load(f)
def status(**kw):write(HERE/'queue/status.json',dict(at=gate.now(),pid=os.getpid(),**kw))
def tick(**kw):
    for d in (HERE,HERE/'queue'):
        for n in ('STOP_REQUESTED','STOP_REQUESTED.json'):
            if (d/n).exists():raise InterruptedError('User stop '+str(d/n))
    gate.guard()
    if _start is not None:
        used=_used+time.monotonic()-_start
        write(HERE/'queue/budget.json',dict(used_seconds=used,maximum_seconds=3600,at=gate.now()))
        if used>=3600:raise TimeoutError('One-hour fixed numerical budget')
    if kw:status(event='step_process_started',**kw)
def start_budget():
    global _start,_used
    _used=gate.read(HERE/'queue/budget.json')['used_seconds'] if (HERE/'queue/budget.json').exists() else 0.
    _start=time.monotonic()
def verify():
    for path,digest in gate.read(HERE/'EXECUTION_SEAL.json')['bindings'].items():assert gate.sha(path)==digest,path
    assert gate.read(HERE/'QA.json')['status']=='passed'
    tick()
def dense(last):
    import numpy as np
    n=len(last)
    return np.column_stack([np.repeat(last[:,:,FIELDS].reshape(-1,len(FIELDS)),12,axis=0),np.tile((np.arange(12)+1)/12,n*30)]).astype(np.float32)
def raw_price(last,sc):
    import numpy as np
    return last[...,0]*np.array(sc['price_scale'])[0,:,0]+np.array(sc['price_center'])[0,:,0]
def regime(last,sc,thresholds):
    import numpy as np
    amp=abs(raw_price(last,sc)-np.array(thresholds['center']))
    q=np.array(thresholds['thresholds'])
    return (amp>q[0]).astype(int)+(amp>q[1]).astype(int)
def tar_features(rows,nodes,sc):
    """All rows are historical origin-1 features; no future targets or states."""
    import numpy as np
    center=np.array(sc['price_center'])[0,:,0];scale=np.array(sc['price_scale'])[0,:,0];unit=scale.mean()
    price=rows[:,0]*scale[nodes]+center[nodes]
    lag=[]
    for j,name in enumerate(('lmp_lag_24h','lmp_lag_48h','lmp_lag_7d','lmp_lag_14d')):
        d=sc['derived'][name];lag.append(rows[:,25+j]*np.array(d['scale'])[nodes]+np.array(d['center'])[nodes])
    level=np.median(np.array(lag),axis=0)
    # First coefficient is mean reversion strength, constrained to [0,1].
    X=np.column_stack([(level-price)/unit,np.ones(len(rows)),rows[:,[21,22,23,24,8,9,10,11,14]]])
    return X.astype(float),price
def bounded_irls(X,y,prior,penalty):
    """Fixed ten Huber IRLS iterations; exact constrained quadratic subproblem."""
    import numpy as np
    beta=prior.copy();eye=np.eye(X.shape[1]);others=np.arange(1,X.shape[1])
    for _ in range(10):
        w=np.minimum(1.,.5/np.maximum(abs(y-X@beta),1e-12))
        A=X.T@(w[:,None]*X)+penalty*eye;rhs=X.T@(w*y)+penalty*prior
        beta=np.linalg.solve(A,rhs)
        if not 0<=beta[0]<=1:
            beta[0]=np.clip(beta[0],0,1)
            beta[others]=np.linalg.solve(A[1:,1:],rhs[1:]-A[1:,0]*beta[0])
    return beta
def correction_weights(experts,mean,median,allowed):
    """Move toward both estimated conditional functionals, inside anchored expert hull."""
    import numpy as np
    delta=experts[...,1:]-experts[...,:1]
    c=np.where(mean*median>0,np.sign(mean)*np.minimum(abs(mean),abs(median)),0.)
    c=np.where(allowed,c,0.)
    direction=np.sign(c);best=np.argmax(delta*direction[...,None],axis=-1)
    d=np.take_along_axis(delta,best[...,None],axis=-1)[...,0]
    a=np.where(d*c>0,np.minimum(abs(c)/np.maximum(abs(d),1e-12),.75),0.)
    w=np.zeros_like(experts,dtype=float);w[...,0]=1-a
    np.put_along_axis(w,(best+1)[...,None],a[...,None],axis=-1)
    return w,c

class Calibration:
    """Related-node pooling, calendar-aware, released feedback only."""
    def __init__(self):self.items={};self.applied=set()
    def observe(self,key,issued,ready,now,reg,h,residuals):
        import numpy as np
        assert ready<=now and issued<now and key not in self.applied
        self.applied.add(key);day=int(issued)//86400
        for r in range(3):
            mask=reg==r
            if mask.any():self.items.setdefault((day,r*3+h//4),[]).append(residuals[mask].copy())
    def bias(self,now):
        import numpy as np
        result=np.zeros((9,2));count=np.zeros(9,int)
        for g in range(9):
            ds=sorted(d for d,gr in self.items if gr==g)[-7:];count[g]=len(ds)
            if len(ds)<3:continue
            vals=[np.concatenate(self.items[(d,g)]) for d in ds]
            perday=np.array([[x[:,0].mean(),np.median(x[:,1])] for x in vals])
            w=np.exp(-np.log(2)*np.maximum(0,now/86400-np.array(ds)-1)/7);w/=w.sum()
            result[g]=(w[:,None]*perday).sum(0)*len(ds)/(len(ds)+5.)
        return result,count
def fit_tree(path,X,y,seed,loss='squared_error'):
    from sklearn.ensemble import HistGradientBoostingRegressor
    identity=dict(protocol=gate.sha(HERE/'PROTOCOL.json'),seed=int(seed),rows=len(y),columns=X.shape[1],loss=loss)
    if path.exists():
        obj=load(path);assert obj['identity']==identity;model=obj['model']
    else:
        kw=dict(loss=loss,learning_rate=.05,max_iter=10,max_leaf_nodes=7,min_samples_leaf=100,l2_regularization=1.,early_stopping=False,warm_start=True,random_state=int(seed))
        if loss=='quantile':kw['quantile']=.5
        model=HistGradientBoostingRegressor(**kw)
    for it in range((getattr(model,'n_iter_',0)//10+1)*10,41,10):
        tick(stage='meta_fit',case=path.stem,iteration=it,total=40)
        model.set_params(max_iter=it);model.fit(X,y);dump(path,dict(identity=identity,model=model))
    return model
