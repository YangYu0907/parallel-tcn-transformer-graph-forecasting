"""Frozen FULL backbone plus zero-output residual bottleneck before shared head."""
import hashlib
import torch
from torch import nn

def fingerprint(module):
    h=hashlib.sha256()
    for key,v in sorted(module.state_dict().items()):
        h.update(key.encode());h.update(v.detach().cpu().contiguous().numpy().tobytes())
    return h.hexdigest()

class ResidualAdapter(nn.Module):
    def __init__(self,seed):
        super().__init__()
        with torch.random.fork_rng(devices=[]):
            torch.manual_seed(seed+800000)
            self.down=nn.Linear(32,8)
            self.up=nn.Linear(8,32)
            nn.init.zeros_(self.up.weight);nn.init.zeros_(self.up.bias)
    def forward(self,features):
        return features+self.up(torch.nn.functional.gelu(self.down(features)))

class AdaptedFULL(nn.Module):
    def __init__(self,base,seed,arm):
        super().__init__()
        if arm not in ('GLOBAL','OFFHOUR'):raise ValueError('Unregistered arm')
        self.base=base.eval().requires_grad_(False)
        self.adapter=ResidualAdapter(seed)
        self.arm=arm
        self.train(False)
    def train(self,mode=True):
        super().train(mode)
        self.base.eval()
        return self
    def forward(self,x,hourly):
        if hourly.dtype!=torch.bool or hourly.shape!=(len(x),):raise ValueError('Known-origin hourly mask required')
        with torch.no_grad():out=self.base(x)
        original=out['prediction']
        adapted=self.base.head(self.adapter(out['head_features'].detach()))
        # Explicit branch selection preserves original hourly floating-point output.
        prediction=adapted if self.arm=='GLOBAL' else torch.where(~hourly[:,None,None],adapted,original)
        return dict(**{k:v for k,v in out.items() if k!='prediction'},prediction=prediction)
