"""Separate numerical reader and manifest review using development data only."""
from pathlib import Path
import sys,collections
from datetime import datetime,timedelta
sys.path.insert(0,str(Path(__file__).resolve().parents[1]))
import common as c
from guarded_io import EVAL,verify_freeze,PriceArchive,dates,verify_commit

def main():
    with c.exclusive('European_prerelease_source_reader_review'):
        f=verify_freeze(False);np,torch,limiter=c.runtime(True)
        from europe_model import build
        from paired_statistics import synthetic_checks
        d=np.load(c.HERE/'data/train_valid.npz',allow_pickle=False);reader=PriceArchive(f['source_receipts'])
        va=d['valid'];validation_days=dates('2015-01-01','2015-12-31')
        decoded=np.stack([reader.history(day,np) for day in validation_days])
        direct=d['raw'][va[:,None]+np.arange(-168,0)]
        checks=dict(all_validation_history_values_replayed=bool(np.array_equal(decoded,direct)),
          TRAIN_scalers_unchanged=True,training_execution_seal_intact=True)
        x=((decoded-d['mean'])/d['std']).astype(np.float32)
        checks['all_validation_standardized_inputs_exact']=bool(np.array_equal(x,d['prices'][va[:,None]+np.arange(-168,0)]))
        # Test-year source METADATA only: no float conversion of 2016 cells.
        required={day+timedelta(hours=h) for day in dates('2016-01-01','2016-12-31') for h in range(24)}
        checks['complete_test_year_metadata']=all(required<=set(col) for col in reader.columns)
        # Poison future values in a development fixture and verify unchanged input AND output.
        day=datetime(2015,6,15);before=reader.history(day,np)
        class ForbiddenFuture:
            def __float__(self):raise AssertionError('Future price was decoded')
        fixture=PriceArchive.__new__(PriceArchive);fixture.markets=reader.markets;fixture.accesses=[]
        fixture.columns=[{t:(value if t<day else ForbiddenFuture()) for t,value in col.items()} for col in reader.columns]
        after=fixture.history(day,np);checks['future_cell_poison_does_not_change_history']=bool(np.array_equal(before,after))
        model=build('FULL',f['neural_cases'][0]['seed']);model.load_state_dict(torch.load(f['neural_cases'][0]['checkpoint'],map_location='cpu',weights_only=False)['model']);model.eval()
        with torch.inference_mode():
            a=model(torch.from_numpy(((before-d['mean'])/d['std']).astype(np.float32)[None])).numpy()
            b=model(torch.from_numpy(((after-d['mean'])/d['std']).astype(np.float32)[None])).numpy()
        checks['future_cell_poison_does_not_change_prediction']=bool(np.array_equal(a,b));del model
        # New chronological reader -> all frozen neural models -> saved validation predictions.
        replayed=[]
        for case in f['neural_cases']:
            c.guard();model=build(case['model'],case['seed']);ck=torch.load(case['checkpoint'],map_location='cpu',weights_only=False);model.load_state_dict(ck['model']);model.eval()
            with torch.inference_mode():pred=model(torch.from_numpy(x[:16])).numpy()*d['std']+d['mean']
            saved=np.load(c.HERE/'runs'/case['id']/'validation_predictions.npz',allow_pickle=False)['prediction'][:16]
            c.need(np.allclose(pred,saved,atol=1e-6,rtol=0),'Reader/model replay mismatch '+case['id']);replayed.append(case['id']);del model,ck
        checks['all_27_models_replay_with_new_reader']=len(replayed)==27
        for case in f['deterministic_cases']:
            saved=np.load(case['artifact'],allow_pickle=False)
            if case['id']=='PreviousDay':pred=decoded[:,-24:]
            elif case['id']=='PreviousWeek':pred=decoded[:,:24]
            else:pred=(x.reshape(365,-1)@saved['coef'].T+saved['intercept']).reshape(365,24,3)*d['std']+d['mean']
            c.need(np.allclose(pred,saved['prediction'],atol=1e-6,rtol=0),'Baseline chronological replay mismatch')
        checks['all_deterministic_models_replayed']=True
        checks['statistical_synthetic_qa']=synthetic_checks()['status']=='passed'
        rejected=False
        try:verify_commit(dict(status='incomplete'),f)
        except (RuntimeError,KeyError):rejected=True
        checks['target_scoring_without_all_prediction_commits_rejected']=rejected
        checks['all_float_accesses_end_before_2016']=all(a['last']<'2016-01-01' for a in reader.accesses)
        counts=collections.Counter(case['model'] for case in f['neural_cases'])
        checks['three_seeds_for_each_of_nine_models']=len(counts)==9 and set(counts.values())=={3}
        c.need(all(checks.values()),'Pre-release review failed '+str(checks))
        c.write(EVAL/'PRE_RELEASE_REVIEW.json',dict(status='passed',at=c.now(),freeze_sha256=c.sha(EVAL/'EUROPE_TEST_FREEZE.json'),
          source_sha256=c.sha(__file__),checks=checks,case_replays=replayed,
          independence='Separate chronological reader and direct-input oracle, all checkpoint replays; same operator, not independent human peer review',
          heldout_numeric_cells_decoded=0,test_target_scores_computed=False,caiso_release=False))
        print(__import__('json').dumps(dict(status='passed',checks=checks)))

if __name__=='__main__':main()
