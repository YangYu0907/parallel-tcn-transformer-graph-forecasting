"""Separate scoring formulas and stability diagnosis; no model fitting."""
from common import *
import numpy as np
from scipy.stats import johnsonsu
import probability_revision as prior
def main():
 with numeric('separate arithmetic audit and distribution stability trace'):
  verify_sources();checks=0;maxerr=0.;tails=[];stability=[]
  rows=list(csv.DictReader((ROOT/'DISTRIBUTION_RESULTS.csv').open(encoding='utf-8-sig')))
  for task in ['CAISO','Europe']:
   for seed in SEEDS:
    z=np.load(ROOT/'distribution_predictions'/f'{task}_{seed}.npz');old=np.load(FIRST/'probability_predictions'/task/f'{seed}.npz')
    assert np.array_equal(z['point'],old['point']) and np.array_equal(z['truth'],old['truth'])
    y=z['truth'];qs=np.array([.05,.1,.5,.9,.95]);shape=z['parameters'];mu,s,a,b=[shape[...,k] for k in range(4)]
    d=prior.load_data(task,seed);ev=d['role']==2
    q=johnsonsu.ppf(z['quantile_levels'],a[...,None],b[...,None],loc=mu[...,None],scale=s[...,None]);currency=z['point'][...,None]+q*d['scale'][None,:,None,None]
    np.testing.assert_allclose(currency,z['raw_seven'],rtol=2e-12,atol=1e-7)
    for arm in ['HIST_CAL','CQR_CAL','JSU_RAW','JSU_CAL']:
     pred=z[arm];err=y[...,None]-pred;wis=2*np.maximum(qs*err,(qs-1)*err).mean(-1)
     for state in ['overall']+[str(int(s)) for s in np.unique(z['states'])]:
      mask=np.ones(y.shape,bool) if state=='overall' else z['states']==int(state)
      expected=next(r for r in rows if r['task']==task and int(r['seed'])==seed and r['model']==arm and r['state']==state)
      got=float(wis[mask].mean());target=float(expected['wis']);gap=abs(got-target)/max(1,abs(target));maxerr=max(maxerr,gap);assert gap<1e-10;checks+=1
    c=np.load(ROOT/'onset_forward_predictions.npz')
    for row in csv.DictReader((ROOT/'ONSET_RESULTS.csv').open(encoding='utf-8-sig')):
     h=int(row['horizon']);j=[1,4,12].index(h);k=1 if row['event']=='up' else 2;p=c[f"{row['model']}_H{h}"][:,k];target=c['y'][:,j]==k
     assert abs(np.mean((p-target)**2)-float(row['brier']))<1e-12;checks+=1
    # Diagnose extrapolation on fitting and calibration inputs without another fit.
    import torch
    from distribution import JSU
    cp=torch.load(ROOT/'distribution_models'/f'{task}_{seed}.pt',map_location='cpu',weights_only=False);m=JSU(d['X'].shape[1]);m.load_state_dict(cp['model']);m.eval();x=(d['X']-cp['center'])/cp['scale']
    with torch.no_grad():par=np.concatenate([np.stack([v.numpy() for v in m(torch.from_numpy(x[i:i+4096]))],-1) for i in range(0,len(x),4096)])
    for role in [0,1,2]:
     sel=d['masks'][role].ravel();mu,s,a,b=par[sel].astype(float).T
     rq=johnsonsu.ppf(np.array([.05,.95]),a[:,None],b[:,None],loc=mu[:,None],scale=s[:,None]);width=rq[:,1]-rq[:,0]
     vals=np.max(abs(x[sel]),axis=0);features=sorted(zip(d['features'],vals.tolist()),key=lambda t:-t[1])[:3]
     stability.append(dict(task=task,seed=seed,role=['fit','calibration','forward_development'][role],maximum_standardized_feature=float(vals.max()),largest_feature=features[0][0],median_normalized_width90=float(np.median(width)),maximum_normalized_width90=float(width.max()),width99=float(np.quantile(width,.99)),minimum_shape_b=float(b.min()),max_abs_shape_a=float(abs(a).max())))
    z.close();old.close();del d,x,m,par
  table('DISTRIBUTION_STABILITY_TRACE.csv',stability)
  onset=read(ROOT/'ONSET_RESULT.json');dist=read(ROOT/'DISTRIBUTION_RESULT.json')
  write(ROOT/'BATCH_AUDIT.json',dict(at=now(),status='arithmetic_passed_not_performance_acceptance',checks=checks,max_relative_WIS_gap=maxerr,scipy_quantile_reconstruction=True,point_preserved_all_six_cases=True,protected=verify_protected(),new_test_targets_read=False,reviewer='same operator, separate scoring formulas; not an external reviewer'))
  write(ROOT/'DECISIONS.json',dict(at=now(),onset=dict(screen_pass=onset['screen_pass'],integration=False,scope='Only H12 had preregistered three-class support; H1/H4 negative-spike calibration insufficient',limitations='Original TRAIN-derived scalers/state definitions span the downstream forward block; this is a retrospective development diagnostic, not an end-to-end untouched temporal test.'),distribution=dict(integration=False,reason='JohnsonSU fixed candidate worsens WIS vs CQR in both tasks; CAISO extrapolation produces enormous intervals. Retain CQR and every failed result; no price change.',stability_trace='DISTRIBUTION_STABILITY_TRACE.csv'),components=dict(status='paired date/block uncertainty added',scope='post-selection development; complete table retained'),fair_inputs=dict(status='registered_QA_passed_pending_training'),new_candidate_automatically_queued=False))
  print(json.dumps(dict(status='audited',checks=checks,protected=18)))
if __name__=='__main__':main()
