"""Cross-conditioned gated values; original fusion and decoder remain explicit."""
import torch
from torch import nn
from torch.nn import functional as F

class GatedValue(nn.Module):
    def __init__(self):
        super().__init__()
        self.self_value=nn.Linear(32,16);self.cross_value=nn.Linear(32,16)
        self.self_gate=nn.Linear(32,16);self.cross_gate=nn.Linear(32,16)
        self.out=nn.Linear(16,32)
        nn.init.zeros_(self.out.weight);nn.init.zeros_(self.out.bias)
    def forward(self,own,other):
        a=F.layer_norm(own,(32,));b=F.layer_norm(other,(32,))
        value=F.elu(self.self_value(a)+self.cross_value(b))
        gate=torch.sigmoid(self.self_gate(a)+self.cross_gate(b))
        return own+self.out(value*gate)

class Adapter(nn.Module):
    def __init__(self,seed):
        super().__init__()
        with torch.random.fork_rng(devices=[]):
            torch.manual_seed(seed+2100000)
            self.local=GatedValue();self.long=GatedValue()
    def forward(self,t,z):return self.local(t,z),self.long(z,t)

def encode(base,x,variant):
    from models.model_feature_fusion_rev12 import FeatureFusionModel
    encoded,adj,context=base.graph(x);t=base.tcn(encoded)
    b,_,n,d=encoded.shape
    low=FeatureFusionModel.low_frequency_history(encoded)
    seq=low.permute(0,2,3,1).reshape(b*n,d,-1)
    z=base.transformer(F.avg_pool1d(seq,6,6,ceil_mode=True).transpose(1,2)).reshape(b,n,d)
    w=base.attention(t,z,context) if variant=='FULL' else x.new_full((b,n,12,2),.5)
    price=base.price_context(base.observed_context(x))
    return dict(t=t,z=z,w=w,price=price),adj

def decode(base,variant,features,adapter=None):
    t,z,w,price=(features[k] for k in ('t','z','w','price'))
    if adapter is not None:t,z=adapter(t,z)
    if variant=='FULL':fused=w[...,:1]*t.unsqueeze(2)+w[...,1:]*z.unsqueeze(2)
    elif variant=='EQUAL':fused=(.5*t.unsqueeze(2)+.5*z.unsqueeze(2)).expand(-1,-1,12,-1)
    elif variant=='CONCAT':fused=base.concat_projection(torch.cat((t,z),-1)).unsqueeze(2).expand(-1,-1,12,-1)
    else:raise ValueError(variant)
    return base.head(fused+price.unsqueeze(2))

def manual(adapter,t,z):
    def one(m,a,b):
        a0=F.layer_norm(a,(32,));b0=F.layer_norm(b,(32,))
        val=F.elu(F.linear(a0,m.self_value.weight,m.self_value.bias)+F.linear(b0,m.cross_value.weight,m.cross_value.bias))
        g=torch.sigmoid(F.linear(a0,m.self_gate.weight,m.self_gate.bias)+F.linear(b0,m.cross_gate.weight,m.cross_gate.bias))
        return a+F.linear(val*g,m.out.weight,m.out.bias)
    return one(adapter.local,t,z),one(adapter.long,z,t)
