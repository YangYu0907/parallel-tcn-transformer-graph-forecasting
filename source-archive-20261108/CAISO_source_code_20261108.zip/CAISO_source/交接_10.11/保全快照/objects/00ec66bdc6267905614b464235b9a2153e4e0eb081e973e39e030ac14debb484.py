"""Finite CDF recalibration, on existing forward development folds only.

Kuleshov et al. ICML2018 motivates monotone PIT recalibration. Observable-state
stratification is our fixed diagnostic, not a reproduction of Song et al.2019.
No neural refit, new test access, threshold search or automatic promotion.
"""
from pathlib import Path
import sys, os, time, gc, json, traceback
P = Path(__file__).resolve().parent
R = P.parent
sys.path.insert(0, str(R/'compatibility_execution_20261004'))
import run as compatibility
prior = compatibility.prior
c = prior.c
np = prior.np
Q = prior.Q
ARMS = ['IDENTITY', 'GLOBAL', 'OBSERVABLE']

def write(name, value):
    c.write(P/name, value)

def guard(start=False):
    for d in [P, compatibility.P, prior.P, prior.H]:
        for name in ['STOP_REQUESTED','STOP_REQUESTED.json']:
            if (d/name).exists(): raise InterruptedError('Local stop '+str(d/name))
    return c.guard(start)

def weighted_quantiles(values, weights, levels):
    order = np.argsort(values, kind='stable')
    x, w = values[order], weights[order]
    # Inverse weighted empirical CDF. Exact generalized inverse; no extrapolation.
    cumulative = np.cumsum(w)/w.sum()
    j = np.minimum(np.searchsorted(cumulative, levels, side='left'), len(x)-1)
    return x[j]

def learn_maps(q, residual, days, origins, observable, calibration_mask, horizon):
    # This API receives calibration labels only. Realized S0-S5 is never input.
    mask = calibration_mask & (horizon >= 4)
    assert mask.any()
    pit = prior.distribution.cdf_numpy(q[mask], residual[mask])
    ds, oo, ob = days[mask], origins[mask], observable[mask]
    maps = {}
    for key in ['global'] + [str(int(v)) for v in sorted(np.unique(ob))]:
        take = np.ones(len(pit),bool) if key=='global' else ob==int(key)
        ud, inverse, counts = np.unique(ds[take], return_inverse=True, return_counts=True)
        n_orig = len(np.unique(oo[take]))
        eligible = len(ud)>=5 and n_orig>=30
        if key=='global': assert eligible, 'Insufficient calibration dates/origins'
        entry = dict(cells=int(take.sum()),dates=len(ud),origins=n_orig,eligible=bool(eligible))
        if eligible:
            weights = 1./counts[inverse]
            entry['inverse_levels'] = np.clip(weighted_quantiles(pit[take], weights, Q),1e-6,1-1e-6).tolist()
            entry['pit_cdf_at_grid'] = [float(np.average(pit[take]<=u,weights=weights)) for u in Q]
        maps[key] = entry
    return maps

def inverse_original(q, levels):
    """Inverse of the existing 13-quantile CDF including its fixed tails."""
    levels = np.broadcast_to(np.asarray(levels,float), q.shape)
    j = np.clip(np.searchsorted(Q, levels, side='right')-1,0,len(Q)-2)
    a = np.take_along_axis(q,j,axis=1)
    b = np.take_along_axis(q,j+1,axis=1)
    out = a+(b-a)*(levels-Q[j])/(Q[j+1]-Q[j])
    ls = np.maximum((q[:,1]-q[:,0])/np.log(Q[1]/Q[0]),1e-8)[:,None]
    rs = np.maximum((q[:,-1]-q[:,-2])/np.log((1-Q[-2])/(1-Q[-1])),1e-8)[:,None]
    out = np.where(levels<Q[0],q[:,0,None]+ls*np.log(levels/Q[0]),out)
    out = np.where(levels>Q[-1],q[:,-1,None]-rs*np.log((1-levels)/(1-Q[-1])),out)
    return out

def apply_maps(q, observable, horizon, maps, conditional):
    # Runtime inputs: frozen forecast, issue-time state, horizon, calibration map.
    out = q.copy()
    eligible = horizon>=4
    active_local = np.zeros(len(q),bool)
    for state in np.unique(observable[eligible]):
        use = eligible & (observable==state)
        key = str(int(state))
        local = conditional and key in maps and maps[key]['eligible']
        entry = maps[key] if local else maps['global']
        out[use] = inverse_original(q[use],entry['inverse_levels'])
        active_local[use] = local
    # The 13-knot projection is the actual forecast being scored. Keep a strictly
    # increasing numerical representation; this is not an exact continuous R(F).
    for j in range(1,len(Q)): out[:,j]=np.maximum(out[:,j],out[:,j-1]+1e-8)
    assert np.array_equal(out[~eligible],q[~eligible])
    return out, active_local

def qa():
    rng=np.random.default_rng(107)
    q=np.cumsum(rng.uniform(.01,1,(360,len(Q))),axis=1)-3
    lev=np.broadcast_to(Q,q.shape)
    assert np.allclose(inverse_original(q,lev),q)
    pp=np.broadcast_to(np.linspace(.001,.999,len(Q)),q.shape)
    x=inverse_original(q,pp)
    err=max(float(np.max(abs(prior.distribution.cdf_numpy(q,x[:,j])-pp[:,j]))) for j in range(len(Q)))
    assert err<1e-7
    h=np.tile(np.arange(12),30);days=np.repeat(np.arange(10),36);orig=np.arange(360)
    ob=np.arange(360)%3;cm=days<6;res=rng.normal(size=360)
    m=learn_maps(q,res,days,orig,ob,cm,h)
    other=res.copy();other[~cm]=1e9
    assert m==learn_maps(q,other,days,orig,ob,cm,h)
    a,_=apply_maps(q,ob,h,m,True)
    assert np.isfinite(a).all() and (np.diff(a,axis=1)>0).all()
    assert np.array_equal(a[h<4],q[h<4])
    delta,_,ae,se=compatibility.action(a,(h>=4).astype(float))
    assert ae.max()<1e-7 and se.max()<1e-7
    return dict(status='passed',inverse_CDF_max_error=err,future_labels_invariant=True,
        ordering=True,near_exact=True,synthetic_rows=360)

def register():
    if (P/'PROTOCOL.json').exists():return
    guard(True)
    sources=[Path(__file__),Path(compatibility.__file__),Path(prior.__file__),Path(prior.distribution.__file__),
        R/'common.py',c.FIRST/'revision_common.py',prior.P/'PROTOCOL.json',prior.P/'AUDIT.json',prior.H/'WINDOWS.json']
    for w in [1,2,3]:
        for seed in c.SEEDS:
            for info in ['old','new']:
                case=prior.P/'fits'/f'w{w}_{seed}_{info}'
                sources.extend([case/'COMPLETE.json',case/('B.npz' if info=='old' else 'D.npz')])
    assert c.verify_protected()==18
    write('QA.json',qa())
    write('PROTOCOL.json',dict(at=c.now(),registered_before_fit=True,
        scope='Known development428origins/28dates;3forwardwindows,3seeds,2matched information sets. Already viewed development, not untouched confirmation.',
        hypothesis='Does calibrating the whole predictive CDF improve realized loss decisions and proper probability scores?',
        primary='OBSERVABLE;GLOBAL is the mandatory mechanism ablation;IDENTITY is unchanged priorCDF. No winner search.',
        fit='Weighted empirical PIT inverse map on held calibration labels only, equal total weight per UTCdate. 13fixedquantiles;globalmap plus issue-time observable regime map if>=5dates and>=30origins,elseglobal. Fixed support policy,not literature optimal.',
        forecast='Quantile projection Q_original(R_inverse(Q));original interpolation/exponential tails reconstruct13knots;strictmonotone1e-8repair;unchangedH1-H4. No future states for routing.',
        decision='EachCDF produces a median-sign min(abs(median),2abs(mean)) action if mean*median>0 else0;H1-H4zero. SamepointusedforMAEandRMSE. Distribution median also scored separately.',
        theory='Kuleshov2018 monotonePITrecalibration;Song2019 globalcalibration doesnot implyconditionalcalibration. Observable stratification anddayweighting are our implementation,not their theorem. No iidcoverage or per-origin safety guarantee.',
        references=['https://proceedings.mlr.press/v80/kuleshov18a.html','https://proceedings.mlr.press/v97/song19a.html'],
        calibration_reuse='Same heldcalalreadyusedforpriorCQR;this is extra fitted postprocessing. Calibration-set accuracy is not validation. Only nexttimeblockusedforreported evaluation.',
        evaluations='AllS0-S5,horizons,months,nodes,issue-timeobservablegroups,lowvolatility;cells/origins/dates;seedresults;WIS,pinball,coverage,width,Brier,logloss;PITreliability only global andissue-timeconditions.',
        acceptance='PrimarymustimproveoverallMAEandRMSEvsV7andIDENTITY andnotregressanyregisteredstate,horizon,lowvolatility,window;preserveearlypointsbitwise. ProbabilitymustimproveWISwithoutcoverage/Briers/loglossregression. Any sparseeventsupport is insufficient,notpass. Noautomaticpromotion.',
        max_case_fits=18,max_local_maps_per_case=3,max_seconds=1200,automatic_extension=False,
        neural_fits=0,search=False,new_test_targets_read=False,V7_replaced=False,
        start_GiB=5,runtime_GiB=4,single_numeric_worker=True,
        bindings={str(x):c.sha(x) for x in sources} ))

def groups(d):
    out={'overall':np.ones(len(d['truth']),bool),'near':d['h']<4,'h12':d['h']==11,'low_volatility':d['low_volatility'].astype(bool)}
    for j in range(6):out[f'S{j}']=d['state']==j
    for j in range(12):out[f'H{j+1}']=d['h']==j
    for j in range(30):out[f'node{j}']=d['node']==j
    for j in np.unique(d['observable']):out[f'observable{j}']=d['observable']==j
    month=np.array([str(np.datetime64(int(x),'D'))[:7] for x in d['days']])
    for m in np.unique(month):out[m]=month==m
    return out

def case(w,seed,info):
    key=f'w{w}_{seed}_{info}';path=P/'cases'/f'{key}.json'
    if path.exists():
        v=c.read(path);assert v['protocol_sha256']==c.sha(P/'PROTOCOL.json');return v
    guard()
    d=prior.prepare_data(seed,w,info)
    with np.load(prior.P/'fits'/key/('B.npz' if info=='old' else 'D.npz')) as z:q=z['q'].copy()
    # No evaluation labels passed to the fitting function.
    cal=d['cal'];ev=d['evaluate']
    maps=learn_maps(q[cal],d['residual'][cal],d['days'][cal],d['origin'][cal],d['observable'][cal],np.ones(sum(cal),bool),d['h'][cal])
    q=q[ev]
    e={k:v[ev].copy() for k,v in d.items() if isinstance(v,np.ndarray) and v.ndim>=1 and len(v)==len(ev)}
    del d
    masks=groups(e);row={};output={};checks=[]
    near=e['h']<4
    for arm in ARMS:
        a=q if arm=='IDENTITY' else apply_maps(q,e['observable'],e['h'],maps,arm=='OBSERVABLE')[0]
        delta,mu,ea,es=compatibility.action(a,e['allow'])
        pred=e['point']+delta*e['scale']
        assert np.array_equal(pred[near],e['point'][near])
        assert ea.max()<1e-6 and es.max()<1e-6
        losses=prior.distribution.loss_arrays(a,e)
        # Same forecast for both point metrics. Probability losses target the
        # distribution; its median's errors remain separately visible.
        losses['decision_ae']=abs(pred-e['truth']);losses['decision_se']=(pred-e['truth'])**2
        losses['V7_ae']=abs(e['point']-e['truth']);losses['V7_se']=(e['point']-e['truth'])**2
        pit=prior.distribution.cdf_numpy(a,e['residual'])
        row[arm]={}
        for name,m in masks.items():
            if not m.any():continue
            v=dict(n=int(m.sum()),dates=len(np.unique(e['days'][m])),origins=len(np.unique(e['origin'][m])),
                scores={k:float(x[m].mean()) for k,x in losses.items() if not k.endswith('_probability')})
            if name=='overall' or name.startswith('observable') or name in ['near','h12']:
                _,iv,co=np.unique(e['days'][m],return_inverse=True,return_counts=True)
                weights=1./co[iv]
                v['date_balanced_pit_cdf']=[float(np.average(pit[m]<=u,weights=weights)) for u in Q]
                v['pit_reliability_mean_abs']=float(np.mean(abs(np.array(v['date_balanced_pit_cdf'])-Q)))
            row[arm][name]=v
        sample=np.linspace(0,len(pred)-1,512,dtype=int)
        alternate=compatibility.direct_absolute_risk(a[sample],delta[sample])-compatibility.direct_absolute_risk(a[sample],np.zeros(len(sample)))
        assert np.allclose(alternate,ea[sample],atol=1e-7)
        # Independent direct NumPy scoring (currencyunits).
        for name,m in masks.items():
            if m.any():assert abs(np.linalg.norm(pred[m]-e['truth'][m])**2/m.sum()-row[arm][name]['scores']['decision_se'])<1e-6
        checks.append(dict(arm=arm,near_exact=True,modeled_compatibility=True,alternate_AE_discrepancy=float(np.max(abs(alternate-ea[sample])))))
        output[arm+'_q']=a.copy();output[arm+'_point']=pred
    output.update(truth=e['truth'],V7=e['point'],origins=e['origin'],horizon=e['h'],states=e['state'],days=e['days'])
    predpath=P/'predictions'/f'{key}.npz';c.npz_save(predpath,**output)
    record=dict(at=c.now(),key=key,window=w,seed=seed,info=info,protocol_sha256=c.sha(P/'PROTOCOL.json'),
        maps=maps,rows=row,checks=checks,prediction_sha256=c.sha(predpath),prediction_path=str(predpath),
        new_test_targets_read=False)
    c.write(path,record);del output,q,e;gc.collect();return record

def aggregate(cases):
    out={}
    for info in ['old','new']:
        out[info]={}
        names=sorted({k for r in cases if r['info']==info for k in r['rows']['IDENTITY']})
        for name in names:
            out[info][name]={}
            for arm in ARMS:
                seeds=[]
                for seed in c.SEEDS:
                    rr=[r['rows'][arm][name] for r in cases if r['info']==info and r['seed']==seed and name in r['rows'][arm]]
                    n=sum(x['n'] for x in rr)
                    scores={k:sum(x['scores'][k]*x['n'] for x in rr)/n for k in rr[0]['scores']}
                    for stem in ['decision','V7']:
                        scores[stem+'_mae']=scores[stem+'_ae'];scores[stem+'_rmse']=float(np.sqrt(scores[stem+'_se']))
                    scores['median_mae']=scores['ae'];scores['median_rmse']=float(np.sqrt(scores['se']))
                    seeds.append(dict(seed=seed,n=n,scores=scores))
                out[info][name][arm]=dict(seeds=seeds,mean={k:float(np.mean([s['scores'][k] for s in seeds])) for k in seeds[0]['scores']})
    return out

def main():
    register();pr=c.read(P/'PROTOCOL.json')
    for path,expected in pr['bindings'].items():assert c.sha(path)==expected,path
    assert c.verify_protected()==18
    start=time.monotonic();records=[]
    try:
        with c.numeric('WholeCDFrecalibration18fixedcases;no neuraltraining'):
            for w in [1,2,3]:
                for seed in c.SEEDS:
                    for info in ['old','new']:
                        guard()
                        if time.monotonic()-start>pr['max_seconds']:raise TimeoutError('Finitecalibrationbudget')
                        write('STATUS.json',dict(at=c.now(),stage='running',pid=os.getpid(),completed=len(records),total=18))
                        records.append(case(w,seed,info));print(f'{len(records)}/18 calibration cases complete',flush=True)
        summary=aggregate(records)
        write('SUMMARY.json',dict(at=c.now(),scope=pr['scope'],results=summary))
        assert c.verify_protected()==18
        write('RESULT.json',dict(at=c.now(),status='completed',cases=18,
            empirical_maps=sum(sum(x['eligible'] for x in r['maps'].values()) for r in records),
            seconds=time.monotonic()-start,neural_fits=0,new_test_targets_read=False,V7_replaced=False,
            independent_confirmation=False,protected_files_unchanged=18,
            selected={info:{g:{arm:summary[info][g][arm]['mean'] for arm in ARMS} for g in ['overall','near','h12','low_volatility']+[f'S{s}' for s in range(6)]} for info in ['old','new']}))
        write('STATUS.json',dict(at=c.now(),stage='completed',active_worker=False,cases=18))
        print('Completed;V7 retained. No automatic follow-up.',flush=True)
    except Exception as exc:
        write('FAILURE.json',dict(at=c.now(),error=repr(exc),traceback=traceback.format_exc(),completed=len(records)))
        write('STATUS.json',dict(at=c.now(),stage='failed',active_worker=False))
        raise

if __name__=='__main__':main()
