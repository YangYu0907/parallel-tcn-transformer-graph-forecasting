"""Free finite DAM cached-source census; no new target access or model fitting."""
from pathlib import Path
from datetime import datetime,timedelta,timezone
from zoneinfo import ZoneInfo
import sys,os,time,json,zipfile,io,csv,traceback,requests,re
sys.path.insert(0,str(Path(__file__).resolve().parent.parent))
from io_utils import *
STATE=Path(__file__).resolve().parent
_original_verify=verify
def verify():
 p=_original_verify()
 recovery=read(STATE/'PROTOCOL.json');qa=read(STATE/'QA.json')
 assert qa['passed']
 for filename,h in recovery['bindings'].items():assert s.sha(filename)==h,filename
 assert not (D/'MANAGER.lock').exists(),'Original source manager lock exists'
 return p
_original_guard=guard
def guard(launch=False):
 for name in ['STOP_REQUESTED','STOP_REQUESTED.json']:
  if (STATE/name).exists():raise InterruptedError('User stop '+str(STATE/name))
 return _original_guard(launch)
import psutil
Q=W/'dam_xml_1009'
# Load the sealed streaming extractor by path without shadowing other compare modules.
import importlib.util
spec=importlib.util.spec_from_file_location('xml_source_parser',Q/'compare.py');parser=importlib.util.module_from_spec(spec);spec.loader.exec_module(parser)
LAST_REQUEST=0.
def request(job,progress):
 global LAST_REQUEST
 dest=D/'raw'/(job['id']+'.zip');receipt=D/'rx'/(job['id']+'.json')
 if receipt.exists():
  old=read(receipt);assert dest.exists() and s.sha(dest)==old['sha256'];return dict(old,transport_reused=True)
 dest.parent.mkdir(exist_ok=True);attempts=[]
 for attempt in range(1,7):
  wait_safe(max(0,5-(time.monotonic()-LAST_REQUEST)));LAST_REQUEST=time.monotonic();tmp=dest.with_name('.part');size=0;last=time.monotonic()
  try:
   progress(stage='requesting',job=job['id'],attempt=attempt)
   with requests.get(job['url'],stream=True,timeout=(15,45)) as response:
    if response.status_code in [401,403]:raise PermissionError('Source authentication/access required: HTTP'+str(response.status_code))
    response.raise_for_status()
    headers={k:v for k,v in response.headers.items() if k.lower() in ['date','etag','last-modified','content-type','content-disposition']}
    with tmp.open('wb') as f:
     for block in response.iter_content(32768):
      size+=len(block)
      if size>80000000:raise ValueError('Per-response80MB source cap exceeded')
      f.write(block)
      if time.monotonic()-last>3:progress(stage='downloading',job=job['id'],attempt=attempt,bytes=size);last=time.monotonic()
   with zipfile.ZipFile(tmp) as z:
    assert z.namelist()
    errors=[]
    for n in z.namelist():
     if z.getinfo(n).file_size<8192:
      with z.open(n) as f:head=f.read(8192).decode('utf-8',errors='replace')
      errors+=re.findall(r'<(?:\w+:)?ERR_CODE>(.*?)</(?:\w+:)?ERR_CODE>',head)
   if any(c in ['1015','1016','1017'] for c in errors):raise requests.ConnectionError('OASIS transient request failure '+str(errors))
   if errors and any(c!='1000' for c in errors):raise ValueError('Unexpected OASIS semantic error '+str(errors))
   os.replace(tmp,dest)
   result=dict(at=s.now(),url=job['url'],sha256=s.sha(dest),bytes=size,headers=headers,error_codes=errors,attempts=attempts,original_zip=str(dest))
   write(receipt,result);return result
  except (requests.ConnectionError,requests.Timeout,requests.HTTPError,requests.exceptions.ChunkedEncodingError,requests.exceptions.ContentDecodingError) as e:
   status=getattr(getattr(e,'response',None),'status_code',None)
   attempts.append(dict(at=s.now(),attempt=attempt,error=repr(e),received_bytes=size));write(D/'retry'/(job['id']+'.json'),attempts)
   if attempt==6 or (status is not None and status not in [408,429] and status<500):raise
   progress(stage='transient_retry',job=job['id'],attempt=attempt,error=repr(e));wait_safe(min(60,10*attempt))
def stamp(x):return datetime.fromisoformat(x).timestamp()
def analyze(job,receipt,pubs,nodes):
 day=job['date'];p=Path(receipt['original_zip']);code=job['id'];result=dict(at=s.now(),date=day,source_sha256=receipt['sha256'],source_path=str(p),admitted=False,admission_scope='retrospective publisher-cached-file reconstruction only; not contemporaneous user capture')
 if receipt['error_codes']:
  result['reason']='official_no_data';write(D/'days'/(code+'.json'),result);return result
 with zipfile.ZipFile(p) as arc:
  member=next(n for n in arc.namelist() if '_DAM_MCC_' in n and n.endswith('.xml'))
  with arc.open(member) as f:head=f.read(16384).decode('utf-8')
  timedate=re.findall(r'<TimeDate>(.*?)</TimeDate>',head);assert len(timedate)==1
  generated=stamp(timedate[0]);local=datetime.fromisoformat(day).replace(tzinfo=ZoneInfo('America/Los_Angeles'));start=local.timestamp();end=(local+timedelta(days=1)).timestamp()
  assert '<MKT_TYPE>DAM</MKT_TYPE>' in head and '<REPORT>PRC_LMP</REPORT>' in head and '<Source>OASIS</Source>' in head
 result.update(payload_time=timedate[0],generation_utc=generated,start_utc=start,end_utc=end)
 # Receipt is a distinct publication witness, not a file version identifier.
 candidates=[r for r in pubs if r.get('OPR_DT')==day and r.get('STATUS')=='Push Completed' and r.get('REPORT_NAME')=='PRC_LMP' and r.get('MARKET_RUN_ID')=='DAM' and stamp(r['INTERVAL_START_GMT'])==start and stamp(r['INTERVAL_END_GMT'])==end and abs(stamp(r['PUBLICATION_DATE_GMT'])-generated)<=900]
 result['publication_witnesses']=candidates
 if generated>=start:result['reason']='payload_created_after_delivery_start'
 elif not candidates:result['reason']='no_nearby_matching_publication_witness'
 else:
  available=max([generated]+[stamp(r['PUBLICATION_DATE_GMT']) for r in candidates])
  if available>=start:result['reason']='publication_not_before_delivery_start'
  else:
   values,meta=parser.parse(p,nodes);hours=int((end-start)/3600)
   from decimal import Decimal
   assert all(Decimal(v).is_finite() for v in values.values()),'Nonfinite MCC source values'
   expected={(n,start+3600*h,start+3600*(h+1)) for n in nodes for h in range(hours)}
   actual={(k[0],stamp(k[1]),stamp(k[2])) for k in values}
   if actual!=expected:result.update(reason='node_or_hour_coverage_mismatch',expected_rows=len(expected),actual_rows=len(actual))
   else:
    result.update(admitted=True,reason='exact_cached_payload_plus_contemporaneous_publication_witness',available_by=available,selected_rows=len(values),expected_hours=hours,header=meta['header'],rows=[dict(node=k[0],start=stamp(k[1]),end=stamp(k[2]),MCC=v) for k,v in sorted(values.items())])
 write(D/'days'/(code+'.json'),result);return result
def main():
 start=time.monotonic();lock=STATE/'MANAGER.lock'
 with lock.open('x') as f:json.dump(dict(pid=os.getpid(),created=psutil.Process().create_time()),f)
 done=0;admitted=0;network=0;times=[]; prior_seconds_per_day=77.2329
 def status(**kw):write(STATE/'STATUS.json',dict(at=s.now(),pid=os.getpid(),**kw))
 def tick(**kw):
  rss=psutil.Process().memory_info()
  record=dict(at=s.now(),pid=os.getpid(),elapsed_seconds=time.monotonic()-start,completed_days=done,admitted_days=admitted,requested_days=706,downloaded_bytes=network,rss_MiB=rss.rss/2**20,resources=guard(),**kw)
  perday=sum(times[-20:])/len(times[-20:]) if times else prior_seconds_per_day
  record.update(recent_seconds_per_day=perday,estimated_remaining_hours=(706-done)*perday/3600,prior_checkpoint_days=96,recovery=True)
  write(STATE/'PROGRESS.json',record)
 try:
  protocol=verify();guard(True);status(event='awaiting_exit_monitor_binding')
  while not (STATE/'START_READY.json').exists():
   if time.monotonic()-start>55:raise TimeoutError('Exit monitor receipt missing')
   time.sleep(.2)
  ready=read(STATE/'START_READY.json');assert ready['manager_pid']==os.getpid()
  assert abs((ready['manager_start_utc_ticks']-621355968000000000)/1e7-psutil.Process().create_time())<.01
  receipt=read(ready['receipt']);assert receipt['manager_pid']==os.getpid() and receipt['watcher_pid']==ready['exit_monitor_pid'] and psutil.pid_exists(ready['exit_monitor_pid'])
  status(event='step_process_started',stage='706_day_cached_source_census',model_fits=0)
  pubs=[]
  for job in protocol['publication_jobs']:
   receipt=request(job,tick);network+=0 if receipt.get('transport_reused') else receipt['bytes'];guard()
   with zipfile.ZipFile(receipt['original_zip']) as arc:
    for member in arc.namelist():
     if not member.lower().endswith('.csv'):continue
     with arc.open(member) as f:pubs.extend(r for r in csv.DictReader(io.TextIOWrapper(f,encoding='utf-8-sig')) if r.get('REPORT_NAME')=='PRC_LMP' and r.get('MARKET_RUN_ID')=='DAM')
  unique={json.dumps(r,sort_keys=True):r for r in pubs};pubs=list(unique.values());write(D/'PUB_LEDGER.json',pubs)
  nodes=set(read(B/'dataset/compiled_train_june/manifest.json')['nodes']);summaries=[];pending=[]
  for job in protocol['day_jobs']:
   started=time.monotonic();path=D/'days'/(job['id']+'.json')
   reused_day=path.exists()
   if reused_day:
    row=read(path);assert s.sha(row['source_path'])==row['source_sha256']
   else:
    try:
     receipt=request(job,tick);network+=0 if receipt.get('transport_reused') else receipt['bytes'];tick(stage='source_day_review',date=job['date']);row=analyze(job,receipt,pubs,nodes)
    except (requests.Timeout,requests.ConnectionError,requests.HTTPError,requests.exceptions.ChunkedEncodingError,requests.exceptions.ContentDecodingError) as e:
     pending.append(job);write(D/'PENDING.json',dict(at=s.now(),jobs=pending,last_error=repr(e)));continue
   done+=1;admitted+=int(row['admitted'])
   if not reused_day:times.append(time.monotonic()-started)
   summaries.append({k:v for k,v in row.items() if k not in ['rows','publication_witnesses']});tick(stage='day_complete',date=job['date'])
  # One deferred transport-only pass; model/data choices never change with results.
  unresolved=[]
  for job in pending:
   try:
    receipt=request(job,tick);network+=0 if receipt.get('transport_reused') else receipt['bytes'];row=analyze(job,receipt,pubs,nodes)
    done+=1;admitted+=int(row['admitted']);summaries.append({k:v for k,v in row.items() if k not in ['rows','publication_witnesses']});tick(stage='deferred_day_complete',date=job['date'])
   except (requests.Timeout,requests.ConnectionError,requests.HTTPError,requests.exceptions.ChunkedEncodingError,requests.exceptions.ContentDecodingError) as e:unresolved.append(dict(job=job,error=repr(e)))
  verify()
  result=dict(at=s.now(),status='finite_source_census_complete' if not unresolved else 'source_census_transport_incomplete',requested_days=len(protocol['day_jobs']),completed_days=done,admitted_days=admitted,excluded_days=done-admitted,unresolved=unresolved,days=summaries,elapsed_seconds=time.monotonic()-start,source_class='publisher-cached XML + near-time publication-log corroboration, retrospective reconstruction',whole_archive_admitted=False,independent_person_review=False,new_model_fits=0,new_test_targets_read=False,whole_research_completed=False,next='Continue automatically: independently replay source filters and as-of join; require fixed-fold support; refit HISTORY/COARSE and their DAM additions on exactly matched admitted rows. Do not await a user continue prompt. If transport unresolved, repair checkpoint without duplicate completed downloads.')
  write(STATE/'RESULT.json',result);eid=s.emit('needs_analysis' if not unresolved else 'blocking_failure',STATE/'RESULT.json');status(event='finite_mechanism_queue_completed',event_id=eid,whole_research_completed=False)
 except InterruptedError as e:status(event='user_stop_at_stage_boundary',classification='user_stop',error=str(e))
 except BaseException as e:
  write(STATE/'FAILURE.json',dict(at=s.now(),error=repr(e),traceback=traceback.format_exc(),completed_days=done,automatic_continuation=True));eid=s.emit('blocking_failure',STATE/'FAILURE.json');status(event='step_stopped_or_failed',event_id=eid,error=repr(e))
 finally:
  if lock.exists() and read(lock)['pid']==os.getpid():lock.unlink()
if __name__=='__main__':main()
