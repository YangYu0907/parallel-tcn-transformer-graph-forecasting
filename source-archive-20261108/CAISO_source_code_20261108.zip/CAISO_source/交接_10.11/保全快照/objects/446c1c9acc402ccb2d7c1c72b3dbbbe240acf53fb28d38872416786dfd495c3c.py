"""Independent dictionary/set replay of the unchanged information windows."""
from pathlib import Path
from collections import Counter
import sys
HERE=Path(__file__).resolve().parent
B=HERE.parent
sys.path.insert(0,str(B/'context_expert_v1_20260929'))
import gate
reader=gate.load('v17_meta_rows',B/'stress_source_feasibility_v16_20260930/audit_renewable.py')


def main():
    with gate.exclusive('V17 separate full metadata-window audit; no market values'):
        root=HERE/'full_metadata'
        result=gate.read(root/'RESULT.json')
        keys=('price','rtd','dam_load','dam_renewable')
        latest={k:{} for k in keys};initial={}
        a,b=reader.stamp('2026-08-17T00:00:00Z'),reader.stamp('2026-09-30T00:00:00Z')
        for item in result['receipts']:
            assert gate.sha(item['source_receipt'])==item['source_receipt_sha256']
            rec=gate.read(item['source_receipt']);body=rec['body']
            assert gate.sha(body)==item['source_sha256']
            params=rec.get('params') or rec['job']['params']
            market=params['market_run_id']
            reports=({'PRC_INTVL_LMP':'price'} if market=='RTM' else {'SLD_FCST':'rtd'} if market=='RTD'
                     else {'SLD_FCST':'dam_load','SLD_REN_FCST':'dam_renewable'})
            gate.guard()
            for r in reader.rows(body):
                k=reports.get(r.get('REPORT_NAME'))
                if k is None or r['STATUS']!='Push Completed' or r['OASIS_REC_STAT']!='V':continue
                lo,hi,pub=[reader.stamp(r[f]) for f in ('INTERVAL_START_GMT','INTERVAL_END_GMT','PUBLICATION_DATE_GMT')]
                for t in range(max(a,lo),min(b,hi),300):
                    latest[k][t]=max(latest[k].get(t,0),pub)
                    if k=='price' and r['ATLPUBVERSION']=='New':initial[t]=min(initial.get(t,pub),pub)
        rows=gate.read(root/'source_screen/origins.json')
        expected=list(range(reader.stamp('2026-09-01T00:00:00Z'),b-3300,3600))
        assert [reader.stamp(r['target_start_utc']) for r in rows]==expected
        reasons=Counter();days=Counter()
        for row,origin in zip(rows,expected):
            cut=origin-300;flags=[]
            price=list(range(origin-864*300,origin,300))
            price+=list(range(origin-2304*300,origin-2016*300,300))
            price+=list(range(origin-4320*300,origin-4032*300,300))
            if any(t not in latest['price'] for t in price):flags.append('price_publication_coverage_gap')
            if any(latest['price'].get(t,0)>cut for t in price):flags.append('price_latest_publication_after_cutoff')
            o=(origin-a)//300;qs=a+((o-1)//12-23)*3600;qe=a+((o+11)//12+1)*3600
            for k,(left,right) in {'rtd':(origin-86400,origin),'dam_load':(origin-86400,qe),'dam_renewable':(qs,qe)}.items():
                if any(t not in latest[k] for t in range(left,right,300)):flags.append(k+'_publication_coverage_gap')
                if any(latest[k].get(t,0)>cut for t in range(left,right,300)):flags.append(k+'_latest_publication_after_cutoff')
            target=range(origin,origin+3600,300)
            if any(t not in initial for t in target):flags.append('target_initial_publication_missing')
            elif any(initial[t]<=cut for t in target):flags.append('a_target_initial_publication_not_after_cutoff')
            assert row['reasons']==flags and row['metadata_candidate']==(not flags)
            reasons.update(flags)
            if not flags:days[row['target_start_utc'][:10]]+=1
        summary=gate.read(root/'source_screen/SUMMARY.json')
        assert sum(days.values())==summary['metadata_candidates'] and dict(reasons)==summary['all_reason_counts']
        gate.write(root/'source_screen/AUDIT.json',dict(at=gate.now(),status='passed_timestamp_metadata_only',
            registered_origins=len(rows),candidates=sum(days.values()),candidate_dates=dict(days),
            audit_type='Separate raw-ledger and explicit timestamp-set recomputation; same operator',
            origins_sha256=gate.sha(root/'source_screen/origins.json'),
            summary_sha256=gate.sha(root/'source_screen/SUMMARY.json'),
            result_sha256=gate.sha(root/'RESULT.json'),source_values_read=False,independent_period_admitted=False))
        print('Separate full metadata audit passed: '+str(sum(days.values()))+' candidates on '+str(len(days))+' UTC dates.')


if __name__=='__main__':main()
