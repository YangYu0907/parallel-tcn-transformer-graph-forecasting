"""Separate arithmetic and inference replay, same operator (not outside human review)."""
from core import *
import numpy as np

def main():
    verify()
    with numeric('integrated experiment separate arithmetic and replay audit'):
        import torch
        from fair_inputs import PriceModel,runtime
        runtime();tick=timer('audit');r=read(HERE/'RESULT.json');checks=0
        for fn,key in [('REPLAY.npz','prediction_sha256'),('CALIBRATION_REPLAY.npz','calibration_sha256'),('PROBABILITY_REPLAY.npz','probability_sha256')]:
            assert sha(HERE/fn)==r[key];checks+=1
        with np.load(HERE/'REPLAY.npz') as z:d={k:z[k] for k in z.files}
        with np.load(HERE/'CALIBRATION_REPLAY.npz') as z:cal={k:z[k] for k in z.files}
        y=d['truth'];ss=d['states'];raw,times,_,_=arrays()
        for row in r['rows']:
            e=d[row['model']]-y
            recomputed=[np.sum(abs(e))/e.size,np.linalg.norm(e.ravel())/np.sqrt(e.size),np.sum(abs(e[:,:,:4]))/e[:,:,:4].size,np.sum(abs(e[:,:,-1]))/e[:,:,-1].size]
            assert np.allclose(recomputed,[row[k] for k in ['mae','rmse','near_mae','h12_mae']],rtol=1e-10,atol=1e-10);checks+=4
        for group in r['states']:
            for row in group['states']:
                mask=ss==row['state'];e=(d[group['model']]-y)[mask]
                assert row['cells']==len(e) and row['dates']==len(np.unique(d['days'][mask.any((1,2))]));checks+=2
                if len(e):assert np.allclose([abs(e).mean(),np.sqrt(np.dot(e,e)/len(e))],[row['mae'],row['rmse']],rtol=1e-10);checks+=2
        for row in r['router_details']:
            name=row['model'];q=row['calibration'];a=cal[name]-cal['truth'];b=cal['FULL']-cal['truth']
            tests=[abs(a).mean()<=abs(b).mean()+1e-6,(a*a).mean()**.5<=(b*b).mean()**.5+1e-6,
                   bool(np.all(abs(a).mean((0,1))<=abs(b).mean((0,1))+1e-6))]
            support=[]
            for s in range(6):
                m=cal['states']==s;support.append(len(np.unique(cal['days'][m.any((1,2))]))>=5)
                tests.append(bool(m.any() and abs(a[m]).mean()<=abs(b[m]).mean()+1e-6 and np.sqrt((a[m]**2).mean())<=np.sqrt((b[m]**2).mean())+1e-6))
            assert q['passed']==bool(all(tests+support));checks+=1
            assert np.array_equal(d[name+'_CHECKED'],d[name] if q['passed'] else d['FULL']);checks+=1
            assert np.array_equal(d[name][:,:,:7],d['FULL'][:,:,:7]);checks+=1
        for fold in range(3):
            z=np.load(HERE/f'fold{fold}_origins.npz');st=read(HERE/f'fold{fold}_stats.json')['neural'];ev=z['evaluate']
            assert times[z['train'].max()+11]<times[ev.min()-1]-86400;checks+=1
            for name in ['FULL_price_only','iTransformer_price_only']:
                tick(fold=fold,model=name);folder=HERE/f'fold{fold}'/name;proof=read(folder/'COMPLETE.json')
                assert sha(folder/'latest.pt')==proof['checkpoint_sha256'] and sha(folder/'PREDICTIONS.npz')==proof['prediction_sha256'];checks+=2
                saved=np.load(folder/'PREDICTIONS.npz');ids=np.array([0,len(ev)//2,len(ev)-1]);x,_=neural_batch(raw,ev[ids],st)
                ck=torch.load(folder/'latest.pt',map_location='cpu',weights_only=False);m=PriceModel(name,SEEDS[0],st['limits']);m.load_state_dict(ck['model']);m.eval()
                with torch.no_grad():p=m(torch.from_numpy(x)).numpy().astype(float)*np.array(st['scale'])[None,:,None]+np.array(st['center'])[None,:,None]
                assert np.allclose(p,saved['prediction'][ids],atol=1e-4,rtol=1e-5);checks+=1
        with np.load(HERE/'PROBABILITY_REPLAY.npz') as z:
            for row in r['probability']:
                b=z[row['model']+'_'+row['method']];p=d[row['model']];score=.5*abs(p-y)
                for i,alpha in enumerate([.1,.2]):
                    lo=b[...,i,0];hi=b[...,i,1];v=hi-lo+2/alpha*((lo-y)*(y<lo)+(y-hi)*(y>hi))
                    score+=alpha*.5*v
                    assert np.allclose([((y>=lo)&(y<=hi)).mean(),(hi-lo).mean(),v.mean()],
                        [row['intervals'][i][k] for k in ['coverage','width','interval_score']]);checks+=3
                assert abs(score.mean()/2.5-row['wis'])<1e-9;checks+=1
        # Average losses over router seeds; seeds are not independent observations.
        avg=np.mean([abs(d[f'COMPLETE_{s}']-y) for s in SEEDS],axis=0).mean((1,2))
        family={k:abs(d[k]-y).mean((1,2)) for k in ['FULL','iTransformer','SPIKE','FIXED25','FIXED50','FIXED_THREE']}
        for arm in ['NO_SPIKE','NO_RISK']:family[arm]=np.mean([abs(d[f'{arm}_{s}']-y).mean((1,2)) for s in SEEDS],axis=0)
        block=d['days']//7;unique=np.unique(block);rng=np.random.default_rng(20261003)
        counts=np.array([(block==b).sum() for b in unique]);boot=rng.integers(0,len(unique),(2000,len(unique)));stats=[]
        for name,error in family.items():
            delta=error-avg;sums=np.array([delta[block==b].sum() for b in unique]);samples=sums[boot].sum(1)/counts[boot].sum(1)
            centered=samples-delta.mean();pval=(1+np.sum(abs(centered)>=abs(delta.mean())))/(len(samples)+1)
            stats.append(dict(control=name,mae_difference=float(delta.mean()),ci95=np.quantile(samples,[.025,.975]).tolist(),p=float(pval)))
        ordered=np.argsort([s['p'] for s in stats]);prior=0
        for j,idx in enumerate(ordered):prior=max(prior,min(1.,stats[idx]['p']*(len(stats)-j)));stats[idx]['holm_p']=prior
        write(HERE/'STATISTICS.json',dict(status='exploratory_development_statistics',method='Paired resampling of fixed seven-calendar-day bins; actual gaps retained; 2000 replicates; mean losses across router seeds; eight-control Holm family',
            dates=len(np.unique(d['days'])),calendar_blocks=len(unique),rows=stats,confirmatory=False))
        verify();write(HERE/'AUDIT.json',dict(at=now(),status='separate_arithmetic_and_inference_replay_passed',checks=checks,
            result_sha256=sha(HERE/'RESULT.json'),statistics_sha256=sha(HERE/'STATISTICS.json'),screen_passed=r['screen_passed'],
            V7_replaced=False,new_test_targets_read=False,protected_files=18,external_human_review=False))
        tick(status='complete')

if __name__=='__main__':main()
