"""Verify recorded access scope and earlier-only library, without new target reads."""
from pathlib import Path
from datetime import datetime, timezone
import sys, subprocess
HERE=Path(__file__).resolve().parent;B=HERE.parent
sys.path.insert(0,str(B/'context_expert_v1_20260929'))
import gate
ART=Path('C:/Users/于阳/CAISO_temporary_storage')/HERE.name
OLD=B/'chronological_expert_pilot_v14_20260930'
OLDART=ART.parent/OLD.name
def stamp(s):return int(datetime.fromisoformat(s.replace('Z','+00:00')).timestamp())
def main():
    with gate.exclusive('V17 preregistered pilot compatibility and access-history review'):
        np,limiter=gate.runtime(False)
        audit=gate.read(HERE/'source_admission/AUDIT.json');assert audit['status']=='passed_separate_source_window_replay'
        for p,h in audit['bindings'].items():assert gate.sha(p)==h,p
        candidates=np.array(audit['candidates_utc_seconds'],dtype=np.int64)
        assert len(candidates)>0 and candidates.min()>=stamp('2026-09-01T00:00Z') and candidates.max()<stamp('2026-09-30T00:00Z')
        binding={str(HERE/'source_admission/AUDIT.json'):gate.sha(HERE/'source_admission/AUDIT.json')}
        listed=subprocess.check_output(['rg','--files','--hidden',str(B),'-g','*ACCESS*.json','-g','*RELEASE*.json'],encoding='utf-8')
        access_files=sorted({Path(p) for p in listed.splitlines()})
        known={'adaptive_experts_v4_20260929','submission_validation_v1_20260926','energy_confirmation_v1_20260926','h1_final_evaluation_v1_20260927','spike_transition_v12_20260930','guarded_confirmation_v1_20260929'}
        for p in access_files:
            assert p.relative_to(B).parts[0] in known,('Unreviewed access record',p)
            binding[str(p)]=gate.sha(p)
        release=gate.read(B/'guarded_confirmation_v1_20260929/evaluation/TARGET_RELEASE.json')
        past=np.array(release['origins_utc_seconds'],np.int64)
        assert past.max()+3600<candidates.min()
        h1=gate.read(B/'h1_final_evaluation_v1_20260927/FINAL_TEST_FREEZE.json')
        assert '2026H1' in h1['scope']
        inv=gate.read(B/'common_unit_huber_v1_20260929/ADMISSION_DECISION.json')
        assert inv['latest_archive_filename_endpoint']=='20260701'
        for p in [B/'common_unit_huber_v1_20260929/ADMISSION_DECISION.json',B/'h1_final_evaluation_v1_20260927/FINAL_TEST_FREEZE.json']:
            binding[str(p)]=gate.sha(p)
        gate.write(HERE/'PROJECT_ACCESS_REVIEW.json',dict(at=gate.now(),status='no_recorded_prior_September_target_access_in_project',
            records_reviewed=len(access_files),bindings=binding,prior_CAISO_target_scopes=['2026H1','111August2026origins'],
            latest_prior_confirmation_target_end_utc=datetime.fromtimestamp(int(past.max()+3600),timezone.utc).isoformat(),
            other_scopes=['2016Europe','Previously inspected2024H2development'],new_sources='Newly fetched66sealed archives, only identifiers/timestamps/token-syntax/hashes inspected',
            scope_limit='Project records and retained archive inventory; does not certify unrecorded human access outside this project',
            new_target_values_read=False,external_human_review=False))
        ar=gate.read(OLD/'AUDIT.json');assert ar['status']=='passed' and ar['result_sha256']==gate.sha(OLD/'RESULT.json')
        result=gate.read(OLD/'RESULT.json');assert result['selection_freeze']=='2024-06-30T23:55Z'
        assert gate.read(OLD/'DATA_AUDIT.json')['status']=='passed'
        for p,h in result['artifacts'].items():assert gate.sha(p)==h,p
        inp=gate.read(HERE/'INPUT_RESULT.json');assert gate.read(HERE/'INPUT_AUDIT.json')['status']=='passed'
        for p,h in inp['artifacts'].items():assert gate.sha(p)==h,p
        with np.load(OLDART/'EXPERT_ERROR_LIBRARY.npz') as z:d={k:z[k] for k in z.files}
        with np.load(OLDART/'PREDICTIONS.npz') as z:orig=z['origins'];full=z['FULL'];special=z['SPIKE_ARM']
        with np.load(ART/'evaluation_renewables.npz') as z:ro=z['origins'];rx=z['features']
        ix=np.searchsorted(orig,d['origins']);rr=np.searchsorted(ro,d['origins']);node=d['node']
        assert np.array_equal(orig[ix],d['origins']) and np.array_equal(ro[rr],d['origins'])
        assert np.array_equal(full[ix,node],d['FULL']) and np.array_equal(special[ix,node],d['SPECIALIST'])
        assert len(set(zip(d['origins'].tolist(),node.tolist())))==len(node)
        assert d['context'].shape==(len(node),151) and d['probabilities'].shape==(len(node),12,3)
        assert rx[rr].shape==(len(node),12,5) and np.isfinite(rx).all()
        meta=gate.read(OLD/'DATA.json');directory=Path(meta['directory'])
        times=np.load(meta['timestamps'],mmap_mode='r');features=np.load(directory/'features.npy',mmap_mode='r')
        train=np.load(directory/'train.npy');sc=gate.read(directory/'scalers.json');scale=np.array(sc['price_scale'])[0,:,0]
        assert np.array_equal(times[d['origins']-1],d['issued'])
        assert (stamp(result['selection_freeze'])<d['issued']).all()
        assert np.isfinite(d['truth']).all() and (scale>0).all()
        low_threshold=np.quantile(np.asarray(features[train-1,:,22]),1/3,axis=0)
        low=features[d['origins']-1,node,22]<=low_threshold[node]
        from risk_gate import chronological_mask
        folds=[]
        for start,end in gate.read(HERE/'PROTOCOL.json')['historical_pilot']['folds']:
            a,b=stamp(start+'T00:00Z'),stamp(end+'T00:00Z')
            available=d['available'].max(1)
            fit=chronological_mask(d['issued'],d['issued']+3900,available,stamp(result['selection_freeze']),a)
            pred=(d['issued']>=a)&(d['issued']<b)
            days=len(np.unique(d['issued'][fit]//86400))
            assert days>=10 and pred.any(),('Insufficient fixed-fold support',start,days)
            folds.append(dict(start=start,end=end,training_pairs=int(fit.sum()),training_dates=days,
                evaluation_pairs=int(pred.sum()),evaluation_dates=len(np.unique(d['issued'][pred]//86400)),
                protected_lowvol_pairs=int((pred&low).sum())))
        files=[HERE/'PROTOCOL.json',HERE/'risk_gate.py',HERE/'KERNEL_QA.json',HERE/'INPUT_RESULT.json',HERE/'INPUT_AUDIT.json',
            HERE/'source_admission/AUDIT.json',HERE/'PROJECT_ACCESS_REVIEW.json',OLD/'DATA.json',OLD/'AUDIT.json',OLD/'DATA_AUDIT.json',OLD/'RESULT.json',OLD/'FINAL_FREEZE.json',
            directory/'scalers.json',directory/'state_thresholds.json',directory/'train.npy',directory/'evaluation.npy',OLDART/'PREDICTIONS.npz',OLDART/'EXPERT_ERROR_LIBRARY.npz',ART/'evaluation_renewables.npz']
        gate.write(HERE/'PILOT_READINESS.json',dict(at=gate.now(),status='bounded_development_pilot_admitted',
            source_origin_candidates=len(candidates),source_dates=audit['candidate_dates'],source_version_and_structure_admitted=True,
            project_access_review_passed=True,earlier_only_library_compatible=True,folds=folds,
            numerical_worker_allowed=True,maximum_fits=8,budget_seconds=1800,
            scope='One prefix-refitted seed on previously inspected2024H2; not the retained H1three-seedV7 numerical panel',
            independent_test_release_allowed=False,new_target_values_read=False,
            before_final_confirmation=['Deployment parent/error-library compatibility','Numeric input-only reconstruction and invariance replay','Final model and all predictions freeze','Target release then one-time scoring'],
            lowvolatility_thresholds=low_threshold.tolist(),bindings={str(p):gate.sha(p) for p in files}))
        print('Pilot readiness passed; eight fixed fits; independent test remains sealed',flush=True)
if __name__=='__main__':main()
