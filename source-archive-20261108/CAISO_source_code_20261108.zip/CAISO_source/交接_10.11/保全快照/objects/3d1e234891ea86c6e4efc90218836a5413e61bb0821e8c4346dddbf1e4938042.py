"""Isolated additive/repeat sampling backbone training. Metadata admission precedes numeric imports.

This runner does not train FiLM/QUERY or evaluate Q3. A completed backbone is
not a completed G-TCN-TF experiment. No old checkpoint path is accepted.
"""
from contextlib import contextmanager
from datetime import datetime, timezone
from pathlib import Path
import argparse
import copy
import hashlib
import json
import math
import os
import random
import re
import sys
import time
import uuid

VARIANT_ROOT = Path(__file__).resolve().parents[1]
ROOT = VARIANT_ROOT.parent
sys.path.insert(1, str(ROOT/'source'))
SAMPLING_PROTOCOL = VARIANT_ROOT/'PROTOCOL.json'
SOURCE_QA = VARIANT_ROOT/'runner_synthetic_qa.json'
SAMPLING_MATH_QA = VARIANT_ROOT/'runner_math_qa.json'
MATH_EXECUTION = VARIANT_ROOT/'runner_math_execution.json'
RUNNER_REVIEW = VARIANT_ROOT/'independent_runner_review.json'
POLICIES = ('REPEAT', 'ADDITIVE')
GLOBAL_LOCK = Path('D:/Desktop/数据科学_论文/研究优化_20260818/logs/NEURAL_RUN.lock')
PROTOCOL = ROOT / 'BACKBONE_PROTOCOL.json'
LOCK = VARIANT_ROOT / 'SAMPLING_RUNNER_LOCK.json'
MODEL_QA = ROOT / 'audits/model_synthetic_qa.json'
MATH_QA = ROOT / 'audits/backbone_math_qa.json'
torch = None
np = None


def now():
    return datetime.now(timezone.utc).isoformat()


def read(path):
    return json.loads(Path(path).read_text(encoding='utf-8-sig'))


def sha(path):
    h = hashlib.sha256()
    with Path(path).open('rb') as stream:
        for block in iter(lambda: stream.read(1024 * 1024), b''):
            h.update(block)
    return h.hexdigest()


def inside(value):
    p = Path(value)
    p = (ROOT / p if not p.is_absolute() else p).resolve()
    if not p.is_relative_to(ROOT):
        raise ValueError('Path escapes the new isolated branch: ' + str(p))
    return p


def atomic(path, writer, replace=False):
    path = inside(path)
    path.parent.mkdir(parents=True, exist_ok=True)
    pending = path.with_name(path.name + '.' + uuid.uuid4().hex + '.pending')
    with pending.open('xb') as stream:
        writer(stream)
        stream.flush()
        os.fsync(stream.fileno())
    if replace:
        os.replace(pending, path)
    else:
        # On Windows rename fails if the immutable destination already exists.
        pending.rename(path)


def write(path, value, replace=False):
    raw = json.dumps(value, ensure_ascii=False, indent=2, allow_nan=False).encode('utf-8')
    atomic(path, lambda stream: stream.write(raw), replace)


def bindings_check(bindings):
    for path, digest in bindings.items():
        if sha(inside(path)) != digest:
            raise RuntimeError('Bound new-branch artifact changed: ' + path)


def source_paths():
    paths = [PROTOCOL, ROOT/'recipe.json', Path(__file__).resolve(),
             ROOT/'source/backbone_math_qa.py', ROOT/'source/compiled_data.py',
             ROOT/'source/compile_gate.py', ROOT/'source/compile_math.py']
    paths += sorted((ROOT/'source/models').glob('*.py'))
    paths += [SAMPLING_PROTOCOL, ROOT/'BACKBONE_LOCK.json', ROOT/'source/backbone_train.py',
              ROOT/'source/audit_backbone_result.py']
    paths += [VARIANT_ROOT/'source'/name for name in
              ('train.py', 'audit_result.py', 'runner_math_qa.py', 'runner_source_qa.py',
               'preflight.py', 'compile_sampling.py', 'audit_schedule.py', 'schedule.py')]
    return {str(p.relative_to(ROOT)): sha(p) for p in paths}


def qa_binding(path, kind):
    report = read(path)
    if report.get('status') != 'passed':
        raise RuntimeError(kind + ' QA has not passed')
    if kind == 'model':
        for key in ('common_seed_initialization_exact', 'all_eight_control_formulas_verified',
                    'no_old_data_or_weight_reads'):
            if report.get(key) is not True:
                raise RuntimeError('Missing model QA: ' + key)
    else:
        for key in ('resume_exact', 'optimizer_recipe_exact', 'epoch_cosine_exact',
                    'safe_stop_boundary_verified', 'synthetic_only'):
            if report.get(key) is not True:
                raise RuntimeError('Missing training-math QA: ' + key)
    bindings_check(report['sources'])
    return sha(path)


def runner_evidence(require_math=True):
    sources = source_paths()
    source_qa, review = read(SOURCE_QA), read(RUNNER_REVIEW)
    for report, label in ((source_qa, 'synthetic source QA'), (review, 'independent review')):
        if report.get('status') != 'passed' or report.get('sources') != sources:
            raise RuntimeError('Sampling runner ' + label + ' missing or stale')
    for key in ('independent', 'unchanged_training_math', 'isolated_paths_verified'):
        if review.get(key) is not True:
            raise RuntimeError('Independent sampling review missing: ' + key)
    result = dict(source_qa_sha256=sha(SOURCE_QA), independent_review_sha256=sha(RUNNER_REVIEW))
    if require_math:
        report, receipt = read(SAMPLING_MATH_QA), read(MATH_EXECUTION)
        if report.get('status') != 'passed' or report.get('sources') != sources:
            raise RuntimeError('Actual sampling math QA is missing or stale')
        for key in ('resume_exact', 'optimizer_recipe_exact', 'epoch_cosine_exact',
                    'safe_stop_boundary_verified', 'synthetic_only',
                    'common_seed_initialization_exact', 'paired_slot_shuffle_exact', 'total_budget_verified'):
            if report.get(key) is not True:
                raise RuntimeError('Sampling math QA missing: ' + key)
        if (receipt.get('status') != 'completed' or receipt.get('exit_code') != 0 or
                receipt.get('report_sha256') != sha(SAMPLING_MATH_QA)):
            raise RuntimeError('No successful actual execution receipt for sampling math QA')
        result.update(sampling_math_qa_sha256=sha(SAMPLING_MATH_QA),
                      sampling_math_execution_sha256=sha(MATH_EXECUTION))
    return result


def seal():
    evidence = runner_evidence()
    value = dict(status='sealed_backbone_only', created_at=now(), sources=source_paths(),
                 model_qa_sha256=qa_binding(MODEL_QA, 'model'),
                 math_qa_sha256=qa_binding(MATH_QA, 'math'),
                 sampling_evidence=evidence, scope='isolated_sampling_backbone_only',
                 formal_training_started=False)
    if LOCK.exists():
        previous = read(LOCK)
        if any(value[k] != previous.get(k) for k in value if k != 'created_at'):
            raise RuntimeError('Existing sampling runner seal differs; preserve it')
        return previous
    write(LOCK, value)
    return value


def policy_manifest(policy):
    if policy not in POLICIES:
        raise ValueError('Unregistered sampling policy')
    return VARIANT_ROOT/'dataset'/policy/'manifest.json'


def run_directory(policy, variant, seed):
    if policy not in POLICIES or variant not in ('FULL', 'TCN') or seed not in (20260813, 20260814):
        raise ValueError('Unregistered sampling run')
    return VARIANT_ROOT/'runs'/policy/'backbone'/f'{seed}_{variant}'


def sampling_admission(manifest_path, variant, seed):
    # Metadata only. Independent certification binds derived schedules; the parent
    # source/data gate below still checks every original causal admission condition.
    protocol = read(SAMPLING_PROTOCOL)
    bindings_check(protocol['bindings'])
    manifest_path = inside(manifest_path)
    manifest = read(manifest_path)
    extension = manifest['sampling_extension']
    policy = extension['policy']
    run_directory(policy, variant, seed)
    if manifest_path != policy_manifest(policy):
        raise ValueError('Sampling manifest must use its canonical policy namespace')
    parent_path = ROOT/'dataset/compiled_train_june/manifest.json'
    parent_audit = parent_path.parent/'audit.json'
    expected = dict(policy=policy, protocol_sha256=sha(SAMPLING_PROTOCOL),
                    schedule_sha256=sha(VARIANT_ROOT/'dataset/schedule.json'),
                    parent_manifest_sha256=sha(parent_path), parent_audit_sha256=sha(parent_audit))
    if extension != expected:
        raise RuntimeError('Sampling extension identity changed')
    parent = read(parent_path)
    if manifest.get('status') != 'sampling_extension_pending_independent_origin_audit':
        raise RuntimeError('Unexpected sampling manifest lifecycle')
    replaced = {'phase_manifest.json', 'unique_phase_origins.npy'}
    replaced.update(f'epoch{e}_{kind}.npy' for e in range(1, 7) for kind in ('origins', 'phases'))
    if manifest['artifacts'].keys() != parent['artifacts'].keys():
        raise RuntimeError('Sampling artifact set changed')
    for name, row in parent['artifacts'].items():
        if name not in replaced and manifest['artifacts'][name] != row:
            raise RuntimeError('Sampling changed a frozen parent artifact: ' + name)
    for key, value in parent.items():
        if key not in ('artifacts', 'dataset_revision', 'status') and manifest.get(key) != value:
            raise RuntimeError('Sampling changed parent metadata: ' + key)
    audit_path = VARIANT_ROOT/'dataset/schedule_audit.json'
    schedule_audit, audit = read(audit_path), read(manifest_path.parent/'audit.json')
    if (schedule_audit.get('auditor_source_sha256') != sha(VARIANT_ROOT/'source/audit_schedule.py') or
            schedule_audit.get('all_schedule_checks_passed') is not True or
            schedule_audit.get('fixed_TRAIN_diagnostic_panel_verified') is not True or
            schedule_audit.get('manifests', {}).get(policy) != sha(manifest_path)):
        raise RuntimeError('Independent schedule source or manifest binding changed')
    if (schedule_audit.get('status') != 'passed' or schedule_audit.get('independent') is not True or
            schedule_audit.get('protocol_sha256') != expected['protocol_sha256'] or
            schedule_audit.get('schedule_sha256') != expected['schedule_sha256']):
        raise RuntimeError('Independent real schedule certification missing or stale')
    if (audit.get('sampling_policy') != policy or
            audit.get('sampling_schedule_audit_sha256') != sha(audit_path) or
            audit.get('all_schedule_checks_passed') is not True or
            audit.get('inherited_parent_audit_sha256') != expected['parent_audit_sha256'] or
            audit.get('inherited_parent_manifest_sha256') != expected['parent_manifest_sha256']):
        raise RuntimeError('Policy dataset audit does not bind the independent schedule audit')
    phase_path = inside(manifest['artifacts']['phase_manifest.json']['path'])
    phase = read(phase_path)
    if len(phase['epochs']) != 6 or any(row['count'] != 4032 or row['updates'] != 1008 for row in phase['epochs']):
        raise RuntimeError('Sampling six-epoch doubled budget changed')
    if read(LOCK).get('sampling_evidence') != runner_evidence():
        raise RuntimeError('Sampling runner evidence no longer matches its seal')
    if stop_reason(VARIANT_ROOT):
        raise RuntimeError('Sampling branch is paused')
    return dict(sampling_policy=policy, sampling_protocol_sha256=sha(SAMPLING_PROTOCOL),
                sampling_schedule_sha256=expected['schedule_sha256'],
                sampling_schedule_audit_sha256=sha(audit_path),
                sampling_parent_manifest_sha256=expected['parent_manifest_sha256'])


def parent_admission_contract(manifest_path, variant, seed):
    """Read JSON/source hashes only; never import NumPy/Torch or decode arrays."""
    import compile_gate as gate
    protocol = read(PROTOCOL)
    recipe = read(ROOT/'recipe.json')
    if variant not in protocol['enabled_variants'] or seed not in recipe['seeds']:
        raise ValueError('Unregistered backbone variant/seed')
    fixed = dict(epochs=6, batch=4, lr_start=.001, lr_end=.0001,
                 weight_decay=.0001, betas=[.9, .999], eps=1e-8,
                 huber_delta=.5, clip_norm=1.)
    if any(recipe['backbone'].get(k) != v for k, v in fixed.items()):
        raise RuntimeError('Sealed six-epoch optimizer recipe changed')
    lock = read(LOCK)
    if lock.get('status') != 'sealed_backbone_only' or lock['sources'] != source_paths():
        raise RuntimeError('Backbone source seal missing/stale')
    if qa_binding(MODEL_QA, 'model') != lock['model_qa_sha256']:
        raise RuntimeError('Model QA revision changed')
    if qa_binding(MATH_QA, 'math') != lock['math_qa_sha256']:
        raise RuntimeError('Training-math QA revision changed')
    for lock_name in ('SOURCE_LOCK.json', 'COMPILER_LOCK.json'):
        bindings_check(read(ROOT/lock_name)['sources'])
    manifest_path = inside(manifest_path)
    manifest = read(manifest_path)
    audit_path = manifest_path.parent/'audit.json'
    audit = read(audit_path)
    if audit.get('status') != 'passed' or audit.get('dataset_manifest_sha256') != sha(manifest_path):
        raise RuntimeError('Independent dataset audit missing or stale')
    for key in ('all_derived_dependencies_asof', 'no_future_fill', 'train_only_fit',
                'target_version_predictor_separation', 'all_models_same_eligible_panel'):
        if audit.get(key) is not True:
            raise RuntimeError('Unresolved dataset audit: ' + key)
    required = dict(prefix_stop=219168, train_target_stop_exclusive=210528,
                    june_target_stop_exclusive=219168, cutoff='timestamps_ns[o-1]',
                    node_count=30, feature_count=29, old_fitted_state_reused=False,
                    test_2026_targets_read=False, Q3_target_values_read=False,
                    requires_origin_aware_age_overlay=True)
    if any(manifest.get(k) != v for k, v in required.items()):
        raise RuntimeError('New dataset period/schema/information-set contract changed')
    if manifest['compiler_lock_sha256'] != sha(ROOT/'COMPILER_LOCK.json'):
        raise RuntimeError('Compiler revision differs from compiled dataset')
    config = read(ROOT/'compiler_config.json')
    eligibility = read(config['eligibility_manifest'])
    source_audit = read(config['source_publication_binding_audit'])
    problems = gate.validate_evidence(eligibility, source_audit, sha(config['eligibility_manifest']))
    if problems:
        raise RuntimeError('Source admission revoked: ' + '; '.join(problems))
    if manifest['eligibility_manifest_sha256'] != sha(config['eligibility_manifest']):
        raise RuntimeError('Current eligibility differs from compiled dataset')
    if manifest['source_publication_audit_sha256'] != sha(config['source_publication_binding_audit']):
        raise RuntimeError('Current source proof differs from compiled dataset')
    for path, digest in source_audit['bound_evidence_metadata_sha256'].items():
        if Path(path).suffix.lower() not in ('.json', '.jsonl', '.csv', '.py') or sha(path) != digest:
            raise RuntimeError('Source proof metadata changed')
    pause = read(ROOT.parent/'RESEARCH_PAUSED.json')
    if pause.get('status') != 'resumed_by_user' or pause.get('stop_preparation_and_training'):
        raise RuntimeError('Research is paused')
    paths = {name: inside(row['path']) for name, row in manifest['artifacts'].items()}
    # Numeric files are hashed by CompiledData only after numeric admission.
    for name in ('scalers.json', 'context_limits.json', 'phase_manifest.json'):
        if sha(paths[name]) != manifest['artifacts'][name]['sha256']:
            raise RuntimeError('Fresh metadata artifact changed: ' + name)
    phase = read(paths['phase_manifest.json'])
    if (phase['dataset_revision'] != manifest['dataset_revision'] or
        phase.get('every_shifted_origin_eligible') is not True or
        phase.get('shared_across_variants_and_seeds') is not True or
        phase.get('origin_selection_uses_Q3_errors') is not False):
        raise RuntimeError('New phase provenance invalid')
    counts = []
    for epoch, row in enumerate(phase['epochs'], 1):
        name = f'epoch{epoch}_origins.npy'
        if (row['epoch'] != epoch or row['count'] <= 0 or
            row['updates'] != math.ceil(row['count']/4) or
            row['max_target_end_exclusive'] > 210528 or
            row['sha256'] != manifest['artifacts'][name]['sha256'] or
            inside(row['origins_path']) != paths[name]):
            raise RuntimeError('New epoch origin metadata invalid')
        counts.append(row['count'])
    if len(counts) != 6 or phase['June_hourly_origins'] <= 0:
        raise RuntimeError('Six nonempty epochs and registered June set required')
    scales, limits = read(paths['scalers.json']), read(paths['context_limits.json'])
    if (scales.get('old_fitted_state_reused') is not False or scales['fit_stop'] != 210528 or
        scales['fit_rows_sha256'] != manifest['artifacts']['training_scaler_rows.npy']['sha256'] or
        limits['fit_origins_sha256'] != manifest['artifacts']['registered_train_origins.npy']['sha256']):
        raise RuntimeError('Fresh TRAIN scaler/context lineage mismatch')
    return dict(status='admitted_backbone_only', variant=variant, seed=seed,
        dataset_manifest=str(manifest_path.relative_to(ROOT)), dataset_manifest_sha256=sha(manifest_path),
        dataset_audit_sha256=sha(audit_path), dataset_revision=manifest['dataset_revision'],
        backbone_lock_sha256=sha(LOCK), compiler_lock_sha256=sha(ROOT/'COMPILER_LOCK.json'),
        model_qa_sha256=sha(MODEL_QA), math_qa_sha256=sha(MATH_QA), recipe_sha256=sha(ROOT/'recipe.json'),
        phase_sha256=sha(paths['phase_manifest.json']), context_sha256=sha(paths['context_limits.json']),
        scalers_sha256=sha(paths['scalers.json']), epoch_counts=counts,
        total_updates=sum(math.ceil(n/4) for n in counts), june_origins=phase['June_hourly_origins'],
        scope='backbone_only', film_query_trained=False, Q3_targets_read=False, test_2026_targets_read=False)


def admission(manifest_path, variant, seed):
    extension = sampling_admission(manifest_path, variant, seed)
    identity = parent_admission_contract(manifest_path, variant, seed)
    if identity['epoch_counts'] != [4032]*6 or identity['total_updates'] != 6048:
        raise RuntimeError('Admitted budget is not the registered sampling budget')
    identity.update(extension)
    return identity


def resource_guard():
    import compile_gate as gate
    capacity = gate.resources()
    if capacity['available_physical_GiB'] < 4 or capacity['available_commit_GiB'] < 4:
        raise MemoryError('Backbone requires at least 4 GiB available physical RAM and commit')
    return capacity


@contextmanager
def exclusive(action):
    resource_guard()
    import psutil
    owner = dict(token=uuid.uuid4().hex, pid=os.getpid(), created=psutil.Process().create_time(),
                 action=action, directory=str(ROOT), at=now())
    with GLOBAL_LOCK.open('x', encoding='utf-8') as stream:
        json.dump(owner, stream)
        stream.flush()
        os.fsync(stream.fileno())
    try:
        resource_guard()
        yield owner
    finally:
        if read(GLOBAL_LOCK) != owner:
            raise RuntimeError('Global lock ownership changed; refusing to remove it')
        write(ROOT/'audits/backbone_lock_releases'/f"{owner['token']}.json",
              dict(owner=owner, released_at=now()))
        GLOBAL_LOCK.unlink()


def numeric_runtime():
    global torch, np
    protocol = read(PROTOCOL)
    threads = protocol['torch_threads']
    for key in ('OMP_NUM_THREADS', 'MKL_NUM_THREADS', 'OPENBLAS_NUM_THREADS', 'NUMEXPR_NUM_THREADS'):
        os.environ[key] = str(threads)
    import numpy as numpy_module
    import torch as torch_module
    np, torch = numpy_module, torch_module
    torch.set_num_threads(threads)
    torch.set_num_interop_threads(1)
    torch.use_deterministic_algorithms(True)
    from threadpoolctl import threadpool_limits, threadpool_info
    limiter = threadpool_limits(threads)
    if any(row['num_threads'] > threads for row in threadpool_info()):
        raise RuntimeError('Numerical thread limit not enforced')
    return dict(python=sys.version, executable=sys.executable, numpy=np.__version__,
                torch=torch.__version__, threads=threads, interop=1,
                deterministic=True), limiter


def optimizer(model):
    return torch.optim.AdamW(model.parameters(), lr=.001, weight_decay=.0001,
                             betas=(.9, .999), eps=1e-8)


class EpochCosine:
    """Original driver uses one fixed learning rate per epoch, not per update."""
    def __init__(self, opt):
        self.opt = opt
        self.epoch = 0

    @staticmethod
    def rate(epoch):
        if epoch not in range(1, 7):
            raise ValueError('Cosine epoch must be 1..6')
        return .0001 + .5*(.001-.0001)*(1 + math.cos(math.pi*(epoch-1)/5))

    def set_epoch(self, epoch):
        self.epoch = epoch
        for group in self.opt.param_groups:
            group['lr'] = self.rate(epoch)

    def state_dict(self):
        return dict(epoch=self.epoch, formula='epoch_cosine_1_to_6', lr_start=.001, lr_end=.0001)

    def load_state_dict(self, state):
        expected = dict(epoch=state['epoch'], formula='epoch_cosine_1_to_6', lr_start=.001, lr_end=.0001)
        if state != expected or state['epoch'] not in range(7):
            raise RuntimeError('Scheduler state changed')
        self.epoch = state['epoch']
        lr = self.rate(self.epoch) if self.epoch else .001
        if any(group['lr'] != lr for group in self.opt.param_groups):
            raise RuntimeError('Restored optimizer/scheduler learning rates disagree')


def update(model, opt, x, y):
    opt.zero_grad(set_to_none=True)
    prediction = model(x)['prediction']
    loss = torch.nn.functional.huber_loss(prediction, y, delta=.5)
    if not torch.isfinite(loss):
        raise RuntimeError('Nonfinite Huber loss')
    loss.backward()
    if any(p.grad is None or not torch.isfinite(p.grad).all()
           for p in model.parameters() if p.requires_grad):
        raise RuntimeError('Missing/nonfinite active gradient')
    norm = torch.nn.utils.clip_grad_norm_(model.parameters(), 1.)
    if not torch.isfinite(norm):
        raise RuntimeError('Nonfinite gradient norm')
    opt.step()
    return float(loss.detach()), float(norm)


def rng_state(rng):
    return dict(torch=torch.get_rng_state().clone(), numpy_generator=copy.deepcopy(rng.bit_generator.state),
                numpy_global=np.random.get_state(), python=random.getstate())


def restore_rng(state, rng):
    torch.set_rng_state(state['torch'])
    rng.bit_generator.state = state['numpy_generator']
    np.random.set_state(state['numpy_global'])
    random.setstate(state['python'])


def payload(model, opt, scheduler, rng, identity, runtime, state):
    return dict(format_version=1, identity=identity, runtime=runtime,
                state_dict=copy.deepcopy(model.state_dict()), optimizer=copy.deepcopy(opt.state_dict()),
                scheduler=scheduler.state_dict(), rng=rng_state(rng), model_training=model.training,
                progress=copy.deepcopy(state), scope='backbone_only')


def restore(saved, model, opt, scheduler, rng, identity, runtime):
    if saved['identity'] != identity or saved['runtime'] != runtime or saved['scope'] != 'backbone_only':
        raise RuntimeError('Resume checkpoint belongs to another source/data/runtime/run')
    model.load_state_dict(saved['state_dict'], strict=True)
    opt.load_state_dict(saved['optimizer'])
    scheduler.load_state_dict(saved['scheduler'])
    restore_rng(saved['rng'], rng)
    model.train(saved['model_training'])
    return copy.deepcopy(saved['progress'])


def checkpoint(run, saved, name=None):
    name = name or ('checkpoint_' + uuid.uuid4().hex + '.pt')
    if not re.fullmatch(r'[a-zA-Z0-9_]+\.pt', name):
        raise ValueError('Invalid checkpoint name')
    path = inside(run/'checkpoints'/name)
    atomic(path, lambda stream: torch.save(saved, stream))
    receipt = dict(status='committed', path=str(path.relative_to(ROOT)), sha256=sha(path),
                   steps=saved['progress']['steps'], epoch=saved['progress']['epoch'],
                   phase=saved['progress']['phase'], committed_at=now(), identity=saved['identity'])
    write(path.with_suffix('.receipt.json'), receipt)
    write(run/'latest.json', receipt, replace=True)
    return receipt


def load_checkpoint(run, receipt):
    path = inside(receipt['path'])
    if not path.is_relative_to((run/'checkpoints').resolve()):
        raise RuntimeError('Only the current new-branch run may resume')
    if read(path.with_suffix('.receipt.json')) != receipt or sha(path) != receipt['sha256']:
        raise RuntimeError('Resume checkpoint receipt/hash mismatch')
    # This pickle was written by this exact sealed runner and is hash-bound above.
    return torch.load(path, map_location='cpu', weights_only=False)



def recover_receipt(run):
    """A receipt committed just before a pointer-write crash remains resumable."""
    receipts = []
    for path in sorted((run/'checkpoints').glob('*.receipt.json')):
        receipt = read(path)
        target = inside(receipt['path'])
        if (not target.is_relative_to((run/'checkpoints').resolve()) or
            target.with_suffix('.receipt.json') != path or
            receipt.get('status') != 'committed' or sha(target) != receipt['sha256']):
            raise RuntimeError('Invalid durable checkpoint receipt: ' + str(path))
        receipts.append(receipt)
    pointer = run/'latest.json'
    if pointer.exists() and read(pointer) not in receipts:
        raise RuntimeError('Latest pointer has no identical committed receipt')
    if not receipts:
        return None
    latest = max(receipts, key=lambda r: (r['steps'], r['epoch'],
                 r['phase'] == 'epoch_complete', r['committed_at']))
    if not pointer.exists() or read(pointer) != latest:
        write(pointer, latest, replace=True)
    return latest


def stop_reason(run):
    for folder in (ROOT, VARIANT_ROOT, run):
        for name in ('STOP_REQUESTED', 'STOP_REQUESTED.json'):
            if (folder/name).exists():
                return 'STOP_REQUESTED: ' + str(folder/name)
    pause = read(ROOT.parent/'RESEARCH_PAUSED.json')
    if pause.get('status') != 'resumed_by_user' or pause.get('stop_preparation_and_training'):
        return 'Research paused'
    return None


def validate_state(state, identity):
    counts = identity['epoch_counts']
    epoch = state['epoch']
    if epoch not in range(7):
        raise RuntimeError('Invalid saved epoch range')
    if state['phase'] == 'epoch_complete':
        expected = sum(math.ceil(n/4) for n in counts[:epoch])
        if len(state['epochs']) != epoch or state['order'] is not None or state['offset'] != 0:
            raise RuntimeError('Invalid completed-epoch cursor')
    elif state['phase'] == 'train':
        if epoch not in range(1, 7) or len(state['epochs']) != epoch-1:
            raise RuntimeError('Invalid training-epoch cursor')
        count = counts[epoch-1]
        order = state['order']
        offset = state['offset']
        if (not isinstance(order, np.ndarray) or order.dtype != np.int64 or
            not np.array_equal(np.sort(order), np.arange(count)) or
            offset < 0 or offset > count or (offset != count and offset % 4)):
            raise RuntimeError('Invalid saved shuffle/offset')
        expected = sum(math.ceil(n/4) for n in counts[:epoch-1]) + math.ceil(offset/4)
    else:
        raise RuntimeError('Unknown checkpoint phase')
    if state['steps'] != expected:
        raise RuntimeError('Checkpoint optimizer count disagrees with actual new origins')


def evaluate_june(model, data, run):
    n = len(data.origins['june'])
    predictions = np.empty((n, 30, 12), np.float64)
    absolute = squared = near = h12 = 0.
    model.eval()
    with torch.no_grad():
        for start in range(0, n, 4):
            reason = stop_reason(run)
            if reason:
                return None, None, reason
            x, y = data.batch('june', slice(start, start+4))
            p = model(torch.from_numpy(x))['prediction'].cpu().numpy().astype(np.float64)
            p = p*data.scale[None, :, None]+data.center[None, :, None]
            truth = y.astype(np.float64)*data.scale[None, :, None]+data.center[None, :, None]
            error = p-truth
            if not np.isfinite(error).all():
                raise RuntimeError('Nonfinite registered June forecast')
            predictions[start:start+len(p)] = p
            absolute += float(np.abs(error).sum(dtype=np.float64))
            squared += float(np.square(error).sum(dtype=np.float64))
            near += float(np.abs(error[:, :, :4]).sum(dtype=np.float64))
            h12 += float(np.abs(error[:, :, 11]).sum(dtype=np.float64))
    return dict(mae=absolute/(n*360), rmse=math.sqrt(squared/(n*360)),
                near_h1_4_mae=near/(n*120), h12_mae=h12/(n*30),
                origins=n, forecast_cells=n*360, units='USD/MWh'), predictions, None


def train(manifest_path, variant, seed, resume=False):
    import preflight
    preflight.require_mechanisms_complete()
    preflight.launch_guard()
    identity = admission(manifest_path, variant, seed)
    run = run_directory(identity['sampling_policy'], variant, seed)
    if stop_reason(run):
        raise RuntimeError('Remove the reviewed STOP request explicitly before launch')
    with exclusive(f"sampling_{identity['sampling_policy']}_{variant}_{seed}"):
        runtime, limiter = numeric_runtime()
        resource_guard()
        from compiled_data import CompiledData
        from models.factory import build_backbone
        data = CompiledData(manifest_path)
        limits = read(data.paths['context_limits.json'])['limits']
        for epoch, count in enumerate(identity['epoch_counts'], 1):
            data.set_epoch(epoch)
            if len(data.origins['train']) != count:
                raise RuntimeError('Actual epoch count differs from admitted phase')
        if len(data.origins['june']) != identity['june_origins']:
            raise RuntimeError('Actual registered June count differs from phase')
        model = build_backbone(variant, seed, limits)
        torch.manual_seed(seed+200000)
        np.random.seed(seed)
        random.seed(seed)
        rng = np.random.default_rng(seed)
        opt = optimizer(model)
        scheduler = EpochCosine(opt)
        state = dict(phase='epoch_complete', epoch=0, steps=0, offset=0, order=None,
                     train_huber_sum=0., gradient_norm_sum=0., epochs=[])
        run_start = dict(identity=identity, runtime=runtime,
                         active_parameters=sum(p.numel() for p in model.parameters() if p.requires_grad),
                         total_parameters=sum(p.numel() for p in model.parameters()),
                         initialization='fresh_factory_constructor', scope='backbone_only')
        if run.exists():
            if not resume:
                raise RuntimeError('Existing run requires explicit --resume; it will not be overwritten')
            if read(run/'run_start.json') != run_start:
                raise RuntimeError('Run identity/runtime changed')
            receipt = recover_receipt(run)
            if receipt is None:
                # No committed optimizer update exists; preserve any orphan temporary bytes.
                checkpoint(run, payload(model, opt, scheduler, rng, identity, runtime, state))
            else:
                saved = load_checkpoint(run, receipt)
                state = restore(saved, model, opt, scheduler, rng, identity, runtime)
                validate_state(state, identity)
        else:
            if resume:
                raise RuntimeError('Cannot resume a run that does not exist')
            write(run/'run_start.json', run_start)
            checkpoint(run, payload(model, opt, scheduler, rng, identity, runtime, state))
        began = time.perf_counter()
        invocation_steps = state['steps']

        def stop(reason):
            receipt = checkpoint(run, payload(model, opt, scheduler, rng, identity, runtime, state))
            event = dict(status='stopped_at_safe_boundary', at=now(), reason=reason,
                         checkpoint=receipt, optimizer_steps=state['steps'],
                         unsaved_updates=0, scope='backbone_only', film_query_trained=False)
            write(run/'events'/f'stop_{uuid.uuid4().hex}.json', event)
            return event

        while state['phase'] == 'train' or state['epoch'] < 6:
            reason = stop_reason(run)
            if reason:
                return stop(reason)
            try:
                resource_guard()
            except MemoryError as exc:
                return stop(str(exc))
            if state['phase'] == 'epoch_complete':
                epoch = state['epoch']+1
                count = identity['epoch_counts'][epoch-1]
                scheduler.set_epoch(epoch)
                state.update(phase='train', epoch=epoch, offset=0,
                             order=rng.permutation(count), train_huber_sum=0., gradient_norm_sum=0.)
                checkpoint(run, payload(model, opt, scheduler, rng, identity, runtime, state))
            epoch = state['epoch']
            data.set_epoch(epoch)
            model.train()
            count = identity['epoch_counts'][epoch-1]
            while state['offset'] < count:
                reason = stop_reason(run)
                if reason:
                    return stop(reason)
                start = state['offset']
                x, y = data.batch('train', state['order'][start:start+4])
                loss, norm = update(model, opt, torch.from_numpy(x), torch.from_numpy(y))
                state['steps'] += 1
                state['offset'] = min(start+4, count)
                state['train_huber_sum'] += loss*len(x)
                state['gradient_norm_sum'] += norm*len(x)
                # A stop is honored only after the whole optimizer update and cursor commit.
                reason = stop_reason(run)
                if reason:
                    return stop(reason)
                if state['steps'] % 64 == 0 or state['offset'] == count:
                    checkpoint(run, payload(model, opt, scheduler, rng, identity, runtime, state))
                    print(json.dumps(dict(event='backbone_progress', at=now(), epoch=epoch,
                          offset=state['offset'], epoch_origins=count, optimizer_steps=state['steps'])), flush=True)
                    try:
                        resource_guard()
                    except MemoryError as exc:
                        return stop(str(exc))
            metrics, predictions, reason = evaluate_june(model, data, run)
            if reason:
                return stop(reason)
            prediction_name = f'epoch{epoch}_june_{uuid.uuid4().hex}.npy'
            prediction_path = run/'validation'/prediction_name
            atomic(prediction_path, lambda stream: np.save(stream, predictions, allow_pickle=False))
            checkpoint_name = f'epoch{epoch}_complete_{uuid.uuid4().hex}.pt'
            row = dict(epoch=epoch, june=metrics, lr=EpochCosine.rate(epoch),
                       train_origins=count, optimizer_steps=state['steps'],
                       train_huber_mean=state['train_huber_sum']/count,
                       gradient_norm_mean=state['gradient_norm_sum']/count,
                       checkpoint=str((run/'checkpoints'/checkpoint_name).relative_to(ROOT)),
                       prediction=str(prediction_path.relative_to(ROOT)), prediction_sha256=sha(prediction_path))
            state['epochs'].append(row)
            state.update(phase='epoch_complete', offset=0, order=None)
            validate_state(state, identity)
            checkpoint(run, payload(model, opt, scheduler, rng, identity, runtime, state), checkpoint_name)
            print(json.dumps(dict(event='epoch_completed', **row)), flush=True)
        validate_state(state, identity)
        if state['steps'] != identity['total_updates']:
            raise RuntimeError('Final optimizer budget mismatch')
        best = None
        for row in state['epochs']:
            if best is None or row['june']['mae'] < best['june']['mae']-1e-6:
                best = row
            if sha(inside(row['prediction'])) != row['prediction_sha256']:
                raise RuntimeError('Completed epoch validation output changed')
            ckpt = inside(row['checkpoint'])
            receipt = read(ckpt.with_suffix('.receipt.json'))
            if sha(ckpt) != receipt['sha256'] or receipt['identity'] != identity:
                raise RuntimeError('Completed epoch checkpoint changed')
        if admission(manifest_path, variant, seed) != identity:
            raise RuntimeError('Admission changed while training')
        result = dict(status='backbone_completed_pending_independent_audit', identity=identity,
                      epochs=state['epochs'], selected_epoch=best['epoch'], selected_june=best['june'],
                      selected_checkpoint=best['checkpoint'], selected_checkpoint_sha256=sha(inside(best['checkpoint'])),
                      criterion='June registered eligible origins raw MAE; epochs 1..6; improvement > 1e-6',
                      optimizer_steps=state['steps'], scope='backbone_only', film_query_trained=False,
                      complete_G_TCN_TF_result=False, Q3_targets_read=False, test_2026_targets_read=False)
        completion = run/'backbone_completion.json'
        if completion.exists():
            if read(completion) != result:
                raise RuntimeError('Immutable completion differs')
        else:
            write(completion, result)
        write(run/'events'/f'execution_{uuid.uuid4().hex}.json',
              dict(status='completed', at=now(), optimizer_steps_this_invocation=state['steps']-invocation_steps,
                   elapsed_seconds=time.perf_counter()-began, completion_sha256=sha(completion)))
        return result


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('action', choices=('check', 'seal', 'run'))
    parser.add_argument('--policy', choices=POLICIES, default='ADDITIVE')
    parser.add_argument('--variant', choices=('FULL', 'TCN'), default='FULL')
    parser.add_argument('--seed', type=int, choices=(20260813, 20260814), default=20260813)
    parser.add_argument('--resume', action='store_true')
    args = parser.parse_args()
    if args.action == 'seal':
        result = seal()
    elif args.action == 'check':
        try:
            result = admission(policy_manifest(args.policy), args.variant, args.seed)
        except (OSError, ValueError, KeyError, RuntimeError) as exc:
            print(json.dumps(dict(status='blocked', reason=str(exc), numeric_imports=False,
                                 actual_market_values_read=False, training_started=False)))
            return 2
    else:
        result = train(policy_manifest(args.policy), args.variant, args.seed, args.resume)
    print(json.dumps(result, ensure_ascii=True))
    return 3 if result.get('status') == 'stopped_at_safe_boundary' else 0


if __name__ == '__main__':
    raise SystemExit(main())
