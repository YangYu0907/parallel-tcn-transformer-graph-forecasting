from common import *
from datetime import datetime,timezone
import math
np=None
def load(path):
    with np.load(path,allow_pickle=False) as z:return {k:z[k] for k in z.files}
def features(hist,center,q):
    assert hist.ndim==3 and hist.shape[0]==288 and hist.shape[2]==4
    sign=np.where(hist[-1,:,0]>=center,1.,-1.)
    cols=[sign*(hist[-1,:,k]-hist[-1-step,:,k])/q for k in range(4) for step in [1,3,12]]
    cols += [abs(hist[-1,:,2])/np.maximum(abs(hist[-1,:,1:]).sum(1),1e-12),
      sign*(hist[-1,:,2]-np.median(hist[:,:,2],axis=0))/q,
      sign*(hist[-1,:,1]-np.median(hist[:,:,1],axis=0))/q]
    return np.column_stack(cols)
def identity(arr):
    residual=arr[...,0]-arr[...,1:].sum(-1)
    bad=abs(residual)>(.001+1e-6*abs(arr[...,0]))
    return dict(cells=int(residual.size),max_abs_residual=float(abs(residual).max()),failed=int(bad.sum()))
def concatenate(rows):return {k:np.concatenate([r[k] for r in rows]) for k in rows[0]}
def auc(y,x,w=None):
    from sklearn.metrics import roc_auc_score
    return float(roc_auc_score(y,x,sample_weight=w)) if len(np.unique(y))==2 else None
def diagnostic_scores(panel,pname,months=False):
    # Fixed score orientation. There is no fit, sign optimization or cutoff.
    out=[];st=panel['states'];X=panel['features'];dates=panel['date']
    partitions={'ALL':np.ones(len(st),bool)}
    if months:
        mm=np.array([datetime.fromtimestamp(int(d)*86400,timezone.utc).strftime('%Y-%m') for d in dates])
        partitions.update({m:mm==m for m in np.unique(mm)})
    for part,use in partitions.items():
      for hs in [[0],list(range(12))]:
        target=st[use][:,hs];score=np.repeat(X[use],len(hs),axis=0);ds=np.repeat(dates[use],len(hs))
        m=np.isin(target.ravel(),[3,5]);y=(target.ravel()[m]==5).astype(int);score=score[m];ds=ds[m]
        if not len(y):continue
        ud,inv,count=np.unique(ds,return_inverse=True,return_counts=True);weights=1/count[inv]
        for j,n in enumerate(NAMES):
          row=dict(panel=pname,month=part,horizon='H1' if len(hs)==1 else 'ALL12',feature=n,cells=len(y),S3=int((y==0).sum()),S5=int(y.sum()),dates=len(ud),
            S3_dates=len(np.unique(ds[y==0])),S5_dates=len(np.unique(ds[y==1])),pooled_auc=auc(y,score[:,j]),equal_date_auc=auc(y,score[:,j],weights),
            median_S3=float(np.median(score[y==0,j])) if (y==0).any() else None,median_S5=float(np.median(score[y==1,j])) if y.any() else None)
          if pname=='H1_DEVELOPMENT' and part=='ALL' and len(hs)==1:
            loo=[auc(y[ds!=d],score[ds!=d,j],weights[ds!=d]) for d in ud];loo=[a for a in loo if a is not None]
            row['leave_one_date_out_auc_range']=[min(loo),max(loo)] if loo else None
            # Independent dates are not assumed for a formal significance test.
            # This exploratory resampling reports date-cluster sensitivity only.
            rng=np.random.default_rng(20261001);vals=[]
            for _ in range(300):
                multiplicity=np.bincount(rng.integers(len(ud),size=len(ud)),minlength=len(ud));ww=weights*multiplicity[inv];z=ww>0
                v=auc(y[z],score[z,j],ww[z])
                if v is not None:vals.append(v)
            row['date_cluster_auc_interval95_descriptive']=np.quantile(vals,[.025,.975]).tolist() if vals else None
          out.append(row)
    return out
def counts(panel):
    st=panel['states'];orig=panel['origin'];node=panel['node'];dates=panel['date'];rows=[]
    for s in range(6):
        active=(st==s);pairs=active.any(1);events=0
        for n in np.unique(node[pairs]):
            oo=np.unique(orig[pairs&(node==n)]);events+=int(1+np.sum(np.diff(oo)>12)) if len(oo) else 0
        rows.append(dict(state=s,cells=int(active.sum()),origin_node_pairs=int(pairs.sum()),origins=len(np.unique(orig[pairs])),dates=len(np.unique(dates[pairs])),node_origin_episode_clusters=events))
    return rows
def component_changes(panel,mask,weight=None):
    dc=panel['target']-panel['last'][:,None,:];z=dc[mask]
    if not len(z):return None
    w=np.ones(len(z)) if weight is None else weight[mask];den=w.sum()
    if den<=0:return None
    # The three named components do not close some June2026 records. Preserve
    # the residual explicitly; do not force it into energy or remove records.
    z=np.column_stack([z,z[:,0]-z[:,1:].sum(1)])
    mag=abs(z[:,1:]);absolute=(w[:,None]*mag).sum(0);dominant=np.argmax(mag,axis=1)
    direction=np.sign(z[:,0]);agreement=(np.sign(z[:,1:])==direction[:,None]) & (direction[:,None]!=0)
    projection=(w[:,None]*(z[:,1:]*direction[:,None])).sum(0)
    return dict(cells=len(z),absolute_movement_share=(absolute/max(absolute.sum(),1e-12)).tolist(),
      dominant_component_share=[float(w[dominant==k].sum()/den) for k in range(4)],
      mean_signed_change_USD_MWh=((w[:,None]*z).sum(0)/den).tolist(),
      net_direction_projected_component_change=(projection/den).tolist(),
      same_direction_fraction=((w[:,None]*agreement).sum(0)/den).tolist(),
      note='Order ENERGY,CONGESTION,LOSS,UNACCOUNTED_RESIDUAL. Residual is not verified GHG. Movement decomposition, not causal attribution of forecast error. Means include LMP first.')
def main():
    global np
    p=gate.read(HERE/'PROTOCOL.json');seal=gate.read(HERE/'SEAL.json');start=time.monotonic()
    for path,h in seal['bindings'].items():assert gate.sha(path)==h,path
    with gate.exclusive('Fit-free component and event diagnosis; original forecasts unchanged'):
      np,limiter=gate.runtime(False)
      for path,h in {**p['bindings'],**p['protected']}.items():assert gate.sha(path)==h,path
      def tick(stage):
          check();assert time.monotonic()-start<1200,'Fixed diagnostic time budget'
          write(HERE/'status.json',dict(at=gate.now(),pid=os.getpid(),stage=stage,fit_count=0))
      pp=paths();sc=gate.read(pp['scalers.json']);th=gate.read(pp['state_thresholds.json']);center=np.array(th['center']);thresholds=np.array(th['thresholds']);q=thresholds[1]
      ts=np.load(pp['timestamps_seconds.npy'],mmap_mode='r');raw=np.load(pp['raw_prices.npy'],mmap_mode='r')
      tr=load(A/'spike_specialist_v7_20260930/TRAIN_features.npz');rows=[];identity_checks=[]
      assert raw.ndim==3 and raw.shape[1:]==(30,4)
      for k,o in enumerate(np.unique(tr['origins'])):
          if k%150==0:tick('TRAIN_component_histories_'+str(k))
          ix=np.flatnonzero(tr['origins']==o);nn=tr['nodes'][ix];hist=np.array(raw[o-288:o],dtype=np.float64);target=np.array(raw[o:o+12],dtype=np.float64).transpose(1,0,2)
          assert o+12<=210528
          assert np.isfinite(hist[:,nn]).all() and np.isfinite(target[nn]).all()
          f=features(hist[:,nn],center[nn],q[nn]);yt=target[nn,:,0]
          classes=(abs(yt-center[nn,None])>thresholds[0,nn,None]).astype(int)+(abs(yt-center[nn,None])>q[nn,None]).astype(int)
          mismatch=classes!=tr['classes'][ix]
          if mismatch.any():
              distance=np.minimum(abs(abs(yt-center[nn,None])-thresholds[0,nn,None]),abs(abs(yt-center[nn,None])-q[nn,None]))
              assert (distance[mismatch]<1e-4).all(),'Non-rounding TRAIN label mismatch'
          # Keep the original frozen classifications, with the raw boundary discrepancy explicitly recorded.
          classes=tr['classes'][ix]
          identity_checks.append(identity(hist[:,nn]));identity_checks.append(identity(target[nn]))
          rows.append(dict(origin=tr['origins'][ix],node=nn,date=np.full(len(nn),int(ts[o]//86400)),features=f,last=hist[-1,nn],target=target[nn],states=classes+3,fit=tr['fit'][ix],cal=tr['cal'][ix]))
      train=concatenate(rows);del rows
      save(ART/'TRAIN_COMPONENTS.npz',**train)
      tick('H1_existing_development_component_read')
      audits=[load(A/f'spike_specialist_v7_20260930/audited/{s}.npz') for s in [20260813,20260814,20260815]]
      origins=audits[0]['origins'];assert len(origins)==698
      for a in audits:assert np.array_equal(a['origins'],origins) and np.array_equal(a['truth'],audits[0]['truth'])
      fr=gate.read(B/'h1_source_inputs_v1_20260927/INPUT_AUDIT_FREEZE.json')
      meta=load(B/'h1_feature_admission_v1_20260927/publication_routing.npz');meta['epoch']=int(meta['epoch'])
      sys.path.insert(0,str(B/'h1_feature_admission_v1_20260927'));from history import validate_origin
      sys.path.insert(0,str(B/'energy_confirmation_v1_20260926/admission'));from bounded_history import BoundedMember
      allowed=set(map(int,origins));admitted=set(fr['origins']);assert allowed<=admitted
      for o in allowed:validate_origin(o,admitted,meta)
      class Contract:
          def __init__(self,o):
              assert o in allowed;self.origin=o;self.price_ranges=((o-288,o+12),)
          def allows(self,a,b,kind):
              return (kind=='past_only' and self.origin-288<=a<b<=self.origin) or (kind=='existing_outcomes_only' and (a,b)==(self.origin,self.origin+12))
      reader=BoundedMember(fr['config']['price_archive'],'values','<f4',(30,4));rows=[]
      try:
        for j,o in enumerate(origins):
          o=int(o)
          if j%64==0:
              tick('H1_component_histories_'+str(j));reader.prepare_byte_cache([Contract(int(v)) for v in origins[j:j+64]],'price')
          c=Contract(o);hist=np.frombuffer(reader.read(o-288,o,c,'past_only'),'<f4').reshape(288,30,4).astype(np.float64)
          yt=np.frombuffer(reader.read(o,o+12,c,'existing_outcomes_only'),'<f4').reshape(12,30,4).transpose(1,0,2).astype(np.float64)
          assert np.array_equal(yt[:,:,0],audits[0]['truth'][j]);assert np.isfinite(hist).all() and np.isfinite(yt).all()
          f=features(hist,center,q);identity_checks.extend([identity(hist),identity(yt)])
          rows.append(dict(origin=np.full(30,o),node=np.arange(30),date=np.full(30,int(meta['seconds'][o]//86400)),features=f,last=hist[-1],target=yt,states=audits[0]['states'][j]))
        receipts=reader.receipts
      finally:reader.close()
      dev=concatenate(rows);del rows
      save(ART/'DEV_COMPONENTS.npz',**dev)
      write(HERE/'READ_RECEIPTS.json',dict(at=gate.now(),scope='Known development origins only; target components used only for attribution',receipts=receipts))
      maxid=max(r['max_abs_residual'] for r in identity_checks);bad=sum(r['failed'] for r in identity_checks)
      assert gate.read(HERE/'RESIDUAL_SOURCE_REVIEW.json')['all_states']['3']==0
      assert gate.read(HERE/'RESIDUAL_SOURCE_REVIEW.json')['all_states']['5']==0
      # Document identity failure; continue only descriptive four-term accounting.
      # No three-component physical forecast is admitted by this diagnostic.
      # Exact feature interface never receives an outcome. Synthetic future perturbation and boundary QA.
      synthetic=np.zeros((288,2,4));synthetic[:,:,1]=10;synthetic[:,:,2]=2;synthetic[:,:,3]=1;synthetic[:,:,0]=13
      joint=np.concatenate([synthetic,np.zeros((12,2,4))]);sx=features(joint[:288],np.zeros(2),np.ones(2))
      joint[288:]=1e6
      assert np.array_equal(sx,features(joint[:288],np.zeros(2),np.ones(2)))
      c=Contract(int(origins[0]));assert not c.allows(c.origin,c.origin+1,'past_only') and not c.allows(c.origin+12,c.origin+13,'existing_outcomes_only')
      qa=dict(component_identity_max_abs=maxid,component_identity_failed=bad,known_target_LMP_exact=True,TRAIN_classes_exact=True,
        three_component_physical_identity_passed=False,unaccounted_residual_retained=True,
        TRAIN_raw_boundary_discrepancy=gate.read(HERE/'LABEL_BOUNDARY_DIAGNOSIS.json'),
        future_not_argument_of_features=True,forbidden_history_future_read_rejected=True,unique_dev_dates=len(np.unique(dev['date'])),fit_count=0)
      tick('fixed_score_ranking_and_date_sensitivity')
      rankings=[]
      for part,mask in [('TRAIN_FIT',train['fit']),('TRAIN_CAL',train['cal'])]:rankings.extend(diagnostic_scores({k:v[mask] for k,v in train.items()},part))
      rankings.extend(diagnostic_scores(dev,'H1_DEVELOPMENT',True))
      changes=[]
      for state in range(6):changes.append(dict(group='S'+str(state),**(component_changes(dev,dev['states']==state) or {})))
      seedrows=[];daily=[]
      for seed,a in zip([20260813,20260814,20260815],audits):
          f=a['FULL'].reshape(-1,12);v=a['CONTEXT'].reshape(-1,12);y=a['truth'].reshape(-1,12);ds=(v-y)**2-(f-y)**2
          for s in range(6):
              mask=dev['states']==s
              for label,z in [('all',mask),('harmful',mask&(ds>1e-8)),('helpful',mask&(ds<-1e-8))]:
                  ch=component_changes(dev,z)
                  weighted=component_changes(dev,z,abs(ds))
                  seedrows.append(dict(seed=seed,state=s,condition=label,forecast_cells=int(z.sum()),dates=len(np.unique(dev['date'][z.any(1)])),
                      component_movement=ch,absolute_SSE_change_weighted_movement=weighted,SSE_change=float(ds[z].sum()),
                      MAE_FULL=float(abs(f[z]-y[z]).mean()) if z.any() else None,MAE_V7=float(abs(v[z]-y[z]).mean()) if z.any() else None))
              for d in np.unique(dev['date'][mask.any(1)]):
                  z=mask&(dev['date'][:,None]==d)
                  daily.append(dict(seed=seed,state=s,UTC_date=datetime.fromtimestamp(int(d)*86400,timezone.utc).date().isoformat(),cells=int(z.sum()),
                      SSE_change=float(ds[z].sum()),sum_abs_FULL=float(abs(f[z]-y[z]).sum()),sum_abs_V7=float(abs(v[z]-y[z]).sum()),
                      component_movement=component_changes(dev,z)))
      save(ART/'UNCHANGED_FORECASTS.npz',FULL=np.stack([a['FULL'] for a in audits]),V7=np.stack([a['CONTEXT'] for a in audits]))
      result=dict(at=gate.now(),status='completed_fit_free_diagnostic',scope=p['scope'],QA=qa,features=NAMES,fit_count=0,
        independent_test=False,V7_changed=False,TRAIN_support=counts(train),DEV_support=counts(dev),rankings=rankings,
        component_movement_by_state=changes,seed_error_conditioned_attribution=seedrows,daily_attribution=daily,
        protected_files_verified=preserved(),elapsed_seconds=time.monotonic()-start,
        artifacts={str(x):gate.sha(x) for x in ART.glob('*.npz')},protocol_sha256=gate.sha(HERE/'PROTOCOL.json'))
      write(HERE/'RESULT.json',result)
      print(json.dumps(dict(status=result['status'],seconds=result['elapsed_seconds'],QA=qa,DEV_support=result['DEV_support'])))
if __name__=='__main__':main()
