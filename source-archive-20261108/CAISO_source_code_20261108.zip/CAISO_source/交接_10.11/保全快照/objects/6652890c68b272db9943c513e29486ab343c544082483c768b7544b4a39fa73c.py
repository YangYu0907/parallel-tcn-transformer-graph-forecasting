import json, hashlib, os
from pathlib import Path
from datetime import datetime, timezone
import psutil
P=Path(__file__).resolve().parent
Z=P.parent
B=Z.parent.parent
now=datetime.now(timezone.utc).isoformat()
delivery='120b48e9ad8bb7ab18a4cd1d01a37c3a4d49ed64f6d907703eb44470bc7ca01e'
event=json.loads((B/'event_driven_automation/inbox/wi_06ca670b45be55c7b89f41d5.json').read_text(encoding='utf-8-sig'))
def sha(p):return hashlib.sha256(Path(p).read_bytes()).hexdigest()
def read(p):return json.loads(Path(p).read_text(encoding='utf-8-sig'))
def write(p,obj):
    p=Path(p);p.parent.mkdir(parents=True,exist_ok=True)
    tmp=p.with_name(p.name+'.tmp')
    tmp.write_text(json.dumps(obj,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
    os.replace(tmp,p)
assert sha(event['evidence_path'])==event['evidence_sha256']
audit=read(Z/'native_full_run_20261007/COST_STOP_AUDIT.json')
assert audit['passed'] and audit['cost_gate_correct']
launch=read(P/'LAUNCH.json')
pid=launch['manager_pid']
alive=psutil.pid_exists(pid) and str(P/'manager.py').lower() in ' '.join(psutil.Process(pid).cmdline()).lower()
assert alive, 'Mirror worker exited; inspect result before recording active'
assert psutil.pid_exists(launch['exit_monitor_pid'])
assert psutil.pid_exists(3936) and 'watch.ps1' in ' '.join(psutil.Process(3936).cmdline())
review=dict(at=now,delivery_event_id=delivery,source_event_id=event['event_id'],
  decision='Cost protection correctly stopped full source worker; verified85sourcecycles preserved; bounded same32source mirror proof launched',
  failure_sha256=event['evidence_sha256'],source_audit=str(Z/'native_full_run_20261007/COST_STOP_AUDIT.json'),
  old_manager_pid=21468,old_worker_alive=psutil.pid_exists(21468),
  completed_source_cycles=85,total_source_cycles=5286,model_fits=0,
  current_launch=launch,mirror_protocol=str(P/'PROTOCOL.json'),mirror_protocol_sha256=sha(P/'PROTOCOL.json'),
  same_source_only=True,automatic_full_restart=False,new_test_targets_read=False,V7_replaced=False,
  periodic_model_wakeups=False,source_deadline_unix=read(P/'PROTOCOL.json')['parent_source_deadline_unix'],
  review_scope='Separate-script source/hash and arithmetic verification, not independent-person or model-performance audit')
reviewpath=Z/'handled_events'/('review_'+delivery[:16]+'.json')
write(reviewpath,review)
source=read(Z/'REVIEWED_SOURCE_EVENTS.json')
source['at']=now
source['handled'][event['event_id']]=review['decision']
source['current_launch']=launch
source['latest_review']=str(reviewpath)
write(Z/'REVIEWED_SOURCE_EVENTS.json',source)
hp=B/'HANDOFF.json';before=hp.read_bytes();h=json.loads(before.decode('utf-8-sig'))
write(P/'HANDOFF_BEFORE.json',h)
ext=h['mechanism_weather_extension_20261007']
ext.update(at=now,stage='bounded_same_source_mirror_proof_running',launch=launch,
  active_numeric_job=True,active_script=str(P/'manager.py'),manager_pid=pid,
  manager_start_utc_ticks=launch['manager_start_utc_ticks'],exit_monitor_pid=launch['exit_monitor_pid'],
  exit_monitor_receipt=launch['receipt'],completed_source_cycles=85,completed_model_fits=0,model_fits=0,
  latest_event_review=str(reviewpath),cost_stop_audit=review['source_audit'],
  mirror_proof_protocol=review['mirror_protocol'],mirror_proof_protocol_sha256=review['mirror_protocol_sha256'],
  next='Finish bounded32cycle original-byte/value/cost check; only a passing audited mirror may resume same full source population before unchanged source deadline',
  previous_full_launch=h.get('current_process'),automatic_full_restart=False)
h.update(at=now,last_updated_utc=now,current_stage='Full weather source paused by measured cost gate; bounded mirror proof running; zero model fits; V7 frozen',
  current_process=launch,numeric_diagnostic_active=True,training_active=False,research_training_active=False,
  periodic_model_wakeups=False,event_listener_pid=3936,last_event_dedup_check=dict(at=now,delivery_event_id=delivery,source_event_id=event['event_id'],decision=review['decision'],review=str(reviewpath)),
  last_handled_event=event['event_id'],manager_pid=pid)
ids=h.setdefault('handled_event_ids',[])
assert isinstance(ids,list)
for value in [delivery,event['event_id']]:
    if value not in ids:ids.append(value)
assert hp.read_bytes()==before,'Concurrent HANDOFF update'
write(hp,h)
print(json.dumps(dict(event_recorded=True,manager_pid=pid,exit_monitor_pid=launch['exit_monitor_pid'],completed_source_cycles=85,mirror_status=read(P/'STATUS.json')),ensure_ascii=False))

