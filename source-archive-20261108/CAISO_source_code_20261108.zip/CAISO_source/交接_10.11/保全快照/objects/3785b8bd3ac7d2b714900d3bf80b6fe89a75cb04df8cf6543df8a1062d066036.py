"""Separate metric loops and state-path enumeration; no fitting."""
from experiment import *
def score_scalar(p,y,days):
    p=np.clip(p,1e-12,1-1e-12)
    b=[float((float(a)-float(b))**2) for a,b in zip(p,y)]
    ll=[float(-int(b)*np.log(a)-(1-int(b))*np.log(1-a)) for a,b in zip(p,y)]
    byday={int(k):[] for k in days}
    for i,d in enumerate(days):byday[int(d)].append(i)
    return dict(brier=sum(b)/len(b),log_loss=sum(ll)/len(ll),
        date_brier=np.mean([sum(b[i] for i in ids)/len(ids) for ids in byday.values()]),
        date_log_loss=np.mean([sum(ll[i] for i in ids)/len(ids) for ids in byday.values()]))

def main():
    verify();checked(True);result=old.read(HERE/'RESULT.json');checks=0
    with old.numeric('Independent scalar score and marginal-state inference audit'):
        for row in result['probes']:
            folder=HERE/f"probe{row['fold']}"
            with np.load(folder/'REPLAY.npz') as f:d={k:f[k] for k in f.files}
            use=d['ids'][:,2]>=7
            for arm in row['arms']:
                name=arm['arm'];path=folder/name/'model.pkl';frozen=old.read(folder/name/'FROZEN.json')
                assert old.sha(path)==frozen['sha256'];checks+=1
                model=old.load(path)['model'];x=feature_X(d,name)
                if name.startswith('DIRECT'):
                    replay=model.predict_proba(x)[:,1]
                else:
                    xx=x.reshape(-1,12,x.shape[1]);replay=np.zeros((len(xx),12))
                    # Explicit two-state probability vectors and matrix propagation.
                    state=np.zeros((len(xx),2));state[:,0]=1.
                    for h in range(12):
                        matrix=np.empty((len(xx),2,2))
                        for s in [0,1]:matrix[:,s,:]=model.predict_proba(np.column_stack([xx[:,h],np.full(len(xx),s)]))
                        state=np.einsum('ni,nij->nj',state,matrix);replay[:,h]=state[:,1]
                    replay=replay.ravel()
                    # Exhaustive 2^4 paths verify the first four steps of first8pairs.
                    for i in range(min(8,len(xx))):
                        distribution={(0,):1.}
                        for h in range(4):
                            newer={}
                            for path0,w in distribution.items():
                                pp=model.predict_proba(np.r_[xx[i,h],path0[-1]][None])[0]
                                for s in [0,1]:newer[path0+(s,)]=w*pp[s]
                            distribution=newer
                            exact=sum(w for states,w in distribution.items() if states[-1]==1)
                            assert abs(exact-replay.reshape(-1,12)[i,h])<1e-12;checks+=1
                assert np.max(abs(replay-d[name]))<1e-12;checks+=1
                for key,value in score_scalar(d[name][use],d['y'][use],d['days'][use]).items():
                    assert abs(value-arm['scores'][key])<1e-11;checks+=1
                for g in arm['groups']:
                    mask=use&(d['states']==g['state'])
                    assert g['cells']==int(mask.sum()) and g['dates']==len(np.unique(d['days'][mask]));checks+=1
                    for key,value in score_scalar(d[name][mask],d['y'][mask],d['days'][mask]).items():
                        assert abs(value-g[key])<1e-11;checks+=1
            # Recompute strict screen from numeric predictions rather than trusting recorded flags.
            candidate=d['TRANSITION_COMPONENT'][use];yy=d['y'][use];days=d['days'][use]
            new=score_scalar(candidate,yy,days);expected={}
            for name in ARMS[:-1]:
                oldscore=score_scalar(d[name][use],yy,days)
                expected['all_probability_scores_better_than_'+name]=all(new[k]<oldscore[k] for k in new)
            oldscore=score_scalar(d['reference_PRICE'],yy,days)
            expected['better_than_retained_old_PRICE']=all(new[k]<oldscore[k] for k in new)
            for s in [3,4,5]:
                mask=(d['states'][use]==s);ns=score_scalar(candidate[mask],yy[mask],days[mask])
                base=score_scalar(d['DIRECT_PRICE'][use][mask],yy[mask],days[mask])
                oldscore=score_scalar(d['reference_PRICE'][mask],yy[mask],days[mask])
                expected[f'S{s}_support_and_retention']=len(np.unique(days[mask]))>=5 and all(ns[k]<=min(base[k],oldscore[k])+1e-12 for k in ns)
            assert expected==row['checks'] and all(expected.values())==row['passed'];checks+=8
        assert result['screen_passed']==all(x['passed'] for x in result['probes']);checks+=1
    assert old.parent.verify_protected()==18
    old.write(HERE/'AUDIT.json',dict(at=old.now(),status='passed',checks=checks,result_sha256=old.sha(HERE/'RESULT.json'),
        audit_kind='Independent scalar formulas/matrix propagation/exhaustive toy paths by same operator; not external reviewer',
        protected_files=18,new_test_targets_read=False))
    print('Separate audit passed:',checks)

if __name__=='__main__':main()
