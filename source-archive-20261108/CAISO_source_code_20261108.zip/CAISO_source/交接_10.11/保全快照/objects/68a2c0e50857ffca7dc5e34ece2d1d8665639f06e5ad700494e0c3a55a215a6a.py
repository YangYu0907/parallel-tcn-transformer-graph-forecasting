"""Different-formula replay and complete fold/month/block reporting."""
from pathlib import Path
import numpy as np
from sklearn.metrics import average_precision_score
import support as s
W=Path(__file__).resolve().parent

def summarize(y,prob,alarm):
 out={}
 for c,sign in [(1,'up'),(2,'down')]:
  q=np.clip(prob[:,c],1e-12,1-1e-12);truth=y==c;on=alarm[:,c-1];tp=int(np.sum(truth&on));fp=int(np.sum(~truth&on))
  out[sign]=dict(brier=float(np.dot(q-truth,q-truth)/len(y)),logloss=float((-np.log(q[truth]).sum()-np.log1p(-q[~truth]).sum())/len(y)),precision=tp/(tp+fp) if tp+fp else 0.,recall=tp/int(truth.sum()) if truth.any() else 0.,TP=tp,FP=fp,events=int(truth.sum()),FPR=fp/int((~truth).sum()),AP=float(average_precision_score(truth,q)) if truth.any() else None)
 return out
def run(p,tick):
 r=s.read(W/'RESULT_PENDING_AUDIT.json');folds=r['results'];checks=0
 for fold in p['folds']:
  for arm in p['arms']:
   cell=W/fold['name']/arm
   with np.load(cell/'PREDICTIONS.npz') as a:
    pr=a['evaluation'];thresholds=folds[fold['name']][arm]['thresholds'];alarms=np.column_stack([pr[:,c]>thresholds[c-1] for c in [1,2]])
    mm=summarize(a['y'],pr,alarms)
    for sign in ['up','down']:
     for k in ['brier','logloss','TP','FP','precision','recall','FPR']:
      assert abs(mm[sign][k]-folds[fold['name']][arm]['metrics'][sign][k])<1e-12,(fold,arm,sign,k)
      checks+=1
 with np.load(W/'PREDICTIONS.npz') as a:
  y=a['y'];tm=a['time'];arms=p['arms']+['FROZEN_HISTORY','FROZEN_COARSE']
  global_metrics={arm:summarize(y,a[arm],a[arm+'_alarm']) for arm in arms}
  months=tm.astype('datetime64[s]').astype('datetime64[M]')
  monthly={str(m):{arm:summarize(y[months==m],a[arm][months==m],a[arm+'_alarm'][months==m]) for arm in arms} for m in np.unique(months)}
  block=(tm-(tm.min()//86400)*86400)//(86400*3);nb=int(block.max()+1);counts=np.bincount(block,minlength=nb)
  weights=np.random.default_rng(20260813).multinomial(nb,np.full(nb,1/nb),size=2000);den=weights@counts;stats=[]
  for candidate,control in [('GROUPED','COARSE'),('COARSE','FROZEN_COARSE')]:
   for c,sign in [(1,'up'),(2,'down')]:
    truth=y==c;pc=np.clip(a[candidate][:,c],1e-12,1-1e-12);pb=np.clip(a[control][:,c],1e-12,1-1e-12)
    for metric in ['brier','logloss']:
     diff=(pc-truth)**2-(pb-truth)**2 if metric=='brier' else np.where(truth,np.log(pb/pc),np.log((1-pb)/(1-pc)))
     sampled=weights@np.bincount(block,weights=diff,minlength=nb)/den
     pv=min(1.,2*min((np.count_nonzero(sampled>=0)+1)/2001,(np.count_nonzero(sampled<=0)+1)/2001))
     stats.append(dict(candidate=candidate,control=control,sign=sign,metric=metric,difference=float(diff.mean()),CI95=np.quantile(sampled,[.025,.975]).tolist(),p=pv))
  previous=0
  for rank,j in enumerate(np.argsort([a['p'] for a in stats])):
   previous=max(previous,min(1.,(len(stats)-rank)*stats[j]['p']));stats[j]['exploratory_Holm_p']=previous
 descriptive=all(f['GROUPED']['metrics'][sign][metric]<f[control]['metrics'][sign][metric] for f in folds.values() for sign in ['up','down'] for metric in ['brier','logloss'] for control in ['HISTORY','COARSE'])
 descriptive=descriptive and all(f['GROUPED']['metrics'][sign][metric]>=f['COARSE']['metrics'][sign][metric] for f in folds.values() for sign in ['up','down'] for metric in ['precision','recall'])
 descriptive=descriptive and all(f['GROUPED']['metrics'][sign]['FPR']<=.02 for f in folds.values() for sign in ['up','down'])
 statistical=all(a['difference']<0 and a['exploratory_Holm_p']<.05 for a in stats if a['candidate']=='GROUPED')
 tick(stage='statistics_replay_complete',metric_equalities=checks)
 protected=s.read(W.parent/'PROTECTED_FILES.json')
 for path,h in protected.items():assert s.sha(path)==h
 audit=dict(at=s.now(),passed=True,metric_equalities=checks,calendar_blocks=nb,bootstrap_replicates=2000,protected_files_unchanged=len(protected),review_scope='Different-formula same operator; independent-person audit not completed',protocol_sha256=s.sha(W/'PROTOCOL.json'),predictions_sha256=s.sha(W/'PREDICTIONS.npz'))
 s.base.write(W/'AUDIT.json',audit)
 s.base.write(W/'RESULT.json',dict(r,aggregate=global_metrics,all_months=monthly,statistics=stats,descriptive_gate_passed=bool(descriptive),statistical_gate_passed=bool(statistical),information_candidate_promising=bool(descriptive and statistical),automatic_admission=False,independent_formula_replay_passed=True,audit_sha256=s.sha(W/'AUDIT.json'),next='If stable: register genuine independent confirmation and OOF benefit integration. Otherwise close grouped-weather candidate; no threshold/region/month search. Entire research not complete.'))

