"""Separate scalar metrics/direct targets, actual optimizer lineage, selected raw formula."""
import argparse,json,sys,gc
import gate
def main(case_id):
 s=gate.verify();case=next(c for c in s['cases'] if c['id']==case_id);run=gate.HERE/'runs'/case_id
 r=gate.read(run/'completion.json');gate.need(r['identity']['case']==case and r['identity']['execution_lock_sha256']==gate.sha(gate.SEAL),'Result identity')
 with gate.exclusive('budget_audit_'+case_id):
  np,torch,lim=gate.runtime();oracle=gate.load('budget_scalar_oracle',gate.COMMON/'audit.py');oracle.np=np
  from compiled_data import CompiledData
  from model_io import build,explicit
  data=CompiledData(s['dataset_manifest']);m=gate.read(gate.inside(s['dataset_manifest']))
  path=lambda n:gate.inside(m['artifacts'][n]['path'])
  target=np.load(path('target_scaled.npy'),mmap_mode='r',allow_pickle=False)
  features=np.load(path('features.npy'),mmap_mode='r',allow_pickle=False)
  center=data.center;scale=data.scale;q=np.array(gate.read(path('state_thresholds.json'))['thresholds'],np.float64)
  pops=dict(june=data.origins['june'],dense=data.origins['june_dense'],train=np.load(gate.inside(s['train_diagnostic']),allow_pickle=False));gold={}
  for name,origins in pops.items():
   gate.guard();gate.need((origins+12<=(210528 if name=='train' else 219168)).all() and (origins>=288).all(),'Label bounds')
   truth=np.stack([target[o:o+12].T.copy() for o in origins]).astype(np.float64)*scale[None,:,None]+center[None,:,None]
   last=np.array(features[origins-1,:,0],np.float64)*scale+center;codes=np.empty(truth.shape,np.uint8)
   for i in range(len(origins)):
    for n in range(30):
     active=abs(float(last[i,n]-center[n]))>float(q[1,n])
     for h in range(12):
      delta=abs(float(truth[i,n,h]-center[n]));codes[i,n,h]=3*int(active)+int(delta>q[0,n])+int(delta>q[1,n])
   gold[name]=(origins,truth,codes)
  bindings={gate.rel(run/'completion.json'):gate.sha(run/'completion.json')}
  def bind(p,d=None):
   p=gate.inside(p);value=gate.sha(p);gate.need(d is None or value==d,'Artifact changed')
   bindings[gate.rel(p)]=value;return p
  def load(ref,part):
   p=bind(ref['path'],ref['sha256'])
   with np.load(p,allow_pickle=False) as z:
    gate.need(set(z.files)=={'origins','truth','codes','prediction'},'Evaluation schema')
    for name,expected in zip(('origins','truth','codes'),gold[part]):gate.need(np.array_equal(z[name],expected),'Direct target/state mismatch')
    pred=z['prediction']
   gate.need(pred.shape==gold[part][1].shape and np.isfinite(pred).all(),'Prediction finite/shape')
   return pred,pred-gold[part][1]
  terminal=gate.inside(case['terminal_checkpoint']);parent=torch.load(terminal,map_location='cpu',weights_only=False)
  gate.need(parent['identity']==case['parent']['identity'],'Parent identity')
  gate.need(r['epochs'][:6]==parent['progress']['epochs'],'Original sixepoch evidence changed')
  gate.need([x['epoch'] for x in r['epochs']]==list(range(1,13)) and r['optimizer_steps']==12096 and r['new_updates']==6048,'Budget')
  limits=gate.read(data.paths['context_limits.json'])['limits'];model=build(case['variant'],case['seed'],limits)
  frozen={k for k,p in model.named_parameters() if not p.requires_grad};active=sum(p.requires_grad for p in model.parameters());initial=model.state_dict()
  chosen=None;epoch_checks=[];selected_pred=None
  weight_spec=gate.read(gate.HERE/'WEIGHTS.json');counts=np.zeros(12,np.int64);phase_counts={}
  for ep in range(1,7):
   origins=np.load(data.paths[f'epoch{ep}_origins.npy'],allow_pickle=False)
   phase_counts[ep]=np.bincount(origins%12,minlength=12);counts+=phase_counts[ep]
  gate.need(counts.tolist()==weight_spec['phase_counts'],'TRAIN weight population')
  exact=counts.sum()/(12*counts.astype(np.float64));gate.need(np.array_equal(exact,np.array(weight_spec['weights'])),'Phase importance ratio')
  gate.need(abs(float(np.dot(counts,exact))-24192)<1e-9,'Mean weight normalization')
  next_rng=np.random.default_rng();next_rng.bit_generator.state=parent['rng']['numpy_generator']
  shuffles={ep:__import__('hashlib').sha256(next_rng.permutation(4032).tobytes()).hexdigest() for ep in range(7,13)}
  for row in r['epochs']:
   gate.guard();e=row['epoch']
   if e<=6:
    p=bind(row['prediction'],row['prediction_sha256']);pred=np.load(p,allow_pickle=False)
    gate.need(pred.shape==gold['june'][1].shape,'Prefix prediction shape')
    score=oracle.head(pred-gold['june'][1]);oracle.compare({k:row['june'][k] for k in ('mae','rmse','near_h1_4_mae','h12_mae')},{k:score[k] for k in ('mae','rmse','near_h1_4_mae','h12_mae')})
   else:
    pred,err=load(row['evaluation'],'june');oracle.compare(row['june'],oracle.head(err))
   if chosen is None or row['june']['mae']<chosen['june']['mae']-1e-6:chosen=row;selected_pred=pred.copy()
   ck=gate.inside(row['checkpoint']);rr=gate.read(ck.with_suffix('.receipt.json'));bind(ck,rr['sha256']);bind(ck.with_suffix('.receipt.json'))
   saved=torch.load(ck,map_location='cpu',weights_only=False)
   gate.need(saved['identity']==(case['parent']['identity'] if e<=6 else r['identity']),'Checkpoint identity')
   prog=saved['progress'];gate.need(prog['phase']=='epoch_complete' and prog['steps']==e*1008 and prog['epoch']==e and prog['offset']==0 and prog['order'] is None,'Adam/cursor epoch')
   gate.need(saved['scope']==('backbone_only' if e<=6 else 'phase_weighted_continuation_backbone_only'),'Checkpoint scope')
   expected_lr=.0001 if e>6 else .0001+.5*(.001-.0001)*(1+__import__('math').cos(__import__('math').pi*(e-1)/5))
   for group in saved['optimizer']['param_groups']:gate.need(group['lr']==expected_lr and group['weight_decay']==.0001 and group['betas']==(.9,.999) and group['eps']==1e-8,'Optimizer recipe')
   states=saved['optimizer']['state'];gate.need(len(states)==active and all(float(v['step'])==e*1008 for v in states.values()),'Active Adam steps')
   gate.need(all(torch.isfinite(v[k]).all() for v in states.values() for k in ('exp_avg','exp_avg_sq')),'Adam finite moments')
   weights=saved['state_dict'];gate.need(set(weights)==set(initial) and all(torch.isfinite(v).all() for v in weights.values()),'Weights schema/finite')
   gate.need(all(torch.equal(weights[k],parent['state_dict'][k]) for k in frozen),'Inactive parameter changed')
   if 'context_limits' in weights:gate.need(torch.equal(weights['context_limits'],parent['state_dict']['context_limits']),'TRAIN context limits changed')
   if e>6:
    gate.need(row['weights_sha256']==gate.sha(gate.HERE/'WEIGHTS.json') and row['phase_counts']==phase_counts[e-6].tolist() and row['shuffle_sha256']==shuffles[e],'Weight/phase/shuffle lineage')
    gate.need(saved['scheduler']==dict(epoch=e,rule='epochs7to12_fixed_terminal_lr',lr=.0001),'Tail scheduler')
    gate.need(prog['epochs']==r['epochs'][:e],'Checkpoint epoch evidence')
   epoch_checks.append(dict(epoch=e,steps=e*1008,lr=expected_lr,active_parameter_tensors=active));del saved
  gate.need(chosen['epoch']==r['selected_epoch'] and chosen['checkpoint']==r['selected_checkpoint'],'Selector mismatch')
  p,e=load(r['dense_evaluation'],'dense');ix,blocks=oracle.panels_oracle(pops['dense'],pops['june'])
  gate.need(len(blocks)==278 and len(pops['dense'])==3397 and np.array_equal(p[ix['June284']],selected_pred),'Selected panel replay')
  oracle.compare(r['panels'],{name:oracle.oracle_breakdown(e[idx],gold['dense'][2][idx],pops['dense'][idx]) for name,idx in ix.items()})
  gate.need([x['epoch'] for x in r['train_curves_new']]==list(range(7,13)),'TRAIN curve scope')
  for row in r['train_curves_new']:
   gate.guard();_,err=load(row['evaluation'],'train');oracle.compare(row['metrics'],oracle.oracle_breakdown(err,gold['train'][2],pops['train']))
  # Ensure the first durable epoch6 snapshot contains the exact parent optimizer/RNG/state.
  def equal(a,b):
   if torch.is_tensor(a):return torch.equal(a,b)
   if isinstance(a,np.ndarray):return np.array_equal(a,b)
   if isinstance(a,dict):return set(a)==set(b) and all(equal(a[k],b[k]) for k in a)
   if isinstance(a,(list,tuple)):return type(a)==type(b) and len(a)==len(b) and all(equal(x,y) for x,y in zip(a,b))
   return a==b
  starts=[]
  for f in (run/'checkpoints').glob('*.receipt.json'):
   rr=gate.read(f)
   if rr['epoch']==6 and rr['steps']==6048:
    ck=bind(rr['path'],rr['sha256']);starts.append(torch.load(ck,map_location='cpu',weights_only=False))
  gate.need(bool(starts),'Initial bridge checkpoint missing')
  for start in starts:
   for key in ('state_dict','optimizer','rng'):gate.need(equal(start[key],parent[key]),'Bridge altered '+key)
  prefix=gate.read(bind(run/'prefix_replay.json'));gate.need(prefix['status']=='passed' and prefix['maximum_prediction_difference']==0,'Prefix replay missing')
  selected=torch.load(gate.inside(r['selected_checkpoint']),map_location='cpu',weights_only=False)
  model.load_state_dict(selected['state_dict'],strict=True);model.eval()
  probes=list(ix['June284'][:12])+[i for i,o in enumerate(pops['dense']) if int(o)%12!=0][:12];difference=0.
  with torch.no_grad():
   for start in range(0,24,4):
    gate.guard();ids=np.array(probes[start:start+4]);x,_=data.batch('june_dense',ids,with_target=False)
    yp=explicit(model,torch.from_numpy(x),case['variant']).numpy().astype(np.float64)*scale[None,:,None]+center[None,:,None]
    difference=max(difference,float(np.max(np.abs(yp-p[ids]))))
  gate.need(difference<=1e-9,'Independent formula replay')
  gate.verify();gate.write(run/'audit.json',dict(status='passed',at=gate.now(),completion_sha256=gate.sha(run/'completion.json'),
   epoch_checks=epoch_checks,original_prefix_preserved=True,optimizer_rng_bridge_exact=True,training_phase_weights_verified=True,all_six_training_shuffles_verified=True,selected_formula_replay_origins=24,
   selected_formula_max_difference=difference,output_bindings=bindings,scope='Sameoperator distinct scalar/directlabel and pinnedformula audits; notsecondperson.',
   heldout_targets_read=False,complete_research_experiment=False))
  print(json.dumps(dict(status='passed',case=case_id,selected_epoch=r['selected_epoch'])),flush=True)
if __name__=='__main__':
 p=argparse.ArgumentParser();p.add_argument('--case',required=True);main(p.parse_args().case)
