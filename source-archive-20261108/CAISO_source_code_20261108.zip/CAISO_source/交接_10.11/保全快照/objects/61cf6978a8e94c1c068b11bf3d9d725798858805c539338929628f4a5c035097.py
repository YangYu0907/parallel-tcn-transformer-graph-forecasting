from common import *
import numpy as np,gc,pickle
from scipy.optimize import minimize_scalar
import compare,disk_hgb
from features import calendar
N=Z.parent/'short_context_support_trial_20261005'
def inputs(a,ii,arm):
 x=np.load(N/'features.npy',mmap_mode='r');hist=np.asarray(x[a['row'][ii]],np.float32);x._mmap.close()
 w=np.load(W/'weather_GROUPED.npy',mmap_mode='r');weather=np.asarray(w[a['weather_row'][ii]],np.float32);w._mmap.close()
 ex=np.load(E/'EXTRA.npy',mmap_mode='r');extra=np.asarray(ex[a['weather_row'][ii]],np.float32);ex._mmap.close()
 pieces=[hist,calendar(a['time'][ii]).astype(np.float32),weather,extra[:,:2]]
 if arm=='TEND':pieces.append(extra[:,2:])
 result=np.concatenate(pieces,axis=1);assert np.isfinite(result).all()
 return result
def model_save(path,m):
 tmp=path.with_name('.m'+uuid.uuid4().hex[:8])
 with tmp.open('wb') as f:pickle.dump(m,f,protocol=5)
 os.replace(tmp,path)
def run(p,tick):
 with np.load(W/'INDICES.npz') as z:a={k:z[k] for k in z.files}
 fits=[]
 for fi,fold in enumerate(p['folds']):
  name=fold['name'];fit,cal,ev=[a[name+'_'+part] for part in ['fit','cal','eval']]
  for arm in p['arms']:
   cell=E/f"q{fi+1}_{arm.lower()}";cell.mkdir(exist_ok=True)
   def ct(**kw):tick(fold=name,arm=arm,completed_fits=len(fits),**kw)
   assert not (cell/'DONE.json').exists(),'No duplicate fit'
   start=time.monotonic();target=cell/'X.npy'
   mm=np.lib.format.open_memmap(target,mode='w+',dtype=np.float32,shape=(len(fit),p['features'][arm]),fortran_order=True);mm._mmap.close()
   for i in range(0,len(fit),8192):
    val=inputs(a,fit[i:i+8192],arm);mm=np.load(target,mmap_mode='r+');mm[i:i+len(val)]=val;mm.flush();mm._mmap.close()
    if i%131072==0:ct(stage='design',rows=i,total=len(fit))
   disk_hgb.TICK=ct;model=disk_hgb.DiskHGB(**p['learner'])
   for it in p['iterations']:
    ct(stage='fit',iterations=it,fit_pairs=len(fit));mm=np.load(target,mmap_mode='r');model.set_params(max_iter=it);model.fit(mm,a['y'][fit]);mm._mmap.close()
    model_save(cell/'MODEL.pkl',model);write(cell/'FIT.json',dict(at=now(),n_iter=it,sha256=sha(cell/'MODEL.pkl')))
   assert model.n_iter_==80 and model.classes_.tolist()==[0,1,2]
   def predict(ii):
    out=np.empty((len(ii),3))
    for i in range(0,len(ii),8192):
     sub=ii[i:i+8192];out[i:i+len(sub)]=model.predict_proba(inputs(a,sub,arm))
     if i%65536==0:ct(stage='predict',rows=i,total=len(ii))
    return out
   cp0=predict(cal)
   temperature=float(minimize_scalar(lambda t:compare.old.logscore(compare.old.temp(cp0,t),a['y'][cal]),bounds=(.5,2),method='bounded').x)
   cp=compare.old.temp(cp0,temperature);th=[float(np.quantile(cp[a['y'][cal]!=c,c],.99,method='higher')) for c in [1,2]]
   write(cell/'CAL.json',dict(at=now(),temperature=temperature,thresholds=th,model_sha256=sha(cell/'MODEL.pkl'),eval_predictions_not_yet_made=True))
   ep0=predict(ev);ep=compare.old.temp(ep0,temperature)
   save(cell/'PRED.npz',cal_raw=cp0,calibration=cp,eval_raw=ep0,evaluation=ep,y=a['y'][ev],time=a['time'][ev],node=a['node'][ev],cal_y=a['y'][cal])
   result=dict(fold=name,arm=arm,seconds=time.monotonic()-start,fit_pairs=len(fit),cal_pairs=len(cal),eval_pairs=len(ev),metrics=compare.old.metrics(ep,a['y'][ev],th),temperature=temperature,thresholds=th)
   write(cell/'DONE.json',dict(result=result,bindings={str(p):sha(p) for p in [cell/'MODEL.pkl',cell/'PRED.npz',cell/'CAL.json',cell/'FIT.json']}));fits.append(result)
   del model,cp0,cp,ep0,ep;gc.collect();ct(stage='cell_complete',seconds=result['seconds'])
 write(E/'FITS.json',dict(at=now(),fits=fits))
 import audit
 audit.run(p,a,tick)

