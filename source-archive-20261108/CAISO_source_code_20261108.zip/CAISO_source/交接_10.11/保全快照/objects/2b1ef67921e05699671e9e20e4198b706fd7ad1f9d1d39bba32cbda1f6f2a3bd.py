"""Code-native vector diagrams, restyled from the user's visual references.
No illustrative curve is represented as measured data. Only Fig2 has data marks.
Run with the bundled Codex Python runtime.
"""
from pathlib import Path
import os, json, csv, calendar, collections, hashlib
os.environ['MPLCONFIGDIR']='C:/Users/于阳/CAISO_temporary_storage/diagram_revision_mpl'
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
from matplotlib.patches import FancyBboxPatch, Rectangle, Ellipse, Polygon, Circle, PathPatch
from matplotlib.path import Path as MPath
from matplotlib import font_manager
ROOT=Path(__file__).resolve().parents[1]
FIG=ROOT/'figures';FIG.mkdir(parents=True,exist_ok=True)
INK='#263858';BLUE='#5079BC';PALEBLUE='#E2EDF7';GREEN='#E8F0DB';YELLOW='#FFF3CC';PEACH='#F8E7D8';PINK='#F5DCDD';GRAY='#67717F'
CHECKS=[]
plt.rcParams.update({'font.family':'Times New Roman','font.size':9,'mathtext.fontset':'stix',
 'svg.fonttype':'none','pdf.fonttype':42,'ps.fonttype':42,'axes.unicode_minus':False,'savefig.facecolor':'white'})

class Canvas:
 def __init__(self,w,h,size,lang):
  self.w,self.h,self.lang=w,h,lang;self.fig=plt.figure(figsize=size);self.ax=self.fig.add_axes([0,0,1,1]);self.ax.set(xlim=(0,w),ylim=(h,0));self.ax.axis('off');self.labels=[]
  self.family='SimSun' if lang=='zh' else 'Times New Roman'
 def tr(self,en,zh):return zh if self.lang=='zh' else en
 def text(self,x,y,s,fs=9,ha='center',weight='normal',color='black',va='center',**kw):
  t=self.ax.text(x,y,s,ha=ha,va=va,fontsize=fs,fontfamily=[self.family,'Times New Roman'],fontweight=weight,color=color,linespacing=1.14,zorder=5,**kw);return t
 def box(self,x,y,w,h,s='',fc=PALEBLUE,fs=9,r=.8,lw=.75):
  p=FancyBboxPatch((x,y),w,h,boxstyle=f'round,pad=0,rounding_size={r}',fc=fc,ec=INK,lw=lw,zorder=2);self.ax.add_patch(p)
  if s:self.labels.append((self.text(x+w/2,y+h/2,s,fs),p))
  return p
 def group(self,x,y,w,h,title,letter=None):
  p=FancyBboxPatch((x,y),w,h,boxstyle='round,pad=0,rounding_size=2.6',fc='white',ec=INK,lw=1.15,linestyle=(0,(4,3)),zorder=0);self.ax.add_patch(p)
  tx=x+3
  if letter:self.text(tx,y+2.9,letter,11,ha='left',weight='bold');tx+=5
  self.text(tx,y+2.9,title,9.8,ha='left',weight='normal')
 def route(self,pts,color=BLUE,lw=1.05,dash=None,arrow=True):
  xs,ys=zip(*pts)
  if len(pts)>2:self.ax.plot(xs[:-1],ys[:-1],color=color,lw=lw,linestyle=dash or '-',zorder=1)
  self.ax.annotate('',xy=pts[-1],xytext=pts[-2],arrowprops=dict(arrowstyle='-|>' if arrow else '-',mutation_scale=8,color=color,lw=lw,shrinkA=0,shrinkB=.6,linestyle=dash or '-'),zorder=1)
 def cyl(self,x,y,w,h,s,fc):
  self.ax.add_patch(Rectangle((x,y+1.1),w,h-2.2,fc=fc,ec=INK,lw=.75,zorder=2))
  self.ax.add_patch(Ellipse((x+w/2,y+h-1.1),w,2.2,fc=fc,ec=INK,lw=.75,zorder=2))
  self.ax.add_patch(Rectangle((x+.13,y+h-2.4),w-.26,1.3,fc=fc,ec='none',zorder=3))
  self.ax.add_patch(Ellipse((x+w/2,y+1.1),w,2.2,fc=fc,ec=INK,lw=.75,zorder=4));self.text(x+w/2,y+h/2+.4,s,8.6)
 def stack(self,x,y,w,h,fc=PALEBLUE,n=3):
  for k in range(n-1,-1,-1):self.ax.add_patch(Rectangle((x+k*.65,y-k*.65),w,h,fc=fc,ec=INK,lw=.65,zorder=2))
 def dot(self,x,y,s='+'):
  self.ax.add_patch(Circle((x,y),1.4,fc='white',ec=INK,lw=.75,zorder=3));self.text(x,y,s,11)
 def save(self,name):
  self.fig.canvas.draw();rend=self.fig.canvas.get_renderer();bad=[]
  for txt,box in self.labels:
   t=txt.get_window_extent(rend);b=box.get_window_extent(rend)
   if t.x0<b.x0+1 or t.x1>b.x1-1 or t.y0<b.y0+1 or t.y1>b.y1-1:bad.append(txt.get_text())
  CHECKS.append(dict(figure=name,language=self.lang,box_label_overflow=bad))
  if bad:print('LABEL_OVERFLOW',name,self.lang,bad)
  stem=FIG/(name+'_'+self.lang)
  self.fig.savefig(str(stem)+'.svg');self.fig.savefig(str(stem)+'.pdf')
  self.fig.savefig(str(stem)+'.png',dpi=600);self.fig.savefig(str(stem)+'_preview.png',dpi=180)
  plt.close(self.fig)

def framework(lang):
 c=Canvas(144,110,(7.65,5.85),lang);tr=c.tr
 c.group(2,2,140,31,tr('Qualified inputs and separately trained backbones','合格输入与分任务独立训练的骨干'),'a')
 c.cyl(6,10,25,8,tr('CAISO histories\n30 price nodes','CAISO历史\n30个电价节点'),PEACH)
 c.cyl(6,22,25,8,tr('European histories\nFR / DE / BE','欧洲历史\n法国 / 德国 / 比利时'),YELLOW)
 c.box(38,11,23,18,tr('Information cutoff\nSource verification\nTraining-only scaling','信息截止时间\n来源核验\n仅训练集归一化'),PALEBLUE,8.4)
 c.route([(31,14),(34,14),(34,20),(38,20)]);c.route([(31,26),(34,26),(34,20)],arrow=False)
 c.box(68,11,31,6,tr('Dynamic graph propagation','动态图传播'),GREEN,8.4)
 c.box(68,21,13,5,'TCN',PALEBLUE,8.5);c.box(84,21,15,5,'Transformer',PEACH,7.9)
 c.route([(61,20),(64,20),(64,14),(68,14)]);c.route([(83.5,17),(83.5,19),(74.5,19),(74.5,21)]);c.route([(83.5,19),(91.5,19),(91.5,21)])
 c.route([(74.5,26),(74.5,29),(106,29),(106,21),(110,21)]);c.route([(91.5,26),(91.5,29)],arrow=False)
 c.box(110,11,27,16,tr('Adaptive feature fusion\nShared prediction head\nFULL forecast','自适应特征融合\n共享预测头\nFULL预测'),YELLOW,8.3)
 c.group(2,38,140,35,tr('History-conditioned CAISO correction','由历史信息驱动的CAISO修正'),'b')
 c.box(6,49,25,14,tr('Available history\nAuxiliary forecasts\nFULL forecast','可用历史\n辅助模型预测\nFULL预测'),PALEBLUE,8.6)
 c.ax.add_patch(Polygon([(42,57),(50,49),(58,57),(50,65)],fc=YELLOW,ec=INK,lw=.8,zorder=2))
 c.text(50,57,tr('Active\nextreme?','历史极端\n状态？'),8.2);c.route([(31,57),(42,57)])
 c.box(67,46,39,10,tr('Contextual residual router\nMean / median agreement','情境残差路由\n均值 / 中位数方向一致'),GREEN,8.4)
 c.box(67,60,39,10,tr('Duration-aware spike specialist\nSurvival + amplitude mixture','持续时间感知尖峰专家\n生存概率 + 幅度混合'),PEACH,8.2)
 c.route([(58,57),(62,57),(62,51),(67,51)]);c.text(59.5,48.2,tr('No','否'),8,color=GRAY)
 c.route([(50,65),(67,65)]);c.text(59.5,62.1,tr('Yes','是'),8,color=GRAY)
 c.box(115,50,22,15,tr('Bounded correction\nV7 forecast','有界修正\nV7预测'),YELLOW,8.5)
 c.route([(106,51),(110,51),(110,54),(115,54)]);c.route([(106,65),(110,65),(110,61),(115,61)])
 c.route([(123.5,27),(123.5,38)],dash=(0,(2,2)))
 c.text(121,35.4,tr('CAISO','CAISO'),7.2,ha='right',color=GRAY)
 c.group(2,79,140,28,tr('Matched evaluation within each chronological panel','各时间面板内的匹配评价'),'c')
 vals=[(6,tr('Backbone comparisons','骨干对照'),tr('CAISO H1 / Europe 2016\nTemporal, fusion and graph controls','CAISO上半年 / 欧洲2016年\n时间分支、融合与图结构对照'),PALEBLUE),
       (52,tr('Corrected-system controls','完整修正系统对照'),tr('698 development origins\nFULL / CONCAT / EQUAL','698个开发起点\nFULL / CONCAT / EQUAL'),GREEN),
       (98,tr('Frozen deployment','冻结部署评价'),tr('186 September origins\nV7 / FULL / specialist controls','9月186个起点\nV7 / FULL / 专家对照'),PEACH)]
 for x,title,body,fc in vals:
  c.box(x,86,40,14,'',fc);c.text(x+20,89.6,title,8.7);c.text(x+20,95.5,body,7.7)
 c.text(72,103.9,tr('Paired errors  •  Horizon / location / state profiles  •  Separate statistical families','配对误差  •  预测期 / 地点 / 状态分析  •  各面板独立统计检验'),8.5)
 c.save('Fig01_research_framework')

def architecture(lang):
 c=Canvas(144,108,(7.65,5.74),lang);tr=c.tr
 c.group(2,2,140,25,tr('Dynamic graph encoding','动态图编码'),'a')
 c.stack(6,13,8,8);c.text(10,10,r'$X_t$',10);c.text(10,24,r'$L\times N\times F$',7.5)
 c.box(22,13,21,9,tr('Shared linear\nprojection','共享线性\n映射'),PALEBLUE,8.2);c.route([(16,17.5),(22,17.5)])
 c.box(51,8,30,6,tr('GRU + node embedding','GRU + 节点嵌入'),PEACH,8.3)
 c.box(90,8,30,6,tr('QK scores → top-k → softmax','QK打分 → top-k → softmax'),YELLOW,7.4)
 c.box(51,18,69,6,tr('Graph message + residual connection + layer normalization','图消息传播 + 残差连接 + 层归一化'),GREEN,8.2)
 c.route([(43,17.5),(47,17.5),(47,11),(51,11)]);c.route([(47,17.5),(47,21),(51,21)])
 c.route([(81,11),(90,11)]);c.text(85.5,8.8,r'$c_i$',8)
 c.route([(105,14),(105,18)]);c.text(109,16,r'$A_t$',8)
 c.stack(129,17,7,6,GREEN);c.text(132.5,25,r'$Z_t$',9);c.route([(120,21),(129,21)])
 c.route([(132.5,27),(132.5,30),(35,30),(35,33)]);c.route([(105,30),(105,33)])
 c.group(2,33,66,28,tr('TCN branch','TCN分支'),'b')
 for j,d in enumerate([1,2,4,8]):
  x=7+13*j;c.box(x,42,10,10,'',PALEBLUE);c.text(x+5,44.7,tr('Residual','残差块'),7.3);c.text(x+5,49,r'$d='+str(d)+'$',8.3)
  if j<3:c.route([(x+10,47),(x+13,47)])
  # Small return arc depicts the residual path, not a separate fitted module.
  c.route([(x+1,42),(x+1,40),(x+9,40),(x+9,42)],lw=.6)
 c.route([(56,47),(60,47)]);c.stack(60,44,4,7,PALEBLUE,n=2);c.text(61.8,55,r'$u_i\in\mathbb{R}^{32}$',8.5)
 c.text(33,58.4,tr('2 causal convolutions per block  •  kernel = 3','每块2次因果卷积  •  卷积核 = 3'),7.8)
 c.group(72,33,70,28,tr('Transformer branch','Transformer分支'),'c')
 c.box(76,42,13,10,tr('Average\npooling +\npositions','平均池化\n+\n位置编码'),PEACH,7.6)
 c.box(94,42,14,10,tr('Pre-LN\nMHA\n4 heads','Pre-LN\n多头注意力\n4头'),PALEBLUE,7.5)
 c.box(113,42,12,10,tr('Pre-LN\nFFN\nwidth 64','Pre-LN\n前馈网络\n维度64'),GREEN,7.3)
 c.route([(89,47),(94,47)]);c.route([(108,47),(113,47)]);c.route([(125,47),(129,47)])
 c.stack(129,44,6,7,GREEN,n=2);c.text(132,55,r'$v_i\in\mathbb{R}^{32}$',8.5)
 for x,w in [(94,14),(113,12)]:c.route([(x+1,42),(x+1,40),(x+w-1,40),(x+w-1,42)],lw=.6)
 c.text(106,58.4,tr('1 encoder layer  •  learned-query pooling','1层编码器  •  可学习查询汇总'),7.8)
 c.group(2,66,140,39,tr('Adaptive feature fusion and direct multi-horizon prediction','自适应特征融合与直接多步预测'),'d')
 c.route([(62,61),(62,64),(4.5,64),(4.5,78),(7,78)]);c.route([(132,61),(132,64),(62,64)],arrow=False)
 c.box(7,74,17,8,tr('Branch features\nuᵢ and vᵢ','分支特征\nuᵢ 与 vᵢ'),PALEBLUE,8)
 c.box(30,74,15,8,tr('Shared key\nmap Wₖ','共享键\n映射 Wₖ'),PEACH,8)
 c.box(51,74,28,8,tr('Scaled dot product\nBias + two-way softmax','缩放点积\n偏置 + 双分支softmax'),YELLOW,7.8)
 c.box(87,74,22,8,'',GREEN);c.text(98,76.2,tr('Weighted sum','加权求和'),8.3);c.text(98,80,r'$z_{i,h}=\alpha_u u_i+\alpha_v v_i$',8)
 c.box(116,74,20,8,tr('Shared head\nInverse scaling','共享预测头\n反归一化'),PALEBLUE,8)
 for a,b in [(24,30),(45,51),(79,87),(109,116)]:c.route([(a,78),(b,78)])
 # Values bypass the shared key map: attention operates on features, not outputs.
 c.route([(21,74),(21,71),(98,71),(98,74)],lw=.75);c.text(92,69.5,tr('values','值特征'),7.2,color=GRAY)
 c.box(44,89,42,8,tr('Node context cᵢ + horizon embedding eₕ\nQuery qᵢ,ₕ = Wq cᵢ + eₕ','节点上下文cᵢ + 预测期嵌入eₕ\n查询 qᵢ,ₕ = Wq cᵢ + eₕ'),PEACH,8)
 c.route([(65,89),(65,82)]);c.text(65,85.5,r'$\alpha_u+\alpha_v=1$',8.4,color=GRAY,ha='left')
 c.box(98,89,24,8,tr('CAISO price\ncontext residual','CAISO价格\n上下文残差'),YELLOW,7.7)
 c.route([(122,93),(126,93),(126,82)])
 c.route([(136,78),(139,78),(139,101),(127,101)]);c.text(124,101,r'$\hat{y}_i\in\mathbb{R}^{H}$',10,ha='right')
 c.text(8,92,tr('Graph neighbors\nCAISO: 5; Europe: 2','其他图邻居数\nCAISO：5；欧洲：2'),7.5,ha='left')
 c.text(8,102,tr('Feature width = 32; all H horizons are predicted together.','特征维度 = 32；H个预测期一次性共同输出。'),8,ha='left')
 c.save('Fig03_parallel_architecture')

def admission(lang):
 c=Canvas(144,153,(7.65,8.13),lang);tr=c.tr
 rows=list(csv.DictReader((ROOT/'evidence/registered_h1_metadata_join.csv').open(encoding='utf-8-sig')))
 reg=collections.Counter(r['target_start_utc'][:10] for r in rows)
 adm=collections.Counter(r['target_start_utc'][:10] for r in rows if r['metadata_qualified']=='1')
 assert sum(reg.values())==3743 and sum(adm.values())==1002 and len(adm)==56
 c.group(2,2,140,32,tr('From registered origins to the frozen evaluation panel','从登记起点到冻结评价面板'),'a')
 vals=[(6,tr('Registered origins','登记起点'),'3,743',PEACH),(41,tr('Timing eligible','时间合格'),'1,002',YELLOW),(76,tr('Inputs verified','输入核验通过'),'1,002',GREEN),(111,tr('Frozen and scored','冻结并完成评分'),'1,002',PALEBLUE)]
 for j,(x,t,n,fc) in enumerate(vals):
  c.box(x,10,27,10,'',fc);c.text(x+13.5,13.1,t,8.3);c.text(x+13.5,17.2,n,11)
  if j<3:c.route([(x+27,15),(x+35,15)])
 c.route([(36.8,15),(36.8,25),(41,25)],color=GRAY,lw=.7)
 c.box(41,22,64,7,tr('Excluded: 2,601 price timing + 140 joint price / RTD timing','排除：2,601个价格时间不合格 + 140个价格/RTD共同不合格'),PINK,7.5)
 c.text(109,28.6,tr('56 dates\n18 observed weeks','56个日期\n18个观测周'),7.3,ha='left')
 c.group(2,39,140,84,tr('Date coverage in 2026 H1','2026年上半年日期覆盖'),'b')
 c.text(72,46.1,tr('Each cell shows admitted / registered origins; gaps are retained.','单元格显示纳入 / 登记起点；保留全部日期空缺。'),8.1)
 for m in range(1,7):
  x0=7+46*((m-1)%3);y0=57+37*((m-1)//3);first,nd=calendar.monthrange(2026,m)
  month=calendar.month_name[m] if lang=='en' else f'{m}月';count=sum(v for k,v in adm.items() if k.startswith(f'2026-{m:02d}'))
  c.text(x0+19.5,y0-6.4,f'{month}  (n = {count})',9)
  for i,letter in enumerate(['M','T','W','T','F','S','S'] if lang=='en' else list('一二三四五六日')):c.text(x0+i*5.65+2.7,y0-2.6,letter,7.3)
  for day in range(1,nd+1):
   j=first+day-1;x=x0+(j%7)*5.65;y=y0+(j//7)*4.25;date=f'2026-{m:02d}-{day:02d}';n,a=adm[date],reg[date]
   col=plt.cm.Blues(.02+.74*n/24) if n else '#F4F6F8';c.ax.add_patch(Rectangle((x,y),5.4,4.0,fc=col,ec='#C8D1DF',lw=.35,hatch='..' if a==0 else None,zorder=2))
   ink='white' if n>=16 else INK;c.text(x+.55,y+.95,str(day),5.9,ha='left',color=ink);c.text(x+2.7,y+2.9,f'{n}/{a}',5.8,color=ink)
 c.text(10,120,tr('Pale: no admitted origin     Blue: 1–24 admitted origins     Dotted: no registered origin','浅色：无纳入起点    蓝色：纳入1–24个起点    点纹：无登记起点'),7.9,ha='left')
 c.group(2,128,140,23,tr('Verified information timeline at the first origin (UTC)','首个起点的信息时间线核验（UTC）'),'c')
 # Coordinates preserve actual temporal spacing relative to 23:55.
 def tx(minute):return 10+(minute+17)/85*123
 c.route([(tx(-17),140.5),(tx(68),140.5)],color=GRAY,lw=.75)
 cutoff=tx(0);release=tx(-8-4/60)
 c.ax.plot([cutoff,cutoff],[135.2,147],ls=(0,(3,2)),color=INK,lw=.75)
 c.ax.plot(release,140.5,'o',ms=3.8,mfc='white',mec=BLUE,mew=1,zorder=4)
 c.box(tx(5),139.4,tx(65)-tx(5),2.2,'',PALEBLUE,r=0,lw=.65)
 c.text(release-2,135,tr('Published\n23:46:56','发布\n23:46:56'),7.5);c.route([(release-2,137),(release,139.9)],lw=.6,arrow=False)
 c.text(cutoff+2,135,tr('Cutoff\n23:55','截止\n23:55'),7.5,ha='left')
 for v,label in [(-10,'23:45'),(0,'23:55'),(5,'00:00'),(35,'00:30'),(65,'01:00')]:
  c.ax.plot([tx(v),tx(v)],[140.8,141.7],color=GRAY,lw=.5);c.text(tx(v),144,label,7.2)
 c.text(tx(37),148,tr('12 target intervals: 00:00–01:00','12个目标区间：00:00–01:00'),8)
 c.save('Fig02_final_admission')

if __name__=='__main__':
 for lang in ['en','zh']:
  framework(lang);architecture(lang);admission(lang)
 (ROOT/'qa').mkdir(exist_ok=True)
 (ROOT/'qa/DIAGRAM_LABEL_QA.json').write_text(json.dumps(CHECKS,ensure_ascii=False,indent=2),encoding='utf-8')
 print('Six vector diagrams and high-resolution previews generated.')
