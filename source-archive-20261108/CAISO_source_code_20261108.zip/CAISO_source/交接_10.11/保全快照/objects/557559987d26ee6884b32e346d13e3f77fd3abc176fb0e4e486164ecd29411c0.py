import support as s
def main():
 s.guard(True)
 with s.base.numeric('output_routing_synthetic_qa'):
  import numpy as np
  import output_routing as r
  shape=(2,30,12);v=np.linspace(-500,2000,np.prod(shape),dtype=np.float64).reshape(shape)
  candidate=v*1.1+7;zero=np.zeros(shape);one=np.ones(shape);half=np.full(shape,.5)
  assert np.array_equal(r.apply_to_v7(v,candidate,zero).view(np.uint64),v.view(np.uint64))
  unused=np.full(shape,np.nan)
  assert np.array_equal(r.apply_to_v7(v,unused,zero),v)
  assert np.array_equal(r.graph_local(unused,v,zero),v)
  assert np.allclose(r.graph_local(candidate,v,one),candidate,atol=1e-12,rtol=0)
  routed=r.apply_to_v7(v,candidate,half);lo=np.minimum(v,candidate);hi=np.maximum(v,candidate)
  assert ((routed>=lo)&(routed<=hi)).all()
  a=r.development_benefits(np.array([[[3.]]]),np.array([[[1.]]]),np.array([[[0.]]]))
  assert a['mae_gain'].item()==2 and a['mse_gain'].item()==8
  assert np.array_equal(r.eligible_prefix_rows(np.array([9,10,11]),np.array([4,4,4]),np.array([5,5,5]),10),[True,False,False])
  assert np.array_equal(r.eligible_prefix_rows(np.array([9,9,9]),np.array([4,5,6]),np.array([5,5,5]),10),[True,False,False])
  failures=0
  for bad in [np.full(shape,1.01),np.full(shape,-.01),np.full(shape,np.nan),np.zeros((2,30,1))]:
   try:r.apply_to_v7(v,candidate,bad)
   except AssertionError:failures+=1
  assert failures==4
  s.write('ROUTING_QA.json',dict(status='passed',at=s.now(),code_sha256=s.sha(r.__file__),
   checks=['bitwise zero-action V7 return','inactive unavailable expert not used','graph-zero returns SELF',
   'graph-one returns graph output','bounded convex output','separate MAE and MSE label units',
   'unavailable future labels excluded','invalid weights and accidental horizon broadcasting rejected'],
   model_fits=0,real_targets_read=False,guaranteed_nondegradation=False,protected_verified=s.protected()))
 print('Output routing synthetic checks passed; no fitted gate installed')
if __name__=='__main__':main()
