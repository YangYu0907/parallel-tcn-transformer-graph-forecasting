"""Record the bounded-trial decision and handling of the export failure."""
import gate

def main():
    r=gate.read(gate.HERE/'RESULT.json')
    a=gate.read(gate.HERE/'AUDIT.json')
    d=gate.read(gate.HERE/'DIAGNOSIS.json')
    gate.need(a['status']=='passed' and a['result_sha256']==gate.sha(gate.HERE/'RESULT.json'), 'Audit binding')
    gate.need(d['result_sha256']==a['result_sha256'], 'Diagnostic binding')
    decision=dict(at=gate.now(),status='fixed_candidate_closed_not_promoted',
        event_handled='83fbe550b3f13beae1314cc6047fc1907f514bc2149dedac21fa3c2dcfeb31a2',
        failure_resolved='NumPy scalar conversion at file and console JSON export; original training/scoring source and seal unchanged',
        result_sha256=a['result_sha256'],audit_sha256=gate.sha(gate.HERE/'AUDIT.json'),
        recovery_sha256=gate.sha(gate.HERE/'RECOVERY_AUDIT.json'),diagnosis_sha256=gate.sha(gate.HERE/'DIAGNOSIS.json'),
        finite_fits_completed=27,additional_training_updates_after_event=0,
        new_test_targets_read=False,existing_paper_or_models_replaced=False,
        evidence={
            'scope':'Three seeds, three forward development windows, 2646 origins on12UTCdays; previously inspected June; no independent-test claim',
            'context_MAE_improvement_percent':r['MAE_gain_percent'],
            'context_RMSE_increase_percent':-d['improvement_percent_vs_matched_FULL']['CONTEXT_MIX']['rmse'],
            'horizon_MAE_improvement_percent':d['improvement_percent_vs_matched_FULL']['HORIZON_MIX']['mae'],
            'horizon_RMSE_increase_percent':-d['improvement_percent_vs_matched_FULL']['HORIZON_MIX']['rmse'],
            'first_fold_train_S2_S3_S4_S5_count':0,
            'reversion_S3_FULL_vs_context_MAE':r['state_protection']['3'],
            'after_extreme_S4_FULL_vs_context_MAE':r['state_protection']['4']},
        interpretation='Observed routing errors concentrate in states absent from the first gate-training window. This supports investigating lack of training support and unconstrained routing; does not establish their separate causal contributions.',
        next_bounded_hypothesis={
            'status':'Designed, untested; no automatic continuation of this fixed candidate',
            'idea':'Selectively enable expert mixing only when historical context is sufficiently supported; retain the frozen FULL forecast elsewhere',
            'causal_requirements':'Support and fallback rule fitted from preceding training inputs only, never from future state labels or held-out errors. Score every origin, including fallback cases.',
            'candidate_rule_to_register_before_any_new_score':'Use an existing TRAIN-calibrated current-price extreme flag and prior-fold feature support; no search over state thresholds on these outcomes',
            'next_matched_comparison':['frozen FULL','unchanged context and horizon combinations','same combinations with the single support/fallback rule'],
            'benefit_hypothesis':'Reduce unsupported switches that displace the strong FULL forecast after observed price extremes',
            'cost':'May remove gains in persistent extremes; support checks can be conservative and FULL itself can still err',
            'acceptance':'Keep original all-metric and six-state protections. Require future admitted independent evaluation before replacing paper results.',
            'literature':[{'title':'Mixture-of-Linear-Experts for Long-term Time Series Forecasting','url':'https://proceedings.mlr.press/v238/ni24a.html','use':'Adaptive expert combination; not a guarantee of universal improvement'},
                          {'title':'SelectiveNet: A Deep Neural Network with an Integrated Reject Option','url':'https://proceedings.mlr.press/v97/geifman19a.html','use':'Selective prediction and risk-coverage tradeoff; fallback to FULL is our proposed adaptation, not the published architecture'}]},
        periodic_wakeups=False,notification_delivery='Current foreground turn; no duplicate model wakeup')
    gate.write(gate.HERE/'DECISION.json',decision)
    h=gate.read(gate.ROOT/'HANDOFF.json')
    h['context_expert_trial'].update(decision=str(gate.HERE/'DECISION.json'),
        diagnosis=str(gate.HERE/'DIAGNOSIS.json'),fixed_candidate_closed=True,
        next_hypothesis_status='designed_untested_not_launched',last_handled_event=decision['event_handled'])
    h.update(training_active=False,current_process=None,current_plan_complete=True,
        current_stage='context_expert_development_closed_not_promoted')
    gate.write(gate.ROOT/'HANDOFF.json',h)
    gate.write(gate.ROOT/'event_driven_automation/handled'/('event_'+decision['event_handled']+'.json'),
        dict(at=gate.now(),event_id=decision['event_handled'],status='resolved_training_complete_export_repaired',
             decision=str(gate.HERE/'DECISION.json'),notification='current_foreground_turn',
             repeat_notification_required=False,new_training_process=False))
    print('Bounded trial closed; paper and original models retained.')

if __name__=='__main__':main()
