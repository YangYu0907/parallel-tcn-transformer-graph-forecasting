"""Prediction-head-before/after placement is explicit: fuse features, then decode."""
from __future__ import annotations

import math
from dataclasses import dataclass

import torch
from torch import Tensor, nn
import torch.nn.functional as F

from .model_dynamic_dual_stream_v4 import DynamicGraphEncoder, TCNBranch, TransformerBranch


@dataclass
class FusionConfig:
    num_nodes: int = 30
    input_dim: int = 29
    hidden_dim: int = 32
    horizon: int = 12
    graph_top_k: int = 5
    dropout: float = 0.1
    variant: str = "FULL"


class GraphEncoder(DynamicGraphEncoder):
    def __init__(self, config: FusionConfig):
        super().__init__(config.num_nodes, config.input_dim, config.hidden_dim, config.graph_top_k)
        self.static = config.variant == "STATIC"

    def dynamic_adjacency(self, projected: Tensor) -> tuple[Tensor, Tensor]:
        if not self.static:
            return super().dynamic_adjacency(projected)
        batch, steps, nodes, hidden = projected.shape
        sequence = projected.permute(0, 2, 1, 3).reshape(batch * nodes, steps, hidden)
        _, state = self.context_gru(sequence)
        context = state[-1].reshape(batch, nodes, hidden) + self.node_embedding.unsqueeze(0)
        scores = self.query(self.node_embedding) @ self.key(self.node_embedding).T / math.sqrt(hidden)
        identity = torch.eye(nodes, dtype=torch.bool, device=scores.device)
        values, indices = scores.masked_fill(identity, -torch.inf).topk(self.top_k, dim=-1)
        sparse = torch.full_like(scores, -torch.inf).scatter(-1, indices, values)
        adjacency = sparse.masked_fill(identity, 0).softmax(dim=-1)
        return adjacency.unsqueeze(0).expand(batch, -1, -1), context


class FeatureAttention(nn.Module):
    def __init__(self, dim: int, horizon: int):
        super().__init__()
        self.query = nn.Linear(dim, dim, bias=False)
        self.key = nn.Linear(dim, dim, bias=False)
        self.horizon_embedding = nn.Parameter(torch.empty(horizon, dim))
        self.branch_bias = nn.Parameter(torch.zeros(2))
        nn.init.normal_(self.horizon_embedding, std=dim ** -0.5)

    def forward(self, tcn: Tensor, transformer: Tensor, context: Tensor) -> Tensor:
        query = self.query(context).unsqueeze(2) + self.horizon_embedding
        keys = self.key(torch.stack((tcn, transformer), dim=2))
        logits = torch.einsum("bnhd,bnkd->bnhk", query, keys) / math.sqrt(tcn.shape[-1])
        return (logits + self.branch_bias).softmax(dim=-1)


class SharedHead(nn.Module):
    def __init__(self, dim: int, horizon: int, dropout: float):
        super().__init__()
        self.horizon_embedding = nn.Parameter(torch.empty(horizon, dim))
        nn.init.normal_(self.horizon_embedding, std=dim ** -0.5)
        self.network = nn.Sequential(nn.Linear(dim, dim), nn.GELU(), nn.Dropout(dropout), nn.Linear(dim, 1))

    def forward(self, fused_features: Tensor) -> Tensor:
        return self.network(fused_features + self.horizon_embedding).squeeze(-1)


class FeatureFusionModel(nn.Module):
    VARIANTS = ("TCN", "FULL", "STATIC", "CONCAT", "EQUAL", "TRANSFORMER")

    def __init__(self, config: FusionConfig):
        super().__init__()
        if config.variant not in self.VARIANTS:
            raise ValueError(config.variant)
        self.config = config
        self.graph = GraphEncoder(config)
        self.tcn = TCNBranch(config.hidden_dim, (1, 2, 4, 8), 3, config.dropout)
        # Preserve the existing low-frequency preprocessing and backbone.
        self.transformer = TransformerBranch("fixed_pool", config.input_dim, config.hidden_dim,
                                             4, 1, 64, config.dropout, 6, 12, 6, ())
        self.attention = FeatureAttention(config.hidden_dim, config.horizon)
        self.head = SharedHead(config.hidden_dim, config.horizon, config.dropout)
        self.concat_projection = nn.Sequential(nn.Linear(2 * config.hidden_dim, config.hidden_dim), nn.GELU())
        unused = []
        if config.variant == "TCN":
            unused.append(self.transformer)
        if config.variant == "TRANSFORMER":
            unused.append(self.tcn)
        if config.variant not in ("FULL", "STATIC"):
            unused.append(self.attention)
        if config.variant != "CONCAT":
            unused.append(self.concat_projection)
        for module in unused:
            module.requires_grad_(False)

    @staticmethod
    def low_frequency_history(encoded: Tensor) -> Tensor:
        batch, steps, nodes, hidden = encoded.shape
        seq = encoded.permute(0, 2, 3, 1).reshape(batch * nodes, hidden, steps)
        kernel = min(12, steps)
        pooled = F.avg_pool1d(seq, kernel, min(6, kernel), ceil_mode=True)
        return pooled.transpose(1, 2).reshape(batch, nodes, -1, hidden).permute(0, 2, 1, 3)

    def forward(self, x: Tensor) -> dict[str, Tensor]:
        c = self.config
        if x.ndim != 4 or x.shape[2:] != (c.num_nodes, c.input_dim):
            raise ValueError("Expected [batch, history, registered_nodes, registered_features]")
        encoded, adjacency, context = self.graph(x)
        tcn = torch.zeros_like(context) if c.variant == "TRANSFORMER" else self.tcn(encoded)
        transformer = (torch.zeros_like(context) if c.variant == "TCN" else
                       self.transformer(self.low_frequency_history(encoded), x))
        shape = (x.shape[0], c.num_nodes, c.horizon, 2)
        if c.variant in ("FULL", "STATIC"):
            weights = self.attention(tcn, transformer, context)
            fused = (weights[..., 0:1] * tcn.unsqueeze(2) + weights[..., 1:2] * transformer.unsqueeze(2))
        elif c.variant == "CONCAT":
            fused = self.concat_projection(torch.cat((tcn, transformer), dim=-1))
            fused = fused.unsqueeze(2).expand(-1, -1, c.horizon, -1)
            # Diagnostic convention only; these are not CONCAT attention weights.
            weights = x.new_full(shape, 0.5)
        else:
            weights = x.new_full(shape, 0.5)
            if c.variant == "TCN":
                weights[..., 0], weights[..., 1] = 1, 0
            elif c.variant == "TRANSFORMER":
                weights[..., 0], weights[..., 1] = 0, 1
            fused = weights[..., 0:1] * tcn.unsqueeze(2) + weights[..., 1:2] * transformer.unsqueeze(2)
        return {"prediction": self.head(fused), "branch_weights": weights,
                "dynamic_adjacency": adjacency, "fused_features": fused}
