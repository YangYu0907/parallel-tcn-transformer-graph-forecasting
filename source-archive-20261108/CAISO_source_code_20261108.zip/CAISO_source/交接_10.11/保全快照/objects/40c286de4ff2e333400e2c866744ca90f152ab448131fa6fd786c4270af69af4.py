from pathlib import Path
import sys,json
HERE=Path(__file__).resolve().parent;B=HERE.parent
sys.path.insert(0,str(B/'context_expert_v1_20260929'));import gate
old=B/'recovery_guard_v8_20260930'
assert not (HERE/'EXECUTION_SEAL.json').exists(),'Do not overwrite a registered experiment'
c=(old/'common.py').read_text(encoding='utf-8').replace('recovery_guard_v8_20260930','episode_spike_v9_20260930').replace("ARMS=['V7','CAL_ONLY','GUARD_ONLY','CAL_GUARD']","ARMS=['V7','EVENT_ONLY','EVENT_MIX']")
(HERE/'common.py').write_text(c,encoding='utf-8')
m=(old/'manager.py').read_text(encoding='utf-8').replace('recovery_v8','episode_v9').replace('recovery_guard_v8','episode_spike_v9').replace('TRAIN_chronological_calibration','TRAIN_event_weighted_specialist').replace("('worker.py','audit.py')","('worker.py','audit.py')")
(HERE/'manager.py').write_text(m,encoding='utf-8')
(HERE/'queue').mkdir(exist_ok=True)
gate.write(HERE/'PROTOCOL.json',dict(at=gate.now(),status='registered_before_new_fit',version='V9',
 purpose='Test whether repeated windows within long observed spike episodes contribute to continuation/recovery conflict; one bounded weighting amendment, no architecture search.',
 authorization='Current user asks high-level journal spike methods and improvement retaining core elements; prior bounded development authorization continues.',
 mandatory_elements=['TCN','Transformer','dynamic GNN','parallel temporal branches','adaptive feature-fusion attention','original head'],
 literature=[
 dict(title='Regime jumps in electricity prices',authors='Huisman and Mahieu',journal='Energy Economics',year=2003,doi='10.1016/S0140-9883(03)00041-0',url='https://repub.eur.nl/pub/111/erimrs20010815170147.pdf',access='Author working-paper full text, especially model and transition restrictions; published metadata verified.',supports='Separate ordinary dynamics, spike and reversal. Published restrictions force rapid sequential reversal; NOT copied as a one-step law for 5-minute CAISO.'),
 dict(title='Short-Term Electricity Price Forecast Using Frequency Analysis and Price Spikes Oversampling',authors='Chenxu Zhang, Yong Fu, Lin Gong',journal='IEEE Transactions on Power Systems',year=2023,doi='10.1109/TPWRS.2022.3218712',url='https://ieeexplore.ieee.org/document/9937193/',access='Publisher abstract and metadata, not full methods.',supports='Treat spike sample imbalance explicitly and separate normal/spike forecasting. This paper uses ESPO/SMOTE; our episode weighting is an adaptation to observed repeated-window concentration, not its reproduction.'),
 dict(title='Forecasting spikes in electricity prices',authors='Christensen, Hurn and Lindsay',journal='International Journal of Forecasting',year=2012,doi='10.1016/j.ijforecast.2011.02.019',url='https://www.sciencedirect.com/science/article/pii/S0169207011000550',access='Publisher abstract/introduction and author working paper previously inspected.',supports='Discrete-time spike occurrence hazard and relevant market history. V7 models exit rather than replicating occurrence task.'),
 dict(title='Predicting price spikes in electricity markets using a regime-switching model with time-varying parameters',authors='Mount, Ning and Cai',journal='Energy Economics',year=2006,doi='10.1016/j.eneco.2005.09.008',url='https://www.sciencedirect.com/science/article/abs/pii/S0140988305000897',access='Publisher abstract.',supports='Load/reserve-driven transition probabilities; spike prediction depends on accurate reserve margin. Current data lack admitted reserve margin: do not claim a physical supply-margin mechanism.')],
 change='Replace per-origin specialist training weights with per-origin weights times inverse sqrt(number of qualifying fit origins in the same node-specific spike episode), renormalized to the identical total task weight. No synthetic prices or label filtering.',
 episode='Contiguous historical above-TRAIN-q99 absolute deviations with same sign; break on missing price or non-300s timestamp gap. Determine onset causally using history up to origin-1. Reconstruct beyond 24h censor; separate TRAIN fit/cal scopes for counts.',
 exponent=.5,reason='Fixed partial balancing between time-weighted and event-weighted objectives. Neither value nor causal usefulness claimed established by cited paper; no search.',
 data='Same 20998 TRAIN fit and 613 calibration origin-node pairs, existing 140/16 dates. All horizons and all outcomes retained. Reuse V7 admitted covariates. TRAIN calibration remains naturally weighted using the unchanged V7 temperature rule.',
 models='V7 CONTEXT hazard/postexit HGB, 80 iterations,15 leaves,min_leaf50,lr.05,L2=1,early_stopping=False. Six fits,3 existing seeds. Original amplitudes, FULL, graph and temporal parameters frozen.',
 arms=['V7 frozen control','EVENT_ONLY mechanistic control','EVENT_MIX sole candidate'],
 candidate='At observed-extreme origins, one-half V7 plus one-half EVENT_ONLY; outside these origins exact V7. EVENT_ONLY uses unchanged mean/median agreement and at least25% FULL anchor. No future-state routing.',
 selection='No adaptive hyperparameter or blend search; final fixed80 iterations. Calibrate temperature in[.5,2] exactly as original specialist. Keep every result; never promote a favorable control after candidate fails.',
 evaluation='Same already-inspected H1 development698origins42dates30nodes12horizons. Never call independent confirmation. No new sealed targets accessed.',
 acceptance='Candidate: five aggregate metrics,all6stateMAE/RMSE,all30nodeMAE/RMSE,all12horizonMAE/RMSE positive versus originalFULL; at least2seeds improve MAE; each state>=3dates. All original positive directions must remain positive; magnitude may reduce. Examine probabilities by each state; pooled scores alone cannot certify recovery.',
 budget_seconds=3600,stop='One candidate; fail preservation means close without another search. No paper replacement absent a new admitted frozen independent period.',
 resources='Single numerical worker, existing5GiBlaunch/4GiBruntime guards, C temporary artifacts authorized; checkpoint every10 iterations; same local event listener; no scheduled wakeups.',
 novelty_boundary='Episode balancing is an empirical hypothesis motivated by data concentration and spike-sampling literature. It changes the training weighting target and could reduce sustained-spike gains. No universal error guarantee.'))
print('Protocol and runtime prepared')
