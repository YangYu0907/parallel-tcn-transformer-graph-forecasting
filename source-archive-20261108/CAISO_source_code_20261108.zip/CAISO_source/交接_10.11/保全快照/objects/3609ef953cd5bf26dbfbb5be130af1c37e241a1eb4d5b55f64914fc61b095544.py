import common as c
import subprocess, os, traceback

def emit(event,path):
    key='v23_probability_'+event+'_'+c.sha(path)
    c.gate.write(c.B/'event_driven_automation/inbox'/(key+'.json'),dict(schema='caiso_research_event_v1',event_id=key,event=event,evidence_path=str(path),at=c.now(),periodic=False))
    return key

def main():
    try:
        c.verify()
        assert not (c.HERE/'AUDIT.json').exists(),'Already audited; do not repeat'
        for script in ('run.py','audit.py'):
            c.check(True);c.write(c.HERE/'status.json',dict(at=c.now(),pid=os.getpid(),event='step_process_started',script=script))
            proc=subprocess.run(['D:/Documents/conda_envs/tcn_air/python.exe','-u',str(c.HERE/script)],cwd=str(c.HERE))
            if proc.returncode:raise RuntimeError(script+' exit='+str(proc.returncode))
        r=c.read(c.HERE/'RESULT.json');key=emit('audited_result_ready' if r['screen']['passed'] else 'unexpected_result',c.HERE/'AUDIT.json')
        c.write(c.HERE/'status.json',dict(at=c.now(),pid=os.getpid(),event='finite_mechanism_queue_completed',event_id=key,status='audited_complete',screen_passed=r['screen']['passed'],diagnostic_only=True))
    except BaseException as exc:
        stopped=isinstance(exc,InterruptedError)
        try:c.check()
        except InterruptedError:stopped=True
        except Exception:pass
        path=c.HERE/'FAILURE.json';c.write(path,dict(at=c.now(),error=str(exc),traceback=traceback.format_exc(),V7_unchanged=True))
        key=None if stopped else emit('blocking_failure',path)
        c.write(c.HERE/'status.json',dict(at=c.now(),pid=os.getpid(),event='user_stop_before_launch' if stopped else 'step_stopped_or_failed',classification='user_stop' if stopped else 'failure',event_id=key))
        raise

if __name__=='__main__':main()
