"""Create a new trial; never alter the sealed V26 implementation."""
from pathlib import Path
import ast

B = Path(__file__).resolve().parent
old = B / 'temporal_memory_v26_20261001'
new = B / 'horizon_value_v27_20261001'
new.mkdir(exist_ok=False)


def replace(s, a, b):
    assert a in s, a
    return s.replace(a, b)


def save(name, text):
    if name.endswith('.py'):
        ast.parse(text)
    (new / name).write_text(text, encoding='utf-8')


s = (old / 'common.py').read_text(encoding='utf-8')
s = s.replace('7200', '1800').replace('Two-hour finite', 'Thirty-minute finite')
s = replace(s, "for k in ('rmse','near_h1_4_mae','h12_mae')))",
            "for k in ('rmse','near_h1_4_mae','h12_mae'))\n            and all(token['by_state'][j][k] is not None and parent['by_state'][j][k] is not None\n                    and token['by_state'][j][k]<=parent['by_state'][j][k]\n                    for j in range(6) for k in ('mae','rmse')))")
s += '''
MEMROOT=Path('C:/Users/于阳/CAISO_temporary_storage/temporal_memory_v26_20261001')
def memory(case,part,np):
    path=MEMROOT/case['id']/part/'memory.npy'
    receipt=read(path.parent/'receipt.json')
    assert receipt['identity']['parent']==case['parent_sha256']
    assert receipt['identity']['part']==part
    assert receipt['identity']['seal']==sha(B/'temporal_memory_v26_20261001/SEAL.json')
    assert receipt['identity']['old_receipt']==sha(OLDART/case['id']/'cache'/part/'receipt.json')
    assert sha(path)==receipt['sha256']
    return np.load(path,mmap_mode='r',allow_pickle=False)
'''
save('common.py', s)

s = (old / 'model.py').read_text(encoding='utf-8')
s = replace(s, 'The control has equal parameters and tokens, but only two branch summaries.',
            'Both arms use all temporal tokens. Only the modulation horizon input differs.')
s = replace(s, 'def __init__(self,seed):', "def __init__(self,seed,arm='HORIZON'):")
s = replace(s, 'super().__init__()', "super().__init__()\n        assert arm in ('HORIZON','MEAN')\n        self.arm=arm")
s = replace(s, 'seed+2600000', 'seed+2700000')
s = replace(s, 'nn.init.zeros_(self.output.weight);nn.init.zeros_(self.output.bias)',
            'nn.init.zeros_(self.output.weight);nn.init.zeros_(self.output.bias)\n            self.modulation=nn.Linear(32,32)\n            nn.init.zeros_(self.modulation.weight);nn.init.zeros_(self.modulation.bias)')
s = replace(s, "return fused+self.output(torch.einsum('bnhk,bnkd->bnhd',weight,v))",
            "u=torch.einsum('bnhk,bnkd->bnhd',weight,v)\n        condition=horizon if self.arm=='HORIZON' else horizon.mean(dim=-2,keepdim=True)\n        gamma,beta=self.modulation(F.layer_norm(fused+condition,(32,))).chunk(2,dim=-1)\n        return fused+self.output((1+torch.tanh(gamma))*u+beta)")
s = replace(s, 'return fused+F.linear(a@v,reader.output.weight,reader.output.bias)',
            "condition=horizon if reader.arm=='HORIZON' else horizon.mean(dim=-2,keepdim=True)\n    parameters=F.linear(F.layer_norm(fused+condition,(32,)),reader.modulation.weight,reader.modulation.bias)\n    value=(1+parameters[...,:16].tanh())*(a@v)+parameters[...,16:]\n    return fused+F.linear(value,reader.output.weight,reader.output.bias)")
save('model.py', s)

s = (old / 'run.py').read_text(encoding='utf-8').replace('V26', 'V27').replace('TOKEN','HORIZON').replace('SUMMARY','MEAN')
start = s.index('        def cache(')
stop = s.index('        def evaluate(', start)
s = s[:start] + s[stop:]
s = s.replace("from model import Reader,encode,decode,summary_memory", 'from model import Reader,decode')
s = replace(s, "torch.from_numpy(np.array(mem[ids],copy=True)) if kind=='HORIZON' else summary_memory(f)",
            'torch.from_numpy(np.array(mem[ids],copy=True))')
s = replace(s, "torch.from_numpy(np.array(mf[ids],copy=True)) if kind=='HORIZON' else summary_memory(f)",
            'torch.from_numpy(np.array(mf[ids],copy=True))')
s = replace(s, "mf=cache(case,base,'fit',fit);mv=cache(case,base,'june_dense',valid)",
            "mf=c.memory(case,'fit',np);mv=c.memory(case,'june_dense',np)\n            assert len(mf)==len(fit['y']) and len(mv)==len(valid['y'])")
s = replace(s, "reader=Reader(case['seed'])", "reader=Reader(case['seed'],kind)")
s = s.replace('case[\'seed\']+2600000+e', "case['seed']+2700000+e")
s = replace(s, 'stopped_after_first_seed=len(results)==1', 'one_seed_pilot=True')
save('run.py', s)

s = (old / 'audit.py').read_text(encoding='utf-8').replace('V26','V27').replace('TOKEN','HORIZON').replace('SUMMARY','MEAN')
start = s.index("            memory=np.load(c.ART")
stop = s.index('            summary={}', start)
s = s[:start] + "            memory=c.memory(case,'june_dense',np)\n" + s[stop:]
s = replace(s, "torch.from_numpy(np.array(memory[ids],copy=True)) if arm=='HORIZON' else torch.stack([f['t']]*8+[f['z']]*8,2)",
            'torch.from_numpy(np.array(memory[ids],copy=True))')
s = replace(s, "reader=Reader(case['seed'])", "reader=Reader(case['seed'],arm)")
s = replace(s, "max(t[k]-b[k] for k in ('rmse','near_h1_4_mae','h12_mae'))<=0)",
            "max(t[k]-b[k] for k in ('rmse','near_h1_4_mae','h12_mae'))<=0 and\n                   all(t['by_state'][j][k] is not None and b['by_state'][j][k] is not None\n                       and t['by_state'][j][k]<=b['by_state'][j][k] for j in range(6) for k in ('mae','rmse')))")
s = replace(s, "assert len(rows)==3 or (len(rows)==1 and not rows[0]['first_seed_passed'])", 'assert len(rows)==1')
s = replace(s, 'all_three_seeds=len(rows)==3,', 'one_seed_complete=len(rows)==1,')
s = replace(s, "at_least_two_seeds=sum(x['metrics']['HORIZON']['mae']<x['metrics']['PARENT']['mae'] for x in rows)>=2,",
            "no_promotion_from_pilot=True,")
s = replace(s, 'beats_summary=', 'beats_matched_mean=')
s = replace(s, 'If screen passes, first audit fully matched fusion controls and V7 integration on development;',
            'If pilot passes, separately register remaining two seeds before fully matched controls and V7 integration;')
save('audit.py', s)

s = (old / 'manager.py').read_text(encoding='utf-8').replace('V26','V27').replace('v26_temporal_memory','v27_horizon_value')
s = s.replace('temporal_memory_v26=', 'horizon_value_v27=').replace('temporal-memory', 'horizon-conditioned-value')
s = replace(s, "c.verify();assert not (c.HERE/'AUDIT.json').exists(),'Already completed'",
            "c.verify();assert not (c.HERE/'AUDIT.json').exists(),'Already completed'\n        launch=c.read(c.HERE/'LAUNCH.json')\n        assert launch['manager_pid']==os.getpid(), 'Exit monitoring launch handshake absent'")
# Wait only for a launch-file handshake, without any scheduled model notification.
s = replace(s, "launch=c.read(c.HERE/'LAUNCH.json')", "import time\n        deadline=time.monotonic()+30\n        while not (c.HERE/'LAUNCH.json').exists():\n            if time.monotonic()>deadline:raise RuntimeError('Launch monitoring handshake timed out')\n            time.sleep(.1)\n        launch=c.read(c.HERE/'LAUNCH.json')")
save('manager.py', s)
print('V27 isolated scaffold created:', new)
