"""Synthetic formula, frozen-backbone, gating, gradient and exact-resume tests."""
import copy,io,json,sys
import gate
def main():
    with gate.exclusive('adapter_synthetic_qa'):
        np,torch,limiter=gate.runtime()
        from torch import nn
        from adapter import AdaptedFULL,ResidualAdapter,fingerprint
        from math_ops import objective,step
        import train
        train.torch=torch
        tests=[]
        values=torch.tensor([-2.,-.2,.4,1.5],dtype=torch.float64,requires_grad=True)
        loss=objective(values,torch.zeros_like(values))
        manual=sum(.5*float(x)**2 if abs(float(x))<=.5 else .5*(abs(float(x))-.25) for x in values.detach())/4
        assert abs(float(loss)-manual)<1e-15
        loss.backward();assert torch.equal(values.grad,values.detach().clamp(-.5,.5)/4)
        tests+=['scalar_Huber_value_oracle','Huber_gradient_oracle']
        class Head(nn.Module):
            def __init__(self):
                super().__init__();self.linear=nn.Linear(32,1)
            def forward(self,f):return self.linear(f).squeeze(-1)
        class FakeBase(nn.Module):
            def __init__(self):
                super().__init__();self.head=Head()
            def forward(self,x):return dict(prediction=self.head(x),head_features=x)
        torch.manual_seed(824)
        b=FakeBase().eval();x=torch.randn(4,30,12,32);y=torch.randn(4,30,12)
        m=AdaptedFULL(copy.deepcopy(b),20260813,'HOURLY')
        g=AdaptedFULL(copy.deepcopy(b),20260813,'GLOBAL')
        mask=torch.tensor([True,False,True,False])
        assert fingerprint(m)==fingerprint(g)
        assert sum(p.numel() for p in m.parameters() if p.requires_grad)==552
        assert torch.equal(m(x,mask)['prediction'],b(x)['prediction'])
        assert torch.equal(g(x,mask)['prediction'],b(x)['prediction'])
        tests+=['matched_initialization','552_parameters','identity_initial_prediction']
        m.train();assert not m.base.training and all(not p.requires_grad for p in m.base.parameters())
        opt=train.opt_for(m);original_fp=fingerprint(m.base)
        step(m,opt,x,y,mask)
        assert fingerprint(m.base)==original_fp and all(p.grad is None for p in m.base.parameters())
        assert torch.count_nonzero(m.adapter.up.weight)>0
        assert torch.equal(m(x,mask)['prediction'][~mask],b(x)['prediction'][~mask])
        tests+=['base_frozen_after_update','adapter_learns','offhour_exact_after_update']
        # Differentiate an all-off-hour batch: no parameter receives a data gradient.
        opt.zero_grad(set_to_none=True);objective(m(x,torch.zeros(4,dtype=torch.bool))['prediction'],y).backward()
        assert all(p.grad is not None and torch.count_nonzero(p.grad)==0 for p in m.adapter.parameters())
        tests+=['masked_offhour_zero_gradient']
        # Gate treatment equals GLOBAL exactly when every origin is hourly.
        m2=AdaptedFULL(copy.deepcopy(b),20260814,'HOURLY')
        g2=AdaptedFULL(copy.deepcopy(b),20260814,'GLOBAL')
        optm=train.opt_for(m2);optg=train.opt_for(g2);ones=torch.ones(4,dtype=torch.bool)
        step(m2,optm,x,y,ones);step(g2,optg,x,y,ones)
        assert fingerprint(m2)==fingerprint(g2)
        tests+=['all_hourly_matches_ungated_exactly']
        # Formula and finite-difference oracle for a nonzero adapter.
        ad=copy.deepcopy(m.adapter).double();features=x[:1,:1,:1].double().requires_grad_()
        a=ad(features)
        z=features@ad.down.weight.T+ad.down.bias
        gelu=.5*z*(1+torch.erf(z/2**.5))
        expected=features+gelu@ad.up.weight.T+ad.up.bias
        assert torch.allclose(a,expected,rtol=0,atol=1e-14)
        scalar=(a*a).sum();grad=torch.autograd.grad(scalar,features)[0]
        eps=1e-6;plus=features.detach().clone();minus=features.detach().clone();plus[...,3]+=eps;minus[...,3]-=eps
        fd=float(((ad(plus)**2).sum()-(ad(minus)**2).sum())/(2*eps))
        assert abs(fd-float(grad[...,3]))<1e-7
        tests+=['manual_adapter_formula','adapter_finite_difference']
        # Saved optimizer/model/RNG resumes an interrupted run bit for bit.
        uninterrupted=copy.deepcopy(m);ou=train.opt_for(uninterrupted);ou.load_state_dict(copy.deepcopy(opt.state_dict()))
        buf=io.BytesIO();torch.save(dict(model=m.state_dict(),optimizer=opt.state_dict(),rng=torch.get_rng_state()),buf);buf.seek(0)
        saved=torch.load(buf,weights_only=False)
        resumed=AdaptedFULL(copy.deepcopy(b),20260813,'HOURLY');resumed.load_state_dict(saved['model'])
        ore=train.opt_for(resumed);ore.load_state_dict(saved['optimizer']);torch.set_rng_state(saved['rng'])
        for _ in range(3):step(uninterrupted,ou,x,y,mask)
        torch.set_rng_state(saved['rng'])
        for _ in range(3):step(resumed,ore,x,y,mask)
        assert fingerprint(uninterrupted)==fingerprint(resumed)
        for i,v in ou.state_dict()['state'].items():
            for k,value in v.items():
                peer=ore.state_dict()['state'][i][k]
                assert torch.equal(value,peer) if torch.is_tensor(value) else value==peer
        tests+=['exact_optimizer_model_resume']
        # Exercise the actual required FULL architecture on synthetic history.
        from models.factory import build_backbone
        actual=build_backbone('FULL',20260813,[[1.,1.]]*30).eval()
        real=AdaptedFULL(actual,20260813,'HOURLY').eval()
        torch.manual_seed(925);history=torch.randn(4,288,30,29)*.1
        rng=torch.get_rng_state().clone();base_fp=fingerprint(actual)
        with torch.inference_mode():
            original=actual(history);out=real(history,mask)
        assert torch.equal(out['prediction'],original['prediction'])
        assert torch.equal(out['branch_weights'],original['branch_weights'])
        assert torch.equal(out['dynamic_adjacency'],original['dynamic_adjacency'])
        assert out['branch_weights'].shape==(4,30,12,2) and torch.allclose(out['branch_weights'].sum(-1),torch.ones(4,30,12))
        assert fingerprint(actual)==base_fp and torch.equal(rng,torch.get_rng_state())
        tests+=['real_FULL_identity','real_attention_graph_preserved','real_eval_no_randomness_or_mutation']
        for bad in (torch.ones(4),torch.ones(3,dtype=torch.bool)):
            try:real(history,bad)
            except ValueError:pass
            else:raise RuntimeError('Invalid phase mask accepted')
        tests+=['invalid_mask_rejected']
        sources={}
        for p in gate.HERE.glob('*.py'):
            compile(p.read_text(encoding='utf-8'),str(p),'exec')
            sources[gate.rel(p)]=gate.sha(p)
        report=dict(status='passed',at=gate.now(),tests=tests,sources=sources,
            real_data_arrays_read=False,synthetic_model_calls=True,real_training_started=False,
            independent_formula_and_gradient_checks=True,exact_resume_checked=True)
        gate.write(gate.HERE/'synthetic_qa.json',report)
        print(json.dumps(dict(status='passed',checks=len(tests))))
if __name__=='__main__':main()
