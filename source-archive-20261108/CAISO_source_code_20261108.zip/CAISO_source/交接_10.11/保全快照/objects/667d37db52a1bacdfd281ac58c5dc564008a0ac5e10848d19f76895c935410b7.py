"""Separate scoring formulas, sampled model replay, and immutable-file audit."""
from pilot import *
import math
def audit():
 pr=verify();checks=[];rows=c.read(P/'ALL_RESULTS.json');result=c.read(P/'RESULT.json')
 for window in [1,2,3]:
  for seed in c.SEEDS:
   for info,arms in [('old','AB'),('new','CD')]:
    guard();d=prepare_data(seed,window,info);out=P/'fits'/f'w{window}_{seed}_{info}';ck=c.read(out/'COMPLETE.json')
    assert ck['protocol_sha256']==c.sha(P/'PROTOCOL.json')
    for path,h in ck['models'].items():assert c.sha(path)==h
    with np.load(out/'raw.npz') as z:raw=z['q']
    indices=np.unique(np.linspace(0,len(raw)-1,64,dtype=int))
    for j in [0,MID,len(Q)-1]:
     model=load(out/f'q{j}.pkl');assert model.n_iter_==60
     assert np.array_equal(model.predict(d['X'][indices]),raw[indices,j]);checks.append(f'w{window}:{seed}:{info}:replayQ{j}')
    for arm in arms:
     path=out/f'{arm}.npz';assert c.sha(path)==ck['outputs'][str(path)]
     with np.load(path) as z:q=z['q'];p=z['point']
     assert np.all(np.diff(q)>0) and np.isfinite(q).all()
     assert np.array_equal(p,d['point']+q[:,MID]*d['scale'])
     assert np.array_equal(p[d['h']<4],d['point'][d['h']<4])
     if arm in 'AC':assert np.array_equal(p,d['point'])
     ev=d['evaluate'];err=p[ev]-d['truth'][ev];n=len(err)
     r=next(r for r in rows if r['window']==window and r['seed']==seed and r['arm']==arm and r['part']=='overall')
     assert math.isclose(math.fsum(np.abs(err))/n,r['mae'],rel_tol=1e-12)
     assert math.isclose(math.sqrt(math.fsum(err*err)/n),r['rmse'],rel_tol=1e-12)
     curr=d['point'][ev,None]+q[ev]*d['scale'][ev,None];y=d['truth'][ev]
     wis=.5*abs(curr[:,MID]-y)
     for alpha,lo,hi in [(.2,4,8),(.1,3,9)]:
      width=curr[:,hi]-curr[:,lo]
      interval=width+2/alpha*(np.maximum(curr[:,lo]-y,0)+np.maximum(y-curr[:,hi],0))
      wis+=alpha/2*interval
      level=int(100*(1-alpha));coverage=((y>=curr[:,lo])&(y<=curr[:,hi])).mean()
      assert math.isclose(float(coverage),r[f'coverage{level}'],abs_tol=1e-12)
      assert math.isclose(float(width.mean()),r[f'width{level}'],rel_tol=1e-12)
     assert math.isclose(float((wis/2.5).mean()),r['wis'],rel_tol=1e-12)
     checks.append(f'w{window}:{seed}:{arm}:point_and_interval_formulas')
    del d,raw,q;gc.collect()
 # Independently recompute every pooled subgroup from saved cell errors.
 for seed in c.SEEDS:
  for arm in 'ABCD':
   with np.load(P/'evaluated'/f'{arm}_{seed}.npz') as z:dd={k:z[k] for k in z.files}
   for r in [r for r in rows if r['window']==0 and r['seed']==seed and r['arm']==arm]:
    part=r['part'];m=np.ones(len(dd['point']),bool)
    if part=='near':m=dd['h']<4
    elif part=='low_volatility':m=dd['low_volatility']
    elif part.startswith('H'):m=dd['h']==int(part[1:])-1
    elif part.startswith('S'):m=dd['state']==int(part[1:])
    elif part.startswith('node'):m=dd['node']==int(part[4:])
    elif part.startswith('observed'):m=dd['observable']==int(part[8:])
    elif part=='low_endpoint':m=dd['truth']<dd['threshold_lo']
    elif part=='high_endpoint':m=dd['truth']>dd['threshold_hi']
    elif part!='overall':m=dd['days'].astype('datetime64[D]').astype('datetime64[M]')==np.datetime64(part,'M')
    e=dd['point'][m]-dd['truth'][m]
    assert len(e)==r['cells'] and len(np.unique(dd['days'][m]))==r['issue_dates']
    assert math.isclose(float(abs(e).mean()),r['mae'],rel_tol=1e-12)
    assert math.isclose(float(np.sqrt((e*e).mean())),r['rmse'],rel_tol=1e-12)
    checks.append(f'{seed}:{arm}:{part}:pooled_errors')
 stats=c.read(P/'STATISTICS.json');assert len(stats)==9
 order=sorted(stats,key=lambda x:x['p_unadjusted']);last=0
 for i,r in enumerate(order):
  last=max(last,min(1.,(9-i)*r['p_unadjusted']));assert abs(last-r['p_holm'])<1e-14
 assert result['point_screen_passed']==all(x['passed'] for x in result['point_checks'])
 assert result['probability_screen_passed']==all(x['passed'] for x in result['probability_checks'])
 assert c.verify_protected()==18
 files=['RESULT.json','ALL_RESULTS.json','SUMMARY.json','STATISTICS.json','REPORT_CN.txt']
 write('AUDIT.json',dict(at=c.now(),status='passed',checks=len(checks),details=checks,
   review_type='Separate formula and model replay script, same operator; not independent human review',
   models_sample_replayed=54,point_outputs_checked=36,all18protected_unchanged=True,new_test_targets_read=False,
   V7_replaced=False,files={str(P/f):c.sha(P/f) for f in files},protocol_sha256=c.sha(P/'PROTOCOL.json')))
if __name__=='__main__':
 with c.numeric('Four-arm separate replay and numeric audit'):audit()
