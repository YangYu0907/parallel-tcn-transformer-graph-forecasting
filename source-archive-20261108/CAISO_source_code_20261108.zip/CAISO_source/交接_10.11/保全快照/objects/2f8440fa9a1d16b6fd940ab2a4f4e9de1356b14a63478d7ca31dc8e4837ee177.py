from pathlib import Path
from datetime import datetime, timezone
import sys, os, json, uuid, time, shutil
HERE = Path(__file__).resolve().parent
B = HERE.parent
V14 = B / 'chronological_expert_pilot_v14_20260930'
ART = Path('C:/Users/于阳/CAISO_temporary_storage') / HERE.name
sys.path.insert(0, str(B / 'context_expert_v1_20260929'))
import gate
read, sha, now = gate.read, gate.sha, gate.now
def write(path, obj):
    raw = json.dumps(obj, ensure_ascii=False, indent=2, allow_nan=False).encode('utf-8')
    atomic(path, lambda f: f.write(raw))
def atomic(path, writer):
    path = Path(path)
    assert any(path.resolve().is_relative_to(x.resolve()) for x in (HERE, ART))
    path.parent.mkdir(parents=True, exist_ok=True)
    temp = path.with_name('.' + path.name + '.' + uuid.uuid4().hex + '.tmp')
    with temp.open('xb') as f:
        writer(f); f.flush(); os.fsync(f.fileno())
    for i in range(6):
        try: os.replace(temp, path); break
        except PermissionError:
            if i == 5: raise
            time.sleep(.05 * 2**i)
def stamp(value): return int(datetime.fromisoformat(value).replace(tzinfo=timezone.utc).timestamp())
def check(launch=False):
    for n in ('STOP_REQUESTED', 'STOP_REQUESTED.json'):
        if (HERE/n).exists(): raise InterruptedError('Local stop requested')
    gate.guard(launch)
    ART.mkdir(parents=True, exist_ok=True)
    assert shutil.disk_usage(HERE).free > 32*2**20, 'F metadata reserve'
    assert shutil.disk_usage(ART).free > (2 if launch else 1)*2**30, 'C reserve'
def preserved():
    paths=read(B/'multi_round_mechanism_v21_20261001/RETAINED_BASELINE_HASHES.json')['files']
    for path,digest in paths.items(): assert sha(path)==digest,path
    return len(paths)
def verify():
    s=read(HERE/'SEAL.json')
    for path,digest in s['bindings'].items(): assert sha(path)==digest,path
    check(); return read(HERE/'PROTOCOL.json')
def matrix(d, arm, np):
    # X[0:17] contains contemporaneous derived/calendar channels. Exclude it from PRICE.
    # X[17:37] is price-only shape; context[37:61] is price duration/trajectory.
    x=d['context'] if arm=='CONTEXT' else np.column_stack([d['X'][:,17:37],d['context'][:,37:61]])
    return np.column_stack([np.repeat(x,12,axis=0),np.repeat(np.log1p(d['duration']),12),np.tile(np.arange(1,13)/12,len(x))]).astype(np.float32)
def eligible(d, start, np):
    return (d['issued']+12*300 < start-2*86400) & (d['available'].max(axis=1)<start)
def register():
    assert not (HERE/'PROTOCOL.json').exists(),'Already registered'
    check(True); preserved()
    old=read(V14/'RESULT.json'); audit=read(V14/'AUDIT.json')
    assert audit['status']=='passed' and sha(V14/'RESULT.json')==audit['result_sha256']
    lib=next(x for x in old['artifacts'] if x.endswith('EXPERT_ERROR_LIBRARY.npz'))
    assert sha(lib)==old['artifacts'][lib]
    p=dict(at=now(),status='registered_before_any_new_probe_fit',purpose='Distinguish regime-identification quality from price-correction magnitude using earlier-only historical TRAIN forecasts.',
      scope='Exploratory 2024H2 development already inspected in V14. No independent study-level confirmation; only observed-extreme origin-node pairs, not S0/S1/S2.',
      library=lib, folds=[['2024-09-01','2024-10-01'],['2024-10-01','2024-11-01'],['2024-11-01','2024-12-01'],['2024-12-01','2025-01-01']],
      targets='Three horizon-specific destinations S3/S4/S5 coded0/1/2. Observed origin-extreme domain is fixed by prefix TRAIN thresholds. Final labels used only in matured training rows and later scoring.',
      causal_contract='Frozen prefix preprocessing/core trained before2024H2; expanding prior H2 dates, two real calendar-day purge plus exact final-label availability before each fold. No truth/state/availability values enter predictors.',
      arms=['PRICE','CONTEXT','PRIOR','FROZEN_V14'],
      features={'PRICE':'44 price-only trajectory/duration columns plus log duration and horizon=46. Excludes X first17mixed derived/calendar channels.', 'CONTEXT':'All151 prefix-frozen origin-context columns plus log duration and horizon=153. Additional features are mixed historical context, not exclusively external covariates.'},
      classifier=dict(class_name='HistGradientBoostingClassifier',loss='log_loss',max_iter=80,max_leaf_nodes=4,max_depth=2,min_samples_leaf=100,learning_rate=.05,l2_regularization=1.,early_stopping=False,random_state=20260813),
      training_weights='Each UTC date has equal total training weight across all origin-node-horizon cells. No class resampling or outcome-based sample selection.',
      controls='PRICE and CONTEXT have identical capacity, folds and fitting budget. PRIOR is smoothed prior-date-weighted class frequency, add0.5count per class. FROZEN_V14 is an older fixed probability system and differs in training recency; comparison cannot isolate architecture.',
      primary='Multiclass Brier=sum over3classes, mean over all forecast cells. Secondary logloss, per-state Brier/AUPRC/AUROC, calibration, horizon/month and leave-one-date-out influence.',
      inference='2000 paired bootstrap replicates of fixed7-real-UTC-day blocks anchored Unix epoch, retain gaps and within-block nodes/horizons. Context versus PRICE/PRIOR/FROZEN3contrast family, centered-bootstrap two-sided p with Holm. Exploratory intervals only.',
      feasibility='Further causal-routing prototype is considered only if CONTEXT improves pooled Brier and logloss over PRICE and PRIOR, beats PRICE in>=3/4fold Briers, >=5evaluated dates per state, and its Brier improvement95percent interval versus PRICE excludes0. This screen is not an Energy publication rule or a price-accuracy guarantee.',
      distinction='Earlier V14 probes predicted relative expert losses or residual magnitudes. This probe predicts state probabilities, excludes all expert point predictions, and uses a matched price-only feature ablation. No price predictions changed.',
      maximum_seconds=900,maximum_classifier_fits=8,resources={'single_worker':True,'launch_GiB':5,'runtime_GiB':4,'threads':1},
      theory=[{'url':'https://doi.org/10.1007/s10994-018-05774-y','supports':'Earlier-only expert meta-information; this is an identification diagnostic, not a reproduction of ADE.'},
              {'url':'https://www.sciencedirect.com/science/article/abs/pii/S0140988310000885','supports':'Janczura and Weron2010, Energy Economics, publisher indexed abstract: regime-dependent price dynamics; motivation only, no current-data gain guarantee.'},
              {'url':'https://doi.org/10.1198/016214506000001437','supports':'Proper probability scoring; Brier/logloss separate probabilistic quality from price magnitude.'}],
      V7_unchanged=True,new_test_targets_read=False,model_promotion_allowed=False,stop='No feature/model/threshold search after results; no automatic price-model training on diagnostic completion.')
    write(HERE/'PROTOCOL.json',p)
    paths=list(HERE.glob('*.py'))+[HERE/'PROTOCOL.json',V14/'PROTOCOL.json',V14/'DATA.json',V14/'DATA_AUDIT.json',V14/'RESULT.json',V14/'AUDIT.json',V14/'FINAL_FREEZE.json',V14/'specialist.py',Path(lib),B/'spike_specialist_v7_20260930/prepare.py',B/'adaptive_experts_v5_20260929/worker.py',B/'context_expert_v1_20260929/gate.py']
    write(HERE/'SEAL.json',dict(at=now(),bindings={str(x):sha(x) for x in paths}))
    print('Registered 8 finite classification probes; V7 price forecasts unchanged.')
if __name__=='__main__': register()
