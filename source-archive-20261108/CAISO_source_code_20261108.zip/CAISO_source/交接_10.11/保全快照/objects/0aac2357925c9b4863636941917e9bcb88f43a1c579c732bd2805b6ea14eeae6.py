"""Causal snapshot contract, competing first-entry risks, and natural-library retrieval."""
import numpy as np

def forecast_acceleration(values,target_seconds,publication_seconds,cutoff,vintage):
 v=np.asarray(values,float);t=np.asarray(target_seconds);p=np.asarray(publication_seconds);ids=np.asarray(vintage)
 if v.shape[-1]<3 or p.shape!=v.shape or ids.shape!=v.shape:raise ValueError('Incomplete forecast curve')
 if not np.isfinite(v).all() or np.any(p>cutoff) or np.any(p<=0):raise ValueError('Unavailable forecast')
 if np.any(ids!=ids[...,:1]) or np.any(p!=p[...,:1]):raise ValueError('Mixed forecast vintages')
 dt=np.diff(t)/60
 if np.any(dt<=0) or not np.allclose(dt,dt[0]):raise ValueError('Unequal lead-time spacing')
 return np.diff(v,n=2,axis=-1)/(dt[0]**2)

def first_entry_labels(path,center,q99):
 """Inputs [pair,horizon]; classes0 none,1 upper,2 lower. At-risk includes first hit."""
 diff=path-center[:,None];hit=abs(diff)>q99[:,None]
 tau=np.where(hit.any(1),hit.argmax(1),path.shape[1]);h=np.arange(path.shape[1])[None]
 y=np.zeros(path.shape,dtype=np.int8);rows=np.flatnonzero(tau<path.shape[1]);j=tau[rows]
 y[rows,j]=np.where(diff[rows,j]>0,1,2)
 return h<=tau[:,None],y,tau

def cumulative_incidence(conditional):
 p=np.asarray(conditional,float)
 if p.shape[-1]!=3 or np.any(p<0) or not np.allclose(p.sum(-1),1):raise ValueError('Invalid hazards')
 survive=np.cumprod(p[:,:,0],axis=1)
 previous=np.concatenate([np.ones((len(p),1)),survive[:,:-1]],axis=1)
 mass=previous[:,:,None]*p[:,:,1:]
 cif=np.cumsum(mass,axis=1)
 assert np.allclose(survive+cif.sum(-1),1)
 return cif,survive

class EventLibrary:
 """All eligible historical normal-origin pairs, including non-events; never event-only."""
 def __init__(self,X,paths,first_hit,k=32):
  self.center=np.median(X,axis=0);self.scale=np.maximum(np.quantile(X,.75,axis=0)-np.quantile(X,.25,axis=0),1e-3)
  self.X=np.clip((X-self.center)/self.scale,-8,8).astype('float32');self.paths=np.asarray(paths);self.hit=np.asarray(first_hit)
  self.norm=(self.X*self.X).sum(1);self.k=min(k,len(X))
 def query(self,X):
  q=np.clip((X-self.center)/self.scale,-8,8).astype('float32')
  # Exact, chunked distances: no approximate-index nondeterminism or future-library insertions.
  d=np.maximum((q*q).sum(1)[:,None]+self.norm[None]-2*q@self.X.T,0)/self.X.shape[1]
  ix=np.argpartition(d,self.k-1,axis=1)[:,:self.k];dd=np.take_along_axis(d,ix,axis=1)
  order=np.argsort(dd,axis=1,kind='stable');ix=np.take_along_axis(ix,order,1);dd=np.take_along_axis(dd,order,1)
  w=1/np.maximum(np.sqrt(dd),1e-3);w/=w.sum(1,keepdims=True)
  return dict(paths=self.paths[ix],weights=w,event_fraction=(w*(self.hit[ix]<12)).sum(1),distance=np.sqrt(dd).mean(1),indices=ix)

def eligible_retrieval(cif_h12,neighbors,threshold,max_distance,min_event_fraction=.1):
 return (cif_h12>=threshold)&(neighbors['distance']<=max_distance)&(neighbors['event_fraction']>=min_event_fraction)

def qa():
 y=np.array([[0,2,0],[0,0,0],[-2,-2,0]],float);risk,event,tau=first_entry_labels(y,np.zeros(3),np.ones(3))
 assert tau.tolist()==[1,3,0] and risk.sum(1).tolist()==[2,3,1]
 assert event.tolist()==[[0,1,0],[0,0,0],[2,0,0]]
 p=np.tile([.8,.15,.05],(4,12,1));c,s=cumulative_incidence(p)
 assert np.all(np.diff(c,axis=1)>=0) and np.allclose(s+c.sum(-1),1)
 v=np.array([[1.,4.,9.]]);t=np.array([100,400,700]);pub=np.full((1,3),50);ids=np.zeros((1,3),int)
 assert np.allclose(forecast_acceleration(v,t,pub,90,ids),.08)
 rejected=0
 for pp,vv in [(np.full((1,3),100),ids),(pub,np.array([[0,1,1]]))]:
  try:forecast_acceleration(v,t,pp,90,vv)
  except ValueError:rejected+=1
 assert rejected==2
 return dict(first_hit_censoring=True,competing_risk_mass=True,publication_boundary=True,same_vintage_required=True,unit_MW_per_minute_squared=True)
