import argparse,json
import film_audit
p=argparse.ArgumentParser();p.add_argument('--case',required=True);a=p.parse_args();seed,variant=a.case.split('_',1)
r=film_audit.cache_audit(int(seed),variant)
print(json.dumps(dict(status=r['status'],case=a.case)))
