"""Separate direct-summation replay and complete-panel scoring, not peer review."""
from common import *

def main():
    with gate.exclusive('adaptive_v3_direct_arithmetic_audit'):
        np,lim=gate.runtime(False);verify();start_budget()
        protocol=gate.read(HERE/'PROTOCOL.json');done=gate.read(HERE/'FIT_COMPLETE.json')
        assert done['protocol_sha256']==gate.sha(HERE/'PROTOCOL.json')
        for path,digest in done['prediction_hashes'].items():assert gate.sha(path)==digest
        manifest=gate.read(gate.read(V2/'PROTOCOL.json')['dataset_manifest'])
        paths={k:gate.resolve(v['path']) for k,v in manifest['artifacts'].items()}
        features=np.load(paths['features.npy'],mmap_mode='r');sc=gate.read(paths['scalers.json'])
        center=np.array(sc['price_center'])[0,:,0];scale=np.array(sc['price_scale'])[0,:,0];sbar=scale.mean()
        th=gate.read(paths['state_thresholds.json']);q=np.array(th['thresholds']);tc=np.array(th['center'])
        with np.load(V2/'feedback.npz') as z:cut=z['cutoff'];ready=z['available'];origins=z['origins']
        price=features[origins-1,:,0].astype(np.float64)*scale+center
        amp=np.abs(price-tc);regime=(amp>q[0]).astype(int)+(amp>q[1]).astype(int);dates=cut//86400
        reports=[];all_diagnostics=[];checks=[];daily=[];counts={}
        for seed in protocol['seeds']:
            with np.load(V2/'cache'/f'{seed}_experts.npz') as z:experts=z['experts'];truth=z['truth']
            parts=[]
            for fold in (1,2,3):
                with np.load(ART/'folds'/f'{seed}_fold{fold}.npz') as z:d={k:z[k] for k in z.files}
                tr=d['train_indices'];ev=d['eval_indices'];cal=d['calibration_indices'];fitids=d['fit_indices']
                assert np.array_equal(np.sort(np.concatenate([fitids,cal])),tr)
                assert dates[fitids].max()<dates[cal].min()<dates[ev].min()
                assert ready[tr].max()<=cut[ev[0]]
                assert np.array_equal(d['FULL'],experts[ev,...,0]) and np.array_equal(d['truth'],truth[ev])
                receipt=gate.read(HERE/'receipts'/f'{seed}_fold{fold}.json')
                assert receipt['fit_cells']==len(fitids)*360
                trace=d['releases'];assert len(trace)==len(set(map(tuple,trace[:,:2])))
                assert np.all(trace[:,2]<=trace[:,3]) and np.all(cut[trace[:,0]]<trace[:,3])
                assert np.array_equal(trace[:,2],ready[trace[:,0],trace[:,1]])
                with np.load(V2/'folds'/f'{seed}_fold{fold}.npz') as z:
                    assert np.array_equal(d['V2_JOINT4'],z['JOINT4']) and np.array_equal(d['FULL_SELECTED'],z['FULL_SELECTED'])
                lookup={int(j):k for k,j in enumerate(np.concatenate([cal,ev]))}
                for pos in sorted(set([0,len(ev)//2,len(ev)-1])):
                    j=ev[pos];now=int(cut[j]);r=regime[j]
                    for name in ['GAIN_L1_DYNAMIC','GAIN_DUAL_STATIC','GAIN_DUAL_DYNAMIC']:
                        dynamic=name!='GAIN_DUAL_STATIC'
                        eligible=np.concatenate([cal,ev[:pos]]) if dynamic else cal
                        sums={};mass={}
                        observed=[[set(dates[tr][regime[tr,n]==k].tolist()) for k in range(3)] for n in range(30)]
                        for t in eligible:
                            day=int(dates[t])
                            for h in range(12):
                                if ready[t,h]>now:continue
                                if day not in sums:sums[day]=np.zeros((9,3,2));mass[day]=np.zeros(9,int)
                                error=experts[t,:,h,:]-truth[t,:,h,None]
                                g=np.stack([np.abs(error[:,:1])-np.abs(error[:,1:]),
                                    (error[:,:1]**2-error[:,1:]**2)/sbar],-1)
                                residual=g-d['predicted_gains'][lookup[int(t)],:,h]
                                for k in range(3):
                                    ids=np.flatnonzero(regime[t]==k);group=k*3+h//4
                                    sums[day][group]+=residual[ids].sum(0);mass[day][group]+=len(ids)
                                if dynamic:
                                    for n in range(30):observed[n][regime[t,n]].add(day)
                        mean=np.zeros((9,3,2));margin=np.zeros_like(mean);n_days=np.zeros(9,int)
                        for group in range(9):
                            ds=[day for day in sorted(sums) if mass[day][group]>0][-7:];n_days[group]=len(ds)
                            if len(ds)<3:continue
                            v=np.stack([sums[day][group]/mass[day][group] for day in ds])
                            w=np.array([2**(-max(0,now/86400-day-1)/7) for day in ds]);w=w/w.sum()
                            mean[group]=np.sum(w[:,None,None]*v,0)
                            var=np.sum(w[:,None,None]*(v-mean[group])**2,0)/(1-np.sum(w*w))
                            margin[group]=1.64*np.sqrt(var*np.sum(w*w))
                        groups=r[:,None]*3+np.arange(12)[None,:]//4
                        raw_gain=d['predicted_gains'][lookup[int(j)]]+mean[groups]-margin[groups]
                        ratios=np.maximum(raw_gain,0)/d['temperature'][None,:,None,:]
                        scores=ratios[...,0] if name=='GAIN_L1_DYNAMIC' else np.min(ratios,axis=-1)
                        sf=features[origins[j]-1][:,[0,21,22]]
                        allow=np.array([len(observed[n][r[n]])>=5 for n in range(30)])&((sf>=d['lower'])&(sf<=d['upper'])).all(-1)
                        scores=np.clip(scores,0,1)*((allow[:,None])&(n_days[groups]>=3))[...,None]
                        ww=np.concatenate([np.ones((30,12,1)),scores],-1);ww/=ww.sum(-1,keepdims=True)
                        assert np.allclose(ww,d[name+'_weights'][pos],atol=1e-7,rtol=1e-6)
                for name in ['GAIN_L1_DYNAMIC','GAIN_DUAL_STATIC','GAIN_DUAL_DYNAMIC']:
                    w=d[name+'_weights'];assert (w>=0).all() and (w[...,0]>=.25-1e-7).all()
                    assert np.allclose(w.sum(-1),1,atol=2e-7)
                    assert np.allclose((w.astype(float)*experts[ev]).sum(-1),d[name],atol=1e-4,rtol=2e-6)
                    fallback=(w[...,0]==1)
                    assert np.array_equal(d[name][fallback],d['FULL'][fallback])
                assert np.array_equal(d['SUPPORT_ONLY'],np.where(d['eligible'][:,:,None],d['V2_JOINT4'],d['FULL']))
                w=d['GAIN_DUAL_DYNAMIC_weights']
                diagnostics=dict(seed=seed,fold=fold,fit_dates=int(np.unique(dates[fitids]).size),fit_cells=len(fitids)*360,
                    fallback_fraction=float((w[...,0]==1).mean()),full_mean_weight=float(w[...,0].mean()),
                    expert_mean_weights=w.mean((0,1,2)).tolist(),
                    regime_weights={str(k):dict(cells=int((regime[ev]==k).sum()*12),
                        mean=w[regime[ev]==k].mean((0,1)).tolist() if (regime[ev]==k).any() else None)
                        for k in range(3)})
                all_diagnostics.append(diagnostics);parts.append(d)
                checks.append(f'{seed}/{fold}:hashes_chronology_feedback_direct_router_replay_frozen_predictions')
                tick(stage='separate_audit',seed=seed,fold=fold)
            merged={name:np.concatenate([d[name] for d in parts]) for name in ['origins','truth']+protocol['arms']}
            with np.load(T/'audited_arrays'/f'{seed}.npz') as z:
                assert np.array_equal(z['origins'],merged['origins']) and np.array_equal(z['truth'],merged['truth'])
                codes=z['codes'];low=z['low_volatility']
            ix=np.searchsorted(origins,merged['origins']);dt=dates[ix]
            for state in range(6):
                mask=codes==state;counts['S'+str(state)]=dict(cells=int(mask.sum()),UTC_dates=int(np.unique(dt[mask.any((1,2))]).size))
            def stat(e):return dict(count=int(e.size),mae=float(np.abs(e).mean()) if e.size else None,rmse=float(np.sqrt(np.square(e).mean())) if e.size else None)
            for name in protocol['arms']:
                e=merged[name]-merged['truth'];metrics=stat(e)
                metrics.update(near_mae=stat(e[:,:,:4])['mae'],h12_mae=stat(e[:,:,11])['mae'],low_volatility_mae=stat(e[low])['mae'],
                    states=[stat(e[codes==s]) for s in range(6)],horizons=[stat(e[:,:,h]) for h in range(12)],nodes=[stat(e[:,n,:]) for n in range(30)])
                reports.append(dict(seed=seed,model=name,**metrics))
                for date in np.unique(dt):
                    err=e[dt==date];daily.append(dict(seed=seed,model=name,UTC_date=int(date),cells=int(err.size),SAE=float(np.abs(err).sum()),SSE=float(np.square(err).sum())))
        keys=['mae','rmse','near_mae','h12_mae','low_volatility_mae'];candidate='GAIN_DUAL_DYNAMIC'
        means={name:{k:float(np.mean([r[k] for r in reports if r['model']==name])) for k in keys} for name in protocol['arms']}
        states={name:[{k:float(np.mean([r['states'][s][k] for r in reports if r['model']==name])) for k in ['mae','rmse']} for s in range(6)] for name in protocol['arms']}
        gains={base:{k:100*(1-means[candidate][k]/means[base][k]) for k in keys} for base in protocol['arms'] if base!=candidate}
        tests=dict(mean_MAE_improvement_at_least_half_percent=gains['FULL']['mae']>=.5,
            at_least_two_seeds_improve=sum(r['mae']<next(v['mae'] for v in reports if v['seed']==r['seed'] and v['model']=='FULL') for r in reports if r['model']==candidate)>=2,
            secondary_metrics_protected=all(means[candidate][k]<=means['FULL'][k]+1e-10 for k in keys[1:]),
            all_states_protected=all(states[candidate][s][k]<=states['FULL'][s][k]+1e-10 for s in range(6) for k in ['mae','rmse']),
            selected_FULL_protected=all(means[candidate][k]<=means['FULL_SELECTED'][k]+1e-10 for k in keys)
                and all(states[candidate][s][k]<=states['FULL_SELECTED'][s][k]+1e-10 for s in range(6) for k in ['mae','rmse']),
            state_evidence_present=all(v['UTC_dates']>=3 for v in counts.values()))
        result=dict(at=gate.now(),status='exploratory_development_complete',candidate=candidate,means=means,states=states,per_seed=reports,
            state_counts_per_seed=counts,improvements_percent=gains,acceptance_checks=tests,candidate_passed=all(tests.values()),
            scope='June2646 origins12 UTC cutoff dates30 nodes12 horizons3 seeds; repeatedly inspected development',
            independent_confirmation=False,new_test_targets_read=False,manuscript_results_replaced=False,
            interpretation='Date calibration margin is a heuristic and does not certify future risk or per-instance optimality')
        write(HERE/'RESULT.json',result);write(HERE/'ROUTING_DIAGNOSTICS.json',all_diagnostics);write(ART/'DAILY_ERRORS.json',daily)
        write(HERE/'AUDIT.json',dict(at=gate.now(),status='passed',checks=checks,operator='same primary operator; separate arithmetic implementation, no external review claimed',
            result_sha256=gate.sha(HERE/'RESULT.json'),fit_complete_sha256=gate.sha(HERE/'FIT_COMPLETE.json')))
        write(HERE/'DECISION.json',dict(at=gate.now(),status='development_passed_pending_independent_source_admission' if all(tests.values()) else 'fixed_candidate_failed_no_promotion',
            acceptance_checks=tests,new_test_targets_read=False,automatic_extra_training=False,automatic_test_opening=False,
            all_directions_preserved=True,result=str(HERE/'RESULT.json'),audit=str(HERE/'AUDIT.json')))
        print(json.dumps(dict(means=means,tests=tests)),flush=True)

if __name__=='__main__':main()
