"""Pure model construction, lazy Torch import; official pinned class bodies."""
from pathlib import Path
import ast,hashlib,json

BUNDLE=Path(__file__).resolve().parents[4]
VENDOR=BUNDLE/"external_baselines_20260913/vendor"
ALLOWED=("DLinear","iTransformer","iTransformer-H","iTransformer-X")
SELECTIONS={
 "DLinear":[("models/DLinear.py",["moving_avg","series_decomp","Model"])],
 "iTransformer":[("layers/Embed.py",["DataEmbedding_inverted"]),
  ("layers/SelfAttention_Family.py",["FullAttention","AttentionLayer"]),
  ("layers/Transformer_EncDec.py",["EncoderLayer","Encoder"]),
  ("model/iTransformer.py",["Model"])]}

def vendor_receipt():
    manifest=json.loads((VENDOR/"manifest.json").read_text(encoding="utf-8-sig"))
    for name,row in manifest.items():
        for rel,item in row["files"].items():
            if hashlib.sha256((VENDOR/name/rel).read_bytes()).hexdigest()!=item["sha256"]:
                raise RuntimeError("Pinned official model source changed")
    return manifest

def make_model(name,profile=None):
    if name not in ALLOWED:raise ValueError("Unregistered external model")
    profile=dict(profile or {})
    allowed={"individual"} if name=="DLinear" else {"d_model","n_heads","e_layers","d_ff"}
    if set(profile)-allowed:raise ValueError("Unregistered architecture override")
    vendor_receipt()
    import math,numpy as np,torch
    from torch import nn
    from torch.nn import functional as F
    from types import SimpleNamespace
    namespace=dict(torch=torch,nn=nn,F=F,np=np,math=math,sqrt=math.sqrt,__name__="pinned_external")
    family="DLinear" if name=="DLinear" else "iTransformer"
    for rel,names in SELECTIONS[family]:
        path=VENDOR/family/rel
        tree=ast.parse(path.read_text(encoding="utf-8"))
        classes=[n for n in tree.body if isinstance(n,ast.ClassDef) and n.name in names]
        if [n.name for n in classes]!=names:raise RuntimeError("Pinned class ordering changed")
        exec(compile(ast.Module(body=classes,type_ignores=[]),str(path),"exec"),namespace)
    config=dict(seq_len=288,pred_len=12,individual=False,enc_in=30,output_attention=False,
                use_norm=True,embed="timeF",freq="t",class_strategy="projection",factor=1,
                dropout=.1,activation="gelu",d_model=64,n_heads=4,e_layers=2,d_ff=128)
    config.update(profile)
    official=namespace["Model"](SimpleNamespace(**config))
    class TaskModel(nn.Module):
        def __init__(self):
            super().__init__();self.core=official
        def forward(self,price,marks=None):
            if price.ndim!=3 or price.shape[1:]!=(288,30):raise RuntimeError("Price adapter shape")
            if family=="DLinear":out=self.core(price)
            else:
                count={"iTransformer":0,"iTransformer-H":434,"iTransformer-X":446}[name]
                if count:
                    if marks is None or marks.shape!=(len(price),288,count):raise RuntimeError("Covariate token shape")
                else:marks=None
                out=self.core(price,marks,None,None)
            if out.shape!=(len(price),12,30):raise RuntimeError("Official forecast shape")
            return out.transpose(1,2)
    return TaskModel()
