"""Separate score implementation and frozen inference replay by same operator."""
from runner import *

def independent(p,y,days):
    p=np.clip(p,1e-12,1-1e-12)
    square=np.square(p-y);log=-np.where(y,np.log(p),np.log1p(-p))
    return dict(brier=float(sum(square)/len(y)),log_loss=float(sum(log)/len(y)),
        date_brier=float(np.mean([np.mean(square[days==d]) for d in sorted(set(days))])),
        date_log_loss=float(np.mean([np.mean(log[days==d]) for d in sorted(set(days))])))

def main():
    verify();checked(True);checks=0
    with old.numeric('Separate arithmetic and inference audit; no fits'):
        result=old.read(HERE/'RESULT.json');ex,pub,times,caps=inputs();passes=[]
        for row in result['probes']:
            folder=HERE/f"probe{row['fold']}"
            with np.load(folder/'REPLAY.npz') as f:z={k:f[k] for k in f.files}
            o=z['ids'][:,0];cut=times[o-1];v=ex[o-1,:2];lag=ex[o-13,:2]
            independently_built=np.column_stack([v[:,0]/1000,(v[:,1]-v[:,0])/1000,(v[:,0]-lag[:,0])/1000,(v[:,1]-lag[:,1])/1000,np.minimum(np.maximum((cut[:,None]-pub[o-1])/60/caps,0),1)]).astype('float32')
            assert np.allclose(z['extra'],independently_built,rtol=1e-6,atol=1e-6);checks+=1
            vals={}
            for arm in ['PRICE','PRICE_LOAD']:
                ff=old.read(folder/arm/'FROZEN.json');assert ff['sha256']==old.sha(folder/arm/'model.pkl');checks+=1
                obj=old.load(folder/arm/'model.pkl');model=obj['model']
                X=z['X'] if arm=='PRICE' else np.column_stack([z['X'],z['extra']])
                pred=model.predict_proba(X)[:,1];assert np.array_equal(pred,z[arm]);checks+=1
                vals[arm]=independent(pred,z['y'],z['days'])
                for k,value in vals[arm].items():assert abs(value-row['scores'][arm][k])<1e-12;checks+=1
                assert model.n_iter_==80 and obj['protocol']==old.sha(HERE/'PROTOCOL.json');checks+=1
            support=all(len(set(z['days'][z['y']==i]))>=5 for i in [0,1])
            passed=support and all(vals['PRICE_LOAD'][k]<vals['PRICE'][k] for k in vals['PRICE'])
            assert passed==row['passed'];passes.append(passed);checks+=1
            with np.load(EM/f"probe{row['fold']}/REPLAY.npz") as oldz:
                assert np.array_equal(oldz['ids'],z['ids']) and np.array_equal(oldz['y'],z['y']);checks+=1
                assert np.max(abs(oldz['control']-z['PRICE']))<1e-12;checks+=1
        assert all(passes)==result['screen_passed'] and result['new_fits']==4;checks+=1
    assert old.parent.verify_protected()==18;checks+=1
    old.write(HERE/'AUDIT.json',dict(at=old.now(),status='separate_arithmetic_and_inference_replay_passed',checks=checks,
        result_sha256=old.sha(HERE/'RESULT.json'),screen_passed=result['screen_passed'],
        protected_files=18,V7_replaced=False,new_test_targets_read=False,external_human_review=False))
    print('Separate audit passed:',checks)

if __name__=='__main__':main()
