"""Tiny synthetic training-math QA, with the same lock/resource guards as training.

No CompiledData, market arrays, old checkpoint or heldout reader is invoked.
Fresh model constructors verify paired-policy initialization using bound context
metadata only; tiny synthetic tensors verify updates and exact resume.
"""
import copy
import json
from pathlib import Path
import random
import time
import uuid
import train as runner


def execute():
    import preflight
    preflight.require_mechanisms_complete()
    preflight.launch_guard()
    runner.runner_evidence(require_math=False)
    started = time.perf_counter()
    with runner.exclusive('sampling_synthetic_training_math'):
        runtime, limiter = runner.numeric_runtime()
        torch, np = runner.torch, runner.np
        checks = []

        def check(condition, label):
            if not condition:
                raise AssertionError(label)
            checks.append(label)

        def equal(a, b):
            if isinstance(a, torch.Tensor):
                return isinstance(b, torch.Tensor) and a.dtype == b.dtype and torch.equal(a, b)
            if isinstance(a, np.ndarray):
                return isinstance(b, np.ndarray) and a.dtype == b.dtype and np.array_equal(a, b)
            if isinstance(a, dict):
                return isinstance(b, dict) and a.keys() == b.keys() and all(equal(a[k], b[k]) for k in a)
            if isinstance(a, (list, tuple)):
                return type(a) == type(b) and len(a) == len(b) and all(equal(x, y) for x, y in zip(a, b))
            return a == b

        class Tiny(torch.nn.Module):
            def __init__(self):
                super().__init__()
                self.network = torch.nn.Sequential(torch.nn.Linear(3, 7), torch.nn.GELU(),
                    torch.nn.Dropout(.2), torch.nn.Linear(7, 2))

            def forward(self, x):
                return {'prediction': self.network(x)}

        torch.manual_seed(71023)
        template = Tiny()
        x = torch.arange(39, dtype=torch.float32).reshape(13, 3)/13 - 1
        y = torch.stack((x[:, 0]*.8-2, -x[:, 2]*.3+1), dim=1)

        # Independent Huber derivative, global clipping, and first AdamW step.
        model = copy.deepcopy(template)
        reference = copy.deepcopy(template)
        model.eval(); reference.eval()
        opt = runner.optimizer(model)
        group = opt.param_groups[0]
        check(group['lr'] == .001 and group['weight_decay'] == .0001 and
              group['betas'] == (.9, .999) and group['eps'] == 1e-8,
              'AdamW arguments retain the sealed recipe')
        prediction = reference(x[:4])['prediction']
        residual = prediction-y[:4]
        absolute = residual.abs()
        direct_loss = torch.where(absolute <= .5, .5*residual.square(), .5*(absolute-.25)).mean()
        direct_loss.backward()
        flat = torch.cat([p.grad.reshape(-1) for p in reference.parameters()])
        direct_norm = torch.linalg.vector_norm(flat)
        factor = min(1., 1./(float(direct_norm)+1e-6))
        expected_parameters = {}
        for name, parameter in reference.named_parameters():
            gradient = parameter.grad*factor
            # At step 1 the bias-corrected first and second moments are g and g^2.
            expected_parameters[name] = parameter.detach()*(1-.001*.0001)-.001*gradient/(gradient.abs()+1e-8)
        loss, norm = runner.update(model, opt, x[:4], y[:4])
        check(abs(loss-float(direct_loss.detach())) < 1e-7, 'Huber delta .5 matches explicit piecewise formula')
        check(abs(norm-float(direct_norm)) < 1e-6, 'Global gradient norm matches concatenated direct norm')
        check(all(torch.allclose(p, expected_parameters[name], rtol=2e-6, atol=2e-7)
                  for name, p in model.named_parameters()), 'First AdamW update matches independent bias-corrected equation')
        check(all(float(s['step']) == 1 for s in opt.state.values()), 'Optimizer update counter advances once')
        scheduler = runner.EpochCosine(opt)
        rates = []
        for epoch in range(1, 7):
            scheduler.set_epoch(epoch)
            rates.append(opt.param_groups[0]['lr'])
            check(opt.param_groups[0]['lr'] == runner.EpochCosine.rate(epoch),
                  'Fixed within-epoch cosine setting ' + str(epoch))
        expected_rates = .0001+.5*(.001-.0001)*(1+np.cos(np.pi*np.arange(6)/5))
        check(np.allclose(rates, expected_rates, rtol=0, atol=1e-18) and rates[0] == .001 and rates[-1] == .0001,
              'Six epoch rates agree with independent cosine endpoints/interior')

        counts = [9, 11, 8, 10, 7, 13]
        identity = dict(scope='synthetic_only', epoch_counts=counts,
                        total_updates=sum((n+3)//4 for n in counts), seed=20260813)
        folder = runner.VARIANT_ROOT/'_qa'/('m_'+uuid.uuid4().hex[:12])
        baseline_run, resumed_run = folder/'c', folder/'r'
        baseline_run.mkdir(parents=True)
        resumed_run.mkdir(parents=True)

        def fresh():
            model = copy.deepcopy(template)
            model.train()
            opt = runner.optimizer(model)
            scheduler = runner.EpochCosine(opt)
            torch.manual_seed(4811)
            np.random.seed(4811)
            random.seed(4811)
            rng = np.random.default_rng(20260813)
            state = dict(phase='epoch_complete', epoch=0, steps=0, offset=0, order=None,
                         train_huber_sum=0., gradient_norm_sum=0., epochs=[])
            return model, opt, scheduler, rng, state

        def drive(parts, run, pause_at=None):
            model, opt, scheduler, rng, state = parts
            while state['phase'] == 'train' or state['epoch'] < 6:
                if state['phase'] == 'epoch_complete':
                    epoch = state['epoch']+1
                    scheduler.set_epoch(epoch)
                    state.update(phase='train', epoch=epoch, offset=0,
                                 order=rng.permutation(counts[epoch-1]),
                                 train_huber_sum=0., gradient_norm_sum=0.)
                count = counts[state['epoch']-1]
                while state['offset'] < count:
                    start = state['offset']
                    indices = state['order'][start:start+4]
                    loss, norm = runner.update(model, opt, x[indices], y[indices])
                    state['steps'] += 1
                    state['offset'] = min(start+4, count)
                    state['train_huber_sum'] += loss*len(indices)
                    state['gradient_norm_sum'] += norm*len(indices)
                    runner.validate_state(state, identity)
                    if state['steps'] == pause_at:
                        # A request arriving during the prior batch is handled only now.
                        runner.write(run/'STOP_REQUESTED.json', {'synthetic': True})
                        check(runner.stop_reason(run) is not None, 'STOP request is detected at complete batch boundary')
                        receipt = runner.checkpoint(run, runner.payload(model, opt, scheduler, rng, identity, runtime, state))
                        check(receipt['steps'] == state['steps'], 'Safe-stop receipt records the completed optimizer step')
                        return parts, receipt
                state['epochs'].append(dict(epoch=state['epoch'], loss_sum=state['train_huber_sum'],
                    norm_sum=state['gradient_norm_sum'], lr=opt.param_groups[0]['lr']))
                state.update(phase='epoch_complete', offset=0, order=None)
                runner.validate_state(state, identity)
            return parts, None

        baseline_parts, _ = drive(fresh(), baseline_run)
        expected = runner.payload(*baseline_parts[:4], identity, runtime, baseline_parts[4])
        split_parts, receipt = drive(fresh(), resumed_run, pause_at=5)
        check(runner.recover_receipt(resumed_run) == receipt, 'Verified durable receipt is recovered')
        saved = runner.load_checkpoint(resumed_run, receipt)
        # Simulate explicit acknowledgement while preserving the request as evidence.
        (resumed_run/'STOP_REQUESTED.json').rename(resumed_run/'STOP_ACKNOWLEDGED.json')
        check(runner.stop_reason(resumed_run) is None, 'Acknowledged stop permits explicit resume')
        model2, opt2, scheduler2, rng2, _ = fresh()
        state2 = runner.restore(saved, model2, opt2, scheduler2, rng2, identity, runtime)
        runner.validate_state(state2, identity)
        check(state2['offset'] == 8 and state2['epoch'] == 2, 'Mid-epoch remainder and shuffled offset restored')
        final_parts, _ = drive((model2, opt2, scheduler2, rng2, state2), resumed_run)
        actual = runner.payload(*final_parts[:4], identity, runtime, final_parts[4])
        check(equal(expected, actual), 'Continuous and disk-resumed training are bitwise identical including optimizer/RNG/cursors')
        check(actual['progress']['steps'] == sum((n+3)//4 for n in counts),
              'Total updates derive from all six new cardinalities, including short final batches')
        check([step for step in range(1, 131) if step % 64 == 0 or step == 130] == [64, 128, 130],
              '64-step persistence and final-batch persistence boundaries')
        rejected = False
        try:
            runner.restore(saved, model2, opt2, scheduler2, rng2, dict(identity, seed=20260814), runtime)
        except RuntimeError:
            rejected = True
        check(rejected, 'Resume rejects changed run/dataset identity before loading state')
        rejected = False
        try:
            runner.load_checkpoint(resumed_run, dict(receipt, path=str(runner.ROOT.parent/'old_run/model.pt')))
        except ValueError:
            rejected = True
        check(rejected, 'Old-branch checkpoint path rejected without opening it')
        malformed = copy.deepcopy(saved['progress'])
        malformed['steps'] += 1
        rejected = False
        try:
            runner.validate_state(malformed, identity)
        except RuntimeError:
            rejected = True
        check(rejected, 'Inconsistent offset/update counters fail closed')
        check('compiled_data' not in __import__('sys').modules,
              'Synthetic training QA does not import market-data adapter')
        # Real factory construction with no market values or forward execution.
        # Every policy starts from the same constructor seed before training RNG reset.
        from models.factory import build_backbone
        parent = runner.read(runner.ROOT/'dataset/compiled_train_june/manifest.json')
        limits = runner.read(runner.inside(parent['artifacts']['context_limits.json']['path']))['limits']
        for seed in (20260813, 20260814):
            for variant in ('FULL', 'TCN'):
                first = build_backbone(variant, seed, limits)
                second = build_backbone(variant, seed, limits)
                check(equal(first.state_dict(), second.state_dict()),
                      f'Fresh policy initialization exact: {variant}/{seed}')
                del first, second
            left, right = np.random.default_rng(seed), np.random.default_rng(seed)
            for epoch in range(1, 7):
                check(np.array_equal(left.permutation(4032), right.permutation(4032)),
                      f'Paired policy slot shuffle exact: {seed}/epoch{epoch}')
        fixed_identity = dict(epoch_counts=[4032]*6, total_updates=6048)
        fixed_state = dict(epoch=6, phase='epoch_complete', epochs=[{}]*6,
                           order=None, offset=0, steps=6048)
        runner.validate_state(fixed_state, fixed_identity)
        check(sum((n+3)//4 for n in fixed_identity['epoch_counts']) == 6048,
              'Six 4032-origin epochs imply exactly 6048 optimizer updates')
        import compile_gate as gate
        report = dict(status='passed', at=runner.now(), checks=checks, check_count=len(checks),
            resume_exact=True, optimizer_recipe_exact=True, epoch_cosine_exact=True,
            common_seed_initialization_exact=True, paired_slot_shuffle_exact=True, total_budget_verified=True,
            safe_stop_boundary_verified=True, synthetic_only=True, actual_market_values_read=False,
            formal_training_started=False, real_backbone_optimizer_steps=0,
            synthetic_optimizer_steps=1+2*identity['total_updates'],
            Q3_targets_read=False, test_2026_targets_read=False, runtime=runtime,
            resources=gate.check_working_set(), elapsed_seconds=time.perf_counter()-started,
            sources=runner.source_paths(), artifacts={str(p.relative_to(runner.ROOT)):runner.sha(p)
                for p in folder.rglob('*') if p.is_file()},
            remaining='Real compiled-data first-batch and complete-backbone integration audit; full model math has separate model_synthetic_qa evidence')
        runner.write(runner.SAMPLING_MATH_QA, report)
        return report


if __name__ == '__main__':
    print(json.dumps(execute(), ensure_ascii=True))
