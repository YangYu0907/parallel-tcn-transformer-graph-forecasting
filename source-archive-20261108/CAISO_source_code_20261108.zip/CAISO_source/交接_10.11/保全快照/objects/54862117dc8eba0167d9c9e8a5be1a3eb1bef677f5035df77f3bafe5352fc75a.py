"""Actual Adam state inspection and pinned-original formula replay, same operator."""
import gc,json,math
import gate
def main():
    seal=gate.verify_evaluation()
    with gate.exclusive('external_checkpoint_and_original_formula_audit'):
        np,torch,limiter=gate.runtime(True)
        from model_adapter import build_model,explicit_forward
        from compiled_data import CompiledData
        import reductions
        data=CompiledData(seal['dataset_manifest'])
        ids,_=reductions.panels(data.origins['june_dense'],data.origins['june'])
        probes=list(ids['June284'][:12])+[i for i,o in enumerate(data.origins['june_dense']) if int(o)%12!=0][:12]
        result=gate.read(gate.HERE/'result.json');rows={r['id']:r for r in result['results']}
        reports=[];bindings={}
        for c in seal['cases']:
            gate.guard();model=build_model(c['variant'],c['seed'])
            initial=model.state_dict();active=sum(p.requires_grad for p in model.parameters());epochs=[]
            gate.need(all(p.requires_grad for p in model.parameters()),'Unexpected frozen external parameters')
            for e in c['epochs']:
                gate.guard();path=gate.inside(e['checkpoint']);saved=torch.load(path,map_location='cpu',weights_only=False)
                gate.need(gate.sha(path)==e['checkpoint_sha256'] and saved['identity']==c['identity'],'Checkpoint binding')
                expected=1008*e['epoch'];prog=saved['progress']
                gate.need(prog['phase']=='epoch_complete' and prog['steps']==expected and prog['offset']==0 and prog['order'] is None,'Cursor')
                gate.need(set(saved['state_dict'])==set(initial) and all(torch.isfinite(x).all() for x in saved['state_dict'].values()),'Parameter schema/finite')
                lr=.0001+.5*(.001-.0001)*(1+math.cos(math.pi*(e['epoch']-1)/5))
                for g in saved['optimizer']['param_groups']:
                    gate.need(g['lr']==lr and g['weight_decay']==.0001 and g['betas']==(.9,.999) and g['eps']==1e-8,'Optimizer recipe')
                states=saved['optimizer']['state']
                gate.need(len(states)==active and all(float(v['step'])==expected for v in states.values()),'Adam counters')
                gate.need(all(torch.isfinite(v[k]).all() for v in states.values() for k in ('exp_avg','exp_avg_sq')),'Adam finite moments')
                epochs.append(dict(epoch=e['epoch'],steps=expected,active_optimizer_tensors=active))
                bindings[gate.rel(path)]=gate.sha(path);del saved
            selected=gate.inside(c['selected_checkpoint']);saved=torch.load(selected,map_location='cpu',weights_only=False)
            model.load_state_dict(saved['state_dict'],strict=True);model.eval().requires_grad_(False);del saved
            rr=gate.read(gate.inside(rows[c['id']]['dense_receipt']));p=gate.inside(rr['artifact'])
            gate.need(gate.sha(p)==rr['artifact_sha256'],'Saved predictions changed');bindings[gate.rel(p)]=gate.sha(p)
            with np.load(p,allow_pickle=False) as z:pred=z['prediction'];origins=z['origins']
            gate.need(np.array_equal(origins,data.origins['june_dense']),'Dense origins')
            diff=0.
            with torch.inference_mode():
                for start in range(0,24,4):
                    gate.guard();ix=np.asarray(probes[start:start+4]);x,_=data.batch('june_dense',ix,with_target=False)
                    p=explicit_forward(model,torch.from_numpy(x),c['variant'])
                    usd=p.numpy().astype(np.float64)*data.scale[None,:,None]+data.center[None,:,None]
                    diff=max(diff,float(np.max(np.abs(usd-pred[ix]))))
            gate.need(diff<=1e-9,'Original formula and separate token adapter replay mismatch')
            reports.append(dict(case=c['id'],epochs=epochs,formula_probe_origins=24,maximum_prediction_difference=diff))
            del model;gc.collect()
        gate.verify_evaluation()
        gate.write(gate.HERE/'checkpoint_audit.json',dict(status='passed',at=gate.now(),result_sha256=gate.sha(gate.HERE/'result.json'),
            execution_lock_sha256=gate.sha(gate.SEAL),evaluation_lock_sha256=gate.sha(gate.EVAL_SEAL),cases=reports,bindings=bindings,
            review_scope='Same operator; DLinear explicit MA25 formula, iTransformer pinned-original class, separate NumPy token adapter, actual Adam states.',heldout_targets_read=False))
if __name__=='__main__':main()
