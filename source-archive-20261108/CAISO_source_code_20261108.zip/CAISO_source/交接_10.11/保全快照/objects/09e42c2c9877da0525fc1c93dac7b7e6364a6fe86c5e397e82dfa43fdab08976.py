"""Finite 100-step QUERY then 100-step CONTROL with immutable per-step recovery.

CONTROL is a separately invoked stage. It requires the independently audited
selected QUERY adapter, resets Adam/q/R0/anchor, and reuses the same FiLM z.
No Q3 or 2026 target loader exists in this module.
"""
import argparse,copy,json,uuid,sys
import query_runtime as q
import film_runtime as f
import query_cache as cacheio


def settings():
    p=q.read(q.PROTOCOL)
    expected=dict(updates_per_stage=100,selection_steps=list(range(0,101,10)),lr=.003,
        betas=[.9,.999],eps=1e-8,weight_decay=0.,risk_weight_update_rate=.1,
        anchor_penalty=.001,gradient_batch=32,tasks=36,query_seed_offset=910000,
        control_layers=1,numerical_threads=1)
    if any(p.get(k)!=v for k,v in expected.items()):raise RuntimeError('QUERY recipe changed')
    return p


def check_inputs(identity,stage):
    folder=q.folder(identity['seed'],identity['variant'])
    cache_completion=q.read(folder/'cache_completion.json');audit=q.read(folder/'cache_audit.json')
    if (cache_completion['identity']!=identity or audit.get('status')!='passed' or
        audit.get('cache_completion_sha256')!=q.sha(folder/'cache_completion.json')):
        raise RuntimeError('Independent QUERY cache audit missing/stale')
    for part in ('train','inner'):
        if audit['cache_commits'][part]!=q.sha(folder/'cache'/part/'commit.json'):
            raise RuntimeError('Audited QUERY cache changed')
    parent=None
    if stage=='CONTROL':
        previous=folder/'runs/QUERY';selected=q.read(previous/'selection.json');pa=q.read(previous/'query_audit.json')
        if (selected['status']!='query_selected_pending_independent_audit' or selected['identity']!=identity or
            pa.get('status')!='passed' or pa.get('selection_sha256')!=q.sha(previous/'selection.json') or
            pa.get('fit_completion_sha256')!=q.sha(previous/'fit_completion.json')):
            raise RuntimeError('CONTROL requires independently audited selected new QUERY')
        for field in ('checkpoint','train_prediction','inner_prediction'):
            if q.sha(q.inside(selected[field]))!=selected[field+'_sha256']:raise RuntimeError('QUERY selected artifact changed')
        parent=selected
    return parent


def save_snapshot(folder,stage,identity,runtime,step,model,opt,rng,qweights,initial,anchor,parent,previous,record):
    path=folder/'checkpoints'/f'step{step:03d}_{uuid.uuid4().hex}.pt'
    payload=dict(complete_checkpoint=True,identity=identity,runtime=runtime,stage=stage,step=step,
        state_dict=copy.deepcopy(model.adapter.state_dict()),optimizer=copy.deepcopy(opt.state_dict()),
        rng=f.backbone.rng_state(rng),q=qweights.copy(),initial=initial.copy(),anchor=[x.clone() for x in anchor],
        head_sha256=f.fingerprint(model.head),parent_query_sha256=parent['checkpoint_sha256'] if parent else None,
        previous_checkpoint_sha256=previous,record=record)
    f.atomic(path,lambda stream:q.torch.save(payload,stream))
    receipt=dict(status='committed',identity=identity,stage=stage,step=step,path=str(path.relative_to(q.ROOT)),
        sha256=q.sha(path),previous_checkpoint_sha256=previous,committed_at=f.now())
    q.write(path.with_suffix('.receipt.json'),receipt)
    q.write(folder/'latest.json',receipt,replace=True)
    return payload,receipt


def committed(folder,identity,stage):
    out={}
    for path in (folder/'checkpoints').glob('*.receipt.json'):
        row=q.read(path);checkpoint=q.inside(row['path'])
        if (row.get('status')!='committed' or row['identity']!=identity or row['stage']!=stage or
            not checkpoint.is_relative_to(folder/'checkpoints') or checkpoint.with_suffix('.receipt.json')!=path or
            q.sha(checkpoint)!=row['sha256']):raise RuntimeError('Invalid QUERY resume receipt')
        if row['step'] in out:raise RuntimeError('Ambiguous duplicate committed optimizer step')
        out[row['step']]=row
    if out and sorted(out)!=list(range(max(out)+1)):raise RuntimeError('QUERY committed steps are not contiguous')
    return out


def restore(receipt,identity,stage,runtime,model,opt,rng,initial,anchor,parent,previous):
    saved=q.torch.load(q.inside(receipt['path']),map_location='cpu',weights_only=False)
    if (saved.get('complete_checkpoint') is not True or saved['identity']!=identity or saved['runtime']!=runtime or
        saved['stage']!=stage or saved['step']!=receipt['step'] or saved['head_sha256']!=f.fingerprint(model.head) or
        saved['previous_checkpoint_sha256']!=previous or receipt['previous_checkpoint_sha256']!=previous or
        saved['parent_query_sha256']!=(parent['checkpoint_sha256'] if parent else None)):
        raise RuntimeError('QUERY resume payload identity/lineage changed')
    if not q.np.array_equal(initial,saved['initial']) or any(not q.torch.equal(a,b) for a,b in zip(anchor,saved['anchor'])):
        raise RuntimeError('Stage initial risks/anchor changed')
    mean,std=model.adapter.mean.clone(),model.adapter.std.clone()
    model.adapter.load_state_dict(saved['state_dict'],strict=True);opt.load_state_dict(saved['optimizer'])
    if not q.torch.equal(mean,model.adapter.mean) or not q.torch.equal(std,model.adapter.std):
        raise RuntimeError('QUERY checkpoint altered selected FiLM buffers')
    weights=saved['q']
    if not q.np.isfinite(weights).all() or (weights<=0).any() or abs(float(weights.sum())-1)>1e-14:
        raise RuntimeError('Invalid resumed risk distribution')
    if receipt['step']:
        if len(opt.state)!=len(list(model.adapter.parameters())) or any(int(s['step'])!=receipt['step'] for s in opt.state.values()):
            raise RuntimeError('Adam counters disagree with committed step')
    elif opt.state or not q.np.array_equal(weights,q.np.ones(36)/36):raise RuntimeError('Initial optimizer/q not fresh')
    f.backbone.restore_rng(saved['rng'],rng)
    return saved


def evaluate(folder,identity,stage,step,receipt,model,train,inner):
    import query_math as math
    pointer=folder/'evaluations'/f'step{step:03d}'/'selected.json'
    if pointer.exists():
        row=q.read(pointer);directory=q.inside(row['directory'])
        if not directory.is_relative_to(pointer.parent) or q.sha(directory/'commit.json')!=row['commit_sha256']:
            raise RuntimeError('QUERY evaluation pointer changed')
        f.check_commit(directory,identity);record=q.read(directory/'record.json')
        if record['step']!=step or record['checkpoint_sha256']!=receipt['sha256']:
            raise RuntimeError('Evaluation checkpoint differs')
        return record,directory
    directory=pointer.parent/('attempt_'+uuid.uuid4().hex)
    tp,ip=math.predict(model,train),math.predict(model,inner)
    if step==0 and (not q.np.array_equal(tp,train['baseline']) or not q.np.array_equal(ip,inner['baseline'])):
        raise RuntimeError('Stage-zero baseline replay differs')
    f.array(directory/'train_prediction.npy',tp);f.array(directory/'inner_prediction.npy',ip)
    record=dict(step=step,stage=stage,checkpoint=receipt['path'],checkpoint_sha256=receipt['sha256'],
        train_risks=math.losses(tp,train).tolist(),june=math.metric(ip,inner['truth']))
    q.write(directory/'record.json',record);f.commit(directory,identity)
    q.write(pointer,dict(directory=str(directory.relative_to(q.ROOT)),commit_sha256=q.sha(directory/'commit.json')))
    return record,directory


def train(seed,variant,stage,resume=False):
    settings();identity=q.admission(seed,variant);parent=check_inputs(identity,stage)
    common=q.folder(seed,variant);folder=common/'runs'/stage
    if (folder/'fit_completion.json').exists():
        row=q.read(folder/'fit_completion.json')
        if row['identity']!=identity:raise RuntimeError('Existing completed QUERY identity differs')
        return row
    if folder.exists() and not resume:raise RuntimeError('Existing QUERY run requires explicit --resume')
    with f.exclusive('asof_'+stage,folder):
        runtime,limiter=q.numeric()
        import query_math as math
        from compiled_data import CompiledData
        data=CompiledData();model=q.make(identity,data,parent);head=f.fingerprint(model.head)
        rng=q.np.random.default_rng(seed+910000)
        train_cache=cacheio.load(common,'train',identity,parent['train_prediction'] if parent else None)
        inner=cacheio.load(common,'inner',identity,parent['inner_prediction'] if parent else None)
        try:
            params=list(model.adapter.parameters());anchor=[p.detach().clone() for p in params]
            opt=q.torch.optim.Adam(params,lr=.003,betas=(.9,.999),eps=1e-8,weight_decay=0.)
            initial=math.losses(train_cache['baseline'],train_cache)
            if not q.np.isfinite(initial).all() or (initial<=0).any():raise RuntimeError('Invalid stage initial risks')
            weights=q.np.ones(36)/36;previous=None;rows=[]
            existing=committed(folder,identity,stage)
            start_record=dict(identity=identity,runtime=runtime,stage=stage,parent_query=parent,
                new_optimizer=True,initial_risks=initial.tolist(),source_origin_scope='new TRAIN/June only',
                cache_completion_sha256=q.sha(common/'cache_completion.json'),cache_audit_sha256=q.sha(common/'cache_audit.json'),
                cache_commits={part:q.sha(common/'cache'/part/'commit.json') for part in ('train','inner')})
            if not (folder/'run_start.json').exists():q.write(folder/'run_start.json',start_record)
            elif q.read(folder/'run_start.json')!=start_record:raise RuntimeError('QUERY run/cache/runtime identity changed on resume')
            for step in range(101):
                if step in existing:
                    receipt=existing[step];saved=restore(receipt,identity,stage,runtime,model,opt,rng,initial,anchor,parent,previous)
                    weights=saved['q'].copy()
                else:
                    f.boundary(folder,True);record={}
                    if step:
                        before=math.losses(math.predict(model,train_cache),train_cache)
                        weights=math.update_q(weights,before,initial)
                        risks,reg,gradient=math.backward(model,train_cache,weights,initial,anchor)
                        opt.step()
                        if any(not q.torch.isfinite(p).all() for p in params):raise RuntimeError('Nonfinite QUERY update')
                        record=dict(before_risks=before.tolist(),gradient_risks=risks.tolist(),anchor_penalty=reg,
                                    first_gradient=gradient if step==1 else None)
                    saved,receipt=save_snapshot(folder,stage,identity,runtime,step,model,opt,rng,weights,initial,anchor,parent,previous,record)
                previous=receipt['sha256']
                q.write(folder/'latest.json',receipt,replace=True)
                if step%10==0:
                    row,directory=evaluate(folder,identity,stage,step,receipt,model,train_cache,inner)
                    rows.append(dict(row,evaluation_directory=str(directory.relative_to(q.ROOT)),commit_sha256=q.sha(directory/'commit.json')))
                    print(json.dumps(dict(event='QUERY_checkpoint',stage=stage,seed=seed,variant=variant,step=step,june_mae=row['june']['mae'])),flush=True)
                f.boundary(folder,True)
            if f.fingerprint(model.head)!=head:raise RuntimeError('Frozen QUERY head changed')
            if q.admission(seed,variant)!=identity or check_inputs(identity,stage)!=parent:
                raise RuntimeError('QUERY parent/source/data admission changed during fit')
            if (q.sha(common/'cache_completion.json')!=start_record['cache_completion_sha256'] or
                q.sha(common/'cache_audit.json')!=start_record['cache_audit_sha256'] or
                any(q.sha(common/'cache'/part/'commit.json')!=digest for part,digest in start_record['cache_commits'].items())):
                raise RuntimeError('QUERY fit cache evidence changed during updates')
            best=rows[0]
            for row in rows[1:]:
                if row['june']['mae']<best['june']['mae']-1e-6:best=row
            chosen=q.inside(best['evaluation_directory'])
            selection=dict(status=stage.lower()+'_selected_pending_independent_audit',identity=identity,stage=stage,
                step=best['step'],checkpoint=best['checkpoint'],checkpoint_sha256=best['checkpoint_sha256'],
                june_metrics=best['june'],parent_query_sha256=parent['checkpoint_sha256'] if parent else None,
                selected_evaluation_directory=best['evaluation_directory'],selected_evaluation_commit_sha256=best['commit_sha256'],
                train_prediction=str((chosen/'train_prediction.npy').relative_to(q.ROOT)),train_prediction_sha256=q.sha(chosen/'train_prediction.npy'),
                inner_prediction=str((chosen/'inner_prediction.npy').relative_to(q.ROOT)),inner_prediction_sha256=q.sha(chosen/'inner_prediction.npy'),
                selection_scope='new qualified dense June3397 only',Q3_targets_read=False,test_2026_targets_read=False)
            if not (folder/'selection.json').exists():q.write(folder/'selection.json',selection)
            elif q.read(folder/'selection.json')!=selection:raise RuntimeError('Immutable QUERY selection changed')
            completion=dict(status=stage.lower()+'_completed_pending_independent_audit',identity=identity,stage=stage,
                optimizer_steps=100,selection_sha256=q.sha(folder/'selection.json'),rows=rows,
                frozen_head_sha256=head,ordinary_inactive_nodes_preserved=True,
                Q3_targets_read=False,test_2026_targets_read=False,complete_G_TCN_TF_result=False)
            q.write(folder/'fit_completion.json',completion);return completion
        except f.StopRequested as exc:
            row=dict(status='query_stopped_at_committed_step',stage=stage,identity=identity,reason=str(exc),
                latest=q.read(folder/'latest.json') if (folder/'latest.json').exists() else None)
            q.write(folder/'events'/('stop_'+uuid.uuid4().hex+'.json'),row);return row
        finally:cacheio.close(train_cache);cacheio.close(inner)


def main():
    p=argparse.ArgumentParser();p.add_argument('action',choices=['seal','check','cache','train'])
    p.add_argument('--seed',type=int);p.add_argument('--variant');p.add_argument('--stage',choices=['QUERY','CONTROL'])
    p.add_argument('--resume',action='store_true');args=p.parse_args()
    if args.action=='seal':result=q.seal()
    elif args.action=='check':result=q.admission(args.seed,args.variant)
    elif args.action=='cache':result=cacheio.build(args.seed,args.variant)
    else:
        if not args.stage:p.error('--stage is required for training')
        result=train(args.seed,args.variant,args.stage,args.resume)
    print(json.dumps(result,ensure_ascii=False,allow_nan=False),flush=True)
    if 'stopped' in result.get('status',''):sys.exit(3)
if __name__=='__main__':main()
