"""No-fit post-result diagnosis: event support, ranking and calibration."""
from risk_model import *

def main():
    from sklearn.metrics import average_precision_score,roc_auc_score
    guard(True);verify();assert read('AUDIT.json')['status']=='passed'
    write('DIAGNOSIS_PLAN.json',dict(at=c.now(),scope='All seeds and windows; compare already saved raw/calibrated probabilities descriptively. No selection or retuning.',new_fits=0))
    rows=[]
    with c.numeric('Direct event no-fit calibration and ranking diagnosis'):
        for seed in c.SEEDS:
            for info in ['old','new']:
                arrays=[]
                for w in [1,2,3]:
                    with np.load(N/'fits'/f'w{w}_{seed}_{info}'/'out.npz') as z:arrays.append({k:z[k] for k in ['y','p','p_raw','p_cdf','days','window']})
                d={k:np.concatenate([z[k] for z in arrays]) for k in arrays[0]}
                for w in [0,1,2,3]:
                    mask=np.ones(len(d['y']),bool) if w==0 else d['window']==w
                    for side,j in [('low',1),('high',2)]:
                        yy=d['y'][mask]==j
                        for method in ['p_raw','p','p_cdf']:
                            pr=d[method][mask,j];safe=np.clip(pr,1e-12,1-1e-12)
                            rows.append(dict(seed=seed,info=info,window=w,side=side,method=method,cells=int(mask.sum()),
                                positive_cells=int(yy.sum()),event_rate=float(yy.mean()),mean_probability=float(pr.mean()),
                                brier=float(np.mean((pr-yy)**2)),logloss=float(np.mean(np.where(yy,-np.log(safe),-np.log1p(-safe)))),
                                AP=float(average_precision_score(yy,pr)),ROC=float(roc_auc_score(yy,pr)),
                                hits=int(((pr>=.1)&yy).sum()),false_alarms=int(((pr>=.1)&~yy).sum()),
                                misses=int(((pr<.1)&yy).sum()),overconfident_false_alarms=int(((pr>=.9)&~yy).sum())))
                guard()
        assert c.verify_protected()==18
    avg=[]
    for info in ['old','new']:
        for w in [0,1,2,3]:
            for side in ['low','high']:
                for method in ['p_raw','p','p_cdf']:
                    rr=[z for z in rows if z['info']==info and z['window']==w and z['side']==side and z['method']==method]
                    keys=['event_rate','mean_probability','brier','logloss','AP','ROC','hits','false_alarms','misses','overconfident_false_alarms']
                    avg.append(dict(info=info,window=w,side=side,method=method,cells=rr[0]['cells'],positive_cells=rr[0]['positive_cells'],**{k:float(np.mean([z[k] for z in rr])) for k in keys}))
    write('ATTRIBUTION.json',dict(at=c.now(),status='passed_descriptive_only',records=rows,seed_mean=avg,
        new_fits=0,new_test_targets_read=False,V7_replaced=False,thresholds_changed=False,
        caveat='Raw versus calibrated performance is a retrospective mechanism diagnostic, not permission to replace the registered candidate with its raw variant. Small event-day support and event-rate shifts do not uniquely establish causality.'))
    print(json.dumps([r for r in avg if r['info']=='new' and r['window']==0],indent=2))
if __name__=='__main__':main()
