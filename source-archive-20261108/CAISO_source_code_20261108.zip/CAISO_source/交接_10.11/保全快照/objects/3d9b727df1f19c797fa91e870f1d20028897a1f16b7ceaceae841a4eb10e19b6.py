from pathlib import Path
import os,sys,json,time,uuid,pickle,hashlib,shutil
from datetime import datetime,timezone
HERE=Path(__file__).resolve().parent;B=HERE.parent;V14=B/'chronological_expert_pilot_v14_20260930'
ART=Path('C:/Users/于阳/CAISO_temporary_storage')/HERE.name
A14=ART.parent/V14.name
sys.path.insert(0,str(B/'context_expert_v1_20260929'));import gate
sys.path.insert(1,str(B/'source'))
np=None
_clock=None
_prior=0.

def write(p,x):atomic(p,lambda f:f.write(json.dumps(x,ensure_ascii=False,indent=2,allow_nan=False).encode('utf-8')))
def atomic(p,writer):
 p=Path(p);assert any(p.resolve().is_relative_to(x.resolve()) for x in [HERE,ART]);p.parent.mkdir(parents=True,exist_ok=True)
 assert shutil.disk_usage(p.parent).free>32*2**20
 t=p.with_name('.'+p.name+'.'+uuid.uuid4().hex+'.tmp')
 with t.open('xb') as f:writer(f);f.flush();os.fsync(f.fileno())
 os.replace(t,p)
def save(p,**x):atomic(p,lambda f:np.savez_compressed(f,**x))
def dump(p,x):atomic(p,lambda f:pickle.dump(x,f,protocol=5))
def readnp(p):
 with np.load(p) as z:return {k:z[k] for k in z.files}
def stamp(s):return int(datetime.fromisoformat(s).replace(tzinfo=timezone.utc).timestamp())
def verify():
 p=gate.read(HERE/'PROTOCOL.json')
 for path,h in p['bindings'].items():assert gate.sha(path)==h,path
 return p
def progress(**kwargs):
 gate.guard()
 charge()
 for d in [HERE,HERE/'queue']:
  for n in ['STOP_REQUESTED','STOP_REQUESTED.json']:
   if (d/n).exists():raise InterruptedError('User stop '+str(d/n))
 write(HERE/'queue/worker.json',dict(at=gate.now(),pid=os.getpid(),**kwargs))
def initialize():
 global np,_clock,_prior
 np,lim=gate.runtime(False)
 _prior=gate.read(HERE/'budget.json')['used_seconds'] if (HERE/'budget.json').exists() else 0.
 _clock=time.monotonic()
 return np,lim
def charge():
 if _clock is None:return
 seconds=_prior+time.monotonic()-_clock
 write(HERE/'budget.json',dict(at=gate.now(),used_seconds=seconds,maximum_seconds=7200))
 if seconds>=7200:raise TimeoutError('Finite V15 two-hour numerical budget exhausted')
def measure(e):return dict(cells=int(e.size),mae=float(abs(e).mean()),rmse=float(np.sqrt((e**2).mean()))) if e.size else dict(cells=0,mae=None,rmse=None)
def oldmodule(folder,filename,name):
 previous=sys.modules.get('common');sys.modules['common']=gate.load(name+'_common',B/folder/'common.py')
 try:m=gate.load(name,B/folder/filename)
 finally:
  if previous is None:sys.modules.pop('common',None)
  else:sys.modules['common']=previous
 m.np=np;return m
