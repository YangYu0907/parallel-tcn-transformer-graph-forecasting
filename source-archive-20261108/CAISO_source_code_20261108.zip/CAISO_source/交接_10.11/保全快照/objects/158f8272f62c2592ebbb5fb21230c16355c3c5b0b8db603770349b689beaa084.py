from pathlib import Path
import sys, os, json, uuid, time, shutil, importlib.util
HERE=Path(__file__).resolve().parent
B=HERE.parent
ART=Path('C:/Users/于阳/CAISO_temporary_storage')/HERE.name
V23=B/'probability_contract_v23_20261001'
sys.path.insert(0,str(V23))
import common as old
gate=old.gate
read,sha,now=old.read,old.sha,old.now
stamp,split,targets,temperature,compose=old.stamp,old.split,old.targets,old.temperature,old.compose
spec=importlib.util.spec_from_file_location('v23_score_functions',V23/'run.py')
scorer=importlib.util.module_from_spec(spec);spec.loader.exec_module(scorer)
metrics=scorer.metrics

def atomic(path,writer):
    path=Path(path)
    assert any(path.resolve().is_relative_to(root.resolve()) for root in (HERE,ART))
    path.parent.mkdir(parents=True,exist_ok=True)
    tmp=path.with_name('.'+path.name+'.'+uuid.uuid4().hex+'.tmp')
    with tmp.open('xb') as f:writer(f);f.flush();os.fsync(f.fileno())
    for i in range(6):
        try:os.replace(tmp,path);break
        except PermissionError:
            if i==5:raise
            time.sleep(.05*2**i)

def write(path,obj):
    raw=json.dumps(obj,ensure_ascii=False,indent=2,allow_nan=False).encode('utf-8')
    atomic(path,lambda f:f.write(raw))

def check(launch=False):
    for name in ('STOP_REQUESTED','STOP_REQUESTED.json'):
        if (HERE/name).exists():raise InterruptedError('User stop requested')
    gate.guard(launch)
    ART.mkdir(parents=True,exist_ok=True)
    assert shutil.disk_usage(HERE).free>32*2**20
    assert shutil.disk_usage(ART).free>(2 if launch else 1)*2**30

def matrix(d,features,np):
    ctx=d['context'] if features=='RICH' else np.column_stack([d['X'][:,17:37],d['context'][:,37:61]])
    h=np.tile(np.arange(1,13),len(ctx))
    return np.column_stack([np.repeat(ctx,12,axis=0),h/12,(np.repeat(d['duration'],12)+h)/288]).astype(np.float32)

def verify():
    for path,digest in read(HERE/'SEAL.json')['bindings'].items():assert sha(path)==digest,path
    check();return read(HERE/'PROTOCOL.json')

def inference(y,probs,issued,np):
    hot=np.eye(3)[y];block=issued//604800;ids=np.unique(block)
    count=np.array([12*np.sum(block==k) for k in ids]);sums={a:np.array([np.square(p[block==k]-hot[block==k]).sum() for k in ids]) for a,p in probs.items()}
    draws=np.random.default_rng(20260813).integers(len(ids),size=(2000,len(ids)))
    rows=[]
    for a in ('RICH_LARGE','RICH_SMALL','PRICE_LARGE','PRIOR'):
        delta=sums[a]-sums['PRICE_SMALL'];gain=float(delta.sum()/count.sum());boot=delta[draws].sum(1)/count[draws].sum(1)
        rows.append(dict(comparator=a,gain=gain,interval95=np.quantile(boot,[.025,.975]).tolist(),p=float((1+(np.abs(boot-gain)>=abs(gain)).sum())/2001)))
    last=0.
    for rank,j in enumerate(sorted(range(len(rows)),key=lambda k:rows[k]['p'])):
        last=max(last,min(1.,(len(rows)-rank)*rows[j]['p']));rows[j]['holm_p']=last
    return dict(week_blocks=len(ids),replicates=2000,comparisons=rows)

def register():
    assert not (HERE/'PROTOCOL.json').exists()
    old.verify();check(True);old.preserved()
    result=read(V23/'RESULT.json');audit=read(V23/'AUDIT.json');support=read(HERE/'SUPPORT.json')
    assert audit['status']=='passed' and audit['result_sha256']==sha(V23/'RESULT.json')
    previous=read(V23/'PROTOCOL.json')
    p=dict(at=now(),status='registered_before_V24_fits',authorization='User said 继续 after V23 closure; bounded diagnosis of event support and auxiliary classifier capacity.',
      scope=previous['scope'],library=previous['library'],folds=previous['folds'],
      question='Does unstable high-dimensional context, tree interaction capacity, or their interaction explain probability transfer failure? Fixed two-factor matched diagnosis, no model grid or winning-arm selection.',
      event_support='2082observed-extreme origin-node pairs on46dates; no history-censored episodes. September fit345pairs18dates, calibration81pairs5dates; calibration S4 only31cells2dates. Multiple nodes/horizons are dependent. Adequate to run a diagnostic, not evidence of sufficient independent confirmation.',
      feature_factor={'RICH':'153columns exactly V23','PRICE':'46columns: X17:37 plus context37:61 price shape/duration, same horizon/12 and(duration+h)/288. Predetermined V22 price subset; no outcome-based feature selection.'},
      capacity_factor={'LARGE':{'max_leaf_nodes':15,'max_depth':None},'SMALL':{'max_leaf_nodes':4,'max_depth':2}},
      arms=['RICH_LARGE','PRICE_LARGE','RICH_SMALL','PRICE_SMALL','PRIOR','FROZEN_V14'],
      candidate='PRICE_SMALL fixed before fit; other arms are matched explanatory controls only.',
      common_classifier=previous['classifier'],
      common_contract='Same V23 fit/cal/test memberships, two-day purges, label-publication checks, natural row likelihood, mean1 weights, 80iterations, minleaf50, LR.05,L2=1, seed20260813, bounded temperature[.5,2] per task, first-step structural support correction. Core graph/TCN/Transformer/fusion/head are unchanged.',
      reuse='RICH_LARGE equals audited V23 NATURAL_SUPPORT. Reuse8existing models and probabilities after hashes/shape/fold/inference checks; do not train duplicate models.',
      calibration='Natural likelihood only; retain raw probability diagnostics but do not switch candidate calibration after scores. Training-resubstitution scores are diagnostic only.',
      max_iter=80,maximum_new_classifier_fits=24,maximum_seconds=900,
      primary='Mean multiclass Brier across every retained origin-node-horizon cell; logloss secondary. All states/horizons/months and date dependence retained.',
      inference='2000 paired7-real-UTC-day-block bootstrap; candidate vsRICH_LARGE,RICH_SMALL,PRICE_LARGE,PRIOR4contrast family with Holm. Exploratory intervals, no fresh independent test.',
      screen='PRICE_SMALL must improve pooled Brier and logloss over RICH_LARGE and PRIOR, improve Brier over RICH_LARGE in>=3/4months, preserve H1AUC and eachS3/S4/S5conditional Brier against RICH_LARGE, each state>=5evaluated dates, lower95percent Brier gain bound vsRICH_LARGE>0. These finite diagnostic gates are not publication criteria. Passing still requires later price-retention and new independent confirmation.',
      stop='No additional model family/features/calibration search after scores. No price integration this run, regardless of ranking. Preserve V7 and all negative evidence.',
      theory=[{'url':'https://arxiv.org/abs/0804.2752','supports':'Buhlmann and Hothorn, Statistical Science: regularization and base-learner complexity in boosting. Motivation for fixed small-tree control, not proof that chosen4leaves is optimal.'},
              {'url':'https://www.sciencedirect.com/science/article/pii/S0169207011000550','supports':'Christensen et al2012 International Journal of Forecasting, publisher abstract: historical spike information and event-probability forecasting. Our exit-state task is distinct from their onset model.'},
              {'url':'https://proceedings.mlr.press/v70/guo17a.html','supports':'Keep temperature-calibration protocol fixed to isolate feature/capacity factors.'},
              {'url':'https://jmlr.org/papers/v11/cawley10a.html','supports':'Freeze candidate and finite factor levels; explicitly account for repeated development selection.'}],
      resources={'launch_GiB':5,'runtime_GiB':4,'single_numeric_worker':True,'threads':1,'numeric_storage':'C temporary authorized'},V7_unchanged=True,new_test_targets_read=False,price_predictions_changed=False)
    write(HERE/'PROTOCOL.json',p)
    paths=list(HERE.glob('*.py'))+[HERE/'SUPPORT.json',HERE/'PROTOCOL.json',V23/'PROTOCOL.json',V23/'SEAL.json',V23/'common.py',V23/'run.py',V23/'RESULT.json',V23/'AUDIT.json',Path(result['output']),Path(p['library'])]
    for f in result['folds']:
        paths += [Path(f['replay'])]
        paths += [Path(f['models']['NATURAL_'+task]['path']) for task in ('hazard','postexit')]
    write(HERE/'SEAL.json',dict(at=now(),bindings={str(x):sha(x) for x in paths}))
    print('V24 registered:24new lightweight fits;8matched model fits reused; V7 unchanged.')

if __name__=='__main__':register()
