"""Separate fixed-output recomputation and deterministic source/prediction replay."""
from common import *

def checkmetric(e,m):
 assert abs(float(abs(e).mean())-m['mae'])<1e-8
 assert abs(float(np.sqrt(np.mean(e*e)))-m['rmse'])<1e-8

def main():
 global np
 with gate.exclusive('V15 fixed-output audit and source replay'):
  np,lim=initialize();p=verify();cal=gate.read(HERE/'CALIBRATION_RESULT.json');on=gate.read(HERE/'ONSET_RESULT.json')
  for f,h in cal['outputs'].items():assert gate.sha(f)==h
  for fz in ['ONSET_MODEL_FREEZE.json','ONSET_PREDICTION_FREEZE.json']:
   for f,h in gate.read(HERE/fz)['bindings'].items():assert gate.sha(f)==h
  dm=gate.read(V14/'DATA.json');root=Path(dm['directory']);raw=np.load(dm['raw_prices'],mmap_mode='r');ts=np.load(dm['timestamps'],mmap_mode='r')
  th=gate.read(root/'state_thresholds.json');center=np.array(th['center']);q=np.array(th['thresholds'])
  z=readnp(ART/'calibration/predictions.npz');lib=readnp(A14/'EXPERT_ERROR_LIBRARY.npz');old=readnp(A14/'PREDICTIONS.npz')
  from scipy.special import softmax
  hit=np.zeros(len(lib['node']),bool)
  for i,(left,right) in enumerate(p['calibration']['folds']):
   f=readnp(ART/f'calibration/map{i}.npz');t=stamp(left);tr=(lib['available'].max(1)<t)&(lib['issued']+3600<t-172800);te=(lib['issued']>=t)&(lib['issued']<stamp(right))
   assert np.array_equal(f['train'],tr) and np.array_equal(f['evaluation'],te)
   theta=f['theta'];x=np.log(np.clip(lib['probabilities'][te],1e-12,1));pp=softmax(np.einsum('...j,kj->...k',x,theta[:9].reshape(3,3))+theta[9:],axis=-1)
   assert np.allclose(pp,z['probability'][te],rtol=0,atol=1e-12);hit|=te
  assert np.array_equal(hit,z['selected'])
  select=ts[old['origins']-1]>=stamp('2024-09-01');origins=old['origins'][select];out=old['FULL'][select].copy();ix=np.searchsorted(origins,lib['origins'][hit]);out[ix,lib['node'][hit]]=z['prediction'][hit]
  y=np.stack([raw[o:o+12,:,0].T for o in origins]).astype(float);e=out-y
  from compile_math import group_codes
  state=group_codes(y,raw[origins-1,:,0],center,q);assert np.array_equal(out[state<3],old['FULL'][select][state<3])
  checkmetric(e,cal['metrics']['overall']);checkmetric(e[:,:,:4],cal['metrics']['near']);checkmetric(e[:,:,-1],cal['metrics']['h12'])
  for s in range(6):checkmetric(e[state==s],cal['metrics']['by_state'][s])
  for n in range(30):checkmetric(e[:,n],cal['metrics']['by_node'][n])
  for h in range(12):checkmetric(e[:,:,h],cal['metrics']['by_horizon'][h])
  del old,out,y,e,state
  progress(stage='audit_onset_replay')
  z=readnp(ART/'onset/evaluation_probabilities.npz');labels=readnp(ART/'onset/evaluation_labels.npz');inputs=readnp(ART/'onset/evaluation_inputs.npz');freeze=gate.read(HERE/'ONSET_MODEL_FREEZE.json')
  assert np.array_equal(z['origin'],inputs['origin']) and np.array_equal(z['node'],inputs['node'])
  selected=np.unique(np.linspace(0,len(z['origin'])-1,123,dtype=int));maxreplay=0.;feature_error=0.
  from scipy.special import expit,logit
  from sklearn.metrics import average_precision_score
  for name in ['SHORT90','RECURRENCE103']:
   f=freeze['models'][name]
   with open(f['model'],'rb') as fh:model=pickle.load(fh)
   pred=expit(logit(np.clip(model.predict_proba(inputs['X'][selected,:f['features']])[:,1],1e-9,1-1e-9))/f['temperature'])
   maxreplay=max(maxreplay,float(abs(pred-z[name][selected]).max()));assert maxreplay<1e-12
   pp=z[name];yy=labels['y'];r=on['scores'][name];assert abs(float(((pp-yy)**2).mean())-r['brier'])<1e-12
   assert abs(average_precision_score(yy,pp)-r['auprc'])<1e-12
   active=pp>f['threshold'];assert int((active&(yy==0)).sum())==r['fp'] and int((active&(yy==1)).sum())==r['tp']
  with np.load(dm['publication_ledger']) as data:pub=data['price_last_publication_seconds'];valid=data['source_row_valid'].astype(bool)
  cache=np.load(root/'features.npy',mmap_mode='r');sc=gate.read(root/'scalers.json');math=gate.load('audit_short',B/'spike_transition_v12_20260930/modelmath.py')
  # Independent brute-force local event reconstruction, not recurrence.catalog/features.
  for j in selected:
   o=int(z['origin'][j]);n=int(z['node'][j]);cut=int(ts[o-1]);left=int(np.searchsorted(ts,cut-2419200));rows=np.arange(max(1,left),o)
   known=valid[rows]&valid[rows-1]&(pub[rows]>0)&(pub[rows-1]>0)&(pub[rows]<=cut)&(pub[rows-1]<=cut)&(ts[rows]+300<=cut)&(ts[rows]-ts[rows-1]==300)
   current=raw[rows,:,0];previous=raw[rows-1,:,0]
   starts=(abs(current-center)>q[1])&(abs(previous-center)<=q[1])&np.isfinite(current)&np.isfinite(previous)&known[:,None]
   counts=np.array([starts[ts[rows]>=cut-w].sum(0) for w in [3600,86400,604800,2419200]]).T
   eventrows=rows[starts[:,n]];age=(cut-ts[eventrows[-1]])/60 if len(eventrows) else 40320
   coverage=[]
   for w in [86400,604800,2419200]:
    rr=np.arange(np.searchsorted(ts,cut-w),o);coverage.append(float((valid[rr]&(pub[rr]<=cut)&(ts[rr]+300<=cut)).sum())/(w//300))
   expected=np.r_[counts[n],np.log1p(age),float(not len(eventrows)),counts.mean(0),coverage]
   feature_error=max(feature_error,float(abs(expected-inputs['X'][j,90:]).max()));assert feature_error<1e-5
   short=math.features(raw[o-72:o],cache[o-1],sc)[n];assert np.array_equal(short,inputs['X'][j,:90])
   actual=bool((abs(raw[o:o+12,n,0]-center[n])>q[1,n]).any());assert actual==bool(labels['y'][j])
  import recurrence;tests=recurrence.qa();charge()
  write(HERE/'AUDIT.json',dict(at=gate.now(),status='passed',script_sha256=gate.sha(__file__),protocol_sha256=gate.sha(HERE/'PROTOCOL.json'),
   results={str(HERE/f):gate.sha(HERE/f) for f in ['CALIBRATION_RESULT.json','ONSET_RESULT.json']},checks=['sealed_dependency_hashes','expanding_publication_purged_folds','calibration_probability_replay','all_price_metrics_from_fixed_predictions','all_nonextreme_prices_bitwise_unchanged','onset_output_metrics_recomputed','source_feature_and_target_replay','onset_prediction_replay']+tests,
   sampled_origin_node_pairs=len(selected),max_feature_replay_abs=feature_error,max_onset_prediction_replay_abs=maxreplay,external_human_review=False,independent_test=False,main_model_replaced=False))
  print('V15 independent numerical replay script passed; no external human review or new blind-test claim.')
if __name__=='__main__':main()
