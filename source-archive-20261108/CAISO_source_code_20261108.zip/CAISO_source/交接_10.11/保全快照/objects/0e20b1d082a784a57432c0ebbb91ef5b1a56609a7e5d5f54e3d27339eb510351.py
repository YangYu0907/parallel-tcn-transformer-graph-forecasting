"""Actual checkpoint optimizer/frozen-tensor audit plus independently written formula replay."""
import gc,json
import gate
def main():
    seal=gate.verify_evaluation()
    with gate.exclusive('additive_mechanism_checkpoint_audit'):
        np,torch,limiter=gate.runtime(True)
        from models.factory import build_backbone
        from models.component_controls import inactive_name,explicit_forward
        from compiled_data import CompiledData
        import reductions
        data=CompiledData(seal['dataset_manifest']);limits=gate.read(data.paths['context_limits.json'])['limits']
        ids,blocks=reductions.panels(data.origins['june_dense'],data.origins['june'])
        probes=list(ids['June284'][:12])+[i for i,o in enumerate(data.origins['june_dense']) if int(o)%12!=0][:12]
        result=gate.read(gate.HERE/'result.json');rows={r['id']:r for r in result['results']};reports=[];bindings={}
        for c in seal['cases']:
            gate.guard();model=build_backbone(c['variant'],c['seed'],limits)
            initial={k:v.clone() for k,v in model.state_dict().items()}
            frozen={k for k,p in model.named_parameters() if not p.requires_grad}
            gate.need(frozen=={k for k,p in model.named_parameters() if inactive_name(c['variant'],k)},'Unexpected inactive parameters')
            active=sum(p.requires_grad for p in model.parameters());epochs=[]
            for e in c['epochs']:
                gate.guard();path=gate.inside(e['checkpoint']);saved=torch.load(path,map_location='cpu',weights_only=False)
                gate.need(gate.sha(path)==e['checkpoint_sha256'] and saved['identity']==c['identity'],'Checkpoint binding')
                expected=1008*e['epoch'];prog=saved['progress']
                gate.need(prog['phase']=='epoch_complete' and prog['steps']==expected and prog['offset']==0 and prog['order'] is None,'Checkpoint cursor')
                state=saved['state_dict'];gate.need(set(state)==set(initial),'Parameter schema')
                gate.need(all(torch.isfinite(x).all() for x in state.values()),'Nonfinite parameter')
                gate.need(all(torch.equal(state[k],initial[k]) for k in frozen),'Inactive parameter changed')
                gate.need(torch.equal(state['context_limits'],initial['context_limits']),'TRAIN clip limit changed')
                lr=.0001+.5*(.001-.0001)*(1+__import__('math').cos(__import__('math').pi*(e['epoch']-1)/5))
                for group in saved['optimizer']['param_groups']:
                    gate.need(group['lr']==lr and group['weight_decay']==.0001 and group['betas']==(.9,.999) and group['eps']==1e-8,'Optimizer recipe')
                states=saved['optimizer']['state']
                gate.need(len(states)==active and all(float(v['step'])==expected for v in states.values()),'Active Adam counters')
                epochs.append(dict(epoch=e['epoch'],steps=expected,active_optimizer_tensors=active,frozen_parameters_unchanged=True))
                bindings[gate.rel(path)]=gate.sha(path)
                del saved
            selected=gate.inside(c['selected_checkpoint']);saved=torch.load(selected,map_location='cpu',weights_only=False)
            model.load_state_dict(saved['state_dict'],strict=True);model.eval().requires_grad_(False);del saved
            rec=gate.read(gate.inside(rows[c['id']]['dense_receipt']));p=gate.inside(rec['artifact'])
            gate.need(gate.sha(p)==rec['artifact_sha256'],'Saved prediction changed');bindings[gate.rel(p)]=gate.sha(p)
            with np.load(p,allow_pickle=False) as z:pred=z['prediction'];origins=z['origins']
            gate.need(np.array_equal(origins,data.origins['june_dense']),'Dense origins')
            diff=0.
            with torch.inference_mode():
                for start in range(0,24,4):
                    gate.guard();ix=np.asarray(probes[start:start+4]);x,_=data.batch('june_dense',ix)
                    out,_,adj=explicit_forward(model,torch.from_numpy(x))
                    usd=out.numpy().astype(np.float64)*data.scale[None,:,None]+data.center[None,:,None]
                    diff=max(diff,float(np.max(np.abs(usd-pred[ix]))))
                    if c['variant']=='SELF':gate.need(torch.equal(adj,torch.eye(30).expand(len(ix),-1,-1)),'SELF adjacency')
            gate.need(diff<=1e-9,'Independent model formula replay')
            reports.append(dict(case=c['id'],epochs=epochs,formula_probe_origins=24,maximum_prediction_difference=diff))
            del model;gc.collect()
        gate.verify_evaluation()
        gate.write(gate.HERE/'checkpoint_audit.json',dict(status='passed',at=gate.now(),result_sha256=gate.sha(gate.HERE/'result.json'),
            execution_lock_sha256=gate.sha(gate.SEAL),evaluation_lock_sha256=gate.sha(gate.EVAL_SEAL),cases=reports,bindings=bindings,
            review_scope='Same operator; distinct explicit graph/fusion arithmetic and actual optimizer state checks.',heldout_targets_read=False))
if __name__=='__main__':main()
