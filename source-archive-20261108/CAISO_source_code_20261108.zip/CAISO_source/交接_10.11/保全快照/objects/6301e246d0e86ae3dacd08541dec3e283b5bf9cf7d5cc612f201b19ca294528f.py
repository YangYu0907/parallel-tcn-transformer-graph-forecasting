"""FiLM metadata admission and durable I/O; numeric imports are explicitly delayed."""
from contextlib import contextmanager
from pathlib import Path
import copy
import json
import os
import sys
import uuid
import backbone_train as backbone

ROOT = backbone.ROOT
PROTOCOL = ROOT/'FILM_PROTOCOL.json'
LOCK = ROOT/'FILM_LOCK.json'
QA = ROOT/'audits/film_synthetic_qa.json'
np = torch = None
VARIANTS = ('FULL','TCN','EQUAL','CONCAT','GLOBAL','GTF','STATIC','SELF')
read, sha, write, inside, now = backbone.read, backbone.sha, backbone.write, backbone.inside, backbone.now


class StopRequested(RuntimeError):
    pass


def stage(seed, variant):
    if seed not in (20260813, 20260814) or variant not in VARIANTS:
        raise ValueError('Unregistered FiLM case')
    return inside(f'stages/film/{seed}_{variant}')


def sources():
    files = [PROTOCOL, ROOT/'FILM_DERIVATION.json', ROOT/'recipe.json', ROOT/'BACKBONE_LOCK.json',
             ROOT/'CONTROL_BACKBONE_LOCK.json', ROOT/'CONTROL_BACKBONE_PROTOCOL.json',
             ROOT/'source/control_backbone_train.py', ROOT/'source/backbone_train.py']
    files += [ROOT/'source'/name for name in ('film_runtime.py','film_cache.py','film_math.py',
              'film_mnp.py','film_stage.py','film_synthetic_qa.py','film_audit.py')]
    files += sorted((ROOT/'source/models').glob('*.py'))
    return {str(p.relative_to(ROOT)):sha(p) for p in files}


def seal():
    report=read(QA)
    if report.get('status')!='passed' or report.get('synthetic_only') is not True or report['sources']!=sources():
        raise RuntimeError('Fresh FiLM synthetic QA missing/stale')
    for key in ('full_empirical_gradient_resume_exact','full_snapshot_rng_resume_exact',
                'original_risk_equations_verified','safe_stop_boundary_verified',
                'ordinary_predictions_exact','normalizer_train_only_verified'):
        if report.get(key) is not True:raise RuntimeError('Missing FiLM math QA evidence: '+key)
    value=dict(status='sealed_film_preparation',sources=sources(),qa_sha256=sha(QA),
               scope='film_only',old_fitted_state_reused=False)
    if LOCK.exists():
        if read(LOCK)!=value:raise RuntimeError('Existing immutable FiLM seal differs')
    else:write(LOCK,value)
    return value


def base_admission(seed,variant):
    if variant not in VARIANTS:raise ValueError('Unregistered FiLM variant')
    expected=read(PROTOCOL)['backbone_locks']
    if any(sha(ROOT/name)!=digest for name,digest in expected.items()):
        raise RuntimeError('Only the two authorized backbone seals are allowed')
    if variant in ('FULL','TCN'):
        return backbone.admission('dataset/compiled_train_june/manifest.json',variant,seed)
    saved=(backbone.PROTOCOL,backbone.LOCK,backbone.source_paths)
    original=saved[2]
    def paths():
        value=original()
        value['source/control_backbone_train.py']=sha(ROOT/'source/control_backbone_train.py')
        value['BACKBONE_LOCK.json']=expected['BACKBONE_LOCK.json']
        return value
    try:
        backbone.PROTOCOL=ROOT/'CONTROL_BACKBONE_PROTOCOL.json'
        backbone.LOCK=ROOT/'CONTROL_BACKBONE_LOCK.json'
        backbone.source_paths=paths
        return backbone.admission('dataset/compiled_train_june/manifest.json',variant,seed)
    finally:
        backbone.PROTOCOL,backbone.LOCK,backbone.source_paths=saved


def admission(seed,variant):
    lock=read(LOCK)
    if lock.get('status')!='sealed_film_preparation' or lock['sources']!=sources() or lock['qa_sha256']!=sha(QA):
        raise RuntimeError('FiLM source/QA seal invalid')
    base=base_admission(seed,variant)
    if base['dataset_manifest_sha256']!=read(PROTOCOL)['provenance']['dataset_manifest_sha256']:
        raise RuntimeError('FiLM dataset differs from the frozen preparation protocol')
    run=inside(f'runs/backbone/{seed}_{variant}')
    completion_path=run/'backbone_completion.json'
    completion=read(completion_path)
    if (completion['status']!='backbone_completed_pending_independent_audit' or
        completion['identity']!=base or completion['optimizer_steps']!=base['total_updates'] or
        completion['film_query_trained'] is not False):
        raise RuntimeError('New backbone completion does not match admitted case')
    audit_path=run/'backbone_audit.json'
    audit=read(audit_path)
    if audit.get('status')!='passed' or audit.get('backbone_completion_sha256')!=sha(completion_path):
        raise RuntimeError('Independent selected-backbone audit missing/stale')
    checkpoint=inside(completion['selected_checkpoint'])
    if not checkpoint.is_relative_to(run/'checkpoints') or sha(checkpoint)!=completion['selected_checkpoint_sha256']:
        raise RuntimeError('Only current newly trained backbone checkpoint is allowed')
    receipt=read(checkpoint.with_suffix('.receipt.json'))
    if receipt['sha256']!=sha(checkpoint) or receipt['identity']!=base:
        raise RuntimeError('New backbone selected checkpoint receipt mismatch')
    return dict(seed=seed,variant=variant,base_identity=base,film_lock_sha256=sha(LOCK),
        backbone_completion_sha256=sha(completion_path),backbone_audit_sha256=sha(audit_path),
        backbone_checkpoint=str(checkpoint.relative_to(ROOT)),backbone_checkpoint_sha256=sha(checkpoint),
        dataset_manifest_sha256=base['dataset_manifest_sha256'],dataset_audit_sha256=base['dataset_audit_sha256'],
        scope='TRAIN_June_only',Q3_targets_read=False,test_2026_targets_read=False)


def boundary(folder,check_resources=False):
    folder=inside(folder)
    # A stage stop also interrupts its nested prediction/gradient/trial work.
    while True:
        reason=backbone.stop_reason(folder)
        if reason:raise StopRequested(reason)
        if folder==ROOT:break
        folder=folder.parent
    if check_resources:
        try:backbone.resource_guard()
        except MemoryError as exc:raise StopRequested(str(exc)) from exc


@contextmanager
def exclusive(action,folder):
    boundary(folder,True)
    import psutil
    owner=dict(token=uuid.uuid4().hex,pid=os.getpid(),created=psutil.Process().create_time(),
               action=action,directory=str(folder),at=now())
    with backbone.GLOBAL_LOCK.open('x',encoding='utf-8') as stream:
        json.dump(owner,stream);stream.flush();os.fsync(stream.fileno())
    try:
        boundary(folder,True)
        yield owner
    finally:
        if read(backbone.GLOBAL_LOCK)!=owner:
            raise RuntimeError('FiLM refuses to remove a different global-lock owner')
        write(ROOT/'audits/film_lock_releases'/f"{owner['token']}.json",dict(owner=owner,released_at=now()))
        backbone.GLOBAL_LOCK.unlink()


def numeric():
    global np,torch
    runtime,limiter=backbone.numeric_runtime()
    np,torch=backbone.np,backbone.torch
    if runtime['threads']!=1:raise RuntimeError('New FiLM panel is uniformly one thread')
    return runtime,limiter


def array(path,value):
    backbone.atomic(path,lambda stream:np.save(stream,value,allow_pickle=False))


def archive(path,**values):
    backbone.atomic(path,lambda stream:np.savez(stream,**values))


def exact_json(path,value):
    if path.exists():
        if read(path)!=value:raise RuntimeError('Immutable FiLM artifact differs: '+str(path))
    else:write(path,value)


def commit(folder,identity,extra=None):
    row=dict(status='committed',identity=identity,
             artifacts={str(p.relative_to(folder)):sha(p) for p in sorted(folder.rglob('*'))
                        if p.is_file() and p.name!='commit.json' and not p.name.endswith('.pending')})
    if extra:row.update(extra)
    write(folder/'commit.json',row)
    return row


def check_commit(folder,identity=None):
    folder=inside(folder);row=read(folder/'commit.json')
    if row.get('status')!='committed' or (identity is not None and row['identity']!=identity):
        raise RuntimeError('FiLM commit identity mismatch')
    for name,digest in row['artifacts'].items():
        path=inside(folder/name)
        if not path.is_relative_to(folder) or sha(path)!=digest:raise RuntimeError('Changed FiLM artifact: '+str(path))
    return row


def frozen_backbone(identity,data):
    from models.factory import build_backbone
    model=build_backbone(identity['variant'],identity['seed'],read(data.paths['context_limits.json'])['limits'])
    path=inside(identity['backbone_checkpoint'])
    run=inside(f"runs/backbone/{identity['seed']}_{identity['variant']}")
    saved=backbone.load_checkpoint(run,read(path.with_suffix('.receipt.json')))
    if saved['identity']!=identity['base_identity']:raise RuntimeError('Selected new backbone payload identity')
    model.load_state_dict(saved['state_dict'],strict=True)
    return model.float().eval().requires_grad_(False)


def fingerprint(module):
    import hashlib
    digest=hashlib.sha256()
    for key,value in module.state_dict().items():
        a=value.detach().cpu().contiguous().numpy()
        digest.update(key.encode());digest.update(str(a.dtype).encode());digest.update(str(a.shape).encode());digest.update(a.tobytes())
    return digest.hexdigest()


def save_fit(folder,model,state,identity,runtime,rng):
    state['sequence']+=1
    value=dict(identity=identity,runtime=runtime,state=copy.deepcopy(state),
        state_dict=copy.deepcopy(model.film.state_dict()),head_sha256=fingerprint(model.head),
        rng=backbone.rng_state(rng),optimizer='BBDMO_Wolfe_MNP',complete_checkpoint=True)
    path=folder/'checkpoints'/f"snapshot_{state['sequence']:06d}_{uuid.uuid4().hex}.pt"
    backbone.atomic(path,lambda stream:torch.save(value,stream))
    receipt=dict(status='committed',path=str(path.relative_to(ROOT)),sha256=sha(path),
                 identity=identity,sequence=state['sequence'],phase=state['phase'],updates=state['updates'])
    write(path.with_suffix('.receipt.json'),receipt)
    write(folder/'latest.json',receipt,replace=True)
    return receipt


def restore_fit(folder,model,identity,runtime,rng):
    receipts=[]
    for file in (folder/'checkpoints').glob('*.receipt.json'):
        r=read(file);p=inside(r['path'])
        if (not p.is_relative_to(folder/'checkpoints') or r['identity']!=identity or
            p.with_suffix('.receipt.json')!=file or sha(p)!=r['sha256']):
            raise RuntimeError('Invalid FiLM resume receipt')
        receipts.append(r)
    if not receipts:return None,None
    receipt=max(receipts,key=lambda r:r['sequence'])
    saved=torch.load(inside(receipt['path']),map_location='cpu',weights_only=False)
    if (saved['identity']!=identity or saved['runtime']!=runtime or saved['head_sha256']!=fingerprint(model.head)
        or saved.get('complete_checkpoint') is not True):raise RuntimeError('FiLM resume binding changed')
    mean,std=model.film.mean.clone(),model.film.std.clone()
    model.film.load_state_dict(saved['state_dict'],strict=True)
    if not torch.equal(mean,model.film.mean) or not torch.equal(std,model.film.std):
        raise RuntimeError('FiLM checkpoint changed the newly fitted TRAIN buffers')
    backbone.restore_rng(saved['rng'],rng)
    write(folder/'latest.json',receipt,replace=True)
    return saved['state'],receipt
