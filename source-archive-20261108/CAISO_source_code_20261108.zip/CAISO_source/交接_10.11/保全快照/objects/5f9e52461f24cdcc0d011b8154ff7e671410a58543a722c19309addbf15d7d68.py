"""Finite common evaluation, audit and interpretation queue; event-only notification."""
import os, sys, json, subprocess, uuid
import gate
HERE=gate.HERE;Q=HERE/'queue'
def emit(event,**kwargs):
    row=dict(event=event,pid=os.getpid(),at=gate.now(),**kwargs)
    p=Q/'events'/(uuid.uuid4().hex+'.json')
    gate.write(p,row);gate.write(Q/'status.json',row,True);return p
def notify(event,path):
    eid='common_sampling_'+event+'_'+gate.sha(path)
    p=gate.ROOT/'event_driven_automation/inbox'/(eid+'.json')
    obj=dict(schema='caiso_research_event_v1',event_id=eid,event=event,evidence_path=str(path),complete_research_experiment=False)
    if p.exists():gate.need(gate.read(p)==obj,'Event collision')
    else:gate.write(p,obj)
    return eid
def main():
    gate.verify()
    import psutil
    owner=dict(pid=os.getpid(),created=psutil.Process().create_time(),token=uuid.uuid4().hex)
    Q.mkdir(parents=True,exist_ok=True);lock=Q/'QUEUE.lock'
    with lock.open('x',encoding='utf-8') as f:json.dump(owner,f);f.flush();os.fsync(f.fileno())
    child=None
    try:
        for name,marker,status in [('run','result.json','common_inference_completed_pending_numeric_audit'),
                                    ('audit','numeric_audit.json','passed'),
                                    ('summarize','summary.json','audited_common_development_summary')]:
            gate.verify();gate.guard(True)
            gate.need(not gate.LOCK.exists(),'Other numerical process active')
            rp=Q/'steps'/(name+'.json');mp=HERE/marker
            if rp.exists():
                rr=gate.read(rp)
                gate.need(rr['exit_code']==0 and rr['seal_sha256']==gate.sha(gate.SEAL) and rr['marker_sha256']==gate.sha(mp),'Receipt changed')
                continue
            gate.need(not mp.exists(),'Marker without successful execution receipt; review recovery required')
            out=Q/'logs'/(name+'_'+owner['token']+'.stdout.log')
            err=out.with_name(out.name.replace('stdout','stderr'));out.parent.mkdir(parents=True,exist_ok=True)
            command=[sys.executable,str(HERE/(name+'.py'))]
            with out.open('xb') as fo,err.open('xb') as fe:
                child=subprocess.Popen(command,cwd=gate.ROOT,stdout=fo,stderr=fe,creationflags=getattr(subprocess,'CREATE_NO_WINDOW',0))
                emit('step_process_started',step=name,child_pid=child.pid,command=command,stdout=str(out),stderr=str(err))
                code=child.wait()
            gate.need(code==0,f'{name} exited {code}; see {err}')
            gate.need(gate.read(mp)['status']==status,'Wrong success marker')
            gate.write(rp,dict(exit_code=code,at=gate.now(),seal_sha256=gate.sha(gate.SEAL),
                marker=gate.rel(mp),marker_sha256=gate.sha(mp),stdout=str(out),stderr=str(err)))
        gate.write(Q/'completion.json',dict(status='twelve_backbones_and_72_epoch_panels_audited',
            at=gate.now(),seal_sha256=gate.sha(gate.SEAL),
            steps={p.name:gate.sha(p) for p in sorted((Q/'steps').glob('*.json'))},
            summary=gate.rel(HERE/'summary.json'),summary_sha256=gate.sha(HERE/'summary.json'),
            heldout_targets_read=False,complete_research_experiment=False))
        eid=notify('audited_result_ready',Q/'completion.json')
        emit('finite_sampling_queue_completed',scope='common_evaluation_only',completion_sha256=gate.sha(Q/'completion.json'),event_id=eid)
        return 0
    except Exception as exc:
        paused=False
        try:gate.boundary()
        except InterruptedError:paused=True
        evidence=emit('user_stop' if paused else 'step_stopped_or_failed',reason=repr(exc),child_pid=child.pid if child else None)
        if not paused:
            eid=notify('blocking_failure',evidence)
            emit('step_stopped_or_failed',reason=repr(exc),event_id=eid,evidence_path=str(evidence))
        return 3 if paused else 2
    finally:
        if child is not None and child.poll() is None:child.wait()
        gate.need(gate.read(lock)==owner,'Queue owner changed')
        gate.write(Q/'lock_releases'/(owner['token']+'.json'),dict(owner=owner,at=gate.now()));lock.unlink()
if __name__=='__main__':raise SystemExit(main())

