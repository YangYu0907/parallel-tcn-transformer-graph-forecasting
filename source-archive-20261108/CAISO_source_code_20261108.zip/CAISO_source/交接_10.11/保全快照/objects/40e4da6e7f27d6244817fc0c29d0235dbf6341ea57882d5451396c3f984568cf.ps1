$ErrorActionPreference='Stop'
$here=$PSScriptRoot
$python='D:\Documents\conda_envs\tcn_air\python.exe'
$manager=Join-Path $here 'manager.py'
$status=Join-Path $here 'queue\status.json'
if (Test-Path -LiteralPath (Join-Path $here 'manager.lock')) { throw 'Manager identity lock exists' }
if (Test-Path -LiteralPath (Join-Path $here 'queue\completion.json')) { throw 'Finite experiment already completed' }
$p=Start-Process -FilePath $python -ArgumentList @('-B',('"' + $manager + '"')) -WorkingDirectory $here -WindowStyle Hidden -PassThru -RedirectStandardOutput (Join-Path $here 'manager.stdout.log') -RedirectStandardError (Join-Path $here 'manager.stderr.log')
$ticks=$p.StartTime.ToUniversalTime().Ticks
$bridgeScript=Join-Path $here 'watch_manager_exit.ps1'
$bridge=Start-Process -FilePath 'powershell.exe' -ArgumentList @('-NoProfile','-ExecutionPolicy','Bypass','-File',('"' + $bridgeScript + '"'),'-ManagerProcessId',$p.Id,'-ManagerStartUtcTicks',$ticks,'-ManagerScript',('"' + $manager + '"'),'-StatusPath',('"' + $status + '"')) -WindowStyle Hidden -PassThru
$record=[ordered]@{at=[DateTime]::UtcNow.ToString('o');manager_pid=$p.Id;manager_start_utc_ticks=$ticks;exit_bridge_pid=$bridge.Id;manager_script=$manager;timer=$false}
$record | ConvertTo-Json | Set-Content -LiteralPath (Join-Path $here 'launch.json') -Encoding UTF8
$record | ConvertTo-Json -Compress
