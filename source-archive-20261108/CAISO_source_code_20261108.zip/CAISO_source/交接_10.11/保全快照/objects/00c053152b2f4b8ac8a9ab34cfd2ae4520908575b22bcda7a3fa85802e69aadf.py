from core import *
import argparse,random

def run(fold,name):
    verify()
    run=HERE/f'fold{fold}'/name;run.mkdir(parents=True,exist_ok=True)
    if (run/'COMPLETE.json').exists():return
    with numeric('integrated chronological '+str(fold)+' '+name):
        import numpy as np,torch
        from fair_inputs import PriceModel,runtime,lr,save_pt
        runtime();tick=timer('neural');raw,times,_,_=arrays()
        stats=read(HERE/f'fold{fold}_stats.json')['neural']
        z=np.load(HERE/f'fold{fold}_origins.npz');tr=z['train'];ev=z['evaluate']
        seed=SEEDS[0];model=PriceModel(name,seed,stats['limits'])
        torch.manual_seed(seed+200000);np.random.seed(seed);random.seed(seed)
        rng=np.random.default_rng(seed+fold*1000)
        opt=torch.optim.AdamW(model.parameters(),lr=.001,weight_decay=.0001,betas=(.9,.999),eps=1e-8)
        identity=dict(protocol=sha(HERE/'PROTOCOL.json'),fold=fold,model=name,seed=seed)
        state=dict(epoch=1,offset=0,steps=0,order=None)
        latest=run/'latest.pt'
        def checkpoint():
            save_pt(latest,dict(identity=identity,model=model.state_dict(),optimizer=opt.state_dict(),state=state,
                rng=rng.bit_generator.state,torch_rng=torch.get_rng_state(),numpy_rng=np.random.get_state(),python_rng=random.getstate()))
        if latest.exists():
            c=torch.load(latest,map_location='cpu',weights_only=False);assert c['identity']==identity
            model.load_state_dict(c['model']);opt.load_state_dict(c['optimizer']);state=c['state']
            rng.bit_generator.state=c['rng'];torch.set_rng_state(c['torch_rng']);np.random.set_state(c['numpy_rng']);random.setstate(c['python_rng']);del c
        start=time.monotonic();initial=state['steps'];checkpoint()
        try:
            while state['epoch']<=12:
                for g in opt.param_groups:g['lr']=lr(state['epoch'])
                if state['order'] is None:
                    state['order']=rng.permutation(tr)[:4032];state['offset']=0;checkpoint()
                while state['offset']<4032:
                    if state['steps']%32==0:
                        checkpoint();n=state['steps']-initial
                        tick(fold=fold,model=name,epoch=state['epoch'],steps=state['steps'],
                             seconds_per_update=(time.monotonic()-start)/n if n else None)
                    oo=state['order'][state['offset']:state['offset']+4]
                    x,y=neural_batch(raw,oo,stats)
                    model.train();opt.zero_grad(set_to_none=True)
                    loss=torch.nn.functional.huber_loss(model(torch.from_numpy(x)),torch.from_numpy(y),delta=.5)
                    assert torch.isfinite(loss);loss.backward()
                    assert all(p.grad is not None and torch.isfinite(p.grad).all() for p in model.parameters() if p.requires_grad)
                    torch.nn.utils.clip_grad_norm_(model.parameters(),1.);opt.step()
                    state['offset']+=len(oo);state['steps']+=1
                state['epoch']+=1;state['offset']=0;state['order']=None;checkpoint()
            assert state['steps']==12096
            model.eval();pred=[];truth=[];contexts=[];last=[]
            c=np.array(stats['center']);s=np.array(stats['scale'])
            with torch.no_grad():
                for j in range(0,len(ev),4):
                    if j%64==0:tick(fold=fold,model=name,inference=j,total=len(ev))
                    oo=ev[j:j+4];x,y=neural_batch(raw,oo,stats)
                    pred.append(model(torch.from_numpy(x)).numpy().astype(float)*s[None,:,None]+c[None,:,None])
                    # Use identical raw target arithmetic for every expert/control.
                    truth.append(np.stack([raw[o:o+12].T.astype(float) for o in oo]))
                    contexts.append(price_features(x[:,:,:,0]));last.append(raw[oo-1].astype(float))
            yy=np.concatenate(truth);ll=np.concatenate(last)
            save(run/'PREDICTIONS.npz',origins=ev,days=times[ev-1]//86400,cutoff=times[ev-1],
                prediction=np.concatenate(pred),truth=yy,context=np.concatenate(contexts),last=ll,states=codes(yy,ll,stats))
            verify();write(run/'COMPLETE.json',dict(at=now(),identity=identity,steps=state['steps'],fixed_epoch=12,
                training_target_last=int(times[tr.max()+11]),evaluation_cutoff_first=int(times[ev.min()-1]),
                prediction_sha256=sha(run/'PREDICTIONS.npz'),checkpoint_sha256=sha(latest),selection_on_forward_errors=False))
            tick(fold=fold,model=name,status='complete')
        except Exception:
            checkpoint();tick(fold=fold,model=name,status='saved_at_boundary');raise

if __name__=='__main__':
    p=argparse.ArgumentParser();p.add_argument('--fold',type=int,required=True);p.add_argument('--model',required=True)
    a=p.parse_args();run(a.fold,a.model)
