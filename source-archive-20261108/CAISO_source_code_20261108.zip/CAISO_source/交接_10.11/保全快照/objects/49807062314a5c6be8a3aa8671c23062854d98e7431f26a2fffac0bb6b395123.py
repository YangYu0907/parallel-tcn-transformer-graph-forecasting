from engine import *
def main():
    verify();checked(True);checks=0;result=old.read(HERE/'RESULT.json')
    with old.numeric('event memory separate numerical and inference audit'):
        allpass=True;raw,times,_,_=old.parent.arrays()
        for fold in [1,2]:
            folder=HERE/f'probe{fold}';checked()
            with np.load(folder/'REPLAY.npz') as z:d={k:z[k] for k in z.files}
            y=d['y'];dates=np.unique(d['days']);row=result['probes'][fold-1]
            for kind,key in [('CONTROL','control'),('MEMORY','memory')]:
                p=d[key];b=(p-y)**2;ll=np.where(y==1,-np.log(p),-np.log1p(-p))
                m=dict(brier=float(b.mean()),log_loss=float(ll.mean()),
                    date_brier=float(np.mean([b[d['days']==v].mean() for v in dates])),
                    date_log_loss=float(np.mean([ll[d['days']==v].mean() for v in dates])))
                for k,v in m.items():assert np.isclose(v,row[key][k],rtol=1e-11);checks+=1
                path=folder/kind/'model.pkl';fr=old.read(folder/kind/'FROZEN.json');assert old.sha(path)==fr['sha256'];checks+=1
                saved=old.load(path);assert saved['protocol']==old.sha(HERE/'PROTOCOL.json');checks+=1
                idx=np.array([0,len(y)//2,len(y)-1]);xx=control_X(d['X'][idx]) if kind=='CONTROL' else d['X'][idx]
                assert np.allclose(saved['model'].predict_proba(xx)[:,1],p[idx],rtol=0,atol=1e-12);checks+=1
            support=old.read(folder/'SUPPORT.json');assert support['last_fit_target']<support['first_probe_cutoff']-86400;checks+=1
            st=old.read(folder/'STATS.json')
            # Check inference inputs from actual raw prefix, not only saved design matrices.
            idx=np.array([0,len(y)//2,len(y)-1]);ids=d['ids'][idx];f,last=features_at(raw,ids[:,0],st)
            xx=np.column_stack([f[np.arange(3),ids[:,1]],np.eye(30)[ids[:,1]],(ids[:,2]+1)/12]).astype('float32')
            assert np.array_equal(xx,d['X'][idx]);checks+=1
            truth=(abs(raw[ids[:,0]+ids[:,2],ids[:,1]]-np.array(st['center'])[ids[:,1]])<=np.array(st['thresholds'])[1,ids[:,1]])
            assert np.array_equal(truth,d['y'][idx]);checks+=1
            passed=min(row['memory']['recovery_dates'],row['memory']['extreme_dates'])>=5 and all(row['memory'][k]<row['control'][k] for k in ['brier','log_loss','date_brier','date_log_loss'])
            assert passed==row['passed'];checks+=1;allpass=allpass and passed
        if not allpass:
            assert result['stage']=='stopped_at_inner_temporal_probe' and result['new_fits']==4 and not result['screen_passed'];checks+=1
            assert not (HERE/'fold1').exists() and not (HERE/'fold2').exists();checks+=1
        else:
            assert result['new_fits']==6
            for fold in [1,2]:
                with np.load(HERE/f'REPLAY_fold{fold}.npz') as z:d={k:z[k] for k in z.files}
                for row in [x for x in result['rows'] if x['fold']==fold]:
                    err=d[row['model']]-d['truth']
                    assert np.allclose([np.abs(err).mean(),np.linalg.norm(err.ravel())/np.sqrt(err.size)],
                        [row['mae'],row['rmse']],rtol=1e-11);checks+=2
                    for state in row['states']:
                        e=err[d['states']==state['state']]
                        assert np.allclose([np.abs(e).mean(),np.linalg.norm(e)/np.sqrt(e.size)],[state['mae'],state['rmse']],rtol=1e-11);checks+=2
                for seed in old.SEEDS:
                    a=d[f'MEMORY_{seed}'];b=d[f'BASE_{seed}']
                    assert np.array_equal(a[:,:,:7],b[:,:,:7]) and np.array_equal(a[d['states']<3],b[d['states']<3]);checks+=2
                    rec=next(x for x in result['details'] if x['fold']==fold and x['seed']==seed)
                    assert old.parent.qualification(a,b,d['truth'],d['states'],d['days'])['passed']==rec['qualification']['passed'];checks+=1
        verify()
        old.write(HERE/'AUDIT.json',dict(at=old.now(),status='separate_arithmetic_and_inference_replay_passed',checks=checks,
            result_sha256=old.sha(HERE/'RESULT.json'),screen_passed=result['screen_passed'],protected_files=18,
            new_test_targets_read=False,V7_replaced=False,external_human_review=False))
if __name__=='__main__':main()
