from common import *
def main():
    with gate.exclusive('V8 analytic QA before fitting'):
        np,lim=gate.runtime(False);import mathcore as mc
        classes=np.array([[2,2,0,1]+[2]*8,[2]*12,[0]*12]);risk,event,post=mc.targets(classes)
        assert risk[0].sum()==3 and event[0,2] and post[0].sum()==10 and not event[1].any() and post[2].all()
        prob=mc.survival(np.full((1,12),.2),np.broadcast_to([1.,0.,0.],(1,12,3)))
        assert np.allclose(prob[:,:,2],.8**np.arange(1,13)) and np.allclose(prob.sum(-1),1)
        X,sc=mc.design(prob,np.array([3]),np.array([.2]));W=np.zeros((X.shape[1],3));W[:3]=np.eye(3)
        assert np.allclose(mc.softmax(X@W),prob.reshape(-1,3))
        rng=np.random.default_rng(81030);x=rng.normal(size=(21,7));ref=np.zeros((7,3));ref[:3]=np.eye(3);par=(ref+rng.normal(0,.03,ref.shape)).ravel();y=rng.integers(0,3,21)
        loss,grad=mc.calibration_loss_grad(par,x,y,ref)
        for j in range(len(par)):
            a=par.copy();b=par.copy();a[j]+=1e-6;b[j]-=1e-6
            fd=(mc.calibration_loss_grad(a,x,y,ref)[0]-mc.calibration_loss_grad(b,x,y,ref)[0])/2e-6
            assert abs(fd-grad[j])<1e-6
        atoms=np.array([[-2.,0.,2.],[-10.,1.,2.],[1.,2.,5.]]);weights=np.array([[.1,.8,.1],[.1,.6,.3],[.2,.6,.2]]);full=np.array([1.,0.,0.])
        pred,alpha,d=mc.forecast(full,atoms,weights,True);assert (alpha>=0).all() and (alpha<=.75).all()
        for j in range(3):
            grid=np.linspace(0,.75,10001);e0=full[j]-atoms[j];e=e0[None,:]+grid[:,None]*d[j]
            risks=((e*e+np.maximum(e*e-e0*e0,0))*weights[j]).sum(1);ae=(abs(e)*weights[j]).sum(1);valid=ae<=(abs(e0)*weights[j]).sum()+1e-12
            actual=pred[j]-atoms[j];obj=((actual*actual+np.maximum(actual*actual-e0*e0,0))*weights[j]).sum()
            assert obj<=risks[valid].min()+1e-6
            assert (abs(actual)*weights[j]).sum()<=(abs(e0)*weights[j]).sum()+1e-9
        p2,a2,d2=mc.forecast(full+123,atoms+123,weights,True);assert np.allclose(p2,pred+123)
        p3,a3,d3=mc.forecast(full*7,atoms*7,weights,True);assert np.allclose(p3,pred*7,atol=1e-7)
        # No target argument is accepted by either inference transformation.
        targets=np.zeros(3);before=mc.forecast(full,atoms,weights,True)[0];targets[:]=1e9;after=mc.forecast(full,atoms,weights,True)[0];assert np.array_equal(before,after)
        for f in gate.read(HERE/'FOLDS.json'):
            assert f['max_fit_target_second']<f['first_validation_origin_second']-300 and not set(f['fit_indices'])&set(f['validation_indices'])
        write(HERE/'QA.json',dict(at=gate.now(),status='passed',checks=['first-exit censoring','analytic survival','identity log-probability map','all21calibrator gradient components finite-difference checked','risk optimum against independent dense grid','expected absolute-loss constraint','translation and scale equivariance','future-target mutation invariant','chronological target purge'],real_market_test_targets_read=False))
        files=[HERE/n for n in ('common.py','mathcore.py','worker.py','audit.py','manager.py','register.py','qa.py','PROTOCOL.json','SOURCE_BINDINGS.json','FOLDS.json','DATA_ADMISSION.json','QA.json')]
        write(HERE/'EXECUTION_SEAL.json',dict(at=gate.now(),bindings={str(p):gate.sha(p) for p in files}));print('V8 numerical QA passed; code sealed')
if __name__=='__main__':main()

