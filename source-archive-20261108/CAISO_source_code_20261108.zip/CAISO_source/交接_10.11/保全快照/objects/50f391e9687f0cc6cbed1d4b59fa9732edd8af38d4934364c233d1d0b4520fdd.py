import numpy as np

def inputs(context,full,v7,v10,p7,p10,center,q):
    """Origin-time inputs only; no label, future-state, date-ID or node-ID argument."""
    n=len(context);h=np.tile((np.arange(12)+1)/12,n)
    ctx=np.repeat(context,12,axis=0);c=np.repeat(center,12);s=np.repeat(q,12)
    f=full.ravel();a=v7.ravel();b=v10.ravel()
    return np.column_stack([ctx[:,17],ctx[:,21],ctx[:,53],ctx[:,37],ctx[:,44],ctx[:,71],ctx[:,92],h,
         (f-c)/s,(a-c)/s,(b-c)/s,(a-f)/s,(b-f)/s,p7[:,:,2].ravel(),p10[:,:,2].ravel(),(p10[:,:,2]-p7[:,:,2]).ravel()])

def losses(experts,y,scale):
    e=experts-y[:,None];a=np.abs(e);s=e*e
    return np.column_stack([(a[:,0]-a[:,1])/scale,(s[:,0]-s[:,1])/scale**2,
                            (a[:,2]-a[:,1])/scale,(s[:,2]-s[:,1])/scale**2])

def fit(x,y):
    center=x.mean(0);scale=x.std(0);scale=np.where(scale<1e-8,1.,scale)
    z=(x-center)/scale;yc=y.mean(0)
    coef=np.linalg.solve(z.T@z+100*np.eye(x.shape[1]),z.T@(y-yc))
    return dict(center=center,scale=scale,coef=coef,intercept=yc)

def predict(model,x):return ((x-model['center'])/model['scale'])@model['coef']+model['intercept']

def train_guard(x,y,days,fitmask,calmask):
    dates=np.unique(days[fitmask]);cd=np.unique(days[calmask])
    assert len(dates)>=3 and len(cd)==2
    model=fit(x[fitmask],y[fitmask]);sub=[]
    for d in dates:
        use=fitmask&(days!=d);sub.append(fit(x[use],y[use]))
    residual=y[calmask]-predict(model,x[calmask]);dd=days[calmask]
    means=np.stack([residual[dd==d].mean(0) for d in cd]);bias=means.mean(0)
    variance=means.var(0,ddof=1)/len(cd)
    return dict(model=model,jackknife=sub,bias=bias,calibration_mean_variance=variance,fit_dates=dates,calibration_dates=cd)

def upper(obj,x):
    estimate=predict(obj['model'],x);sub=np.stack([predict(m,x) for m in obj['jackknife']])
    n=len(sub);variance=(n-1)/n*((sub-sub.mean(0))**2).sum(0)
    return estimate+obj['bias']+1.645*np.sqrt(variance+obj['calibration_mean_variance'])

def choices(bounds):
    good=np.column_stack([(bounds[:,:2]<0).all(1),(bounds[:,2:]<0).all(1)])
    risk=np.column_stack([bounds[:,:2].max(1),bounds[:,2:].max(1)])
    risk=np.where(good,risk,np.inf);pick=np.where(risk[:,0]<=risk[:,1],0,2)
    return np.where(good.any(1),pick,1)

def eligible(issued,available,first_evaluation):
    return (issued<first_evaluation)&(available<first_evaluation)

def qa():
    b=np.array([[-1,-2,1,1],[1,1,-1,-2],[1,-1,-1,1],[-1,-1,-2,-2]])
    assert np.array_equal(choices(b),[0,2,1,2])
    assert np.array_equal(eligible(np.array([1,1,5]),np.array([3,5,4]),5),[True,False,False])
    rng=np.random.default_rng(123);x=rng.normal(size=(50,16));y=rng.normal(size=(50,4));m=fit(x,y)
    assert np.isfinite(predict(m,x)).all()
    # A withheld future target has no path into fit normalization or routing.
    y2=y.copy();y2[30:]+=1e6
    a=fit(x[:30],y[:30]);c=fit(x[:30],y2[:30]);assert np.array_equal(predict(a,x[30:]),predict(c,x[30:]))
    return ['strict release cutoff','two loss agreement','uncertain selection abstains','future target perturbation invariant','finite ridge fit']
