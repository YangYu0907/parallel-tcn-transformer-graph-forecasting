from pathlib import Path
import numpy as np,json,sys
sys.stdout.reconfigure(encoding='utf-8')
A=Path(r'C:\Users\于阳\CAISO_V7_成功实验归档_20261002');B=A/'研究资料/CAISO_feature_fusion_rev12/asof_retraining_branch_20260913';T=A/'运行依赖/CAISO_temporary_storage'
paths=[T/'adaptive_experts_v4_20260929/panel.npz',T/'adaptive_experts_v4_20260929/experts/20260813.npz',T/'spike_specialist_v7_20260930/audited/20260813.npz',T/'spike_specialist_v7_20260930/predictions/20260813.npz',T/'spike_specialist_v7_20260930/H1_features.npz', B/'energy_confirmation_v1_20260926/data/train_valid.npz', B/'energy_confirmation_v1_20260926/runs/FULL_20260813_0.001/validation_predictions.npz']
rows=[]
for p in paths:
 with np.load(p,allow_pickle=False) as z:
  row={'path':str(p),'arrays':{k:{'shape':z[k].shape,'dtype':str(z[k].dtype)} for k in z.files}}
  for k in ['origins','timestamps','delivery_days','fit','cal']:
   if k in z: row[k+'_first_last']=[str(z[k][:3]),str(z[k][-3:])]
 rows.append(row)
f=json.loads((B/'adaptive_experts_v4_20260929/FOLDS.json').read_text())
print(json.dumps(rows,ensure_ascii=False,indent=2));print('FOLDS',[(x['id'],len(x['evaluation']), {k:(len(v) if isinstance(v,list) else v) for k,v in x.items() if k!='evaluation'}) for x in f])
(A/'老师意见修订_20261003/DEVELOPMENT_ARRAY_INVENTORY.json').write_text(json.dumps(rows,ensure_ascii=False,indent=2),encoding='utf-8')
