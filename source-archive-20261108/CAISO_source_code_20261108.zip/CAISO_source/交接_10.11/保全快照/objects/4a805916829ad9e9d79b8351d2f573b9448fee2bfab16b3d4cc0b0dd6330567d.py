"""Finite serial worker then independent arithmetic audit; event-only notification."""
from common import *
import subprocess,json

def event(kind,evidence):
    eid='adaptive_v2_'+kind+'_'+gate.sha(evidence)
    gate.write(B/'event_driven_automation/inbox'/(eid+'.json'),dict(schema='caiso_research_event_v1',event_id=eid,
        event=kind,evidence_path=str(evidence),at=gate.now(),trial=str(HERE),new_test_targets_read=False))
    return eid

def main():
    gate.boundary();guard();gate.need(not gate.LOCK.exists(),'Numerical worker already active')
    for path,digest in gate.read(HERE/'EXECUTION_SEAL.json')['bindings'].items():
        gate.need(gate.sha(path)==digest,'Changed sealed dependency: '+path)
    lock=HERE/'queue/manager.lock';lock.parent.mkdir(parents=True,exist_ok=True)
    with lock.open('x') as f:f.write(str(os.getpid()))
    try:
        h=gate.read(B/'HANDOFF.json');h.update(at=gate.now(),status='adaptive_v2_finite_development_running',
            current_process=os.getpid(),training_active=True,current_plan_complete=False)
        h['adaptive_experts_v2']=dict(directory=str(HERE),status_path=str(HERE/'queue/status.json'),
            protocol=str(HERE/'PROTOCOL.json'),new_test_targets_read=False)
        gate.write(B/'HANDOFF.json',h)
        for script in ('worker.py','audit.py'):
            guard();status(event='step_process_started',script=script)
            result=subprocess.run([sys.executable,str(HERE/script)],cwd=str(HERE))
            if result.returncode:raise RuntimeError(f'{script} exit {result.returncode}')
        decision=gate.read(HERE/'DECISION.json')
        passed=decision['status'].startswith('development_passed')
        completion=HERE/'queue/completion.json'
        gate.write(completion,dict(at=gate.now(),status='finite_development_and_audit_completed',
            decision=str(HERE/'DECISION.json'),decision_sha256=gate.sha(HERE/'DECISION.json'),
            new_test_targets_read=False,complete_research_experiment=False))
        h=gate.read(B/'HANDOFF.json');h.update(at=gate.now(),status=decision['status'],current_process=None,
            training_active=False,current_plan_complete=True,complete_research_experiment=False)
        h['adaptive_experts_v2'].update(decision=str(HERE/'DECISION.json'),result=str(HERE/'RESULT.json'))
        gate.write(B/'HANDOFF.json',h)
        eid=event('audited_result_ready' if passed else 'unexpected_result',completion)
        status(event='finite_sampling_queue_completed',event_id=eid)
    except BaseException as exc:
        stopped=isinstance(exc,InterruptedError)
        try:
            gate.boundary()
            for folder in (HERE,HERE/'queue'):
                for name in ('STOP_REQUESTED','STOP_REQUESTED.json'):
                    if (folder/name).exists():stopped=True
        except InterruptedError:
            stopped=True
        evidence=HERE/'queue/STOP.json'
        gate.write(evidence,dict(at=gate.now(),error=repr(exc),automatic_restart=False,checkpoints_preserved=True))
        h=gate.read(B/'HANDOFF.json');h.update(at=gate.now(),status='adaptive_v2_stopped_with_saved_state',
            current_process=None,training_active=False);gate.write(B/'HANDOFF.json',h)
        eid=None if stopped else event('blocking_failure',evidence)
        status(event='user_stop' if stopped else 'sampling_blocking_failure',event_id=eid,error=repr(exc))
        raise
    finally:
        assert lock.read_text()==str(os.getpid());lock.unlink()

if __name__=='__main__':main()
