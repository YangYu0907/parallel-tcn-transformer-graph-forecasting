from pathlib import Path
import sys,json,os
R=Path(__file__).resolve().parent;N=R.parents[1]
sys.path.insert(0,str(N))
import gate
seal=gate.verify_evaluation()
assert os.environ.get('PYTHONPATH')==str(gate.ORIGINAL)
import model_adapter,official_models
assert Path(model_adapter.__file__).resolve()==gate.ORIGINAL/'model_adapter.py'
assert Path(official_models.__file__).resolve()==gate.EXT/'source/official_models.py'
review=gate.read(R/'review.json')
assert review['status']=='passed'
for p,d in review['bindings'].items():assert gate.sha(p)==d,p
assert 'torch' not in sys.modules
assert not gate.LOCK.exists()
print(json.dumps(dict(status='passed',resources=gate.guard(True),model_adapter_path=str(Path(model_adapter.__file__).resolve()),training_will_restart=False)))
