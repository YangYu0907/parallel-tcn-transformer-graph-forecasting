"""Fixed paired three-seed TRAIN/June weighting decision; no blind-test access."""
import statistics,json,hashlib
import gate
M=('mae','rmse','near_h1_4_mae','h12_mae');PANELS=('June284','June3397','balanced278')
def compare(a,b):
 return {p:{m:dict(candidate=a[p][m],reference=b[p][m],reduction_percent=100*(1-a[p][m]/b[p][m])) for m in M} for p in PANELS}
def main():
 s=gate.verify();rows=[];groups={'phase_weighted':[],'unweighted':[]};common=None
 import numpy as np
 for c in s['cases']:
  pair={}
  for label,folder in (('phase_weighted',gate.HERE),('unweighted',gate.BUD)):
   d=folder/'runs'/c['id'];r=gate.read(d/'completion.json');a=gate.read(d/'audit.json')
   gate.need(a['status']=='passed' and a['completion_sha256']==gate.sha(d/'completion.json'),'Missing audit')
   for p,h in a['output_bindings'].items():gate.need(gate.sha(gate.inside(p))==h,'Audited output changed')
   ref=r['dense_evaluation'];gate.need(gate.sha(gate.inside(ref['path']))==ref['sha256'],'Dense changed')
   with np.load(gate.inside(ref['path']),allow_pickle=False) as z:
    hashes=[hashlib.sha256(z[k].tobytes()).hexdigest() for k in ('origins','truth','codes')]
   if common is None:common=hashes
   else:gate.need(common==hashes,'Different comparison population')
   groups[label].append(r);pair[label]=r
  rows.append(dict(case=c['id'],weighted_selected_epoch=pair['phase_weighted']['selected_epoch'],unweighted_selected_epoch=pair['unweighted']['selected_epoch'],
   paired_changes=compare(pair['phase_weighted']['panels'],pair['unweighted']['panels']),
   weighted_panels=pair['phase_weighted']['panels'],unweighted_panels=pair['unweighted']['panels'],
   hourly_curves={k:[dict(epoch=x['epoch'],mae=x['june']['mae'],training_objective=x['train_huber_mean']) for x in r['epochs']] for k,r in pair.items()}))
 means={k:{p:{m:statistics.mean(r['panels'][p][m] for r in rr) for m in M} for p in PANELS} for k,rr in groups.items()}
 protection={p:{m:means['phase_weighted'][p][m]<=means['unweighted'][p][m]+1e-9 for m in M} for p in PANELS}
 no_headline_regression=all(v for d in protection.values() for v in d.values())
 dense_improves=means['phase_weighted']['June3397']['mae']<means['unweighted']['June3397']['mae']-1e-6
 gate.write(gate.HERE/'summary.json',dict(status='three_phase_weighted_cases_audited',at=gate.now(),cases=rows,means=means,
  mean_paired_changes=compare(means['phase_weighted'],means['unweighted']),headline_protection=protection,
  warrants_matched_controls_review=no_headline_regression and dense_improves,automatic_promotion=False,
  scope='Three paired seeds with exact shared epoch6 terminal weights, Adam/RNG/shuffle and12096total updates; only tail7..12 origin loss weights differ. June is development.',
  training_objective_comparability='Weighted and unweighted online Huber means target different risks and must not be treated as identical training metrics.',
  common_origins_truth_codes_sha256=common,all_positive_negative_results_preserved=True,
  next='Close if benefit/protection unsupported. If supported, review every state/node/horizon/seed then same weighted EQUAL/CONCAT and competitive-input fair controls before any mechanism claim or final promotion; no LR/weight grid.',
  heldout_targets_read=False,complete_research_experiment=False))
 print(json.dumps(dict(status='three_phase_weighted_cases_audited',cases=3,automatic_promotion=False)))
if __name__=='__main__':
 with gate.exclusive('phase_weighting_summary'):
  np,lim=gate.runtime(False);main()
