"""Storage-only HGB adapter: original encoding, thresholds, bins and tree learner.

Large immutable matrices live on disk. Columns are mapped separately so mapped
pages can be released promptly; no training row, weight or threshold is changed.
"""
from pathlib import Path
import json, gc
import numpy as np
from sklearn.ensemble import HistGradientBoostingClassifier
from sklearn.ensemble._hist_gradient_boosting.binning import _find_binning_thresholds
from sklearn.ensemble._hist_gradient_boosting._binning import _map_to_bins
from sklearn.utils import check_random_state

TICK=lambda **kw: None
def column(path,j):
    mm=np.load(path,mmap_mode='r'); value=np.array(mm[:,j],dtype=np.float64)
    mm._mmap.close();return value

class DiskHGB(HistGradientBoostingClassifier):
    def _preprocess_X(self,X,*,reset):
        if not reset:return super()._preprocess_X(X,reset=False)
        assert isinstance(X,np.memmap) and X.flags.f_contiguous
        assert self.early_stopping is False and self.categorical_features==[24]
        source=Path(X.filename); encoded=source.with_suffix('.encoded.npy')
        marker=source.with_suffix('.encoded.json')
        cat=column(source,24); _,idx=np.unique(cat,return_index=True)
        assert np.isfinite(cat).all(); del cat
        # All categorical levels appear in these representatives. Numerical
        # preprocessing in this sklearn version is identity + float64 casting.
        sample=np.array(X[idx]); _,known=super()._preprocess_X(sample,reset=True)
        signature=dict(path=str(source),size=source.stat().st_size,mtime=source.stat().st_mtime_ns,shape=list(X.shape))
        if not marker.exists() or json.loads(marker.read_text())!=signature:
            mm=np.lib.format.open_memmap(encoded,mode='w+',dtype=np.float64,shape=X.shape,fortran_order=True);mm._mmap.close()
            ordering=[24]+[j for j in range(X.shape[1]) if j!=24]
            encoder=self._preprocessor.named_transformers_['encoder']
            for target,j in enumerate(ordering):
                value=column(source,j)
                if j==24:value=encoder.transform(value[:,None])[:,0]
                mm=np.load(encoded,mmap_mode='r+');mm[:,target]=value;mm.flush();mm._mmap.close();del value
                if target%16==0:TICK(stage='disk_feature_encoding',columns=target,total=X.shape[1])
            marker.write_text(json.dumps(signature),encoding='utf-8')
        gc.collect();return np.load(encoded,mmap_mode='r'),known

    def _bin_data(self,X,is_training_data):
        assert is_training_data and isinstance(X,np.memmap)
        mapper=self._bin_mapper;n,d=X.shape
        rng=check_random_state(mapper.random_state)
        subset=rng.choice(n,mapper.subsample,replace=False) if mapper.subsample is not None and n>mapper.subsample else None
        mapper.is_categorical_=np.asarray(mapper.is_categorical,dtype=np.uint8)
        mapper.missing_values_bin_idx_=mapper.n_bins-1
        mapper.bin_thresholds_=[];sizes=[]
        binned=np.empty((n,d),dtype=np.uint8,order='F')
        for j in range(d):
            value=column(X.filename,j)
            if mapper.is_categorical_[j]:threshold=mapper.known_categories[j]
            else:threshold=_find_binning_thresholds(value if subset is None else value[subset],mapper.n_bins-1)
            mapper.bin_thresholds_.append(threshold)
            sizes.append(len(threshold) if mapper.is_categorical_[j] else len(threshold)+1)
            _map_to_bins(value[:,None],[threshold],mapper.is_categorical_[j:j+1],mapper.missing_values_bin_idx_,1,binned[:,j:j+1])
            del value
            if j%16==0:TICK(stage='disk_binning',columns=j,total=d)
        mapper.n_bins_non_missing_=np.asarray(sizes,dtype=np.uint32)
        X._mmap.close();gc.collect();TICK(stage='disk_binning_complete',features=d,rows=n)
        return binned
