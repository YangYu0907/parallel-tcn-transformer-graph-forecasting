"""Eight fixed earlier-only fits; guarded, resumable predictions; no new test reader."""
from pathlib import Path
from datetime import datetime, timezone
import os, sys, json, pickle, uuid, time, traceback
HERE=Path(__file__).resolve().parent;B=HERE.parent
sys.path.insert(0,str(B/'context_expert_v1_20260929'))
import gate
ART=Path('C:/Users/于阳/CAISO_temporary_storage')/HERE.name
OLD=B/'chronological_expert_pilot_v14_20260930';OLDART=ART.parent/OLD.name
Q=HERE/'pilot';START=None;USED=0;np=None
def stamp(s):return int(datetime.fromisoformat(s.replace('Z','+00:00')).timestamp())
def atomic(p,fn):
    p=Path(p);assert p.resolve().is_relative_to(ART.resolve())
    p.parent.mkdir(parents=True,exist_ok=True);tmp=p.with_name('.'+p.name+'.'+uuid.uuid4().hex+'.tmp')
    with tmp.open('xb') as f:fn(f);f.flush();os.fsync(f.fileno())
    os.replace(tmp,p)
def save(p,**kw):atomic(p,lambda f:np.savez_compressed(f,**kw))
def check(**kwargs):
    gate.guard()
    for root in (HERE,Q):
        if any((root/name).exists() for name in ('STOP_REQUESTED','STOP_REQUESTED.json')):raise InterruptedError('V17 stop requested')
    elapsed=USED+time.monotonic()-START
    gate.write(Q/'budget.json',dict(at=gate.now(),used_seconds=elapsed,maximum_seconds=1800))
    if elapsed>=1800:raise TimeoutError('Fixed1800second development budget reached; no extension')
    if kwargs:gate.write(Q/'status.json',dict(at=gate.now(),pid=os.getpid(),event='step_process_started',**kwargs))
def emit(kind,path):
    event_id='conditional_risk_v17_'+kind+'_'+gate.sha(path)
    gate.write(B/'event_driven_automation/inbox'/(event_id+'.json'),dict(schema='caiso_research_event_v1',at=gate.now(),event_id=event_id,event=kind,evidence_path=str(path),periodic=False))
    gate.write(Q/'status.json',dict(at=gate.now(),pid=os.getpid(),event='step_stopped_or_failed' if kind=='blocking_failure' else 'finite_mechanism_queue_completed',event_id=event_id,evidence_path=str(path)))

def metrics(p,y,states,low,days):
    error=p-y
    def m(e):return dict(mae=float(abs(e).mean()),rmse=float(np.sqrt(np.square(e).mean()))) if e.size else dict(mae=None,rmse=None)
    states_out=[]
    for s in range(6):
        mask=states==s
        states_out.append(dict(state=s,cells=int(mask.sum()),dates=len(np.unique(np.broadcast_to(days[:,None,None],mask.shape)[mask])),**m(error[mask])))
    return dict(overall=m(error),near=m(error[:,:,:4]),h12=m(error[:,:,-1]),lowvol=m(error[np.broadcast_to(low[:,:,None],error.shape)]),
        by_state=states_out,by_node=[m(error[:,i,:]) for i in range(30)],by_horizon=[m(error[:,:,h]) for h in range(12)])
def flat_metrics(m):
    out={}
    for k in ['overall','near','h12','lowvol']:
        for metric,v in m[k].items():out[k+'/'+metric]=v
    for k in ['by_state','by_node','by_horizon']:
        for i,row in enumerate(m[k]):
            for metric in ['mae','rmse']:out[k+'/'+str(i)+'/'+metric]=row[metric]
    return out

def main():
    global np,START,USED
    with gate.exclusive('V17 fixed conditional-risk gate pilot, eight fits maximum'):
        np,limiter=gate.runtime(False)
        readiness=gate.read(HERE/'PILOT_READINESS.json');assert readiness['status']=='bounded_development_pilot_admitted'
        registration=gate.read(Q/'IMPLEMENTATION_FREEZE.json')
        assert registration['worker_sha256']==gate.sha(__file__) and registration['readiness_sha256']==gate.sha(HERE/'PILOT_READINESS.json')
        for p,h in readiness['bindings'].items():assert gate.sha(p)==h,p
        protocol=gate.read(HERE/'PROTOCOL.json')
        for p,h in protocol['evidence_bindings'].items():assert gate.sha(p)==h,p
        assert readiness['independent_test_release_allowed'] is False
        USED=gate.read(Q/'budget.json')['used_seconds'] if (Q/'budget.json').exists() else 0
        START=time.monotonic();check(stage='load_frozen_development_library')
        from risk_gate import ConditionalRiskGate,feature_matrix,chronological_mask
        with np.load(OLDART/'EXPERT_ERROR_LIBRARY.npz') as z:d={k:z[k] for k in z.files}
        with np.load(ART/'evaluation_renewables.npz') as z:ro=z['origins'];rx=z['features']
        data=gate.read(OLD/'DATA.json');dd=Path(data['directory']);sc=gate.read(dd/'scalers.json')
        scale=np.array(sc['price_scale'])[0,:,0];center=np.array(sc['price_center'])[0,:,0]
        features=np.load(dd/'features.npy',mmap_mode='r');node=d['node'];n=len(node)
        threshold=np.array(readiness['lowvolatility_thresholds']);protected=features[d['origins']-1,node,22]<=threshold[node]
        q=np.searchsorted(ro,d['origins']);assert np.array_equal(ro[q],d['origins'])
        sx=np.repeat(scale[node],12);v7=d['SPECIALIST'].reshape(-1);full=d['FULL'].reshape(-1)
        old_x=feature_matrix(np.repeat(d['context'],12,axis=0),np.repeat(d['duration'],12),np.tile(np.arange(1,13),n),d['probabilities'].reshape(-1,3),v7,full,sx)
        new_x=np.column_stack([old_x,rx[q].reshape(-1,5)])
        residual=(d['truth'].reshape(-1)-v7)/sx
        parent_end=stamp('2024-06-30T23:55Z')
        fold_records=[];arms={};weights={}
        for arm,x in [('old_features',old_x),('renewable_features',new_x)]:
            output=d['SPECIALIST'].copy();weight=np.zeros_like(output)
            for fi,(a,b) in enumerate(protocol['historical_pilot']['folds']):
                start,end=stamp(a+'T00:00Z'),stamp(b+'T00:00Z')
                fit=chronological_mask(d['issued'],d['issued']+3900,d['available'].max(1),parent_end,start)
                predict=(d['issued']>=start)&(d['issued']<end);ix=np.flatnonzero(predict)
                rows=np.flatnonzero(np.repeat(fit,12));pred_rows=(ix[:,None]*12+np.arange(12)).reshape(-1)
                model_path=ART/'pilot/models'/f'{arm}_{fi}.pkl';receipt=Q/f'fits/{arm}_{fi}.json'
                check(stage='fit',arm=arm,fold=fi+1,training_rows=len(rows),prediction_rows=len(pred_rows))
                if receipt.exists():
                    prior=gate.read(receipt);assert prior['status']=='fitted' and gate.sha(model_path)==prior['model_sha256'],'Incomplete fit requires explicit failure review'
                    with model_path.open('rb') as f:model=pickle.load(f)
                else:
                    ledger=gate.read(Q/'FIT_LEDGER.json') if (Q/'FIT_LEDGER.json').exists() else []
                    assert len(ledger)<8;ledger.append(dict(arm=arm,fold=fi,at=gate.now()));gate.write(Q/'FIT_LEDGER.json',ledger)
                    gate.write(receipt,dict(status='started',at=gate.now(),arm=arm,fold=fi))
                    t=time.monotonic();model=ConditionalRiskGate().fit(x[rows],residual[rows],
                        np.repeat(d['issued'],12)[rows],np.repeat(d['issued']+3900,12)[rows],
                        np.repeat(d['available'].max(1),12)[rows],np.full(len(rows),parent_end),start,confirmation_admitted=True)
                    atomic(model_path,lambda f:pickle.dump(model,f,protocol=5))
                    gate.write(receipt,dict(status='fitted',at=gate.now(),arm=arm,fold=fi,seconds=time.monotonic()-t,
                        training_rows=len(rows),training_dates=len(np.unique(d['issued'][fit]//86400)),
                        model=str(model_path),model_sha256=gate.sha(model_path),fit_scope='Past-only development rows; fresh source admission passed; no target release'))
                values=np.empty(len(pred_rows));ww=np.empty(len(pred_rows));changes=np.empty((len(pred_rows),2))
                for j in range(0,len(pred_rows),32):
                    rr=pred_rows[j:j+32];chunk=ART/'pilot/chunks'/f'{arm}_{fi}_{j:06d}.npz'
                    check(stage='predict',arm=arm,fold=fi+1,done=j,total=len(pred_rows))
                    if chunk.exists():
                        with np.load(chunk) as z:assert np.array_equal(z['rows'],rr);vv=z['prediction'];wg=z['weight'];ec=z['estimated_changes']
                    else:
                        vv,wg,ec=model.predict(x[rr],v7[rr],full[rr],sx[rr],np.ones(len(rr),bool),np.repeat(protected,12)[rr])
                        save(chunk,rows=rr,prediction=vv,weight=wg,estimated_changes=ec)
                    values[j:j+len(rr)]=vv;ww[j:j+len(rr)]=wg;changes[j:j+len(rr)]=ec
                output[ix]=values.reshape(-1,12);weight[ix]=ww.reshape(-1,12)
                fold_records.append(dict(arm=arm,start=a,end=b,training_pairs=int(fit.sum()),prediction_pairs=len(ix),
                    changed_cells=int(np.count_nonzero(ww)),maximum_weight=float(ww.max(initial=0)),
                    estimated_MAE_increases=int((changes[:,0]>1e-8).sum()),estimated_MSE_increases=int((changes[:,1]>1e-8).sum())))
                save(ART/'pilot/folds'/f'{arm}_{fi}.npz',library_rows=ix,prediction=output[ix],weight=weight[ix])
                print('Completed',arm,a,'changed cells',int(np.count_nonzero(ww)),flush=True)
                del model
            arms[arm]=output;weights[arm]=weight
        check(stage='complete_panel_scoring')
        times=np.load(data['timestamps'],mmap_mode='r');raw=np.load(data['raw_prices'],mmap_mode='r')
        with np.load(OLDART/'PREDICTIONS.npz') as z:
            all_origins=z['origins'];issue=times[all_origins-1]
            selected=(issue>=stamp('2024-09-01T00:00Z'))&(issue<stamp('2025-01-01T00:00Z'))
            origins=all_origins[selected];pfull=z['FULL'][selected];parent=z['SPIKE_ARM'][selected]
        truth=np.stack([raw[o:o+12,:,0].T for o in origins]).astype(float)
        from compile_math import group_codes
        last=np.asarray(raw[origins-1,:,0]);states=group_codes(truth,last,center,np.array(gate.read(dd/'state_thresholds.json')['thresholds']))
        low=features[origins-1,:,22]<=threshold;days=times[origins-1]//86400
        libmask=np.isin(d['origins'],origins);libindex=np.flatnonzero(libmask);oi=np.searchsorted(origins,d['origins'][libmask]);nn=node[libmask]
        observed_extreme=np.abs(last-center)>np.array(gate.read(dd/'state_thresholds.json')['thresholds'])[1]
        allpred={'FULL':pfull,'PARENT_SPECIALIST':parent}
        for arm,values in arms.items():
            forecast=parent.copy();forecast[oi,nn]=values[libindex];allpred[arm]=forecast
            unchanged=~observed_extreme|low
            assert np.array_equal(forecast[unchanged],parent[unchanged]),'Protected domain changed'
        predictions=ART/'pilot/PREDICTIONS.npz'
        save(predictions,origins=origins,**allpred)
        ms={name:metrics(p,truth,states,low,days) for name,p in allpred.items()}
        decisions={};base=flat_metrics(ms['FULL']);pm=flat_metrics(ms['PARENT_SPECIALIST'])
        positive=[k for k in base if base[k] is not None and pm[k]<base[k]]
        for arm in arms:
            am=flat_metrics(ms[arm]);lost=[k for k in positive if am[k]>=base[k]]
            core=['overall/mae','overall/rmse','near/mae','h12/mae']
            core_regression=[k for k in core if am[k]>pm[k]+1e-10]
            s3=am['by_state/3/rmse'] is not None and am['by_state/3/rmse']<pm['by_state/3/rmse']
            supported=bool(np.count_nonzero(weights[arm]))
            passed=supported and s3 and not lost and not core_regression
            decisions[arm]=dict(nonzero_supported_correction=supported,prior_positive_directions=len(positive),lost_positive_directions=lost,
                aggregate_regressions=core_regression,S3_RMSE_improved=s3,pilot_passed=passed,
                note='These are one-prefix development directions; not the83retained H1V7 gates or independent test results')
        duration=USED+time.monotonic()-START
        result=dict(at=gate.now(),status='eight_fixed_fits_complete_pending_arithmetic_audit',scope='Previously inspected2024Sep-Dec; one earlier-only prefix seed20260813',
            origins=len(origins),dates=len(np.unique(days)),nodes=30,horizons=12,fits=len(gate.read(Q/'FIT_LEDGER.json')),seconds=duration,
            folds=fold_records,metrics=ms,decisions=decisions,predictions=str(predictions),predictions_sha256=gate.sha(predictions),
            readiness_sha256=gate.sha(HERE/'PILOT_READINESS.json'),implementation_freeze_sha256=gate.sha(Q/'IMPLEMENTATION_FREEZE.json'),
            new_independent_test_targets_read=False,retained_V7_unchanged=True,comprehensive_improvement_established=False)
        gate.write(Q/'RESULT.json',result)
        # Independent reduction order: scalar sums with long-double accumulation.
        checks=0;maxdiff=0.
        with np.load(predictions) as z:
            assert np.array_equal(z['origins'],origins)
            for name in allpred:
                err=z[name]-truth
                groups=[('overall',err),('near',err[:,:,:4]),('h12',err[:,:,-1]),('lowvol',err[np.broadcast_to(low[:,:,None],err.shape)])]
                groups += [('by_state/'+str(s),err[states==s]) for s in range(6)]
                groups += [('by_node/'+str(n),err[:,n,:]) for n in range(30)]
                groups += [('by_horizon/'+str(h),err[:,:,h]) for h in range(12)]
                flat=flat_metrics(ms[name])
                for key,e in groups:
                    if not e.size:assert flat[key+'/mae'] is None;continue
                    ae=float(np.sum(np.abs(e),dtype=np.longdouble)/e.size)
                    se=float(np.sqrt(np.sum(e.astype(np.longdouble)**2)/e.size))
                    for metric,val in [('mae',ae),('rmse',se)]:
                        diff=abs(val-flat[key+'/'+metric]);maxdiff=max(maxdiff,diff);assert diff<1e-9;checks+=1
        for p,h in protocol['evidence_bindings'].items():assert gate.sha(p)==h,p
        gate.write(Q/'AUDIT.json',dict(at=gate.now(),status='passed_separate_reduction_and_frozen_parent_checks',
            arithmetic_checks=checks,max_absolute_discrepancy=maxdiff,operator='same operator, separate scalar reduction; not external certification',
            result_sha256=gate.sha(Q/'RESULT.json'),prediction_sha256=gate.sha(predictions),retained_V7_bindings_unchanged=True,
            protected_domains_identical=True,independent_test_targets_read=False))
        check(stage='audited_completion')
        gate.write(Q/'completion.json',dict(at=gate.now(),status='bounded_pilot_completed_and_audited',
            result=str(Q/'RESULT.json'),result_sha256=gate.sha(Q/'RESULT.json'),audit_sha256=gate.sha(Q/'AUDIT.json'),
            any_arm_passed=any(v['pilot_passed'] for v in decisions.values()),complete_research_experiment=False,
            next_action='Review matched incremental gain and deployment loss-library compatibility before any confirmation' if any(v['pilot_passed'] for v in decisions.values()) else 'Close this registered candidate; retain all outcomes and diagnose before any further authorized design'))
        emit('audited_result_ready' if any(v['pilot_passed'] for v in decisions.values()) else 'unexpected_result',Q/'completion.json')
if __name__=='__main__':
    try:main()
    except BaseException as e:
        failure=dict(at=gate.now(),status='stopped_without_promotion',type=type(e).__name__,error=str(e),traceback=traceback.format_exc(),new_test_targets_read=False)
        gate.write(Q/'FAILURE.json',failure)
        if isinstance(e,InterruptedError):gate.write(Q/'status.json',dict(at=gate.now(),pid=os.getpid(),event='user_stop_at_stage_boundary',classification='user_stop'))
        else:emit('blocking_failure',Q/'FAILURE.json')
        raise
