"""Post-result diagnosis only: inspect existing median corrections and their cap.

No fit, alternative candidate scoring, threshold selection, or test data access.
"""
import pilot as p
from pilot import *

def main():
    guard(True)
    verify()
    assert c.read(P / 'AUDIT.json')['status'] == 'passed'
    names = ['PROTOCOL.json', 'RESULT.json', 'AUDIT.json', 'ERROR_DECOMPOSITION.json']
    before = {str(P / n): c.sha(P / n) for n in names}
    write('CAP_DIAGNOSIS_PLAN.json', dict(at=c.now(), status='registered_before_diagnostic',
        purpose='Distinguish cap binding from small learned conditional median on evaluated development cells.',
        scope='All original states, all three windows and seeds; descriptive only.',
        new_fits=0, alternative_predictions_scored=False, future_state_used_for_routing=False,
        no_model_selection=True, bindings=before))
    windows = c.read(H / 'WINDOWS.json')
    rows = []
    with c.numeric('Existing-output cap diagnosis; no fits or candidate changes'):
        for seed in c.SEEDS:
            with np.load(P / 'evaluated' / f'A_{seed}.npz') as z:
                base = {k: z[k] for k in ['point', 'window', 'origin', 'h', 'state', 'days']}
            with np.load(P / 'evaluated' / f'D_{seed}.npz') as z:
                delta = z['point'] - base['point']
            raw_parts, cap_parts = [], []
            for w in windows['windows']:
                guard()
                out = P / 'fits' / f"w{w['id']}_{seed}_new"
                ck = c.read(out / 'COMPLETE.json')
                assert c.sha(out / 'raw.npz') == ck['prediction_sha256']
                ids = np.array(w['evaluation'], dtype=int)
                flat = np.sort((ids[:, None] * 360 + np.arange(360)[None, :]).ravel())
                m = base['window'] == w['id']
                expected_origins = np.repeat(np.array(windows['origins'])[np.sort(ids)], 360)
                assert np.array_equal(expected_origins, base['origin'][m])
                with np.load(out / 'raw.npz') as z:
                    med = np.sort(z['q'][flat], axis=1)[:, MID]
                with np.load(out / 'transforms.npz') as z:
                    cap = z['cap'][base['h'][m]]
                assert len(med) == int(m.sum())
                raw_parts.append(med)
                cap_parts.append(cap)
            med, cap = np.concatenate(raw_parts), np.concatenate(cap_parts)
            allowed = base['h'] >= 4
            bound = (np.abs(med) > cap) & allowed
            ratio = np.abs(med) / cap
            parts = [('overall', np.ones(len(med), dtype=bool))]
            parts += [(f'window{w}', base['window'] == w) for w in [1, 2, 3]]
            parts += [(f'S{s}', base['state'] == s) for s in range(6)]
            parts += [(f'H{h+1}', base['h'] == h) for h in range(12)]
            for part, mask in parts:
                active = mask & allowed
                rows.append(dict(seed=seed, part=part, cells=int(mask.sum()), eligible_cells=int(active.sum()),
                    capped_cells=int((bound & mask).sum()),
                    capped_fraction_of_eligible=float(bound[active].mean()) if active.any() else None,
                    median_to_cap_max=float(ratio[active].max()) if active.any() else None,
                    mean_absolute_currency_correction_all_cells=float(abs(delta[mask]).mean()),
                    mean_signed_currency_correction_all_cells=float(delta[mask].mean()),
                    mean_absolute_currency_correction_eligible=float(abs(delta[active]).mean()) if active.any() else None))
        for path, expected in before.items():
            assert c.sha(path) == expected
        assert c.verify_protected() == 18
    totals = []
    for part in sorted(set(r['part'] for r in rows)):
        rr = [r for r in rows if r['part'] == part]
        assert len(rr) == 3
        vals = dict(part=part, cells=rr[0]['cells'], eligible_cells=rr[0]['eligible_cells'],
            capped_cells_across_seeds=sum(r['capped_cells'] for r in rr))
        for key in rr[0]:
            if key not in ['seed', 'part', 'cells', 'eligible_cells', 'capped_cells']:
                vv = [r[key] for r in rr if r[key] is not None]
                vals[key] = (float(max(vv)) if key.endswith('_max') else float(np.mean(vv))) if vv else None
        totals.append(vals)
    write('CAP_DIAGNOSIS.json', dict(at=c.now(), status='passed', new_fits=0, V7_replaced=False,
        type='Post-result descriptive diagnosis; no causal inference or alternative candidate selection',
        all_original_evaluation_groups_retained=True, records=rows, seed_summary=totals,
        prior_artifacts_unchanged=True, protected_files_unchanged=18, new_test_targets_read=False))
    print(json.dumps([r for r in totals if r['part'] in ['overall', 'S1', 'S2', 'S3', 'S4', 'S5']], indent=2))

if __name__ == '__main__':
    main()
