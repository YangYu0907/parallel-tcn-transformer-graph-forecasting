"""Matched natural-frequency support expansion. Two fits; no V7 intervention."""
import support as s
import os,time,json,traceback,gc,pickle,hashlib
import numpy as np
from scipy.optimize import minimize_scalar
from sklearn.ensemble import HistGradientBoostingClassifier
from sklearn.metrics import average_precision_score

def dump(path,obj):
    path=s.N/path;path.parent.mkdir(exist_ok=True);tmp=path.with_suffix('.tmp')
    with tmp.open('wb') as f:pickle.dump(obj,f,protocol=5)
    os.replace(tmp,path)
def status(**kw):s.write('STATUS.json',dict(at=s.now(),pid=os.getpid(),**kw))
def emit(event,path):
    h=s.sha(path);eid='sc_'+h[:32];p=s.B/'event_driven_automation/inbox'/(eid+'.json')
    if not p.exists():
        tmp=p.with_suffix('.tmp');tmp.write_text(json.dumps(dict(schema='caiso_research_event_v1',event_id=eid,event=event,evidence_path=str(path),evidence_sha256=h,at=s.now()),ensure_ascii=False),encoding='utf-8');os.replace(tmp,p)
    return eid
def temp(p,t):
    z=np.log(np.maximum(p,1e-12))/t;z-=z.max(1,keepdims=True);v=np.exp(z);return v/v.sum(1,keepdims=True)
def logscore(p,y):return float(-np.log(np.maximum(p[np.arange(len(y)),y],1e-12)).mean())

def features(price,o):
    raw=np.asarray(price[o[:,None]-np.arange(36,0,-1),:,:],float)
    x=raw[:,:,:,0];last=x[:,-1,:];mean=x.mean(1);sd=x.std(1)
    lo=x.min(1);hi=x.max(1);median=np.median(x,axis=1)
    congestion=raw[:,:,:,2];c=congestion[:,-1,:]
    def spread(v):return v-np.median(v,axis=1)[:,None]
    market=np.median(last,axis=1)[:,None];disp=np.std(last,axis=1)[:,None]
    cc=np.mean(x[:,-12:,:],axis=1);mm=np.mean(x[:,:12,:],axis=1)
    #24 numeric features + categorical node. No future feature, fitted scaler, or qualification flag.
    vals=[last,mean,sd,lo,hi,median,last-x[:,-2,:],last-x[:,-4,:],last-x[:,-13,:],last-x[:,0,:],cc-mm,hi-lo,
        c,congestion.mean(1),congestion.std(1),c-congestion[:,-13,:],raw[:,-1,:,1],raw[:,-1,:,3],spread(last),spread(c),np.broadcast_to(market,last.shape),np.broadcast_to(disp,last.shape),last-median,(last-mean)/(sd+1)]
    return np.stack(vals+[np.broadcast_to(np.arange(30),last.shape)],axis=2)

def prepare(p,tick):
    source=s.read(p['source_protocol']);th=s.read(p['thresholds']);cen=np.array(th['center']);q=np.array(th['thresholds'])
    price=np.load(source['raw_prices'],mmap_mode='r')
    with np.load(p['population']) as z:o=z['origin'];cutoff=z['cutoff'];roles=z['role'];eligible=z['eligible']
    with np.load(p['old_population']) as z:old=z['origins'][z['eligible']]
    use=np.flatnonzero(eligible);all_o=o[use];roles=roles[use];cutoff=cutoff[use];oldmask=np.isin(all_o,old)
    total=0
    for begin in range(0,len(all_o),1024):
        oo=all_o[begin:begin+1024];x=np.asarray(price[oo-1,:,0],float);total+=int((abs(x-cen)<=q[0]).sum())
    xx=np.lib.format.open_memmap(s.N/'features.npy',mode='w+',dtype=np.float64,shape=(total,25))
    yy=np.lib.format.open_memmap(s.N/'labels.npy',mode='w+',dtype=np.int8,shape=(total,))
    role=np.lib.format.open_memmap(s.N/'role.npy',mode='w+',dtype=np.int8,shape=(total,))
    oldrows=np.lib.format.open_memmap(s.N/'old.npy',mode='w+',dtype=np.bool_,shape=(total,))
    times=np.lib.format.open_memmap(s.N/'times.npy',mode='w+',dtype=np.int64,shape=(total,))
    nodes=np.lib.format.open_memmap(s.N/'nodes.npy',mode='w+',dtype=np.int8,shape=(total,))
    k=0
    for begin in range(0,len(all_o),256):
        oo=all_o[begin:begin+256];hist=np.asarray(price[oo-1,:,0],float);normal=abs(hist-cen)<=q[0]
        f=np.asarray(price[oo[:,None]+np.arange(12),:,0],float).transpose(0,2,1)-cen[None,:,None]
        hit=abs(f)>q[1][None,:,None];at=hit.argmax(2);classes=np.where(hit.any(2),np.where(np.take_along_axis(f,at[:,:,None],axis=2)[:,:,0]>0,1,2),0)
        i,j=np.where(normal);size=len(i);x=features(price,oo);assert np.isfinite(x).all()
        xx[k:k+size]=x[i,j];yy[k:k+size]=classes[i,j];role[k:k+size]=roles[begin:begin+256][i];oldrows[k:k+size]=oldmask[begin:begin+256][i];times[k:k+size]=cutoff[begin:begin+256][i];nodes[k:k+size]=j;k+=size
        if begin%4096==0:tick(stage='features',origins=begin,total=len(all_o),pairs=k)
    assert k==total
    for item in [xx,yy,role,oldrows,times,nodes]:item.flush()
    del xx,yy,role,oldrows,times,nodes;gc.collect()
    yp=np.load(s.N/'labels.npy',mmap_mode='r');rp=np.load(s.N/'role.npy',mmap_mode='r');op=np.load(s.N/'old.npy',mmap_mode='r')
    support=s.read(p['support_result']);checks=[]
    for rec in support['rows']:
        if rec['population'] not in ['ALL_SHORT','COMMON_OLD']:continue
        mask=(rp==rec['role'])&(op if rec['population']=='COMMON_OLD' else True)
        actual=dict(pairs=int(mask.sum()),up=int(((yp==1)&mask).sum()),down=int(((yp==2)&mask).sum()))
        assert actual==dict(pairs=rec['pairs'],up=rec['up']['pairs'],down=rec['down']['pairs'])
        checks.append(dict(population=rec['population'],role=rec['role'],**actual))
    del yp,rp,op;gc.collect()
    s.write('DATA_COMPLETE.json',dict(at=s.now(),pairs=total,features=25,qualified_origins=len(all_o),support_reconciliation=checks,bindings={f:s.sha(s.N/f) for f in ['features.npy','labels.npy','role.npy','old.npy','times.npy','nodes.npy']}))

def predict(model,x,indices,tick):
    p=np.zeros((len(indices),3),float)
    for start in range(0,len(indices),16384):
        z=indices[start:start+16384];p[start:start+len(z)]=model.predict_proba(x[z])
        if start%131072==0:tick(stage='predict',done=start,total=len(indices))
    return p
def metrics(prob,y,thresholds):
    result={}
    for c,label in [(1,'up'),(2,'down')]:
        truth=y==c;v=np.clip(prob[:,c],1e-12,1-1e-12);alarm=v>thresholds[c-1]
        tp=int((alarm&truth).sum());fp=int((alarm&~truth).sum())
        result[label]=dict(brier=float(np.mean((v-truth)**2)),logloss=float(-np.where(truth,np.log(v),np.log1p(-v)).mean()),precision=tp/(tp+fp) if tp+fp else 0.,recall=tp/int(truth.sum()) if truth.any() else 0.,TP=tp,FP=fp,events=int(truth.sum()),FPR=fp/int((~truth).sum()),AP=float(average_precision_score(truth,v)) if truth.any() else None)
    return result

def run(p,tick):
    if not (s.N/'DATA_COMPLETE.json').exists():prepare(p,tick)
    for f,h in s.read(s.N/'DATA_COMPLETE.json')['bindings'].items():assert s.sha(s.N/f)==h
    arrays={f:np.load(s.N/(f+'.npy'),mmap_mode='r') for f in ['features','labels','role','old','times','nodes']}
    x=arrays['features'];y=arrays['labels'];role=arrays['role'];old=arrays['old']
    cal_old=np.flatnonzero((role==1)&old);cal_all=np.flatnonzero(role==1);evaluation=np.flatnonzero((role==2)&old)
    results={};predictions={};fit_counts={}
    for arm in ['OLD_SUPPORT','EXPANDED_SUPPORT']:
        train=np.flatnonzero((role==0)&(old if arm=='OLD_SUPPORT' else True));modelpath=s.N/'models'/(arm+'.pkl')
        if modelpath.exists():
            with modelpath.open('rb') as f:model=pickle.load(f)
        else:model=HistGradientBoostingClassifier(**p['learner'])
        fit_counts[arm]=dict(pairs=len(train),class_counts=np.bincount(y[train],minlength=3).tolist())
        tick(stage='fit_allocation',arm=arm,train_pairs=len(train));xt=x[train];yt=np.asarray(y[train]);s.guard()
        for it in [20,40,60,80]:
            if getattr(model,'n_iter_',0)>=it:continue
            tick(stage='fit',arm=arm,iterations=it);model.set_params(max_iter=it);model.fit(xt,yt);dump('models/'+arm+'.pkl',model)
            s.write('FIT_PROGRESS.json',dict(at=s.now(),arm=arm,completed_iterations=it,model_sha256=s.sha(modelpath)))
        del xt,yt;gc.collect();assert model.classes_.tolist()==[0,1,2]
        pc=predict(model,x,cal_all,tick);pe=predict(model,x,evaluation,tick);old_in_cal=old[cal_all]
        for calname,mask in [('OLD_CAL',old_in_cal)]+([('EXPANDED_CAL',np.ones(len(cal_all),bool))] if arm=='EXPANDED_SUPPORT' else []):
            yc=y[cal_all][mask];v=pc[mask]
            temperature=float(minimize_scalar(lambda t:logscore(temp(v,t),yc),bounds=(.5,2),method='bounded').x)
            cp=temp(v,temperature);ep=temp(pe,temperature)
            thresholds=[float(np.quantile(cp[yc!=c,c],.99,method='higher')) for c in [1,2]]
            name=arm+'_'+calname;results[name]=dict(temperature=temperature,calibration_pairs=len(yc),calibration_counts=np.bincount(yc,minlength=3).tolist(),thresholds=thresholds,metrics=metrics(ep,y[evaluation],thresholds));predictions[name]=ep
        del model,pc,pe;gc.collect()
    s.save('predictions.npz',y=np.asarray(y[evaluation]),time=np.asarray(arrays['times'][evaluation]),node=np.asarray(arrays['nodes'][evaluation]),**predictions)
    base=results['OLD_SUPPORT_OLD_CAL']['metrics'];candidate=results['EXPANDED_SUPPORT_EXPANDED_CAL']['metrics']
    passed=all(candidate[sign]['brier']<base[sign]['brier'] and candidate[sign]['logloss']<base[sign]['logloss'] and candidate[sign]['precision']>=base[sign]['precision'] and candidate[sign]['recall']>=base[sign]['recall'] and candidate[sign]['FPR']<=.02 for sign in ['up','down'])
    report=dict(at=s.now(),scope='Previously inspected TRAIN development; H12 first-entry detection, not endpoint price MAE/RMSE. All arms scored on identical old-qualified source-safe evaluation pairs.',model_fits=2,fit_counts=fit_counts,evaluation_pairs=len(evaluation),evaluation_dates=len(np.unique(arrays['times'][evaluation]//86400)),results=results,descriptive_gate_passed=passed,independent_scoring_pending=True,statistical_significance_not_yet_tested=True,V7_replaced=False,new_test_targets_read=False)
    s.write('RESULT_PENDING_AUDIT.json',report);return report

def main():
    lock=s.N/'MANAGER.lock'
    with lock.open('x') as f:json.dump(dict(pid=os.getpid()),f)
    start=time.monotonic()
    try:
        p=s.verify();s.guard(True);status(event='awaiting_exit_monitor_binding')
        while not (s.N/'START_READY.json').exists():
            if time.monotonic()-start>55:raise TimeoutError('Exit monitor missing')
            time.sleep(.2)
        import psutil
        ready=s.read(s.N/'START_READY.json');assert ready['manager_pid']==os.getpid() and psutil.pid_exists(ready['exit_monitor_pid'])
        def tick(**kw):
            s.guard()
            if time.monotonic()-start>p['maximum_seconds']:raise TimeoutError('Finite90minute budget reached; keep saved models, no automatic retry')
            s.write('PROGRESS.json',dict(at=s.now(),pid=os.getpid(),elapsed_seconds=time.monotonic()-start,**kw))
        status(event='step_process_started',stage='matched_support_training')
        with s.base.numeric('Two matched short-context hazard fits; expanded natural event support'):
            run(p,tick)
            for path,h in s.read(s.N/'PROTECTED_FILES.json').items():assert s.sha(path)==h
        eid=emit('needs_analysis',s.N/'RESULT_PENDING_AUDIT.json');status(event='finite_mechanism_queue_completed',event_id=eid,independent_scoring_pending=True)
    except InterruptedError as e:status(event='user_stop_before_launch',classification='user_stop',error=str(e))
    except BaseException as e:
        s.write('FAILURE.json',dict(at=s.now(),error=repr(e),traceback=traceback.format_exc(),automatic_retry=False));eid=emit('blocking_failure',s.N/'FAILURE.json');status(event='step_stopped_or_failed',event_id=eid,error=repr(e))
    finally:
        if lock.exists() and s.read(lock)['pid']==os.getpid():lock.unlink()
if __name__=='__main__':main()
