"""Separate saved-array arithmetic and exact selected-model replay; no training."""
import gc
import gate as g
import common as c


def main():
    g.verify();protocol=g.read(g.HERE/'PROTOCOL.json')
    with g.exclusive('residual_separate_numeric_audit'):
        limiter=c.init();np,torch=c.np,c.torch;d=c.data();limits=g.read(d.paths['context_limits.json'])['limits']
        import reductions as red
        expected_panel=c.panel(d);panels,_=red.panels(d.origins['june_dense'],d.origins['june'])
        checks=0;cases=[];reference_truth=None
        def core(e):
            flat=e.reshape(-1).astype(np.float64)
            if not flat.size:return dict(count=0,mae=None,rmse=None)
            return dict(count=int(flat.size),mae=float(np.sum(np.abs(flat),dtype=np.float64)/flat.size),rmse=float(np.sqrt(np.dot(flat,flat)/flat.size)))
        def compare(actual,expected):
            nonlocal checks
            for key,value in expected.items():
                if isinstance(value,dict):compare(actual[key],value)
                elif isinstance(value,list):
                    g.need(len(actual[key])==len(value),'Audit group length')
                    for a,b in zip(actual[key],value):compare(a,b)
                elif value is None:g.need(actual[key] is None,'Empty group mismatch');checks+=1
                else:g.need(np.isclose(actual[key],value,rtol=1e-11,atol=1e-10),f'Numerical mismatch {key}');checks+=1
        for seed in protocol['seeds']:
            for variant in protocol['variants']:
                run=g.HERE/'runs'/f'{seed}_{variant}';r=g.read(run/'completion.json')
                g.need(r['optimizer_updates']==2016 and [v['epoch'] for v in r['epochs']]==[0,1,2],'Wrong finite budget')
                selected=None;recomputed=[]
                for row in r['epochs']:
                    g.need(row['steps']==row['epoch']*1008 and row['panel']==expected_panel,'Epoch scope')
                    g.need(g.sha(row['evaluation'])==row['evaluation_sha256'] and g.sha(row['checkpoint']['path'])==row['checkpoint']['sha256'],'Artifact hash')
                    with np.load(row['evaluation'],allow_pickle=False) as z:
                        origins=z['origins'];pred=z['prediction'];truth=z['truth'];codes=z['codes']
                        g.need(np.array_equal(origins,d.origins['june_dense']),'Origin identity')
                        if reference_truth is None:reference_truth=truth.copy()
                        g.need(np.array_equal(truth,reference_truth) and np.isfinite(pred).all(),'Truth or predictions invalid')
                        computed={}
                        for name,ix in panels.items():
                            e=(pred-truth)[ix];s=codes[ix];o=origins[ix];m=core(e)
                            m.update(near_h1_4_mae=core(e[:,:,:4])['mae'],h12_mae=core(e[:,:,11])['mae'],origins=len(ix),
                                by_horizon=[core(e[:,:,h]) for h in range(12)],by_node=[core(e[:,n,:]) for n in range(30)],
                                by_phase=[dict(phase=i,origins=int((o%12==i).sum()),**core(e[o%12==i])) for i in range(12)],
                                by_state=[dict(state=i,origins=int(np.any(s==i,axis=(1,2)).sum()),node_origins=int(np.any(s==i,axis=2).sum()),**core(e[s==i])) for i in range(6)])
                            compare(row['metrics'][name],m);computed[name]=m
                        compare(dict(mae=row['mae']),dict(mae=computed['June3397']['mae']))
                        if selected is None or computed['June3397']['mae']<selected['metrics']['June3397']['mae']-1e-6:
                            selected=dict(epoch=row['epoch'],metrics=computed,row=row)
                        recomputed.append(dict(epoch=row['epoch'],metrics=computed,beta=row['beta']))
                g.need(selected['epoch']==r['selected_epoch'],'Selected epoch mismatch')
                m=c.model(seed,variant,limits)
                zero=torch.load(r['epochs'][0]['checkpoint']['path'],map_location='cpu',weights_only=False)
                g.need(all(torch.equal(v,zero['model'][k]) for k,v in m.state_dict().items()),'Epoch0 differs from immutable parent')
                del zero
                cp=torch.load(r['selected_checkpoint']['path'],map_location='cpu',weights_only=False)
                m.load_state_dict(cp['model'],strict=True);m.eval();del cp
                dense=np.arange(3397);off=dense[~np.isin(dense,panels['June284'])]
                with np.load(r['evaluation'],allow_pickle=False) as z,torch.no_grad():
                    for ix in [panels['June284'][:4],off[:4]]:
                        g.guard();x,_=d.batch('june_dense',ix)
                        pred=m(torch.from_numpy(x))['prediction'].numpy().astype(np.float64)*d.scale[None,:,None]+d.center[None,:,None]
                        g.need(np.array_equal(pred,z['prediction'][ix]),'Exact selected replay mismatch');checks+=1
                out=dict(seed=seed,variant=variant,selected_epoch=selected['epoch'],epochs=recomputed,metrics=selected['metrics'],
                         completion=str(run/'completion.json'),completion_sha256=g.sha(run/'completion.json'),elapsed_seconds=r['elapsed_seconds'])
                cases.append(out);g.write(run/'audit.json',dict(status='passed',at=g.now(),completion_sha256=out['completion_sha256'],checks_cumulative=checks,exact_replayed_origins=8))
                del m;gc.collect()
        keys=['mae','rmse','near_h1_4_mae','h12_mae']
        means={v:{panel:{k:float(np.mean([r['metrics'][panel][k] for r in cases if r['variant']==v])) for k in keys} for panel in panels} for v in protocol['variants']}
        parent_means={panel:{k:float(np.mean([r['epochs'][0]['metrics'][panel][k] for r in cases if r['variant']=='FULL_CONT'])) for k in keys} for panel in panels}
        wins=sum(next(r for r in cases if r['seed']==s and r['variant']=='RESIDUAL')['metrics']['June3397']['mae']<next(r for r in cases if r['seed']==s and r['variant']=='FULL_CONT')['metrics']['June3397']['mae'] for s in protocol['seeds'])
        protected=all(means['RESIDUAL'][panel][k]<=parent_means[panel][k]+1e-8 for panel in ['June3397','June284'] for k in keys)
        better=all(means['RESIDUAL']['June3397']['mae']<means[v]['June3397']['mae'] for v in ['FULL_CONT','CONCAT_CONT'])
        candidate=bool(better and wins>=2 and protected)
        comparisons={v:{panel:{k:100*(means[v][panel][k]-means['RESIDUAL'][panel][k])/means[v][panel][k] for k in keys} for panel in panels} for v in ['FULL_CONT','CONCAT_CONT']}
        g.write(g.HERE/'RESULT.json',dict(status='finite_residual_trial_audited',at=g.now(),cases=cases,means=means,parent_full_means=parent_means,
            residual_improvement_percent=comparisons,seed_wins_vs_full_cont=wins,headline_protection=protected,
            exploratory_promotion_gate_passed=candidate,new_independent_test_completed=False,
            interpretation='Development selection only; full positive and negative directions retained. This experiment cannot establish a dynamic-graph advantage.',
            next='Close failed variant or freeze a successful exploratory candidate before source-admitted unused-period confirmation; no automatic grid/epoch extension.',
            training_updates=9*2016,new_test_targets_read=False,original63_cases_unchanged=True,complete_research_experiment=False))
        g.write(g.HERE/'AUDIT.json',dict(status='passed',at=g.now(),cases=9,epochs_scored=27,checks=checks,exact_replayed_origins=72,
            scope='Separate arithmetic and checkpoint replay by the same operator; no independent human review claimed.',result_sha256=g.sha(g.HERE/'RESULT.json')))
        print('Audit passed',checks,'checks; exploratory gate',candidate,flush=True)


if __name__=='__main__':main()
