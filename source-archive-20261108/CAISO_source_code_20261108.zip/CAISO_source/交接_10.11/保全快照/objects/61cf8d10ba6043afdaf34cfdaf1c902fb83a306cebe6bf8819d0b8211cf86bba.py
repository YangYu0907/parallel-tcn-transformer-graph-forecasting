"""V25: one chronological probability-pooling candidate; no price-model writer."""
from pathlib import Path
import sys, os, json, uuid, time, shutil, importlib.util

HERE = Path(__file__).resolve().parent
B = HERE.parent
ART = Path('C:/Users/于阳/CAISO_temporary_storage') / HERE.name
V24 = B / 'support_capacity_v24_20261001'
sys.path.insert(0, str(B / 'probability_contract_v23_20261001'))
# Resolve the parent by an explicit module name rather than importing ourselves.
spec = importlib.util.spec_from_file_location('v25_parent_contract', B/'probability_contract_v23_20261001/common.py')
old = importlib.util.module_from_spec(spec)
spec.loader.exec_module(old)
gate, read, sha, now = old.gate, old.read, old.sha, old.now


def atomic(path, writer):
    path = Path(path)
    assert any(path.resolve().is_relative_to(r.resolve()) for r in (HERE, ART))
    path.parent.mkdir(parents=True, exist_ok=True)
    temp = path.with_name('.' + path.name + '.' + uuid.uuid4().hex + '.tmp')
    with temp.open('xb') as f:
        writer(f)
        f.flush()
        os.fsync(f.fileno())
    os.replace(temp, path)


def write(path, obj):
    raw = json.dumps(obj, ensure_ascii=False, indent=2, allow_nan=False).encode('utf-8')
    atomic(path, lambda f: f.write(raw))


def check(launch=False):
    for name in ('STOP_REQUESTED', 'STOP_REQUESTED.json'):
        if (HERE/name).exists():
            raise InterruptedError('Local user stop')
    gate.guard(launch)
    ART.mkdir(parents=True, exist_ok=True)
    assert shutil.disk_usage(HERE).free > 32*2**20, 'F metadata reserve'
    assert shutil.disk_usage(ART).free > (2 if launch else 1)*2**30, 'C numerical reserve'


def protected():
    return old.preserved()


def verify():
    for path, digest in read(HERE/'SEAL.json')['bindings'].items():
        assert sha(path) == digest, path
    gate.boundary()
    return read(HERE/'PROTOCOL.json')


def fit_weight(labels, probability, prior, np):
    """Exact empirical Brier minimizer on CALIBRATION only, no grid."""
    displacement = probability - prior
    denominator = float(np.square(displacement).sum())
    numerator = float(((np.eye(3)[labels] - prior) * displacement).sum())
    value = 0.0 if denominator <= 1e-15 else float(np.clip(numerator / denominator, 0., 1.))
    return value, numerator, denominator


def predict(weight, probability, prior):
    return prior + weight * (probability - prior)


def metrics(y, prob, issued, np):
    hot = np.eye(3)[y]
    brier = np.square(prob-hot).sum(-1)
    logloss = -np.log(np.clip(np.take_along_axis(prob,y[...,None],-1)[...,0],1e-12,None))
    dates = np.broadcast_to((issued//86400)[:,None],y.shape)
    def row(mask):
        n = int(mask.sum())
        return dict(cells=n, dates=len(np.unique(dates[mask])), brier=float(brier[mask].mean()) if n else None,
                    logloss=float(logloss[mask].mean()) if n else None)
    return dict(brier=float(brier.mean()),logloss=float(logloss.mean()),pairs=len(y),cells=int(y.size),
                dates=len(np.unique(issued//86400)),
                states=[dict(state=k+3,**row(y==k)) for k in range(3)],
                horizons=[dict(h=h+1,brier=float(brier[:,h].mean()),logloss=float(logloss[:,h].mean())) for h in range(12)])


def paired_inference(y, probs, issued, np):
    ids, block = np.unique(issued//604800,return_inverse=True)
    counts = np.bincount(block)*12
    hot = np.eye(3)[y]
    loss = {a:np.square(p-hot).sum(-1) for a,p in probs.items()}
    draws = np.random.default_rng(20260813).integers(len(ids),size=(2000,len(ids)))
    rows = []
    for arm in ('RICH_LARGE','PRICE_SMALL','PRIOR'):
        difference = loss[arm]-loss['ANCHORED']
        sums = np.bincount(block,weights=difference.sum(1))
        gain = float(difference.mean())
        boot = sums[draws].sum(1)/counts[draws].sum(1)
        rows.append(dict(comparator=arm,gain=gain,interval95=np.quantile(boot,[.025,.975]).tolist(),
                         p=float((1+(np.abs(boot-gain)>=abs(gain)).sum())/2001)))
    last = 0.
    for rank,j in enumerate(sorted(range(len(rows)),key=lambda k:rows[k]['p'])):
        last=max(last,min(1.,(len(rows)-rank)*rows[j]['p']))
        rows[j]['holm_p']=last
    return dict(real_week_blocks=len(ids),replicates=2000,comparisons=rows)


def admissible_interval(y, probability, prior, reference, np):
    """CAL-only algebraic feasibility diagnostic; never selects the candidate."""
    lo,hi=0.,1.
    rows=[]
    for k in range(3):
        mask=y==k
        if not mask.any():
            rows.append(dict(state=k+3,interval=None,reason='no calibration support'))
            return dict(interval=None,states=rows)
        delta=(probability-prior)[mask]
        err=(prior-np.eye(3)[y])[mask]
        referr=(reference-np.eye(3)[y])[mask]
        a=float(np.square(delta).sum(-1).mean())
        b=float(2*(delta*err).sum(-1).mean())
        cc=float(np.square(err).sum(-1).mean()-np.square(referr).sum(-1).mean())
        if a<=1e-15:
            if abs(b)<=1e-15:
                interval=[0.,1.] if cc<=1e-12 else None
            elif b>0:
                interval=[0.,min(1.,-cc/b)] if -cc/b>=0 else None
            else:
                interval=[max(0.,-cc/b),1.] if -cc/b<=1 else None
        else:
            disc=b*b-4*a*cc
            if disc<0:
                interval=None
            else:
                root=float(np.sqrt(disc))
                lower,upper=max(0.,(-b-root)/(2*a)),min(1.,(-b+root)/(2*a))
                interval=[lower,upper] if lower<=upper else None
        rows.append(dict(state=k+3,quadratic=[a,b,cc],interval=interval))
        if interval is None:
            hi=-1.
        else:
            lo,hi=max(lo,interval[0]),min(hi,interval[1])
    return dict(interval=[lo,hi] if lo<=hi else None,states=rows)


def register():
    assert not (HERE/'PROTOCOL.json').exists(), 'Already registered; do not overwrite'
    gate.boundary()
    result=read(V24/'RESULT.json');audit=read(V24/'AUDIT.json')
    assert audit['status']=='passed' and audit['result_sha256']==sha(V24/'RESULT.json')
    assert sha(result['output'])==result['output_sha256']
    for path,digest in read(V24/'SEAL.json')['bindings'].items():
        assert sha(path)==digest, path
    for fold in result['folds']:
        assert sha(fold['replay'])==fold['replay_sha256']
        for info in fold['models'].values():
            assert sha(info['path'])==info['sha256']
    parent=read(V24/'PROTOCOL.json')
    p=dict(at=now(),status='registered_before_V25_coefficients_or_scores',
       authorization='User: 开始，尽快 after literature/code review. Execute priority-one probability reliability check, retain V7.',
       scope=parent['scope'],library=parent['library'],folds=parent['folds'],
       hypothesis='The audited price-only small classifier deviates from the historical state prior more than its transferable discrimination justifies. Test calibrated probability pooling, not a larger model or price-loss search.',
       candidate='ANCHORED: per-fold scalar lambda in[0,1]; p=prior+lambda*(PRICE_SMALL-prior). One common lambda for all nodes, origins and horizons within that fold. Predictions remain input-dependent through PRICE_SMALL; this is not a newly learned per-origin confidence gate.',
       coefficient='Closed-form minimizer of natural-cell multiclass Brier on the existing earlier CAL subset only: clip(sum((onehot-prior)*(model-prior))/sum((model-prior)^2),0,1). Zero denominator ->lambda0. No alpha grid, threshold, or choice from evaluation outcomes.',
       prior='Exactly V23/V24 per-horizon fit-only class frequency, add0.5 per class. Does not use CAL outcomes.',
       reuse='All classifiers, calibrated task temperatures, fit/cal/evaluation indices and feature selection frozen to V24 PRICE_SMALL. Temperatures and pooling coefficient both use CAL; CAL is fitting data, not an independent evaluation. No new classifier/neural fits.',
       arms=['ANCHORED','PRICE_SMALL','PRIOR','RICH_LARGE','FROZEN_V14'],
       matched_controls='PRICE_SMALL without pooling, same historical PRIOR, earlier rich classifier and frozen V14 diagnostic. These are probability controls, not the main-paper graph/fusion ablations.',
       diagnostics='Leave-one-calibration-date-out lambda sensitivity without choosing among them. Analytically compute intersection of CAL per-state Brier non-regression intervals against RICH_LARGE; diagnostic only, never changes lambda. All fold/state/horizon directions retained.',
       primary='Natural-cell multiclass Brier on four chronological 2024Sep-Dec forward evaluation folds; exploratory already-inspected development data.',
       secondary='Logloss; h1 exit-probability AUC; allS3/S4/S5conditional Brier/logloss; allhorizons/months; calendar-date support.',
       inference='2000 paired real7day-block bootstrap, retaining gaps; ANCHORED vsRICH_LARGE/PRICE_SMALL/PRIOR three-comparison Holm family. No reinterpretation as fresh confirmation.',
       screen='Pooled Brier and logloss improve over both RICH_LARGE and PRIOR; Brier below RICH in>=3/4months; h1AUC>=RICH; everyS3/S4/S5conditional Brier<=RICH; each evaluated state>=5dates; each CAL state>=2dates and totalCAL>=5dates; lower95percent Brier gain bound vsRICH>0. Gate permits only separately checked price-retention work, not promotion. Empty/unsupported states do not pass.',
       interpretation='Conditional-on-outcome Brier tradeoffs are not automatically price-error regressions. Failure means current probability retention gate is unmet, not that every price forecast would worsen.',
       stop='One candidate only. No coefficient changes after forward scoring. Failed screen closes this route. V7/core/checkpoints/manuscript unchanged. No new independent targets. No automatic price integration.',
       maximum_seconds=300,maximum_new_classifier_fits=0,maximum_pooling_coefficients=4,
       resources=dict(single_numeric_worker=True,threads=1,launch_GiB=5,runtime_GiB=4,numeric_artifacts='authorized C temporary storage',metadata='F project'),
       theory=[dict(url='https://arxiv.org/abs/1106.1638',supports='Gneiting/Ranjan: predictive-distribution combination and joint calibration/dispersion evaluation; pooling is not automatically calibrated or dominant.'),
               dict(url='https://doi.org/10.1198/016214506000001437',supports='Proper probability scoring; the Brier-optimal scalar above follows by elementary differentiation and is a study-specific implementation.'),
               dict(url='https://jmlr.org/papers/v11/cawley10a.html',supports='Repeated development selection remains exploratory; no new independent performance claim.')],
       V7_unchanged=True,new_test_targets_read=False,price_predictions_changed=False)
    write(HERE/'PROTOCOL.json',p)
    paths=list(HERE.glob('*.py'))+[HERE/'PROTOCOL.json',V24/'RESULT.json',V24/'AUDIT.json',V24/'PROTOCOL.json',V24/'SEAL.json',Path(result['output']),Path(p['library']),
         B/'probability_contract_v23_20261001/common.py',B/'context_expert_v1_20260929/gate.py',B/'source/compile_gate.py']
    for fold in result['folds']:
        paths.append(Path(fold['replay']))
        paths += [Path(fold['models'][a+'_'+t]['path']) for a in ('PRICE_SMALL','RICH_LARGE') for t in ('hazard','postexit')]
    write(HERE/'SEAL.json',dict(at=now(),bindings={str(x):sha(x) for x in paths}))
    write(HERE/'status.json',dict(at=now(),status='prepared_resource_check_required',new_classifier_fits=0,protected_files_verified=protected()))
    print('V25 registered; four CAL-only coefficients; no classifier retraining.')


if __name__=='__main__':
    register()
