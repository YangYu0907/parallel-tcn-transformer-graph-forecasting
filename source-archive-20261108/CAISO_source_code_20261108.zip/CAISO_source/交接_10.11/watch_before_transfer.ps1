﻿param([switch]$SelfTest)
$ErrorActionPreference = 'Stop'
$root = Split-Path -Parent $PSScriptRoot
$queue = Join-Path $root 'post_backbone_queue_io_v2'
$records = Join-Path $PSScriptRoot 'dispatches'
$inbox = Join-Path $PSScriptRoot 'inbox'
$threadId = '01a08bcc-5e32-79d1-9d89-fcf19c30f204'
$pausePath = Join-Path (Split-Path -Parent $root) 'RESEARCH_PAUSED.json'
$codex = (Get-Command codex -CommandType Application -ErrorAction Stop).Source

function File-Sha($path) {
    $hash = [Security.Cryptography.SHA256]::Create()
    try { return [BitConverter]::ToString($hash.ComputeHash([IO.File]::ReadAllBytes($path))).Replace('-','').ToLower() }
    finally { $hash.Dispose() }
}
function Save-Json($path, $value) {
    $temp = $path + '.' + [guid]::NewGuid().ToString('N') + '.tmp'
    $value | ConvertTo-Json -Depth 12 | Set-Content -LiteralPath $temp -Encoding UTF8
    Move-Item -LiteralPath $temp -Destination $path -Force
}
function Read-Json($path) {
    for ($attempt = 0; $attempt -lt 5; $attempt++) {
        try { return Get-Content -LiteralPath $path -Raw -Encoding UTF8 | ConvertFrom-Json }
        catch { if ($attempt -eq 4) { throw }; Start-Sleep -Milliseconds 100 }
    }
}
function Is-Paused {
    if (Test-Path -LiteralPath $pausePath) {
        $pause = Read-Json $pausePath
        return ($pause.stop_preparation_and_training -eq $true)
    }
    return $false
}
function Decision($row, $origin) {
    if ($row.classification -eq 'user_stop') { return $null }
    if ($origin -eq 'queue') {
        switch ($row.event) {
            'finite_post_backbone_completed' { return 'queue_completed' }
            'step_stopped_or_failed' { return 'experiment_failed' }
            'post_backbone_stopped_with_preserved_state' {
                if ([string]$row.error -match 'STOP_REQUESTED|Research paused') { return $null }
                return 'manager_failed'
            }
            'waiting_for_resource_boundary' {
                if ($row.reason -eq 'waiting_for_physical_and_commit_headroom') { return 'resource_blocked' }
                return $null
            }
            'known_resource_guard_waiting_with_state_preserved' { return 'resource_blocked' }
            default { return $null }
        }
    }
    if ($origin -eq 'inbox' -and $row.schema -eq 'caiso_research_event_v1' -and $row.event_id) {
        if ($row.event -in @('audited_result_ready','major_milestone','unexpected_result','needs_analysis','blocking_failure','research_completed')) {
            return [string]$row.event
        }
    }
    if ($origin -eq 'process' -and $row.event -eq 'manager_exit_without_terminal_event') { return 'manager_failed' }
    return $null
}
function Event-Key($row, $origin, $kind) {
    if ($origin -eq 'inbox') { $value = 'inbox|' + [string]$row.event_id }
    elseif ($kind -eq 'queue_completed') { $value = 'queue_completed|' + [string]$row.completion_sha256 }
    elseif ($kind -eq 'resource_blocked') { $value = 'resource_blocked|' + [string]$row.step }
    else { $value = 'manager_terminal|' + [string]$row.pid }
    $hash = [System.Security.Cryptography.SHA256]::Create()
    try { return -join ($hash.ComputeHash([Text.Encoding]::UTF8.GetBytes($value)) | ForEach-Object { $_.ToString('x2') }) }
    finally { $hash.Dispose() }
}
function Dispatch($row, $origin, $source) {
    $kind = Decision $row $origin
    if (-not $kind -or (Is-Paused)) { return }
    $key = Event-Key $row $origin $kind
    $receipt = Join-Path $records ($key + '.json')
    if (Test-Path -LiteralPath $receipt) { return }
    $record = [ordered]@{
        event_id = $key; kind = $kind; source = $source
        at = [DateTime]::UtcNow.ToString('o'); status = 'dispatch_attempted'
        thread_id = $threadId; model_call_reason = 'actual_local_experiment_event'
    }
    Save-Json $receipt $record
    $message = @"
[CAISO 本地事件触发，非定时任务]
事件类型：$kind
证据文件：$source
事件编号：$key
请先读取 $root\HANDOFF.json、TASK_LOGIC_REVISION_20260920.json、TASK_EFFICIENCY_REVISION_20260926.json 和上述事件证据，核验真实进程、结果与独立审核。用户已取消所有定时模型唤醒；此消息仅由本地实验状态变化触发。不要创建定时提醒，不重复启动训练，不绕过资源保护或用户暂停。
重大进展主动简短汇报。新完成且可比的结果若不理想，要同时汇报关键数值、比较范围、事实与待检验原因，并给出原始文献支持的有限解决方案、收益代价和下一项匹配对照；按已授权范围推进，不等用户催促。同一事件不重复通知。不以单轮波动作为最终结论。
保留 TCN、Transformer、动态图 GNN、并行分支、自适应融合注意力全部要素。有限队列完成不代表全研究完成；继续共同面板评估、独立审核、必要的小幅改进及机制验证、冻结、数据准入和独立跨期验证。只在冻结及准入条件满足后读取测试目标，不用盲测调参，保留全部结果，正文润色暂缓。
完成当前处理后，为新的后台实验保留同样的本地事件触发方式：监听器在 event_driven_automation/watch.ps1；可向其 inbox 原子写入 schema=caiso_research_event_v1、唯一 event_id、event（audited_result_ready / major_milestone / unexpected_result / needs_analysis / blocking_failure / research_completed）及证据路径的 JSON，只在有真实新增证据时投递，不创建时间循环消息。新训练管理进程需更新退出监听，避免失去异常检测。全部研究完成后停止监听器。
"@
    try {
        $output = & $codex queue --thread $threadId --message $message 2>&1 | Out-String
        $code = $LASTEXITCODE
        $record['exit_code'] = $code
        $record['command_output'] = $output.Trim()
        $record['status'] = if ($code -eq 0) { 'queued_by_official_cli' } else { 'delivery_failed_no_automatic_retry' }
    } catch {
        $record['status'] = 'delivery_uncertain_no_automatic_retry'
        $record['error'] = $_.Exception.Message
    }
    Save-Json $receipt $record
    if ($record['status'] -ne 'queued_by_official_cli') {
        Save-Json (Join-Path $PSScriptRoot 'DELIVERY_FAILED.json') $record
    }
}

if ($SelfTest) {
    $checks = @(
        ((Decision ([pscustomobject]@{event='step_process_started'}) 'queue') -eq $null),
        ((Decision ([pscustomobject]@{event='step_completed'}) 'queue') -eq $null),
        ((Decision ([pscustomobject]@{event='step_stopped_or_failed';classification='user_stop'}) 'queue') -eq $null),
        ((Decision ([pscustomobject]@{event='post_backbone_stopped_with_preserved_state';error='RuntimeError: Research paused'}) 'queue') -eq $null),
        ((Decision ([pscustomobject]@{event='finite_post_backbone_completed'}) 'queue') -eq 'queue_completed'),
        ((Decision ([pscustomobject]@{event='step_stopped_or_failed';classification='unknown_or_QA_failure'}) 'queue') -eq 'experiment_failed'),
        ((Decision ([pscustomobject]@{event='waiting_for_resource_boundary';reason='shared_numerical_lock_occupied'}) 'queue') -eq $null),
        ((Decision ([pscustomobject]@{schema='caiso_research_event_v1';event_id='qa1';event='unexpected_result'}) 'inbox') -eq 'unexpected_result'),
        ((Event-Key ([pscustomobject]@{step='s1';at='a'}) 'queue' 'resource_blocked') -eq (Event-Key ([pscustomobject]@{step='s1';at='b'}) 'queue' 'resource_blocked'))
    )
    if ($checks -contains $false) { throw 'Event filtering QA failed' }
    [ordered]@{status='passed';checks=$checks.Count;model_calls=0;training_changes=0} | ConvertTo-Json
    exit 0
}

New-Item -ItemType Directory -Path $records,$inbox -Force | Out-Null
$mutex = [Threading.Mutex]::new($false, 'Local\CAISO_Research_Event_Watcher_01a08bcc')
if (-not $mutex.WaitOne(0)) { throw 'A CAISO event watcher is already running' }
$watchers = @()
$subscriptions = @()
$manager = $null
try {
    foreach ($spec in @(@{tag='queue';path=(Join-Path $queue 'events')}, @{tag='inbox';path=$inbox})) {
        $watcher = [IO.FileSystemWatcher]::new($spec.path, '*.json')
        $watcher.IncludeSubdirectories = $false
        $watcher.NotifyFilter = [IO.NotifyFilters]::FileName -bor [IO.NotifyFilters]::LastWrite
        $watcher.InternalBufferSize = 32768
        foreach ($eventName in @('Created','Changed','Renamed','Error')) {
            $subscription = Register-ObjectEvent -InputObject $watcher -EventName $eventName -SourceIdentifier ('CAISO.' + $spec.tag + '.' + $eventName)
            $subscriptions += $subscription
        }
        $watcher.EnableRaisingEvents = $true
        $watchers += $watcher
    }
    $state = Read-Json (Join-Path $queue 'status.json')
    if ($state.pid) {
        $processInfo = Get-CimInstance Win32_Process -Filter ("ProcessId = " + [int]$state.pid)
        if ($processInfo -and $processInfo.CommandLine.Contains((Join-Path $root 'source\post_backbone_queue.py'))) {
            $manager = Get-Process -Id ([int]$state.pid) -ErrorAction SilentlyContinue
            if ($manager) {
                $manager.EnableRaisingEvents = $true
                $subscriptions += Register-ObjectEvent -InputObject $manager -EventName Exited -SourceIdentifier 'CAISO.manager.Exited'
                if ($manager.HasExited) { New-Event -SourceIdentifier 'CAISO.manager.Exited' | Out-Null }
            }
        }
    }
    Save-Json (Join-Path $PSScriptRoot 'status.json') ([ordered]@{
        status='listening_for_os_events';pid=$PID;at=[DateTime]::UtcNow.ToString('o')
        manager_pid=$state.pid;periodic_model_calls=$false;timer=$false;thread_id=$threadId
        source_sha256=(File-Sha $PSCommandPath)
    })
    Dispatch $state 'queue' (Join-Path $queue 'status.json')
    if (-not $manager) { New-Event -SourceIdentifier 'CAISO.manager.Exited' | Out-Null }
    # Startup recovery handles pending explicit events once, never historical queue noise.
    Get-ChildItem -LiteralPath $inbox -Filter '*.json' -File | ForEach-Object {
        Dispatch (Read-Json $_.FullName) 'inbox' $_.FullName
    }
    while ($true) {
        $signal = Wait-Event
        try {
            if ($signal.SourceIdentifier -eq 'CAISO.manager.Exited') {
                $terminal = Read-Json (Join-Path $queue 'status.json')
                if ($terminal.classification -eq 'user_stop' -or [string]$terminal.error -match 'STOP_REQUESTED|Research paused') { continue }
                if (Decision $terminal 'queue') { Dispatch $terminal 'queue' (Join-Path $queue 'status.json') }
                elseif (-not (Is-Paused)) {
                    $terminal = [pscustomobject]@{event='manager_exit_without_terminal_event';pid=$state.pid;at=[DateTime]::UtcNow.ToString('o')}
                    $path = Join-Path $PSScriptRoot 'manager_exit.json'
                    Save-Json $path $terminal
                    Dispatch $terminal 'process' $path
                }
                continue
            }
            if ($signal.SourceIdentifier.EndsWith('.Error')) {
                $path = Join-Path $PSScriptRoot 'watcher_error.json'
                $row = [pscustomobject]@{schema='caiso_research_event_v1';event_id='watcher_error_' + $PID;event='blocking_failure';error=[string]$signal.SourceEventArgs.GetException()}
                Save-Json $path $row
                Dispatch $row 'inbox' $path
                throw 'OS event watcher error; inspect watcher_error.json'
            }
            $path = $signal.SourceEventArgs.FullPath
            if ([IO.Path]::GetExtension($path) -ne '.json' -or -not (Test-Path -LiteralPath $path)) { continue }
            $origin = if ($signal.SourceIdentifier.StartsWith('CAISO.queue.')) { 'queue' } else { 'inbox' }
            $row = Read-Json $path
            if ($origin -eq 'inbox' -and $row.schema -eq 'caiso_watcher_probe_v1') {
                Save-Json (Join-Path $PSScriptRoot 'probe_ack.json') ([ordered]@{probe_id=$row.probe_id;at=[DateTime]::UtcNow.ToString('o');pid=$PID;model_calls=0})
                continue
            }
            Dispatch $row $origin $path
        } finally { Remove-Event -EventIdentifier $signal.EventIdentifier -ErrorAction SilentlyContinue }
    }
} catch {
    Save-Json (Join-Path $PSScriptRoot 'watcher_failure.json') ([ordered]@{status='watcher_failed';at=[DateTime]::UtcNow.ToString('o');error=$_.Exception.Message;pid=$PID})
    throw
} finally {
    $subscriptions | ForEach-Object { Unregister-Event -SubscriptionId $_.SubscriptionId -ErrorAction SilentlyContinue }
    $watchers | ForEach-Object { $_.Dispose() }
    $mutex.ReleaseMutex()
    $mutex.Dispose()
}
