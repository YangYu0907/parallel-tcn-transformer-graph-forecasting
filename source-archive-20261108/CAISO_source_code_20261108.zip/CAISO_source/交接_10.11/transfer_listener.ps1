﻿param([Parameter(Mandatory=$true)][string]$DestinationThreadId)
$ErrorActionPreference = 'Stop'
$transferRoot = $PSScriptRoot
$archiveRoot = Split-Path -Parent $transferRoot
$branchRoot = Join-Path $archiveRoot '研究资料\CAISO_feature_fusion_rev12\asof_retraining_branch_20260913'
$eventRoot = Join-Path $branchRoot 'event_driven_automation'
$watchPath = Join-Path $eventRoot 'watch.ps1'
$report = Get-Content -LiteralPath (Join-Path $transferRoot 'PRESERVATION_CHECK.json') -Raw -Encoding UTF8 | ConvertFrom-Json
if ($report.status -ne 'passed') { throw 'Preservation not verified; do not transfer.' }
if ($DestinationThreadId -notmatch '^[a-zA-Z0-9-]+$') { throw 'Invalid thread id' }
$old = Get-Content -LiteralPath (Join-Path $eventRoot 'status.json') -Raw -Encoding UTF8 | ConvertFrom-Json
$proc = Get-CimInstance Win32_Process -Filter ('ProcessId = ' + [int]$old.pid)
if (-not $proc -or -not $proc.CommandLine.Contains($watchPath)) { throw 'Existing watcher identity does not match; inspect before any stop.' }
$oldTicks = $proc.CreationDate.ToUniversalTime().Ticks
$oldPid = [int]$old.pid
$text = [IO.File]::ReadAllText($watchPath)
$oldLine = '$threadId = ' + "'" + $old.thread_id + "'"
$newLine = '$threadId = ' + "'" + $DestinationThreadId + "'"
if (-not $text.Contains($oldLine)) { throw 'Watcher source and status target mismatch' }
$backup = Join-Path $transferRoot 'watch_before_transfer.ps1'
if (Test-Path -LiteralPath $backup) { throw 'Transfer already attempted; inspect receipt before retrying.' }
Copy-Item -LiteralPath $watchPath -Destination $backup
Copy-Item -LiteralPath (Join-Path $branchRoot 'HANDOFF.json') -Destination (Join-Path $transferRoot 'HANDOFF_before_transfer.json')
$receiptsBefore = @(Get-ChildItem -LiteralPath (Join-Path $eventRoot 'dispatches') -File -Filter '*.json').Count
$temp = $watchPath + '.' + [guid]::NewGuid().ToString('N') + '.tmp'
[IO.File]::WriteAllText($temp, $text.Replace($oldLine, $newLine), [Text.UTF8Encoding]::new($true))
Move-Item -LiteralPath $temp -Destination $watchPath -Force
$powershellPath = Join-Path $env:WINDIR 'System32\WindowsPowerShell\v1.0\powershell.exe'
& $powershellPath -NoProfile -ExecutionPolicy Bypass -File $watchPath -SelfTest
if ($LASTEXITCODE -ne 0) {
    Copy-Item -LiteralPath $backup -Destination $watchPath -Force
    throw 'SelfTest failed; restored source and kept existing watcher'
}
$recheck = Get-CimInstance Win32_Process -Filter ('ProcessId = ' + $oldPid)
if (-not $recheck -or $recheck.CreationDate.ToUniversalTime().Ticks -ne $oldTicks -or -not $recheck.CommandLine.Contains($watchPath)) { throw 'Watcher PID changed; no process stopped.' }
Stop-Process -Id $oldPid
$new = Start-Process -FilePath $powershellPath -ArgumentList @('-NoProfile','-ExecutionPolicy','Bypass','-File',('"' + $watchPath + '"')) -WindowStyle Hidden -PassThru -RedirectStandardOutput (Join-Path $transferRoot 'listener_stdout.log') -RedirectStandardError (Join-Path $transferRoot 'listener_stderr.log')
$state = $null
for($attempt=0;$attempt -lt 15;$attempt++) {
    Start-Sleep -Milliseconds 500
    if($new.HasExited){ throw 'New watcher exited; see listener logs.' }
    $state = Get-Content -LiteralPath (Join-Path $eventRoot 'status.json') -Raw -Encoding UTF8|ConvertFrom-Json
    if([int]$state.pid -eq $new.Id -and $state.thread_id -eq $DestinationThreadId){break}
}
if([int]$state.pid -ne $new.Id -or $state.thread_id -ne $DestinationThreadId){throw 'New watcher did not publish correct state'}
$probeId='handoff_1011_' + [guid]::NewGuid().ToString('N')
$probePath=Join-Path $eventRoot ('inbox\' + $probeId + '.json')
$probe=@{schema='caiso_watcher_probe_v1';probe_id=$probeId;model_calls=0}|ConvertTo-Json
[IO.File]::WriteAllText(($probePath + '.tmp'),$probe,[Text.UTF8Encoding]::new($false))
Move-Item -LiteralPath ($probePath + '.tmp') -Destination $probePath
$ack=$null
for($attempt=0;$attempt -lt 20;$attempt++) {
    Start-Sleep -Milliseconds 500
    $ackPath=Join-Path $eventRoot 'probe_ack.json'
    if(Test-Path -LiteralPath $ackPath){$ack=Get-Content -LiteralPath $ackPath -Raw -Encoding UTF8|ConvertFrom-Json}
    if($ack.probe_id -eq $probeId){break}
}
if($ack.probe_id -ne $probeId -or [int]$ack.pid -ne $new.Id){throw 'OS file event probe not acknowledged'}
$receiptsAfter=@(Get-ChildItem -LiteralPath (Join-Path $eventRoot 'dispatches') -File -Filter '*.json').Count
$live=Get-CimInstance Win32_Process -Filter ('ProcessId = ' + $new.Id)
$receipt=[ordered]@{
    status='passed';at=[DateTime]::UtcNow.ToString('o');old_thread_id=$old.thread_id;new_thread_id=$DestinationThreadId
    old_watcher_pid=$oldPid;new_watcher_pid=$new.Id;new_watcher_creation_utc_ticks=$live.CreationDate.ToUniversalTime().Ticks
    source_sha256=(Get-FileHash -LiteralPath $watchPath -Algorithm SHA256).Hash.ToLower()
    self_test_checks=9;os_event_probe=$ack;dispatch_receipts_before=$receiptsBefore;dispatch_receipts_after=$receiptsAfter
    dispatch_receipts_deleted=0;periodic_model_wakeups=$false;training_started=$false;whole_research_completed=$false
}
$receipt|ConvertTo-Json -Depth 8|Set-Content -LiteralPath (Join-Path $transferRoot 'LISTENER_TRANSFER.json') -Encoding UTF8
$receipt|ConvertTo-Json -Depth 8
