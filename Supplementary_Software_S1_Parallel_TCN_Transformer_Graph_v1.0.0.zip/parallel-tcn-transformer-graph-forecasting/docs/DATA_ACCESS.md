# Data access and temporal admission

## Public sources

- CAISO OASIS market data: https://oasis.caiso.com/
- European electricity-price benchmark: https://doi.org/10.5281/zenodo.4624805
- EPF toolbox dataset documentation: https://github.com/jeslago/epftoolbox

The compact supplement distributes processed results and source/admission manifests. It does not silently substitute current revised source values for historical first-publication vintages. Exact raw-vintage reproduction requires the admitted archive identified by the manifests; a newly downloaded historical series alone may not recover the original release timestamps or revisions.

## Required arrays for a complete rerun

CAISO expert inputs use 288 historical observations, 30 nodes, 29 historical fields, ten source fields (eight admitted values plus availability and age), twelve forecast steps and thirteen quantiles. The European adapter uses 168 observations, three nodes, four local historical fields, 24 forecast steps and the same thirteen quantiles, with separately fitted scalers and parameters.

The recorded workflow expects `X.npy`, `SOURCE.npy`, `ORIGINS.npz`, `SCALERS.json`, role-specific label archives, timestamps, source publication timestamps and source admission receipts. Roles are expert fitting, expert validation, expert calibration, risk fitting, risk selection and frozen chronological evaluation. Their precise recorded boundaries and counts are provided in the experiment protocol and manuscript Table 2.

Only source values whose publication timestamp plus 60 seconds does not exceed forecast issuance enter the CAISO source vector. Labels must meet the recorded 24-hour maturity separation from their fitting boundary. Retain source hashes, ordering, node identities and time-zone conventions. Public data retain their respective providers' terms; this package does not grant new rights over third-party data.
