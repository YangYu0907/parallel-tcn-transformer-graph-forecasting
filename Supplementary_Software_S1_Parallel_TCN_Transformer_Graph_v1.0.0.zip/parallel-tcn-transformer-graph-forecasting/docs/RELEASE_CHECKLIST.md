# Release record

- Software: Supplementary Software S1, version 1.0.0.
- Author approval for public publication: 2026-10-28.
- GitHub account: YangYu0907.
- Manuscript snapshot: identified by SHA-256 in `data/manifests/manuscript_source.json`.
- Verification: syntax checks, deterministic scientific arithmetic, file hashes, table exports and figure-data reproduction.
- The release does not retrain any model or change the frozen research results.
- Raw-vintage requirements and full-training reproduction instructions remain in `DATA_ACCESS.md` and `REPRODUCTION_LEVELS.md`.
- A final author list, DOI or software license may be added only from confirmed author metadata.
