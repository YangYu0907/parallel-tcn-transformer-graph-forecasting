# Rights and attribution

The authors retain rights to this research software; this release does not assign an open-source license. Third-party datasets and dependencies retain their original terms and citations. Reference implementations and methodological sources are cited in the associated manuscript bibliography. Source-data links are provided in `DATA_ACCESS.md`. The public archive contains processed research results and implementation records, not a new license for underlying third-party data.
