# Parallel TCN–Transformer graph forecasting

Supplementary Software S1 for **A parallel TCN–Transformer framework with adaptive graph learning for multi-location electricity price forecasting**.

Version 1.0.0 contains the scientific model implementation, archived training and evaluation workflows, processed manuscript data and figure-generation scripts. The chronological experiments distinguish information availability, history length and spatial aggregation while preserving the parallel temporal architecture.

## Quick start

Python 3.10 or later is required. Create a virtual environment, then run:

```bash
python -m pip install -r requirements-analysis.txt
python scripts/check_package.py
python tests/test_scientific_components.py
python scripts/reproduce_result_figures.py
```

These commands check archive integrity, test the mathematical components and recreate the result figures from recorded data. They do not retrain models or select parameters on evaluation data. The architecture illustration is supplied as editable SVG and draw.io files.

## Repository structure

| Location | Contents |
| --- | --- |
| `src/electricity_forecasting/` | Neural architecture, training loss, point decisions, temporal admission and statistical evaluation |
| `archived_workflows/` | Recorded neural, baseline, risk-policy, calibration and replay implementations |
| `configs/` | Recorded optimization and chronological experiment configuration |
| `data/processed/` | All 15 manuscript tables, numerical figure data and editable architecture illustration |
| `data/manifests/` | Data sources, publication-time admission, event census and manuscript mapping |
| `results/` | Frozen comparison results, uncertainty summaries and optimization records |
| `scripts/` | Integrity checks and figure reproduction |
| `tests/` | Deterministic checks of the scientific calculations |
| `docs/` | Data access, reproduction instructions and source attribution |

## Models and controls

The neural core includes a TCN branch, a Transformer branch, adaptive temporal fusion, dynamic/static/dense spatial aggregation and an ordered quantile decoder. The point-decision layer uses frozen candidate forecasts and calibration-derived decisions. Baseline and historical component workflows are retained under descriptive filenames. `SOURCE_PROVENANCE.json` maps them to the executed source records and their hashes.

## Data and reproduction

Processed research data and numerical results are included. Source-data access links and publication-time admission records are in `docs/DATA_ACCESS.md`. Large raw input arrays and trained checkpoints are not included in this compact archive. A complete training rerun requires the admitted input archive and the environment described in `docs/REPRODUCTION_LEVELS.md`; the archived orchestration scripts require their documented source mappings. The result-reproduction commands above are available independently of that archive.

The table CSV files preserve the final manuscript's cell text, including merged-header rows, units and uncertainty intervals. They are not new experimental estimates. Caption text is indexed in `data/manifests/manuscript_captions.json`.

## Citation and release

This is Supplementary Software S1, version 1.0.0, for the manuscript named above. Cite the associated manuscript and this software version. `CITATION.bib` records the software title, version and repository URL without inventing an author list or DOI.

Repository: https://github.com/YangYu0907/parallel-tcn-transformer-graph-forecasting

The authors retain software rights unless an explicit license is added. Third-party datasets and dependencies retain their original terms. See `docs/RIGHTS_AND_ATTRIBUTION.md`.
