# Recorded historical component workflow. See docs/REPRODUCTION_LEVELS.md.
from common21 import *
from scipy.optimize import minimize
def score(e):return float(abs(e).mean()+.5*np.sqrt((e*e).mean()))
def weights(xx,y):
 e=xx-y[:,None];K=xx.shape[1]
 def fun(w):return score(e@w)
 def jac(w):
  v=e@w;rm=np.sqrt(np.mean(v*v));return (e*np.sign(v)[:,None]).mean(0)+.5*(e*v[:,None]).mean(0)/max(rm,1e-12)
 res=minimize(fun,np.full(K,1/K),jac=jac,method='SLSQP',bounds=[(0.,1.)]*K,constraints={'type':'eq','fun':lambda w:w.sum()-1,'jac':lambda w:np.ones(K)},options={'maxiter':100,'ftol':1e-9})
 if not res.success:
  # Finite convex optimization can stop at a nonsmooth optimum. Preserve its
  # termination; only admit a feasible solution no worse than equal weights.
  pass
 w=np.maximum(res.x,0);w/=w.sum()
 if fun(w)>fun(np.full(K,1/K))+1e-8:w=np.full(K,1/K)
 return w,dict(success=bool(res.success),message=str(res.message),iterations=int(res.nit))
def run():
 data=load(E/'data/train_valid.npz',['raw','timestamps','valid']);raw=data['raw'];ev=data['valid'];days=data['timestamps'][ev].astype('datetime64[D]').astype(int)
 preds={k:[] for k in ['FULL','STATIC','SELF','JOINT_STATIC_SELF','EUROPE_JOINT_VALIDATED_GRAPH','PRIOR_NODE_STATIC_SELF']};records={};y=None;rs=None
 import node_graph as node19
 for seed in SEEDS:
  progress('Europe_joint_validation_graph',seed=seed);pt={};orig=None
  for name in ['FULL','STATIC','SELF']:
   a=load(PREV/f'Europe_TRAIN_{name}_{seed}.npz',['origins','prediction'])
   mask=data['timestamps'][a['origins']].astype('datetime64[Y]')==np.datetime64('2014')
   if orig is None:orig=a['origins'][mask]
   check('Europe_joint2014_origin',np.array_equal(orig,a['origins'][mask]));pt[name]=a['prediction'][mask]
  yt=raw[orig[:,None]+np.arange(24)].transpose(0,2,1);split=int(.8*len(orig));va=np.arange(len(orig))>=split;tr=orig+24+24<orig[split]
  feat=gd.history_features(raw,orig,24);threshold=np.quantile(feat[tr],.7,axis=0);risk=(feat>=threshold).all(1)
  pair=np.zeros((2,3,24,3));full=np.zeros_like(pair);gating=[]
  for s,n,h in itertools.product([0,1],range(3),range(24)):
   train=tr&(risk==s);validation=va&(risk==s);pooled=False
   if train.sum()<20:train=tr;pooled=True
   xx=np.column_stack([pt[k][train,n,h] for k in ['FULL','STATIC','SELF']]);yy=yt[train,n,h]
   wp,op=weights(xx[:,1:],yy);wf,of=weights(xx,yy);pair[s,n,h,1:]=wp;full[s,n,h]=pair[s,n,h]
   active=(s==1 or h>=18);admit=False;pm=pr=fm=fr=None
   if active and validation.sum()>=5:
    xv=np.column_stack([pt[k][validation,n,h] for k in ['FULL','STATIC','SELF']]);yv=yt[validation,n,h]
    ep=xv[:,1:]@wp-yv;ef=xv@wf-yv;pm=float(abs(ep).mean());pr=float(np.sqrt((ep*ep).mean()));fm=float(abs(ef).mean());fr=float(np.sqrt((ef*ef).mean()))
    admit=fm<pm and fr<pr and wf[0]>0
    if admit:full[s,n,h]=wf
   gating.append(dict(state=s,node=n,h=h,train=int(train.sum()),validation=int(validation.sum()),pooled_fit=pooled,active=active,admit=admit,pair_mae=pm,pair_rmse=pr,full_mae=fm,full_rmse=fr,pair_solver=op,full_solver=of))
  rec=dict(at=rt.now(),train_origins=len(orig),inner_fit=int(tr.sum()),inner_validation=int(va.sum()),threshold=threshold.tolist(),pair=pair.tolist(),triple=full.tolist(),decisions=gating,markets=['FR','DE','BE'],refit_after_validation=False,checkpoint_exposure='Base models trained on prior years including this internal validation; validation is meta-fit holdout only. 2015 checkpoint selection exposure remains.')
  records[str(seed)]=rec;write(D/f'EUROPE_{seed}_JOINT_WEIGHTS_FROZEN.json',rec)
  pe={}
  for name in ['FULL','STATIC','SELF']:
   a=load(E/f'runs/{name}_{seed}_0.001/validation_predictions.npz',['prediction','origins']);check('joint_eval_origins',np.array_equal(ev,a['origins']));pe[name]=a['prediction'].transpose(0,2,1)
  y=raw[ev[:,None]+np.arange(24)].transpose(0,2,1);rs=(gd.history_features(raw,ev,24)>=threshold).all(1)
  pe['JOINT_STATIC_SELF']=node19.predict(pe,rs,pair);pe['EUROPE_JOINT_VALIDATED_GRAPH']=node19.predict(pe,rs,full)
  old=read(P19/f'Europe_{seed}_NODE_WEIGHTS_FROZEN.json');oldrisk=(gd.history_features(raw,ev,24)>=np.asarray(old['threshold'])).all(1);pe['PRIOR_NODE_STATIC_SELF']=node19.predict(pe,oldrisk,np.asarray(old['pair']))
  mask=np.broadcast_to((~rs)[:,None,None]&(np.arange(24)<18)[None,None,:],y.shape)
  check('joint_inactive_exact_'+str(seed),np.array_equal(pe['EUROPE_JOINT_VALIDATED_GRAPH'][mask],pe['JOINT_STATIC_SELF'][mask]))
  for name,v in pe.items():preds[name].append(v)
  save21(f'Europe_{seed}_JOINT_GRAPH.npz',origins=ev,prediction=pe['EUROPE_JOINT_VALIDATED_GRAPH'],reference=pe['JOINT_STATIC_SELF'],high=rs)
 masks=dict(all=np.ones(y.shape,bool),high_q70=np.broadcast_to(rs[:,None,None],y.shape),far=np.broadcast_to((np.arange(24)>=18)[None,None,:],y.shape));masks['high_far']=masks['high_q70']&masks['far']
 for n,label in enumerate(['FR','DE','BE']):masks[label]=np.broadcast_to((np.arange(3)==n)[None,:,None],y.shape)
 sm,ae,se=summarize_points(preds,y,masks,days,'Europe');co=compare_points(ae,se,'EUROPE_JOINT_VALIDATED_GRAPH',['JOINT_STATIC_SELF','PRIOR_NODE_STATIC_SELF','STATIC','SELF'],masks,days,'Europe')
 write(D/'JOINT_GRAPH_RESULTS.json',dict(summary=sm,comparisons=co,records=records,high_eval_origins=int(rs.sum()),training_scope='1079 archived train predictions span2012-2014; only363 origins from2014 eligible. Internal80/20 chronological split with48-slot target+delay boundary.',not_independent=True))
