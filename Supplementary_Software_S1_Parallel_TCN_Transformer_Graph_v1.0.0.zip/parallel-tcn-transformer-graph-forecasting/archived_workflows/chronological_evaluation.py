# Recorded study workflow. See docs/REPRODUCTION_LEVELS.md before execution.
"""Historical forward scores after the complete three-seed policy freeze."""
from train_policy import *
SEEDS=[20260813,20260814,20260815]
def block_compare(y,p,r,days,mask):
 import numpy as np
 guard()
 # p/r are seed x cell. Average losses, not forecasts, before resampling dates.
 ae_p=abs(y[None]-p).mean(0);ae_r=abs(y[None]-r).mean(0);se_p=((y[None]-p)**2).mean(0);se_r=((y[None]-r)**2).mean(0)
 out={}
 for name,blocks in [('date',days),('seven_day',days//7)]:
  ud=np.unique(blocks[mask]);v=np.asarray([[np.sum(mask&(blocks==d)),ae_r[mask&(blocks==d)].sum(),ae_p[mask&(blocks==d)].sum(),se_r[mask&(blocks==d)].sum(),se_p[mask&(blocks==d)].sum()] for d in ud])
  if not len(v):out[name]=None;continue
  rng=np.random.default_rng(20261020);z=v[rng.integers(0,len(v),(2000,len(v)))].sum(1);a=(z[:,1]-z[:,2])/z[:,0];rm=np.sqrt(z[:,3]/z[:,0])-np.sqrt(z[:,4]/z[:,0])
  out[name]=dict(blocks=len(v),MAE_CI95=np.quantile(a,[.025,.975]).tolist(),RMSE_CI95=np.quantile(rm,[.025,.975]).tolist())
 out.update(MAE_improvement=float((ae_r-ae_p)[mask].mean()),RMSE_improvement=float(np.sqrt(se_r[mask].mean())-np.sqrt(se_p[mask].mean())),MAE_seed_wins=int(sum(np.mean(abs(y[mask]-p[s,mask]))<np.mean(abs(y[mask]-r[s,mask])) for s in range(len(p)))),RMSE_seed_wins=int(sum(np.mean((y[mask]-p[s,mask])**2)<np.mean((y[mask]-r[s,mask])**2) for s in range(len(p)))),replicates=2000,positive_means_candidate_better=True)
 return out
def scores(y,p,mask):
 import numpy as np
 err=y[None]-p
 return dict(cells=int(mask.sum()),MAE=float(abs(err[:,mask]).mean()),RMSE=float(np.sqrt((err[:,mask]**2).mean())))
def main():
 import numpy as np
 with locked('historical_forward_final_score'):
  sealcheck();seals={}
  for seed in SEEDS:
   seal=read(W/str(seed)/'POLICY_FREEZE.json')
   for p,h in seal['bindings'].items():assert sha(p)==h,p
   seals[seed]=seal
  # Complete model choices are committed for ALL seeds before opening scoring targets.
  freeze=dict(at=now(),policy_seals={str(s):sha(W/str(s)/'POLICY_FREEZE.json') for s in SEEDS},all_choices_fixed=True,P8_tuning=False)
  save(W/'ALL_MODELS_FROZEN_BEFORE_DEV.json',freeze)
  role='HISTORICAL_DEV_CHECK'
  with np.load(F/'ORIGINS.npz') as z:oo=z[role]
  root=Path(read('${DATA_ROOT}/CAISO_unified_forward_main_20261019/CAISO/PRETRAIN.json')['paths']['features.npy']).parent;times=np.load(root/'timestamps_seconds.npy',mmap_mode='r')
  save(W/'HISTORICAL_DEV_TARGET_ACCESS.json',dict(at=now(),freeze_sha=sha(W/'ALL_MODELS_FROZEN_BEFORE_DEV.json'),metadata_whitelist_sha=sha(T/'ROLE_ORIGINS.npz'),origins=len(oo),target_scope='Already admitted fixed2025Jan-Mar TRAIN development role. Previously viewed historical evidence, not independentblind.',P8_reads=0))
  raw=np.load(root/'raw_prices.npy',mmap_mode='r');y=np.empty((len(oo),30,12),np.float32);last=np.empty((len(oo),30),np.float32)
  for st in range(0,len(oo),128):
   guard();ii=oo[st:st+128];y[st:st+len(ii)]=np.asarray(raw[ii[:,None]+np.arange(12),:,0]).transpose(0,2,1);last[st:st+len(ii)]=raw[ii-1,:,0]
  raw._mmap.close();th=read(T/'EARLY_PREFIX_STATE_THRESHOLDS.json');center=np.asarray(th['center']);tt=np.asarray(th['thresholds'])
  states=(abs(y-center[None,:,None])>tt[0][None,:,None]).astype(np.int8)+(abs(y-center[None,:,None])>tt[1][None,:,None]).astype(np.int8)+3*(abs(last-center)>tt[1])[:,:,None]
  yy=y.ravel().astype(float);ss=states.ravel();days=np.repeat(times[oo-1]//86400,360);pred={}
  rr=np.load(W/('REFERENCE_'+role+'.npz'))['point'].ravel().astype(float);pred['EARLY_REFERENCE']=np.repeat(rr[None],3,axis=0)
  pred['PERSISTENCE']=np.repeat(np.repeat(last[:,:,None],12,2).reshape(1,-1),3,axis=0)
  pred['DLINEAR']=np.array([np.load(W/str(s)/('ANCHOR_'+role+'.npz'))['point'].ravel() for s in SEEDS])
  for arm in ['A','B','C','D']:pred[arm]=np.array([np.load(W/str(s)/(arm+'_'+role+'_POINT.npz'))['point'].ravel() for s in SEEDS])
  pred['SELECTED']=np.array([pred[seals[s]['selected_arm']][i] for i,s in enumerate(SEEDS)])
  for arm in ['I0_DYNAMIC','I1_DYNAMIC','I1_STATIC','I1_FLAT']:pred[arm]=np.array([qmean(np.load(W/str(s)/(arm+'_'+role+'.npz'))['q']).ravel() for s in SEEDS])
  subsets={'all':np.ones(len(yy),bool),**{'S'+str(k):ss==k for k in range(6)}}
  results={name:{part:dict(**scores(yy,p,mask),UTC_dates=len(np.unique(days[mask]))) for part,mask in subsets.items() if mask.any()} for name,p in pred.items()}
  comparisons={}
  for a,b in [('SELECTED','EARLY_REFERENCE'),('B','A'),('D','C'),('C','A'),('D','B'),('I1_DYNAMIC','I0_DYNAMIC'),('I1_DYNAMIC','I1_STATIC'),('I1_DYNAMIC','I1_FLAT')]:
   comparisons[a+'_vs_'+b]={part:block_compare(yy,pred[a],pred[b],days,mask) for part,mask in subsets.items() if mask.any()}
  attribution={}
  for part,mask in subsets.items():
   if not mask.any():continue
   d=pred['SELECTED'][:,mask]-pred['EARLY_REFERENCE'][:,mask];e=yy[mask][None]-pred['EARLY_REFERENCE'][:,mask]
   identity=d*d-2*e*d;observed=(yy[mask][None]-pred['SELECTED'][:,mask])**2-e*e
   assert np.max(abs(identity-observed))<1e-6
   attribution[part]=dict(cells=int(mask.sum()),MSE_change=float(observed.mean()),correction_square_cost=float((d*d).mean()),error_alignment_benefit=float((2*e*d).mean()),correction_nonzero_fraction=float((abs(d)>1e-8).mean()))
  source=np.load(Q/'NATIVE_CALENDAR_FEATURES.npz');ix=np.searchsorted(source['origins'],oo);source_subset=np.repeat(source['retrospective_qualified'][ix],360)
  result=dict(at=now(),scope='Fixed early-contract chronological historicaldevelopment; not originalV7replacement or newblindconfirmation.',roles='ExpertFIT2023;VALIDJanFeb2024;CALMar2024;RiskFITAprAug2024;RiskCALSepDec2024;DEVJanMar2025',origin_count=len(oo),UTC_dates=len(np.unique(days)),metrics=results,paired_comparisons=comparisons,source_qualified_cells=int(source_subset.sum()),same_source_subset_metrics={k:scores(yy,p,source_subset) for k,p in pred.items()},selected_arms={str(s):seals[s]['selected_arm'] for s in SEEDS},original_V7_comparison='Pending lawful later-period input replay after this complete freeze; never replace EARLY_REFERENCE with V7 in a fitted utility formula.',attribution=attribution,original_V7_modified=False,P8_reads=0)
  from distribution_review import review
  result['distribution_secondary']={a:{str(s):review(y,np.load(W/str(s)/(a+'_'+role+'.npz'))['q'],rr.reshape(y.shape),subsets) for s in SEEDS} for a in ['I0_DYNAMIC','I1_DYNAMIC','I1_STATIC','I1_FLAT']}
  save(W/'HISTORICAL_FORWARD_RESULTS.json',result)
  atomic_np(W/'HISTORICAL_SCORING_ARCHIVE.npz',y=y,states=states,issue=times[oo-1],**{k:v.reshape(3,len(oo),30,12) for k,v in pred.items()})
  allc=comparisons['SELECTED_vs_EARLY_REFERENCE']['all'];save(W/'HISTORICAL_DECISION.json',dict(at=now(),full_three_seed_complete=True,joint_point_improvement=allc['MAE_improvement']>0 and allc['RMSE_improvement']>0,both_date_CI_positive=allc['date']['MAE_CI95'][0]>0 and allc['date']['RMSE_CI95'][0]>0,V7_replacement_established=False,remaining='Later lawful same-reference replay vs originalV7; independentconfirmation separate. No new architecture grid authorized by this result.',all=allc))
  print(json.dumps(dict(completed=True,all=allc)),flush=True)
if __name__=='__main__':main()

