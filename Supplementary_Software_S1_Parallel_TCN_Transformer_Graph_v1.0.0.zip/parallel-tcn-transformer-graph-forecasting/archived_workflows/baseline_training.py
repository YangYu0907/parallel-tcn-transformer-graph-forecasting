# Recorded study workflow. See docs/REPRODUCTION_LEVELS.md before execution.
"""Finite, training-only selected tabular baselines. Same information, explicit representation."""
from shared import *
import pickle, gc

def blocks(x,size=32768):
    import numpy as np
    for st in range(0,len(x),size):
        guard();end=min(st+size,len(x))
        if isinstance(x,np.memmap):
            b=np.memmap(x.filename,mode='r',dtype=x.dtype,offset=x.offset+st*x.strides[0],shape=(end-st,x.shape[1]))
            try:yield st,b
            finally:b._mmap.close()
        else:yield st,x[st:end]

def tree(x,y,path,loss,node,seed=20260813):
    from threadpoolctl import threadpool_limits
    if path.exists():
        assert sha(path)==read(path.with_suffix('.json'))['sha256']
        return pickle.loads(path.read_bytes())
    if node==35:
        from memory_safe_hgb import FixedNodeHGB as HGB
    else:
        from sklearn.ensemble import HistGradientBoostingRegressor as HGB
    args=dict(loss=loss,max_iter=20,max_leaf_nodes=7,min_samples_leaf=100,l2_regularization=1.,learning_rate=.05,early_stopping=False,random_state=seed,categorical_features=[node],warm_start=True)
    tmp=path.with_suffix('.working.pkl');start=time.monotonic()
    m=pickle.loads(tmp.read_bytes()) if tmp.exists() else HGB(**args)
    with threadpool_limits(1):
        for count in [20,40,60]:
            if getattr(m,'n_iter_',0)>=count:continue
            guard();m.set_params(max_iter=count);m.fit(x,y)
            t=tmp.with_suffix('.tmp');t.write_bytes(pickle.dumps(m,protocol=5));os.replace(t,tmp)
            tick('baseline_HGB_checkpoint',model=path.name,iterations=count)
    t=path.with_suffix('.tmp');t.write_bytes(pickle.dumps(m,protocol=5));os.replace(t,path)
    save(path.with_suffix('.json'),dict(at=now(),sha256=sha(path),rows=len(y),columns=x.shape[1],loss=loss,iterations=60,seconds=time.monotonic()-start))
    return m

def pred_tree(m,x):
    import numpy as np
    p=np.empty(len(x),float)
    for st,b in blocks(x):p[st:st+len(b)]=m.predict(b)
    return p

def ridge_design(v,node,nodes):
    import numpy as np
    ids=v[:,node].astype(int);assert np.all((ids>=0)&(ids<nodes))
    return np.column_stack([np.delete(v,node,axis=1),np.eye(nodes)[ids]])

def fit_ridge(x,y,xv,yv,lastv,unit,node,nodes,path,fixed_alpha=None):
    import numpy as np
    if path.exists():
        assert sha(path)==read(path.with_suffix('.json'))['sha256'];return pickle.loads(path.read_bytes())
    count=0;su=None;sq=None
    for _,v in blocks(x):
        a=ridge_design(v,node,nodes);su=a.sum(0) if su is None else su+a.sum(0);sq=(a*a).sum(0) if sq is None else sq+(a*a).sum(0);count+=len(a)
    c=su/count;s=np.maximum(np.sqrt(np.maximum(0,sq/count-c*c)),1e-6)
    g=np.zeros((len(c)+1,len(c)+1));rhs=np.zeros(len(c)+1)
    for st,v in blocks(x):
        a=(ridge_design(v,node,nodes)-c)/s;a=np.column_stack([np.ones(len(a)),a]);g+=a.T@a;rhs+=a.T@y[st:st+len(a)]
    ae=max(float(abs(yv-lastv).mean()),1e-6);rm=max(float(np.sqrt(((yv-lastv)**2).mean())),1e-6)
    candidates=[];models={}
    for alpha in ([float(fixed_alpha)] if fixed_alpha is not None else [10.,100.,1000.,10000.,100000.,1000000.]):
        reg=np.eye(len(rhs))*alpha;reg[0,0]=0.;coef=np.linalg.solve(g+reg,rhs)
        m=dict(center=c,scale=s,coef=coef,node=node,nodes=nodes,alpha=alpha)
        p=lastv+unit*pred_ridge(m,xv);e=yv-p
        candidates.append(dict(alpha=alpha,MAE=float(abs(e).mean()),RMSE=float(np.sqrt((e*e).mean())),score=float(abs(e).mean()/ae+np.sqrt((e*e).mean())/rm)));models[alpha]=m
    chosen=min(candidates,key=lambda r:(r['score'],-r['alpha']));m=models[chosen['alpha']]
    tmp=path.with_suffix('.tmp');tmp.write_bytes(pickle.dumps(m,protocol=5));os.replace(tmp,path)
    save(path.with_suffix('.json'),dict(at=now(),sha256=sha(path),validation=candidates,selected_alpha=chosen['alpha'],fit_rows=len(y),feature_contract='All same tabular fields as HGB; node one-hot; FIT-only standardization; pooled node/horizon regression. Not full288x30 raw-history Ridge.',selection='Frozen earlier VALID choice; diagnostic rows now included in refit, no new selection' if fixed_alpha is not None else 'EXPERT_VALID normalizedMAE+RMSE only'))
    return m

def pred_ridge(m,x):
    import numpy as np
    out=np.empty(len(x),float)
    for st,v in blocks(x):
        a=(ridge_design(v,m['node'],m['nodes'])-m['center'])/m['scale'];out[st:st+len(a)]=m['coef'][0]+a@m['coef'][1:]
    return out

def fit_family(frames,labels,last,unit,node,nodes,dest,extra_meta=None):
    """Returns predictions for every role; evaluation labels never passed here."""
    import numpy as np
    dest.mkdir(parents=True,exist_ok=True)
    if (dest/'FREEZE.json').exists():
        s=read(dest/'FREEZE.json')
        for p,h in s['bindings'].items():assert sha(p)==h,p
        return
    yf=(labels['EXPERT_FIT']-last['EXPERT_FIT'])/unit
    yv=labels['EXPERT_VALID'];lv=last['EXPERT_VALID'];ae=max(float(abs(yv-lv).mean()),1e-6);rm=max(float(np.sqrt(((yv-lv)**2).mean())),1e-6)
    trials=[]
    for loss in ['absolute_error','squared_error']:
        path=dest/('HGB_'+loss+'.pkl');m=tree(frames['EXPERT_FIT'],yf,path,loss,node)
        e=yv-(lv+unit*pred_tree(m,frames['EXPERT_VALID']))
        trials.append(dict(loss=loss,MAE=float(abs(e).mean()),RMSE=float(np.sqrt((e*e).mean())),score=float(abs(e).mean()/ae+np.sqrt((e*e).mean())/rm)))
        del m;gc.collect()
    selected=min(trials,key=lambda r:(r['score'],r['loss']))['loss']
    hgb=pickle.loads((dest/('HGB_'+selected+'.pkl')).read_bytes())
    ridge=fit_ridge(frames['EXPERT_FIT'],yf,frames['EXPERT_VALID'],yv,lv,unit,node,nodes,dest/'RIDGE.pkl')
    bindings={str(p):sha(p) for p in dest.glob('*.pkl') if '.working.' not in p.name};details={}
    for name,model,fn in [('HGB',hgb,pred_tree),('RIDGE',ridge,pred_ridge)]:
        cal=last['EXPERT_CAL']+unit*fn(model,frames['EXPERT_CAL']);e=labels['EXPERT_CAL']-cal;bias=bias_fit(e)
        details[name]=dict(bias=bias,CAL_MAE=float(abs(e-bias).mean()),CAL_RMSE=float(np.sqrt(((e-bias)**2).mean())))
        for role,x in frames.items():
            p=last[role]+unit*fn(model,x)+bias;out=dest/(name+'_'+role+'.npz');atomic_np(out,point=p);bindings[str(out)]=sha(out)
    save(dest/'FREEZE.json',dict(at=now(),bindings=bindings,HGB_VALID_trials=trials,HGB_selected=selected,details=details,selection='VALID and scalar CAL only; independent of current neural final results',evaluation_targets_read=False,metadata=extra_meta))

def caiso():
    import numpy as np
    with locked('CAISO_same_information_tabular_baselines'):
        sealcheck();parent_complete();dest=Q/'CAISO_baselines';dest.mkdir(parents=True,exist_ok=True)
        roles=['EXPERT_FIT','EXPERT_VALID','EXPERT_CAL','RISK_FIT','RISK_CAL','HISTORICAL_DEV_CHECK','LATER']
        L=CW/'later_replay';audit=read(L/'INPUT_AUDIT.json');assert audit['passed']
        for p,h in audit['bindings'].items():assert sha(p)==h,p
        with np.load(L/'META.npz') as z:src=z['source'];lastlater=z['last']
        laterframe=dest/'LATER_FRAME.npy'
        if not laterframe.exists():
            building=laterframe.with_suffix('.building.npy');old=np.load(L/'X.npy',mmap_mode='r');out=np.lib.format.open_memmap(building,mode='w+',dtype='float32',shape=(len(old)*360,47))
            for st in range(0,len(old),16):
                guard();xx=old[st:st+16];stats=np.stack([xx[:,-t:,:,0].mean(1) for t in [12,36,288]]+[xx[:,-t:,:,0].std(1) for t in [12,36,288]],-1)
                out[st*360:(st+len(xx))*360]=np.column_stack([np.repeat(xx[:,-1].reshape(-1,29),12,0),np.repeat(stats.reshape(-1,6),12,0),np.tile(np.repeat(np.arange(30),12),len(xx)),np.tile((np.arange(12)+1)/12,len(xx)*30),np.repeat(src[st:st+len(xx)],360,0)])
            out.flush();out._mmap.close();old._mmap.close();os.replace(building,laterframe)
        labels={};last={};d=parent.Data()
        for role in roles:
            if role in ['EXPERT_FIT','EXPERT_VALID','EXPERT_CAL','RISK_FIT','RISK_CAL']:
                with np.load(CF/(role+'_LABELS.npz')) as z:labels[role]=z['y'].ravel().astype(float);v=z['last']
            elif role=='LATER':v=lastlater
            else:
                v=np.concatenate([d.batch(d.roles[role][st:st+128])[2][:,-1] for st in range(0,len(d.roles[role]),128)])
            last[role]=np.broadcast_to(v[:,:,None],(len(v),30,12)).ravel().astype(float)
        for info in [0,1]:
            folder=dest/f'I{info}';folder.mkdir(exist_ok=True);frames={}
            # Exact same FIT rows, columns, mask, target, seed and capacity as the
            # already completed reference: reuse it, do not train it again.
            if info==0 and not (folder/'HGB_absolute_error.pkl').exists():
                import shutil
                source=CW/'REFERENCE.pkl';receipt=read(source.with_suffix('.json'))
                assert sha(source)==receipt['sha256']
                shutil.copy2(source,folder/'HGB_absolute_error.pkl')
                save(folder/'HGB_absolute_error.json',dict(**receipt,reused_from=str(source),retraining=False))
            for role in roles:
                target=folder/(role+'.npy');source=laterframe if role=='LATER' else CW/'frames'/(role+'.npy')
                if not target.exists():
                    building=target.with_suffix('.building.npy');z=np.load(source,mmap_mode='r');out=np.lib.format.open_memmap(building,mode='w+',dtype='float64',shape=z.shape);offset=out.offset;out.flush();out._mmap.close()
                    for st,v in blocks(z):
                        a=np.array(v,dtype=float,copy=True)
                        if info==0:a[:,37:45]=0
                        with building.open('r+b') as stream:stream.seek(offset+st*47*8);stream.write(a.tobytes())
                    z._mmap.close();os.replace(building,target)
                frames[role]=np.load(target,mmap_mode='r')
            fit_family(frames,labels,last,d.unit,35,30,folder,dict(info=info,fit_cutoff='EXPERT_FIT2023',same_information_as=f'I{info}_DYNAMIC',different_representation='47causal tabular fields versus full neural history',risk_selector_uses_later_training_labels=True))
            if info==1:operational_refit(frames,labels,last,d.unit,folder,dest/'UPDATED_I1')
            for v in frames.values():v._mmap.close()
        save(dest/'COMPLETE.json',dict(at=now(),seals={str(i):sha(dest/f'I{i}/FREEZE.json') for i in [0,1]},updated_seal=sha(dest/'UPDATED_I1/FREEZE.json'),new_neural_fits=0,selection_on_EVAL_or_P8=False))

def operational_refit(frames,labels,last,unit,early,dest):
    """Give strong simple baselines the same latest eligible label cutoff as the policy."""
    import numpy as np
    dest.mkdir(exist_ok=True)
    if (dest/'FREEZE.json').exists():
        for p,h in read(dest/'FREEZE.json')['bindings'].items():assert sha(p)==h,p
        return
    chosen=read(early/'FREEZE.json')['HGB_selected'];alpha=read(early/'RIDGE.json')['selected_alpha']
    roles=['EXPERT_FIT','EXPERT_VALID','EXPERT_CAL','RISK_FIT'];count=sum(len(frames[k]) for k in roles);p=dest/'FIT.npy'
    if not p.exists():
        building=p.with_suffix('.building.npy');out=np.lib.format.open_memmap(building,mode='w+',dtype='float64',shape=(count,47));offset=out.offset;out.flush();out._mmap.close();pos=0
        for role in roles:
            for _,v in blocks(frames[role]):
                with building.open('r+b') as stream:stream.seek(offset+pos*47*8);stream.write(np.asarray(v).tobytes())
                pos+=len(v)
        assert pos==count
        os.replace(building,p)
    x=np.load(p,mmap_mode='r');y=np.concatenate([(labels[k]-last[k])/unit for k in roles])
    hgb=tree(x,y,dest/'HGB.pkl',chosen,35)
    ridge=fit_ridge(x,y,frames['EXPERT_VALID'],labels['EXPERT_VALID'],last['EXPERT_VALID'],unit,35,30,dest/'RIDGE.pkl',fixed_alpha=alpha)
    bind={str(dest/(name+'.pkl')):sha(dest/(name+'.pkl')) for name in ['HGB','RIDGE']};details={}
    for name,model,fn in [('HGB',hgb,pred_tree),('RIDGE',ridge,pred_ridge)]:
        e=labels['RISK_CAL']-(last['RISK_CAL']+unit*fn(model,frames['RISK_CAL']));b=bias_fit(e);details[name]=dict(bias=b)
        for role in ['HISTORICAL_DEV_CHECK','LATER']:
            point=last[role]+unit*fn(model,frames[role])+b;p=dest/(name+'_'+role+'.npz');atomic_np(p,point=point);bind[str(p)]=sha(p)
    x._mmap.close()
    save(dest/'FREEZE.json',dict(at=now(),bindings=bind,fit_roles=roles,fit_rows=count,selection='Reuse early VALID-selected loss/alpha; no new search',calibration='RISK_CAL same constant-bias protection',details=details,latest_labels_same_cutoff_as_policy=True,all_permitted_early_history_used=True,evaluation_targets_read=False,compute_note='60HGB rounds; same information and latest eligible labels, not exact parameter/FLOP equality'))

if __name__=='__main__':caiso()
