# Recorded study workflow. See docs/REPRODUCTION_LEVELS.md before execution.
"""Secondary distribution metrics; never invent a CDF for a point-only selector."""
from train_policy import *
def cdf(q,t):
 import numpy as np
 lev=np.asarray(LEVELS);t=np.broadcast_to(t,q.shape[:-1]);ans=np.full(t.shape,.5)
 for k in range(12):
  hit=(t>=q[...,k])&(t<q[...,k+1]);den=np.maximum(q[...,k+1]-q[...,k],1e-9)
  ans=np.where(hit,lev[k]+(lev[k+1]-lev[k])*(t-q[...,k])/den,ans)
 sl=np.maximum((q[...,1]-q[...,0])/np.log(2),1e-8);sr=np.maximum((q[...,-1]-q[...,-2])/np.log(2),1e-8)
 ans=np.where(t<q[...,0],.005*np.exp(np.minimum(0,(t-q[...,0])/sl)),ans)
 ans=np.where(t>=q[...,-1],1-.005*np.exp(np.minimum(0,-(t-q[...,-1])/sr)),ans)
 return np.clip(ans,1e-9,1-1e-9)
def thresholds(reference):
 import numpy as np
 # All thresholds fixed on early FIT/CAL, never later scored prices.
 with np.load(F/'EXPERT_FIT_LABELS.npz') as z:y=z['y']
 lo=np.quantile(y,[.01,.99],axis=(0,2))
 with np.load(F/'EXPERT_CAL_LABELS.npz') as z:yc=z['y']
 rc=np.load(W/'REFERENCE_EXPERT_CAL.npz')['point']
 residual=np.quantile(yc-rc,[.05,.95],axis=(0,2))
 return dict(fixed_low=lo[0][None,:,None],fixed_high=lo[1][None,:,None],relative_low=reference+residual[0][None,:,None],relative_high=reference+residual[1][None,:,None])
def review(y,q,reference,masks):
 import numpy as np
 e=y[...,None]-q;pb=2*np.maximum(np.asarray(LEVELS)*e,(np.asarray(LEVELS)-1)*e).mean(-1)
 arrays={'WIS13':pb}
 for a,b,n in [(4,8,'80'),(3,9,'90'),(0,12,'99')]:
  arrays['coverage'+n]=(y>=q[...,a])&(y<=q[...,b]);arrays['width'+n]=q[...,b]-q[...,a]
 for name,t in thresholds(reference).items():
  low=name.endswith('low');p=cdf(q,t);p=p if low else 1-p;hit=(y<t) if low else (y>t)
  arrays[name+'_Brier']=(p-hit)**2;arrays[name+'_Logloss']=-(hit*np.log(p)+(1-hit)*np.log1p(-p))
 out={part:{k:float(v.ravel()[mask].mean()) for k,v in arrays.items()} for part,mask in masks.items() if mask.any()}
 return dict(metrics=out,crossings=int((np.diff(q,axis=-1)<0).sum()),thresholds='fixedEarlyFITnodeq01/q99; relativeEARLYREFERENCE plus nodeEXPERTCAL residualq05/q95. Not originalV7probability task.',CDF='Linear inversequantile interpolation; exponentialoutertails; analyticmean as checkpoint.',point_selector_has_no_distribution=True)

