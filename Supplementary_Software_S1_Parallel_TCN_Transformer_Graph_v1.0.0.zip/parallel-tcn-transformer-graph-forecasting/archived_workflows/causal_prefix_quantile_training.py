# Recorded historical component workflow. See docs/REPRODUCTION_LEVELS.md.
from common20 import *
from group_calibration20 import candidates as frozen_group
import outer_calibration20 as outer20
FIELDS=[0,8,9,10,11,12,13,14,15,16,19,20,21,22,23,24,25,26,27,28]
RFIELDS=[0,21,22,23,24,15,16,25,26,27,28,8,9,10,11,12,13]
def model_fit(X,y,seed,loss='squared_error',tau=.5,iters=40):
 from sklearn.ensemble import HistGradientBoostingRegressor
 kw=dict(loss=loss,max_iter=20,max_leaf_nodes=7,min_samples_leaf=100,learning_rate=.05,l2_regularization=1.,early_stopping=False,warm_start=True,random_state=seed)
 if loss=='quantile':kw['quantile']=float(tau)
 m=HistGradientBoostingRegressor(**kw)
 for end in range(20,iters+1,20):guard();m.set_params(max_iter=end);m.fit(X,y)
 return m
def routx(last,ex,scale):
 n=len(last);hist=np.repeat(last[:,:,RFIELDS].reshape(-1,len(RFIELDS)),12,0)
 return np.column_stack([hist,np.tile((np.arange(12)+1)/12,n*30),((ex[...,0]-ex[...,2])/scale[None,:,None]).ravel(),((ex[...,1]-ex[...,0])/scale[None,:,None]).ravel()]).astype('float32')
def headx(last,point,ex,center,scale):
 n=len(last);hist=np.repeat(last[:,:,FIELDS].reshape(-1,len(FIELDS)),12,0);node=np.tile(np.repeat(np.eye(30,dtype='float32'),12,0),(n,1))
 return np.column_stack([hist,((point-center[None,:,None])/scale[None,:,None]).ravel(),((ex[...,0]-center[None,:,None])/scale[None,:,None]).ravel(),(np.ptp(ex,axis=-1)/scale[None,:,None]).ravel(),(ex.std(-1)/scale[None,:,None]).ravel(),np.tile((np.arange(12)+1)/12,n*30),node]).astype('float32')
def resolve_manifest():
 m=read(gd.MANIFEST);paths={k:translated(v['path']) for k,v in m['artifacts'].items()};return m,paths
def early_features(panel):
 path=D/'EARLY_CAUSAL_FEATURES.npz'
 if path.exists():return load(path,['features'])['features']
 f=read(B/'h1_final_evaluation_v1_20260927/FINAL_TEST_FREEZE.json');parent=read(translated(f['input_freeze']));sys.path.insert(0,str(B/'h1_feature_admission_v1_20260927'))
 from history import validate_origin,BoundedMember
 with np.load(translated(f['publication_routing'])) as zz:meta={k:zz[k] for k in zz.files}
 meta['epoch']=int(meta['epoch']);allowed=frozenset(parent['origins']);orig=panel['origins'][:304];contracts=[validate_origin(int(o),allowed,meta)[0] for o in orig]
 archive=Path(parent['config']['price_archive']);expected=parent['archive_hashes'][str(archive)];check('early_price_archive_hash',sha(archive)==expected)
 reader=BoundedMember(archive,'values','<f4',(30,4));values=[]
 try:
  reader.prepare_byte_cache(contracts,'price')
  for o,c in zip(orig,contracts):
   pp=np.frombuffer(reader.read(int(o-13),int(o),c,'price'),'<f4').reshape(13,30,4)[:,:,0].astype(float)
   check('early_last_'+str(o),np.allclose(pp[-1],panel['raw_last'][np.searchsorted(panel['origins'],o)],atol=1e-6,rtol=0));values.append(np.column_stack([pp[-1]-pp[-4],np.maximum(pp[-1]-pp[-1].min(),0)]))
  receipts=reader.receipts
 finally:reader.close()
 ex=np.asarray(values);save20(path.name,origins=orig,features=ex);write(D/'EARLY_FEATURE_ADMISSION.json',dict(source=str(archive),sha256=expected,receipts=receipts,origins=304,latest_index='origin-1',earliest_index='origin-13'));return ex
def specialist(panel,ex,seed,threshold):
 # Reuse only TRAIN-fitted V5 conditional distributions and V7 TRAIN-calibrated survival probabilities.
 d=load(T/f'adaptive_experts_v5_20260929/models/{seed}_distributions.npz',['mus','quantiles','prior']);p=load(T/f'spike_specialist_v7_20260930/models/{seed}_CONTEXT_probabilities.npz',['probabilities'])['probabilities']
 q=np.asarray(threshold['thresholds']);center=np.asarray(threshold['center']);mu=d['mus'].reshape(-1,3);prob=p.reshape(-1,3);ratio=np.broadcast_to((q[0]/q[1])[None,:,None],ex.shape[:-1]).ravel();sign=np.broadcast_to(np.sign(panel['raw_last']-center)[:,:,None],ex.shape[:-1]).ravel()
 atoms=mu[...,None]+d['quantiles'][None,:,:];atoms[:,0]=np.clip(atoms[:,0],-ratio[:,None],ratio[:,None])
 for k in [1,2]:
  s=np.where(atoms[:,k]>=0,1.,-1.);s=np.where(abs(atoms[:,k])<1e-12,sign[:,None],s);atoms[:,k]=s*np.clip(abs(atoms[:,k]),ratio[:,None] if k==1 else 1.,1. if k==1 else np.inf)
 weights=np.broadcast_to(prob[...,None]/d['quantiles'].shape[1],atoms.shape).reshape(len(mu),-1);atoms=atoms.reshape(len(mu),-1);mean=(atoms*weights).sum(-1);order=np.argsort(atoms,axis=-1);av=np.take_along_axis(atoms,order,-1);wv=np.take_along_axis(weights,order,-1);median=av[np.arange(len(av)),np.argmax(np.cumsum(wv,-1)>=.5,axis=-1)]
 shape=ex.shape[:-1];mean=mean.reshape(shape)*q[1][None,:,None]+center[None,:,None];median=median.reshape(shape)*q[1][None,:,None]+center[None,:,None];full=ex[...,0];a=mean-full;b=median-full;out=np.where(a*b>0,.25*full+.75*np.where(abs(a)<=abs(b),mean,median),full);return out
def routing(panel,ex,seed,paths,sc,threshold):
 path=D/f'CAUSAL_EARLY_ROUTER_{seed}.npz'
 if path.exists():return load(path,['prediction'])['prediction']
 f=read(B/'h1_final_evaluation_v1_20260927/FINAL_TEST_FREEZE.json');heads={}
 for name in ['FULL','DLinear']:
  case=next(c for c in f['cases'] if c['id']==f'{seed}_{name}');p=translated(case['reference']);check('router_reference_'+str(seed)+name,sha(p)==case['reference_sha256']);heads[name]=load(p,['origins','prediction','truth'])
 fb=load(B/'adaptive_experts_v2_20260929/feedback.npz',['origins','cutoff','available']);oo=heads['FULL']['origins'];check('June_feedback_alignment',np.array_equal(oo,fb['origins']) and np.array_equal(oo,heads['DLinear']['origins']));check('June_before_early24',int(fb['available'].max())+86400<int(panel['cutoff'][0]))
 features=np.load(paths['features.npy'],mmap_mode='r');last=np.asarray(features[oo-1]);scale=np.asarray(sc['price_scale'])[0,:,0];center=np.asarray(sc['price_center'])[0,:,0];rawlast=last[:,:,0]*scale+center
 jex=np.stack([heads['FULL']['prediction'],heads['DLinear']['prediction'],np.broadcast_to(rawlast[:,:,None],heads['FULL']['prediction'].shape)],-1);X=routx(last,jex,scale);Y=(heads['FULL']['truth']-heads['FULL']['prediction']).ravel();dates=fb['cutoff']//86400;ud=np.unique(dates);split=ud[int(.8*len(ud))];cal=dates>=split;fit=(dates<split)&(fb['available'].max(1)+86400<fb['cutoff'][cal].min());fitcells=np.flatnonzero(np.repeat(fit,360));rng=np.random.default_rng(seed+2000)
 if len(fitcells)>96000:fitcells=np.sort(rng.choice(fitcells,96000,replace=False))
 H=routx(panel['last'][:304],ex[:304],scale);func=[];cor=[];th=np.asarray(threshold['thresholds']);reg=(abs(rawlast-np.asarray(threshold['center']))>th[0]).astype(int)+(abs(rawlast-np.asarray(threshold['center']))>th[1]).astype(int)
 for k,loss in enumerate(['squared_error','quantile']):
  progress('causal_pre2026_router',seed=seed,function=loss);model=model_fit(X[fitcells],Y[fitcells],seed+2000+k,loss);c19.store_tree(model,D/f'ROUTER_{seed}_{k}.pkl');pred=model.predict(H).reshape(304,30,12);calpred=model.predict(X).reshape(len(oo),30,12);bias=np.zeros((3,3));counts=np.zeros((3,3),int)
  for r,g in itertools.product(range(3),range(3)):
   dayvalues=[]
   for day in np.unique(dates[cal]):
    m=(dates==day)[:,None,None]&(reg==r)[:,:,None]&np.broadcast_to((np.arange(12)//4==g)[None,None,:],calpred.shape);v=(Y.reshape(calpred.shape)-calpred)[m]
    if len(v):dayvalues.append(float(v.mean() if k==0 else np.median(v)))
   counts[r,g]=len(dayvalues)
   if len(dayvalues)>=3:bias[r,g]=np.mean(dayvalues)*len(dayvalues)/(len(dayvalues)+5.)
  funcs=pred+bias[panel['observable_regime'][:304,:,None],np.arange(12)[None,None,:]//4];func.append(funcs);cor.append(dict(bias=bias.tolist(),days=counts.tolist()))
 mean,median=func;c=np.where(mean*median>0,np.sign(mean)*np.minimum(abs(mean),abs(median)),0);delta=ex[:304,...,1:]-ex[:304,...,:1];best=np.argmax(delta*np.sign(c)[...,None],-1);v=np.take_along_axis(delta,best[...,None],-1)[...,0];alpha=np.where(c*v>0,np.minimum(abs(c)/np.maximum(abs(v),1e-12),.75),0);point=ex[:304,...,0]+alpha*v
 sp=specialist(panel,ex,seed,threshold);point[panel['observable_regime'][:304]==2]=sp[:304][panel['observable_regime'][:304]==2]
 old=load(T/f'spike_specialist_v7_20260930/audited/{seed}.npz',['origins','CONTEXT']);idx=np.searchsorted(panel['origins'],old['origins']);ext=panel['observable_regime'][idx]==2;check('TRAIN_specialist_exact_old_'+str(seed),np.array_equal(sp[idx][ext],old['CONTEXT'][ext]))
 save20(path.name,prediction=point,origins=panel['origins'][:304]);write(D/f'ROUTER_{seed}_CONTRACT.json',dict(at=rt.now(),origin_count=304,latest_label_available=dc.prev.utc(int(fb['available'].max())),first_prediction_issue=dc.prev.utc(int(panel['cutoff'][0])),fit_cells=len(fitcells),fit_days=len(np.unique(dates[fit])),cal_days=len(np.unique(dates[cal])),seed=seed,correction=cor,scope='New PRE2026 V4-style routine functional router, old TRAIN-only V7 extreme specialist. Not bitwise original V4/V6/V7. Shared feature schema; historical routing version changes before original V7 available. Original point files never changed.',checkpoint_match='June selected_dense references directly bound to H1 FINAL_TEST_FREEZE',June_selection_exposure=True))
 del features,X,jex,sp;gc.collect();return point
def run():
 reg=read(D/'PREFIX_REGISTRATION.json')
 overrides={}
 for ap in sorted(D.glob('AMENDMENT*.json')):overrides.update(read(ap).get('code_overrides',{}))
 for p,h in reg['sources'].items():check('prefix_source_'+str(Path(p).name),sha(p)==overrides.get(p,h))
 panel=load(T/'adaptive_experts_v4_20260929/panel.npz',['origins','cutoff','available','last','raw_last','observable_regime','truth','states']);m,paths=resolve_manifest();sc=read(paths['scalers.json']);th=read(paths['state_thresholds.json']);scale=np.asarray(sc['price_scale'])[0,:,0];center=np.asarray(sc['price_center'])[0,:,0]
 # TRAIN-only expert ancestry ends long before H1, including its held calibration.
 ts=np.load(paths['timestamps_seconds.npy'],mmap_mode='r');v7tr=load(T/'spike_specialist_v7_20260930/TRAIN_features.npz',['origins','fit','cal']);v5tr=load(T/'adaptive_experts_v5_20260929/TRAIN_prepared.npz',['origins','fit','cal']);latest=max(int(ts[v7tr['origins']+11].max()),int(ts[v5tr['origins']+11].max()));check('specialist_training_pre2026_24',latest+86400<int(panel['cutoff'][0]))
 earlyex=early_features(panel);oldex=load(F/'ENHANCED_CAUSAL_FEATURES.npz',['origins','features']);exall=np.concatenate([earlyex,oldex['features'][:,:,[0,2]]]);check('prefix_feature_origins',np.array_equal(np.r_[panel['origins'][:304],oldex['origins']],panel['origins']))
 results={};states={};recipes={};admissions=[];training=[];oldrows=read(F/'ENHANCED_RESULTS.json')
 for seed in SEEDS:
  progress('prefix_seed',seed=seed);experts=load(T/f'adaptive_experts_v4_20260929/experts/{seed}.npz',['origins','experts']);check('expert_order',np.array_equal(experts['origins'],panel['origins']));ex=experts['experts'];earlypoint=routing(panel,ex,seed,paths,sc,th)
  d=load(U/f'data/CAISO_{seed}.npz',['X','fit','residual','origin','h','node','cap','allow','feature_center','feature_scale','point']);point=np.concatenate([earlypoint,d['point'].reshape(-1,30,12)]);z=dc.panel('CAISO',seed,'ANCHOR');origpoint=digest(z['point']);calcut=float(z['cut'][z['cal']].min())
  keep=d['fit']&(z['available']+86400<calcut);purged=np.r_[np.zeros(304*360,bool),keep];extra=np.repeat((panel['available'][:304].max(1)+86400<calcut),360);expanded=np.r_[extra,keep]
  Xraw=headx(panel['last'],point,ex,center,scale);check('head_feature_old_parity_'+str(seed),np.array_equal(np.clip((Xraw[304*360:]-d['feature_center'])/d['feature_scale'],-6,6).astype('float32'),d['X']))
  e=np.repeat(exall[:,:,None,:],12,2).reshape(-1,2);Xraw=np.column_stack([Xraw,e]).astype('float32');med=np.median(Xraw[purged],0);iq=np.quantile(Xraw[purged],[.25,.75],0);sp=np.maximum(iq[1]-iq[0],1e-3);X=np.clip((Xraw-med)/sp,-6,6).astype('float32');res=((panel['truth']-point)/scale[None,:,None]).ravel().astype('float32')
  check('head_old_residual_exact_'+str(seed),np.array_equal(res[304*360:],d['residual']))
  info=dict(seed=seed,old_fit_origins=len(np.unique(d['origin'][keep])),old_fit_cells=int(keep.sum()),extra_origins=int(extra.sum()//360),expanded_origins=int(np.any(expanded.reshape(1002,360),1).sum()),expanded_cells=int(expanded.sum()),old_fit_dates=len(np.unique(z['days'][keep])),expanded_dates=len(np.unique(np.repeat(panel['cutoff']//86400,360)[expanded])),S2_cells=int((expanded&(panel['states'].ravel()==2)).sum()),S2_days=len(np.unique(np.repeat(panel['cutoff']//86400,360)[expanded&(panel['states'].ravel()==2)])),latest_fit_available=dc.prev.utc(int(np.repeat(panel['available'][:,None,:],30,1).ravel()[expanded].max())),CAL_first=dc.prev.utc(int(calcut)),normalization='Shared matched purged FIT245-only normalization; changes only training sample inclusion',point_sources='First304 new pre2026 router; later original V7 unchanged')
  admissions.append(info);write(D/'FIT_EXPANDED_ADMISSION.json',dict(at=rt.now(),rows=admissions,all_specialist_train_labels_latest=dc.prev.utc(latest)))
  rows={k:oldrows[str(seed)][k] for k in ['STATIC','STATE_ADD','EQ_EVAL_HINDSIGHT_STATE_ADD','ENHANCED_FULL_OUTER_CAP25','ENHANCED_FULL_OUTER_CAP35']};states[str(seed)]={};recipes[str(seed)]={}
  for arm,mask in [('PURGED_FIT',purged),('EXPANDED_FIT',expanded)]:
   progress('quantile_prefix_fit',seed=seed,arm=arm,cells=int(mask.sum()));q=np.empty((len(d['origin']),13));start=time.monotonic()
   for j,tau in enumerate(Q):
    p=D/f'{arm}_{seed}_q{j:02d}.pkl'
    if p.exists():
     with p.open('rb') as ff:model=pickle.load(ff)
    else:model=model_fit(X[mask],res[mask],seed,'quantile',tau,60);c19.store_tree(model,p)
    q[:,j]=model.predict(X[304*360:]);del model
   q=c19.q_adjust(q,d);zz=dc.panel('CAISO',seed,'ANCHOR');zz['qraw']=zz['point'][:,None]+zz['scale'][:,None]*(q-q[:,6,None]);zz['base'],sr=dc.prev.static(zz['qraw'],zz);fr,gr=frozen_group(zz);om,orr=outer20.make_outer(zz,fr['STATE_GROUP_AWARE_OUTER_CAP25']);recipes[str(seed)][arm]=dict(static=sr,group=gr,outer=orr)
   for cap in [25,35]:
    name=f'{arm}_CAP{cap}';v=om[f'STATE_GROUP_AWARE_FULL_OUTER_CAP{cap}'];check(name+'_ordered_'+str(seed),np.all(np.diff(v,axis=1)>0));rows[name]=dc.summarize(zz,v);states[str(seed)][name]=fp.state_table(zz,v);eq,f=dc.prev.equalwidth(z,v,'EVAL_HINDSIGHT');rows['EQ_EVAL_HINDSIGHT_'+name]=dc.summarize(z,eq)
    c19.save(f'PREFIX_{seed}_{name}.npz',reference=F/f'probability_{seed}_ENHANCED_GROUP_AWARE.npz',quantiles=v[z['late']],origin=z['origin'][z['late']],h=z['h'][z['late']],node=z['node'][z['late']])
   check('prefix_eval_point_unchanged_'+str(seed),digest(zz['point'])==origpoint);training.append(dict(seed=seed,arm=arm,seconds=time.monotonic()-start,trees=13,cells=int(mask.sum())));write(D/'PREFIX_TRAINING.json',training);del q,zz,fr,om;gc.collect()
  results[str(seed)]=rows;write(D/'PREFIX_RESULTS.json',results);write(D/'PREFIX_STATES.json',states);write(D/'PREFIX_RECIPES.json',recipes);del X,Xraw,experts,ex,d,point,z,res;gc.collect()
 cases=[results[str(s)] for s in SEEDS];jc.CANDS=[f'{a}_CAP{cap}' for a in ['PURGED_FIT','EXPANDED_FIT'] for cap in [25,35]];summary=jc.gates(cases)
 for cap in [25,35]:summary['gates'][f'EXPANDED_FIT_CAP{cap}']['vs_matched_purged']=boot(cases,f'EXPANDED_FIT_CAP{cap}',f'PURGED_FIT_CAP{cap}','CAISO');summary['gates'][f'EXPANDED_FIT_CAP{cap}']['vs_original_FIT245']=boot(cases,f'EXPANDED_FIT_CAP{cap}',f'ENHANCED_FULL_OUTER_CAP{cap}','CAISO')
 write(D/'PREFIX_SUMMARY.json',summary)
