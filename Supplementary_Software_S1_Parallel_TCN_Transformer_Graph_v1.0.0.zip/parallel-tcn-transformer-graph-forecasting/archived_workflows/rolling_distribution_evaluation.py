# Recorded historical component workflow. See docs/REPRODUCTION_LEVELS.md.
from batch_common import *
def calibrate_current(z,q,prefix,use):
 # The only labels read by this calibrator are fully mature prefix labels.
 adds=np.zeros((int(use.sum()),4));hh=z['h'][use];recipes=[]
 for h in np.unique(hh):
  m=prefix&(z['h']==h);row=[]
  for lev,i,j in [(80,4,8),(90,3,9)]:
   v=dc.prev.fq(np.maximum(q[m,i]-z['truth'][m],z['truth'][m]-q[m,j])/z['scale'][m],lev/100);row.extend([v,v])
  adds[hh==h]=np.asarray(row)*z['scale'][use][hh==h,None];recipes.append(row)
 return dc.prev.expand(q[use],*adds.T),recipes
def run():
 results={};support={};recipes={}
 for seed in SEEDS:
  progress('Europe_expanding_CQR',seed=seed);z=dc.prev.panel('Europe',seed);post=z['cal']|z['evaluate'];point=digest(z['point']);raw={}
  for arm in ['INDEPENDENT','JOINT','FIXED_POINT']:
   v=load(dc.U/'fits'/f'Europe_{seed}_{arm}/raw.npz',['q'])['q'].astype(float)
   if arm=='FIXED_POINT':v-=v[:,6,None]
   raw[arm]=z['point'][:,None]+z['scale'][:,None]*v
  out={k:np.zeros_like(raw['INDEPENDENT']) for k in ['NATIVE_INDEPENDENT','NATIVE_POOL','ANCHORED_FIXED_POINT']};ev=np.zeros(len(post),bool);schedule=[];records=[]
  for cut in np.unique(z['cut'][post]):
   prefix=post&(z['available']+86400<cut);use=post&(z['cut']==cut)
   if len(np.unique(z['days'][prefix]))<45:continue
   schedule.append(dict(cut=int(cut),mature_days=len(np.unique(z['days'][prefix])),cal_cells=int(prefix.sum()),eval_cells=int(use.sum()),latest_available=int(z['available'][prefix].max())))
  write(D/f'Europe_{seed}_ROLLING_SCHEDULE_FROZEN.json',dict(schedule=schedule,postfit_days=len(np.unique(z['days'][post])),delay_hours=24,minimum_mature_days=45))
  for it,row in enumerate(schedule):
   if it%20==0:guard()
   cut=row['cut'];prefix=post&(z['available']+86400<cut);use=post&(z['cut']==cut);q={};r={}
   check('Europe_maturity_'+str(seed)+'_'+str(cut),np.all(z['available'][prefix]+86400<cut) and not np.any(prefix&use))
   for arm in raw:q[arm],r[arm]=calibrate_current(z,raw[arm],prefix,use)
   out['NATIVE_INDEPENDENT'][use]=q['INDEPENDENT'];out['NATIVE_POOL'][use]=(q['INDEPENDENT']+q['JOINT'])/2;out['ANCHORED_FIXED_POINT'][use]=q['FIXED_POINT'];ev|=use;records.append(dict(cut=cut,margins=r))
   if it==0:
    oldtruth=z['truth'].copy();z['truth'][~prefix]=1e9;qq,_=calibrate_current(z,raw['INDEPENDENT'],prefix,use);z['truth']=oldtruth
    check('Europe_future_mutation_'+str(seed),np.array_equal(qq,q['INDEPENDENT']))
  check('Europe_point_unchanged_'+str(seed),point==digest(z['point']));check('Europe_eval_notFIT_'+str(seed),not np.any(ev&z['fit']))
  z['late']=ev;ud=np.unique(z['days'][ev]);mid=len(ud)//2;z['late_a']=ev&np.isin(z['days'],ud[:mid]);z['late_b']=ev&np.isin(z['days'],ud[mid:])
  # Relative thresholds are same current anchored baseline across all three heads.
  z['thresholds']=np.column_stack([z['lo'],z['hi'],out['ANCHORED_FIXED_POINT'][:,3],out['ANCHORED_FIXED_POINT'][:,9]])
  results[str(seed)]={}
  for name,q in out.items():
   check(name+'_rolling_monotone_'+str(seed),np.all(np.diff(q[ev],axis=1)>0));results[str(seed)][name]=dc.summarize(z,q)
   save(f'Europe_{seed}_{name}.npz',quantiles=q[ev],origin=z['origin'][ev],h=z['h'][ev],node=z['node'][ev])
  support[str(seed)]=dict(postfit_days=len(np.unique(z['days'][post])),evaluation_days=len(ud),evaluation_origins=len(np.unique(z['origin'][ev])),cells=int(ev.sum()),weeks=len(np.unique((ud+3)//7)),first_UTC=dc.prev.utc(z['cut'][ev].min()),last_UTC=dc.prev.utc(z['cut'][ev].max()),initial_mature_days=schedule[0]['mature_days'],excluded_initial_or_immature_days=len(np.unique(z['days'][post&~ev])),scope='2015 historical replay; original checkpoint selection exposure retained; additional calendar is not independent confirmation')
  recipes[str(seed)]=records;del z,raw,out,q;gc.collect()
 cases=[results[str(s)] for s in SEEDS];summary={k:aggregate(cases,k) for k in cases[0]};comparisons={}
 for name in ['NATIVE_INDEPENDENT','NATIVE_POOL']:
  comparisons[name]=dict(**boot(cases,name,'ANCHORED_FIXED_POINT','Europe'),seed_wins=sum(c[name]['metrics']['late']['wis13']<c['ANCHORED_FIXED_POINT']['metrics']['late']['wis13'] for c in cases),halves={part:dict(candidate=aggregate(cases,name,part)['wis13'],reference=aggregate(cases,'ANCHORED_FIXED_POINT',part)['wis13'],seed_wins=sum(c[name]['metrics'][part]['wis13']<c['ANCHORED_FIXED_POINT']['metrics'][part]['wis13'] for c in cases)) for part in ['late_a','late_b']})
 write(D/'EUROPE_ROLLING_RESULTS.json',results);write(D/'EUROPE_ROLLING_RECIPES.json',recipes);write(D/'EUROPE_ROLLING_SUMMARY.json',dict(summary=summary,comparisons=comparisons,support=support))
 return summary
