# Recorded study workflow. See docs/REPRODUCTION_LEVELS.md before execution.
"""One frozen expert library, four history-by-information arms, no late V7 backfill."""
from train_experts import *
import pickle,gc
def qmean(q):
 import numpy as np
 lev=np.asarray(LEVELS);return ((q[...,:-1]+q[...,1:])*.5*np.diff(lev)).sum(-1)+.005*(q[...,0]-(q[...,1]-q[...,0])/np.log(2))+.005*(q[...,-1]+(q[...,-1]-q[...,-2])/np.log(2))
def frame():
 import numpy as np
 d=Data();folder=W/'frames';folder.mkdir(exist_ok=True)
 for role,oo in d.roles.items():
  if role in ['ALL','ISSUE']:continue
  p=folder/(role+'.npy');receipt=p.with_suffix('.json')
  if receipt.exists():assert sha(p)==read(receipt)['sha256'];continue
  out=np.lib.format.open_memmap(p,mode='w+',dtype='float32',shape=(len(oo)*360,47))
  # 29last +6price-history moments +node+horizon +8native+availability+age =47.
  for st in range(0,len(oo),16):
   guard();ii=oo[st:st+16];xx,src,raw=d.batch(ii);stats=np.stack([xx[:,-t:,:,0].mean(1) for t in [12,36,288]]+[xx[:,-t:,:,0].std(1) for t in [12,36,288]],-1)
   z=np.column_stack([np.repeat(xx[:,-1].reshape(-1,29),12,axis=0),np.repeat(stats.reshape(-1,6),12,axis=0),np.tile(np.repeat(np.arange(30),12),len(ii)),np.tile((np.arange(12)+1)/12,len(ii)*30),np.repeat(src,360,axis=0)]).astype('float32')
   assert z.shape==(len(ii)*360,47) and np.isfinite(z).all();out[st*360:(st+len(ii))*360]=z
  out.flush();out._mmap.close();save(receipt,dict(at=now(),sha256=sha(p),columns=47,native_slice=[37,45],node_column=35,origins=len(oo),no_targets_used=True))
 d.x._mmap.close();d.src._mmap.close()
def hgb_fit(x,y,path,seed,weights=None):
 from memory_safe_hgb import FixedNodeHGB as HistGradientBoostingRegressor
 from threadpoolctl import threadpool_limits
 if path.exists():
  assert sha(path)==read(path.with_suffix('.json'))['sha256']
  with path.open('rb') as f:return pickle.load(f)
 guard();started=time.monotonic()
 kw=dict(loss='squared_error',max_iter=60,max_leaf_nodes=7,min_samples_leaf=100,l2_regularization=1.,learning_rate=.05,early_stopping=False,random_state=seed,categorical_features=[35])
 if path.name.startswith('REFERENCE'):kw['loss']='absolute_error'
 working=path.with_suffix('.working.pkl')
 with threadpool_limits(1):
  if working.exists():
   with working.open('rb') as f:m=pickle.load(f)
  else:
   warmkw=dict(kw,max_iter=20,warm_start=True);m=HistGradientBoostingRegressor(**warmkw)
  for count in [20,40,60]:
   if getattr(m,'n_iter_',0)>=count:continue
   tick('HGB_fit',model=path.name,rows=len(y),target_iterations=count);m.set_params(max_iter=count);m.fit(x,y,sample_weight=weights)
   tmp=working.with_suffix('.tmp');tmp.write_bytes(pickle.dumps(m,protocol=5));os.replace(tmp,working)
   tick('HGB_checkpoint',model=path.name,completed_iterations=count,seconds=time.monotonic()-started)
 guard();tmp=path.with_suffix('.tmp');tmp.write_bytes(pickle.dumps(m,protocol=5));os.replace(tmp,path)
 save(path.with_suffix('.json'),dict(at=now(),sha256=sha(path),rows=len(y),columns=x.shape[1],capacity=kw,seconds=time.monotonic()-started))
 return m
def predict(m,x):
 import numpy as np
 out=np.empty(len(x),float)
 for st in range(0,len(x),65536):
  guard();end=min(st+65536,len(x))
  if isinstance(x,np.memmap):
   assert x.flags.c_contiguous
   block=np.memmap(x.filename,mode='r',dtype=x.dtype,offset=x.offset+st*x.strides[0],shape=(end-st,x.shape[1]))
   try:out[st:end]=m.predict(block)
   finally:block._mmap.close()
  else:out[st:end]=m.predict(x[st:end])
 return out
def reference():
 import numpy as np
 with locked('fixed_early_price_reference'):
  sealcheck();frame();receipt=W/'REFERENCE_COMPLETE.json'
  if receipt.exists():
   for p,h in read(receipt)['bindings'].items():assert sha(p)==h
   return
  # Shared deterministic reference, not three independent replicas.
  unit=read(F/'SCALERS.json')['unit'];xx=np.load(W/'frames/EXPERT_FIT.npy',mmap_mode='r');x=np.array(xx,copy=True);xx._mmap.close();x[:,37:45]=0
  with np.load(F/'EXPERT_FIT_LABELS.npz') as z:y=((z['y']-z['last'][:,:,None])/unit).ravel()
  path=W/'REFERENCE.pkl';m=hgb_fit(x,y,path,20260813);del x,y;gc.collect()
  bindings={str(path):sha(path)}
  with np.load(F/'ORIGINS.npz') as z:roles={k:z[k] for k in z.files if k not in ['ALL','ISSUE']}
  d=Data()
  for role,oo in roles.items():
   xx=np.load(W/('frames/'+role+'.npy'),mmap_mode='r');pred=np.empty(len(xx),float)
   for st in range(0,len(xx),65536):
    guard();v=np.array(xx[st:st+65536],copy=True);v[:,37:45]=0;pred[st:st+len(v)]=m.predict(v)
   xx._mmap.close();last=[]
   for st in range(0,len(oo),128):guard();_,_,raw=d.batch(oo[st:st+128]);last.append(raw[:,-1])
   last=np.concatenate(last);point=last[:,:,None]+unit*pred.reshape(-1,30,12);p=W/('REFERENCE_'+role+'.npz');atomic_np(p,origins=oo,point=point);bindings[str(p)]=sha(p)
  save(receipt,dict(at=now(),bindings=bindings,reference='Earlier frozen price-only median HGB residual about last observed price; NOT originalV7.',scope='Same exact model in every risk and evaluation role. OriginalV7 files unchanged.',DEV_targets_read=False))
def gamma(y,r,a,routine):
 import numpy as np
 e=y-r;d=a-r;g=float(np.clip(np.mean(e*d)/max(float(np.mean(d*d)),1e-20),0,1))
 def good(t):
  return np.mean(abs(e-t*d))<=np.mean(abs(e))+1e-12 and (not routine.any() or np.mean(abs((e-t*d)[routine]))<=1.01*np.mean(abs(e[routine]))+1e-12)
 if good(g):return g
 lo=0.;hi=g
 for _ in range(52):
  mid=(lo+hi)/2
  if good(mid):lo=mid
  else:hi=mid
 return lo if lo>1e-10 else 0.
def make_actions(seed,role,info):
 import numpy as np
 import zipfile,shutil
 source=W/str(seed)/(f'I{info}_DYNAMIC_'+role+'.npz')
 cache=W/str(seed)/'action_cache';cache.mkdir(exist_ok=True)
 path=cache/(f'I{info}_{role}_q.npy');receipt=path.with_suffix('.json')
 source_sha=sha(source)
 if not (path.exists() and receipt.exists() and read(receipt).get('source_sha')==source_sha and sha(path)==read(receipt)['sha256']):
  guard();tmp=path.with_suffix('.tmp')
  # Extract the unchanged NPY member with ZIP CRC verification and bounded RAM.
  with zipfile.ZipFile(source) as archive,archive.open('q.npy') as inp,tmp.open('wb') as out:
   while True:
    guard();chunk=inp.read(2**20)
    if not chunk:break
    out.write(chunk)
   out.flush();os.fsync(out.fileno())
  os.replace(tmp,path);save(receipt,dict(source=str(source),source_sha=source_sha,sha256=sha(path)))
 q=np.load(path,mmap_mode='r');assert q.flags.c_contiguous and q.shape[-1]==len(LEVELS)
 shape=q.shape;offset=q.offset;dtype=q.dtype;q._mmap.close();rows=int(np.prod(shape[:-1]))
 act=np.empty((rows,3),float)
 with np.load(W/('REFERENCE_'+role+'.npz')) as z:
  r=z['point'];assert r.size==rows;act[:,0]=r.ravel()
 del r
 for st in range(0,rows,32768):
  guard();end=min(rows,st+32768)
  block=np.memmap(path,mode='r',dtype=dtype,offset=offset+st*len(LEVELS)*dtype.itemsize,shape=(end-st,len(LEVELS)))
  try:act[st:end,1]=qmean(block);act[st:end,2]=block[:,6]
  finally:block._mmap.close()
 return act
def policy_phase(stage,**kw):
 import psutil
 proc=psutil.Process()
 tick(stage,rss_bytes=proc.memory_info().rss,resources=rt.guard(),**kw)
def make_features(role,act,info,mask=None):
 import numpy as np
 p=W/'frames'/(role+'.npy');z=np.load(p,mmap_mode='r');ids=np.flatnonzero(mask) if mask is not None else np.arange(len(z))
 z._mmap.close()
 # sklearn HGB validates float64 input. A disk map avoids a simultaneous
 # full float32+float64 allocation; sample identities/weights are unchanged.
 tmp=W/'frames'/('ACTIVE_'+role+'_'+str(info)+'.npy');x=np.lib.format.open_memmap(tmp,mode='w+',dtype='float64',shape=(len(ids),52));unit=read(F/'SCALERS.json')['unit']
 x.flush();x._mmap.close()
 for st in range(0,len(ids),32768):
  guard();ii=ids[st:st+32768];v=np.empty((len(ii),52),np.float64);z=np.load(p,mmap_mode='r')
  try:v[:,:47]=z[ii]
  finally:z._mmap.close()
  if info==0:v[:,37:45]=0
  v[:,47:]=np.column_stack([act[ii]/unit,(act[ii,1]-act[ii,0])/unit,(act[ii,2]-act[ii,0])/unit])
  # Release mapped pages every block; preserve every row, column and float64 value.
  with tmp.open('r+b') as stream:
   header=np.load(tmp,mmap_mode='r');offset=header.offset;header._mmap.close()
   stream.seek(offset+st*52*8);stream.write(v.tobytes(order='C'));stream.flush();os.fsync(stream.fileno())
  del v
 x=np.load(tmp,mmap_mode='r')
 return x
def fit_policy(seed):
 import numpy as np
 with locked('fixed_expert_four_arm_policy_'+str(seed)):
  sealcheck();stage=W/str(seed);seal=stage/'POLICY_FREEZE.json'
  if seal.exists():
   for p,h in read(seal)['bindings'].items():assert sha(p)==h
   return
  assert (W/'REFERENCE_COMPLETE.json').exists()
  for arm in ['I0_DYNAMIC','I1_DYNAMIC','I1_STATIC','I1_FLAT']:
   rr=read(stage/(arm+'.json'));assert sha(stage/(arm+'.pt'))==rr['sha256']
  unit=float(read(F/'SCALERS.json')['unit'])
  with np.load(F/'RISK_FIT_LABELS.npz') as z:fitissue=z['issue']
  with np.load(F/'RISK_CAL_LABELS.npz') as z:yc=z['y'].ravel().astype(float);last=z['last'];co=z['origins']
  th=read(T/'EARLY_PREFIX_STATE_THRESHOLDS.json');routine=np.broadcast_to((abs(last-np.array(th['center']))<=np.asarray(th['thresholds'])[0])[:,:,None],(len(last),30,12)).ravel()
  recent=np.repeat(fitissue>=int(dt.datetime(2024,7,1,tzinfo=dt.timezone.utc).timestamp()),360)
  roles=['RISK_CAL','HISTORICAL_DEV_CHECK'];details={};bind={}
  for arm,info,short in [('A',0,True),('B',0,False),('C',1,True),('D',1,False)]:
   policy_phase('policy_arm_begin',seed=seed,arm=arm)
   with np.load(F/'RISK_FIT_LABELS.npz') as z:yf=z['y'].ravel().astype(float)
   mf=recent if short else np.ones(len(yf),bool);af=make_actions(seed,'RISK_FIT',info);xf=make_features('RISK_FIT',af,info,mf);rr=yf-af[:,0]
   risk_origins=int(mf.sum()//360)
   models={}
   for k in [1,2]:
    for metric in ['AE','SE']:
     e=yf-af[:,k];target=(abs(rr)-abs(e))/unit if metric=='AE' else (rr*rr-e*e)/(unit*unit)
     path=stage/f'{arm}_a{k}_{metric}.pkl';m=hgb_fit(xf,target[mf],path,seed);models[(k,metric)]=m;bind[str(path)]=sha(path)
   xf._mmap.close();del xf,af,yf,rr,e,target,mf;gc.collect()
   # Select and emit CAL before constructing DEV. No DEV target is accessed.
   # All reductions, grids and tie breaks remain exactly as registered.
   for role in roles:
    policy_phase('policy_actions_begin',seed=seed,arm=arm,role=role)
    ac=make_actions(seed,role,info);xx=make_features(role,ac,info);se=np.zeros_like(ac);ae=np.zeros_like(ac)
    policy_phase('policy_scores_begin',seed=seed,arm=arm,role=role)
    for (k,metric),m in models.items():(ae if metric=='AE' else se)[:,k]=predict(m,xx)
    xx._mmap.close();del xx;gc.collect()
    if role=='RISK_CAL':
     policy_phase('policy_CAL_selection',seed=seed,arm=arm)
     grid=[]
     for lam in [0.,.25,1.,4.]:
      action=np.argmax(se+lam*ae,axis=1);raw=ac[np.arange(len(ac)),action];g=gamma(yc,ac[:,0],raw,routine);point=ac[:,0]+g*(raw-ac[:,0]);err=yc-point
      grid.append(dict(lam=lam,gamma=g,MAE=float(abs(err).mean()),MSE=float((err*err).mean())))
     chosen=min(grid,key=lambda q:(q['MSE'],q['gamma'],q['lam']));details[arm]=dict(selection=chosen,CAL_grid=grid,risk_origins=risk_origins,history='recent' if short else 'full',info=info)
     del action,raw,point,err
    act=np.argmax(se+chosen['lam']*ae,axis=1);raw=ac[np.arange(len(ac)),act];point=ac[:,0]+chosen['gamma']*(raw-ac[:,0]);out=stage/(arm+'_'+role+'_POINT.npz');atomic_np(out,point=point.reshape(-1,30,12),action=act.reshape(-1,30,12));bind[str(out)]=sha(out)
    del ac,se,ae,act,raw,point;gc.collect()
    policy_phase('policy_role_complete',seed=seed,arm=arm,role=role)
   del models,m;gc.collect()
  selected=min(details,key=lambda k:(details[k]['selection']['MSE'],k));save(stage/'POLICY_DETAILS.json',dict(at=now(),arms=details,selected_arm=selected,selection='RISK_CAL only',reference='EARLY_FIXED_REFERENCE, notV7',same_expert_checkpoint_in_all_roles=True,DEV_targets_read=False))
  bind[str(stage/'POLICY_DETAILS.json')]=sha(stage/'POLICY_DETAILS.json')
  for p in [stage/(a+'.pt') for a in ['I0_DYNAMIC','I1_DYNAMIC','I1_STATIC','I1_FLAT']]+[W/'REFERENCE.pkl']:bind[str(p)]=sha(p)
  save(seal,dict(at=now(),selected_arm=selected,bindings=bind,protocol_sha=sha(O/'EXECUTION_PROTOCOL.json'),DEV_targets_read=False,P8_reads=0))
  tick('complete_four_arm_policy_freeze',seed=seed,selected_arm=selected)
if __name__=='__main__':
 W.mkdir(exist_ok=True)
 if sys.argv[1]=='reference':reference()
 elif sys.argv[1]=='policy':fit_policy(int(sys.argv[2]))

