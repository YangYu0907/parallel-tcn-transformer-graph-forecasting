# Recorded historical component workflow. See docs/REPRODUCTION_LEVELS.md.
from common21 import *
def run():
 results={};recipes={}
 for seed in SEEDS:
  progress('Europe_post_pool_CQR',seed=seed);z=dc.prev.panel('Europe',seed);post=z['cal']|z['evaluate'];raw={};point=digest(z['point'])
  for name in ['INDEPENDENT','JOINT','FIXED_POINT']:
   q=load(U/'fits'/f'Europe_{seed}_{name}/raw.npz',['q'])['q'].astype(float)
   if name=='FIXED_POINT':q-=q[:,6,None]
   raw[name]=z['point'][:,None]+z['scale'][:,None]*q
  raw['RAW_POOL']=(raw['INDEPENDENT']+raw['JOINT'])/2
  names=['NATIVE_POOL','ANCHORED_FIXED_POINT','THREE_HEAD_POOL','POST_POOL_DIRECT_CQR_NATIVE','POST_POOL_SHRUNK_ANCHOR'];out={n:np.zeros_like(raw['RAW_POOL']) for n in names}
  issued=np.zeros(len(post),bool);ev=issued.copy();record=[]
  for cut in np.unique(z['cut'][post]):
   prefix=post&(z['available']+86400<cut);use=post&(z['cut']==cut);nd=len(np.unique(z['days'][prefix]))
   if nd<10:continue
   guard();q={};rr={}
   for name in raw:q[name],rr[name]=er.calibrate_current(z,raw[name],prefix,use)
   eligible=issued&prefix;scores=[]
   for w in [.05,.10,.15,.20,.25]:
    value=wis((1-w)*out['POST_POOL_DIRECT_CQR_NATIVE'][eligible]+w*out['ANCHORED_FIXED_POINT'][eligible],z['truth'][eligible]) if eligible.any() else 0.
    scores.append(dict(anchor_weight=w,past_issued_mature_WIS=value))
   chosen=min(scores,key=lambda r:(r['past_issued_mature_WIS'],r['anchor_weight']))['anchor_weight']
   values={'NATIVE_POOL':(q['INDEPENDENT']+q['JOINT'])/2,'ANCHORED_FIXED_POINT':q['FIXED_POINT'],'POST_POOL_DIRECT_CQR_NATIVE':q['RAW_POOL'],'POST_POOL_SHRUNK_ANCHOR':(1-chosen)*q['RAW_POOL']+chosen*q['FIXED_POINT']}
   values['THREE_HEAD_POOL']=(values['NATIVE_POOL']+q['FIXED_POINT'])/2
   # Future-label mutation audit on first evaluated date.
   if nd>=45 and not ev.any():
    y=z['truth'].copy();z['truth'][~prefix]=1e12;qq,_=er.calibrate_current(z,raw['RAW_POOL'],prefix,use);z['truth']=y;check('EU_pool_future_mutation_'+str(seed),np.array_equal(qq,q['RAW_POOL']))
   for n,v in values.items():out[n][use]=v
   issued|=use
   if nd>=45:ev|=use
   check('EU_pool_mature_'+str(seed)+str(int(cut)),np.all(z['available'][prefix]+86400<cut) and not (prefix&use).any())
   record.append(dict(cut=int(cut),mature_days=nd,eval=nd>=45,weight_training_cells=int(eligible.sum()),anchor_weight=chosen,weight_grid=scores,margins=rr))
  old=load(OLD/f'Europe_{seed}_NATIVE_POOL.npz',['quantiles','origin','h','node'])
  check('Europe_same136panel_'+str(seed),np.array_equal(z['origin'][ev],old['origin']) and np.array_equal(z['h'][ev],old['h']) and np.array_equal(z['node'][ev],old['node']))
  check('Europe_old_pool_reproduction_'+str(seed),np.array_equal(out['NATIVE_POOL'][ev],old['quantiles']))
  z['late']=ev;days=np.unique(z['days'][ev]);z['late_a']=ev&np.isin(z['days'],days[:len(days)//2]);z['late_b']=ev&~z['late_a'];z['thresholds']=np.column_stack([z['lo'],z['hi'],out['ANCHORED_FIXED_POINT'][:,3],out['ANCHORED_FIXED_POINT'][:,9]])
  rows={}
  for name,q in out.items():
   check('EU_pool_monotone_'+name+str(seed),np.all(np.diff(q[ev],axis=1)>0))
   rows[name]=dc.summarize(z,q)
   save21(f'Europe_{seed}_{name}.npz',quantiles=q[ev],origin=z['origin'][ev],h=z['h'][ev],node=z['node'][ev])
  check('EU_pool_point_unchanged_'+str(seed),point==digest(z['point']));results[str(seed)]=rows;recipes[str(seed)]=record
  write(D/'EUROPE_POOL_RESULTS.json',results);write(D/'EUROPE_POOL_RECIPES.json',recipes)
  del z,raw,out;gc.collect()
 cases=[results[str(s)] for s in SEEDS];summary={k:aggregate(cases,k) for k in cases[0]};comparisons={};gates={}
 for n in ['POST_POOL_DIRECT_CQR_NATIVE','POST_POOL_SHRUNK_ANCHOR']:
  comparisons[n]=probability_compare(cases,n,['ANCHORED_FIXED_POINT','NATIVE_POOL','THREE_HEAD_POOL'],'Europe')
  checks=dict(CI_positive_anchor=comparisons[n]['ANCHORED_FIXED_POINT']['ci95'][0]>0,WIS_no_worse_native=summary[n]['wis13']<=summary['NATIVE_POOL']['wis13'],three_seed_anchor=comparisons[n]['ANCHORED_FIXED_POINT']['seed_wins']==3)
  for d,s,l in itertools.product(['fixed','relative'],['low','high'],['brier','logloss']):
   k=f'{d}_{s}_{l}';checks[k+'_net_improve_anchor']=summary[n][k]<summary['ANCHORED_FIXED_POINT'][k]
  gates[n]=dict(passed=all(checks.values()),checks=checks,failed=[k for k,v in checks.items() if not v])
 write(D/'EUROPE_POOL_SUMMARY.json',dict(summary=summary,comparisons=comparisons,gates=gates,calibration='Same nonnegative CQR statistic and 80/90 interpolation as prior; only pooling/calibration order changed in direct arm.',scope='136 historical replay days; published market-day indexing retained, 21 week blocks; not new independent test'))
