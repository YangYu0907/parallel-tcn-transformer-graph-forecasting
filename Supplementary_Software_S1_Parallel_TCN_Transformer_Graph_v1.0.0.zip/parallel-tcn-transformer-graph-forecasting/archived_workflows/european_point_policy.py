# Recorded study workflow. See docs/REPRODUCTION_LEVELS.md before execution.
"""Same reference/mean/median utility policy on Europe; no evaluation-driven graph choice."""
from europe_adapter import *
from baseline_fit import tree,pred_tree,fit_family
import pickle

def frames_and_reference():
    import numpy as np
    with locked('Europe_frozen_reference_and_external_baselines'):
        sealcheck();parent_complete();d=EuropeanData();folder=EW/'frames';folder.mkdir(exist_ok=True)
        frames={};labels={};last={}
        for role,oo in d.roles.items():
            if role in ['ALL','ISSUE']:continue
            p=folder/(role+'.npy')
            if not p.exists():
                rows=[]
                for st in range(0,len(oo),128):
                    guard();xx,src,raw=d.batch(oo[st:st+128]);n=len(xx)
                    stats=np.stack([xx[:,-t:,:,0].mean(1) for t in [12,36,168]]+[xx[:,-t:,:,0].std(1) for t in [12,36,168]],-1)
                    rows.append(np.column_stack([np.repeat(xx[:,-1].reshape(-1,4),24,0),np.repeat(stats.reshape(-1,6),24,0),np.tile(np.repeat(np.arange(3),24),n),np.tile((np.arange(24)+1)/24,n*3),np.repeat(src,72,0)]))
                np.save(p,np.concatenate(rows).astype('float64'))
            frames[role]=np.load(p,mmap_mode='r')
            v=np.concatenate([d.batch(oo[st:st+128])[2][:,-1] for st in range(0,len(oo),128)])
            last[role]=np.broadcast_to(v[:,:,None],(len(oo),3,24)).ravel().astype(float)
            if role in ['EXPERT_FIT','EXPERT_VALID','EXPERT_CAL']:labels[role]=d.labels(role)['y'].ravel().astype(float)
        dest=EW/'external_baselines'
        fit_family(frames,labels,last,d.unit,10,3,dest,dict(inputs='identical European observable features, no CAISO netload equivalent',point_comparison='same training cutoff; tabular summary representation'))
        m=pickle.loads((dest/'HGB_absolute_error.pkl').read_bytes());bindings={}
        for role,x in frames.items():
            p=EW/('REFERENCE_'+role+'.npz')
            if not p.exists():atomic_np(p,point=(last[role]+d.unit*pred_tree(m,x)).reshape(-1,3,24),origins=d.roles[role])
            bindings[str(p)]=sha(p)
        save(EW/'REFERENCE_COMPLETE.json',dict(at=now(),bindings=bindings,source_model_sha=sha(dest/'HGB_absolute_error.pkl'),same_as_CAISO_rule=True))

def policy(seed):
    import numpy as np
    import train_policy as original
    with locked('Europe_full_history_risk_policy_'+str(seed)):
        sealcheck();d=EuropeanData();stage=EW/str(seed);freeze=stage/'POLICY_FREEZE.json'
        if freeze.exists():
            for p,h in read(freeze)['bindings'].items():assert sha(p)==h,p
            return
        th=read(EF/'STATE_THRESHOLDS.json');cal=d.labels('RISK_CAL');last=cal['last']
        routine=np.broadcast_to((abs(last-np.asarray(th['center']))<=np.asarray(th['thresholds'])[0])[:,:,None],cal['y'].shape).ravel()
        bind={};detail={}
        for arm in ['I1_DYNAMIC','I1_STATIC','I1_FLAT']:
            r=read(stage/(arm+'.json'));assert sha(stage/(arm+'.pt'))==r['sha256'];bind[str(stage/(arm+'.pt'))]=r['sha256']
            models={}
            def features(role):
                q=np.load(stage/(arm+'_'+role+'.npz'))['q'];ref=np.load(EW/('REFERENCE_'+role+'.npz'))['point']
                a=np.stack([ref,qmean(q),q[...,6]],-1).reshape(-1,3)
                x0=np.load(EW/'frames'/(role+'.npy'));x=np.column_stack([x0,a/d.unit,(a[:,1]-a[:,0])/d.unit,(a[:,2]-a[:,0])/d.unit])
                return x,a
            xf,af=features('RISK_FIT');yf=d.labels('RISK_FIT')['y'].ravel().astype(float);e=yf-af[:,0]
            for k in [1,2]:
                er=yf-af[:,k]
                for metric,t in [('AE',(abs(e)-abs(er))/d.unit),('SE',(e*e-er*er)/d.unit**2)]:
                    p=stage/f'{arm}_a{k}_{metric}.pkl';models[k,metric]=tree(xf,t,p,'squared_error',10,seed);bind[str(p)]=sha(p)
            for role in ['RISK_CAL','HISTORICAL_DEV_CHECK']:
                x,a=features(role);se=np.zeros_like(a);ae=np.zeros_like(a)
                for (k,metric),m in models.items():(ae if metric=='AE' else se)[:,k]=pred_tree(m,x)
                if role=='RISK_CAL':
                    y=cal['y'].ravel().astype(float);grid=[]
                    for lam in [0.,.25,1.,4.]:
                        choice=np.argmax(se+lam*ae,1);raw=a[np.arange(len(a)),choice];g=original.gamma(y,a[:,0],raw,routine);err=y-(a[:,0]+g*(raw-a[:,0]))
                        grid.append(dict(lam=lam,gamma=g,MAE=float(abs(err).mean()),MSE=float((err*err).mean())))
                    selected=min(grid,key=lambda z:(z['MSE'],z['gamma'],z['lam']));detail[arm]=dict(selection=selected,CAL_grid=grid)
                choice=np.argmax(se+selected['lam']*ae,1);point=a[:,0]+selected['gamma']*(a[np.arange(len(a)),choice]-a[:,0]);p=stage/(arm+'_'+role+'_POLICY.npz');atomic_np(p,point=point.reshape(-1,3,24),action=choice.reshape(-1,3,24));bind[str(p)]=sha(p)
            tick('Europe_policy_complete',seed=seed,arm=arm)
        save(stage/'POLICY_DETAILS.json',dict(at=now(),arms=detail,no_cross_graph_winner_selection=True));bind[str(stage/'POLICY_DETAILS.json')]=sha(stage/'POLICY_DETAILS.json')
        save(freeze,dict(at=now(),bindings=bind,evaluation_targets_read=False))

def evaluate():
    import numpy as np
    with locked('Europe_complete_matrix_evaluation'):
        sealcheck();bind={}
        for seed in SEEDS:
            s=read(EW/str(seed)/'POLICY_FREEZE.json')
            for p,h in s['bindings'].items():assert sha(p)==h,p
            bind[str(EW/str(seed)/'POLICY_FREEZE.json')]=sha(EW/str(seed)/'POLICY_FREEZE.json')
            for arm in ['I1_DYNAMIC','I1_STATIC','I1_FLAT']:
                p=EW/str(seed)/(arm+'_HISTORICAL_DEV_CHECK.npz');bind[str(p)]=sha(p)
        for p,h in read(EW/'external_baselines/FREEZE.json')['bindings'].items():assert sha(p)==h;bind[p]=h
        save(EW/'ALL_PREDICTIONS_FROZEN.json',dict(at=now(),bindings=bind,all_choices_fixed=True,targets_read=False))
        d=EuropeanData();oo=d.roles['HISTORICAL_DEV_CHECK']
        save(EW/'TARGET_ACCESS.json',dict(at=now(),freeze_sha=sha(EW/'ALL_PREDICTIONS_FROZEN.json'),origins=oo.tolist(),source=str(RAW_ARCHIVE),scope='Previously admitted/viewed2015 only, no2016/2017 access'))
        raw=np.load(EF/'raw_archive.npy',mmap_mode='r');y=np.stack([raw[o:o+24].T for o in oo]).astype(float);last=np.asarray(raw[oo-1]);raw._mmap.close()
        with np.load(RAW_ARCHIVE) as z:times=z['timestamps'].astype('datetime64[s]').astype('int64')
        th=read(EF/'STATE_THRESHOLDS.json');c=np.asarray(th['center']);t=np.asarray(th['thresholds']);state=(abs(y-c[None,:,None])>t[0][None,:,None]).astype('int8')+(abs(y-c[None,:,None])>t[1][None,:,None]).astype('int8')+3*(abs(last-c)>t[1])[:,:,None]
        yy=y.ravel();ss=state.ravel();days=np.repeat(times[oo-1]//86400,72);pred={};qs={}
        for arm in ['I1_DYNAMIC','I1_STATIC','I1_FLAT']:
            qs[arm]=[np.load(EW/str(seed)/(arm+'_HISTORICAL_DEV_CHECK.npz'))['q'] for seed in SEEDS];pred[arm]=np.stack([qmean(q).ravel() for q in qs[arm]])
            pred[arm+'_POLICY']=np.stack([np.load(EW/str(seed)/(arm+'_HISTORICAL_DEV_CHECK_POLICY.npz'))['point'].ravel() for seed in SEEDS])
        pred['DLINEAR']=np.stack([np.load(EW/str(seed)/'ANCHOR_HISTORICAL_DEV_CHECK.npz')['point'].ravel() for seed in SEEDS])
        for name in ['HGB','RIDGE']:pred[name]=np.repeat(np.load(EW/'external_baselines'/(name+'_HISTORICAL_DEV_CHECK.npz'))['point'][None],3,0)
        ref=np.load(EW/'REFERENCE_HISTORICAL_DEV_CHECK.npz')['point'];pred['REFERENCE']=np.repeat(ref.reshape(1,-1),3,0);pred['PERSISTENCE']=np.repeat(np.broadcast_to(last[:,:,None],y.shape).reshape(1,-1),3,0)
        masks={'all':np.ones(len(yy),bool),**{'S'+str(k):ss==k for k in range(6)},'near':np.tile(np.arange(24)<18,len(oo)*3),'far':np.tile(np.arange(24)>=18,len(oo)*3)}
        for n,country in enumerate(['FR','DE','BE']):masks[country]=np.tile(np.repeat(np.arange(3)==n,24),len(oo))
        # Observable high-coupling threshold from FIT inputs only, never2015 values.
        def moments(origins):
            vol=[];disp=[]
            for st in range(0,len(origins),128):
                _,_,r=d.batch(origins[st:st+128]);vol.extend(r[:,-24:].std(1).mean(1));disp.extend(r[:,-24:].std(2).mean(1))
            return np.asarray(vol),np.asarray(disp)
        vf,df=moments(d.roles['EXPERT_FIT']);v,dis=moments(oo);high=(v>np.quantile(vf,.7))&(dis>np.quantile(df,.7));masks['high_q70']=np.repeat(high,72)
        result={name:{part:metrics(yy,p,m) for part,m in masks.items() if m.any()} for name,p in pred.items()}
        pairs=[('I1_DYNAMIC',b) for b in ['I1_STATIC','I1_FLAT','HGB','RIDGE','DLINEAR','PERSISTENCE']]+[('I1_DYNAMIC_POLICY',b) for b in ['REFERENCE','HGB','RIDGE','DLINEAR']]
        comps={a+'_vs_'+b:{part:compare(yy,pred[a],pred[b],days,m) for part,m in masks.items() if m.any()} for a,b in pairs}
        primary={a+'_'+metric:comps[a]['all']['seven_day'][metric+'_centered_bootstrap_p'] for a in ['I1_DYNAMIC_vs_I1_STATIC','I1_DYNAMIC_vs_I1_FLAT'] for metric in ['MAE','RMSE']}
        spec=importlib.util.spec_from_file_location('eu_distribution_review',P/'distribution_review.py');dr=importlib.util.module_from_spec(spec);spec.loader.exec_module(dr);dr.F=EF;dr.W=EW
        distribution={a:{str(s):dr.review(y,q,ref,masks) for s,q in zip(SEEDS,arr)} for a,arr in qs.items()}
        atomic_np(EW/'SCORING_ARCHIVE.npz',y=y,states=state,issue=times[oo-1],**{k:v.reshape(3,*y.shape) for k,v in pred.items()})
        save(EW/'RESULTS.json',dict(at=now(),origins=len(oo),dates=len(oo),markets=['FR','DE','BE'],metrics=result,comparisons=comps,graph_primary_Holm=holm(primary),distribution_secondary=distribution,point_policy_has_no_CDF=True,scope='Same model family; hourly3market task; already-viewed2015 retrospective evidence; noCAISOexternalfields',high_q70_origins=int(high.sum())))
        # Independent arithmetic formula, rather than trusting the score function.
        checks=[]
        for k,p in pred.items():
            abs_sum=sum(float(np.abs(yy-row).sum()) for row in p);sq_sum=sum(float(np.dot(yy-row,yy-row)) for row in p)
            checks.append(dict(model=k,MAE=abs(abs_sum/(3*len(yy))-result[k]['all']['MAE'])<1e-9,RMSE=abs(np.sqrt(sq_sum/(3*len(yy)))-result[k]['all']['RMSE'])<1e-9))
        assert all(x['MAE'] and x['RMSE'] for x in checks)
        save(EW/'ARITHMETIC_REVIEW.json',dict(at=now(),passed=True,checks=checks,independent_formula=True,external_reviewer=False))
        save(EW/'COMPLETE.json',dict(at=now(),results_sha=sha(EW/'RESULTS.json'),review_sha=sha(EW/'ARITHMETIC_REVIEW.json'),matrix_complete=True,all_directions_retained=True))

if __name__=='__main__':
    if sys.argv[1]=='reference':frames_and_reference()
    elif sys.argv[1]=='policy':policy(int(sys.argv[2]))
    else:evaluate()
