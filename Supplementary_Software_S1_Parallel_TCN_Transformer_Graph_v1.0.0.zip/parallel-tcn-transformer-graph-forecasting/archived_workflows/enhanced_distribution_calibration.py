# Recorded historical component workflow. See docs/REPRODUCTION_LEVELS.md.
from batch_common import *
def make_outer(z,original=None):
 frozen,rec=frozen_group(z);floor=frozen['STATE_GROUP_AWARE_OUTER_CAP25'] if original is None else original
 high=np.zeros(len(floor),bool);th=[]
 for h in np.unique(z['h']):
  v=float(np.quantile(z['spread'][z['early']&(z['h']==h)],.85));high[z['h']==h]=z['spread'][z['h']==h]>=v;th.append(dict(h=int(h),raw_q85=v))
 group=((z['group']==1)|((z['group']==0)&high)).astype(int)
 raw=floor.copy();recipes=[]
 for h in np.unique(z['h']):
  m,r=dc.calibration_mask(z,group,1,h);use=(group==1)&(z['h']==h);r['h']=int(h);r['margins']=[]
  if r['supported']:
   for j in [10,11,12]:
    c=dc.prev.fq((z['truth'][m]-floor[m,j])/z['scale'][m],Q[j]);raw[use,j]+=c*z['scale'][use];r['margins'].append(c)
  recipes.append(r)
 for j in [10,11,12]:raw[:,j]=np.maximum(raw[:,j],raw[:,j-1]+1e-8)
 _,ix=np.unique(z['cut'],return_inverse=True);base=z['base'];bw=np.bincount(ix,weights=base[:,-1]-base[:,0])
 used=np.bincount(ix,weights=floor[:,-1]-floor[:,0]-(base[:,-1]-base[:,0]));extra=np.bincount(ix,weights=raw[:,-1]-floor[:,-1]);out={};caps={}
 for cap,name in zip([.25,.35],OUTER_NAMES):
  check(name+'_floor_feasible',np.all(used<=cap*bw+1e-8))
  f=np.minimum(1,np.divide(np.maximum(0,cap*bw-used),extra,out=np.ones_like(extra),where=extra>0))
  q=floor.copy();q[:,10:]=floor[:,10:]+f[ix,None]*(raw[:,10:]-floor[:,10:])
  ratio=np.bincount(ix,weights=q[:,-1]-q[:,0])/bw
  check(name+'_cap99',ratio.max()<=1+cap+1e-10)
  check(name+'_inner_exact',np.array_equal(q[:,:10],floor[:,:10]))
  check(name+'_G2_exact',np.array_equal(q[z['group']==2],floor[z['group']==2]))
  out[name]=q;caps[name]=dict(max_issue99=float(ratio.max()),factor_min=float(f.min()))
 return out,dict(raw_disagreement_thresholds=th,new_group_CAL_cells=int((group.astype(bool)&z['early']).sum()),margins=recipes,caps=caps)
def state_table(z,q):
 out={}
 for s in range(6):
  m=z['late']&(z['state']==s);y=z['truth'][m];qq=q[m];e=y[:,None]-qq
  out[str(s)]=dict(cells=int(m.sum()),days=len(np.unique(z['days'][m])),wis13=float((abs(e)+(2*Q-1)*e).mean()),coverage90=float(((y>=qq[:,3])&(y<=qq[:,9])).mean()),coverage99=float(((y>=qq[:,0])&(y<=qq[:,12])).mean()))
 return out
def record(z,models,rows,seed,states):
 for name,q in models.items():
  check(name+'_finite',np.isfinite(q).all());check(name+'_monotone',np.all(np.diff(q,axis=1)>0))
  rows[name]=dc.summarize(z,q);states[name]=state_table(z,q)
  for kind in ['CAL','EVAL_HINDSIGHT']:
   eq,f=dc.prev.equalwidth(z,q,kind);rows['EQ_'+kind+'_'+name]=dc.summarize(z,eq);rows['EQ_'+kind+'_'+name]['constant_factor']=f
  save(f'probability_{seed}_{name}.npz',quantiles=q[z['late']])
def run():
 results={};recipes={};states={}
 old=read(OLD/'PROBABILITY_RESULTS.json')
 for seed in SEEDS:
  progress('outer_extension',seed=seed);z=dc.panel('CAISO',seed,'ANCHOR');p=digest(z['point']);models,r=make_outer(z)
  frozen,_=frozen_group(z);qold=frozen['STATE_GROUP_AWARE_OUTER_CAP25']
  saved=load(OLD/f'probability_{seed}_STATE_GROUP_AWARE_OUTER_CAP25.npz',['quantiles'])['quantiles']
  check('old_winner_exact_'+str(seed),np.array_equal(qold[z['late']],saved))
  rows={k:old[str(seed)][k] for k in ['STATIC','STATE_ADD','EQ_EVAL_HINDSIGHT_STATE_ADD','STATE_GROUP_AWARE_OUTER_CAP25']}
  states[str(seed)]={'STATIC':state_table(z,z['base']),'STATE_GROUP_AWARE_OUTER_CAP25':state_table(z,qold)}
  record(z,models,rows,seed,states[str(seed)])
  yy=z['truth'].copy();z['truth'][z['late']]=1e9;mut,_=make_outer(z);z['truth']=yy
  for name in models:check(name+'_no_EVAL_fit_'+str(seed),digest(mut[name])==digest(models[name]))
  check('point_preserved_'+str(seed),digest(z['point'])==p);results[str(seed)]=rows;recipes[str(seed)]=r
  del z,models,frozen,mut;gc.collect()
 jc.CANDS=OUTER_NAMES;summary=jc.gates([results[str(s)] for s in SEEDS])
 for name in OUTER_NAMES:
  sm=summary['summary'];summary['gates'][name]['all8_net_improve']=all(sm[name][f'{d}_{t}_{l}']<sm['STATIC'][f'{d}_{t}_{l}'] for d in ['fixed','relative'] for t in ['low','high'] for l in ['brier','logloss'])
 write(D/'PROBABILITY_RESULTS.json',results);write(D/'PROBABILITY_SUMMARY.json',summary);write(D/'PROBABILITY_STATES.json',states);write(D/'PROBABILITY_RECIPES.json',recipes)

