# Recorded study workflow. See docs/REPRODUCTION_LEVELS.md before execution.
"""Fixed integer node categories without ColumnTransformer full-matrix copies.
Preserves categorical splits and the same raw feature order for fit and predict.
Validated against installed sklearn on complete30node synthetic data before fits.
"""
import numpy as np
from sklearn.ensemble import HistGradientBoostingRegressor
from sklearn.utils.validation import validate_data
from sklearn.utils import check_random_state
from contextlib import contextmanager

def _file_view(X):
 base=X
 while base is not None:
  if isinstance(base,np.memmap):
   assert X.flags.c_contiguous and X.ndim==2
   return (base.filename,base.offset+X.ctypes.data-base.ctypes.data,X.dtype,X.shape)
  base=getattr(base,'base',None)
 return None

@contextmanager
def _rows(spec,start,end):
 filename,offset,dtype,shape=spec
 block=np.memmap(filename,mode='r',dtype=dtype,offset=offset+start*shape[1]*dtype.itemsize,shape=(end-start,shape[1]))
 try:yield block
 finally:block._mmap.close()

class FixedNodeHGB(HistGradientBoostingRegressor):
 def _preprocess_X(self,X,*,reset):
  X=validate_data(self,X,reset=reset,dtype=[np.float64],ensure_all_finite=False)
  if reset:
   assert self.categorical_features==[35]
   spec=_file_view(X)
   if spec is None:
    vals=X[:,35];assert np.isfinite(vals).all() and np.all(vals==np.floor(vals)) and vals.min()==0 and vals.max()==29
   else:
    lo=float('inf');hi=-float('inf')
    for st in range(0,len(X),32768):
     with _rows(spec,st,min(st+32768,len(X))) as block:
      vals=block[:,35];assert np.isfinite(vals).all() and np.all(vals==np.floor(vals))
      lo=min(lo,float(vals.min()));hi=max(hi,float(vals.max()))
    assert lo==0 and hi==29
   mask=np.zeros(X.shape[1],dtype=bool);mask[35]=True
   self.is_categorical_=mask;self._is_categorical_remapped=mask;self._preprocessor=None
   categories=[None]*X.shape[1];categories[35]=np.arange(30,dtype=np.float64)
   return X,categories
  return X

 def _bin_data(self,X,is_training_data):
  spec=_file_view(X)
  if spec is None:return super()._bin_data(X,is_training_data)
  mapper=self._bin_mapper
  if is_training_data:
   # Reproduce sklearn's exact subsample indices AND their original order.
   # Only the file access pattern changes; every row is still used for boosting.
   assert self.early_stopping is False and mapper.subsample is not None
   count=min(len(X),mapper.subsample)
   ids=check_random_state(mapper.random_state).choice(len(X),count,replace=False) if len(X)>count else np.arange(len(X))
   order=np.argsort(ids);sorted_ids=ids[order]
   sample=np.empty((count,X.shape[1]),dtype=X.dtype)
   for st in range(0,len(X),32768):
    end=min(st+32768,len(X));lo=np.searchsorted(sorted_ids,st);hi=np.searchsorted(sorted_ids,end)
    if hi>lo:
     with _rows(spec,st,end) as block:sample[order[lo:hi]]=block[sorted_ids[lo:hi]-st]
   mapper.fit(sample)
   del sample,ids,order,sorted_ids
  binned=np.empty(X.shape,dtype=np.uint8,order='F')
  for st in range(0,len(X),32768):
   end=min(st+32768,len(X))
   with _rows(spec,st,end) as block:binned[st:end]=mapper.transform(block)
  return binned if is_training_data else np.ascontiguousarray(binned)

