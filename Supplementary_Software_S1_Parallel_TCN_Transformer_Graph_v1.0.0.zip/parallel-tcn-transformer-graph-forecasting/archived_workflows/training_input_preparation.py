# Recorded study workflow. See docs/REPRODUCTION_LEVELS.md before execution.
"""Fresh prefix-only inputs for the early expert experiment. No model fits."""
from audit_recount import *
def main():
 import numpy as np
 with locked() as resource:
  gate=read(Q/'TRAINING_ADMISSION_GATE.json');assert gate['source_and_support_passed'],'Source/event gate failed'
  assert read(Q/'SOURCE_EVENT_AUDIT.json')['passed']
  target=Q/'fresh_inputs';target.mkdir(exist_ok=True)
  if (target/'READY.json').exists():
   ready=read(target/'READY.json')
   for p,h in ready['bindings'].items():assert sha(p)==h
   print('Fresh prefix inputs already sealed',flush=True);return
  meta=read('${DATA_ROOT}/CAISO_unified_forward_main_20261019/CAISO/PRETRAIN.json');root=Path(meta['paths']['timestamps_seconds.npy']).parent
  times=np.load(root/'timestamps_seconds.npy',mmap_mode='r')
  if (Q/'EFFECTIVE_ROLE_ORIGINS.npz').exists():
   amendment=read(Q/'COMMON_TRAINING_ADMISSION_AMENDMENT.json');assert amendment['role_file_sha']==sha(Q/'EFFECTIVE_ROLE_ORIGINS.npz')
   with np.load(Q/'EFFECTIVE_ROLE_ORIGINS.npz') as z:roles={k:z[k] for k in z.files}
  else:
   with np.load(T/'ROLE_ORIGINS.npz') as z:roles={k.removesuffix('_ALL_ADMITTED_TRAIN'):z[k] for k in z.files if k.endswith('_ALL_ADMITTED_TRAIN')}
  with np.load(Q/'NATIVE_CALENDAR_FEATURES.npz') as z:src={k:z[k] for k in z.files}
  active=np.unique(np.concatenate(list(roles.values())))
  assert not src['revision_ambiguity'][np.searchsorted(src['origins'],active)].any()
  history=np.zeros(len(times),bool);fitrows=np.zeros(len(times),bool)
  for role,oo in roles.items():
   for o in oo:history[o-288:o]=True
   if role=='EXPERT_FIT':
    for o in oo:fitrows[o-288:o]=True
  fitted=np.flatnonzero(fitrows);used=np.flatnonzero(history)
  assert int(times[fitted[-1]])<stamp('2024-01-01T00:00:00Z')
  # Exact metadata whitelist is already sealed by census; do not open other price archives.
  save(target/'ACCESS_MANIFEST.json',dict(at=now(),source_gate_sha=sha(Q/'TRAINING_ADMISSION_GATE.json'),target_whitelist_sha=sha(T/'ROLE_ORIGINS.npz'),input_history_rows=len(used),scaler_fit_history_rows=len(fitted),scaler_latest=int(times[fitted[-1]]),no_P8=True,only_previously_admitted_TRAIN=True))
  raw=np.load(root/'raw_prices.npy',mmap_mode='r');der=np.load(root/'raw_derived.npy',mmap_mode='r');external=np.load(root/'raw_external.npy',mmap_mode='r');missing=np.load(root/'raw_external_missing.npy',mmap_mode='r');oldx=np.load(root/'features.npy',mmap_mode='r');pub=np.load(root/'forecast_publications_seconds.npy',mmap_mode='r')
  def stats(v,floor):
   v=np.asarray(v,dtype=float);assert np.isfinite(v).all()
   c=np.median(v,axis=0);iq=np.quantile(v,.75,axis=0)-np.quantile(v,.25,axis=0);sd=np.std(v,axis=0)
   return c,np.maximum(np.maximum(iq,.1*sd),floor)
  pc,ps=stats(raw[fitted],1.);dc,ds=stats(der[fitted],1.);ec,es=stats(external[fitted,:2],1.)
  assert not missing[fitted,:2].any()
  fi=np.searchsorted(src['origins'],roles['EXPERT_FIT']);valid=fi[src['available'][fi]];assert len(valid)>0
  nc,ns=stats(src['netload'][valid],1.)
  unit=max(float(np.median(ps[:,0])),1.)
  scales=dict(price_center=pc.tolist(),price_scale=ps.tolist(),derived_center=dc.tolist(),derived_scale=ds.tolist(),external_center=ec.tolist(),external_scale=es.tolist(),native_center=nc.tolist(),native_scale=ns.tolist(),unit=unit,transform='asinh((value-median)/max(IQR,0.1SD,1physicalunit)); monotone input transform, raw-price targets not transformed.',fit_latest=int(times[fitted[-1]]),fit_rows=len(fitted),no_late_scalers=True)
  save(target/'SCALERS.json',scales)
  shape=(len(times),30,29);x=np.lib.format.open_memmap(target/'X.npy',mode='w+',dtype='float32',shape=shape)
  # Unused rows remain explicit NaN; an incorrect origin cannot silently use zero history.
  x[:]=np.nan
  for st in range(0,len(used),512):
   rt.guard();rr=used[st:st+512];v=np.zeros((len(rr),30,29),np.float32)
   v[:,:,:4]=np.arcsinh((raw[rr]-pc)/ps);v[:,:,8:15]=oldx[rr,:,8:15]
   v[:,:,15:17]=np.arcsinh((external[rr,:2]-ec)/es)[:,None,:];v[:,:,17:19]=missing[rr,:2,None].transpose(0,2,1);v[:,:,19:21]=np.nan;v[:,:,21:29]=np.arcsinh((der[rr]-dc)/ds)
   assert np.isfinite(v[:,:,:19]).all() and np.isfinite(v[:,:,21:]).all()
   x[rr]=v
  x.flush();x._mmap.close()
  native=np.zeros((len(src['origins']),10),np.float32);ok=src['available']
  native[ok,:8]=np.arcsinh((src['netload'][ok]-nc)/ns);native[:,8]=(~ok).astype(np.float32);native[:,9]=np.where(ok,np.minimum(src['age'],120)/120,-1)
  np.save(target/'SOURCE.npy',native)
  np.savez_compressed(target/'ORIGINS.npz',**roles,ALL=src['origins'],ISSUE=src['issue'])
  save(target/'TIME_CONTRACT.json',dict(at=now(),roles={k:dict(origins=len(o),first_issue=int(times[o.min()-1]),last_issue=int(times[o.max()-1]),latest_target=int(times[o.max()+11])) for k,o in roles.items()},target_maturity='Per-origin actual publication +24h checked by old immutable census; no role boundary redefinition.',feature_origin='o-1',future_source='Publication+60s<=issue; first-advisory trajectory, not revision innovations.',risk_recent_start='2024-07-01T00:00:00Z',source_control='I0 zeros first8native values only. Availability/age identical, all price histories identical.',target_admission_sha=sha(T/'TARGET_ACCESS_MANIFEST.json')))
  # Save labels by role, with the final history check deliberately separate.
  for role,oo in roles.items():
   if role=='HISTORICAL_DEV_CHECK':continue  # Scoring targets remain closed until the complete policy freeze.
   y=np.empty((len(oo),30,12),np.float32);last=np.empty((len(oo),30),np.float32)
   for st in range(0,len(oo),128):
    rt.guard();ii=oo[st:st+128];y[st:st+len(ii)]=np.asarray(raw[ii[:,None]+np.arange(12),:,0]).transpose(0,2,1);last[st:st+len(ii)]=raw[ii-1,:,0]
   assert np.isfinite(y).all() and np.isfinite(last).all()
   np.savez_compressed(target/(role+'_LABELS.npz'),y=y,last=last,origins=oo,issue=times[oo-1])
  for p,h in read(O/'PROTOCOL.json')['old_v7_protected'].items():assert sha(p)==h
  files=[target/'SCALERS.json',target/'X.npy',target/'SOURCE.npy',target/'ORIGINS.npz',target/'TIME_CONTRACT.json']+list(target.glob('*_LABELS.npz'))
  save(target/'READY.json',dict(at=now(),resource=resource,bindings={str(p):sha(p) for p in files},code_sha=sha(__file__),model_fits=0,training_authorized=False,reason='Fresh datasets ready; full experiment protocol and executable audit must be frozen before fit.'))
  print(json.dumps(dict(ready=True,origins=len(src['origins']),history_rows=len(used),fit_rows=len(fitted),unit=unit,model_fits=0)),flush=True)
if __name__=='__main__':main()

