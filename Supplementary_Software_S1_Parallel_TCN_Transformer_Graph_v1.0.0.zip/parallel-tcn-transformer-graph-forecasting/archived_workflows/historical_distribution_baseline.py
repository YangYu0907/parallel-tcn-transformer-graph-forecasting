# Recorded historical component workflow. See docs/REPRODUCTION_LEVELS.md.
"""Conditional Johnson SU residual head. Fixed point forecasts never replaced."""
from common import *
import numpy as np,gc,math
import probability_revision as prior
import torch
from torch import nn
from torch.nn import functional as F
from scipy.stats import norm,johnsonsu
LEVELS=np.array([.01,.05,.1,.5,.9,.95,.99]);SEL=[1,2,3,4,5]
class JSU(nn.Module):
 def __init__(self,n):
  super().__init__();self.net=nn.Sequential(nn.Linear(n,32),nn.SiLU(),nn.Linear(32,4))
  nn.init.zeros_(self.net[-1].weight);nn.init.zeros_(self.net[-1].bias)
 def forward(self,x):
  v=self.net(x);return v[:,0],F.softplus(v[:,1])+.01,v[:,2],F.softplus(v[:,3])+.1
def nll(y,par):
 mu,scale,a,b=par;z=(y-mu)/scale
 return torch.log(scale)-torch.log(b)+.5*torch.log1p(z*z)+.5*(a+b*torch.asinh(z))**2+.5*math.log(2*math.pi)
def qa():
 torch.set_num_threads(1);torch.set_num_interop_threads(1)
 g=torch.Generator().manual_seed(81);pars=[torch.randn(19,generator=g,dtype=torch.float64),torch.rand(19,generator=g,dtype=torch.float64)+.1,torch.randn(19,generator=g,dtype=torch.float64),torch.rand(19,generator=g,dtype=torch.float64)+.2];y=torch.randn(19,generator=g,dtype=torch.float64)
 mu,s,a,b=[x.numpy() for x in pars];ref=-johnsonsu.logpdf(y.numpy(),a,b,loc=mu,scale=s);gap=float(np.max(abs(nll(y,pars).numpy()-ref)));assert gap<1e-10
 assert torch.autograd.gradcheck(lambda u,v,w,z:nll(y,(u,F.softplus(v)+.01,w,F.softplus(z)+.1)).sum(),tuple(p.requires_grad_() for p in pars))
 q=mu[:,None]+s[:,None]*np.sinh((norm.ppf(LEVELS)[None,:]-a[:,None])/b[:,None]);assert np.allclose(q,johnsonsu.ppf(LEVELS[None,:],a[:,None],b[:,None],loc=mu[:,None],scale=s[:,None]))
 # Split masks are computed before outcome access; altering future targets cannot alter features.
 point=np.zeros((2,30,12));last=np.zeros((2,30,29));ex=np.zeros((2,30,12,5));x=prior.ca_features(last,point,ex,np.zeros(30),np.ones(30))
 future=np.ones_like(point);future*=1e6;assert np.array_equal(x,prior.ca_features(last,point,ex,np.zeros(30),np.ones(30)))
 write(ROOT/'DISTRIBUTION_QA.json',dict(at=now(),status='passed',scipy_nll_max_gap=gap,gradient_check=True,scipy_quantile_check=True,future_target_excluded_from_features=True,source_sha256=sha(Path(__file__))))
def cp_save(path,value):
 path.parent.mkdir(parents=True,exist_ok=True);tmp=path.with_suffix('.tmp');torch.save(value,tmp);os.replace(tmp,path)
def fit_predict(task,seed,d,tick):
 torch.manual_seed(seed);torch.use_deterministic_algorithms(True)
 mask=d['masks'][0].ravel();x=d['X'];y=d['residual'].ravel().astype('float32')
 center=x[mask].mean(0);scale=x[mask].std(0);scale=np.maximum(scale,1e-4);x=((x-center)/scale).astype('float32')
 xf=torch.from_numpy(x[mask]);yf=torch.from_numpy(y[mask]);model=JSU(x.shape[1]);opt=torch.optim.AdamW(model.parameters(),lr=.001,weight_decay=.0001)
 rng=np.random.default_rng(seed);p=ROOT/'distribution_models'/f'{task}_{seed}.pt';epoch=0;offset=0;order=None;history=[]
 if p.exists():
  c=torch.load(p,map_location='cpu',weights_only=False);assert c['source_sha']==sha(Path(__file__));model.load_state_dict(c['model']);opt.load_state_dict(c['optimizer']);rng.bit_generator.state=c['rng'];torch.set_rng_state(c['torch_rng']);epoch=c['epoch'];offset=c['offset'];order=c['order'];history=c['history']
 def save():cp_save(p,dict(model=model.state_dict(),optimizer=opt.state_dict(),rng=rng.bit_generator.state,torch_rng=torch.get_rng_state(),epoch=epoch,offset=offset,order=order,history=history,center=center,scale=scale,source_sha=sha(Path(__file__))))
 try:
  while epoch<30:
   if order is None:order=rng.permutation(len(xf));offset=0
   model.train()
   while offset<len(order):
    if offset%(1024*32)==0:save();tick(task=task,seed=seed,epoch=epoch+1,offset=offset)
    ix=order[offset:offset+1024];opt.zero_grad(set_to_none=True);loss=nll(yf[ix],model(xf[ix])).mean();assert torch.isfinite(loss);loss.backward();torch.nn.utils.clip_grad_norm_(model.parameters(),1.);opt.step();offset+=len(ix)
   history.append(dict(epoch=epoch+1,last_minibatch_nll=float(loss.detach())));epoch+=1;offset=0;order=None;save()
  model.eval();pars=[]
  with torch.no_grad():
   for i in range(0,len(x),4096):
    tick(task=task,seed=seed,step='distribution_inference');pars.append(np.stack([p.numpy() for p in model(torch.from_numpy(x[i:i+4096]))],-1))
  par=np.concatenate(pars).astype(float);mu,s,a,b=par.T
  q=mu[:,None]+s[:,None]*np.sinh((norm.ppf(LEVELS)[None,:]-a[:,None])/b[:,None]);assert np.isfinite(q).all(),'Numerical overflow; no clipping or score-dependent repair'
  shape=(*d['y'].shape,len(LEVELS));return q.reshape(shape),par.reshape((*d['y'].shape,4)),history
 except Exception:save();raise
def main():
 with numeric('reviewer v2 conditional distribution fixed development'):
  verify_sources();qa();tick=budget('distribution',3600);rows=[]
  if not (ROOT/'DISTRIBUTION_IMPLEMENTATION.json').exists():
   write(ROOT/'DISTRIBUTION_IMPLEMENTATION.json',dict(at=now(),source_sha256=sha(Path(__file__)),protocol_sha256=sha(ROOT/'PROTOCOL.json'),registered_before_fit=True,shape_constraints='scale=softplus+.01; b=softplus+.1; these numeric floors fix distribution parameterization, no outcome clipping',fit_normalization='feature means/std fitted only on fit partition; scale floor1e-4',epochs=30,selection='final fixed epoch, no early selection on calibration/evaluation',point='original fixed point output unchanged; conditional median separate'))
  assert read(ROOT/'DISTRIBUTION_IMPLEMENTATION.json')['source_sha256']==sha(Path(__file__))
  for task in ['CAISO','Europe']:
   for seed in SEEDS:
    scorepath=ROOT/'distribution_scores'/f'{task}_{seed}.json'
    if scorepath.exists():rows+=read(scorepath);continue
    tick(task=task,seed=seed,step='load');d=prior.load_data(task,seed);q,par,hist=fit_predict(task,seed,d,tick);ev=d['role']==2
    calibrated,expansion,counts=prior.calibrate(q[...,SEL],d['residual'],d['masks'][1])
    original=np.load(FIRST/'probability_predictions'/task/f'{seed}.npz');assert np.array_equal(original['point'],d['point'][ev]);assert np.array_equal(original['truth'],d['y'][ev])
    payload=dict(truth=d['y'][ev],point=d['point'][ev],states=d['state'][ev],origin=d['origin'][ev],cutoff=d['cutoff'][ev],parameters=par[ev],quantile_levels=LEVELS,raw_seven=d['point'][ev,...,None]+q[ev]*d['scale'][None,:,None,None],expansion=expansion)
    arms={'HIST_CAL':original['HIST_CAL'],'CQR_CAL':original['CQR_CAL'],'JSU_RAW':d['point'][ev,...,None]+q[ev][...,SEL]*d['scale'][None,:,None,None],'JSU_CAL':d['point'][ev,...,None]+calibrated[ev]*d['scale'][None,:,None,None]};rr=[]
    for arm,pred in arms.items():
     payload[arm]=pred;ma=prior.metric_arrays(d['y'][ev],pred)
     for state in ['overall']+list(np.unique(d['state'][ev])):
      m=np.ones(d['y'][ev].shape,bool) if state=='overall' else d['state'][ev]==state
      rr.append(dict(task=task,seed=seed,model=arm,state=str(state),cells=int(m.sum()),**{k:float(v[m].mean()) for k,v in ma.items()}))
    rows+=rr;write(scorepath,rr);npz_save(ROOT/'distribution_predictions'/f'{task}_{seed}.npz',**payload);write(ROOT/'distribution_learning'/f'{task}_{seed}.json',hist)
    del d,q,par,calibrated,payload,arms;original.close();gc.collect()
  table('DISTRIBUTION_RESULTS.csv',rows);summary={}
  for task in ['CAISO','Europe']:
   summary[task]={a:{k:float(np.mean([r[k] for r in rows if r['task']==task and r['state']=='overall' and r['model']==a])) for k in ['wis','coverage80','coverage90','width90']} for a in ['HIST_CAL','CQR_CAL','JSU_RAW','JSU_CAL']}
  write(ROOT/'DISTRIBUTION_RESULT.json',dict(at=now(),summary=summary,fits=6,point_preserved=True,new_test_targets_read=False,independent_confirmation=False,protected=verify_protected()))
  tick(status='completed');print(json.dumps(summary))
if __name__=='__main__':
 try:main()
 except Exception as e:progress(stage='distribution',status='blocked',error=repr(e));raise
