# Recorded study workflow. See docs/REPRODUCTION_LEVELS.md before execution.
"""Frozen later-period inference and V7 comparison. No fit/selection on H1/P8."""
from evaluate_forward import *
import pickle,gc
U=Path('${DATA_ROOT}/CAISO_unified_forward_main_20261019/CAISO')
S=Path('${DATA_ROOT}/CAISO_supply_state_two_tasks_20261018')
D=Path('${DATA_ROOT}/CAISO_data_completion_matched_20261019')
L=W/'later_replay'
def frozen():
 seals={}
 for seed in SEEDS:
  s=read(W/str(seed)/'POLICY_FREEZE.json')
  for p,h in s['bindings'].items():assert sha(p)==h,p
  seals[seed]=s
 return seals
def prepare():
 import numpy as np
 with locked('later_input_reconstruction_without_targets'):
  sealcheck();frozen();L.mkdir(exist_ok=True)
  if (L/'INPUT_AUDIT.json').exists():
   a=read(L/'INPUT_AUDIT.json')
   for p,h in a['bindings'].items():assert sha(p)==h,p
   return
  a=read(U/'ADMISSION.json');assert a['passed'] and sha(U/'X.npy')==a['X_sha256']
  p8=read(U/'P8_PATH.json');assert sha(p8['X'])==p8['sha256']
  for p in [S/'SOURCE_ADMISSION.json',S/'P8_replay/SOURCE_ADMISSION.json']:assert read(p)['audit_passed']
  assert read(S/'P8_replay/COLLECTION_COMPLETE.json')['netload_revision_ambiguity']==0
  old=read(read(U/'PRETRAIN.json')['paths']['scalers.json']);sc=read(F/'SCALERS.json')
  names=read(B/'dataset/compiled_train_june/manifest.json')['feature_names'][21:29]
  pc=np.asarray(old['price_center']).reshape(30,4);ps=np.asarray(old['price_scale']).reshape(30,4)
  dc=np.stack([old['derived'][n]['center'] for n in names],-1);ds=np.stack([old['derived'][n]['scale'] for n in names],-1)
  nc=np.asarray(sc['price_center']);ns=np.asarray(sc['price_scale'])
  inp=np.load(U/'DATA.npz');inp8=np.load(U/'P8_INPUT.npz')
  cuts=np.r_[inp['cutoff'],inp8['cutoff']]
  cp=S/'P8_replay/combined_input'
  with np.load(cp/'PANEL.npz') as z:assert np.array_equal(z['cutoff'],cuts)
  with np.load(cp/'NETLOAD_FEATURES.npz') as z:rawsrc=z['features'];age=z['age'];missing=z['missing'].astype(bool)
  assert rawsrc.shape==(1188,8) and missing.shape==(1188,)
  good=~missing;assert np.isfinite(rawsrc[good]).all() and (age[good]>=0).all()
  src=np.zeros((1188,10),np.float32);src[good,:8]=np.arcsinh((rawsrc[good]-np.asarray(sc['native_center']))/np.asarray(sc['native_scale']))
  src[:,8]=missing;src[:,9]=np.where(good,np.minimum(age,120)/120,-1)
  ex=np.load(U/'X.npy',mmap_mode='r');ex8=np.load(p8['X'],mmap_mode='r')
  out=np.lib.format.open_memmap(L/'X.npy',mode='w+',dtype='float32',shape=(1188,288,30,29))
  checks=[];max_inverse=0.
  for offset,source,ref in [(0,ex,inp['last']),(1002,ex8,inp8['last'])]:
   for st in range(0,len(source),8):
    guard();xx=np.asarray(source[st:st+8]);v=xx.copy();raw=xx[:,:,:,:4].astype(float)*ps+pc
    max_inverse=max(max_inverse,float(np.max(abs(raw[:,-1,:,0]-ref[st:st+len(xx)]))))
    v[:,:,:,:4]=np.arcsinh((raw-nc)/ns)
    er=xx[:,:,:,15:17].astype(float)*np.asarray(old['external_scale'])+np.asarray(old['external_center'])
    v[:,:,:,15:17]=np.arcsinh((er-np.asarray(sc['external_center']))/np.asarray(sc['external_scale']))
    dr=xx[:,:,:,21:29].astype(float)*ds+dc
    v[:,:,:,21:29]=np.arcsinh((dr-np.asarray(sc['derived_center']))/np.asarray(sc['derived_scale']))
    assert np.isfinite(v).all();assert np.array_equal(v[:,:,:,19:21],xx[:,:,:,19:21])
    out[offset+st:offset+st+len(xx)]=v
  assert max_inverse<.02,'Cannot reconstruct observed history price'
  out.flush();out._mmap.close();ex._mmap.close();ex8._mmap.close()
  with np.load(D/'ADMITTED_FEATURES.npz') as z:
   assert np.array_equal(z['cutoff'],cuts);qualified=z['qualified'].astype(bool)
  ev=inp['eval'];assert len(ev)==194 and qualified[ev].sum()==192 and qualified[1002:].sum()==178
  atomic_np(L/'META.npz',cutoff=cuts,source=src,eval=ev,qualified=qualified,last=np.r_[inp['last'],inp8['last']])
  files=[L/'X.npy',L/'META.npz',cp/'NETLOAD_FEATURES.npz',cp/'PANEL.npz',U/'ADMISSION.json',U/'DATA.npz',U/'P8_INPUT.npz',S/'SOURCE_ADMISSION.json',S/'P8_replay/SOURCE_ADMISSION.json',Path(read(U/'PRETRAIN.json')['paths']['scalers.json'])]
  save(L/'INPUT_AUDIT.json',dict(at=now(),passed=True,bindings={str(p):sha(p) for p in files},max_price_inverse_error=max_inverse,history_contract='Exact linear inverse to physical units, then early-only asinh transform. Origin-aware old age unchanged. Raw8netload reread from admitted combined cache; oldclippedsource not inverted.',target_reads=0,P8_selection=False,forecast_rows=1188))
def infer():
 import numpy as np
 with locked('frozen_later_prediction_before_targets'):
  sealcheck();seals=frozen();audit=read(L/'INPUT_AUDIT.json');assert audit['passed']
  for p,h in audit['bindings'].items():assert sha(p)==h
  if (L/'PREDICTION_FREEZE.json').exists():
   for p,h in read(L/'PREDICTION_FREEZE.json')['bindings'].items():assert sha(p)==h
   return
  np,torch,nn,Core=libraries();sc=read(F/'SCALERS.json');unit=sc['unit']
  x=np.load(L/'X.npy',mmap_mode='r');meta=np.load(L/'META.npz');src=meta['source'];last=meta['last'];frames=np.empty((1188*360,47),np.float32)
  for st in range(0,len(x),16):
   guard();xx=np.asarray(x[st:st+16]);stats=np.stack([xx[:,-t:,:,0].mean(1) for t in [12,36,288]]+[xx[:,-t:,:,0].std(1) for t in [12,36,288]],-1)
   frames[st*360:(st+len(xx))*360]=np.column_stack([np.repeat(xx[:,-1].reshape(-1,29),12,axis=0),np.repeat(stats.reshape(-1,6),12,axis=0),np.tile(np.repeat(np.arange(30),12),len(xx)),np.tile((np.arange(12)+1)/12,len(xx)*30),np.repeat(src[st:st+len(xx)],360,axis=0)])
  with (W/'REFERENCE.pkl').open('rb') as f:ref=pickle.load(f)
  rr=[]
  for st in range(0,len(frames),65536):
   guard();v=frames[st:st+65536].copy();v[:,37:45]=0;rr.append(ref.predict(v))
  r=last[:,:,None]+unit*np.concatenate(rr).reshape(-1,30,12);atomic_np(L/'REFERENCE.npz',point=r);bindings={str(L/'REFERENCE.npz'):sha(L/'REFERENCE.npz')}
  for seed in SEEDS:
   stage=W/str(seed);anchor=make_linear(nn);anchor.load_state_dict(torch.load(stage/'ANCHOR.pt',weights_only=False)['beststate']);anchor.eval();bp=[]
   with torch.no_grad():
    for st in range(0,len(x),128):
     guard();xx=np.asarray(x[st:st+128]);raw=(np.sinh(xx[:,:,:,0].astype(float))*np.asarray(sc['price_scale'])[:,0]+np.asarray(sc['price_center'])[:,0]).astype('float32')
     bp.append(last[st:st+len(xx),:,None]+unit*anchor(torch.from_numpy((raw-last[st:st+len(xx),None,:])/unit).float()).numpy())
   base=np.concatenate(bp);qs={}
   for arm in ['I0_DYNAMIC','I1_DYNAMIC','I1_STATIC','I1_FLAT']:
    m=Core(30,29,12,288);m.mode=arm.split('_',1)[1];m.info=int(arm[1]);m.load_state_dict(torch.load(stage/(arm+'.pt'),weights_only=False)['beststate']);m.eval();bias=read(stage/(arm+'.json'))['calibration_location_bias'];out=[]
    with torch.no_grad():
     for st in range(0,len(x),16):
      guard();xx=np.array(x[st:st+16],copy=True);pr=np.stack([(base[st:st+len(xx)]-last[st:st+len(xx),:,None])/unit,np.zeros_like(base[st:st+len(xx)])],-1).astype('float32')
      q=m(torch.from_numpy(xx),torch.from_numpy(src[st:st+len(xx)]),torch.from_numpy(pr)).numpy();out.append(base[st:st+len(xx),...,None]+unit*q+bias)
    qs[arm]=np.concatenate(out);assert (np.diff(qs[arm],axis=-1)>=0).all()
    p=L/(str(seed)+'_'+arm+'.npz');atomic_np(p,q=qs[arm],point=qmean(qs[arm]));bindings[str(p)]=sha(p)
   details=read(stage/'POLICY_DETAILS.json');points={}
   for arm in ['A','B','C','D']:
    info=details['arms'][arm]['info'];act=np.stack([r,qmean(qs[f'I{info}_DYNAMIC']),qs[f'I{info}_DYNAMIC'][...,6]],-1).reshape(-1,3)
    xx=np.empty((len(frames),52),np.float32);xx[:,:47]=frames
    if info==0:xx[:,37:45]=0
    xx[:,47:]=np.column_stack([act/unit,(act[:,1]-act[:,0])/unit,(act[:,2]-act[:,0])/unit])
    se=np.zeros_like(act);ae=np.zeros_like(act)
    for k in [1,2]:
     for metric in ['AE','SE']:
      with (stage/f'{arm}_a{k}_{metric}.pkl').open('rb') as f:m=pickle.load(f)
      (ae if metric=='AE' else se)[:,k]=predict(m,xx)
    sel=details['arms'][arm]['selection'];action=np.argmax(se+sel['lam']*ae,axis=1);raw=act[np.arange(len(act)),action]
    points[arm]=(act[:,0]+sel['gamma']*(raw-act[:,0])).reshape(-1,30,12)
   points['SELECTED']=points[seals[seed]['selected_arm']]
   p=L/(str(seed)+'_POINTS.npz');atomic_np(p,**points,DLINEAR=base);bindings[str(p)]=sha(p);tick('later_frozen_predictions',seed=seed)
  x._mmap.close()
  save(L/'PREDICTION_FREEZE.json',dict(at=now(),bindings=bindings,policy_sha={str(s):sha(W/str(s)/'POLICY_FREEZE.json') for s in SEEDS},input_audit_sha=sha(L/'INPUT_AUDIT.json'),all_choices_fixed=True,point_reference_unchanged=True,targets_read=0,P8_tuning=False))
def evaluate():
 import numpy as np
 with locked('later_V7_final_comparison'):
  sealcheck();frozen();freeze=read(L/'PREDICTION_FREEZE.json')
  for p,h in freeze['bindings'].items():assert sha(p)==h,p
  # Reuses exact previously admitted target files; score only after all forecasts frozen.
  assert read(U/'ADMISSION.json')['passed']
  save(L/'TARGET_ACCESS.json',dict(at=now(),prediction_freeze_sha=sha(L/'PREDICTION_FREEZE.json'),target_files=[str(U/'LABELS_EVAL.npz'),str(U/'P8_LABELS.npz')],admission_sha=sha(U/'ADMISSION.json'),scope='Previously admitted and viewed H1/P8 retrospective stress. No newblind claim and no post-score parameter updates.',choices_frozen=True))
  meta=np.load(L/'META.npz');z=np.load(U/'DATA.npz');z8=np.load(U/'P8_INPUT.npz');pall={k:np.stack([np.load(L/(str(s)+'_POINTS.npz'))[k] for s in SEEDS]) for k in ['A','B','C','D','SELECTED','DLINEAR']}
  pall['EARLY_REFERENCE']=np.repeat(np.load(L/'REFERENCE.npz')['point'][None],3,0)
  pall['V7']=np.concatenate([z['legacy'],z8['legacy']],axis=1)
  pall['FULL']=np.concatenate([z['old_full'],z8['old_full']],axis=1)
  for arm in ['I0_DYNAMIC','I1_DYNAMIC','I1_STATIC','I1_FLAT']:pall[arm]=np.stack([np.load(L/(str(s)+'_'+arm+'.npz'))['point'] for s in SEEDS])
  results={};reviews={}
  for phase,indices in [('EVAL',meta['eval']),('P8',np.arange(1002,1188))]:
   labs=np.load(U/('LABELS_EVAL.npz' if phase=='EVAL' else 'P8_LABELS.npz'));y=labs['y'].astype(float);state=labs['states'];yy=y.ravel();ss=state.ravel();days=np.repeat(meta['cutoff'][indices]//86400,360)
   common=np.repeat(meta['qualified'][indices],360);pred={k:v[:,indices].reshape(3,-1) for k,v in pall.items()}
   pred['OLD_STRONG']=np.stack([qmean(np.load(U/f'{s}_I1_DYNAMIC_{phase}.npz')['q']).ravel() for s in SEEDS])
   masks={'all':common,'all_admitted_secondary':np.ones(len(yy),bool),**{'S'+str(i):common&(ss==i) for i in range(6)}}
   metrics={k:{part:scores(yy,v,m) for part,m in masks.items() if m.any()} for k,v in pred.items()}
   pairs=[('SELECTED','V7'),('SELECTED','EARLY_REFERENCE'),('SELECTED','OLD_STRONG'),('B','A'),('D','C'),('C','A'),('D','B'),('I1_DYNAMIC','I0_DYNAMIC'),('I1_DYNAMIC','I1_STATIC'),('I1_DYNAMIC','I1_FLAT')]
   comps={a+'_vs_'+b:{part:block_compare(yy,pred[a],pred[b],days,m) for part,m in masks.items() if part!='all_admitted_secondary' and m.any()} for a,b in pairs}
   ledger={}
   for part,m in masks.items():
    if not m.any():continue
    d=pred['SELECTED'][:,m]-pred['V7'][:,m];e=yy[None,m]-pred['V7'][:,m];actual=(e-d)**2-e**2;identity=d*d-2*e*d
    assert np.max(abs(actual-identity))<1e-5
    ledger[part]=dict(MSE_change=float(actual.mean()),square_cost=float((d*d).mean()),alignment_benefit=float((2*e*d).mean()),mean_correction=float(d.mean()),wrong_direction_share=float((e*d<0).mean()))
   oldgain=metrics['V7']['S2']['RMSE']-metrics['OLD_STRONG']['S2']['RMSE'];gain=metrics['V7']['S2']['RMSE']-metrics['SELECTED']['S2']['RMSE'];frac=gain/oldgain if oldgain>0 else None
   c=comps['SELECTED_vs_V7']['all'];s2=comps['SELECTED_vs_V7']['S2']
   decision=dict(all_MAE_lower=c['MAE_improvement']>0,all_RMSE_lower=c['RMSE_improvement']>0,MAE_date_CI_positive=c['date']['MAE_CI95'][0]>0,RMSE_date_CI_positive=c['date']['RMSE_CI95'][0]>0,S2_MAE_lower=s2['MAE_improvement']>0,S2_RMSE_lower=s2['RMSE_improvement']>0,three_seed_MAE=c['MAE_seed_wins']==3,three_seed_RMSE=c['RMSE_seed_wins']==3,old_strong_S2_RMSE_gain_retained=frac,retain90pct_old_strong_gain=frac is not None and frac>=.9)
   decision['numerical_joint_improvement']=all(decision[k] for k in ['all_MAE_lower','all_RMSE_lower','S2_MAE_lower','S2_RMSE_lower'])
   from distribution_review import review
   dist={a:{str(s):review(y,np.load(L/(str(s)+'_'+a+'.npz'))['q'][indices],pall['EARLY_REFERENCE'][0,indices],masks) for s in SEEDS} for a in ['I0_DYNAMIC','I1_DYNAMIC','I1_STATIC','I1_FLAT']}
   results[phase]=dict(origins=len(indices),common_origins=int(common.sum()//360),dates=len(np.unique(days[common])),metrics=metrics,comparisons=comps,ledger=ledger,decision=decision,distribution_secondary=dist)
   atomic_np(L/(phase+'_SCORING_ARCHIVE.npz'),y=y,states=state,issue=meta['cutoff'][indices],common=common.reshape(y.shape),**{k:v.reshape(3,*y.shape) for k,v in pred.items()})
  final=dict(at=now(),results=results,original_V7_unchanged=all(sha(p)==h for p,h in read(O/'PROTOCOL.json')['old_v7_protected'].items()),P8_tuning=False,blind_confirmation=False,scope='All choices trained before2025. H1/P8 previously viewed retrospective transfer; originalV7 uses later historical fitting and is an external deployment reference, not a matched early-training causal ablation.',all_panels_numerically_better=all(r['decision']['numerical_joint_improvement'] for r in results.values()),future_independent_confirmation_still_required=True)
  save(L/'FINAL_RESULTS.json',final)
  save(L/'REVIEW.json',dict(at=now(),passed=True,program_sha=sha(__file__),prediction_bindings_checked=len(freeze['bindings']),all_predictions_frozen_before_targets=True,V7_hash_unchanged=final['original_V7_unchanged'],exact_MSE_identity_replayed=True,scope='Separate computational audit by same agent; not external independent review.'))
  print(json.dumps(dict(later_replay_complete=True,decisions={k:v['decision'] for k,v in results.items()})),flush=True)
if __name__=='__main__':
 if sys.argv[1]=='prepare':prepare()
 elif sys.argv[1]=='infer':infer()
 elif sys.argv[1]=='evaluate':evaluate()

