# Recorded historical component workflow. See docs/REPRODUCTION_LEVELS.md.
from batch_common import *

def candidates(z):
 base=z['base'];g=z['group'];state,_,rec=dc.prev.candidate(z,'STATE_ADD');rec.pop('groups_used')
 initial=state.copy();initial[g!=2,:7]=base[g!=2,:7]
 inner,cap=dc.project(z,initial)
 raw=inner.copy();recipes=[]
 for h in np.unique(z['h']):
  m,r=dc.calibration_mask(z,g,2,h);use=(g==2)&(z['h']==h);r['h']=int(h);vals=[]
  if r['supported']:
   for j in [10,11,12]:
    v=dc.prev.fq((z['truth'][m]-inner[m,j])/z['scale'][m],Q[j]);raw[use,j]+=v*z['scale'][use];vals.append(v)
  r['margins']=vals;recipes.append(r)
 for j in [10,11,12]:raw[:,j]=np.maximum(raw[:,j],raw[:,j-1]+1e-8)
 _,ix=np.unique(z['cut'],return_inverse=True)
 bw=np.bincount(ix,weights=base[:,12]-base[:,0])
 # Both lower and upper inherited margins consume the same99width budget.
 need=np.bincount(ix,weights=(inner[:,12]-inner[:,0])-(base[:,12]-base[:,0]))
 ex=np.bincount(ix,weights=raw[:,12]-inner[:,12])
 check('group_outer_floor_feasible',np.all(need<=.25*bw+1e-8))
 f=np.minimum(1,np.divide(np.maximum(0,.25*bw-need),ex,out=np.ones_like(ex),where=ex>0))
 outer=inner.copy();outer[:,10:]=inner[:,10:]+f[ix,None]*(raw[:,10:]-inner[:,10:])
 check('group_outer_nonGroup2_exact',np.array_equal(outer[g!=2],inner[g!=2]))
 return dict(zip(CANDS,[inner,outer])),dict(state=rec,cap90=cap,outer=recipes,max99=float((np.bincount(ix,weights=outer[:,12]-outer[:,0])/bw).max()))

def run():
 old=read(L/'STRICT_BUDGET_RESULT.json');old2=read(PREV/'STATE_UPPER_RESULTS.json');results={};recipes={};states={};attr={}
 for seed in SEEDS:
  progress('probability_group',seed=seed);z=dc.panel('CAISO',seed,'ANCHOR');models,r=candidates(z);m=z['late'];base=z['base'];point=digest(z['point'])
  rows={k:old[f'CAISO_{seed}'][k] for k in ['STATIC','STATE_ADD','EQ_EVAL_HINDSIGHT_STATE_ADD']}
  previous='STATE_UPPER_ONLY_OUTER_CAP25';rows[previous]=old2[str(seed)][previous]
  state=dc.project(z,dc.prev.candidate(z,'STATE_ADD')[0])[0]
  oldq=load(PREV/f'probability_{seed}_{previous}.npz',['quantiles'])['quantiles']
  y=z['truth'][m];high=z['hi'][m];label=y>high
  loss0=(1-independent_cdf(state[m],high)-label)**2;loss1=(1-independent_cdf(oldq,high)-label)**2
  below=high<base[m,6];g=z['group'][m];attr[str(seed)]={}
  for group in [0,1,2]:
   for half,hmask in [('below_median',below),('at_or_above_median',~below)]:
    mm=(g==group)&hmask;attr[str(seed)][f'group{group}_{half}']=dict(cells=int(mm.sum()),days=len(np.unique(z['days'][m][mm])),brier_contribution=float((loss1-loss0)[mm].sum()/len(y)))
  states[str(seed)]={}
  for name,q in models.items():
   check(name+'_lower_g01_'+str(seed),np.array_equal(q[z['group']!=2,:7],base[z['group']!=2,:7]))
   check(name+'_median_'+str(seed),np.array_equal(q[:,6],base[:,6]));check(name+'_monotone_'+str(seed),np.all(np.diff(q,axis=1)>0));check(name+'_point_'+str(seed),digest(z['point'])==point)
   _,ix=np.unique(z['cut'],return_inverse=True);ratio=np.bincount(ix,weights=q[:,9]-q[:,3])/np.bincount(ix,weights=base[:,9]-base[:,3]);check(name+'_90cap_'+str(seed),ratio.max()<=1.25+1e-10)
   if name==CANDS[1]:check(name+'_99cap_'+str(seed),r['max99']<=1.25+1e-10)
   rows[name]=dc.summarize(z,q)
   for kind in ['CAL','EVAL_HINDSIGHT']:
    eq,f=dc.prev.equalwidth(z,q,kind);rows['EQ_'+kind+'_'+name]=dc.summarize(z,eq);rows['EQ_'+kind+'_'+name]['constant_factor']=f
   for s in range(6):
    mm=m&(z['state']==s);yy=z['truth'][mm];qq=q[mm];ee=yy[:,None]-qq
    states[str(seed)].setdefault(name,{})[str(s)]=dict(cells=int(mm.sum()),days=len(np.unique(z['days'][mm])),wis13=float((abs(ee)+(2*Q-1)*ee).mean()),coverage90=float(((yy>=qq[:,3])&(yy<=qq[:,9])).mean()),coverage99=float(((yy>=qq[:,0])&(yy<=qq[:,12])).mean()))
   save(f'probability_{seed}_{name}.npz',quantiles=q[m])
  truth=z['truth'].copy();z['truth'][m]=truth[m][::-1]+1e6;again,_=candidates(z);z['truth']=truth
  for name in CANDS:check(name+'_no_eval_fit_'+str(seed),digest(again[name])==digest(models[name]))
  results[str(seed)]=rows;recipes[str(seed)]=r
  del z,models,again,oldq,state,base,q,eq;gc.collect()
 summary=jc.gates([results[str(s)] for s in SEEDS])
 for name in CANDS:
  ss=summary['summary'];summary['gates'][name]['fixed_both_tails_net_improve']=all(ss[name][f'fixed_{side}_{loss}']<ss['STATIC'][f'fixed_{side}_{loss}'] for side in ['low','high'] for loss in ['brier','logloss'])
 write(D/'PROBABILITY_RESULTS.json',results);write(D/'PROBABILITY_SUMMARY.json',summary);write(D/'PROBABILITY_RECIPES.json',recipes);write(D/'PROBABILITY_STATES.json',states);write(D/'GROUP_MEDIAN_ATTRIBUTION.json',attr)
 return summary
