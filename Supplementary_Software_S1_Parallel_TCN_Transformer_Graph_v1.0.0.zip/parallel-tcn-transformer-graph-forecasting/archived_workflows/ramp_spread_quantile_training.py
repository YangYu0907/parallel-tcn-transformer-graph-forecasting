# Recorded historical component workflow. See docs/REPRODUCTION_LEVELS.md.
from batch_common import *
from probability import record,make_outer,state_table
import pickle
from sklearn.ensemble import HistGradientBoostingRegressor
def run():
 results={};states={};recipes={};training={}
 old=read(OLD/'PROBABILITY_RESULTS.json')
 feat=load(D/'ENHANCED_CAUSAL_FEATURES.npz',['origins','features'])
 for seed in SEEDS:
  progress('enhanced_HGB',seed=seed);d=load(U/f'data/CAISO_{seed}.npz',['X','fit','residual','origin','h','node','cap','allow'])
  fit=d['fit'];ix=np.searchsorted(feat['origins'],d['origin']);ex=feat['features'][ix,d['node']][:,[0,2]]
  med=np.median(ex[fit],0);iq=np.quantile(ex[fit],[.25,.75],0);sp=np.maximum(iq[1]-iq[0],1e-3)
  X=np.column_stack([d['X'],np.clip((ex-med)/sp,-6,6)]).astype('float32')
  check('feature_dimension_'+str(seed),X.shape[1]==d['X'].shape[1]+2)
  tr=dict(seed=seed,fit_cells=int(fit.sum()),fit_origins=len(np.unique(d['origin'][fit])),feature_center=med.tolist(),feature_scale=sp.tolist(),X_fit_sha=digest(X[fit]),target_fit_sha=digest(d['residual'][fit]),target_reads='FIT only for fitting; CAL only later calibration',start=rt.now(),estimators=[])
  write(D/f'HGB_{seed}_FIT_FROZEN.json',tr)
  q=np.empty((len(X),13));start=time.monotonic()
  for j,tau in enumerate(Q):
   guard();p=D/f'HGB_{seed}_q{j:02d}.pkl'
   if p.exists():
    with p.open('rb') as f:obj=pickle.load(f)
    check('resume_tree_complete',obj.n_iter_==60)
   else:
    obj=HistGradientBoostingRegressor(loss='quantile',quantile=float(tau),learning_rate=.05,max_iter=20,max_leaf_nodes=7,min_samples_leaf=100,l2_regularization=1.,early_stopping=False,warm_start=True,random_state=seed)
    for n in [20,40,60]:
     guard();obj.set_params(max_iter=n);obj.fit(X[fit],d['residual'][fit])
    tmp=p.with_suffix('.tmp');tmp.write_bytes(pickle.dumps(obj,protocol=5));os.replace(tmp,p)
   q[:,j]=obj.predict(X);tr['estimators'].append(dict(quantile=float(tau),iterations=obj.n_iter_,model_sha=sha(p)))
  q.sort(axis=1);median=q[:,6].copy();center=np.clip(median,-d['cap'][d['h']],d['cap'][d['h']])*d['allow'];q+=center[:,None]-median[:,None]
  for j in range(5,-1,-1):q[:,j]=np.minimum(q[:,j],q[:,j+1]-1e-8)
  for j in range(7,13):q[:,j]=np.maximum(q[:,j],q[:,j-1]+1e-8)
  save(f'HGB_{seed}_RAW.npz',q=q)
  tr.update(seconds=time.monotonic()-start,finish=rt.now());training[str(seed)]=tr;write(D/'HGB_TRAINING.json',training)
  z=dc.panel('CAISO',seed,'ANCHOR');origthreshold=z['thresholds'].copy();point=digest(z['point'])
  z['qraw']=z['point'][:,None]+z['scale'][:,None]*(q-q[:,6,None]);z['base'],sr=dc.prev.static(z['qraw'],z);z['thresholds']=origthreshold
  fr,rr=frozen_group(z);models={'ENHANCED_GROUP_AWARE':fr['STATE_GROUP_AWARE_OUTER_CAP25']}
  om,orr=make_outer(z,models['ENHANCED_GROUP_AWARE'])
  for cap,n in zip([25,35],OUTER_NAMES):models[f'ENHANCED_FULL_OUTER_CAP{cap}']=om[n]
  rows={k:old[str(seed)][k] for k in ['STATIC','STATE_ADD','EQ_EVAL_HINDSIGHT_STATE_ADD','STATE_GROUP_AWARE_OUTER_CAP25']}
  rows['ENHANCED_STATIC']=dc.summarize(z,z['base']);states[str(seed)]={};record(z,models,rows,seed,states[str(seed)])
  # Equal-width comparisons for enhanced candidates use the original STATIC,
  # not a weaker newly fitted head; identical total average90width budget.
  original=dc.panel('CAISO',seed,'ANCHOR')
  for name,qq in models.items():
   for kind in ['CAL','EVAL_HINDSIGHT']:
    eq,f=dc.prev.equalwidth(original,qq,kind);rows['EQ_'+kind+'_'+name]=dc.summarize(original,eq);rows['EQ_'+kind+'_'+name]['constant_factor']=f
  check('enhanced_point_exact_'+str(seed),digest(z['point'])==point)
  results[str(seed)]=rows;recipes[str(seed)]=dict(static=sr,group=rr,outer=orr,relative_event_threshold='original frozen STATIC q05/q95, unchanged for all heads')
  del d,X,ex,q,z,models,om,original;gc.collect()
 jc.CANDS=['ENHANCED_GROUP_AWARE','ENHANCED_FULL_OUTER_CAP25','ENHANCED_FULL_OUTER_CAP35']
 summary=jc.gates([results[str(s)] for s in SEEDS])
 for name in jc.CANDS:
  summary['gates'][name]['vs_frozen_winner']=boot([results[str(s)] for s in SEEDS],name,'STATE_GROUP_AWARE_OUTER_CAP25','CAISO')
 write(D/'ENHANCED_RESULTS.json',results);write(D/'ENHANCED_SUMMARY.json',summary);write(D/'ENHANCED_STATES.json',states);write(D/'ENHANCED_RECIPES.json',recipes)

