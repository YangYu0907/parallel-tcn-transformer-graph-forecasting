# Recorded historical component workflow. See docs/REPRODUCTION_LEVELS.md.
from common20 import *
CANDS=['STATE_GROUP_AWARE_CAP25','STATE_GROUP_AWARE_OUTER_CAP25']

def candidates(z):
 base=z['base'];g=z['group'];state,_,rec=dc.prev.candidate(z,'STATE_ADD');rec.pop('groups_used')
 initial=state.copy();initial[g!=2,:7]=base[g!=2,:7]
 inner,cap=dc.project(z,initial)
 raw=inner.copy();recipes=[]
 for h in np.unique(z['h']):
  m,r=dc.calibration_mask(z,g,2,h);use=(g==2)&(z['h']==h);r['h']=int(h);vals=[]
  if r['supported']:
   for j in [10,11,12]:
    v=dc.prev.fq((z['truth'][m]-inner[m,j])/z['scale'][m],Q[j]);raw[use,j]+=v*z['scale'][use];vals.append(v)
  r['margins']=vals;recipes.append(r)
 for j in [10,11,12]:raw[:,j]=np.maximum(raw[:,j],raw[:,j-1]+1e-8)
 raw[g!=2]=inner[g!=2] # Preserve untouched groups exactly; monotone repair only applies to modified group.
 _,ix=np.unique(z['cut'],return_inverse=True)
 bw=np.bincount(ix,weights=base[:,12]-base[:,0])
 # Both lower and upper inherited margins consume the same99width budget.
 need=np.bincount(ix,weights=(inner[:,12]-inner[:,0])-(base[:,12]-base[:,0]))
 ex=np.bincount(ix,weights=raw[:,12]-inner[:,12])
 check('group_outer_floor_feasible',np.all(need<=.25*bw+1e-8))
 f=np.minimum(1,np.divide(np.maximum(0,.25*bw-need),ex,out=np.ones_like(ex),where=ex>0))
 outer=inner.copy();outer[:,10:]=inner[:,10:]+f[ix,None]*(raw[:,10:]-inner[:,10:])
 check('group_outer_nonGroup2_exact',np.array_equal(outer[g!=2],inner[g!=2]))
 return dict(zip(CANDS,[inner,outer])),dict(state=rec,cap90=cap,outer=recipes,max99=float((np.bincount(ix,weights=outer[:,12]-outer[:,0])/bw).max()))
