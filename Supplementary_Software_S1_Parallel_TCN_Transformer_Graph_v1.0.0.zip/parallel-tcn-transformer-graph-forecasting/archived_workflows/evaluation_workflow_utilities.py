# Recorded study workflow. See docs/REPRODUCTION_LEVELS.md before execution.
"""Serial evidence closure. Does not alter any running CAISO training source."""
from pathlib import Path
import os, sys, json, time, hashlib, datetime as dt, importlib.util, contextlib
for name in ('OMP_NUM_THREADS','MKL_NUM_THREADS','OPENBLAS_NUM_THREADS','NUMEXPR_NUM_THREADS'):
    os.environ[name] = '1'
O = Path(__file__).resolve().parent
B = O.parent
P = B / 'early_source_completion_20261020'
Q = Path('${DATA_ROOT}/CAISO_research_completion_20261021')
CW = Path('${DATA_ROOT}/CAISO_early_source_completion_20261020/full_training')
CF = CW.parent / 'fresh_inputs'
EQ = Path('${DATA_ROOT}/CAISO_europe_same_framework_20261021')
EO = B / 'europe_same_framework_20261021'
BC = Path('${USER_HOME}/CAISO_V7_成功实验归档_20261002/研究资料/CAISO_feature_fusion_rev12/asof_retraining_branch_20260913')
SEEDS = [20260813,20260814,20260815]
LEVELS = [.005,.01,.025,.05,.1,.25,.5,.75,.9,.95,.975,.99,.995]
sys.path.insert(0, str(P))
import train_experts as parent
read, save, sha, now = parent.read, parent.save, parent.sha, parent.now
atomic_np = parent.atomic_np

def paused():
    for d in (B,O,Q,EQ,CW.parent):
        for name in ('STOP_REQUESTED','STOP_REQUESTED.json'):
            if (d/name).exists(): return True
    p = B.parent/'RESEARCH_PAUSED.json'
    return p.exists() and (read(p).get('stop_preparation_and_training') or read(p).get('status')=='paused_by_user')

def guard(launch=False):
    if paused(): raise InterruptedError('User research pause; migration pause is separate')
    r = parent.rt.guard(launch)
    if os.environ.get('RESEARCH_CLOSURE_DEADLINE') and time.time()>float(os.environ['RESEARCH_CLOSURE_DEADLINE']):
        raise TimeoutError('Frozen closure stage wall budget exhausted')
    return r

@contextlib.contextmanager
def locked(action):
    import psutil
    guard(True)
    owner = dict(pid=os.getpid(),create_time=psutil.Process().create_time(),task=str(O),action=action,at=now())
    with parent.rt.LOCK.open('x',encoding='utf-8') as f: json.dump(owner,f)
    try: yield
    finally:
        if parent.rt.LOCK.exists() and read(parent.rt.LOCK)==owner: parent.rt.LOCK.unlink()

def sealcheck():
    s=read(O/'EXECUTION_SEAL.json')
    assert s['status']=='frozen_before_new_fits'
    for p,h in s['bindings'].items(): assert sha(p)==h,p
    assert sha(P/'EXECUTION_PROTOCOL.json')=='4cd4620a030c566890c6ba6b39c897ead5b3154da1f0814b117190924d66639a'
    return s

def parent_complete():
    c=read(CW/'COMPLETION.json')
    assert c['status']=='full_three_seed_and_V7_transfer_comparison_complete'
    assert c['original_V7_unchanged']
    for seed in SEEDS:
        for p,h in read(CW/str(seed)/'POLICY_FREEZE.json')['bindings'].items(): assert sha(p)==h,p
    return c

def tick(stage,**kw):
    guard(); save(Q/'STATUS.json',dict(at=now(),pid=os.getpid(),stage=stage,**kw))
    print(stage,json.dumps(parent.json_native(kw),ensure_ascii=False),flush=True)

def qmean(q):
    import numpy as np
    return ((q[...,:-1]+q[...,1:])*.5*np.diff(LEVELS)).sum(-1)+.005*(q[...,0]-(q[...,1]-q[...,0])/np.log(2))+.005*(q[...,-1]+(q[...,-1]-q[...,-2])/np.log(2))

def bias_fit(e):
    import numpy as np
    b=float(e.mean()); lo=0.; hi=1.
    if np.mean(abs(e-b))<=np.mean(abs(e))+1e-12:return b
    for _ in range(52):
        m=(lo+hi)/2
        if np.mean(abs(e-m*b))<=np.mean(abs(e))+1e-12:lo=m
        else:hi=m
    return lo*b

def metrics(y,p,mask):
    import numpy as np
    e=y[None]-p
    return dict(cells=int(mask.sum()),MAE=float(abs(e[:,mask]).mean()),RMSE=float(np.sqrt((e[:,mask]**2).mean())))

def compare(y,p,r,days,mask):
    import numpy as np
    ae=abs(y[None]-r).mean(0)-abs(y[None]-p).mean(0)
    sr=((y[None]-r)**2).mean(0); sp=((y[None]-p)**2).mean(0)
    out=dict(MAE_improvement=float(ae[mask].mean()),RMSE_improvement=float(np.sqrt(sr[mask].mean())-np.sqrt(sp[mask].mean())),
             MAE_seed_wins=int(sum(abs(y[mask]-a[mask]).mean()<abs(y[mask]-b[mask]).mean() for a,b in zip(p,r))),
             RMSE_seed_wins=int(sum(((y[mask]-a[mask])**2).mean()<((y[mask]-b[mask])**2).mean() for a,b in zip(p,r))),
             dates=int(len(np.unique(days[mask]))),positive_means_candidate_better=True)
    for name,block in [('date',days),('seven_day',days//7)]:
        ids=np.unique(block[mask]); rows=[]
        for b in ids:
            m=mask&(block==b); rows.append([m.sum(),ae[m].sum(),sr[m].sum(),sp[m].sum()])
        v=np.asarray(rows,float); rng=np.random.default_rng(20261021)
        z=v[rng.integers(0,len(v),(2000,len(v)))].sum(1)
        da=z[:,1]/z[:,0]; dr=np.sqrt(z[:,2]/z[:,0])-np.sqrt(z[:,3]/z[:,0])
        # Centered bootstrap test under zero paired effect; distinct from CI.
        pa=min(1.,float((1+np.sum(abs(da-out['MAE_improvement'])>=abs(out['MAE_improvement'])))/2001))
        pr=min(1.,float((1+np.sum(abs(dr-out['RMSE_improvement'])>=abs(out['RMSE_improvement'])))/2001))
        out[name]=dict(blocks=len(ids),MAE_CI95=np.quantile(da,[.025,.975]).tolist(),RMSE_CI95=np.quantile(dr,[.025,.975]).tolist(),MAE_centered_bootstrap_p=pa,RMSE_centered_bootstrap_p=pr)
    return out

def holm(values):
    order=sorted(values,key=values.get); last=0.; out={}
    for i,k in enumerate(order):last=max(last,min(1.,values[k]*(len(order)-i)));out[k]=last
    return out
