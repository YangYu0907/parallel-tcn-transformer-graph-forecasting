# Recorded study workflow. See docs/REPRODUCTION_LEVELS.md before execution.
"""Supplement fixed external comparisons after all forecasts are sealed."""
from shared import *

def main():
    import numpy as np
    with locked('Complete_external_baseline_common_panel_review'):
        sealcheck();parent_complete();dest=Q/'CAISO_baselines';assert (dest/'COMPLETE.json').exists()
        for folder in ['I0','I1','UPDATED_I1']:
            for p,h in read(dest/folder/'FREEZE.json')['bindings'].items():assert sha(p)==h,p
        L=CW/'later_replay';meta=np.load(L/'META.npz');results={};checks=[]
        for phase,path in [('HISTORICAL_DEV_CHECK',CW/'HISTORICAL_SCORING_ARCHIVE.npz'),('EVAL',L/'EVAL_SCORING_ARCHIVE.npz'),('P8',L/'P8_SCORING_ARCHIVE.npz')]:
            with np.load(path) as z:
                y=z['y'];states=z['states'];issue=z['issue'];common=z['common'].ravel() if 'common' in z.files else np.ones(y.size,bool)
                p={k:z[k].reshape(3,-1).astype(float) for k in ['SELECTED','I0_DYNAMIC','I1_DYNAMIC','I1_STATIC','I1_FLAT','DLINEAR','EARLY_REFERENCE']}
                if 'V7' in z.files:p['V7']=z['V7'].reshape(3,-1).astype(float)
                if 'PERSISTENCE' in z.files:p['PERSISTENCE']=z['PERSISTENCE'].reshape(3,-1).astype(float)
            for folder in ['I0','I1','UPDATED_I1']:
                for family in ['HGB','RIDGE']:
                    role=phase if phase=='HISTORICAL_DEV_CHECK' else 'LATER';point=np.load(dest/folder/(family+'_'+role+'.npz'))['point']
                    if phase!='HISTORICAL_DEV_CHECK':
                        idx=meta['eval'] if phase=='EVAL' else np.arange(1002,1188);point=point.reshape(-1,30,12)[idx].ravel()
                    assert point.size==y.size;p[folder+'_'+family]=np.repeat(point[None],3,0)
            yy=y.ravel().astype(float);days=np.repeat(issue//86400,360);masks={'all':common,**{'S'+str(k):common&(states.ravel()==k) for k in range(6)}}
            report={k:{part:metrics(yy,v,m) for part,m in masks.items() if m.any()} for k,v in p.items()}
            pairs=[('I1_DYNAMIC','I1_HGB'),('I1_DYNAMIC','I1_RIDGE'),('I0_DYNAMIC','I0_HGB'),('I0_DYNAMIC','I0_RIDGE'),('SELECTED','UPDATED_I1_HGB'),('SELECTED','UPDATED_I1_RIDGE'),('SELECTED','DLINEAR'),('SELECTED','EARLY_REFERENCE')]
            if 'PERSISTENCE' in p:pairs.append(('SELECTED','PERSISTENCE'))
            if 'V7' in p:pairs.append(('SELECTED','V7'))
            comps={a+'_vs_'+b:{part:compare(yy,p[a],p[b],days,m) for part,m in masks.items() if m.any()} for a,b in pairs}
            for k,v in p.items():
                e=yy[None,common]-v[:,common];direct=np.sqrt(sum(float(np.dot(r,r)) for r in e)/e.size)
                assert abs(direct-report[k]['all']['RMSE'])<1e-9;checks.append(dict(phase=phase,model=k,passed=True))
            results[phase]=dict(metrics=report,comparisons=comps,common_cells=int(common.sum()),event_dates={part:int(len(np.unique(days[m]))) for part,m in masks.items() if m.any()})
        save(dest/'RESULTS.json',dict(at=now(),results=results,interpretation={'early':'Neural expert vs tabular baselines shares early labels and causal information; representations/parameters differ.', 'updated':'SELECTED vs UPDATED_I1 shares latest eligible training label cutoff and source values; learning procedures differ, not equalFLOPs.', 'V7':'Historical deployment comparator, not sole measure of research value.', 'P3':'Old P3 external comparisons remain separate, not substituted for this panel.'},P8_tuning=False))
        save(dest/'ARITHMETIC_REVIEW.json',dict(at=now(),passed=True,checks=checks,external_reviewer=False,independent_formula=True))
        tick('external_baseline_review_complete',panels=list(results))

if __name__=='__main__':main()
