# Recorded historical component workflow. See docs/REPRODUCTION_LEVELS.md.
from batch_common import *
R=B/'reviewer_revision_v2_20261003/recovery_transition_20261004'
def read_fold(fold):
 z=load(R/f'REPLAY_fold{fold}.npz',['truth','states','days','origins','FULL']+[f'{m}_{s}' for s in SEEDS for m in ['BASE','TRANSITION']])
 head=load(R/f'fold{fold}/PREDICTIONS.npz',['origins','eligible','recovery','probability'])
 check('recovery_join_'+str(fold),np.array_equal(z['origins'],head['origins']))
 return z,head
def delta_for(z,head,seed,tau):
 b=z[f'BASE_{seed}'];delta=z[f'TRANSITION_{seed}']-b
 gate=np.zeros_like(b,bool);gate[:,:,7:]=head['eligible'][:,:,None]&(head['probability']>=tau)
 return delta*gate,gate
def select(z,head):
 y=z['truth'];m=np.broadcast_to(head['eligible'][:,:,None],y.shape);table=[]
 bm=np.mean([abs(z[f'BASE_{s}']-y)[m].mean() for s in SEEDS]);br=np.mean([np.sqrt(np.mean((z[f'BASE_{s}']-y)**2)) for s in SEEDS])
 for tau in [.50,.60,.70,.80,.85]:
  for gamma in [.25,.50,.75,1.]:
   scores=[]
   for s in SEEDS:
    delta,g=delta_for(z,head,s,tau);e=z[f'BASE_{s}']+gamma*delta-y
    scores.append(dict(mae=float(abs(e)[m].mean()),rmse=float(np.sqrt((e*e).mean())),active=int(g.sum())))
   mae=float(np.mean([s['mae'] for s in scores]));rmse=float(np.mean([s['rmse'] for s in scores]))
   table.append(dict(tau=tau,gamma=gamma,current_extreme_mae=mae,all_rmse=rmse,mae_improvement=bm-mae,rmse_improvement=br-rmse,eligible=bool(mae<bm and rmse<=br),per_router=scores))
 eligible=[r for r in table if r['eligible']]
 choice=min(eligible,key=lambda r:(r['current_extreme_mae'],r['gamma'],-r['tau'])) if eligible else dict(tau=1.,gamma=0.,reason='No registered candidate improves CAL observed-extreme MAE while preserving whole CAL RMSE')
 return choice,table
def run():
 z,h=read_fold(1);choice,table=select(z,h)
 write(D/'R04_SELECTION_FROZEN.json',dict(at=rt.now(),choice=choice,grid=table,objective='mean of three router current-observed-extreme MAEs; mean of three whole-panel RMSEs nonworse; ties lower gamma then higher tau',future_state_not_used_in_selection=True))
 # Mutation of future labels alone cannot affect selection.
 original=z['states'].copy();z['states'][:]=0;mut,_=select(z,h);z['states']=original;check('selection_ignores_future_states',mut==choice)
 del z,h;results={}
 for fold in [1,2]:
  progress('recovery_probability',fold=fold);z,head=read_fold(fold);y=z['truth'];st=z['states'];days=z['days'];current=np.broadcast_to(head['eligible'][:,:,None],y.shape)
  check('observable_union_crosscheck_'+str(fold),np.array_equal(current,np.isin(st,[3,4,5])))
  masks={'all':np.ones(y.shape,bool),'H8_H12':np.broadcast_to((np.arange(12)>=7)[None,None,:],y.shape),'current_extreme':current,**{'S'+str(s):st==s for s in [3,4,5]}}
  preds={k:[] for k in ['BASE','FULL','R04','PROB_GATED_R04']};savevals={}
  for seed in SEEDS:
   b=z[f'BASE_{seed}'];delta,g=delta_for(z,head,seed,choice['tau']);q=b+choice['gamma']*delta
   reconstructed=b.copy();reconstructed[:,:,7:]+=.5*head['probability']*head['eligible'][:,:,None]*(head['recovery']-b[:,:,7:])
   check('R04_reconstruct_'+str(fold)+str(seed),np.allclose(reconstructed,z[f'TRANSITION_{seed}'],rtol=0,atol=1e-10))
   check('R04_near_exact_'+str(fold)+str(seed),np.array_equal(q[:,:,:7],b[:,:,:7]))
   check('R04_inactive_exact_'+str(fold)+str(seed),np.array_equal(q[~g],b[~g]))
   for k,v in [('BASE',b),('FULL',z['FULL']),('R04',z[f'TRANSITION_{seed}']),('PROB_GATED_R04',q)]:preds[k].append(v)
   savevals['prediction_'+str(seed)]=q
  summary,ae,se=summarize_points(preds,y,masks,days,'CAISO')
  comparisons={name:compare_points(ae,se,name,['BASE','FULL'],masks,days,'CAISO') for name in ['R04','PROB_GATED_R04']}
  results[str(fold)]=dict(stage='CAL selection reused' if fold==1 else 'previously inspected historical forward EVAL',origins=len(y),dates=len(np.unique(days)),choice=choice,summary=summary,comparisons=comparisons,active_cells=int(g.sum()),active_S5=int((g&(st==5)).sum()))
  save(f'R04_PROB_fold{fold}.npz',origins=z['origins'],gate=g,**savevals);write(D/'RECOVERY_RESULTS.json',results)
  del z,head,preds,ae,se,savevals;gc.collect()

