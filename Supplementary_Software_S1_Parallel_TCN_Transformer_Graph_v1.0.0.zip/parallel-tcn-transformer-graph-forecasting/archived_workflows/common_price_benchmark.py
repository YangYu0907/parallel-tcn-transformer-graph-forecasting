# Recorded historical component workflow. See docs/REPRODUCTION_LEVELS.md.
"""Fresh price-only matched models. No inference-only removal from old weights."""
from common import *
import argparse,copy,math,random
guard(True)
import numpy as np,torch
from torch import nn
sys.path.insert(0,str(B/'source'))
sys.path.insert(1,str(B/'external/preparation_20260913/source'))
from compiled_data import CompiledData
from models.factory import build_backbone
from official_models import make_model
MANIFEST=B/'phase_sampling_support_v3_20260923/dataset/ADDITIVE/manifest.json'
class PriceModel(nn.Module):
 def __init__(self,name,seed,limits):
  super().__init__();self.name=name
  if name=='FULL_price_only':self.model=build_backbone('FULL',seed,limits)
  elif name=='iTransformer_price_only':
   torch.manual_seed(seed);self.model=make_model('iTransformer',dict(d_model=64,n_heads=4,e_layers=2,d_ff=128)).float()
  else:raise ValueError(name)
 def forward(self,x):
  if self.name=='FULL_price_only':
   mask=torch.zeros_like(x);mask[:,:,:,0]=x[:,:,:,0];return self.model(mask)['prediction']
  return self.model(x[:,:,:,0].contiguous(),None)
def runtime():
 torch.set_num_threads(1);torch.set_num_interop_threads(1);torch.use_deterministic_algorithms(True)
def lr(epoch):return .0001 if epoch>6 else .0001+.5*(.001-.0001)*(1+math.cos(math.pi*(epoch-1)/5))
def update(m,opt,x,y):
 m.train();opt.zero_grad(set_to_none=True);loss=torch.nn.functional.huber_loss(m(x),y,delta=.5);assert torch.isfinite(loss);loss.backward();assert all(p.grad is not None and torch.isfinite(p.grad).all() for p in m.parameters() if p.requires_grad);torch.nn.utils.clip_grad_norm_(m.parameters(),1.);opt.step();return float(loss.detach())
def save_pt(path,obj):
 path.parent.mkdir(parents=True,exist_ok=True);q=path.with_suffix('.tmp');torch.save(obj,q);os.replace(q,path)
def qa():
 with numeric('synthetic price-only information and exact resume checks'):
  runtime();torch.manual_seed(73);x=torch.randn(2,288,30,29);y=torch.randn(2,30,12);results=[]
  for name in ['FULL_price_only','iTransformer_price_only']:
   m=PriceModel(name,SEEDS[0],[[4.,4.]]*30).eval();alter=x.clone();alter[:,:,:,1:]+=100
   with torch.no_grad():
    a=m(x);b=m(alter);assert torch.equal(a,b);assert a.shape==(2,30,12)
   opt=torch.optim.AdamW(m.parameters(),lr=.001,weight_decay=.0001);update(m,opt,x,y)
   state=copy.deepcopy(m.state_dict());osnap=copy.deepcopy(opt.state_dict());rs=torch.get_rng_state();update(m,opt,x,y);expected=copy.deepcopy(m.state_dict())
   m.load_state_dict(state);opt.load_state_dict(osnap);torch.set_rng_state(rs);update(m,opt,x,y);assert all(torch.equal(expected[k],v) for k,v in m.state_dict().items())
   results.append(dict(model=name,nonprice_perturbation_invariant=True,resume_exact=True,output_shape=list(a.shape)))
  assert lr(1)==.001 and lr(6)==.0001 and all(lr(e)==.0001 for e in range(7,13))
  write(ROOT/'FAIR_INPUT_QA.json',dict(at=now(),status='passed',checks=results,source_sha=sha(Path(__file__)),schedule='same4032slots and seed-permutation12epochs; price-only mask present from initialization through training and inference',parameter_count_scope='Retain original FULL dimensions; constant zero nonprice channels supply no information'))
def register():
 q=read(ROOT/'FAIR_INPUT_QA.json');assert q['source_sha']==sha(Path(__file__)) and q['status']=='passed'
 path=ROOT/'FAIR_INPUT_SEAL.json';assert not path.exists()
 m=read(MANIFEST);sources=[Path(__file__),ROOT/'common.py',MANIFEST,MANIFEST.parent/'audit.json',B/'source/compiled_data.py',B/'source/compile_math.py',B/'source/compile_gate.py',B/'external/preparation_20260913/source/official_models.py']+list((B/'source/models').glob('*.py'))
 reuse=[]
 for seed in SEEDS:
  p=B/'budget_extension_v1_20260925/runs'/f'{seed}_DLinear/completion.json';r=read(p)
  assert r['optimizer_steps']==12096 and len(r['epochs'])==12
  assert all(row['train_origins']==4032 and abs(row['lr']-lr(row['epoch']))<1e-15 for row in r['epochs'])
  sources.append(p);reuse.append(dict(seed=seed,completion=str(p),sha256=sha(p),status='same12epoch4032slotsbatch4priceonlyrecipe; selected predictions audited separately',selected_epoch=r['selected_epoch']))
 vendor=B.parent/'external_baselines_20260913/vendor';vm=read(vendor/'manifest.json');sources.append(vendor/'manifest.json')
 for family,row in vm.items():
  for name,item in row['files'].items():
   p=vendor/family/name;assert sha(p)==item['sha256'];sources.append(p)
 write(path,dict(at=now(),registered_before_training=True,sources={str(p):sha(p) for p in sources},QA_sha=sha(ROOT/'FAIR_INPUT_QA.json'),manifest_sha=sha(MANIFEST),cases=[dict(model=name,seed=s) for s in SEEDS for name in ['iTransformer_price_only','FULL_price_only']],reuse_DLinear=reuse,epochs=12,steps=12096,selector='earliest June284 MAE improvement >1e-6',evaluation='June3397 dense common panel, allnodes/horizons/states; not new heldout',maximum_numerical_seconds=43200))
def verify():
 s=read(ROOT/'FAIR_INPUT_SEAL.json')
 for p,h in s['sources'].items():assert sha(p)==h,p
 assert sha(ROOT/'FAIR_INPUT_QA.json')==s['QA_sha'];verify_protected();return s
def evaluate(m,d,part,run,tick):
 origins=d.origins[part];p=np.empty((len(origins),30,12),np.float64);y=np.empty_like(p);m.eval()
 before=torch.get_rng_state();order=np.arange(len(origins))
 if part=='june_dense':
  reg=np.searchsorted(origins,d.origins['june']);assert np.array_equal(origins[reg],d.origins['june']);order=np.r_[reg,np.flatnonzero(~np.isin(np.arange(len(origins)),reg))]
 with torch.no_grad():
  for j in range(0,len(order),4):
   if j%64==0:tick(stage='fair_validation',model=run.name,partition=part,origins_done=j)
   ix=order[j:j+4];x,t=d.batch(part,ix);p[ix]=m(torch.from_numpy(x)).numpy().astype(float)*d.scale[None,:,None]+d.center[None,:,None];y[ix]=t.astype(float)*d.scale[None,:,None]+d.center[None,:,None]
 assert torch.equal(before,torch.get_rng_state()) and np.isfinite(p).all()
 e=p-y;return dict(origins=origins,prediction=p,truth=y),dict(mae=float(abs(e).mean()),rmse=float(np.sqrt((e*e).mean())),near_mae=float(abs(e[:,:,:4]).mean()),h12_mae=float(abs(e[:,:,-1]).mean()))
def run(name,seed):
 seal=verify();run=ROOT/'fair_runs'/f'{seed}_{name}'
 if (run/'COMPLETE.json').exists():print('already complete');return
 with numeric('matched price-only '+name+' '+str(seed)):
  runtime();tick=budget('fair',43200);data=CompiledData(MANIFEST);limits=read(data.paths['context_limits.json'])['limits'];m=PriceModel(name,seed,limits)
  torch.manual_seed(seed+200000);np.random.seed(seed);random.seed(seed);rng=np.random.default_rng(seed);opt=torch.optim.AdamW(m.parameters(),lr=.001,weight_decay=.0001,betas=(.9,.999),eps=1e-8)
  state=dict(epoch=1,steps=0,offset=0,order=None,records=[],best_mae=None,best_epoch=None);latest=run/'latest.pt';identity=dict(seal_sha=sha(ROOT/'FAIR_INPUT_SEAL.json'),model=name,seed=seed)
  def checkpoint():save_pt(latest,dict(identity=identity,model=m.state_dict(),optimizer=opt.state_dict(),state=state,rng=rng.bit_generator.state,torch_rng=torch.get_rng_state(),numpy_rng=np.random.get_state(),python_rng=random.getstate()))
  if latest.exists():
   c=torch.load(latest,map_location='cpu',weights_only=False);assert c['identity']==identity;m.load_state_dict(c['model']);opt.load_state_dict(c['optimizer']);state=c['state'];rng.bit_generator.state=c['rng'];torch.set_rng_state(c['torch_rng']);np.random.set_state(c['numpy_rng']);random.setstate(c['python_rng']);del c
  started=time.monotonic();initial_steps=state['steps'];checkpoint()
  try:
   while state['epoch']<=12:
    epoch=state['epoch'];data.set_epoch((epoch-1)%6+1);assert len(data.origins['train'])==4032 and (data.origins['train']+12<=210528).all()
    for g in opt.param_groups:g['lr']=lr(epoch)
    if state['order'] is None:state['order']=rng.permutation(4032);state['offset']=0;checkpoint()
    while state['offset']<4032:
     if state['steps']%32==0:
      checkpoint();tick(stage='fair_training',model=name,seed=seed,epoch=epoch,steps=state['steps']);seconds=time.monotonic()-started;done=state['steps']-initial_steps
      write(run/'PROGRESS.json',dict(at=now(),pid=os.getpid(),epoch=epoch,steps=state['steps'],seconds_per_update=seconds/done if done else None,remaining_updates=12096-state['steps']))
     ix=state['order'][state['offset']:state['offset']+4];x,y=data.batch('train',ix);update(m,opt,torch.from_numpy(x),torch.from_numpy(y));state['offset']+=len(ix);state['steps']+=1
    arrays,metrics=evaluate(m,data,'june',run,tick);npz_save(run/f'epoch{epoch}_june.npz',**arrays)
    if state['best_mae'] is None or metrics['mae']<state['best_mae']-1e-6:
     state['best_mae']=metrics['mae'];state['best_epoch']=epoch;save_pt(run/'best.pt',dict(identity=identity,epoch=epoch,model=m.state_dict()))
    state['records'].append(dict(epoch=epoch,metrics=metrics,steps=state['steps'],lr=lr(epoch)));state['epoch']+=1;state['offset']=0;state['order']=None;checkpoint();save_pt(run/f'epoch{epoch}.pt',torch.load(latest,map_location='cpu',weights_only=False))
   c=torch.load(run/'best.pt',map_location='cpu',weights_only=False);assert c['epoch']==state['best_epoch'];m.load_state_dict(c['model']);arrays,metrics=evaluate(m,data,'june_dense',run,tick);npz_save(run/'selected_dense.npz',**arrays)
   reg=np.searchsorted(arrays['origins'],data.origins['june']);ref=np.load(run/f"epoch{state['best_epoch']}_june.npz");assert np.array_equal(arrays['prediction'][reg],ref['prediction'])
   verify();write(run/'COMPLETE.json',dict(at=now(),identity=identity,steps=state['steps'],selected_epoch=state['best_epoch'],selected_dense=metrics,epochs=state['records'],prediction_sha=sha(run/'selected_dense.npz'),checkpoint_sha=sha(run/'best.pt'),status='completed_pending_separate_arithmetic_audit',new_test_targets_read=False));tick(stage='fair_case_complete',model=name,seed=seed);print(json.dumps(metrics))
  except Exception as e:
   checkpoint();write(run/'STOP.json',dict(at=now(),status='saved_at_boundary',steps=state['steps'],error=repr(e)));raise
if __name__=='__main__':
 p=argparse.ArgumentParser();p.add_argument('action',choices=['qa','register','run']);p.add_argument('--model');p.add_argument('--seed',type=int);args=p.parse_args()
 if args.action=='qa':qa()
 elif args.action=='register':register()
 else:run(args.model,args.seed)
