# Recorded study workflow. See docs/REPRODUCTION_LEVELS.md before execution.
"""Verified dimension-only reuse of the CAISO expert optimizer; fresh EU data/state."""
from shared import *
import ast, types
RAW_ARCHIVE = BC/'energy_confirmation_v1_20260926/data/train_valid.npz'
EU = Path('${DATA_ROOT}/CAISO_unified_forward_main_20261019/EUROPE')
EF = EQ/'fresh_inputs'; EW=EQ/'training'

def make_module():
    tree=ast.parse((P/'train_experts.py').read_text(encoding='utf-8-sig'))
    names={'make_linear','fit_anchor','fit_expert'}
    nodes=[v for v in tree.body if isinstance(v,ast.FunctionDef) and v.name in names]
    edits=[]
    class Dims(ast.NodeTransformer):
        def visit_Call(self,n):
            self.generic_visit(n)
            if isinstance(n.func,ast.Attribute) and isinstance(n.func.value,ast.Name) and n.func.value.id=='nn' and n.func.attr=='Linear':
                if n.args and isinstance(n.args[0],ast.Constant) and n.args[0].value==288:
                    n.args[0]=ast.Constant(168); edits.append('DLinear.L288_to168')
            if isinstance(n.func,ast.Name) and n.func.id=='Core':
                assert [v.value for v in n.args]==[30,29,12,288]
                n.args=[ast.Constant(v) for v in [3,4,24,168]]; edits.append('Core.dimensions_only')
            if isinstance(n.func,ast.Name) and n.func.id=='dict':
                for k in n.keywords:
                    if k.arg=='source_scope' and isinstance(k.value,ast.Constant):
                        k.value=ast.Constant('Admitted European price-history only; all ten native-source slots unavailable, identical across graph arms.')
            return n
    nodes=Dims().visit(ast.Module(body=nodes,type_ignores=[])).body
    for n in nodes:
        if n.name=='make_linear':assert n.args.defaults[0].value==12;n.args.defaults[0]=ast.Constant(24);edits.append('DLinear.H12_to24')
    assert sorted(edits)==sorted(['DLinear.L288_to168']*2+['Core.dimensions_only','DLinear.H12_to24'])
    mod=types.ModuleType('eu_current_expert')
    mod.__dict__.update(parent.__dict__)
    mod.__dict__.update(Data=EuropeanData,W=EW,F=EF,Q=EQ,guard=guard,locked=locked,sealcheck=sealcheck,tick=tick)
    exec(compile(ast.fix_missing_locations(ast.Module(body=nodes,type_ignores=[])),'eu_dimension_adapter','exec'),mod.__dict__)
    return mod,edits

class EuropeanData:
    def __init__(self):
        import numpy as np
        self.np=np;self.sc=read(EF/'SCALERS.json');self.unit=self.sc['unit'];self.label={}
        with np.load(EF/'ORIGINS.npz') as z:self.roles={k:z[k] for k in z.files}
        self.x=np.load(EF/'X.npy',mmap_mode='r');self.src=np.load(EF/'SOURCE.npy',mmap_mode='r')
    def labels(self,role):
        assert role!='HISTORICAL_DEV_CHECK','EU2015 targets remain separate until all predictions frozen'
        if role not in self.label:
            with self.np.load(EF/(role+'_LABELS.npz')) as z:self.label[role]={k:z[k] for k in z.files}
        return self.label[role]
    def batch(self,origins):
        np=self.np;ix=np.searchsorted(self.roles['ALL'],origins);assert np.array_equal(self.roles['ALL'][ix],origins)
        xx=np.array(self.x[ix],copy=True);src=np.array(self.src[ix],copy=True)
        raw=np.sinh(xx[:,:,:,0].astype(float))*np.asarray(self.sc['scale'])[:,0]+np.asarray(self.sc['center'])[:,0]
        assert np.isfinite(xx).all() and np.isfinite(raw).all()
        return xx,src,raw.astype('float32')

def prepare():
    import numpy as np, zipfile, shutil
    with locked('Europe_same_framework_fresh_input_preparation'):
        sealcheck();parent_complete();EF.mkdir(parents=True,exist_ok=True);EW.mkdir(exist_ok=True)
        if (EF/'READY.json').exists():
            for p,h in read(EF/'READY.json')['bindings'].items():assert sha(p)==h,p
            return
        census=read(EO/'ROLE_METADATA_CENSUS.json');assert all(x['passed'] for x in census['checks'])
        with np.load(RAW_ARCHIVE) as z:
            times=z['timestamps'].astype('datetime64[s]').astype('int64')
        # Extract raw NPY bytes without interpreting or slicing evaluation targets.
        rawfile=EF/'raw_archive.npy'
        if not rawfile.exists():
            temp=rawfile.with_suffix('.tmp')
            with zipfile.ZipFile(RAW_ARCHIVE) as z,z.open('raw.npy') as inp,temp.open('wb') as out:shutil.copyfileobj(inp,out,2**20)
            os.replace(temp,rawfile)
        raw=np.load(rawfile,mmap_mode='r');assert raw.ndim==2 and raw.shape[1]==3
        roles={('HISTORICAL_DEV_CHECK' if r['role']=='HISTORICAL_EVAL' else r['role']):np.asarray(r['origin_ids'],np.int64) for r in census['roles']}
        allorig=np.unique(np.concatenate(list(roles.values())))
        with np.load(EU/'DATA.npz') as z:
            orig=z['origins'];cut=z['cutoff'];assert np.array_equal(times[orig-1],cut)
        for name,oo in roles.items():
            assert np.all(np.isin(oo,orig))
            assert np.all(times[oo+23]+3600==times[oo-1]+25*3600)
        ordered=list(roles)
        for a,b in zip(ordered[:-1],ordered[1:]):assert times[roles[a]+23].max()+3600+86400<times[roles[b]-1].min()
        fitrows=np.unique(np.concatenate([np.arange(o-168,o) for o in roles['EXPERT_FIT']]))
        used=np.unique(np.concatenate([np.arange(o-168,o) for o in allorig]))
        def rawfeatures(rows):
            v=np.asarray(raw[rows],float);prev=np.asarray(raw[np.maximum(rows-1,0)],float)
            return np.stack([v,v-prev,np.broadcast_to(np.median(v,1)[:,None],v.shape),np.broadcast_to(v.std(1)[:,None],v.shape)],-1)
        f=rawfeatures(fitrows);center=np.median(f,0);iq=np.quantile(f,.75,axis=0)-np.quantile(f,.25,axis=0);scale=np.maximum(np.maximum(iq,.1*f.std(0)),1.)
        assert times[fitrows].max()<times[roles['EXPERT_VALID'][0]-1]
        save(EF/'SCALERS.json',dict(center=center.tolist(),scale=scale.tolist(),unit=max(float(np.median(scale[:,0])),1.),fit_latest=int(times[fitrows].max()),transform='FIT history-only median/IQR, asinh',nodes=['FR','DE','BE']))
        x=np.lib.format.open_memmap(EF/'X.npy',mode='w+',dtype='float32',shape=(len(allorig),168,3,4))
        for i,o in enumerate(allorig):
            guard();x[i]=np.arcsinh((rawfeatures(np.arange(o-168,o))-center)/scale)
        x.flush();x._mmap.close()
        src=np.zeros((len(allorig),10),np.float32);src[:,8]=1.;src[:,9]=-1.;np.save(EF/'SOURCE.npy',src)
        atomic_np(EF/'ORIGINS.npz',**roles,ALL=allorig,ISSUE=times[allorig-1])
        for role,oo in roles.items():
            if role=='HISTORICAL_DEV_CHECK':continue
            y=np.stack([raw[o:o+24].T for o in oo]).astype('float32');last=np.asarray(raw[oo-1],np.float32)
            assert np.isfinite(y).all();atomic_np(EF/(role+'_LABELS.npz'),y=y,last=last,origins=oo,issue=times[oo-1])
        # The descriptive six-state thresholds use unique FIT target timestamps only.
        rr=np.unique(np.concatenate([np.arange(o,o+24) for o in roles['EXPERT_FIT']]))
        fitprice=np.asarray(raw[rr],float);c=np.median(fitprice,0);tt=np.quantile(abs(fitprice-c),[.9,.99],axis=0)
        save(EF/'STATE_THRESHOLDS.json',dict(center=c.tolist(),thresholds=tt.tolist(),fit_only=True))
        raw._mmap.close();files=list(EF.glob('*LABELS.npz'))+[EF/n for n in ['SCALERS.json','X.npy','SOURCE.npy','ORIGINS.npz','STATE_THRESHOLDS.json']]
        save(EF/'READY.json',dict(at=now(),bindings={str(p):sha(p) for p in files},roles={k:len(v) for k,v in roles.items()},new_test_targets_read=False,raw_member_copy_is_not_scoring=True,source_sha=sha(RAW_ARCHIVE)))
        tick('Europe_inputs_ready',origins=len(allorig))

def run(kind,seed,arm=None,budget=48):
    sealcheck(); parent_complete(); mod,_=make_module();EW.mkdir(parents=True,exist_ok=True)
    if kind=='anchor':mod.fit_anchor(seed)
    else:mod.fit_expert(seed,arm,budget)

if __name__=='__main__':
    if sys.argv[1]=='prepare':prepare()
    else:run(sys.argv[1],int(sys.argv[2]),sys.argv[3] if len(sys.argv)>3 else None,int(sys.argv[4]) if len(sys.argv)>4 else 48)
