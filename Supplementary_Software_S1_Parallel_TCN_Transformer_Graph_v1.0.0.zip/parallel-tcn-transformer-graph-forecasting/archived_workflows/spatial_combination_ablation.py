# Recorded historical component workflow. See docs/REPRODUCTION_LEVELS.md.
from batch_common import *
from scipy.optimize import minimize
FOLDERS={'FULL':'budget_extension_v1_20260925','STATIC':'static_gtf_tail_v1_20260927','SELF':'budget_mechanisms_v1_20260925'}
def ca_sources(seed,model):
 r=read(B/FOLDERS[model]/'runs'/f'{seed}_{model}'/'completion.json');e=r['selected_epoch'];rows=[v for v in r['train_curves_new'] if v['epoch']==e]
 if rows:tr=B/rows[0]['evaluation']['path']
 else:
  row=next(v for v in r['identity']['case']['parent_train_curve'] if v['epoch']==e);tr=B/read(B/row['receipt'])['artifact']
 return tr,B/r['dense_evaluation']['path'],B/r['selected_checkpoint']
def fit_weights(pred,y,risk,with_full,q70):
 models=['FULL','STATIC','SELF'] if with_full else ['STATIC','SELF'];K=len(models);anchor=np.zeros(K);anchor[models.index('STATIC')]=1
 out=np.zeros((2,y.shape[2],K));records=[]
 for s in [0,1]:
  use=risk==s;pool=use.sum()<20
  if pool:use=np.ones(len(y),bool)
  for h in range(y.shape[2]):
   reg=.001 if q70 and s==1 and h>=(8 if y.shape[2]==12 else 18) else .01
   yy=y[use,:,h].ravel();xx=np.stack([pred[m][use,:,h].ravel() for m in models],1);er=xx-yy[:,None]
   G=er.T@er/len(yy)/max(float(np.var(yy)),1)+reg*np.eye(K)
   lo=np.array([.05,0,0]) if with_full else np.zeros(2);w0=np.array([.05,.9,.05]) if with_full else np.array([.95,.05])
   sol=minimize(lambda w:float(w@G@w-2*reg*w@anchor),w0,jac=lambda w:2*G@w-2*reg*anchor,bounds=list(zip(lo,np.ones(K))),constraints={'type':'eq','fun':lambda w:w.sum()-1,'jac':lambda w:np.ones(K)},method='SLSQP',options={'ftol':1e-12,'maxiter':200})
   check(f'weight_{with_full}_{q70}_{s}_{h}',sol.success and np.min(sol.x-lo)>-1e-9 and abs(sol.x.sum()-1)<1e-9)
   out[s,h]=sol.x;records.append(dict(state=s,h=h,origins=int(use.sum()),pooled=bool(pool),regularization=reg))
 return out,models,records
def metric_on(pp,y,mask):
 e=(pp-y)[mask];return dict(cells=len(e),mae=float(abs(e).mean()),rmse=float(np.sqrt((e*e).mean()))) if len(e) else None
def run():
 result={}
 for task in ['CAISO','Europe']:
  progress('graph_ablation',market=task)
  if task=='CAISO':
   d=gd.caiso_data();raw=d['price']*d['scale']+d['center'];train=d['train'];orig=d['evaluation'];days=d['times'][orig-1]//86400;window=288
  else:
   p=load(B/'energy_confirmation_v1_20260926/data/train_valid.npz',['raw','timestamps','train','valid']);raw=p['raw'];orig=p['valid'];train=p['train'][p['train']+48<orig.min()];window=24;days=p['timestamps'][orig].astype('datetime64[D]').astype('int64')
  allx=gd.history_features(raw,train,window);xe=gd.history_features(raw,orig,window);th={k:np.quantile(allx,k/100,axis=0) for k in [70,80]};risk={k:(xe>=th[k]).all(1) for k in th}
  per={};errors={};statecounts={str(k):dict(high_origins=int(risk[k].sum()),high_dates=len(np.unique(days[risk[k]])),threshold=th[k].tolist()) for k in th}
  for seed in SEEDS:
   pt={};pe={};yt=None;ot=None
   for m in ['FULL','STATIC','SELF']:
    if task=='CAISO':
     ft,fe,_=ca_sources(seed,m);z=load(ft,['origins','prediction','truth']);yy=z['truth']
    else:
     z=load(PREV/f'Europe_TRAIN_{m}_{seed}.npz',['origins','prediction']);yy=raw[z['origins'][:,None]+np.arange(24)].transpose(0,2,1)
    if ot is None:ot=z['origins'];yt=yy
    check(f'{task}_{seed}_{m}_train_join',np.array_equal(ot,z['origins']) and np.array_equal(yt,yy));pt[m]=z['prediction']
   check(f'{task}_{seed}_train_count',len(ot)==(288 if task=='CAISO' else 1079));xt=gd.history_features(raw,ot,window);frozen={}
   for name,k,full in [('Q80_STATIC_SELF',80,False),('Q70_WITH_FULL',70,True),('Q70_STATIC_SELF',70,False)]:
    w,models,rec=fit_weights(pt,yt,(xt>=th[k]).all(1),full,k==70);frozen[name]=dict(weights=w.tolist(),models=models,q=k,records=rec,threshold=th[k].tolist())
   write(D/f'{task}_{seed}_GRAPH_WEIGHTS_FROZEN.json',dict(arms=frozen,training_origin_sha=digest(ot),train_n=len(ot),train_only=True))
   y=None
   for m in ['FULL','STATIC','SELF']:
    if task=='CAISO':
     _,fe,_=ca_sources(seed,m);z=load(fe,['origins','prediction','truth']);yy=z['truth'];pp=z['prediction']
    else:
     z=load(B/'energy_confirmation_v1_20260926/runs'/f'{m}_{seed}_0.001/validation_predictions.npz',['origins','prediction']);yy=raw[orig[:,None]+np.arange(24)].transpose(0,2,1);pp=z['prediction'].transpose(0,2,1)
    check(f'{task}_{seed}_{m}_eval_join',np.array_equal(z['origins'],orig));pe[m]=pp
    if y is None:y=yy
    else:check(f'{task}_{seed}_{m}_truth',np.array_equal(y,yy))
   old=load(PREV/f'{task}_{seed}_CONVEX_PREDICTIONS.npz',['origins','prediction','risk']);check(f'{task}_{seed}_q80_same',np.array_equal(old['origins'],orig) and np.array_equal(old['risk'],risk[80]));pe['Q80_WITH_FULL']=old['prediction']
   for name,r in frozen.items():
    w=np.asarray(r['weights'])[risk[r['q']].astype(int)];pe[name]=sum(pe[m]*w[:,None,:,j] for j,m in enumerate(r['models']))
    check(name+'_envelope_'+str(seed),np.all(pe[name]>=np.minimum.reduce([pe[m] for m in r['models']])-1e-8) and np.all(pe[name]<=np.maximum.reduce([pe[m] for m in r['models']])+1e-8))
   masks=dict(all=np.ones(y.shape,bool),high_q70=np.broadcast_to(risk[70][:,None,None],y.shape),far=np.broadcast_to((np.arange(y.shape[2])>=(8 if y.shape[2]==12 else 18))[None,None,:],y.shape),last=np.broadcast_to((np.arange(y.shape[2])==y.shape[2]-1)[None,None,:],y.shape))
   masks['high_q70_far']=masks['high_q70']&masks['far'];per[str(seed)]={}
   for name,pp in pe.items():
    per[str(seed)][name]={label:metric_on(pp,y,mask) for label,mask in masks.items()};errors.setdefault(name,[]).append(abs(pp-y))
   del pt,pe,z;gc.collect()
  avg={m:np.mean(v,axis=0) for m,v in errors.items()};summary={m:{part:{k:float(np.mean([per[str(s)][m][part][k] for s in SEEDS])) for k in ['mae','rmse','cells']} if per[str(SEEDS[0])][m][part] else None for part in masks} for m in avg}
  comp={}
  for cand,ref in [('Q80_WITH_FULL','Q80_STATIC_SELF'),('Q70_WITH_FULL','Q70_STATIC_SELF'),('Q70_WITH_FULL','STATIC'),('Q70_WITH_FULL','SELF')]:
   comp[cand+'_vs_'+ref]={part:dict(**boot_losses(avg[cand],avg[ref],mask,days,task),seed_wins=sum(per[str(s)][cand][part]['mae']<per[str(s)][ref][part]['mae'] for s in SEEDS)) if mask.any() else None for part,mask in masks.items()}
  result[task]=dict(summary=summary,comparisons=comp,per_seed=per,state_support=statecounts,scope='retrospective development; weights TRAIN-only but original checkpoint selection exposed evaluation; q70 and reduced penalty newly user-selected hypotheses, not blind confirmation')
  write(D/'PROBLEM1_GRAPH_ABLATION.json',result);del errors,avg,raw;gc.collect()
 return result
