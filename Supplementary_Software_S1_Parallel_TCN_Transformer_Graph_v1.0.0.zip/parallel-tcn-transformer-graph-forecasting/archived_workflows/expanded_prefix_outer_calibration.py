# Recorded historical component workflow. See docs/REPRODUCTION_LEVELS.md.
from common20 import *
from group_calibration20 import candidates as frozen_group
def make_outer(z,original=None):
 frozen,rec=frozen_group(z);floor=frozen['STATE_GROUP_AWARE_OUTER_CAP25'] if original is None else original
 high=np.zeros(len(floor),bool);th=[]
 for h in np.unique(z['h']):
  v=float(np.quantile(z['spread'][z['early']&(z['h']==h)],.85));high[z['h']==h]=z['spread'][z['h']==h]>=v;th.append(dict(h=int(h),raw_q85=v))
 group=((z['group']==1)|((z['group']==0)&high)).astype(int)
 raw=floor.copy();recipes=[]
 for h in np.unique(z['h']):
  m,r=dc.calibration_mask(z,group,1,h);use=(group==1)&(z['h']==h);r['h']=int(h);r['margins']=[]
  if r['supported']:
   for j in [10,11,12]:
    c=dc.prev.fq((z['truth'][m]-floor[m,j])/z['scale'][m],Q[j]);raw[use,j]+=c*z['scale'][use];r['margins'].append(c)
  recipes.append(r)
 for j in [10,11,12]:raw[:,j]=np.maximum(raw[:,j],raw[:,j-1]+1e-8)
 raw[group!=1]=floor[group!=1] # Preserve untouched G2 exactly.
 _,ix=np.unique(z['cut'],return_inverse=True);base=z['base'];bw=np.bincount(ix,weights=base[:,-1]-base[:,0])
 used=np.bincount(ix,weights=floor[:,-1]-floor[:,0]-(base[:,-1]-base[:,0]));extra=np.bincount(ix,weights=raw[:,-1]-floor[:,-1]);out={};caps={}
 for cap,name in zip([.25,.35],OUTER_NAMES):
  check(name+'_floor_feasible',np.all(used<=cap*bw+1e-8))
  f=np.minimum(1,np.divide(np.maximum(0,cap*bw-used),extra,out=np.ones_like(extra),where=extra>0))
  q=floor.copy();q[:,10:]=floor[:,10:]+f[ix,None]*(raw[:,10:]-floor[:,10:])
  ratio=np.bincount(ix,weights=q[:,-1]-q[:,0])/bw
  check(name+'_cap99',ratio.max()<=1+cap+1e-10)
  check(name+'_inner_exact',np.array_equal(q[:,:10],floor[:,:10]))
  check(name+'_G2_exact',np.array_equal(q[z['group']==2],floor[z['group']==2]))
  out[name]=q;caps[name]=dict(max_issue99=float(ratio.max()),factor_min=float(f.min()))
 return out,dict(raw_disagreement_thresholds=th,new_group_CAL_cells=int((group.astype(bool)&z['early']).sum()),margins=recipes,caps=caps)