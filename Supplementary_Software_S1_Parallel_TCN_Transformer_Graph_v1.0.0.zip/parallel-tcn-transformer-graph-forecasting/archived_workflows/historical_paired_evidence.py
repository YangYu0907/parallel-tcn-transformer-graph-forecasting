# Recorded historical component workflow. See docs/REPRODUCTION_LEVELS.md.
from common import *
import numpy as np
def holm(p):
 p=np.asarray(p);o=np.argsort(p);q=np.empty_like(p);q[o]=np.minimum(1,np.maximum.accumulate(p[o]*(len(p)-np.arange(len(p)))));return q
def infer(a,b,groups,rng):
 # Differences are averaged over seeds before grouping; seed chains are not independent dates.
 delta=b-a;unique=np.unique(groups);sums=np.array([delta[groups==g].sum() for g in unique]);counts=np.array([(groups==g).sum() for g in unique]);draw=rng.integers(len(unique),size=(2000,len(unique)));est=sums[draw].sum(1)/counts[draw].sum(1);observed=delta.mean()
 # Centered block bootstrap null, two sided. These are exploratory after selection.
 p=(1+np.count_nonzero(abs(est-observed)>=abs(observed)))/(len(est)+1)
 return dict(contrast_control_minus_candidate=float(observed),ci_low=float(np.quantile(est,.025)),ci_high=float(np.quantile(est,.975)),p_raw=float(p),blocks=len(unique),origins=len(delta))
def main():
 with numeric('paired development component and graph evidence'):
  verify_sources();rng=np.random.default_rng(20261003);rows=[];errors={}
  for seed in SEEDS:
   with np.load(FIRST/'component_predictions'/f'{seed}.npz') as z:
    y=z['truth'];o=z['origins'];st=z['states']
    for k in z.files:
     if k not in ['truth','origins','states']:errors.setdefault(k,[]).append(z[k]-y)
   with np.load(FIRST/'v7_refit_predictions'/f'{seed}.npz') as z:
    for k in ['NO_DURATION_FEATURES','NO_TEMPERATURE']:errors.setdefault(k,[]).append(z[k]-z['truth'])
  panel=np.load(T/'adaptive_experts_v4_20260929/panel.npz');ix=np.searchsorted(panel['origins'],o);assert np.array_equal(panel['origins'][ix],o);groups=panel['cutoff'][ix]//86400
  losses={k:dict(MAE=np.abs(v).mean((0,2,3)),MSE=np.square(v).mean((0,2,3))) for k,v in errors.items()}
  for metric in ['MAE','MSE']:
   for control in errors:
    if control=='CONTEXT':continue
    rows.append(dict(task='CAISO_development',metric=metric,candidate='CONTEXT',control=control,**infer(losses['CONTEXT'][metric],losses[control][metric],groups,rng)))
  e=B/'energy_confirmation_v1_20260926';z=np.load(e/'data/train_valid.npz');va=z['valid'];raw=z['raw'];y=np.stack([raw[i:i+24] for i in va]);days=z['timestamps'][va].astype('datetime64[D]').astype(int);groups=(days-days.min())//7;errors={}
  for s in SEEDS:
   for k in ['FULL','STATIC','SELF']:
    with np.load(e/'runs'/f'{k}_{s}_0.001/validation_predictions.npz') as p:assert np.array_equal(p['origins'],va);errors.setdefault(k,[]).append(p['prediction']-y)
  losses={k:dict(MAE=np.abs(v).mean((0,2,3)),MSE=np.square(v).mean((0,2,3))) for k,v in errors.items()}
  for metric in ['MAE','MSE']:
   for k in ['STATIC','SELF']:rows.append(dict(task='Europe2015_development',metric=metric,candidate='FULL',control=k,**infer(losses['FULL'][metric],losses[k][metric],groups,rng)))
  for task in ['CAISO_development','Europe2015_development']:
   ids=[i for i,r in enumerate(rows) if r['task']==task];adj=holm([rows[i]['p_raw'] for i in ids])
   for i,p in zip(ids,adj):rows[i]['p_holm']=float(p)
  table('PAIRED_COMPONENT_GRAPH_RESULTS.csv',rows);write(ROOT/'PAIRED_EVIDENCE.json',dict(at=now(),rows=rows,scope='Exploratory after development selection; not independent hypothesis confirmation',calendar='CAISO distinct UTC origin dates, no compressed gaps; Europe fixed contiguous seven-day blocks, last block count weighted',replicates=2000,families='All included controls and both scores within each dataset analysis; no removal of negative directions',new_fits=0,protected=verify_protected()))
  print(json.dumps(dict(rows=len(rows),status='completed')))
if __name__=='__main__':main()
