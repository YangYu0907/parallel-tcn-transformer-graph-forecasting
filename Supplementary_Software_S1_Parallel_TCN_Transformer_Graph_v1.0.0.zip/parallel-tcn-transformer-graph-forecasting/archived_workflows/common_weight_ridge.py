# Recorded historical component workflow. See docs/REPRODUCTION_LEVELS.md.
from batch_common import *
def run():
 from scipy.linalg.blas import dsyrk
 from scipy.linalg import cho_factor,cho_solve
 started=time.monotonic();d=gd.caiso_data();ids=d['train'];price=d['price'];p=8640;k=360;step=128;target=np.load(d['paths']['target_scaled.npy'],mmap_mode='r')
 check('ridge_alignment_train17102',len(ids)==17102);check('ridge_alignment_pre_eval',d['times'][ids[-1]+11]<d['times'][d['evaluation'][0]])
 def batch(oo):return np.stack([price[o-288:o].reshape(-1) for o in oo]),np.stack([target[o:o+12].T.reshape(-1) for o in oo]).astype(float)
 xm=np.zeros(p);ym=np.zeros(k)
 for i in range(0,len(ids),step):
  x,y=batch(ids[i:i+step]);xm+=x.sum(0);ym+=y.sum(0)
 xm/=len(ids);ym/=len(ids);G=np.zeros((p,p),order='F');rhs=np.zeros((p,k))
 for i in range(0,len(ids),step):
  guard();x,y=batch(ids[i:i+step]);x=np.asfortranarray(x-xm);y-=ym;G=dsyrk(1.,x,beta=1.,c=G,trans=1,lower=1,overwrite_c=1);rhs+=x.T@y
 progress('ridge_alpha1_unique_Gram_ready');G[np.diag_indices(p)]+=1.
 factor,low=cho_factor(G,lower=True,overwrite_a=True,check_finite=False);coef=cho_solve((factor,low),rhs,check_finite=False);intercept=ym-xm@coef;del G,factor;gc.collect()
 residual=coef.copy()
 for i in range(0,len(ids),step):
  guard();x,y=batch(ids[i:i+step]);xx=x-xm;residual+=xx.T@(xx@coef-(y-ym))
 rel=float(np.linalg.norm(residual)/max(1,np.linalg.norm(rhs)));check('ridge_alpha1_unique_normal_eq',rel<1e-7,relative=rel)
 save('RIDGE_ALPHA1_UNIQUE_FROZEN.npz',coef=coef,intercept=intercept,train_origins=ids,alpha=np.array(1.))
 pred=[];truth=[]
 for i in range(0,len(d['evaluation']),step):
  guard();x,y=batch(d['evaluation'][i:i+step]);pred.append((x@coef+intercept).reshape(-1,30,12)*d['scale'][None,:,None]+d['center'][None,:,None]);truth.append(y.reshape(-1,30,12)*d['scale'][None,:,None]+d['center'][None,:,None])
 pred=np.concatenate(pred);truth=np.concatenate(truth);prior=load(PREV/'RIDGE_CV_P3.npz',['truth','origins','prediction']);check('ridge_alignment_same_panel',np.array_equal(prior['truth'],truth) and np.array_equal(prior['origins'],d['evaluation']))
 oldcoef=load(PREV/'RIDGE_CV_FROZEN.npz',['train_origins','alpha']);check('ridge_alignment_same_train',np.array_equal(oldcoef['train_origins'],ids) and oldcoef['alpha']==50000)
 save('RIDGE_ALPHA1_UNIQUE_P3.npz',origins=d['evaluation'],prediction=pred)
 out=dict(alpha1_unique=gd.metric(pred,truth),alpha50000_unique=gd.metric(prior['prediction'],truth),controlled_difference='alpha only; same17102uniqueunit-weightTRAIN,288x30inputs,360targets,unpenalizedintercept,scaler,evaluation3397origins',relative_equation_residual=rel,seconds=time.monotonic()-started,additional_closedform_fits=1,neural_tree_fits=0)
 write(D/'PROBLEM2_RIDGE_WEIGHT_ALIGNMENT.json',out);target._mmap.close();return out
