# Recorded study workflow. See docs/REPRODUCTION_LEVELS.md before execution.
"""Early end-to-end experts; executes only after formal source and protocol seal."""
from pathlib import Path
import os,sys,json,time,hashlib,datetime as dt,contextlib,importlib.util
for k in ['OMP_NUM_THREADS','MKL_NUM_THREADS','OPENBLAS_NUM_THREADS','NUMEXPR_NUM_THREADS']:os.environ[k]='1'
O=Path(__file__).resolve().parent;B=O.parent
Q=Path('${DATA_ROOT}/CAISO_early_source_completion_20261020');F=Q/'fresh_inputs';W=Q/'full_training'
T=Path('${DATA_ROOT}/CAISO_early_expert_timeline_20261019')
LEVELS=[.005,.01,.025,.05,.1,.25,.5,.75,.9,.95,.975,.99,.995]
sp=importlib.util.spec_from_file_location('runtime',B/'v7_netload_point_upgrade_20261018/common.py');rt=importlib.util.module_from_spec(sp);sp.loader.exec_module(rt)
read,sha,now=rt.read,rt.sha,rt.now
def json_native(value):
 # Logging/receipts only: preserve NumPy scalar values without changing arithmetic.
 import numpy as np
 def convert(v):
  if isinstance(v,np.generic):return v.item()
  raise TypeError(f'Unsupported JSON metadata type: {type(v).__name__}')
 return json.loads(json.dumps(value,ensure_ascii=False,allow_nan=False,default=convert))
def save(path,value):
 return rt.save(path,json_native(value))
def guard():
 rt.guard()
 for d in [B,O,Q]:
  if any((d/x).exists() for x in ['STOP_REQUESTED','STOP_REQUESTED.json']):raise InterruptedError('User stop request')
 pause=B.parent/'RESEARCH_PAUSED.json'
 if pause.exists() and (read(pause).get('stop_preparation_and_training') or read(pause).get('status')=='paused_by_user'):raise InterruptedError('User paused')
 if os.environ.get('CAISO_EARLY_DEADLINE') and time.time()>float(os.environ['CAISO_EARLY_DEADLINE']):raise TimeoutError('Registered72hour wall budget')
def tick(stage,**kw):
 guard();kw=json_native(kw);save(W/'STATUS.json',dict(at=now(),pid=os.getpid(),stage=stage,status='running',**kw));print(stage,json.dumps(kw),flush=True)
@contextlib.contextmanager
def locked(action):
 import psutil
 info=rt.guard(True);owner=dict(pid=os.getpid(),create_time=psutil.Process().create_time(),task=str(O),action=action,at=now())
 with rt.LOCK.open('x',encoding='utf-8') as f:json.dump(owner,f)
 try:yield info
 finally:
  if rt.LOCK.exists() and read(rt.LOCK)==owner:rt.LOCK.unlink()
def sealcheck():
 p=read(O/'EXECUTION_PROTOCOL.json');assert p['status']=='frozen_before_fits'
 assert read(Q/'TRAINING_ADMISSION_GATE.json')['source_and_support_passed']
 assert read(Q/'SOURCE_EVENT_AUDIT.json')['passed']
 for path,h in p['bindings'].items():assert sha(path)==h,path
 for path,h in read(O/'PROTOCOL.json')['old_v7_protected'].items():assert sha(path)==h,path
 return p
def atomic_torch(p,obj,torch):
 p=Path(p);tmp=p.with_suffix('.tmp');torch.save(obj,tmp);os.replace(tmp,p)
def atomic_np(p,**obj):
 import numpy as np
 p=Path(p);tmp=p.with_suffix('.tmp')
 with tmp.open('wb') as f:np.savez_compressed(f,**obj)
 os.replace(tmp,p)
def libraries():
 import numpy as np,torch
 from torch import nn
 # Original core imports only LEVELS from common; keep its source unchanged.
 sys.modules['common']=sys.modules[__name__]
 sp=importlib.util.spec_from_file_location('early_existing_core',B/'unified_forward_main_20261019/model.py');mm=importlib.util.module_from_spec(sp);sp.loader.exec_module(mm)
 torch.set_num_threads(1)
 return np,torch,nn,mm.Core
class Data:
 def __init__(self):
  import numpy as np
  self.np=np;self.sc=read(F/'SCALERS.json');self.unit=float(self.sc['unit'])
  with np.load(F/'ORIGINS.npz') as z:self.roles={k:z[k] for k in z.files}
  self.x=np.load(F/'X.npy',mmap_mode='r');self.src=np.load(F/'SOURCE.npy',mmap_mode='r')
  root=Path(read('${DATA_ROOT}/CAISO_unified_forward_main_20261019/CAISO/PRETRAIN.json')['paths']['features.npy']).parent
  self.times=np.load(root/'timestamps_seconds.npy',mmap_mode='r');self.pub=np.load(root/'forecast_publications_seconds.npy',mmap_mode='r')
  self.pc=np.asarray(self.sc['price_center'])[:,0];self.ps=np.asarray(self.sc['price_scale'])[:,0]
  self.label={}
 def labels(self,role):
  assert role!='HISTORICAL_DEV_CHECK','Score after separate full policy freeze'
  if role not in self.label:
   with self.np.load(F/(role+'_LABELS.npz')) as z:self.label[role]={k:z[k] for k in z.files}
  return self.label[role]
 def batch(self,origins):
  np=self.np;xx=np.stack([self.x[o-288:o].copy() for o in origins])
  for j,o in enumerate(origins):
   pubs=np.asarray(self.pub[o-288:o]);issue=int(self.times[o-1]);assert (pubs>0).all() and (pubs<=issue).all()
   xx[j,:,:,19:21]=np.clip((issue-pubs)/60/np.array([5.,660.]),0,1)[:,None,:]
  assert np.isfinite(xx).all()
  ii=np.searchsorted(self.roles['ALL'],origins);assert np.array_equal(self.roles['ALL'][ii],origins)
  src=np.array(self.src[ii],copy=True)
  # Invert only the already permitted observed history price channel.
  raw=np.sinh(xx[:,:,:,0].astype(float))*self.ps+self.pc
  return xx,src,raw.astype('float32')
def make_linear(nn,H=12):
 class EarlyDLinear(nn.Module):
  def __init__(self):
   super().__init__();self.season=nn.Linear(288,H);self.trend=nn.Linear(288,H)
   for layer in [self.season,self.trend]:nn.init.zeros_(layer.weight);nn.init.zeros_(layer.bias)
  def forward(self,x):
   import torch.nn.functional as fn
   z=x.transpose(1,2);trend=fn.avg_pool1d(fn.pad(z,(12,12),mode='replicate'),25,stride=1);return self.season(z-trend)+self.trend(trend)
 return EarlyDLinear()
def fit_anchor(seed):
 with locked('fresh_early_DLinear_'+str(seed)):
  p=sealcheck();np,torch,nn,Core=libraries();d=Data();stage=W/str(seed);stage.mkdir(parents=True,exist_ok=True);cp=stage/'ANCHOR.pt';receipt=stage/'ANCHOR.json'
  if receipt.exists():assert sha(cp)==read(receipt)['sha256'];return
  torch.manual_seed(seed);m=make_linear(nn);opt=torch.optim.AdamW(m.parameters(),lr=.001,weight_decay=.01)
  train=d.labels('EXPERT_FIT');valid=d.labels('EXPERT_VALID');tf=train['y'];tl=train['last'];vf=valid['y'];vl=valid['last']
  ae=float(np.mean(abs((tf-tl[:,:,None])/d.unit)));se=float(np.mean(((tf-tl[:,:,None])/d.unit)**2));ae=max(ae,1e-6);se=max(se,1e-6)
  vae=float(np.mean(abs(vf-vl[:,:,None])));vrm=float(np.sqrt(np.mean((vf-vl[:,:,None])**2)))
  start=0;history=[];best=float('inf');beststate=None;stale=0;bestep=0
  if cp.exists():
   z=torch.load(cp,weights_only=False);m.load_state_dict(z['model']);opt.load_state_dict(z['optimizer']);start=z['epoch'];history=z['history'];best=z['best'];beststate=z['beststate'];stale=z['stale'];bestep=z['bestep'];torch.set_rng_state(z['rng'])
  for ep in range(start,48):
   m.train();order=np.random.default_rng(seed+ep).permutation(len(tf));sumloss=0.;steps=0
   for st in range(0,len(order),128):
    guard();ii=order[st:st+128];_,_,raw=d.batch(train['origins'][ii]);z=(raw-tl[ii,None,:])/d.unit;target=torch.from_numpy(((tf[ii]-tl[ii,:,None])/d.unit).astype('float32'))
    opt.zero_grad(set_to_none=True);pred=m(torch.from_numpy(z));loss=abs(pred-target).mean()/ae+((pred-target)**2).mean()/se
    assert torch.isfinite(loss);loss.backward();torch.nn.utils.clip_grad_norm_(m.parameters(),1,error_if_nonfinite=True);opt.step();sumloss+=float(loss.detach());steps+=1
   m.eval();ab=0.;sq=0.;cnt=0
   with torch.no_grad():
    for st in range(0,len(vf),128):
     guard();ii=np.arange(st,min(st+128,len(vf)));_,_,raw=d.batch(valid['origins'][ii]);pred=vl[ii,:,None]+d.unit*m(torch.from_numpy((raw-vl[ii,None,:])/d.unit)).numpy();e=vf[ii]-pred;ab+=abs(e).sum();sq+=(e*e).sum();cnt+=e.size
   ma=ab/cnt;rm=float(np.sqrt(sq/cnt));score=ma/vae+rm/vrm;history.append(dict(epoch=ep+1,loss=sumloss/steps,VALID_MAE=ma,VALID_RMSE=rm,score=score))
   if score<best-1e-10:best=score;bestep=ep+1;beststate={k:v.detach().clone() for k,v in m.state_dict().items()};stale=0
   else:stale+=1
   atomic_torch(cp,dict(model=m.state_dict(),optimizer=opt.state_dict(),epoch=ep+1,history=history,best=best,beststate=beststate,stale=stale,bestep=bestep,rng=torch.get_rng_state()),torch);tick('early_anchor_epoch',seed=seed,epoch=ep+1,selected=bestep,score=score)
   if ep+1>=12 and stale>=8:break
  m.load_state_dict(beststate);outputs={}
  for role,oo in d.roles.items():
   if role in ['ALL','ISSUE']:continue
   pred=[]
   with torch.no_grad():
    for st in range(0,len(oo),128):
     guard();_,_,raw=d.batch(oo[st:st+128]);last=raw[:,-1];pp=last[:,:,None]+d.unit*m(torch.from_numpy((raw-last[:,None,:])/d.unit)).numpy();pred.append(pp)
   f=stage/('ANCHOR_'+role+'.npz');atomic_np(f,origins=oo,point=np.concatenate(pred));outputs[str(f)]=sha(f)
  save(receipt,dict(at=now(),sha256=sha(cp),seed=seed,selected_epoch=bestep,epochs=len(history),history=history,outputs=outputs,fit='EXPERT_FIT',selection='EXPERT_VALID',late_fitted_state_reused=False,loss_normalizers=dict(AE=ae,SE=se),DEV_targets_read=False))
def fit_expert(seed,arm,maxepochs=48):
 with locked('early_full_expert_'+str(seed)+'_'+arm):
  protocol=sealcheck();np,torch,nn,Core=libraries();d=Data();stage=W/str(seed);cp=stage/(arm+'.pt');receipt=stage/(arm+'.json')
  assert arm in ['I0_DYNAMIC','I1_DYNAMIC','I1_STATIC','I1_FLAT']
  if receipt.exists() and read(receipt)['max_epoch_budget']>=maxepochs:assert sha(cp)==read(receipt)['sha256'];return
  ar=read(stage/'ANCHOR.json')
  for path,h in ar['outputs'].items():assert sha(path)==h
  train=d.labels('EXPERT_FIT');valid=d.labels('EXPERT_VALID');base=np.load(stage/'ANCHOR_EXPERT_FIT.npz')['point'];vbase=np.load(stage/'ANCHOR_EXPERT_VALID.npz')['point']
  torch.manual_seed(seed);m=Core(30,29,12,288);m.mode=arm.split('_',1)[1];m.info=int(arm[1]);m.initialize_quantiles(np.quantile(((train['y']-base)/d.unit).ravel(),LEVELS))
  # Identical available parameter template; inactive branches have zero structural role.
  opt=torch.optim.AdamW(m.parameters(),lr=.001,weight_decay=.01)
  ae=ar['loss_normalizers']['AE'];se=ar['loss_normalizers']['SE'];va=float(np.mean(abs(valid['y']-valid['last'][:,:,None])));vr=float(np.sqrt(np.mean((valid['y']-valid['last'][:,:,None])**2)))
  def batch(role,ii,anchor):
   labs=d.labels(role);xx,src,raw=d.batch(labs['origins'][ii]);prior=np.stack([(anchor[ii]-labs['last'][ii,:,None])/d.unit,np.zeros_like(anchor[ii])],-1).astype('float32');target=((labs['y'][ii]-anchor[ii])/d.unit).astype('float32')
   return torch.from_numpy(xx),torch.from_numpy(src),torch.from_numpy(prior),torch.from_numpy(target)
  start=0;batchstart=0;history=[];best=float('inf');beststate=None;stale=0;bestep=0;grads={};updates=0;active_names=set()
  if cp.exists():
   z=torch.load(cp,weights_only=False);m.load_state_dict(z['model']);opt.load_state_dict(z['optimizer']);start=z['epoch'];batchstart=z['batch'];history=z['history'];best=z['best'];beststate=z['beststate'];stale=z['stale'];bestep=z['bestep'];grads=z['grads'];updates=z['updates'];active_names=set(z.get('active_names',[]));torch.set_rng_state(z['rng'])
  def commit(ep,ba):
   atomic_torch(cp,dict(model=m.state_dict(),optimizer=opt.state_dict(),epoch=ep,batch=ba,history=history,best=best,beststate=beststate,stale=stale,bestep=bestep,grads=grads,updates=updates,active_names=sorted(active_names),rng=torch.get_rng_state()),torch)
  started=time.monotonic()
  for ep in range(start,maxepochs):
   m.train();order=np.random.default_rng(seed+ep).permutation(len(base));los=0.;nb=0
   for st in range(batchstart if ep==start else 0,len(order),16):
    guard();ii=order[st:st+16];x,s,p,y=batch('EXPERT_FIT',ii,base);opt.zero_grad(set_to_none=True);q=m(x,s,p);mu=m.mean(q);e=y[...,None]-q;pb=torch.maximum(m.levels*e,(m.levels-1)*e).mean();loss=abs(mu-y).mean()/ae+((mu-y)**2).mean()/se+pb/ae
    assert torch.isfinite(loss);loss.backward();torch.nn.utils.clip_grad_norm_(m.parameters(),1,error_if_nonfinite=True)
    active_names.update(name for name,v in m.named_parameters() if v.grad is not None)
    for name in ['query.weight','key.weight','alpha','static','fuse.weight','project.weight']:
     v=dict(m.named_parameters())[name]
     if v.grad is not None:grads[name]=grads.get(name,0.)+float(v.grad.norm())
    opt.step()
    with torch.no_grad():m.alpha.clamp_(0,1)
    los+=float(loss.detach());nb+=1;updates+=1
    if st%512==0:commit(ep,st+len(ii));tick('end_to_end_expert',seed=seed,arm=arm,epoch=ep+1,done=st+len(ii),total=len(base),updates=updates)
   m.eval();ab=0.;sq=0.;cnt=0
   with torch.no_grad():
    for st in range(0,len(vbase),16):
     guard();ii=np.arange(st,min(st+16,len(vbase)));x,s,p,y=batch('EXPERT_VALID',ii,vbase);q=m(x,s,p);err=d.unit*(m.mean(q)-y).numpy().astype(float);ab+=abs(err).sum();sq+=(err*err).sum();cnt+=err.size
   ma=ab/cnt;rm=float(np.sqrt(sq/cnt));score=ma/va+rm/vr;history.append(dict(epoch=ep+1,VALID_MAE=ma,VALID_RMSE=rm,score=score,loss=los/max(nb,1),alpha=float(m.alpha.detach()),updates=updates))
   if score<best-1e-10:best=score;bestep=ep+1;beststate={k:v.detach().clone() for k,v in m.state_dict().items()};stale=0
   else:stale+=1
   commit(ep+1,0);batchstart=0;tick('end_to_end_epoch',seed=seed,arm=arm,epoch=ep+1,selected=bestep,score=score,seconds=time.monotonic()-started)
   if ep+1>=12 and stale>=8:break
  m.load_state_dict(beststate);m.eval();outputs={}
  # One constant location correction, fitted once on EXPERT_CAL, then frozen.
  cal=d.labels('EXPERT_CAL');ca=np.load(stage/'ANCHOR_EXPERT_CAL.npz')['point'];cm=[]
  with torch.no_grad():
   for st in range(0,len(ca),16):
    guard();ii=np.arange(st,min(st+16,len(ca)));x,s,p,y=batch('EXPERT_CAL',ii,ca);cm.append(ca[ii]+d.unit*m.mean(m(x,s,p)).numpy())
  calpoint=np.concatenate(cm).astype(float);er=cal['y']-calpoint;b0=float(er.mean());lo=0.;hi=1.
  if np.mean(abs(er-b0))<=np.mean(abs(er))+1e-12:bias=b0
  else:
   for _ in range(52):
    mid=(lo+hi)/2
    if np.mean(abs(er-mid*b0))<=np.mean(abs(er))+1e-12:lo=mid
    else:hi=mid
   bias=lo*b0
  assert np.mean((er-bias)**2)<=np.mean(er*er)+1e-10
  assert np.mean(abs(er-bias))<=np.mean(abs(er))+1e-10
  # Input-only inference to later roles; scoring targets remain sealed.
  for role,oo in d.roles.items():
   if role in ['ALL','ISSUE']:continue
   anchor=np.load(stage/('ANCHOR_'+role+'.npz'))['point'];qs=[]
   with torch.no_grad():
    for st in range(0,len(oo),16):
     guard();ids=oo[st:st+16];xx,src,raw=d.batch(ids);last=raw[:,-1];pr=np.stack([(anchor[st:st+len(ids)]-last[:,:,None])/d.unit,np.zeros_like(anchor[st:st+len(ids)])],-1).astype('float32')
     q=m(torch.from_numpy(xx),torch.from_numpy(src),torch.from_numpy(pr)).numpy();qs.append(anchor[st:st+len(ids),...,None]+d.unit*q+bias)
   f=stage/(arm+'_'+role+'.npz');atomic_np(f,origins=oo,q=np.concatenate(qs));outputs[str(f)]=sha(f)
  save(receipt,dict(at=now(),sha256=sha(cp),seed=seed,arm=arm,max_epoch_budget=maxepochs,selected_epoch=bestep,epochs=len(history),updates=updates,history=history,gradient_norm_sums=grads,parameters=sum(v.numel() for v in m.parameters()),active_parameters=sum(v.numel() for name,v in m.named_parameters() if name in active_names),active_parameter_names=sorted(active_names),seconds=time.monotonic()-started,outputs=outputs,trained_end_to_end=True,DEV_targets_read=False,calibration_location_bias=bias,calibration=dict(raw_MAE=float(abs(er).mean()),raw_RMSE=float(np.sqrt((er*er).mean())),calibrated_MAE=float(abs(er-bias).mean()),calibrated_RMSE=float(np.sqrt(((er-bias)**2).mean())),scope='One common scalar location correction; raw predictions recoverable by subtracting bias.'),source_scope='Native first-advisory trajectory, not historical revisions or nodal deliverable reserves.',matching='Same common parameter template and assigned optimization/selection opportunities; active parameters, actual updates and FLOPs can differ by graph mode.'))
if __name__=='__main__':
 W.mkdir(exist_ok=True)
 if sys.argv[1]=='anchor':fit_anchor(int(sys.argv[2]))
 elif sys.argv[1]=='expert':fit_expert(int(sys.argv[2]),sys.argv[3],int(sys.argv[4]) if len(sys.argv)>4 else 48)

