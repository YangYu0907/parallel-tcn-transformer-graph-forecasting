"""Executed neural architecture, extracted without altering the Core implementation."""
import math
import numpy as np
import torch
from torch import nn
import torch.nn.functional as F
from .constants import QUANTILE_LEVELS as LEVELS

class Core(nn.Module):
 def __init__(self,N,C,H,L):
  super().__init__();D=16;self.N=N;self.H=H;self.L=L;self.mode='STATIC';self.info=0;self.intervention=None
  self.project=nn.Conv1d(C,D,1);self.convs=nn.ModuleList(nn.Conv1d(D,D,3,dilation=d,padding=2*d) for d in [1,4,16,64]);self.norms=nn.ModuleList(nn.LayerNorm(D) for _ in range(4))
  self.patch=nn.Linear(12*C,D);self.position=nn.Parameter(torch.zeros(1,L//12,D));enc=nn.TransformerEncoderLayer(D,2,32,dropout=.05,batch_first=True,norm_first=False)
  self.transformer=nn.TransformerEncoder(enc,1,enable_nested_tensor=False);self.fuse=nn.Linear(2*D+10,2)
  self.node=nn.Embedding(N,8);self.horizon=nn.Embedding(H,8);self.static=nn.Parameter(torch.zeros(N,N));self.query=nn.Linear(D+10,D);self.key=nn.Linear(D+10,D);self.value=nn.Linear(D,D);self.alpha=nn.Parameter(torch.tensor(.1));self.flat=nn.Linear(N*D,N*D)
  self.decoder=nn.Sequential(nn.Linear(2*D+8+8+10+2,32),nn.GELU(),nn.Linear(32,13));nn.init.zeros_(self.decoder[-1].weight)
  self.register_buffer('levels',torch.tensor(LEVELS,dtype=torch.float32));self.last_adj=None
 def initialize_quantiles(self,values):
  values=np.asarray(values);g=np.r_[np.maximum(values[6]-values[:6],1e-3)[::-1],np.maximum(values[7:]-values[6],1e-3)]
  # Ordered adjacent distances around median: six outward left/right increments.
  left=np.maximum(np.diff(np.r_[values[:6],values[6]])[::-1],1e-3);right=np.maximum(np.diff(values[6:]),1e-3)
  bias=np.r_[values[6],np.log(np.expm1(np.clip(np.r_[left,right],1e-4,40)))]
  with torch.no_grad():self.decoder[-1].bias.copy_(torch.tensor(bias,dtype=torch.float32))
 def encode(self,x,src):
  b,l,n,c=x.shape;z=x.permute(0,2,3,1).reshape(b*n,c,l);v=self.project(z)
  for conv,norm in zip(self.convs,self.norms):
   u=F.gelu(conv(v)[...,:l]);v=norm((v+u).transpose(1,2)).transpose(1,2)
  tcn=v.mean(-1).reshape(b,n,16)
  patches=x.permute(0,2,1,3).reshape(b*n,l//12,12*c);tr=self.transformer(self.patch(patches)+self.position).mean(1).reshape(b,n,16)
  ss=src[:,None,:].expand(-1,n,-1);w=torch.softmax(self.fuse(torch.cat([tcn,tr,ss],-1)),-1)
  return w[...,:1]*tcn+w[...,1:]*tr
 def forward(self,x,src,prior,specialist=None,ext=None):
  b=x.shape[0];src=src.clone()
  if self.info==0:src[:,:8]=0
  e=self.encode(x,src);s=src[:,None,:].expand(-1,self.N,-1);q=self.query(torch.cat([e,s],-1));k=self.key(torch.cat([e,s],-1));logits=self.static[None].expand(b,-1,-1)
  if self.mode=='DYNAMIC':logits=logits+self.alpha.clamp(0,1)*(q@k.transpose(-1,-2))/4
  mask=torch.eye(self.N,device=x.device,dtype=torch.bool)[None];adj=torch.softmax(logits.masked_fill(mask,-1e4),-1)
  if self.intervention is not None:
   if self.intervention[0]=='fixed':adj=self.intervention[1][None].expand(b,-1,-1)
   elif self.intervention[0]=='permute':
    adj=adj[:,:,self.intervention[1]].masked_fill(mask,0);adj=adj/adj.sum(-1,keepdim=True).clamp_min(1e-8)
  self.last_adj=adj
  innovation=e-e.mean(1,keepdim=True);values=torch.tanh(self.value(innovation));msg=adj@values
  if self.mode=='FLAT':msg=self.flat(values.reshape(b,-1)).reshape(b,self.N,16)
  if self.mode=='PRETRAIN':msg=torch.zeros_like(msg)
  node=self.node(torch.arange(self.N,device=x.device))[None,:,None,:].expand(b,-1,self.H,-1);hh=self.horizon(torch.arange(self.H,device=x.device))[None,None].expand(b,self.N,-1,-1)
  z=torch.cat([e[:,:,None,:].expand(-1,-1,self.H,-1),msg[:,:,None,:].expand(-1,-1,self.H,-1),node,hh,s[:,:,None,:].expand(-1,-1,self.H,-1),prior],-1)
  out=self.decoder(z);mid=out[...,:1];g=F.softplus(out[...,1:])+1e-5
  knots=torch.cat([(mid-torch.cumsum(g[...,:6],-1)).flip(-1),mid,mid+torch.cumsum(g[...,6:],-1)],-1)
  mean=self.mean(knots)
  if specialist is not None:knots=knots+torch.where(ext[:,:,None],specialist-mean,torch.zeros_like(mean))[...,None]
  return knots
 def mean(self,q):
  dt=self.levels[1:]-self.levels[:-1];sl=(q[...,1]-q[...,0])/math.log(2);sr=(q[...,-1]-q[...,-2])/math.log(2)
  return ((q[...,:-1]+q[...,1:])*.5*dt).sum(-1)+.005*(q[...,0]-sl)+.005*(q[...,-1]+sr)
