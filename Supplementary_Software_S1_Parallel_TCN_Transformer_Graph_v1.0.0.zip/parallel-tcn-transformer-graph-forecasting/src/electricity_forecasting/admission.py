"""Publication and target maturity rules, independent of evaluation outcomes."""
import numpy as np
def source_available(publication_seconds, issue_seconds, buffer_seconds=60):
    return np.asarray(publication_seconds) + buffer_seconds <= np.asarray(issue_seconds)
def labels_mature(target_seconds, fitting_cutoff_seconds, buffer_seconds=86400):
    return np.asarray(target_seconds) + buffer_seconds < np.asarray(fitting_cutoff_seconds)
