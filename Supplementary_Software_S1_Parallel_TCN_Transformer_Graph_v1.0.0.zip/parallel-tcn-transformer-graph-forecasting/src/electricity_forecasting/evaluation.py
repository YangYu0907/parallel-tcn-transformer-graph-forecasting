"""Executed seed aggregation, paired temporal block inference and multiplicity adjustment."""
def metrics(y,p,mask):
    import numpy as np
    e=y[None]-p
    return dict(cells=int(mask.sum()),MAE=float(abs(e[:,mask]).mean()),RMSE=float(np.sqrt((e[:,mask]**2).mean())))

def compare(y,p,r,days,mask):
    import numpy as np
    ae=abs(y[None]-r).mean(0)-abs(y[None]-p).mean(0)
    sr=((y[None]-r)**2).mean(0); sp=((y[None]-p)**2).mean(0)
    out=dict(MAE_improvement=float(ae[mask].mean()),RMSE_improvement=float(np.sqrt(sr[mask].mean())-np.sqrt(sp[mask].mean())),
             MAE_seed_wins=int(sum(abs(y[mask]-a[mask]).mean()<abs(y[mask]-b[mask]).mean() for a,b in zip(p,r))),
             RMSE_seed_wins=int(sum(((y[mask]-a[mask])**2).mean()<((y[mask]-b[mask])**2).mean() for a,b in zip(p,r))),
             dates=int(len(np.unique(days[mask]))),positive_means_candidate_better=True)
    for name,block in [('date',days),('seven_day',days//7)]:
        ids=np.unique(block[mask]); rows=[]
        for b in ids:
            m=mask&(block==b); rows.append([m.sum(),ae[m].sum(),sr[m].sum(),sp[m].sum()])
        v=np.asarray(rows,float); rng=np.random.default_rng(20261021)
        z=v[rng.integers(0,len(v),(2000,len(v)))].sum(1)
        da=z[:,1]/z[:,0]; dr=np.sqrt(z[:,2]/z[:,0])-np.sqrt(z[:,3]/z[:,0])
        # Centered bootstrap test under zero paired effect; distinct from CI.
        pa=min(1.,float((1+np.sum(abs(da-out['MAE_improvement'])>=abs(out['MAE_improvement'])))/2001))
        pr=min(1.,float((1+np.sum(abs(dr-out['RMSE_improvement'])>=abs(out['RMSE_improvement'])))/2001))
        out[name]=dict(blocks=len(ids),MAE_CI95=np.quantile(da,[.025,.975]).tolist(),RMSE_CI95=np.quantile(dr,[.025,.975]).tolist(),MAE_centered_bootstrap_p=pa,RMSE_centered_bootstrap_p=pr)
    return out

def holm(values):
    order=sorted(values,key=values.get); last=0.; out={}
    for i,k in enumerate(order):last=max(last,min(1.,values[k]*(len(order)-i)));out[k]=last
    return out
