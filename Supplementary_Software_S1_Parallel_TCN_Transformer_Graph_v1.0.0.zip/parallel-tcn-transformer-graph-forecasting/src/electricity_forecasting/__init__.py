"""Scientific components for publication-aware multi-location electricity-price forecasting."""
__version__ = "1.0.0"
