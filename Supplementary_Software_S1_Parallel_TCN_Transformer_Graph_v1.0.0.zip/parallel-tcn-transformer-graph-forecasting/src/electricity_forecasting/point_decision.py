"""Executed quantile integration, location correction and calibration-only shrinkage."""
from .constants import QUANTILE_LEVELS as LEVELS

def qmean(q):
    import numpy as np
    return ((q[...,:-1]+q[...,1:])*.5*np.diff(LEVELS)).sum(-1)+.005*(q[...,0]-(q[...,1]-q[...,0])/np.log(2))+.005*(q[...,-1]+(q[...,-1]-q[...,-2])/np.log(2))

def bias_fit(e):
    import numpy as np
    b=float(e.mean()); lo=0.; hi=1.
    if np.mean(abs(e-b))<=np.mean(abs(e))+1e-12:return b
    for _ in range(52):
        m=(lo+hi)/2
        if np.mean(abs(e-m*b))<=np.mean(abs(e))+1e-12:lo=m
        else:hi=m
    return lo*b

def gamma(y,r,a,routine):
 import numpy as np
 e=y-r;d=a-r;g=float(np.clip(np.mean(e*d)/max(float(np.mean(d*d)),1e-20),0,1))
 def good(t):
  return np.mean(abs(e-t*d))<=np.mean(abs(e))+1e-12 and (not routine.any() or np.mean(abs((e-t*d)[routine]))<=1.01*np.mean(abs(e[routine]))+1e-12)
 if good(g):return g
 lo=0.;hi=g
 for _ in range(52):
  mid=(lo+hi)/2
  if good(mid):lo=mid
  else:hi=mid
 return lo if lo>1e-10 else 0.


def choose_point(actions, expected_absolute_gain, expected_squared_gain, multiplier, shrinkage):
    """Frozen decision; parameters are selected in risk calibration, not evaluation."""
    import numpy as np
    index = np.argmax(expected_squared_gain + multiplier * expected_absolute_gain, axis=1)
    selected = actions[np.arange(len(actions)), index]
    return actions[:, 0] + shrinkage * (selected - actions[:, 0]), index
