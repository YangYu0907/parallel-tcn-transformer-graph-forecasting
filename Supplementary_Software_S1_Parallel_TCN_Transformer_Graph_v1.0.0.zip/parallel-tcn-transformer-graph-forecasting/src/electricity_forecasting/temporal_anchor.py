"""Executed CAISO DLinear anchor (288 historical observations)."""
def make_linear(nn,H=12):
 class EarlyDLinear(nn.Module):
  def __init__(self):
   super().__init__();self.season=nn.Linear(288,H);self.trend=nn.Linear(288,H)
   for layer in [self.season,self.trend]:nn.init.zeros_(layer.weight);nn.init.zeros_(layer.bias)
  def forward(self,x):
   import torch.nn.functional as fn
   z=x.transpose(1,2);trend=fn.avg_pool1d(fn.pad(z,(12,12),mode='replicate'),25,stride=1);return self.season(z-trend)+self.trend(trend)
 return EarlyDLinear()
