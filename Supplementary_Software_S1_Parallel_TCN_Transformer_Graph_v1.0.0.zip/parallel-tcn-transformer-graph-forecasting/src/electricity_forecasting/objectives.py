"""Normalized joint loss used by the executed expert fitting workflow."""
def joint_training_loss(model, quantiles, target, absolute_normalizer, squared_normalizer):
    import torch
    mean = model.mean(quantiles)
    residual = target[..., None] - quantiles
    pinball = torch.maximum(model.levels * residual, (model.levels - 1) * residual).mean()
    return ((mean - target).abs().mean() / absolute_normalizer
            + ((mean - target) ** 2).mean() / squared_normalizer
            + pinball / absolute_normalizer)
