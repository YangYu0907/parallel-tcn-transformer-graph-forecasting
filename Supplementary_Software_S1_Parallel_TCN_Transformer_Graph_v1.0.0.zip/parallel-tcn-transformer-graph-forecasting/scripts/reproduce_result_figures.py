"""Redraw only the eight existing figures; preserve all DOCX text and layout XML.
Publication figure style retained from the executed manuscript workflow.
No training, target data, altered comparisons, or invented uncertainty.
"""
from pathlib import Path
import sys, json, hashlib, zipfile, csv
import numpy as np
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
from matplotlib.patches import Rectangle, FancyArrowPatch
from matplotlib.lines import Line2D
from matplotlib.ticker import MaxNLocator, MultipleLocator
from PIL import Image, ImageDraw, ImageOps

ROOT=Path(__file__).parent.parent
OUT=ROOT/'generated'; FIG=OUT/'figures'; FIG.mkdir(parents=True,exist_ok=True)
S=json.loads((ROOT/'results/frozen_result_summaries.json').read_text(encoding='utf8'))
B=S['baselines']['results']; H=S['historical']; E=S['europe']; M=S['mechanism']
MAP=json.loads((ROOT/'data/manifests/figure_layout_map.json').read_text(encoding='utf8'))
COST=json.loads((ROOT/'results/optimization_receipts.json').read_text(encoding='utf8'))
BLUE='#2672A9'; MIDBLUE='#6198BD'; TEAL='#377D7A'; GRAY='#7A8790'; LIGHT='#D7DEE2'; INK='#263744'; LINE='#E2E7EB'
plt.rcParams.update({'font.family':['Arial','DejaVu Sans'],'font.size':8.6,'axes.titlesize':9.5,
 'axes.titleweight':'bold','axes.labelsize':8.6,'axes.labelcolor':INK,'text.color':INK,
 'xtick.labelsize':8.2,'ytick.labelsize':8.2,'xtick.color':INK,'ytick.color':INK,
 'axes.spines.top':False,'axes.spines.right':False,'axes.edgecolor':INK,'axes.linewidth':.75,
 'xtick.major.size':3,'ytick.major.size':3,'xtick.major.width':.65,'ytick.major.width':.65,
 'legend.fontsize':8.2,'legend.frameon':False,'svg.fonttype':'none','pdf.fonttype':42,
 'savefig.facecolor':'white','figure.facecolor':'white','hatch.linewidth':.45,'mathtext.fontset':'dejavusans'})
manifest=[]; numbers=[]; artist_checks=[]

def record(fig,field,value,source):numbers.append({'figure':fig,'field':field,'value':value,'source':source})
def newfig(n):
 m=MAP[n-1];return plt.figure(figsize=(6.65,6.65*int(m['extent']['cy'])/int(m['extent']['cx'])))
def finish(fig,n,name):
 for ax in fig.axes:
  if ax.axison:
   lo,hi=sorted(ax.get_xlim())
   ax.set_xticks([t for t in ax.get_xticks() if lo-1e-10 <= t <= hi+1e-10])
 fig.canvas.draw()
 renderer=fig.canvas.get_renderer(); fb=fig.bbox
 outside=[]
 for a in fig.findobj(matplotlib.text.Text):
  if a.get_visible() and a.get_text():
   box=a.get_window_extent(renderer)
   if box.width and box.height and (box.x0<-.5 or box.y0<-.5 or box.x1>fb.width+.5 or box.y1>fb.height+.5):outside.append(a.get_text())
 artist_checks.append({'figure':n,'text_outside_canvas':outside})
 for ext in ['png','pdf','svg']:fig.savefig(FIG/f'Fig{n:02d}_{name}.{ext}',dpi=600)
 fig.savefig(OUT/f'preview_{n:02d}.png',dpi=160)
 manifest.append({'figure':n,'name':name,'width_in':6.65,'height_in':fig.get_figheight(),
   'png_sha256':hashlib.sha256((FIG/f'Fig{n:02d}_{name}.png').read_bytes()).hexdigest(),
   'original_media':MAP[n-1]['part'],'minimum_intended_font_at_print_pt':8.0})
 plt.close(fig)
def title(ax,letter,text):ax.set_title(f'({letter})  {text}',loc='left',pad=8)
def grid(ax,which='y'):
 ax.set_axisbelow(True);ax.grid(axis=which,color=LINE,lw=.55)
def frame(fig):
 ax=fig.add_axes([.015,.02,.97,.96]);ax.set_xlim(0,100);ax.set_ylim(0,100);ax.axis('off');return ax
def txt(ax,x,y,s,fs=8.2,weight='normal',color=INK,ha='left',va='center'):
 return ax.text(x,y,s,fontsize=max(8.0,fs),fontweight=weight,color=color,ha=ha,va=va,linespacing=1.3)
def rect(ax,x,y,w,h,s='',fc='white',ec=GRAY,fs=8.1):
 ax.add_patch(Rectangle((x,y),w,h,facecolor=fc,edgecolor=ec,lw=.8))
 if s:txt(ax,x+w/2,y+h/2,s,fs,ha='center')
def arrow(ax,points,color=INK,ls='-',lw=.85):
 for p,q in zip(points[:-2],points[1:-1]):ax.plot([p[0],q[0]],[p[1],q[1]],color=color,lw=lw,ls=ls)
 ax.add_patch(FancyArrowPatch(points[-2],points[-1],arrowstyle='-|>',mutation_scale=7,color=color,lw=lw,linestyle=ls,shrinkA=0,shrinkB=0))

# Figure 1: aligned role rail and timing rule, followed by matched questions.
fig=newfig(1); ax=frame(fig)
txt(ax,1,97,'(a)  Chronological design',9,'bold')
stages=[('Expert fitting','2023','11,573 origins'),('Validation /\ncalibration','Jan–Mar 2024','4,826 / 4,296 origins'),('Risk fitting /\nselection','Apr–Dec 2024','19,425 / 14,995 origins'),('Development','Jan–Mar 2025','10,604 origins\n51 dates'),('Chronological\nreplay','EVAL / P8','192 / 178 origins')]
for i,(t,d,c) in enumerate(stages):
 x=1+i*19.8
 ax.plot([x,x+17.8],[89,89],color=BLUE if i<3 else TEAL,lw=2.1)
 txt(ax,x,82,t,8.0,'bold');txt(ax,x,74,d,8.0);txt(ax,x,67,c,8.0,color=GRAY)
 if i<4:arrow(ax,[(x+18.1,89),(x+19.2,89)],GRAY)
txt(ax,1,59,'Sequential roles; rail segments are schematic rather than proportional to duration.',8.0,color=GRAY)
txt(ax,1,52,'(b)  Information available at forecast issue',9,'bold')
arrow(ax,[(6,43),(95,43)],GRAY)
for x,lab,sub in [(9,'Publication','Recorded timestamp'),(46,'Forecast issue','Publication + 60 s ≤ issue'),(88,'Target interval','Realized price')]:
 ax.plot(x,43,'o',ms=4.5,color=BLUE if x<50 else GRAY)
 txt(ax,x,47,lab,8,'bold',ha='center');txt(ax,x,36,sub,8.0,ha='center')
txt(ax,1,28,'Training labels: target realization + 24 h must precede the assigned fitting boundary.',8.0,color=GRAY)
txt(ax,1,19,'(c)  Matched comparisons and market replication',9,'bold')
for x,t,s in [(1,'Information × history','Masked / admitted information\nRecent / extended risk history'),(36,'Spatial aggregation','Dynamic / static / dense\nShared inputs and selection rule'),(72,'European replication','2012–2014 → 2015\nFrance · Germany · Belgium')]:
 txt(ax,x,11,t,8.1,'bold',color=BLUE);txt(ax,x,3.4,s,8.0)
finish(fig,1,'protocol')

# Figure 3: same bars and same denominators, easier-to-read values and print encoding.
fig=newfig(3);axs=fig.subplots(1,2)
models=[('UPDATED_I1_HGB','Updated HGB',BLUE,''),('UPDATED_I1_RIDGE','Updated Ridge',TEAL,'//'),('DLINEAR','DLinear',LIGHT,'..')]
for j,key in enumerate(['MAE','RMSE']):
 ax=axs[j]
 for k,(m,label,color,hatch) in enumerate(models):
  vals=[100*(1-B[p]['metrics']['SELECTED']['all'][key]/B[p]['metrics'][m]['all'][key]) for p in ['HISTORICAL_DEV_CHECK','EVAL','P8']]
  xx=np.arange(3)+(k-1)*.235
  bars=ax.bar(xx,vals,.215,color=color,edgecolor=INK,lw=.45,hatch=hatch,label=label)
  for x,v in zip(xx,vals):ax.annotate(f'{v:.2f}',(x,v),xytext=(0,3),textcoords='offset points',ha='center',fontsize=8.0)
  record(3,key+'_'+m,vals,'baselines.results.*.metrics')
 ax.set_xticks(range(3),['Development','EVAL','P8']);ax.set_ylim(0,16);ax.set_yticks([0,4,8,12,16]);ax.set_ylabel('Error reduction (%)');grid(ax);title(ax,chr(97+j),'Overall '+key)
fig.legend(*axs[0].get_legend_handles_labels(),loc='lower center',ncol=3,bbox_to_anchor=(.52,.005),columnspacing=1.6,handlelength=1.5)
fig.subplots_adjust(left=.085,right=.985,bottom=.23,top=.86,wspace=.30)
finish(fig,3,'overall_comparisons')

def interval(ax,y,v,key,scale=1,figid=0,field=''):
 x=v[key+'_improvement']*scale
 for off,kind,col,mark in [(-.12,'date',BLUE,'o'),(.12,'seven_day',GRAY,'D')]:
  lo,hi=np.asarray(v[kind][key+'_CI95'])*scale
  ax.plot([lo,hi],[y+off]*2,color=col,lw=1.25 if kind=='date' else .85)
  ax.plot([lo,lo],[y+off-.045,y+off+.045],color=col,lw=.7)
  ax.plot([hi,hi],[y+off-.045,y+off+.045],color=col,lw=.7)
  ax.plot(x,y+off,marker=mark,color=col,ls='',ms=4 if kind=='date' else 3.5,mec='white',mew=.35)
  record(figid,field+'_'+key+'_'+kind,{'point':x,'lower':float(lo),'upper':float(hi)},'frozen paired_comparisons')
def ilegend(fig,bottom=.015):
 handles=[Line2D([0],[0],color=BLUE,marker='o',lw=1.25,ms=4,label='Date-block 95% CI'),Line2D([0],[0],color=GRAY,marker='D',lw=.85,ms=3.5,label='Seven-day-block 95% CI')]
 fig.legend(handles=handles,loc='lower center',ncol=2,bbox_to_anchor=(.53,bottom),handlelength=2,columnspacing=2)

# Figure 4: preserve both matched information contrasts, all original intervals.
fig=newfig(4);axs=fig.subplots(2,2)
for i,state in enumerate(['all','S2']):
 for j,key in enumerate(['MAE','RMSE']):
  ax=axs[i,j]
  for y,c in enumerate(['C_vs_A','D_vs_B']):interval(ax,y,H['paired_comparisons'][c][state],key,figid=4,field=c+'_'+state)
  ax.axvline(0,color=INK,ls=(0,(3,3)),lw=.7)
  ax.set_yticks([0,1],['C − A','D − B']);ax.set_ylim(1.48,-.48);grid(ax,'x')
  ax.set_xlabel('Error reduction (USD/MWh)');title(ax,chr(97+i*2+j),('Overall' if i==0 else 'Sudden extreme')+' '+key)
  lo,hi=ax.get_xlim();ax.set_xlim(min(lo,-.025*hi),hi*1.03);ax.xaxis.set_major_locator(MaxNLocator(4))
fig.subplots_adjust(left=.10,right=.98,top=.90,bottom=.18,wspace=.34,hspace=.68)
ilegend(fig,.005);finish(fig,4,'information_increment')

# Figure 5: retain the two-panel paired S2 comparison and original numeric labels.
fig=newfig(5);axs=fig.subplots(1,2)
for i,p in enumerate(['EVAL','P8']):
 ax=axs[i]
 for j,(m,lab,color,hatch) in enumerate([('V7','Retained contextual reference',LIGHT,'//'),('SELECTED','Selected system',BLUE,'')]):
  vals=[B[p]['metrics'][m]['S2'][k] for k in ['MAE','RMSE']];xx=np.arange(2)+(j-.5)*.31
  ax.bar(xx,vals,.285,label=lab,color=color,edgecolor=INK,lw=.5,hatch=hatch)
  for x,v in zip(xx,vals):ax.annotate(f'{v:.2f}',(x,v),xytext=(0,4),textcoords='offset points',ha='center',fontsize=8.0)
  record(5,p+'_'+m,vals,'baselines.results.'+p+'.metrics.'+m+'.S2')
 ax.set_xticks([0,1],['S2 MAE','S2 RMSE']);ax.set_ylim(0,710 if i==0 else 190);ax.set_yticks([0,200,400,600] if i==0 else [0,50,100,150]);ax.set_ylabel('Error (USD/MWh)');grid(ax);title(ax,chr(97+i),p)
fig.legend(*axs[0].get_legend_handles_labels(),loc='lower center',ncol=2,bbox_to_anchor=(.54,.005),columnspacing=1.8)
fig.subplots_adjust(left=.10,right=.985,bottom=.24,top=.86,wspace=.36)
finish(fig,5,'sudden_extremes')

# Figure 6: complete matched graph contrasts, with readable row headers.
fig=newfig(6);axs=fig.subplots(4,2)
for row,(panel,metrics,comp) in enumerate([
 ('CAISO development',H['metrics'],H['paired_comparisons']),
 ('CAISO EVAL',M['panels']['EVAL']['metrics'],M['panels']['EVAL']['comparisons']),
 ('CAISO P8',M['panels']['P8']['metrics'],M['panels']['P8']['comparisons']),
 ('Europe 2015',E['metrics'],E['comparisons'])]):
 for col,key in enumerate(['MAE','RMSE']):
  ax=axs[row,col]
  for y,base in enumerate(['I1_STATIC','I1_FLAT']):
   interval(ax,y,comp['I1_DYNAMIC_vs_'+base]['all'],key,100/metrics[base]['all'][key],6,panel+'_'+base)
  ax.axvline(0,color=INK,ls=(0,(3,3)),lw=.7);ax.set_yticks([0,1],['Static','Dense']);ax.set_ylim(1.5,-.5);grid(ax,'x')
  title(ax,chr(97+row*2+col),panel+' · '+key)
  ax.xaxis.set_major_locator(MaxNLocator(4));ax.tick_params(labelsize=8.0)
  if row==3:ax.set_xlabel('Error reduction (%)')
fig.subplots_adjust(left=.10,right=.985,bottom=.13,top=.94,wspace=.37,hspace=.95)
ilegend(fig,.008);finish(fig,6,'graph_controls')

# Figure 7: actual recorded active sizes and selected/completed epochs.
fig=newfig(7);ax1=fig.add_axes([.095,.30,.31,.58]);ax2=fig.add_axes([.60,.30,.375,.58])
arms=[('I1_DYNAMIC','Dynamic',BLUE),('I1_STATIC','Static',TEAL),('I1_FLAT','Dense',GRAY)]
for i,(arm,lab,col) in enumerate(arms):
 v=next(r['active_parameters'] for r in COST if r['arm']==arm)
 ax1.barh(i,v/1000,.52,color=col,edgecolor=INK,lw=.45)
 ax1.annotate(f'{v:,}',(v/1000,i),xytext=(4,0),textcoords='offset points',va='center',fontsize=8.0)
 record(7,lab+'_active_parameters',v,'cost_receipts.json')
ax1.set_yticks(range(3),[a[1] for a in arms]);ax1.set_ylim(2.65,-.65);ax1.set_xlim(0,315);ax1.set_xticks([0,100,200,300]);ax1.set_xlabel('Active parameters (thousands)',fontsize=8.0);grid(ax1,'x');title(ax1,'a','Model size')
ylabs=[]
for si,seed in enumerate([20260813,20260814,20260815]):
 for ai,(arm,lab,col) in enumerate(arms):
  y=si*3+ai;r=next(x for x in COST if x['seed']==seed and x['arm']==arm)
  ax2.plot([r['selected_epoch'],r['epochs']],[y,y],color=col,lw=1)
  ax2.plot(r['selected_epoch'],y,marker='|',ms=6,color=col,mew=1)
  ax2.plot(r['epochs'],y,marker='o',ms=3.3,color=col)
  ylabs.append(f'{str(seed)[-2:]} / {lab}')
  record(7,f'{seed}_{arm}',{'selected':r['selected_epoch'],'completed':r['epochs']},'cost_receipts.json')
ax2.set_yticks(range(9),ylabs,fontsize=8.0);ax2.set_ylim(8.6,-.6);ax2.set_xlim(0,24);ax2.set_xticks([0,5,10,15,20]);ax2.set_xlabel('Epoch');grid(ax2,'x');title(ax2,'b','Checkpoint selection')
handles=[Line2D([0],[0],marker='|',color=INK,ls='',ms=6,label='Selected'),Line2D([0],[0],marker='o',color=INK,ls='',ms=3.3,label='Completed')]
fig.legend(handles=handles,loc='lower right',ncol=2,bbox_to_anchor=(.98,.005),fontsize=8.0)
finish(fig,7,'training_receipts')

# Figure 8: the exact original WIS13 values, same markets and zero-based bars.
fig=newfig(8);axs=fig.subplots(1,2)
for j,(labs,vals,unit) in enumerate([
 (['Static','State-\naware','Enhanced','Expanded'],[8.915091071995308,8.502677641915582,8.405785527776333,8.206328247228539],'USD/MWh'),
 (['Anchored','Shrunk\npool','Direct\nCQR'],[2.834137923932854,2.772429864287872,2.767583376226995],'EUR/MWh')]):
 ax=axs[j];cols=[LIGHT]+[MIDBLUE]*(len(vals)-2)+[BLUE]
 for i,(v,c) in enumerate(zip(vals,cols)):
  ax.bar(i,v,.61,color=c,edgecolor=INK,lw=.5,hatch='//' if i==0 else None)
  ax.annotate(f'{v:.4f}',(i,v),xytext=(0,4),textcoords='offset points',ha='center',fontsize=8.0)
 ax.set_xticks(range(len(labs)),labs,fontsize=8.0);ax.set_ylim(0,10.4 if j==0 else 3.3);ax.set_ylabel(f'WIS13 ({unit})');grid(ax);title(ax,chr(97+j),'CAISO' if j==0 else 'Europe')
 if j==0:ax.set_yticks([0,2,4,6,8,10])
 else:ax.set_yticks([0,1,2,3])
 record(8,'CAISO' if j==0 else 'Europe',vals,'build_final_revision.py verified probability figure inputs')
fig.subplots_adjust(left=.10,right=.985,bottom=.20,top=.86,wspace=.35)
finish(fig,8,'probabilistic_scores')


(OUT/"PLOT_DATA.json").write_text(json.dumps(numbers,ensure_ascii=False,indent=2),encoding="utf8")
(OUT/"CHART_STYLE_QA.json").write_text(json.dumps({"figures":manifest,"artist_checks":artist_checks},ensure_ascii=False,indent=2),encoding="utf8")
