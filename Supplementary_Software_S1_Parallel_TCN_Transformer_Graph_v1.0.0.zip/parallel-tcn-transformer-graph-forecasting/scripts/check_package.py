"""Verify packaged files and table dimensions without opening any raw target array."""
from pathlib import Path
import csv,hashlib,json
ROOT=Path(__file__).resolve().parents[1]
manifest=json.loads((ROOT/'FILE_MANIFEST.json').read_text(encoding='utf-8'))
for record in manifest:
    file=ROOT/record['path']
    assert file.is_file(),file
    assert hashlib.sha256(file.read_bytes()).hexdigest()==record['sha256'],file
tables=[]
for file in sorted((ROOT/'data/processed').glob('table_*.csv')):
    with file.open(encoding='utf-8-sig',newline='') as f: rows=list(csv.reader(f))
    tables.append({'table':file.stem,'rows':len(rows),'column_counts':sorted(set(map(len,rows)))})
assert len(tables)==15
print(json.dumps({'verified_files':len(manifest),'tables':tables},indent=2))
