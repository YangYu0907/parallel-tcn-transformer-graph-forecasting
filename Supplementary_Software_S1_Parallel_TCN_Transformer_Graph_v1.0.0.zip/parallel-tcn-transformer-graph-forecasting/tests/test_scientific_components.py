"""Small deterministic arithmetic checks, not a rerun of the research experiment."""
import sys
from pathlib import Path
sys.path.insert(0,str(Path(__file__).resolve().parents[1]/'src'))
import numpy as np
from electricity_forecasting.evaluation import metrics,compare,holm
from electricity_forecasting.point_decision import qmean,bias_fit,gamma,choose_point
from electricity_forecasting.admission import source_available,labels_mature
q=np.full((3,13),42.0);np.testing.assert_allclose(qmean(q),42.0)
y=np.array([1.,2.,3.,4.]);p=np.stack([y+.5,y+.5,y+.5]);r=np.stack([y+1.,y+1.,y+1.]);mask=np.ones(4,bool)
assert metrics(y,p,mask)=={'cells':4,'MAE':.5,'RMSE':.5}
c=compare(y,p,r,np.arange(4),mask);assert c['MAE_improvement']==.5 and c['RMSE_improvement']==.5
np.testing.assert_allclose(c['date']['MAE_CI95'],[.5,.5])
e=np.array([-1.,-1.,3.,5.]);b=bias_fit(e);assert np.mean(abs(e-b))<=np.mean(abs(e))+1e-10
g=gamma(y,y+1,y+.5,mask);assert 0<=g<=1
a=np.array([[1.,2.,3.],[5.,6.,7.]]);v,idx=choose_point(a,np.zeros_like(a),np.array([[0.,1.,2.],[2.,1.,0.]]),1.,.5)
np.testing.assert_allclose(v,[2.,5.]);assert source_available(100,160) and not source_available(101,160)
assert labels_mature(0,86401) and not labels_mature(0,86400)
assert holm({'a':.01,'b':.1})=={'a':.02,'b':.1}
print('Scientific component arithmetic checks passed; no model training or target-data access.')
